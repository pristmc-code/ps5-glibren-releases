/* teste-pad - payload de teste para PS5 (PristMC).
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Cria um DualSense virtual so com open("/dev/hid") + ioctl() do PROPRIO
 * processo, aperta o direcional DIREITA duas vezes e apaga o controle.
 * Sem ptrace, sem injecao em outro processo, sem escrita na memoria do
 * kernel, sem mudar ucred/authid, sem code cave.
 *
 * Baseado em (GPL-3):
 *   - Darkatek7/ProsperoSunshine  src/platform/ps5/pad.c  (ioctls add/insert/delete,
 *     layout do bloco de 0xA8 bytes, repouso do sensor de movimento)
 *   - Gl0ttis/ps5-mcp  src/pad.c, src/pad.h, src/backend.h  (valores dos botoes,
 *     reenvio do estado a cada 8 ms, sceMbusBindDeviceWithUserId via dlopen)
 *
 * Ligar o passo extra de "bind" (desligado por padrao): criar o arquivo
 * /data/teste-pad.bind antes de enviar, ou rodar com argumento --bind ou
 * variavel TESTE_PAD_BIND=1.
 */
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#define ARQ_LOG "/data/teste-pad.log"
#define ARQ_BIND "/data/teste-pad.bind"

#define BLOCO 0xA8
#define IOCTL_ADD 0xC018482AUL
#define IOCTL_INSERT 0x8018482CUL
#define IOCTL_DELETE 0x80104850UL
#define CLASSE_PAD 3
#define SUBTIPO_PAD 1
#define USUARIO_SEM_DONO 1

#define BTN_RIGHT 0x00000020u /* ps5-mcp src/backend.h */

#define INTERVALO_MS 8 /* ps5-mcp: pad que fica quieto vira "solto" e depois "sumiu" */

/* ---- notificacao (mesmo padrao do websrv / glibren) ---- */
typedef struct {
  char reservado[45];
  char mensagem[3075];
} pedido_notificacao_t;
int sceKernelSendNotificationRequest(int, pedido_notificacao_t *, size_t, int);
int sceUserServiceInitialize(void *) __attribute__((weak));
int sceUserServiceGetForegroundUser(int *) __attribute__((weak));

/* ---- estado global (para apagar o pad em qualquer saida) ---- */
static volatile int g_fd = -1;
static volatile int g_handle = -1;
static uint8_t g_bloco[BLOCO];

static void diario(const char *fmt, ...) {
  char linha[512];
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  int n = snprintf(linha, sizeof linha, "[%ld.%03ld] ", (long)ts.tv_sec, ts.tv_nsec / 1000000L);
  va_list ap;
  va_start(ap, fmt);
  n += vsnprintf(linha + n, sizeof linha - (size_t)n, fmt, ap);
  va_end(ap);
  if(n > (int)sizeof linha - 2) n = (int)sizeof linha - 2;
  linha[n++] = '\n';
  linha[n] = 0;
  fputs(linha, stdout);
  fflush(stdout);
  int fd = open(ARQ_LOG, O_WRONLY | O_CREAT | O_APPEND, 0666);
  if(fd >= 0) {
    write(fd, linha, (size_t)n);
    close(fd);
  }
}

static void notificar(const char *texto) {
  pedido_notificacao_t req;
  memset(&req, 0, sizeof req);
  snprintf(req.mensagem, sizeof req.mensagem, "%s", texto);
  int r = sceKernelSendNotificationRequest(0, &req, sizeof req, 0);
  diario("notificacao \"%s\" -> %d", texto, r);
}

static void dormir_ms(unsigned ms) {
  struct timespec t = {(time_t)(ms / 1000), (long)(ms % 1000) * 1000000L};
  while(nanosleep(&t, &t) != 0 && errno == EINTR) {
  }
}

/* ---- ioctls (ProsperoSunshine pad.c) ---- */
static int apagar_pad(void) {
  if(g_fd < 0 || g_handle < 0) return 0;
  struct {
    uint8_t op;
    uint8_t pad[7];
    uint32_t handle;
    uint32_t pad2;
  } del = {5, {0}, (uint32_t)g_handle, 0};
  int r = ioctl(g_fd, IOCTL_DELETE, &del);
  int e = r ? errno : 0;
  g_handle = -1;
  return r ? -e : 0;
}

static void ao_sinal(int sinal) {
  /* so chamadas seguras em sinal: ioctl/close/write/_exit */
  apagar_pad();
  if(g_fd >= 0) close(g_fd);
  char linha[64];
  int n = snprintf(linha, sizeof linha, "teste-pad: sinal %d, pad apagado\n", sinal);
  int fd = open(ARQ_LOG, O_WRONLY | O_CREAT | O_APPEND, 0666);
  if(fd >= 0) {
    write(fd, linha, (size_t)n);
    close(fd);
  }
  _exit(128 + sinal);
}

static void estado_repouso(uint32_t botoes) {
  /* bloco de estado: botoes @0xC, analogicos @0x10..0x13 = 0x80, l2/r2 @0x14/0x15 = 0,
     byte @0x17 = 1, toque @0x1C = 0, orientacao @0x78 = (0,0,0,1), giro @0x88 = 0,
     aceleracao @0x94 = (0,1,0) -- igual ao ProsperoSunshine (repouso do Remote Play) */
  const float orient[4] = {0, 0, 0, 1}, giro[3] = {0, 0, 0}, grav[3] = {0, 1, 0};
  memset(g_bloco, 0, sizeof g_bloco);
  memcpy(g_bloco + 0x0C, &botoes, 4);
  g_bloco[0x10] = g_bloco[0x11] = g_bloco[0x12] = g_bloco[0x13] = 0x80;
  g_bloco[0x14] = g_bloco[0x15] = 0;
  g_bloco[0x17] = 1;
  g_bloco[0x1C] = 0;
  memcpy(g_bloco + 0x78, orient, sizeof orient);
  memcpy(g_bloco + 0x88, giro, sizeof giro);
  memcpy(g_bloco + 0x94, grav, sizeof grav);
}

static int inserir(void) {
  struct {
    uint32_t handle;
    uint32_t pad;
    uint64_t estado;
    uint8_t zero;
    uint8_t pad2[7];
  } req = {(uint32_t)g_handle, 0, (uint64_t)(uintptr_t)g_bloco, 0, {0}};
  return ioctl(g_fd, IOCTL_INSERT, &req) == 0 ? 0 : -(errno ? errno : EIO);
}

/* mantem o estado atual por ms, reenviando a cada 8 ms; conta falhas */
static unsigned g_insercoes, g_falhas;
static int g_ultimo_erro;
static void segurar(unsigned ms) {
  unsigned passos = ms / INTERVALO_MS;
  if(passos == 0) passos = 1;
  for(unsigned i = 0; i < passos; i++) {
    int r = inserir();
    g_insercoes++;
    if(r) {
      if(g_falhas < 3 || r != g_ultimo_erro) diario("insert falhou: errno %d (%s)", -r, strerror(-r));
      g_falhas++;
      g_ultimo_erro = r;
    }
    dormir_ms(INTERVALO_MS);
  }
}

static int adicionar(int usuario, int *handle_saida) {
  uint8_t desc[BLOCO];
  memset(desc, 0, sizeof desc);
  desc[0] = CLASSE_PAD;
  memcpy(desc + 0x1C, &usuario, 4);
  desc[0x20] = SUBTIPO_PAD;
  int handle = -1;
  struct {
    uint32_t op;
    uint32_t pad;
    uint64_t desc;
    uint64_t handle;
  } req = {3, 0, (uint64_t)(uintptr_t)desc, (uint64_t)(uintptr_t)&handle};
  errno = 0;
  int r = ioctl(g_fd, IOCTL_ADD, &req);
  int e = errno;
  diario("add(usuario 0x%x) -> ioctl %d errno %d (%s) handle %d", (unsigned)usuario, r, r ? e : 0,
         r ? strerror(e) : "ok", handle);
  *handle_saida = handle;
  if(r != 0) return -(e ? e : EIO);
  if(handle < 0) return -EIO;
  return 0;
}

static int bind_ligado(int argc, char **argv) {
  for(int i = 1; i < argc; i++)
    if(argv[i] && strcmp(argv[i], "--bind") == 0) return 1;
  const char *v = getenv("TESTE_PAD_BIND");
  if(v && v[0] == '1') return 1;
  struct stat st;
  return stat(ARQ_BIND, &st) == 0;
}

static void tentar_bind(int usuario) {
  /* passo 2 (opcional): dlopen da libSceMbus NO NOSSO processo e bind do pad ao usuario.
     O ps5-mcp usa o device id lido do klog; aqui nao lemos o klog, entao tentamos o
     handle como device id (o ProsperoSunshine usa o handle como id do aparelho). */
  void *lib = dlopen("/system/common/lib/libSceMbus.sprx", RTLD_NOW | RTLD_GLOBAL);
  if(!lib) lib = dlopen("libSceMbus.sprx", RTLD_NOW | RTLD_GLOBAL);
  if(!lib) {
    const char *e = dlerror();
    diario("bind: dlopen libSceMbus falhou (%s)", e ? e : "?");
    return;
  }
  int32_t (*bind)(uint64_t, int32_t) = (int32_t (*)(uint64_t, int32_t))dlsym(lib, "sceMbusBindDeviceWithUserId");
  if(!bind) {
    diario("bind: sceMbusBindDeviceWithUserId nao encontrada");
    return;
  }
  int32_t r = bind((uint64_t)(uint32_t)g_handle, usuario);
  diario("bind: sceMbusBindDeviceWithUserId(0x%x, 0x%x) -> 0x%08x", (unsigned)g_handle, (unsigned)usuario,
         (unsigned)r);
}

int main(int argc, char **argv) {
  char msg[160];
  const char *etapa = "inicio";
  int erro = 0;

  static const int sinais[] = {SIGSEGV, SIGBUS, SIGFPE, SIGILL, SIGABRT, SIGTERM, SIGINT, SIGHUP, SIGPIPE};
  for(size_t i = 0; i < sizeof sinais / sizeof *sinais; i++) signal(sinais[i], ao_sinal);

  diario("==== teste-pad 1.0 (metodo limpo: so open + ioctl em /dev/hid) ====");
  notificar("teste-pad: iniciando");

  /* usuario em primeiro plano */
  int usuario = -1;
  if(sceUserServiceInitialize) {
    int r = sceUserServiceInitialize(NULL);
    diario("sceUserServiceInitialize -> 0x%08x", (unsigned)r);
  } else {
    diario("sceUserServiceInitialize ausente");
  }
  if(sceUserServiceGetForegroundUser) {
    int r = sceUserServiceGetForegroundUser(&usuario);
    diario("sceUserServiceGetForegroundUser -> 0x%08x usuario 0x%x", (unsigned)r, (unsigned)usuario);
    if(r != 0) usuario = -1;
  } else {
    diario("sceUserServiceGetForegroundUser ausente");
  }

  etapa = "open /dev/hid";
  errno = 0;
  int fd = open("/dev/hid", O_RDONLY);
  diario("open(/dev/hid, O_RDONLY) -> %d errno %d (%s)", fd, fd < 0 ? errno : 0, fd < 0 ? strerror(errno) : "ok");
  if(fd < 0) {
    erro = errno;
    goto falhou;
  }
  g_fd = fd;

  etapa = "add";
  int handle = -1;
  int r = -1;
  if(usuario > USUARIO_SEM_DONO) r = adicionar(usuario, &handle);
  if(r != 0) {
    /* ps5-mcp (13.60): para o usuario real o add pode recusar; com o usuario 1 ("sem dono")
       o pad nasce e o PS5 pergunta "quem esta usando este controle" */
    diario("tentando add com usuario 1 (sem dono)");
    r = adicionar(USUARIO_SEM_DONO, &handle);
  }
  if(r != 0) {
    erro = -r;
    goto falhou;
  }
  g_handle = handle;
  diario("pad criado: handle %d", handle);

  if(bind_ligado(argc, argv)) {
    if(usuario > USUARIO_SEM_DONO)
      tentar_bind(usuario);
    else
      diario("bind: pulado (sem usuario em primeiro plano)");
  } else {
    diario("bind: desligado (crie %s para ligar)", ARQ_BIND);
  }

  etapa = "insert";
  estado_repouso(0);
  int r1 = inserir();
  diario("insert inicial (neutro) -> %d%s%s", r1, r1 ? " " : "", r1 ? strerror(-r1) : "");
  if(r1 != 0) {
    erro = -r1;
    goto falhou;
  }
  diario("esperando 3 s (neutro, reenviando a cada %d ms)", INTERVALO_MS);
  segurar(3000);

  for(int i = 1; i <= 2; i++) {
    diario("DIREITA %d: aperta 150 ms", i);
    estado_repouso(BTN_RIGHT);
    segurar(150);
    estado_repouso(0);
    diario("DIREITA %d: solta, espera 500 ms", i);
    segurar(500);
  }
  diario("esperando 2 s (neutro)");
  segurar(2000);
  diario("insercoes %u, falhas %u, ultimo erro %d", g_insercoes, g_falhas, -g_ultimo_erro);

  etapa = "delete";
  int hfinal = g_handle;
  int rd = apagar_pad();
  diario("delete(handle %d) -> %d%s%s", hfinal, rd, rd ? " " : "", rd ? strerror(-rd) : "");
  close(g_fd);
  g_fd = -1;
  if(g_falhas > 0 && g_falhas == g_insercoes) {
    etapa = "insert";
    erro = -g_ultimo_erro;
    goto falhou_sem_pad;
  }
  if(rd != 0) {
    erro = -rd;
    goto falhou_sem_pad;
  }
  snprintf(msg, sizeof msg, "teste-pad: ok (handle %d)", hfinal);
  diario("RESULTADO: %s", msg);
  notificar(msg);
  diario("==== fim ====");
  return 0;

falhou:
  if(g_handle >= 0) {
    int rx = apagar_pad();
    diario("delete (saida de erro) -> %d", rx);
  }
  if(g_fd >= 0) {
    close(g_fd);
    g_fd = -1;
  }
falhou_sem_pad:
  snprintf(msg, sizeof msg, "teste-pad: falhou em %s errno %d", etapa, erro);
  diario("RESULTADO: %s (%s)", msg, strerror(erro));
  notificar(msg);
  diario("==== fim ====");
  return 1;
}
