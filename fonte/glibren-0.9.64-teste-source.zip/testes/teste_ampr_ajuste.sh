#!/bin/bash
# Testa a "Velocidade do ampr" (0.9.63) na versao de PC: ampr-emu-ng de depuracao falso na GLR_TESTE_AMPR_PORTA (texto
# puro ou com linha HTTP, um cliente por vez, /metrics com contadores que crescem, /set com e sem pares, erro de
# gravacao, /threads, /fsfail, /bench), ajustes validados, voltar ao padrao (GLR_TESTE_MONTADOR no lugar de /data),
# medidas (resumo, rodizio de 40, apagar com tentativa de sair da pasta), pareamento, diagnostico com as medidas, trecho
# (diferenca fim - inicio, sem os *_max), cronometro, sugestao do Claude pelo GitHub falso, conjuntos salvos, enviar uma
# medida (higienizada) e o teste de disco sem jogo.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_ampr_ajuste.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8941; PORTA_GH=8942; PORTA_AMPR=8943
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R="http://$IP:$PORTA"
T=/root/glr-ampr-ajuste; DADOS=$T/dados; M=$T/montador; D=$T/disco; GH=$T/gh
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$(echo "$2" | head -c 700)] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
codigo() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
estado() { curl -s "$L/api/ampr/ajustes"; }
rm -rf "$T"; mkdir -p "$DADOS" "$M" "$D/jogos" "$GH/recebido" "$T/jobe"
printf 'language = pt-BR\nfolder = %s/\n' "$T" > "$DADOS/config.ini"
KJOBE="github_pat_11JOBE0000000000000000_abcdefghijklmnopqrstuvwxyz0123456789JOBEjobe1234"

# ampr-emu-ng falso. $T/ampr.modo: "http" (com linha de status) ou "cru"; "erro_set" = o /set nao grava o arquivo.
cat > "$T/ampr.py" <<'FIM'
import json, re, socket, sys, urllib.parse
porta, pasta = int(sys.argv[1]), sys.argv[2]
knobs = [["decoded_mib", 136, 0, 512, 0], ["workers", 4, 1, 16, 0], ["spin_us", 100, 0, 200, 1], ["lane_eop_overlap", 1, 0, 1, 1],
         ["knob_futuro", 7, 0, 9, 1]]
k = [0]
def lista():
    return "knobs (/data/ampr_emu_tune.txt):\n" + "".join("%s=%d [%d..%d] %s\n" % (n, v, a, b, "live" if l else "next launch") for n, v, a, b, l in knobs)
def metrics():
    k[0] += 1; m = k[0]
    c = {"job_totals": 100 * m, "job_total_ns": 100 * m * 2000000, "job_total_ns_max": 9000000, "apr_reads": 10 * m,
         "apr_read_ns": 10 * m * 1000000, "apr_read_ns_max": 5000000, "decodes": 50 * m, "decode_ns": 50 * m * 30000,
         "cache_hits": 90 * m, "cache_misses": 10 * m, "pack_disk_reads": 5 * m, "pack_disk_bytes": 5 * m * 262144,
         "pack_jobs": 5 * m, "pack_job_ns": 5 * m * 3000000, "pack_job_ns_max": 7000000, "job_order_waits": 20 * m,
         "job_order_wait_ns": 20 * m * 500000, "job_first_issues": 10 * m, "job_first_issue_ns": 10 * m * 1000000,
         "decode_errors": 0, "pack_job_errors": 2}
    return "build ampr-emu-ng 0.6.0 4db1b08 debug\npack_format zstd\n" + "".join("%s %d\n" % kv for kv in c.items()) + "pool_free 3\ntune_spin_us 100\n"
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("127.0.0.1", porta)); s.listen(8)
while True:
    c, _ = s.accept(); c.settimeout(3)
    try: req = c.recv(4096).decode()
    except Exception: req = ""
    linha = req.split("\r\n")[0]
    open(pasta + "/ampr.pedidos", "a").write(linha + "\n")
    modo = open(pasta + "/ampr.modo").read().strip()
    alvo = linha.split(" ")[1] if linha.count(" ") >= 2 else "/"
    u = urllib.parse.urlparse(alvo)
    if u.path == "/metrics": corpo = metrics()
    elif u.path == "/set":
        corpo = ""
        if u.query:
            for par in u.query.split("&"):
                m = re.fullmatch(r"([a-z_0-9]+)=(\d+)", par)
                kn = [x for x in knobs if m and x[0] == m.group(1)]
                if not kn or not (kn[0][2] <= int(m.group(2)) <= kn[0][3]):
                    corpo += "error: bad pair '%s' (later pairs not applied)\n" % par; break
                kn[0][1] = int(m.group(2))
            if modo == "erro_set": corpo += "error: could not write /data/ampr_emu_tune.txt\n"
        corpo += lista()
    elif u.path == "/threads": corpo = "threads 12\nworker 0 decode busy\n"
    elif u.path == "/fsfail": corpo = "fsfail 0\n"
    elif u.path == "/bench": corpo = "bench volume 0: 812.5 MB/s em 2.0 s\n"
    else: corpo = "not found\n"
    if modo == "http" or modo == "erro_set": c.sendall(("HTTP/1.0 200 OK\r\nContent-Type: text/plain\r\n\r\n" + corpo).encode())
    else: c.sendall(corpo.encode())
    c.close()
FIM

# GitHub falso: GET de contents/glibren/ampr-sugestoes.json (de $GH/sugestao.json; sem arquivo = 404) e PUT guardado
cat > "$T/gh.py" <<'FIM'
import base64, http.server, json, os, sys
pasta = sys.argv[2]
pre = "/repos/pristmc-code/ps5-diagnosticos/contents/"
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def responder(self, cod, corpo):
        self.send_response(cod); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(corpo))); self.end_headers(); self.wfile.write(corpo)
    def do_GET(self):
        open(pasta + "/gets", "a").write(self.path + " " + (self.headers.get("Authorization") or "") + "\n")
        f = pasta + "/sugestao.json"
        if self.path != pre + "glibren/ampr-sugestoes.json" or not os.path.exists(f): return self.responder(404, b'{"message":"Not Found"}')
        b = base64.encodebytes(open(f, "rb").read()).decode()
        self.responder(200, json.dumps({"name": "ampr-sugestoes.json", "encoding": "base64", "content": b}).encode())
    def do_PUT(self):
        n = int(self.headers.get("Content-Length") or 0); j = json.loads(self.rfile.read(n))
        destino = os.path.join(pasta, "recebido", self.path[len(pre):])
        os.makedirs(os.path.dirname(destino), exist_ok=True)
        open(destino, "wb").write(base64.b64decode(j["content"]))
        self.responder(201, b'{"content":{}}')
http.server.ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1])), H).serve_forever()
FIM
python3 -I "$T/gh.py" $PORTA_GH "$GH" > "$T/gh.log" 2>&1 & PID_GH=$!

inicia() {
  GLR_TESTE_GITHUB="http://127.0.0.1:$PORTA_GH" GLR_TESTE_JOBE_TOKEN="$T/jobe/token" GLR_TESTE_MONTADOR="$M" GLR_TESTE_ARQ_RAIZES="$D" \
  GLR_TESTE_DIAG_PASTA=teste GLR_TESTE_FW=12.00 GLR_TESTE_AMPR_PORTA=$PORTA_AMPR GLR_TESTE_AMOSTRA_MS=200 GLR_TESTE_DISCO_S=2 \
  GLR_TESTE_ABERTOS="$T/abertos" GLR_TESTE_FPS=60 "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
inicia

echo "--- sem jogo com o ampr de depuracao"
E=$(estado)
confere "fora do ar"                        "$E" '"ok":true,"no_ar":false,"ocupado":false,"build":"","formato":"","arquivo_ajustes":false,"ajustes":\[\]'
confere "fora: resumo vazio"                "$E" '"resumo":{"bloco_ms":null'
confere "fora: medidas vazias"              "$E" '"medidas":\[\]'
confere "medir fora = ampr_dep_fora"        "$(post -X POST $L/api/ampr/medir)" '"chave":"ampr_dep_fora"'
confere "aplicar fora = ampr_dep_fora"      "$(post -d nome=spin_us -d valor=50 $L/api/ampr/ajustes)" '"chave":"ampr_dep_fora"'

echo "--- no ar (resposta com linha HTTP)"
echo http > "$T/ampr.modo"
python3 -I "$T/ampr.py" $PORTA_AMPR "$T" > "$T/ampr.log" 2>&1 & PID_AMPR=$!
sleep 0.5
E=$(estado)
confere "no ar com build e formato"         "$E" '"no_ar":true,"ocupado":false,"build":"build ampr-emu-ng 0.6.0 4db1b08 debug","formato":"zstd"'
confere "ajuste da proxima abertura"        "$E" '{"nome":"decoded_mib","valor":136,"min":0,"max":512,"ao_vivo":false}'
confere "ajuste na hora"                    "$E" '{"nome":"spin_us","valor":100,"min":0,"max":200,"ao_vivo":true}'
confere "ajuste desconhecido aparece"       "$E" '"nome":"knob_futuro"'
confere "resumo: bloco 2 ms"                "$E" '"bloco_ms":2.000'
confere "resumo: leitura 1 ms"              "$E" '"leitura_ms":1.000'
confere "resumo: descompressao 30 us"       "$E" '"decode_us":30.000'
confere "resumo: disco 256 KiB"             "$E" '"disco_kib":256.000'
confere "resumo: peso 0.75%"                "$E" '"peso_decode_pct":0.750'
confere "resumo: cache 90%"                 "$E" '"cache_pct":90.000'
confere "resumo: espera pela ordem 0.5"     "$E" '"ordem_ms":0.500'
confere "resumo: 1a leitura 1 ms"           "$E" '"primeira_ms":1.000'
confere "resumo: erros 0 = null"            "$E" '"decode_errors":null'
confere "resumo: erros de pacote 2"         "$E" '"pack_job_errors":2.000'
confere "contadores crus"                   "$E" '"contadores":{.*"job_totals":'
echo cru > "$T/ampr.modo"
confere "sem linha HTTP tambem"             "$(estado)" '"no_ar":true,.*"build":"build ampr-emu-ng 0.6.0 4db1b08 debug"'

echo "--- recusas e pareamento"
confere "sem X-GLR = 403"                   "$(codigo -d nome=spin_us -d valor=50 $L/api/ampr/ajustes)" "403"
for r in ajustes padrao medir bench medida/apagar trecho/inicio trecho/fim marca sugestao/buscar sugestao/aplicar conjunto/salvar conjunto/aplicar conjunto/apagar medida/enviar disco; do
  confere "rede sem token: $r = 401"        "$(codigo -H 'X-GLR: 1' -X POST $R/api/ampr/$r)" "401"
done
confere "GET livre pela rede"               "$(codigo $R/api/ampr/ajustes)" "200"
confere "nome invalido"                     "$(post -d 'nome=Spin' -d valor=5 $L/api/ampr/ajustes)" '"chave":"ampr_aj_nome"'
confere "nome com ponto"                    "$(post --data-urlencode 'nome=../x' -d valor=5 $L/api/ampr/ajustes)" '"chave":"ampr_aj_nome"'
confere "nome que nao existe"               "$(post -d nome=nao_tem -d valor=5 $L/api/ampr/ajustes)" '"chave":"ampr_aj_nome".*nao tem o ajuste nao_tem'
confere "valor com letra"                   "$(post -d nome=spin_us -d valor=5a $L/api/ampr/ajustes)" '"chave":"ampr_aj_valor"'
confere "valor negativo"                    "$(post -d nome=spin_us -d valor=-1 $L/api/ampr/ajustes)" '"chave":"ampr_aj_valor"'
confere "acima do maximo"                   "$(post -d nome=spin_us -d valor=201 $L/api/ampr/ajustes)" '"chave":"ampr_aj_valor".*0 a 200'
confere "sem valor"                         "$(post -d nome=spin_us $L/api/ampr/ajustes)" '"chave":"ampr_aj_valor"'
confere "vazio"                             "$(post -X POST $L/api/ampr/ajustes)" '"chave":"ampr_aj_vazio"'
nao_tem "nada chegou ao /set?"              "$(cat $T/ampr.pedidos)" "GET /set?"

echo "--- aplicar"
A=$(post -d nome=spin_us -d valor=50 -d nome=decoded_mib -d valor=200 $L/api/ampr/ajustes)
confere "aplicou dois"                      "$A" '"nome":"decoded_mib","valor":200.*"nome":"spin_us","valor":50.*"erro_ampr":"","aplicados":2'
confere "pedido ao ampr em ordem"           "$(cat $T/ampr.pedidos)" "GET /set?spin_us=50&decoded_mib=200 HTTP/1.0"
confere "diario"                            "$(cat $DADOS/glibren.log)" "ampr-ajuste: /set?spin_us=50&decoded_mib=200"
echo erro_set > "$T/ampr.modo"
confere "erro do ampr volta"                "$(post -d nome=spin_us -d valor=60 $L/api/ampr/ajustes)" '"erro_ampr":"error: could not write /data/ampr_emu_tune.txt"'
echo http > "$T/ampr.modo"

echo "--- voltar ao padrao"
printf 'spin_us=50\n' > "$M/ampr_emu_tune.txt"
confere "arquivo de ajustes visto"          "$(estado)" '"arquivo_ajustes":true'
P=$(post -X POST $L/api/ampr/padrao)
confere "padrao: apagado"                   "$P" '"apagado":true,"mensagem":"vale na proxima abertura'
confere "padrao: arquivo sumiu"             "$(ls $M)" "^$"
confere "padrao de novo: nada"              "$(post -X POST $L/api/ampr/padrao)" '"apagado":false'

echo "--- medidas"
MD=$(post --data-urlencode "nota=Teste com acento é ó $(printf '\001')controle" -X POST $L/api/ampr/medir)
confere "medida guardada"                   "$MD" '"medida":"20[0-9-]*_[0-9]*.txt"'
NM=$(echo "$MD" | grep -o '"medida":"20[^"]*"' | head -1 | cut -d'"' -f4)
F="$DADOS/ampr-medidas/$NM"
confere "arquivo da medida"                 "$(ls $DADOS/ampr-medidas)" "$NM"
confere "cabecalho: nota limpa"             "$(cat $F)" "^nota: Teste com acento é ó  controle$"
confere "cabecalho: versao"                 "$(cat $F)" "glibren 0.9.64-teste"
confere "cabecalho: build"                  "$(cat $F)" "^build: build ampr-emu-ng 0.6.0 4db1b08 debug$"
confere "cabecalho: payloads rodando"       "$(cat $F)" "^payloads rodando: "
confere "cabecalho: temperatura e clock"    "$(cat $F)" "^temperatura e clock agora: "
confere "resumo no topo"                    "$(cat $F)" "^tempo medio por bloco de comandos: 2.000 ms$"
confere "resumo: cache"                     "$(cat $F)" "^acerto do cache: 90.000 %$"
confere "resumo: erros de pacote"           "$(cat $F)" "^erros de pedido ao pacote: 2.000$"
nao_tem "resumo: sem erro de descompressao" "$(cat $F)" "erros de descompressao"
confere "secoes"                            "$(grep '^===' $F | tr '\n' '|')" "=== Resumo.*|=== /metrics|=== /threads|=== /set|=== /fsfail|"
confere "lista com a nota"                  "$(estado)" "\"medidas\":\[{\"nome\":\"$NM\",\"tamanho\":[0-9]*,\"nota\":\"Teste com acento"
NOTA_LONGA=$(python3 -c 'print("ç" * 100)')
post --data-urlencode "nota=$NOTA_LONGA" -X POST $L/api/ampr/medir > /dev/null
N2=$(ls -t $DADOS/ampr-medidas | head -1)
confere "nota longa cortada sem quebrar UTF-8" "$(grep '^nota: ' $DADOS/ampr-medidas/$N2 | python3 -c 'import sys; l=sys.stdin.buffer.read().strip(); l.decode(); print(len(l))')" "^126$"
B=$(post -d nota=disco -X POST $L/api/ampr/bench)
confere "bench: texto"                      "$B" '"texto":"bench volume 0: 812.5 MB/s'
NB=$(echo "$B" | grep -o '"medida":"20[^"]*"' | head -1 | cut -d'"' -f4)
confere "bench: nota"                       "$(cat $DADOS/ampr-medidas/$NB)" "^nota: bench: disco$"
mkdir -p "$DADOS/ampr-medidas"
for i in $(seq 10 50); do printf 'nota: velha %s\n' $i > "$DADOS/ampr-medidas/2020-01-01_0000${i}.txt"; done
post -X POST $L/api/ampr/medir > /dev/null
confere "rodizio: ficam 40"                 "$(ls $DADOS/ampr-medidas | wc -l)" "^40$"
nao_tem "rodizio: as mais velhas sairam"    "$(ls $DADOS/ampr-medidas)" "2020-01-01_000010.txt"
confere "rodizio: a nova ficou"             "$(ls $DADOS/ampr-medidas)" "$NM"
confere "apagar: traversal recusado"        "$(post --data-urlencode 'nome=../config.ini' $L/api/ampr/medida/apagar)" '"chave":"ampr_medida_nome"'
confere "apagar: barra recusada"            "$(post --data-urlencode 'nome=2026-01-01_000000.txt/x' $L/api/ampr/medida/apagar)" '"chave":"ampr_medida_nome"'
confere "config intacto"                    "$(cat $DADOS/config.ini)" "language"
confere "apagar inexistente = 404"          "$(codigo -H 'X-GLR: 1' -d nome=2026-01-01_000000.txt $L/api/ampr/medida/apagar)" "404"
confere "apagar"                            "$(post -d nome=$NB $L/api/ampr/medida/apagar)" '"ok":true'
nao_tem "apagada da lista"                  "$(ls $DADOS/ampr-medidas)" "$NB"

echo "--- trecho"
confere "fim sem inicio"                    "$(post -X POST $L/api/ampr/trecho/fim)" '"chave":"ampr_trecho_fechado"'
echo PPSA01234 > "$T/abertos"
confere "cronometro: abri"                  "$(post -d tipo=abri $L/api/ampr/marca)" '"marcas":\[{"tipo":"abri","nome":"abri o jogo","texto":"","s":0.0'
confere "marca invalida"                    "$(post -d tipo=xx $L/api/ampr/marca)" '"chave":"ampr_marca_tipo"'
TI=$(post -d fps=1 $L/api/ampr/trecho/inicio)
confere "trecho aberto"                     "$TI" '"trecho":{"aberto":true,"segundos":0,"fps":true'
confere "arquivo do inicio"                 "$(head -1 $DADOS/ampr-trecho-inicio.txt)" "^inicio: [0-9]*$"
confere "dois inicios = 409"                "$(post -d fps=1 $L/api/ampr/trecho/inicio)" '"chave":"ampr_trecho_aberto"'
sleep 1.5
confere "amostras andando"                  "$(estado)" '"amostras":[1-9]'
post -d tipo=menu -d texto=tela%20inicial $L/api/ampr/marca > /dev/null
TF=$(post -d nota=trecho1 $L/api/ampr/trecho/fim)
confere "trecho fechado"                    "$TF" '"trecho":{"aberto":false'
NT=$(echo "$TF" | grep -o '"medida":"20[^"]*"' | head -1 | cut -d'"' -f4)
FT="$DADOS/ampr-medidas/$NT"
confere "trecho: duracao"                   "$(cat $FT)" "^trecho: [0-9]* s (de "
confere "trecho: resumo da diferenca"       "$(cat $FT)" "=== Resumo (diferenca fim - inicio do trecho"
confere "trecho: media certa na diferenca"  "$(cat $FT)" "^tempo medio por bloco de comandos: 2.000 ms$"
confere "trecho: sem os _max"               "$(cat $FT)" "^pior bloco (desde a ultima leitura): -$"
confere "trecho: contadores da diferenca"   "$(grep '^contadores:' $FT)" "job_totals=[1-9]"
nao_tem "trecho: diferenca sem _max"        "$(grep '^contadores:' $FT)" "_max="
confere "trecho: amostras"                  "$(cat $FT)" "^amostras: [1-9]"
confere "trecho: FPS medido"                "$(cat $FT)" "^FPS (leitura do glibren, por segundo): media"
confere "trecho: metrics do inicio e do fim" "$(grep '^===' $FT | tr '\n' '|')" "=== Durante o trecho|=== /metrics (inicio)|=== /metrics (fim)|"
confere "trecho: cronometro na medida"      "$(cat $FT)" "s  menu apareceu: tela inicial"
confere "trecho: marca automatica do jogo"  "$(cat $FT)" "s  abri o jogo"
confere "cronometro zerou depois"           "$(estado)" '"marcas":\[\]'
confere "arquivo do inicio apagado"         "$(ls $DADOS/ampr-trecho-inicio.txt 2>&1)" "No such file"
post -d fps=0 $L/api/ampr/trecho/inicio > /dev/null
para; inicia
confere "trecho segue depois de reabrir"    "$(estado)" '"trecho":{"aberto":true'
confere "cancelar"                          "$(post -X POST $L/api/ampr/trecho/cancelar)" '"trecho":{"aberto":false'
rm -f "$T/abertos"

echo "--- cronometro: marcas automaticas"
post -X POST $L/api/ampr/trecho/cancelar > /dev/null
kill $PID_AMPR 2>/dev/null; wait $PID_AMPR 2>/dev/null
estado > /dev/null
post -d tipo=abri $L/api/ampr/marca > /dev/null
echo PPSA01234 > "$T/abertos"
python3 -I "$T/ampr.py" $PORTA_AMPR "$T" > "$T/ampr.log" 2>&1 & PID_AMPR=$!
sleep 0.5
E=$(estado)
confere "auto: jogo abriu"                  "$E" '"tipo":"jogo_abriu","nome":"jogo aberto (visto pelo glibren'
confere "auto: 9090 respondeu"              "$E" '"tipo":"ampr_respondeu"'
confere "zerar"                             "$(post -d tipo=zerar $L/api/ampr/marca)" '"marcas":\[\]'
rm -f "$T/abertos"

echo "--- sugestao do Claude"
confere "sem chave"                         "$(post -X POST $L/api/ampr/sugestao/buscar)" '"chave":"ampr_sug_sem_chave"'
printf '%s\n' "$KJOBE" > "$T/jobe/token"
sleep 0
para; inicia
confere "nenhuma publicada = 404"           "$(post -X POST $L/api/ampr/sugestao/buscar)" '"chave":"ampr_sug_nenhuma"'
confere "GET com a chave"                   "$(cat $GH/gets)" "contents/glibren/ampr-sugestoes.json Bearer $KJOBE"
confere "buscar de novo logo = 429"         "$(codigo -H 'X-GLR: 1' -X POST $L/api/ampr/sugestao/buscar)" "429"
cp "$ORIGEM/testes/ampr-sugestoes-exemplo.json" "$GH/sugestao.json"
para; inicia
S=$(post -X POST $L/api/ampr/sugestao/buscar)
confere "sugestao buscada"                  "$S" '"sugestao":{"rodada":3,"criado":"2026-11-23 18:00","titulo":"Mais threads de descompressão"'
confere "sugestao: ajustes"                 "$S" '"ajustes":{"workers":6,"decoded_mib":200}'
confere "sugestao: campo estranho fora"     "$(cat $DADOS/ampr-sugestao.json)" '"medir":"Abra o mesmo save'
nao_tem "sugestao: campo extra descartado"  "$(cat $DADOS/ampr-sugestao.json)" "extra_ignorado"
A=$(post -X POST $L/api/ampr/sugestao/aplicar)
confere "sugestao aplicada"                 "$A" '"nome":"decoded_mib","valor":200.*"nome":"workers","valor":6.*"rodada":3'
confere "sugestao: /set do ampr"            "$(tail -3 $T/ampr.pedidos)" "GET /set?workers=6&decoded_mib=200"
post -X POST $L/api/ampr/medir > /dev/null
N3=$(ls -t $DADOS/ampr-medidas | head -1)
confere "rodada na medida seguinte"         "$(cat $DADOS/ampr-medidas/$N3)" "^rodada da sugestao do Claude: 3$"
printf '{"rodada":4,"ajustes":{"workers":99}}' > "$GH/sugestao.json"
para; inicia
post -X POST $L/api/ampr/sugestao/buscar > /dev/null
confere "sugestao fora do limite recusada"  "$(post -X POST $L/api/ampr/sugestao/aplicar)" '"chave":"ampr_aj_valor"'
confere "rodada nao mudou"                  "$(estado)" '"rodada":3'
printf '{"rodada":5,"ajustes":{"Workers;x":1}}' > "$GH/sugestao.json"
para; inicia
confere "sugestao quebrada = formato"       "$(post -X POST $L/api/ampr/sugestao/buscar)" '"chave":"ampr_sug_formato"'

echo "--- conjuntos"
E=$(estado)
confere "conjunto fixo"                     "$E" '"conjuntos":\[{"nome":"Padrão 4db1b08","fixo":true,"ajustes":{"decoded_mib":136,"pipelines":12'
confere "salvar"                            "$(post --data-urlencode 'nome=Meu teste' $L/api/ampr/conjunto/salvar)" '{"nome":"Meu teste","fixo":false,"ajustes":{"decoded_mib":200'
confere "nome com virgula recusado"         "$(post --data-urlencode 'nome=a,b' $L/api/ampr/conjunto/salvar)" '"chave":"ampr_conj_nome"'
confere "nome do fixo recusado"             "$(post --data-urlencode 'nome=Padrão 4db1b08' $L/api/ampr/conjunto/salvar)" '"chave":"ampr_conj_fixo"'
post -d nome=spin_us -d valor=10 $L/api/ampr/ajustes > /dev/null
A=$(post --data-urlencode 'nome=Padrão 4db1b08' $L/api/ampr/conjunto/aplicar)
confere "aplicar o fixo"                    "$A" '"nome":"spin_us","valor":100.*"nome":"decoded_mib","valor":136\|"nome":"decoded_mib","valor":136.*"nome":"spin_us","valor":100'
confere "fixo: o que o ampr nao tem fica de fora" "$A" '"ignorados":"pipelines,'
A=$(post --data-urlencode 'nome=Meu teste' $L/api/ampr/conjunto/aplicar)
confere "aplicar o salvo"                   "$A" '"nome":"decoded_mib","valor":200'
confere "apagar o fixo recusado"            "$(post --data-urlencode 'nome=Padrão 4db1b08' $L/api/ampr/conjunto/apagar)" '"chave":"ampr_conj_fixo"'
confere "apagar"                            "$(post --data-urlencode 'nome=Meu teste' $L/api/ampr/conjunto/apagar)" '"ok":true'
nao_tem "apagado"                           "$(estado)" "Meu teste"
confere "apagar de novo = 404"              "$(codigo -H 'X-GLR: 1' --data-urlencode 'nome=Meu teste' $L/api/ampr/conjunto/apagar)" "404"

echo "--- enviar so uma medida"
printf 'nota: segredo\nchave %s no meio\n' "$KJOBE" > "$DADOS/ampr-medidas/2026-11-23_120000.txt"
EN=$(post -d nome=2026-11-23_120000.txt $L/api/ampr/medida/enviar)
confere "enviada"                           "$EN" '"destino":"glibren/ampr-medidas/2026-11-23_120000_envteste.txt"'
confere "chegou ao GitHub"                  "$(cat $GH/recebido/glibren/ampr-medidas/2026-11-23_120000_envteste.txt)" "chave \[segredo\] no meio"
nao_tem "sem a chave no GitHub"             "$(cat $GH/recebido/glibren/ampr-medidas/2026-11-23_120000_envteste.txt)" "github_pat"
confere "enviar: traversal recusado"        "$(post --data-urlencode 'nome=../config.ini' $L/api/ampr/medida/enviar)" '"chave":"ampr_medida_nome"'

echo "--- teste de disco sem jogo"
head -c $((3 * 1024 * 1024)) /dev/urandom > "$D/jogos/grande.bin"
printf 'x' > "$D/jogos/pequeno.bin"
confere "fora dos discos recusado"          "$(post -d caminho=$DADOS/config.ini $L/api/ampr/disco)" '"chave":"ampr_disco_caminho"'
confere "traversal recusado"                "$(post --data-urlencode "caminho=$D/jogos/../jogos/grande.bin" $L/api/ampr/disco)" '"chave":"ampr_disco_caminho"'
confere "pequeno recusado"                  "$(post -d caminho=$D/jogos/pequeno.bin $L/api/ampr/disco)" '"chave":"ampr_disco_pequeno"'
confere "comecou"                           "$(post -d caminho=$D/jogos/grande.bin -d nota=hd $L/api/ampr/disco)" '"disco":{"estado":"rodando"'
confere "um por vez"                        "$(post -d caminho=$D/jogos/grande.bin $L/api/ampr/disco)" '"chave":"ampr_disco_ocupado"'
for i in $(seq 1 40); do estado | grep -q '"disco":{"estado":"pronto"' && break; sleep 0.25; done
E=$(estado)
confere "pronto"                            "$E" '"disco":{"estado":"pronto","progresso":100'
confere "resultado sequencial"              "$E" 'sequencial (8 MiB): [0-9.]* MB/s'
confere "resultado aleatorio"               "$E" 'aleatorio (64 KiB): [0-9.]* MB/s'
ND=$(echo "$E" | grep -o '"medida":"20[^"]*"' | tail -1 | cut -d'"' -f4)
confere "virou medida"                      "$(cat $DADOS/ampr-medidas/$ND)" "^nota: disco: hd$"
confere "medida: modo de leitura"           "$(cat $DADOS/ampr-medidas/$ND)" "^modo: "
confere "arquivo intacto"                   "$(stat -c %s $D/jogos/grande.bin)" "^3145728$"

echo "--- diagnostico com as medidas (0.9.63)"
curl -s -o "$T/d.zip" $L/api/diagnostico/zip
ZL=$(python3 -I -c 'import sys,zipfile; z=zipfile.ZipFile(sys.argv[1]); assert z.testzip() is None; print("\n".join(z.namelist()))' "$T/d.zip" 2>&1)
confere "zip: ajustes do ampr"              "$ZL" "/ampr-ajustes.json$"
confere "zip: medidas"                      "$ZL" "/ampr-medida-20[0-9_-]*\.txt$"
confere "zip: 40 medidas"                   "$(echo "$ZL" | grep -c 'ampr-medida-')" "^40$"
ZA=$(python3 -I -c 'import sys,zipfile; z=zipfile.ZipFile(sys.argv[1]); n=[x for x in z.namelist() if x.endswith("ampr-ajustes.json")][0]; print(z.read(n).decode())' "$T/d.zip")
confere "zip: ajustes com resumo"           "$ZA" '"no_ar":true.*"resumo":{'
nao_tem "zip: sem a chave"                  "$(python3 -I -c 'import sys,zipfile; z=zipfile.ZipFile(sys.argv[1]); print("".join(z.read(n).decode("utf-8","replace") for n in z.namelist()))' "$T/d.zip")" "github_pat"

echo "--- pagina"
PG=$(curl -s $L/payloads)
confere "pagina: bloco Velocidade do ampr"  "$PG" 'Velocidade do ampr (depuração)'
confere "pagina: trecho"                    "$PG" 'Início do trecho'
confere "pagina: sugestao"                  "$PG" 'Buscar sugestão'
# 360 e 1280 px no Chromium/Edge do Windows, se houver (testes/teste_ampr_ajuste_pagina.mjs)
NODE_WIN="/mnt/c/Program Files/nodejs/node.exe"
LAD=$(cmd.exe /c 'echo %LOCALAPPDATA%' 2>/dev/null | tr -d '\r')
PW=""; [ -n "$LAD" ] && PW=$(ls -d "$(wslpath "$LAD")"/npm-cache/_npx/*/node_modules/playwright 2>/dev/null | head -1)
if [ -x "$NODE_WIN" ] && [ -n "$PW" ]; then
  SAIDA=$("$NODE_WIN" "$(wslpath -w "$ORIGEM/testes/teste_ampr_ajuste_pagina.mjs")" "http://127.0.0.1:$PORTA" "$(wslpath -w "$PW")" ${GLR_FOTOS:-} 2>&1)
  echo "$SAIDA"
  ok=$((ok + $(echo "$SAIDA" | grep -c '^OK '))); falhas=$((falhas + $(echo "$SAIDA" | grep -c '^FALHA')))
  echo "$SAIDA" | grep -q '^=== pagina' || { falhas=$((falhas+1)); echo "FALHA pagina: o script nao terminou"; }
else
  echo "PULADO: teste da pagina (sem node.exe ou Playwright no Windows)"
fi

kill $PID_AMPR 2>/dev/null; wait $PID_AMPR 2>/dev/null
para
kill $PID_GH 2>/dev/null; wait $PID_GH 2>/dev/null
rm -rf "$T"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
