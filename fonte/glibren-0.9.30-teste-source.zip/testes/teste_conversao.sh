#!/bin/bash
# 0.9.30: converter formato pelo Dump Forge (ps5-dump-forge) na versao de PC, com um Dump Forge FALSO
# (testes/dumpforge_falso.py) no lugar da API real em 127.0.0.1:8095. Casos: Dump Forge ausente (503 dumpforge_fora),
# pareamento/X-GLR, formato/nivel invalidos, recusas (mesmo formato, destino existe ou em uso, origem invalida, nao existe,
# fora das pastas, nome invalido), pedido mandado ao Dump Forge (formato, saida ao lado, niveis Kraken/zstd/zlib/LZ4,
# zstd dentro de imagem, nunca delete_source), andamento ate "feito", erro do Dump Forge, recusa do Dump Forge, cancelar,
# limpar, opcao geral (config.ini), Dump Forge que fecha no meio ("perdido") e o item na pagina Payloads. No fim, se
# houver Node + Playwright no Windows, roda testes/teste_conversao_pagina.mjs (filtro por formato + dialogo).
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_conversao.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8911; PORTA_DF=8912
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R="http://$IP:$PORTA"
T=/root/glr-conversao; DADOS=$T/dados; A=$T/lista
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
codigo() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
estado() { curl -s "$L/api/conversao"; }
ultimo() { tail -1 "$T/df/pedidos.jsonl"; }
liga_df() { (exec python3 -I "$ORIGEM/testes/dumpforge_falso.py" $PORTA_DF "$T/df") >> "$T/df.log" 2>&1 & PID_DF=$!; sleep 0.5; }
para_df() { kill $PID_DF 2>/dev/null; wait $PID_DF 2>/dev/null; }

rm -rf "$T"; mkdir -p "$DADOS" "$A/PastaJogo-PPSA05555/sce_sys" "$T/df"
printf 'language = pt-BR\nfolder = %s/\n' "$A" > "$DADOS/config.ini"
echo dados > "$A/Jogo-PPSA01234-US-PS5.exfat"
echo dados > "$A/Outro-CUSA00001.ffpkg"
echo dados > "$A/Ja-PPSA09999.exfat"; echo dados > "$A/Ja-PPSA09999.ffpkg"
echo dados > "$A/leia.txt"
echo '{}' > "$A/PastaJogo-PPSA05555/sce_sys/param.json"
echo ok > "$T/df/modo"
GLR_TESTE_DUMPFORGE_PORTA=$PORTA_DF "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!
sleep 1

echo "--- Dump Forge ausente"
E=$(estado)
confere "estado: fora do ar"               "$E" '"no_ar":false'
confere "estado: padrao ffpkg"             "$E" '"padrao":"ffpkg","nivel":""'
confere "estado: formatos com zstd"        "$E" '"exfat_zstd","ffpkg_zstd","ffpfs_zstd","ffpfsc_zstd"'
confere "estado: familias"                 "$E" '"pkg":"k"'
R1=$(post -d formato=ffpkg -d "pasta=$A/" -d de=Jogo-PPSA01234-US-PS5.exfat $L/api/conversao)
confere "converter sem Dump Forge: chave"  "$R1" '"chave":"dumpforge_fora"'
confere "converter sem Dump Forge: 503"    "$(codigo -H 'X-GLR: 1' -d formato=ffpkg -d "pasta=$A/" -d de=x.exfat $L/api/conversao)" "503"

liga_df
echo "--- pareamento e X-GLR"
confere "rede sem pareamento: 401"         "$(codigo -H 'X-GLR: 1' -d formato=ffpkg $R/api/conversao)" "401"
confere "cancelar sem pareamento: 401"     "$(codigo -H 'X-GLR: 1' -d id=1 $R/api/conversao/cancelar)" "401"
confere "padrao sem pareamento: 401"       "$(codigo -H 'X-GLR: 1' -d formato=pkg $R/api/conversao/padrao)" "401"
confere "sem X-GLR: 403"                   "$(codigo -d formato=ffpkg $L/api/conversao)" "403"
confere "estado e leitura livre"           "$(curl -s $R/api/conversao)" '"no_ar":true'

echo "--- formato e nivel"
confere "formato desconhecido: 400"        "$(codigo -H 'X-GLR: 1' -d formato=iso -d "pasta=$A/" -d de=x.exfat $L/api/conversao)" "400"
confere "nivel errado p/ pkg: 400"         "$(codigo -H 'X-GLR: 1' -d formato=pkg -d nivel=5 -d "pasta=$A/" -d de=x.exfat $L/api/conversao)" "400"
confere "zstd nivel 23: 400"               "$(codigo -H 'X-GLR: 1' -d formato=pasta_zstd -d nivel=23 $L/api/conversao)" "400"
confere "lz4 nivel 2: 400"                 "$(codigo -H 'X-GLR: 1' -d formato=pasta_lz4 -d nivel=2 $L/api/conversao)" "400"
confere "exfat sem nivel: nivel 1 400"     "$(codigo -H 'X-GLR: 1' -d formato=exfat -d nivel=1 $L/api/conversao)" "400"

echo "--- recusas e um pedido bom"
R1=$(post -d formato=ffpkg -d nivel= \
  -d "pasta=$A/" -d de=Jogo-PPSA01234-US-PS5.exfat -d "pasta=$A/" -d de=Ja-PPSA09999.exfat -d "pasta=$A/" -d de=Outro-CUSA00001.ffpkg \
  -d "pasta=$A/" -d de=leia.txt -d "pasta=$A/" -d de=nao-existe.exfat -d "pasta=/etc/" -d de=passwd -d "pasta=$A/" -d de=../x.exfat \
  $L/api/conversao)
confere "1 criada"                         "$R1" '"criadas":1'
confere "destino existe"                   "$R1" '"nome":"Ja-PPSA09999.exfat","motivo":"destino_existe"'
confere "mesmo formato"                    "$R1" '"nome":"Outro-CUSA00001.ffpkg","motivo":"mesmo_formato"'
confere "origem invalida"                  "$R1" '"nome":"leia.txt","motivo":"origem_invalida"'
confere "nao existe"                       "$R1" '"nome":"nao-existe.exfat","motivo":"nao_existe"'
confere "fora das pastas"                  "$R1" '"nome":"passwd","motivo":"fora_das_pastas"'
confere "nome invalido"                    "$R1" '"nome":"../x.exfat","motivo":"invalido"'
P=$(ultimo)
confere "pedido: origem"                   "$P" "\"source\": \"$A/Jogo-PPSA01234-US-PS5.exfat\""
confere "pedido: saida ao lado"            "$P" "\"output\": \"$A/Jogo-PPSA01234-US-PS5.ffpkg\""
confere "pedido: formato"                  "$P" '"format": "ffpkg"'
confere "pedido: nunca apaga a origem"     "$P" '"delete_source": false'
nao_tem "pedido: sem nivel (padrao)"       "$P" 'level'
E=$(estado)
confere "andamento: rodando 0"             "$E" '"estado":"rodando","etapa":"write","feitos":0,"total":1000'
confere "andamento: origem/destino"        "$E" "\"destino\":\"$A/Jogo-PPSA01234-US-PS5.ffpkg\",\"formato\":\"ffpkg\""
R2=$(post -d formato=ffpkg -d "pasta=$A/" -d de=Jogo-PPSA01234-US-PS5.exfat $L/api/conversao)
confere "mesmo destino em uso: recusado"   "$R2" '"criadas":0.*"motivo":"destino_existe"'
confere "andamento: 50%"                   "$(estado)" '"etapa":"verify","feitos":500,"total":1000'
E=$(estado)
confere "feito"                            "$E" '"estado":"feito"'
confere "feito: tamanho"                   "$E" '"bytes":123456789'
confere "origem continua la"               "$(ls $A)" 'Jogo-PPSA01234-US-PS5.exfat'
confere "diario: pedida e feita"           "$(cat $DADOS/glibren.log)" 'conversao: 1 feita'

echo "--- niveis e formatos com compressao"
post -d formato=pkg -d nivel=balanced -d "pasta=$A/" -d de=Jogo-PPSA01234-US-PS5.exfat $L/api/conversao > /dev/null
P=$(ultimo)
confere "pkg: kraken balanced"             "$P" '"format": "pkg", "kraken_level": "balanced"'
confere "pkg: saida .pkg"                  "$P" "Jogo-PPSA01234-US-PS5.pkg\""
post -d formato=exfat_zstd -d nivel=19 -d "pasta=$A/" -d de=Outro-CUSA00001.ffpkg $L/api/conversao > /dev/null
P=$(ultimo)
confere "exfat+zstd: imagem com packs"     "$P" '"format": "exfat", "zstd_pack": true, "zstd_level": 19'
confere "exfat+zstd: nome -zstd.exfat"     "$P" "Outro-CUSA00001-zstd.exfat\""
post -d formato=ffpfsc -d nivel=9 -d "pasta=$A/" -d de=Outro-CUSA00001.ffpkg $L/api/conversao > /dev/null
confere "ffpfsc: zlib 9"                   "$(ultimo)" '"format": "ffpfsc", "ffpfsc_level": 9'
post -d formato=pasta_lz4 -d nivel=12 -d "pasta=$A/" -d de=PastaJogo-PPSA05555 $L/api/conversao > /dev/null
P=$(ultimo)
confere "pasta lz4: pack + nivel"          "$P" '"format": "folder", "lz4": "pack", "lz4_level": 12'
confere "pasta lz4: nome -lz4"             "$P" "PastaJogo-PPSA05555-lz4\""
confere "pasta -> pasta: mesmo formato"    "$(post -d formato=pasta -d "pasta=$A/" -d de=PastaJogo-PPSA05555 $L/api/conversao)" '"motivo":"mesmo_formato"'
post -d formato=pasta_zstd -d "pasta=$A/" -d de=PastaJogo-PPSA05555 $L/api/conversao > /dev/null
confere "pasta zstd: padrao do DF"         "$(ultimo)" '"format": "folder", "zstd_pack": true, "delete_source": false}'
estado > /dev/null; estado > /dev/null; E=$(estado)
nao_tem "todas terminaram"                 "$E" '"estado":"rodando"'

echo "--- erro e recusa do Dump Forge"
echo erro > "$T/df/modo"
post -d formato=exfat -d "pasta=$A/" -d de=Outro-CUSA00001.ffpkg $L/api/conversao > /dev/null
estado > /dev/null; estado > /dev/null; E=$(estado)
confere "erro do Dump Forge"               "$E" '"estado":"erro".*"erro":"preflight: no param.json in the source"'
echo recusa > "$T/df/modo"
R1=$(post -d formato=ffpfs -d "pasta=$A/" -d de=Outro-CUSA00001.ffpkg $L/api/conversao)
confere "recusa do Dump Forge"             "$R1" '"criadas":0.*"motivo":"dumpforge","texto":".*not a folder or a regular file"'

echo "--- cancelar"
echo lento > "$T/df/modo"
post -d formato=ffpfs -d "pasta=$A/" -d de=Outro-CUSA00001.ffpkg $L/api/conversao > /dev/null
ID=$(ultimo > /dev/null; estado | grep -o '"id":[0-9]*' | head -1 | cut -d: -f2)
confere "cancelar: rodando antes"          "$(estado)" "\"id\":$ID,.*\"estado\":\"rodando\""
confere "cancelar"                         "$(post -d id=$ID $L/api/conversao/cancelar)" '"ok":true'
confere "cancelar: Dump Forge recebeu"     "$(cat $T/df/cancelados)" "^$ID$"
confere "cancelado"                        "$(estado)" "\"id\":$ID,.*\"estado\":\"cancelado\""
confere "cancelar id desconhecido: 404"    "$(codigo -H 'X-GLR: 1' -d id=999 $L/api/conversao/cancelar)" "404"

echo "--- limpar"
R1=$(post -d x=1 $L/api/conversao/limpar)
confere "limpar"                           "$R1" '"ok":true,"tirados":'
confere "lista vazia"                      "$(estado)" '"itens":\[\]'

echo "--- opcao geral (formato padrao)"
confere "padrao: gravou"                   "$(post -d formato=exfat_zstd -d nivel=19 $L/api/conversao/padrao)" '"padrao":"exfat_zstd","nivel":"19"'
confere "config.ini: formato"              "$(cat $DADOS/config.ini)" 'convert_format = exfat_zstd'
confere "config.ini: nivel"                "$(cat $DADOS/config.ini)" 'convert_level = 19'
confere "estado da pagina"                 "$(curl -s $L/api/estado)" '"conv_formato":"exfat_zstd","conv_nivel":"19"'
confere "padrao invalido: 400"             "$(codigo -H 'X-GLR: 1' -d formato=pkg -d nivel=19 $L/api/conversao/padrao)" "400"
confere "padrao sem nivel = DF decide"     "$(post -d formato=pkg $L/api/conversao/padrao)" '"padrao":"pkg","nivel":""'
nao_tem "config.ini sem convert_level"     "$(cat $DADOS/config.ini)" 'convert_level'
echo ok > "$T/df/modo"
post -d "pasta=$A/" -d de=Outro-CUSA00001.ffpkg $L/api/conversao > /dev/null
confere "sem formato: usa o padrao"        "$(ultimo)" '"format": "pkg"'

echo "--- Dump Forge fecha no meio"
echo lento > "$T/df/modo"
post -d formato=ffpfs -d "pasta=$A/" -d de=Ja-PPSA09999.exfat $L/api/conversao > /dev/null
para_df
E=$(estado)
confere "perdido"                          "$E" '"estado":"perdido"'
confere "fora do ar"                       "$E" '"no_ar":false'

echo "--- pagina Payloads: item do Dump Forge"
E=$(curl -s $L/api/payloads)
confere "item dump-forge"                  "$E" '"id":"dump-forge","nome":"PS5 Dump Forge"'
confere "fora do ar: nao baixado"          "$E" '"id":"dump-forge".*"estado":"nao_baixado"'
liga_df
confere "no ar: rodando"                   "$(curl -s $L/api/payloads)" '"id":"dump-forge".*"estado":"rodando"'
confere "pagina principal: botao"          "$(curl -s $L/)" 'btnConverter'

kill $PID 2>/dev/null; wait $PID 2>/dev/null

# Pagina (filtro por formato + dialogo de 3 escolhas) no Chromium/Edge do Windows, se houver
NODE_WIN="/mnt/c/Program Files/nodejs/node.exe"
# pasta de dados local do Windows (pelo cmd.exe, sem escrever o caminho do perfil aqui)
LAD=$(cmd.exe /c 'echo %LOCALAPPDATA%' 2>/dev/null | tr -d '')
PW=""; [ -n "$LAD" ] && PW=$(ls -d "$(wslpath "$LAD")"/npm-cache/_npx/*/node_modules/playwright 2>/dev/null | head -1)
if [ -x "$NODE_WIN" ] && [ -n "$PW" ]; then
  echo ok > "$T/df/modo"
  GLR_TESTE_DUMPFORGE_PORTA=$PORTA_DF "$BIN" -p $PORTA -d "$DADOS" > "$T/glr2.log" 2>&1 & PID=$!
  sleep 1
  SAIDA=$("$NODE_WIN" "$(wslpath -w "$ORIGEM/testes/teste_conversao_pagina.mjs")" "http://127.0.0.1:$PORTA" "$(wslpath -w "$PW")" 2>&1)
  echo "$SAIDA"
  ok=$((ok + $(echo "$SAIDA" | grep -c '^OK '))); falhas=$((falhas + $(echo "$SAIDA" | grep -c '^FALHA')))
  echo "$SAIDA" | grep -q '^=== pagina' || { falhas=$((falhas+1)); echo "FALHA pagina: o script nao terminou"; }
  kill $PID 2>/dev/null; wait $PID 2>/dev/null
else
  echo "PULADO: teste da pagina (sem node.exe ou Playwright no Windows)"
fi
para_df
echo "=== $ok ok, $falhas falhas"
[ $falhas -eq 0 ]
