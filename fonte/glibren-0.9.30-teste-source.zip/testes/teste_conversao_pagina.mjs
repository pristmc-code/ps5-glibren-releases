// 0.9.30: pagina principal - filtro por formato (caixas por tipo), selecao, botao Converter e a pergunta de 3 escolhas
// (padrao / outro formato / cancelar), janela Conversoes (opcao geral + nivel avancado). Roda no Node do Windows com o
// Playwright do cache do npx (Edge ou Chrome instalados), chamado pelo testes/teste_conversao.sh com o glibren-pc e o
// Dump Forge falso no ar.
//   node teste_conversao_pagina.mjs http://127.0.0.1:8911 <pasta do pacote playwright>
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const [base, pw] = process.argv.slice(2);
const { chromium } = await import(pathToFileURL(path.join(pw, 'index.mjs')).href);
let ok = 0, falhas = 0;
const confere = (nome, cond, info = '') => { if (cond) { ok++; console.log('OK   ' + nome); } else { falhas++; console.log('FALHA ' + nome + (info ? ': ' + info : '')); } };

let navegador;
for (const channel of ['msedge', 'chrome']) { try { navegador = await chromium.launch({ channel }); break; } catch { /* outro */ } }
if (!navegador) { console.log('FALHA nenhum navegador abriu'); console.log('=== pagina 0 ok, 1 falhas'); process.exit(1); }

for (const tela of [{ w: 360, h: 780, nome: 'celular' }, { w: 1280, h: 800, nome: 'PC' }]) {
  const pagina = await navegador.newPage({ viewport: { width: tela.w, height: tela.h } });
  const n = s => `${s} (${tela.nome})`;
  await pagina.goto(base + '/');
  await pagina.click('#btnConectar');
  await pagina.waitForSelector('#corpoFtp .sel-item', { timeout: 20000 });
  await pagina.click('#filtrosFtp [data-filtro="todos"]');
  // caixas por formato: exfat, ffpkg, ffpfs, ffpfsc, pkg
  const chips = await pagina.$$eval('#chipsFtp [data-grupo="fmt"]', bs => bs.map(b => b.dataset.valor));
  confere(n('filtro: um botao por formato'), ['exfat', 'ffpkg', 'ffpfs', 'ffpfsc', 'pkg'].every(f => chips.includes(f)), chips.join(','));
  await pagina.click('#chipsFtp [data-valor="ffpkg"]');
  const nomes = await pagina.$$eval('#corpoFtp .arq:not(.novo)', ds => ds.map(d => d.textContent));
  confere(n('filtro ffpkg: so .ffpkg'), nomes.length >= 1 && nomes.every(x => x.endsWith('.ffpkg')), nomes.join(','));
  await pagina.$eval('#selTodos', c => c.click());
  const txt = await pagina.textContent('#btnConverter');
  confere(n('Converter (n) ligado'), txt.includes(`(${nomes.length})`) && !(await pagina.isDisabled('#btnConverter')), txt);
  await pagina.click('#btnConverter');
  await pagina.waitForSelector('#conversao.aberto');
  const padrao = await pagina.textContent('#cvPadrao');
  confere(n('pergunta: nome do formato padrao no botao'), /Converter para \.pkg \(FPKG\)/.test(padrao), padrao);
  const caixas = await pagina.$$eval('.cv-botoes button', bs => bs.filter(b => b.offsetParent).map(b => { const r = b.getBoundingClientRect(); return [Math.round(r.width), Math.round(r.top)]; }));
  confere(n('3 botoes lado a lado, mesma largura'), caixas.length === 3 && new Set(caixas.map(c => c[0])).size === 1 && new Set(caixas.map(c => c[1])).size === 1, JSON.stringify(caixas));
  const semRolagem = () => pagina.evaluate(() => document.scrollingElement.scrollWidth <= innerWidth);
  confere(n('pergunta: sem rolar de lado'), await semRolagem());
  const reticencias = await pagina.$$eval('#conversao button, #janelaConv button', bs => bs.filter(b => getComputedStyle(b).textOverflow === 'ellipsis').length);
  confere(n('sem reticencias nos botoes'), reticencias === 0, String(reticencias));
  await pagina.click('#cvOutro');
  const outros = await pagina.$$eval('#cvOutros button[data-fmt]', bs => bs.map(b => b.dataset.fmt));
  confere(n('outro formato: lista com os 12'), outros.length === 12 && outros.includes('exfat_zstd') && outros.includes('pasta_lz4'), outros.join(','));
  if (tela.nome === 'PC') {   // na 2a volta o Outro ja virou .exfat: so cancela
    await pagina.click('#cvCancelar');
    confere(n('cancelar fecha'), !(await pagina.isVisible('#conversao')));
  } else {
    await pagina.click('#cvOutros button[data-fmt="exfat"]');
    await pagina.waitForSelector('#janelaConv.aberto', { timeout: 8000 });
    await pagina.waitForFunction(() => document.querySelector('#convLista').textContent.includes('Outro-CUSA00001.exfat'), null, { timeout: 8000 });
    confere(n('janela Conversoes com o andamento'), true);
    confere(n('Dump Forge no ar'), (await pagina.textContent('#convDf')).includes('no ar'));
  }
  if (!(await pagina.isVisible('#janelaConv'))) {
    // nada marcado: o mesmo botao vira "Conversoes" e abre a janela da opcao geral
    await pagina.$eval('#selTodos', c => c.click());
    const rot = await pagina.textContent('#btnConverter');
    confere(n('sem marcados: botao Conversoes'), rot.includes('Conversões') && !(await pagina.isDisabled('#btnConverter')), rot);
    await pagina.$eval('#btnConverter', b => b.click());
  }
  await pagina.waitForSelector('#janelaConv.aberto');
  const opcoes = await pagina.$$eval('#convPadrao option', os => os.length);
  confere(n('opcao geral: 12 formatos'), opcoes === 12, String(opcoes));
  await pagina.selectOption('#convPadrao', 'exfat');
  confere(n('formato sem nivel: avancado escondido'), !(await pagina.isVisible('#convAvancado')));
  await pagina.selectOption('#convPadrao', 'ffpkg_zstd');
  await pagina.click('#convAvancado summary');
  const niveis = await pagina.$$eval('#convNivel option', os => os.map(o => o.textContent));
  confere(n('nivel: Padrao (recomendado) primeiro'), niveis[0] === 'Padrão (recomendado)' && niveis.some(x => x.startsWith('zstd 19')), niveis.join('|'));
  confere(n('janela: sem rolar de lado'), await semRolagem());
  await pagina.selectOption('#convPadrao', 'pkg');
  await pagina.waitForTimeout(400);
  await pagina.close();
}
await navegador.close();
console.log(`=== pagina ${ok} ok, ${falhas} falhas`);
process.exit(falhas ? 1 : 0);
