/* Game Library Renamer (payload PS5) - 0.9.30: conversao de formato pelo ps5-dump-forge. Ver conversao.h.

Regras:
  - so arquivos/pastas DENTRO das pastas da lista (config_pasta_permitida), nome simples, origem que existe;
  - origem aceita (a mesma do Dump Forge v0.5.6): pasta de jogo, .exfat, .ffpkg, .ffpfs, .ffpfsc, .pkg, .zip, .7z, .rar
    (".complete" no fim = download terminado: sai antes de olhar a extensao);
  - mesmo formato da origem = recusado; destino que ja existe (ou que outra conversao nossa ainda vai criar) = recusado;
  - delete_source nunca vai no pedido: a origem fica sempre;
  - o glibren guarda so os trabalhos que ELE pediu (id do Dump Forge + saida esperada); o estado vem do GET /api/jobs do
    Dump Forge, conferido pela saida (id igual com outra saida = o Dump Forge reiniciou, o trabalho se perdeu);
  - o ShadowMount+ acha sozinho a imagem nova nas pastas que ele monitora (o glibren nao pede varredura: nao tem rota
    para isso no SMP).
JSON do Dump Forge lido por um leitor minimo daqui (so o que precisa: id, request.output, progress.stage/done/total,
done.result.Ok/Err). */
#include "conversao.h"

#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#include "config.h"
#include "plataforma.h"
#include "util.h"

#define PORTA_DF 8095
#define MAX_CONV 32
#define MAX_RESPOSTA (8u * 1024 * 1024)   /* /api/jobs traz ate 200 linhas de diario por trabalho */
#ifdef MSG_NOSIGNAL
#define SEM_SINAL MSG_NOSIGNAL
#else
#define SEM_SINAL 0
#endif

/* id glibren, sufixo da saida, formato do Dump Forge, o resto do pedido e a familia do nivel de compressao:
   'k' = kraken_level (.pkg), 'z' = zstd_level 1-22, 'c' = ffpfsc_level (zlib 0-9), 'l' = lz4_level (0 ou 3-12), 0 = sem.
   Nivel vazio = o padrao do Dump Forge (recomendado): o campo nem vai no pedido. 0.9.30: zstd tambem DENTRO das imagens
   (.exfat/.ffpkg/.ffpfs/.ffpfsc; .pkg nao), ids com "_zstd" (combinados com a Jobe). */
static const struct {
  const char *id, *sufixo, *formato, *extra;
  char familia;
} FORMATOS[] = {
  {"exfat", ".exfat", "exfat", "", 0},
  {"ffpkg", ".ffpkg", "ffpkg", "", 0},
  {"ffpfs", ".ffpfs", "ffpfs", "", 0},
  {"ffpfsc", ".ffpfsc", "ffpfsc", "", 'c'},
  {"pkg", ".pkg", "pkg", "", 'k'},
  {"pasta", "", "folder", "", 0},
  {"pasta_zstd", "-zstd", "folder", ",\"zstd_pack\":true", 'z'},
  {"pasta_lz4", "-lz4", "folder", ",\"lz4\":\"pack\"", 'l'},
  {"exfat_zstd", "-zstd.exfat", "exfat", ",\"zstd_pack\":true", 'z'},
  {"ffpkg_zstd", "-zstd.ffpkg", "ffpkg", ",\"zstd_pack\":true", 'z'},
  {"ffpfs_zstd", "-zstd.ffpfs", "ffpfs", ",\"zstd_pack\":true", 'z'},
  {"ffpfsc_zstd", "-zstd.ffpfsc", "ffpfsc", ",\"zstd_pack\":true", 'z'},
};
#define N_FORMATOS ((int)(sizeof FORMATOS / sizeof FORMATOS[0]))
static const char *const KRAKEN[] = {"fast", "balanced", "smallest", "stored"};

typedef struct {
  unsigned long long job;
  char origem[1100], destino[1100];
  char formato[16], nivel[12];
  long long inicio;
  char estado[12];      /* fila, rodando, cancelando, feito, erro, cancelado, perdido */
  char etapa[32];
  unsigned long long feitos, total, bytes;
  char erro[400];
} conv_t;

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static conv_t g_conv[MAX_CONV];
static int g_qtd;

static int achar_formato(const char *id) {
  for(int i = 0; i < N_FORMATOS; i++)
    if(!strcmp(FORMATOS[i].id, id)) return i;
  return -1;
}

int conversao_formato_valido(const char *id) { return achar_formato(id) >= 0; }

static int numero(const char *v, int min, int max) {
  if(!v[0] || strlen(v) > 2) return 0;
  for(const char *c = v; *c; c++)
    if(*c < '0' || *c > '9') return 0;
  int n = atoi(v);
  return n >= min && n <= max;
}

int conversao_nivel_valido(const char *formato, const char *nivel) {
  int f = achar_formato(formato);
  if(f < 0) return 0;
  if(!nivel[0]) return 1;   /* padrao do Dump Forge */
  switch(FORMATOS[f].familia) {
    case 'k':
      for(int i = 0; i < 4; i++)
        if(!strcmp(KRAKEN[i], nivel)) return 1;
      return 0;
    case 'z': return numero(nivel, 1, 22);
    case 'c': return numero(nivel, 0, 9);
    case 'l': return numero(nivel, 0, 12) && atoi(nivel) != 1 && atoi(nivel) != 2;
    default: return 0;
  }
}

/* o campo do nivel no pedido do Dump Forge ("" = nenhum) */
static void nivel_campo(int f, const char *nivel, buf_t *b) {
  if(!nivel[0]) return;
  switch(FORMATOS[f].familia) {
    case 'k': buf_fmt(b, ",\"kraken_level\":\"%s\"", nivel); break;
    case 'z': buf_fmt(b, ",\"zstd_level\":%d", atoi(nivel)); break;
    case 'c': buf_fmt(b, ",\"ffpfsc_level\":%d", atoi(nivel)); break;
    case 'l': buf_fmt(b, ",\"lz4_level\":%d", atoi(nivel)); break;
  }
}

static int final(const char *estado) {
  return !strcmp(estado, "feito") || !strcmp(estado, "erro") || !strcmp(estado, "cancelado") || !strcmp(estado, "perdido");
}

/* ------------------------------------------------------------------ cliente HTTP do Dump Forge */

static int porta_df(void) {
  const char *v = getenv("GLR_TESTE_DUMPFORGE_PORTA");
  int n = v ? atoi(v) : 0;
  return n > 0 && n < 65536 ? n : PORTA_DF;
}

/* Um pedido (o Dump Forge atende um por conexao e fecha). Devolve o status HTTP, ou -1 se nao conectou / nao respondeu.
   O corpo da resposta vai para resp (sem o cabecalho). */
static int df_pedir(const char *metodo, const char *rota, const char *corpo, buf_t *resp, int espera_s) {
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if(fd < 0) return -1;
  struct timeval t = {.tv_sec = espera_s};
  setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &t, sizeof t);
  setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &t, sizeof t);
#ifdef SO_NOSIGPIPE
  int sim = 1;
  setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &sim, sizeof sim);
#endif
  struct sockaddr_in end = {.sin_family = AF_INET, .sin_port = htons((uint16_t)porta_df())};
  end.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  if(connect(fd, (struct sockaddr *)&end, sizeof end)) {
    close(fd);
    return -1;
  }
  buf_t pedido = {0};
  size_t n = corpo ? strlen(corpo) : 0;
  buf_fmt(&pedido, "%s %s HTTP/1.1\r\nHost: 127.0.0.1:%d\r\nConnection: close\r\n", metodo, rota, porta_df());
  if(corpo) buf_fmt(&pedido, "Content-Type: application/json\r\nContent-Length: %zu\r\n", n);
  buf_str(&pedido, "\r\n");
  if(corpo) buf_add(&pedido, corpo, n);
  int ok = 1;
  for(size_t feitos = 0; ok && feitos < pedido.n;) {
    ssize_t r = send(fd, pedido.d + feitos, pedido.n - feitos, SEM_SINAL);
    if(r <= 0) ok = 0;
    else feitos += (size_t)r;
  }
  buf_free(&pedido);
  buf_t tudo = {0};
  char bloco[16384];
  while(ok) {
    ssize_t r = recv(fd, bloco, sizeof bloco, 0);
    if(r <= 0) break;
    if(tudo.n + (size_t)r > MAX_RESPOSTA) {
      ok = 0;
      break;
    }
    buf_add(&tudo, bloco, (size_t)r);
  }
  close(fd);
  int status = -1;
  if(ok && tudo.n > 12 && !strncmp(tudo.d, "HTTP/1.", 7)) {
    buf_add(&tudo, "", 1);   /* termina em \0 */
    status = atoi(tudo.d + 9);
    const char *c = strstr(tudo.d, "\r\n\r\n");
    if(c) buf_str(resp, c + 4);
    else status = -1;
  }
  buf_free(&tudo);
  return status > 0 ? status : -1;
}

int conversao_dumpforge_no_ar(void) {
  buf_t r = {0};
  int st = df_pedir("GET", "/api/session", NULL, &r, 2);
  buf_free(&r);
  return st == 200;
}

/* ------------------------------------------------------------------ leitor JSON minimo */

typedef struct {
  const char *p, *fim;
} js_t;

static void js_esp(js_t *j) {
  while(j->p < j->fim && (*j->p == ' ' || *j->p == '\n' || *j->p == '\r' || *j->p == '\t')) j->p++;
}

/* le uma string (j->p no '"'); saida pode ser NULL (so pula). 0 = ok. */
static int js_string(js_t *j, char *saida, size_t tam) {
  js_esp(j);
  if(j->p >= j->fim || *j->p != '"') return -1;
  j->p++;
  size_t n = 0;
  while(j->p < j->fim && *j->p != '"') {
    char c = *j->p++;
    if(c == '\\') {
      if(j->p >= j->fim) return -1;
      char e = *j->p++;
      if(e == 'u') {
        if(j->fim - j->p < 4) return -1;
        unsigned v = 0;
        for(int k = 0; k < 4; k++) {
          char h = *j->p++;
          v = v * 16 + (unsigned)(h >= '0' && h <= '9' ? h - '0' : h >= 'a' && h <= 'f' ? h - 'a' + 10 : h >= 'A' && h <= 'F' ? h - 'A' + 10 : 0);
        }
        c = v < 0x80 ? (char)v : '?';   /* so ASCII: o resto vira "?" (mensagens de erro) */
      } else c = e == 'n' ? '\n' : e == 't' ? '\t' : e == 'r' ? '\r' : e == 'b' || e == 'f' ? ' ' : e;
    }
    if(saida && n + 1 < tam) saida[n++] = c;
  }
  if(j->p >= j->fim) return -1;
  j->p++;
  if(saida && tam) saida[n] = 0;
  return 0;
}

static int js_pular(js_t *j, int nivel) {
  js_esp(j);
  if(j->p >= j->fim || nivel > 32) return -1;
  char c = *j->p;
  if(c == '"') return js_string(j, NULL, 0);
  if(c == '{' || c == '[') {
    char fecha = c == '{' ? '}' : ']';
    j->p++;
    js_esp(j);
    if(j->p < j->fim && *j->p == fecha) {
      j->p++;
      return 0;
    }
    for(;;) {
      if(c == '{') {
        if(js_string(j, NULL, 0)) return -1;
        js_esp(j);
        if(j->p >= j->fim || *j->p != ':') return -1;
        j->p++;
      }
      if(js_pular(j, nivel + 1)) return -1;
      js_esp(j);
      if(j->p >= j->fim) return -1;
      if(*j->p == ',') {
        j->p++;
        continue;
      }
      if(*j->p == fecha) {
        j->p++;
        return 0;
      }
      return -1;
    }
  }
  while(j->p < j->fim && !strchr(",}] \n\r\t", *j->p)) j->p++;   /* numero, true, false, null */
  return 0;
}

/* Procura a chave no objeto que comeca em o->p ('{'). Achou: v aponta para o valor e devolve 1. */
static int js_campo(const js_t *o, const char *chave, js_t *v) {
  js_t j = *o;
  js_esp(&j);
  if(j.p >= j.fim || *j.p != '{') return 0;
  j.p++;
  js_esp(&j);
  if(j.p < j.fim && *j.p == '}') return 0;
  for(;;) {
    char nome[64];
    if(js_string(&j, nome, sizeof nome)) return 0;
    js_esp(&j);
    if(j.p >= j.fim || *j.p != ':') return 0;
    j.p++;
    js_esp(&j);
    if(!strcmp(nome, chave)) {
      v->p = j.p;
      v->fim = j.fim;
      return 1;
    }
    if(js_pular(&j, 1)) return 0;
    js_esp(&j);
    if(j.p >= j.fim || *j.p != ',') return 0;
    j.p++;
  }
}

static unsigned long long js_num(const js_t *v) {
  return (v->p < v->fim && *v->p >= '0' && *v->p <= '9') ? strtoull(v->p, NULL, 10) : 0;
}

static int js_nulo(const js_t *v) { return v->fim - v->p >= 4 && !strncmp(v->p, "null", 4); }

/* Texto de {"error": "..."} (ou o corpo inteiro, cortado). */
static void erro_df(const buf_t *r, char *saida, size_t tam) {
  saida[0] = 0;
  if(!r->d) return;
  js_t j = {r->d, r->d + r->n}, v;
  if(js_campo(&j, "error", &v) && !js_string(&v, saida, tam)) return;
  snprintf(saida, tam, "%.*s", (int)(r->n < 200 ? r->n : 200), r->d);
}

/* ------------------------------------------------------------------ estado */

/* Atualiza os nossos trabalhos pelo /api/jobs. Devolve 1 se o Dump Forge respondeu. */
static int atualizar(void) {
  buf_t r = {0};
  int st = df_pedir("GET", "/api/jobs", NULL, &r, 4);
  if(st != 200 || !r.d) {
    buf_free(&r);
    return 0;
  }
  js_t raiz = {r.d, r.d + r.n}, lista;
  int achou[MAX_CONV] = {0};
  if(js_campo(&raiz, "jobs", &lista)) {
    js_t j = lista;
    js_esp(&j);
    if(j.p < j.fim && *j.p == '[') {
      j.p++;
      js_esp(&j);
      while(j.p < j.fim && *j.p == '{') {
        js_t item = j, v, req, out;
        if(js_pular(&j, 1)) break;
        item.fim = j.p;
        unsigned long long id = js_campo(&item, "id", &v) ? js_num(&v) : 0;
        char saida[1100] = "";
        if(js_campo(&item, "request", &req) && js_campo(&req, "output", &out)) js_string(&out, saida, sizeof saida);
        pthread_mutex_lock(&g_trava);
        for(int i = 0; i < g_qtd; i++) {
          conv_t *c = &g_conv[i];
          if(c->job != id || strcmp(c->destino, saida) || final(c->estado)) continue;
          achou[i] = 1;
          js_t prog, done, res, x;
          if(js_campo(&item, "progress", &prog) && !js_nulo(&prog)) {
            if(js_campo(&prog, "stage", &x)) js_string(&x, c->etapa, sizeof c->etapa);
            if(js_campo(&prog, "done", &x)) c->feitos = js_num(&x);
            if(js_campo(&prog, "total", &x)) c->total = js_num(&x);
            if(strcmp(c->estado, "cancelando")) snprintf(c->estado, sizeof c->estado, "rodando");
          }
          if(js_campo(&item, "done", &done) && !js_nulo(&done) && js_campo(&done, "result", &res)) {
            js_t ok, err;
            if(js_campo(&res, "Ok", &ok)) {
              snprintf(c->estado, sizeof c->estado, "feito");
              if(js_campo(&ok, "bytes", &x)) c->bytes = js_num(&x);
              c->feitos = c->total ? c->total : c->feitos;
              diario("conversao: %llu feita: %s", c->job, c->destino);
            } else if(js_campo(&res, "Err", &err)) {
              js_string(&err, c->erro, sizeof c->erro);
              snprintf(c->estado, sizeof c->estado, "%s", !strncmp(c->erro, "cancelled", 9) ? "cancelado" : "erro");
              diario("conversao: %llu %s: %s", c->job, c->estado, c->erro);
            }
          }
        }
        pthread_mutex_unlock(&g_trava);
        js_esp(&j);
        if(j.p < j.fim && *j.p == ',') {
          j.p++;
          js_esp(&j);
        }
      }
    }
  }
  /* nosso trabalho sumiu da lista do Dump Forge: ele reiniciou (a lista e so da memoria dele) */
  pthread_mutex_lock(&g_trava);
  for(int i = 0; i < g_qtd; i++)
    if(!achou[i] && !final(g_conv[i].estado) && time(NULL) - g_conv[i].inicio > 3) {
      snprintf(g_conv[i].estado, sizeof g_conv[i].estado, "perdido");
      snprintf(g_conv[i].erro, sizeof g_conv[i].erro, "o Dump Forge reiniciou ou fechou: a conversao parou");
    }
  pthread_mutex_unlock(&g_trava);
  buf_free(&r);
  return 1;
}

void conversao_rota_estado(pedido_t *p) {
  pthread_mutex_lock(&g_trava);
  int ativos = 0;
  for(int i = 0; i < g_qtd; i++) ativos += !final(g_conv[i].estado);
  pthread_mutex_unlock(&g_trava);
  int no_ar = ativos ? atualizar() : conversao_dumpforge_no_ar();
  if(ativos && !no_ar) {   /* fora do ar com trabalhos: o Dump Forge fechou */
    pthread_mutex_lock(&g_trava);
    for(int i = 0; i < g_qtd; i++)
      if(!final(g_conv[i].estado)) {
        snprintf(g_conv[i].estado, sizeof g_conv[i].estado, "perdido");
        snprintf(g_conv[i].erro, sizeof g_conv[i].erro, "o Dump Forge fechou: a conversao parou");
      }
    pthread_mutex_unlock(&g_trava);
  }
  char formato[16], nivel[12];
  config_conversao(formato, nivel);
  buf_t b = {0};
  buf_fmt(&b, "{\"ok\":true,\"no_ar\":%s,\"porta\":%d,\"padrao\":", no_ar ? "true" : "false", porta_df());
  buf_json(&b, formato);
  buf_str(&b, ",\"nivel\":");
  buf_json(&b, nivel);
  buf_str(&b, ",\"formatos\":[");
  for(int i = 0; i < N_FORMATOS; i++) {
    buf_str(&b, i ? "," : "");
    buf_json(&b, FORMATOS[i].id);
  }
  buf_str(&b, "],\"familias\":{");
  for(int i = 0; i < N_FORMATOS; i++)
    buf_fmt(&b, "%s\"%s\":\"%c\"", i ? "," : "", FORMATOS[i].id, FORMATOS[i].familia ? FORMATOS[i].familia : '-');
  buf_str(&b, "},\"itens\":[");
  pthread_mutex_lock(&g_trava);
  for(int i = g_qtd - 1; i >= 0; i--) {   /* mais novo primeiro */
    const conv_t *c = &g_conv[i];
    buf_fmt(&b, "%s{\"id\":%llu,\"origem\":", i == g_qtd - 1 ? "" : ",", c->job);
    buf_json(&b, c->origem);
    buf_str(&b, ",\"destino\":");
    buf_json(&b, c->destino);
    buf_str(&b, ",\"formato\":");
    buf_json(&b, c->formato);
    buf_str(&b, ",\"nivel\":");
    buf_json(&b, c->nivel);
    buf_str(&b, ",\"estado\":");
    buf_json(&b, c->estado);
    buf_str(&b, ",\"etapa\":");
    buf_json(&b, c->etapa);
    buf_fmt(&b, ",\"feitos\":%llu,\"total\":%llu,\"bytes\":%llu,\"inicio\":%lld,\"erro\":", c->feitos, c->total, c->bytes, c->inicio);
    buf_json(&b, c->erro);
    buf_str(&b, "}");
  }
  pthread_mutex_unlock(&g_trava);
  buf_str(&b, "]}");
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* ------------------------------------------------------------------ iniciar */

static int termina_com(const char *s, const char *fim) {
  size_t a = strlen(s), b = strlen(fim);
  return a > b && !strcasecmp(s + a - b, fim);
}

/* Nome base (sem ".complete" e sem a extensao de jogo/compactado) e formato da origem ("pasta", "exfat", ... ou
   "compactado"). 0 = origem aceita. */
static int origem_ler(const char *nome, int pasta, char *base, size_t tam, char *fmt, size_t tam_fmt) {
  snprintf(base, tam, "%s", nome);
  if(pasta) {
    /* pasta com packs zstd/LZ4 ja e "pasta_zstd"/"pasta_lz4" so pelo conteudo; o nome nao diz: conta como pasta */
    snprintf(fmt, tam_fmt, "pasta");
    return 0;
  }
  if(termina_com(base, ".complete")) base[strlen(base) - 9] = 0;
  static const char *const EXT[] = {".exfat", ".ffpkg", ".ffpfs", ".ffpfsc", ".pkg", ".zip", ".7z", ".rar", NULL};
  for(int i = 0; EXT[i]; i++)
    if(termina_com(base, EXT[i])) {
      base[strlen(base) - strlen(EXT[i])] = 0;
      snprintf(fmt, tam_fmt, "%s", i >= 5 ? "compactado" : EXT[i] + 1);
      return 0;
    }
  return -1;
}

static void recusa(buf_t *r, int *n, const char *nome, const char *motivo, const char *texto) {
  buf_str(r, (*n)++ ? ",{\"nome\":" : "{\"nome\":");
  buf_json(r, nome);
  buf_str(r, ",\"motivo\":");
  buf_json(r, motivo);
  buf_str(r, ",\"texto\":");
  buf_json(r, texto ? texto : "");
  buf_str(r, "}");
}

static void guardar(const conv_t *c) {
  pthread_mutex_lock(&g_trava);
  if(g_qtd == MAX_CONV) {   /* cheio: sai o terminado mais velho (ou o mais velho de todos) */
    int sai = 0;
    for(int i = 0; i < g_qtd; i++)
      if(final(g_conv[i].estado)) {
        sai = i;
        break;
      }
    memmove(&g_conv[sai], &g_conv[sai + 1], (size_t)(g_qtd - sai - 1) * sizeof *g_conv);
    g_qtd--;
  }
  g_conv[g_qtd++] = *c;
  pthread_mutex_unlock(&g_trava);
}

static int destino_em_uso(const char *destino) {
  pthread_mutex_lock(&g_trava);
  int r = 0;
  for(int i = 0; i < g_qtd && !r; i++) r = !final(g_conv[i].estado) && !strcmp(g_conv[i].destino, destino);
  pthread_mutex_unlock(&g_trava);
  return r;
}

void conversao_rota_iniciar(pedido_t *p) {
  char formato[16] = "", nivel[12] = "", padrao_f[16], padrao_n[12];
  config_conversao(padrao_f, padrao_n);
  param(p->corpo, "formato", 0, formato, sizeof formato);
  param(p->corpo, "nivel", 0, nivel, sizeof nivel);
  if(!formato[0]) snprintf(formato, sizeof formato, "%s", padrao_f);
  (void)padrao_n;   /* nivel vazio = padrao do Dump Forge (a pagina manda o nivel da opcao geral quando vale) */
  int f = achar_formato(formato);
  if(f < 0) {
    responder_erro(p, 400, "conv_formato_invalido", "formato de conversao desconhecido", NULL);
    return;
  }
  if(!conversao_nivel_valido(formato, nivel)) {
    responder_erro(p, 400, "conv_nivel_invalido", "nivel de compressao desconhecido", NULL);
    return;
  }
  if(!conversao_dumpforge_no_ar()) {
    responder_erro(p, 503, "dumpforge_fora", "o Dump Forge nao esta no ar: ligue-o pela pagina Payloads", NULL);
    return;
  }
  buf_t rec = {0};
  int nrec = 0, criadas = 0;
  char pasta[1024], nome[512];
  for(int i = 0; i < 200 && param(p->corpo, "pasta", i, pasta, sizeof pasta); i++) {
    nome[0] = 0;
    param(p->corpo, "de", i, nome, sizeof nome);
    if(!config_pasta_permitida(pasta) || !caminho_valido(pasta)) {
      recusa(&rec, &nrec, nome, "fora_das_pastas", NULL);
      continue;
    }
    if(!nome_valido(nome)) {
      recusa(&rec, &nrec, nome, "invalido", NULL);
      continue;
    }
    conv_t c;
    memset(&c, 0, sizeof c);
    char base[512], fmt_origem[16];
    snprintf(c.origem, sizeof c.origem, "%s%s%s", pasta, pasta[strlen(pasta) - 1] == '/' ? "" : "/", nome);
    struct stat st;
    if(lstat(c.origem, &st) || !(S_ISREG(st.st_mode) || S_ISDIR(st.st_mode))) {
      recusa(&rec, &nrec, nome, "nao_existe", NULL);
      continue;
    }
    if(origem_ler(nome, S_ISDIR(st.st_mode), base, sizeof base, fmt_origem, sizeof fmt_origem) || !base[0]) {
      recusa(&rec, &nrec, nome, "origem_invalida", NULL);
      continue;
    }
    if(!strcmp(fmt_origem, formato)) {
      recusa(&rec, &nrec, nome, "mesmo_formato", NULL);
      continue;
    }
    snprintf(c.destino, sizeof c.destino, "%s%s%s%s", pasta, pasta[strlen(pasta) - 1] == '/' ? "" : "/", base, FORMATOS[f].sufixo);
    if(!lstat(c.destino, &st) || destino_em_uso(c.destino)) {
      recusa(&rec, &nrec, nome, "destino_existe", c.destino);
      continue;
    }
    buf_t corpo = {0}, resp = {0};
    buf_str(&corpo, "{\"request\":{\"source\":");
    buf_json(&corpo, c.origem);
    buf_str(&corpo, ",\"output\":");
    buf_json(&corpo, c.destino);
    buf_fmt(&corpo, ",\"format\":\"%s\"%s", FORMATOS[f].formato, FORMATOS[f].extra);
    nivel_campo(f, nivel, &corpo);
    buf_str(&corpo, ",\"delete_source\":false}}");
    buf_add(&corpo, "", 1);
    int st_df = df_pedir("POST", "/api/start_job", corpo.d, &resp, 20);
    buf_free(&corpo);
    if(st_df == 200 && resp.d && resp.n && resp.d[0] >= '0' && resp.d[0] <= '9') {
      buf_add(&resp, "", 1);
      c.job = strtoull(resp.d, NULL, 10);
      snprintf(c.formato, sizeof c.formato, "%s", formato);
      snprintf(c.nivel, sizeof c.nivel, "%s", nivel);
      snprintf(c.estado, sizeof c.estado, "fila");
      c.inicio = (long long)time(NULL);
      guardar(&c);
      criadas++;
      diario("conversao: %llu pedida: %s -> %s (%s%s%s)", c.job, c.origem, c.destino, formato, c.nivel[0] ? " " : "", c.nivel);
    } else {
      char erro[300];
      erro_df(&resp, erro, sizeof erro);
      if(st_df < 0) snprintf(erro, sizeof erro, "o Dump Forge nao respondeu");
      diario("conversao: recusada pelo Dump Forge (%d): %s: %s", st_df, c.origem, erro);
      recusa(&rec, &nrec, nome, "dumpforge", erro);
    }
    buf_free(&resp);
  }
  buf_t b = {0};
  buf_fmt(&b, "{\"ok\":true,\"criadas\":%d,\"recusadas\":[", criadas);
  if(rec.d) buf_add(&b, rec.d, rec.n);
  buf_str(&b, "]}");
  responder_json(p, 200, &b);
  buf_free(&b);
  buf_free(&rec);
}

/* ------------------------------------------------------------------ cancelar, limpar, padrao */

void conversao_rota_cancelar(pedido_t *p) {
  char id[24] = "";
  param(p->corpo, "id", 0, id, sizeof id);
  unsigned long long job = strtoull(id, NULL, 10);
  int i, achou = 0;
  pthread_mutex_lock(&g_trava);
  for(i = 0; i < g_qtd; i++)
    if(id[0] && g_conv[i].job == job && !final(g_conv[i].estado)) {
      achou = 1;
      break;
    }
  pthread_mutex_unlock(&g_trava);
  if(!achou) {
    responder_erro(p, 404, "conv_nao_achada", "conversao nao encontrada (ou ja terminou)", NULL);
    return;
  }
  char corpo[64];
  snprintf(corpo, sizeof corpo, "{\"id\":%llu}", job);
  buf_t r = {0};
  int st = df_pedir("POST", "/api/cancel_job", corpo, &r, 5);
  buf_free(&r);
  if(st != 200) {
    responder_erro(p, 503, "dumpforge_fora", "o Dump Forge nao respondeu", NULL);
    return;
  }
  pthread_mutex_lock(&g_trava);
  for(i = 0; i < g_qtd; i++)
    if(g_conv[i].job == job && !final(g_conv[i].estado)) snprintf(g_conv[i].estado, sizeof g_conv[i].estado, "cancelando");
  pthread_mutex_unlock(&g_trava);
  diario("conversao: %llu: cancelamento pedido", job);
  static const char ok[] = "{\"ok\":true}";
  responder(p, 200, "application/json", ok, sizeof ok - 1, "no-store");
}

void conversao_rota_limpar(pedido_t *p) {
  pthread_mutex_lock(&g_trava);
  int n = 0;
  for(int i = 0; i < g_qtd; i++)
    if(!final(g_conv[i].estado)) g_conv[n++] = g_conv[i];
  int tirados = g_qtd - n;
  g_qtd = n;
  pthread_mutex_unlock(&g_trava);
  buf_t b = {0};
  buf_fmt(&b, "{\"ok\":true,\"tirados\":%d}", tirados);
  responder_json(p, 200, &b);
  buf_free(&b);
}

void conversao_rota_padrao(pedido_t *p) {
  char formato[16] = "", nivel[12] = "", atual_f[16], atual_n[12];
  config_conversao(atual_f, atual_n);
  param(p->corpo, "formato", 0, formato, sizeof formato);
  param(p->corpo, "nivel", 0, nivel, sizeof nivel);
  if(!formato[0]) snprintf(formato, sizeof formato, "%s", atual_f);
  (void)atual_n;   /* nivel vazio = padrao do Dump Forge */
  if(!conversao_formato_valido(formato) || !conversao_nivel_valido(formato, nivel)) {
    responder_erro(p, 400, "conv_formato_invalido", "formato ou nivel desconhecido", NULL);
    return;
  }
  if(config_gravar_conversao(formato, nivel)) {
    responder_erro(p, 500, "conv_gravar", "nao gravou o config.ini", NULL);
    return;
  }
  buf_t b = {0};
  buf_str(&b, "{\"ok\":true,\"padrao\":");
  buf_json(&b, formato);
  buf_str(&b, ",\"nivel\":");
  buf_json(&b, nivel);
  buf_str(&b, "}");
  responder_json(p, 200, &b);
  buf_free(&b);
}
