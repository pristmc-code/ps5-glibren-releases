/* Game Library Renamer (payload PS5) - 0.9.30: converter jogos de formato pelo ps5-dump-forge.

O glibren nao converte nada sozinho: pede ao payload ps5-dump-forge (quer3q, GPL-3.0; v0.5.6 testada no contrato), que
fica no ar no proprio PS5 com uma API HTTP local sem autenticacao em 127.0.0.1:8095:
  POST /api/start_job {"request": ConvertRequest} -> id do trabalho (numero) ou {"error": "..."};
  GET  /api/jobs -> {"instance", "jobs": [{"id", "request", "stages", "progress", "done", "log", "log_total"}]};
  POST /api/cancel_job {"id": N}; GET /api/session (so para saber se esta no ar).
Formatos (ids combinados com a Jobe): exfat, ffpkg, ffpfs, ffpfsc, pkg (FPKG debug), pasta, pasta_zstd, pasta_lz4 e as
imagens com packs zstd dentro: exfat_zstd, ffpkg_zstd, ffpfs_zstd, ffpfsc_zstd. Nivel de compressao opcional (vazio = o
padrao do Dump Forge): Kraken fast/balanced/smallest/stored (.pkg), zstd 1-22, zlib 0-9 (.ffpfsc), LZ4 0 ou 3-12. Saida ao lado da origem, com o nome da origem e a extensao nova (pastas: sem
extensao; zstd/LZ4 com "-zstd"/"-lz4"); nunca apaga a origem (delete_source fica falso); destino que ja existe =
recusado. Ligar o Dump Forge: pagina Payloads (item "dump-forge" em payloads.c). Testes no PC: GLR_TESTE_DUMPFORGE_PORTA. */
#pragma once

#include "http.h"

/* GET /api/conversao (leitura livre): {"ok","no_ar","padrao","nivel","formatos":[..],"familias":{id:"k|z|c|l|-"},"itens":[..]} */
void conversao_rota_estado(pedido_t *p);
/* POST /api/conversao (formato, nivel, pasta[], de[]): pareamento + X-GLR ja conferidos pelo api.c */
void conversao_rota_iniciar(pedido_t *p);
/* POST /api/conversao/cancelar (id = numero do trabalho no Dump Forge) */
void conversao_rota_cancelar(pedido_t *p);
/* POST /api/conversao/limpar: tira da lista as conversoes terminadas (nao mexe em arquivo) */
void conversao_rota_limpar(pedido_t *p);
/* POST /api/conversao/padrao (formato, nivel): opcao geral, gravada no config.ini */
void conversao_rota_padrao(pedido_t *p);
/* 1 = o id e um formato de saida conhecido / o nivel vale para esse formato */
int conversao_formato_valido(const char *id);
int conversao_nivel_valido(const char *formato, const char *nivel);   /* "" = padrao do Dump Forge */
/* 1 = o Dump Forge responde em 127.0.0.1:8095 (payloads.c usa para o estado "rodando") */
int conversao_dumpforge_no_ar(void);
