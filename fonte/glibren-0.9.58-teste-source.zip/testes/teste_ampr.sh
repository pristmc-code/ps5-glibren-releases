#!/bin/bash
# Testa o build de teste do ampr-emu-ng no ShadowKraken (0.9.51) na versao de PC: GET /api/ampr, envio pelo celular/PC
# (POST /api/ampr/enviar), escolha num disco (POST /api/ampr/arquivo), voltar ao embutido (POST /api/ampr/embutido),
# recusas (PS5/127.0.0.1, nao-ampr, nao-ELF, grande demais, fora dos discos, jogo aberto), [emulators] path do
# config.ini do ShadowKraken, e as copias do /data/ampr_emu_trace.txt (parado ha 2 s, title ID no nome, so as 5 mais
# novas). /data = $T/montador (GLR_TESTE_MONTADOR, o mesmo do diagnostico).
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_ampr.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8971
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R="http://$IP:$PORTA"
T=/root/glr-ampr; DADOS=$T/dados; A=$T/lista; M=$T/montador; D=$T/disco
RT=$M/shadowmount/emus/ampr-emu-ng/libSceAmpr.sprx
UA_PS5='Mozilla/5.0 (PlayStation; PlayStation 5/12.00) AppleWebKit/605.1.15 (KHTML, like Gecko)'
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$(echo "$2" | head -c 600)] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
TOKEN=""
post() { curl -s -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" "$@"; }
codigo() { curl -s -o /dev/null -w '%{http_code}' -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" "$@"; }
estado() { curl -s "$L/api/ampr"; }
enviar() { post --data-binary "@$1" "$R/api/ampr/enviar?nome=$2"; }
rm -rf "$T"; mkdir -p "$DADOS" "$A" "$M/shadowmount" "$D/pasta"
printf 'language = pt-BR\nfolder = %s/\n' "$A" > "$DADOS/config.ini"

# runtimes de mentira: magia SELF + "ampr-emu-ng X.Y.Z"; o de depuracao tem o caminho do trace e o commit
python3 -I - "$T" <<'EOF'
import os, sys
t = sys.argv[1]
def grava(nome, corpo, tam=200000, magia=b"\x4f\x15\x3d\x1d"):
    d = magia + b"\0" * 1000 + corpo
    d += b"\0" * (tam - len(d))
    open(os.path.join(t, nome), "wb").write(d)
grava("release.sprx", b"xx ampr-emu-ng 0.5.0\0")
grava("debug.sprx", b"ampr-emu-ng 0.5.0\0/data/ampr_emu_trace.txt\0elMmapdup/download0/0.5.0lz4pkgplain-fs 5a8cca6startok\0", 300000)
grava("sem-marcador.sprx", b"isto nao e o runtime\0")
grava("nao-elf.sprx", b"ampr-emu-ng 0.5.0\0", magia=b"PK\3\4")
grava("pequeno.sprx", b"ampr-emu-ng 0.5.0\0", tam=10000)
grava("grande.sprx", b"ampr-emu-ng 0.5.0\0", tam=9 * 1024 * 1024)
EOF
cp "$T/debug.sprx" "$D/pasta/ampr-pr113-debug.sprx"
cp "$T/grande.sprx" "$D/pasta/grande.sprx"
SHA_REL=$(sha256sum "$T/release.sprx" | cut -d' ' -f1); SHA_DBG=$(sha256sum "$T/debug.sprx" | cut -d' ' -f1)

inicia() {
  GLR_TESTE_AMPR_CONHECIDO="${CONHECIDO:-}" GLR_TESTE_MONTADOR="$M" GLR_TESTE_ARQ_RAIZES="$D" GLR_TESTE_ABERTOS="$T/abertos" GLR_TESTE_AMPR_VIGIA_MS=200 GLR_TESTE_AMPR_PARADO_S=2 \
    "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
inicia
# pareia o "celular" (as rotas de troca so pelo celular/PC pareado)
curl -s -H 'X-GLR: 1' -X POST $R/api/parear/pedir > /dev/null
C=$(grep -o 'pareamento [0-9]\{6\}' "$T/glr.log" | tail -1 | awk '{print $2}')
TOKEN=$(curl -s -H 'X-GLR: 1' -d codigo=$C -d nome=Teste $R/api/parear | python3 -c 'import json,sys; print(json.load(sys.stdin)["token"])')
confere "pareado"                           "$TOKEN" "^[0-9a-f]\{64\}$"

echo "--- estado inicial"
E=$(estado)
confere "sem arquivo de teste"              "$E" '"teste":null'
confere "sem anterior"                      "$E" '"anterior":null'
confere "sem traces"                        "$E" '"traces":0,"ultimo_trace":null'
confere "pasta padrao dos emuladores"       "$E" "\"pasta_emus\":\"$M/shadowmount/emus\""

echo "--- recusas"
confere "127.0.0.1 = 403"                   "$(codigo --data-binary @$T/release.sprx "$L/api/ampr/enviar?nome=r.sprx")" "403"
confere "navegador do PS5 = 403"            "$(codigo -A "$UA_PS5" --data-binary @$T/release.sprx "$R/api/ampr/enviar?nome=r.sprx")" "403"
confere "sem X-GLR = 403"                   "$(curl -s -o /dev/null -w '%{http_code}' -H "X-GLR-Token: $TOKEN" --data-binary @$T/release.sprx "$R/api/ampr/enviar?nome=r.sprx")" "403"
confere "sem token = 401"                   "$(curl -s -o /dev/null -w '%{http_code}' -H 'X-GLR: 1' --data-binary @$T/release.sprx "$R/api/ampr/enviar?nome=r.sprx")" "401"
confere "nome que nao e .sprx"              "$(enviar $T/release.sprx r.elf)" '"chave":"ampr_arquivo_nome"'
confere "sem o marcador = recusa"           "$(enviar $T/sem-marcador.sprx s.sprx)" 'nao tem o marcador'
confere "nao e SELF/ELF = recusa"           "$(enviar $T/nao-elf.sprx n.sprx)" 'nao e um SELF/ELF'
confere "pequeno demais = recusa"           "$(enviar $T/pequeno.sprx p.sprx)" 'tamanho fora do limite'
confere "grande demais (envio) = 413"       "$(codigo --data-binary @$T/grande.sprx "$R/api/ampr/enviar?nome=g.sprx")" "413"
confere "grande demais (disco) = recusa"    "$(post --data-urlencode "caminho=$D/pasta/grande.sprx" $R/api/ampr/arquivo)" 'tamanho fora do limite'
confere "fora dos discos = recusa"          "$(post --data-urlencode "caminho=$T/release.sprx" $R/api/ampr/arquivo)" '"chave":"ampr_arquivo_fora"'
confere "caminho com .. = recusa"           "$(post --data-urlencode "caminho=$D/pasta/../pasta/ampr-pr113-debug.sprx" $R/api/ampr/arquivo)" '"chave":"ampr_arquivo_fora"'
confere "nada gravado"                      "$(ls $M/shadowmount/emus/ampr-emu-ng 2>&1)" "No such file"

echo "--- enviar o release pelo celular/PC"
E=$(enviar $T/release.sprx ampr-emu-ng-pr113-5a8cca6-release.sprx)
confere "envio ok"                          "$E" '"ok":true,"nome":"ampr-emu-ng-pr113-5a8cca6-release.sprx","versao":"0.5.0","commit":"","depuracao":false'
confere "gravado no lugar do ShadowKraken"  "$(sha256sum $RT | cut -d' ' -f1)" "^$SHA_REL$"
confere "sem .tmp sobrando"                 "$(ls $M/shadowmount/emus/ampr-emu-ng)" "^libSceAmpr.sprx$"
E=$(estado)
confere "estado: teste valido"              "$E" "\"teste\":{\"valido\":true,\"caminho\":\"$RT\",\"versao\":\"0.5.0\",\"commit\":\"\",\"depuracao\":false"
confere "estado: SHA-256"                   "$E" "\"sha256\":\"$SHA_REL\""
# 0.9.55: o nome do arquivo escolhido e de onde veio ficam guardados (na pasta do glibren, nao na dos emuladores)
confere "estado: nome e origem (celular)"   "$E" "\"sha256\":\"$SHA_REL\",\"nome\":\"ampr-emu-ng-pr113-5a8cca6-release.sprx\",\"origem\":\"@celular\",\"instalado\":[1-9]"
confere "estado: nao e build conhecido"     "$E" '"conhecido":null'
confere "dados em <dados>/ampr-teste"       "$(cat $DADOS/ampr-teste/atual.txt)" "^nome=ampr-emu-ng-pr113-5a8cca6-release.sprx$"
confere "dados: sha e tamanho"              "$(cat $DADOS/ampr-teste/atual.txt)" "^sha256=$SHA_REL$"
confere "dados: tamanho"                    "$(cat $DADOS/ampr-teste/atual.txt)" "^tamanho=200000$"
confere "nada a mais nos emuladores"        "$(ls $M/shadowmount/emus/ampr-emu-ng)" "^libSceAmpr.sprx$"
confere "diario: instalado"                 "$(cat $DADOS/glibren.log)" "ampr-teste: build de teste instalado: celular/PC: ampr-emu-ng-pr113-5a8cca6-release.sprx"

echo "--- jogo aberto: recusa"
echo PPSA29629 > "$T/abertos"
E=$(post --data-urlencode "caminho=$D/pasta/ampr-pr113-debug.sprx" $R/api/ampr/arquivo)
confere "jogo aberto = ampr_jogo_aberto"    "$E" '"chave":"ampr_jogo_aberto".*"nome":"PPSA29629"'
confere "embutido com jogo aberto = 409"    "$(codigo -X POST $R/api/ampr/embutido)" "409"
confere "nao trocou"                        "$(sha256sum $RT | cut -d' ' -f1)" "^$SHA_REL$"
rm -f "$T/abertos"

echo "--- escolher o de depuracao num disco"
E=$(post --data-urlencode "caminho=$D/pasta/ampr-pr113-debug.sprx" $R/api/ampr/arquivo)
confere "disco ok, depuracao e commit"      "$E" '"ok":true,"nome":"ampr-pr113-debug.sprx","versao":"0.5.0","commit":"5a8cca6","depuracao":true'
confere "gravado (depuracao)"               "$(sha256sum $RT | cut -d' ' -f1)" "^$SHA_DBG$"
confere "release guardado como .anterior"   "$(sha256sum $RT.anterior | cut -d' ' -f1)" "^$SHA_REL$"
confere "origem fica"                       "$(ls $D/pasta)" "ampr-pr113-debug.sprx"
E=$(estado)
confere "estado: anterior = release"        "$E" "\"anterior\":{\"valido\":true,\"caminho\":\"$RT.anterior\",\"versao\":\"0.5.0\",\"commit\":\"\",\"depuracao\":false"
confere "estado: nome e origem (disco)"     "$E" "\"teste\":{.*\"nome\":\"ampr-pr113-debug.sprx\",\"origem\":\"$D/pasta/ampr-pr113-debug.sprx\""
confere "anterior leva o nome junto"        "$E" "\"anterior\":{.*\"nome\":\"ampr-emu-ng-pr113-5a8cca6-release.sprx\",\"origem\":\"@celular\""
confere "dados: commit e depuracao"         "$(cat $DADOS/ampr-teste/atual.txt)" "^commit=5a8cca6$"
confere "dados do anterior"                 "$(cat $DADOS/ampr-teste/anterior.txt)" "^nome=ampr-emu-ng-pr113-5a8cca6-release.sprx$"

echo "--- [emulators] path do ShadowKraken"
printf '[general]\npath = /nao\n[emulators]\npath = /data/shadowmount/emus2/\n' > "$M/shadowmount/config.ini"
confere "pasta do config.ini"               "$(estado)" "\"pasta_emus\":\"$M/shadowmount/emus2\",\"teste\":null"
rm -f "$M/shadowmount/config.ini"

echo "--- voltar ao embutido"
confere "embutido ok"                       "$(post -X POST $R/api/ampr/embutido)" '"ok":true,"ja":false'
confere "arquivo de teste saiu"             "$(ls $RT 2>&1)" "No such file"
confere "o de teste ficou como .anterior"   "$(sha256sum $RT.anterior | cut -d' ' -f1)" "^$SHA_DBG$"
confere "estado: embutido"                  "$(estado)" '"teste":null'
confere "anterior = o de depuracao, com nome" "$(estado)" "\"anterior\":{.*\"nome\":\"ampr-pr113-debug.sprx\""
confere "dados do atual sairam"             "$(ls $DADOS/ampr-teste)" "^anterior.txt$"
confere "de novo: ja estava"                "$(post -X POST $R/api/ampr/embutido)" '"ok":true,"ja":true'
confere "diario: voltou"                    "$(cat $DADOS/glibren.log)" "ampr-teste: voltou ao ampr-emu-ng embutido"
printf 'lixo' > "$RT"
confere "arquivo invalido no lugar"         "$(estado)" "\"teste\":{\"valido\":false,\"caminho\":\"$RT\"}"
rm -f "$RT"

echo "--- sem dados (posto pelo FTP ou antes da 0.9.55)"
cp "$T/release.sprx" "$RT"
E=$(estado)
confere "pelo FTP: sem nome"                "$E" "\"teste\":{.*\"sha256\":\"$SHA_REL\",\"nome\":\"\",\"origem\":\"\",\"instalado\":0,\"conhecido\":null"
# o anterior foi trocado pelo FTP: o nome guardado (de outro SHA) nao vale
cp "$T/release.sprx" "$RT.anterior"
confere "anterior trocado: nome nao vale"   "$(estado)" "\"anterior\":{.*\"nome\":\"\",\"origem\":\"\""
para
CONHECIDO=$SHA_REL inicia
confere "reconhecido pelo SHA-256"          "$(estado)" "\"teste\":{.*\"nome\":\"\",.*\"conhecido\":{\"nome\":\"ampr-emu-ng-teste-conhecido.sprx\",\"corrige\":\"hades\"}"
para
inicia
rm -f "$RT" "$RT.anterior"

echo "--- traces do build de depuracao"
TR=$M/ampr_emu_trace.txt
for k in 1 2 3 4 5 6 7; do
  printf 'ampr-emu-ng 0.5.0 debug\ntitle PPSA29629 inicio %s\nlinha final %s\n' "$k" "$k" > "$TR"
  touch -d "2026-11-20 22:0$k:00" "$TR"
  for i in $(seq 1 40); do ls $DADOS/ampr-traces 2>/dev/null | grep -q "22:0$k\|220${k}00" && break; sleep 0.1; done
done
sleep 0.6
L5=$(ls $DADOS/ampr-traces)
confere "so as 5 mais novas"                "$(echo "$L5" | wc -l)" "^5$"
confere "nome com data e title ID"          "$L5" "2026-11-20_220700-PPSA29629.txt"
nao_tem "a mais velha saiu"                 "$L5" "220100"
nao_tem "a 2a mais velha saiu"              "$L5" "220200"
confere "conteudo copiado"                  "$(cat $DADOS/ampr-traces/2026-11-20_220700-PPSA29629.txt)" "linha final 7"
E=$(estado)
confere "estado: 5 traces e o ultimo"       "$E" '"traces":5,"ultimo_trace":{"nome":"2026-11-20_220700-PPSA29629.txt"'
confere "diario: trace copiado"             "$(cat $DADOS/glibren.log)" "ampr-teste: trace do ampr-emu-ng copiado: 2026-11-20_220700-PPSA29629.txt"
# o mesmo arquivo sem mudar: nao copia de novo
sleep 0.6
confere "sem copia repetida"                "$(ls $DADOS/ampr-traces | wc -l)" "^5$"
# sendo gravado agora (mtime recente): espera ficar parado
printf 'gravando\n' > "$TR"
sleep 0.4
confere "recente: ainda nao copia"          "$(grep -l gravando $DADOS/ampr-traces/* 2>/dev/null | wc -l)" "^0$"
sleep 3
confere "parado: copia"                     "$(grep -l gravando $DADOS/ampr-traces/* | wc -l)" "^1$"
para

echo "--- reinicio: o trace que ja existe nao vira copia nova"
inicia
sleep 1
confere "reinicio sem copia nova"           "$(ls $DADOS/ampr-traces | wc -l)" "^5$"
para

echo "--- 0.9.57: ampr-emu-ng no fakelib/ dos backports"
inicia
BK=$M/homebrew/backports
mkdir -p "$BK/PPSA13427-HZD/fakelib" "$BK/PPSA00001/fakelib" "$BK/PPSA00002" "$BK/nao-e-titulo" "$M/shadowmount/fpkg-runtime/v0.4.1/ampr-emu-ng"
echo outra > "$BK/PPSA13427-HZD/fakelib/libSceNpAuth.sprx"
printf 'AMPR ORIGINAL DO BACKPORT' > "$BK/PPSA00001/fakelib/libSceAmpr.sprx"
ln -s "$BK/PPSA00002" "$BK/PPSA00003-link"
rm -f "$RT"
bk() { curl -s "$L/api/ampr/backports"; }
bkp() { post --data-urlencode "caminho=$1" -d "acao=$2" "$R/api/ampr/backport"; }
E=$(bk)
confere "lista: sem fonte (nada instalado)" "$E" '"fonte":null'
confere "lista: 3 backports (sem link/nome)" "$(echo "$E" | grep -o '"titulo"' | wc -l)" "^3$"
nao_tem "lista: sem o link"                 "$E" 'PPSA00003'
nao_tem "lista: sem pasta sem titulo"       "$E" 'nao-e-titulo'
confere "lista: HZD sem ampr"               "$E" '"caminho":"/data/homebrew/backports/PPSA13427-HZD","pasta":"PPSA13427-HZD","titulo":"PPSA13427","fakelib":true,"ampr":null,"nosso":false'
confere "lista: PPSA00001 com outro AMPR"   "$E" '"titulo":"PPSA00001","fakelib":true,"ampr":{"ng":false}'
confere "lista: PPSA00002 sem fakelib"      "$E" '"titulo":"PPSA00002","fakelib":false'
confere "por sem fonte = sem_fonte"         "$(bkp /data/homebrew/backports/PPSA13427-HZD por)" '"chave":"ampr_bkp_sem_fonte"'
cp "$T/release.sprx" "$M/shadowmount/fpkg-runtime/v0.4.1/ampr-emu-ng/libSceAmpr.sprx"
confere "fonte: o embutido"                 "$(bk)" '"fonte":{"teste":false,"versao":"0.5.0"'
cp "$T/debug.sprx" "$RT"
confere "fonte: o de teste (depuracao)"     "$(bk)" '"fonte":{"teste":true,"versao":"0.5.0","commit":"5a8cca6","depuracao":true'
confere "sem token = 401"                   "$(curl -s -o /dev/null -w '%{http_code}' -H 'X-GLR: 1' -d acao=por --data-urlencode caminho=/data/homebrew/backports/PPSA13427-HZD $R/api/ampr/backport)" "401"
confere "pelo PS5 = 403"                    "$(curl -s -o /dev/null -w '%{http_code}' -A "$UA_PS5" -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" -d acao=por --data-urlencode caminho=/data/homebrew/backports/PPSA13427-HZD $R/api/ampr/backport)" "403"
confere "acao invalida = 400"               "$(bkp /data/homebrew/backports/PPSA13427-HZD apagar)" '"chave":"ampr_bkp_acao"'
confere "fora da lista = 404"               "$(bkp /data/homebrew/backports/../../shadowmount por)" '"chave":"ampr_bkp_nao_achou"'
confere "link = 404"                        "$(bkp /data/homebrew/backports/PPSA00003-link por)" '"chave":"ampr_bkp_nao_achou"'
echo PPSA13427 > "$T/abertos"
confere "jogo aberto = 409"                 "$(bkp /data/homebrew/backports/PPSA13427-HZD por)" '"chave":"ampr_jogo_aberto"'
rm -f "$T/abertos"
confere "por no HZD"                        "$(bkp /data/homebrew/backports/PPSA13427-HZD por)" '"ok":true,"titulo":"PPSA13427","teste":true,"guardou":false,"versao":"0.5.0","commit":"5a8cca6"'
confere "HZD: arquivo igual ao de teste"    "$(sha256sum "$BK/PPSA13427-HZD/fakelib/libSceAmpr.sprx" | cut -d' ' -f1)" "^$SHA_DBG$"
confere "HZD: o resto do fakelib ficou"     "$(cat "$BK/PPSA13427-HZD/fakelib/libSceNpAuth.sprx")" "^outra$"
nao_tem "HZD: sem .tmp"                     "$(ls -a "$BK/PPSA13427-HZD/fakelib")" 'tmp'
confere "lista: HZD nosso"                  "$(bk)" '"titulo":"PPSA13427","fakelib":true,"ampr":{"ng":true,"versao":"0.5.0","commit":"5a8cca6","depuracao":true,"sha256":"'$SHA_DBG'","conhecido":null},"nosso":true,"original":false'
confere "diario: posto"                     "$(cat $DADOS/glibren.log)" 'ampr-backport: /data/homebrew/backports/PPSA13427-HZD/fakelib/libSceAmpr.sprx = ampr-emu-ng 0.5.0 5a8cca6 (o de teste, depuracao'
confere "por de novo (troca o nosso)"       "$(bkp /data/homebrew/backports/PPSA13427-HZD por)" '"guardou":false'
confere "tirar do HZD"                      "$(bkp /data/homebrew/backports/PPSA13427-HZD tirar)" '"ok":true,"titulo":"PPSA13427","voltou_original":false'
confere "HZD: arquivo saiu, pasta ficou"    "$(ls "$BK/PPSA13427-HZD/fakelib")" '^libSceNpAuth.sprx$'
confere "tirar de novo = nao_nosso"         "$(bkp /data/homebrew/backports/PPSA13427-HZD tirar)" '"chave":"ampr_bkp_nao_nosso"'
echo "-- com AMPR original"
confere "por no PPSA00001"                  "$(bkp /data/homebrew/backports/PPSA00001 por)" '"guardou":true'
confere "original guardado no glibren"      "$(cat $DADOS/ampr-backport/data_homebrew_backports_PPSA00001.original.sprx)" '^AMPR ORIGINAL DO BACKPORT$'
cp "$T/release.sprx" "$RT"
confere "por de novo: original continua"    "$(bkp /data/homebrew/backports/PPSA00001 por)" '"guardou":true,"versao":"0.5.0","commit":""'
confere "original ainda o do backport"      "$(cat $DADOS/ampr-backport/data_homebrew_backports_PPSA00001.original.sprx)" '^AMPR ORIGINAL DO BACKPORT$'
confere "lista: original guardado"          "$(bk)" '"titulo":"PPSA00001".*"nosso":true,"original":true'
confere "tirar: original volta"             "$(bkp /data/homebrew/backports/PPSA00001 tirar)" '"voltou_original":true'
confere "PPSA00001: original de volta"      "$(cat "$BK/PPSA00001/fakelib/libSceAmpr.sprx")" '^AMPR ORIGINAL DO BACKPORT$'
nao_tem "guarda apagada"                    "$(ls $DADOS/ampr-backport)" 'PPSA00001'
echo "-- trocado pelo FTP depois"
bkp /data/homebrew/backports/PPSA00001 por > /dev/null
printf 'OUTRO PELO FTP' > "$BK/PPSA00001/fakelib/libSceAmpr.sprx"
confere "lista: nao e mais nosso"           "$(bk)" '"titulo":"PPSA00001","fakelib":true,"ampr":{"ng":false},"nosso":false'
confere "tirar = nao_nosso"                 "$(bkp /data/homebrew/backports/PPSA00001 tirar)" '"chave":"ampr_bkp_nao_nosso"'
confere "por guarda o novo do FTP"          "$(bkp /data/homebrew/backports/PPSA00001 por; cat $DADOS/ampr-backport/data_homebrew_backports_PPSA00001.original.sprx)" 'OUTRO PELO FTP$'
echo "-- sem fakelib"
confere "por no PPSA00002 (cria fakelib)"   "$(bkp /data/homebrew/backports/PPSA00002 por)" '"ok":true'
confere "fakelib criado com o arquivo"      "$(ls "$BK/PPSA00002/fakelib")" '^libSceAmpr.sprx$'
confere "tirar: fakelib criado sai"         "$(bkp /data/homebrew/backports/PPSA00002 tirar; ls "$BK/PPSA00002")" '"ok":true'
nao_tem "PPSA00002 sem fakelib"             "$(ls "$BK/PPSA00002")" 'fakelib'
touch "$M/shadowmount/emus/libSceAmpr.sprx"
confere "aviso: libSceAmpr solto no emus"   "$(bk)" '"emus_ampr":true'
rm -f "$M/shadowmount/emus/libSceAmpr.sprx"
P=$(curl -s $L/payloads)
confere "pagina: secao dos backports"       "$P" 'class="bkp-lista"'
confere "pagina: rota /api/ampr/backport"   "$P" '/api/ampr/backport'
confere "pagina: textos pt/en/es"           "$P" 'bkp_tit: "🧩 ampr-emu-ng en los backports"'
para

echo "--- pagina"
inicia
P=$(curl -s $L/payloads)
confere "pagina: secao do ampr-emu-ng"      "$P" 'class="ampr"'
confere "pagina: rota /api/ampr"            "$P" '/api/ampr/enviar'
confere "pagina: textos pt/en/es"           "$P" 'ampr_tit: "🧪 ampr-emu-ng runtime"'
para

echo "--- 0.9.58: listas por jogo do ShadowKraken (ampr_add.txt e playgo_off.txt)"
inicia
lb() { curl -s "$L/api/ampr/backports"; }
lst() { post -d "lista=$1" --data-urlencode "titulo=$2" -d "acao=$3" "$R/api/ampr/lista"; }
confere "listas vazias no JSON"             "$(lb)" '"listas":{"ampr_add":\[\],"playgo_off":\[\]}'
confere "sem token = 401"                   "$(curl -s -o /dev/null -w '%{http_code}' -H 'X-GLR: 1' -d lista=ampr_add -d titulo=PPSA13427 -d acao=por $R/api/ampr/lista)" "401"
confere "pelo PS5 = 403"                    "$(curl -s -o /dev/null -w '%{http_code}' -A "$UA_PS5" -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" -d lista=ampr_add -d titulo=PPSA13427 -d acao=por $R/api/ampr/lista)" "403"
confere "lista invalida = 400"              "$(lst outra PPSA13427 por)" '"chave":"ampr_lista_acao"'
confere "acao invalida = 400"               "$(lst ampr_add PPSA13427 apagar)" '"chave":"ampr_lista_acao"'
confere "codigo invalido = 400"             "$(lst ampr_add PPSA1342 por)" '"chave":"ampr_lista_titulo"'
confere "codigo com barra = 400"            "$(lst ampr_add '../../x' por)" '"chave":"ampr_lista_titulo"'
echo PPSA13427 > "$T/abertos"
confere "jogo aberto = 409"                 "$(lst ampr_add PPSA13427 por)" '"chave":"ampr_jogo_aberto"'
rm -f "$T/abertos"
confere "por HZD (minusculo vira maiusculo)" "$(lst ampr_add ppsa13427 por)" '"ok":true,"lista":"ampr_add","titulo":"PPSA13427","acao":"por","mudou":true'
confere "arquivo do ShadowKraken"           "$(grep -v '^#' $M/shadowmount/ampr_add.txt)" '^PPSA13427$'
nao_tem "sem .tmp"                          "$(ls -a $M/shadowmount)" 'glibren.tmp'
confere "por de novo = mudou false"         "$(lst ampr_add PPSA13427 por)" '"mudou":false'
confere "playgo_off Dirt 5"                 "$(lst playgo_off PPSA01552 por)" '"listas":{"ampr_add":\["PPSA13427"\],"playgo_off":\["PPSA01552"\]}'
printf '# feito a mao\n  PPSA00001 # comentario\nlixo\nPPSA13427\n' > $M/shadowmount/ampr_add.txt
confere "le como o ShadowKraken (sem repetir)" "$(lb)" '"ampr_add":\["PPSA00001","PPSA13427"\]'
confere "tirar HZD"                         "$(lst ampr_add PPSA13427 tirar)" '"mudou":true,"listas":{"ampr_add":\["PPSA00001"\]'
confere "arquivo sem o HZD"                 "$(grep -v '^#' $M/shadowmount/ampr_add.txt)" '^PPSA00001$'
confere "tirar de novo = mudou false"       "$(lst ampr_add PPSA13427 tirar)" '"mudou":false'
confere "diario"                            "$(cat $DADOS/glibren.log)" 'ampr-lista: playgo_off + PPSA01552'
P=$(curl -s $L/payloads)
confere "pagina: bloco das listas"          "$P" 'class="bkp lst"'
confere "pagina: rota /api/ampr/lista"      "$P" '/api/ampr/lista'
confere "pagina: textos pt/en/es"           "$P" 'lst_tit: "📋 Ajustes por juego de ShadowKraken"'
para

rm -rf "$T"
echo "=== $ok ok, $falhas falhas"
[ $falhas -eq 0 ]
