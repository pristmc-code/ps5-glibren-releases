#!/bin/bash
# Testa as cheats na versao de PC: Fase 0 (leitura) e Fase 1 (ligar/desligar). O "jogo" e o testes/cheat_alvo.c
# compilado como eboot.bin; o glibren-pc acha o processo pelo nome, a base pelo /proc/<pid>/maps, le por
# /proc/<pid>/mem em O_RDONLY e, so no modo de teste, grava por /proc/<pid>/mem em O_RDWR.
# Confere: parser .json, escolha do arquivo pela versao exata (PS5 e PS4), pastas do catalogo e do onionHEN, leitura
# (desligada, ligada, nao bate, area extra), resumo por tipo de trecho (a 0.9.17 contava a area extra duas vezes:
# "5 de 9"), pagina e API recusadas no navegador do PS5, Host estranho, download do catalogo, simbolos do cheats.o
# do PS5 (kernel_proc_copyin/copyout; nada de ptrace/mprotect/mdbg), e a escrita: ligar e desligar com a memoria
# voltando identica, recusa quando os bytes nao batem, nao suportadas, desfazer parcial, cheat sobreposta, pid
# mudou (perdidas, nada gravado), restaurar ao sair (SIGTERM e /api/sair), retomar depois de SIGKILL, rota sem token
# (401), sem X-GLR (403), de 127.0.0.1 (403) e do navegador do PS5 (403).
# 0.9.25: chave "Area extra (teste)" (POST /api/cheats/area-extra): 401 sem pareamento, 403 sem X-GLR/127.0.0.1/PS5,
# liga e desliga gravando o config.ini (persiste depois de reiniciar) e recusa desligar com cheat de area extra ligada.
# Fase 2: .shn, .mc4 (codificado) e .xml (Illusion) com prioridade json > shn > mc4 > xml e arquivo repetido fora,
# leitura, escrita so nos formatos com on/off (.shn/.mc4) com o mesmo motor, .xml so leitura, padrao (mask) achado,
# ambiguo e ausente, codigo inicial (StartUP) e dependencia de area extra, "area extra" (opcao de teste) numa pagina
# r-x do alvo com ordem area->salto e volta identica, simbolos (so dl_get_list/dl_get_info_2 de syscall; nada de
# ptrace/mmap/mprotect) e, se houver, os arquivos REAIS do HEN-Cheats-Collection e do Illusion (testes/cheats_reais.py).
# 0.9.26: .xml com escrita (padrao unico liga/desliga e a memoria volta identica; ambiguo/ausente recusados; originais
# guardados em aplicadas.json com "fonte":"xml"; sobreposicao; processo mudado = perdida), mask_jump32 so com a area
# extra (teste) e area valida, e area extra "--x" (so execucao) contada como "nao da para ligar" no resumo.
# 0.9.40: area extra que o jogo nao tem, reservada pelo MemDBG (servidor falso testes/memdbg_falso.py na porta 8786):
# HELLO/PING, ALLOC na dica + PROTECT rwx, area pelo MEMORY_WRITE, reserva compartilhada, FREE, recusas, sem MemDBG.
#   wsl -d Ubuntu-24.04 -u root -- flock /tmp/ps5-testes.lock bash testes/teste_cheats.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
# PORTA_ZIP era 8792, a mesma porta do glibren do teste_tarefas.sh (suites em paralelo brigavam por ela)
PORTA=8791; PORTA_ZIP=8789
IP=$(hostname -I | awk '{print $1}')
U="http://127.0.0.1:$PORTA"; RD="http://$IP:$PORTA"
T=/root/glr-cheats-teste; DADOS=$T/dados
UA_PS5='Mozilla/5.0 (PlayStation; PlayStation 5/12.00) AppleWebKit/605.1.15 (KHTML, like Gecko)'
UA_CEL='Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Mobile Safari/537.36'
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [${2:0:400}] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: tem [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
# valor de um caminho no JSON (python): jq "$R" 'd["arquivos"][0]["mods"][0]["estado"]'
jq() { echo "$1" | python3 -I -c "import json,sys; d=json.load(sys.stdin); print($2)" 2>&1; }
codigo() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
# esperar por condicao, nao por tempo (sob carga, sleep fixo nao basta)
espera_http() { for i in $(seq 1 150); do curl -s -o /dev/null -m 2 "$1" && return 0; sleep 0.1; done; echo "AVISO: $1 nao respondeu"; }
espera_info() { for i in $(seq 1 100); do [ -s "$1" ] && return 0; sleep 0.1; done; echo "AVISO: $1 nao apareceu"; }
api() { curl -s -A "$UA_CEL" "$U/api/cheats"; }
# estado de uma cheat pelo nome: estado "Vida infinita"
estado() { jq "$R" "[m['estado'] for a in d['arquivos'] for m in a['mods'] if m['nome']=='$1'][0]"; }
campo() { jq "$R" "[m['$2'] for a in d['arquivos'] for m in a['mods'] if m['nome']=='$1'][0]"; }
# bytes da area de teste do alvo (128), lidos direto do /proc/<pid>/mem: area PID OFF
area() { python3 -I - "$1" "$2" <<'PY'
import sys
pid, off = int(sys.argv[1]), int(sys.argv[2], 16)
base = None
for l in open(f"/proc/{pid}/maps"):
    if l.rstrip().endswith("/eboot.bin"):
        base = int(l.split("-")[0], 16); break
with open(f"/proc/{pid}/mem", "rb") as f:
    f.seek(base + off); print(f.read(128).hex().upper())
PY
}

rm -rf "$T"; mkdir -p "$DADOS" "$T/appmeta/PPSA01234" "$T/appmeta/CUSA00001" "$T/catalogo/json" "$T/onion" "$T/zip"
printf 'language = pt-BR\n' > "$DADOS/config.ini"

echo "--- alvo de teste (o 'jogo')"
clang-18 -O0 -o "$T/eboot.bin" "$ORIGEM/testes/cheat_alvo.c" || { echo "FALHA nao compilou o alvo"; exit 1; }
"$T/eboot.bin" "$T/alvo.info" & ALVO=$!
espera_info "$T/alvo.info"
read -r PID_ALVO OFF OFFCAVE OFFPAD OFFX < "$T/alvo.info"
confere "alvo rodando"                 "$PID_ALVO" "$ALVO"
echo "$PID_ALVO" > "$T/pid"
h() { printf '%X' $((16#$OFF + $1)); }   # offset da area + n, em hex
# grava bytes no alvo (simula outro programa mexendo no jogo): grava PID OFF HEX
grava() { python3 -I - "$1" "$2" "$3" <<'PY'
import sys
pid, off, dados = int(sys.argv[1]), int(sys.argv[2], 16), bytes.fromhex(sys.argv[3])
base = None
for l in open(f"/proc/{pid}/maps"):
    if l.rstrip().endswith("/eboot.bin"):
        base = int(l.split("-")[0], 16); break
with open(f"/proc/{pid}/mem", "r+b") as f:
    f.seek(base + off); f.write(dados)
PY
}
# 64 bytes da area extra (r-x) do alvo: cave PID OFFCAVE
cave() { python3 -I - "$1" "$2" <<'PY'
import sys
pid, off = int(sys.argv[1]), int(sys.argv[2], 16)
base = None
for l in open(f"/proc/{pid}/maps"):
    if l.rstrip().endswith("/eboot.bin"):
        base = int(l.split("-")[0], 16); break
with open(f"/proc/{pid}/mem", "rb") as f:
    f.seek(base + off); print(f.read(64).hex().upper())
PY
}
AREA0=$(area $PID_ALVO $OFF)
confere "area inicial"                 "$AREA0" "^C680CC00000000"

echo "--- jogo instalado (param.json / param.sfo)"
cat > "$T/appmeta/PPSA01234/param.json" <<JSON
{"titleId":"PPSA01234","contentVersion":"01.000.002","masterVersion":"01.00",
 "localizedParameters":{"defaultLanguage":"en-US","en-US":{"titleName":"Jogo de Teste"},"pt-BR":{"titleName":"Jogo de Teste BR"}}}
JSON
python3 -I - "$T/appmeta/CUSA00001/param.sfo" <<'PY'
import struct, sys
itens = [("APP_VER", "01.07"), ("TITLE", "Jogo PS4"), ("TITLE_ID", "CUSA00001"), ("VERSION", "01.00")]
chaves = b""; dados = b""; tabela = b""
for k, v in itens:
    vb = v.encode() + b"\0"
    tabela += struct.pack("<HHIII", len(chaves), 0x0204, len(vb), len(vb), len(dados))
    chaves += k.encode() + b"\0"; dados += vb
ini_chaves = 0x14 + len(tabela)
while len(chaves) % 4: chaves += b"\0"
cab = b"\0PSF" + struct.pack("<IIII", 0x101, ini_chaves, ini_chaves + len(chaves), len(itens))
open(sys.argv[1], "wb").write(cab + tabela + chaves + dados)
PY

echo "--- arquivos de cheat"
# catalogo (HEN-Cheats-Collection): o certo, versao errada e um JSON quebrado
ARQ=PPSA01234_01.000.002_aaaaaaaa.json
cat > "$T/catalogo/json/$ARQ" <<JSON
{
  "name": "Jogo de Teste", "id": "PPSA01234", "version": "01.000.002", "process": "eboot.bin",
  "mods": [
    {"name": "Vida infinita", "description": "nao perde vida", "type": "checkbox",
     "memory": [{"offset": "$(h 0)", "on": "90909090909090", "off": "C680CC00000000"}]},
    {"name": "Dinheiro", "description": "", "type": "checkbox",
     "memory": [{"offset": "7FFFFFFF000", "on": "F048014708C74708", "off": "0000000000000000"},
                {"offset": "$(h 16)", "on": "E98E26A57C", "off": "F048014708"}]},
    {"name": "Nao bate", "description": "", "type": "checkbox",
     "memory": [{"offset": "$(h 32)", "on": "9090909090", "off": "1122334455"}]},
    {"name": "Secao 1", "type": "checkbox", "memory": [{"offset": "10", "on": "90", "off": "00", "section": 1}]},
    {"name": "Hex ruim", "type": "checkbox", "memory": [{"offset": "zz", "on": "9", "off": "00"}]},
    {"name": "Cave legivel", "type": "checkbox",
     "memory": [{"offset": "$(h 56)", "on": "41BE0F2700004401", "off": "0000000000000000"}]},
    {"name": "Tres trechos", "type": "checkbox",
     "memory": [{"offset": "$(h 64)", "on": "A1A2A3A4", "off": "11223344"},
                {"offset": "$(h 72)", "on": "B1B2B3B4", "off": "55667788"},
                {"offset": "$(h 80)", "on": "C1C2C3", "off": "AABBCC"}]},
    {"name": "Meio errado", "type": "checkbox",
     "memory": [{"offset": "$(h 88)", "on": "909090", "off": "0F1E2D"},
                {"offset": "$(h 32)", "on": "9090909090", "off": "1122334455"}]},
    {"name": "Sobreposta", "type": "checkbox", "memory": [{"offset": "$(h 2)", "on": "EEEE", "off": "CC00"}]},
    {"name": "Absoluto", "type": "checkbox", "memory": [{"offset": "10", "on": "90", "off": "01", "absolute": true}]},
    {"name": "Sem off", "type": "checkbox", "memory": [{"offset": "$(h 96)", "on": "90"}]}
  ],
  "credits": ["Autor A", "Autor B"]
}
JSON
echo '{"name":"versao errada","version":"01.000.001","process":"eboot.bin","mods":[{"name":"Nao deve aparecer","memory":[]}]}' \
  > "$T/catalogo/json/PPSA01234_01.000.001_bbbbbbbb.json"
echo '{"name": "quebrado", "mods": [ {"name": "x", }' > "$T/catalogo/json/PPSA01234_01.000.002_dddddddd.json"
echo '{"name":"prefixo parecido","mods":[{"name":"Nao deve aparecer 2","memory":[]}]}' > "$T/catalogo/json/PPSA01234_01.000.0021.json"
# onionHEN: nomes em outra caixa, offset com 0x, hex com espacos
cat > "$T/onion/PPSA01234_01.000.002.json" <<JSON
{"Name": "Jogo de Teste (onion)", "Version": "01.000.002", "Process": "eboot.bin",
 "Mods": [{"Name": "Hex com espacos", "Type": "checkbox", "Memory": [{"Offset": "0x$(h 48)", "On": "AA BB", "Off": "de ad"}]}],
 "Authors": ["Autor C"]}
JSON
# PS4
cat > "$T/catalogo/json/CUSA00001_01.07_eeeeeeee.json" <<JSON
{"name":"Jogo PS4","id":"CUSA00001","version":"01.07","process":"eboot.bin",
 "mods":[{"name":"Municao","type":"checkbox","memory":[{"offset":"$(h 0)","on":"90909090909090","off":"C680CC00000000"}]}]}
JSON
echo '{"name":"PS4 versao base","mods":[{"name":"Nao deve aparecer 3","memory":[]}]}' > "$T/catalogo/json/CUSA00001_01.00_ffffffff.json"

: > "$T/abertos"
inicia() { env GLR_TESTE_ABERTOS="$T/abertos" GLR_TESTE_APPMETA="$T/appmeta" GLR_TESTE_CHEATS="$T/catalogo" GLR_TESTE_ONION="$T/onion" GLR_TESTE_CHEATS_PID="$T/pid" \
  GLR_TESTE_BASE="http://127.0.0.1:$PORTA_ZIP/" GLR_TESTE_CHEATS_URL="http://127.0.0.1:$PORTA_ZIP/catalogo.zip" "$@" \
  "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; espera_http "$U/nada"; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
inicia

echo "--- recusa no navegador do PS5 e Host estranho"
confere "PS5: pagina recusada"         "$(codigo -A "$UA_PS5" $U/cheats)" "403"
confere "PS5: api recusada"            "$(codigo -A "$UA_PS5" $U/api/cheats)" "403"
confere "PS5 (caixa baixa): recusada"  "$(codigo -A 'mozilla playstation 5' $U/api/cheats)" "403"
confere "PS5: mensagem"                "$(curl -s -A "$UA_PS5" $U/cheats)" "so para o celular ou o PC"
confere "PS5: catalogo recusado"       "$(codigo -A "$UA_PS5" -X POST -H 'X-GLR: 1' $U/api/cheats/catalogo)" "403"
confere "Host estranho recusado"       "$(codigo -A "$UA_CEL" -H 'Host: ataque.example.com' $U/api/cheats)" "403"
confere "celular: pagina"              "$(curl -s -A "$UA_CEL" $U/cheats)" "Cheats do jogo"
PAGINA=$(curl -s -A "$UA_CEL" $U/cheats)
confere "pagina: aviso de banimento"   "$PAGINA" "banir a conta na PSN"
confere "pagina: salve o jogo antes"   "$PAGINA" "Salve o jogo antes"
confere "pagina: interruptor"          "$PAGINA" 'role="switch"'
confere "pagina: textos da fase 2"     "$PAGINA" 's_padrao_ambiguo: "padrão encontrado mais de uma vez'
confere "pagina: area extra (en/es)"   "$(echo "$PAGINA" | grep -c 's_area_extra_nao_exec')" "^3$"
confere "pagina: dependencia (3 idiomas)" "$(echo "$PAGINA" | grep -c 'cheats_dependente')" "^3$"
nao_tem "pagina: sem o selo so leitura" "$PAGINA" 'somente: "só leitura"\|legenda-somente'   # o selo da 0.9.17 (a fase 2 usa "só leitura" so no motivo do .xml)
confere "pagina: JOGOS primeiro"       "$(echo "$PAGINA" | grep -o '<nav class="atalhos"><a href="/" id="tVoltar">')" 'tVoltar'

echo "--- rotas de escrita: X-GLR, pareamento, 127.0.0.1 e navegador do PS5"
CORPO0="{\"tid\":\"PPSA01234\",\"versao\":\"01.000.002\",\"arquivo\":\"$ARQ\",\"indice\":0}"
confere "POST /api/cheats = 404"       "$(codigo -A "$UA_CEL" -X POST -H 'X-GLR: 1' $U/api/cheats)" "404"
confere "PUT /api/cheats = 405"        "$(codigo -A "$UA_CEL" -X PUT -H 'X-GLR: 1' $U/api/cheats)" "405"
for r in escrever aplicar gravar; do
  confere "POST /api/cheats/$r = 404"  "$(codigo -A "$UA_CEL" -X POST -H 'X-GLR: 1' $U/api/cheats/$r)" "404"
done
confere "catalogo sem X-GLR = 403"     "$(codigo -A "$UA_CEL" -X POST $U/api/cheats/catalogo)" "403"
confere "ligar sem X-GLR = 403"        "$(codigo -A "$UA_CEL" -d "$CORPO0" $RD/api/cheats/ligar)" "403"
confere "ligar sem token = 401"        "$(codigo -A "$UA_CEL" -H 'X-GLR: 1' -d "$CORPO0" $RD/api/cheats/ligar)" "401"
confere "ligar sem token: pareamento"  "$(curl -s -A "$UA_CEL" -H 'X-GLR: 1' -d "$CORPO0" $RD/api/cheats/ligar)" "parear_necessario"
confere "desligar sem token = 401"     "$(codigo -A "$UA_CEL" -H 'X-GLR: 1' -d "$CORPO0" $RD/api/cheats/desligar)" "401"
confere "token errado = 401"           "$(codigo -A "$UA_CEL" -H 'X-GLR: 1' -H "X-GLR-Token: $(printf '0%.0s' $(seq 64))" -d "$CORPO0" $RD/api/cheats/ligar)" "401"
confere "PS5 (127.0.0.1) ligar = 403"  "$(codigo -A "$UA_PS5" -H 'X-GLR: 1' -d "$CORPO0" $U/api/cheats/ligar)" "403"
confere "127.0.0.1 ligar = 403"        "$(codigo -A "$UA_CEL" -H 'X-GLR: 1' -d "$CORPO0" $U/api/cheats/ligar)" "403"
confere "127.0.0.1 desligar = 403"     "$(codigo -A "$UA_CEL" -H 'X-GLR: 1' -d "$CORPO0" $U/api/cheats/desligar)" "403"
confere "nada gravado ate aqui"        "$(area $PID_ALVO $OFF)" "^$AREA0$"
# pareamento pela rede (o codigo vai para a "notificacao", que no PC sai no log)
N_COD=$(grep -c 'pareamento [0-9]\{6\}' "$T/glr.log")
curl -s -H 'X-GLR: 1' -X POST $RD/api/parear/pedir > /dev/null
for i in $(seq 1 100); do [ "$(grep -c 'pareamento [0-9]\{6\}' "$T/glr.log")" -gt "$N_COD" ] && break; sleep 0.1; done
C=$(grep -o 'pareamento [0-9]\{6\}' "$T/glr.log" | tail -1 | awk '{print $2}')
TOKEN=$(curl -s -H 'X-GLR: 1' -d codigo=$C -d nome=teste $RD/api/parear | python3 -I -c 'import json,sys; print(json.load(sys.stdin).get("token",""))')
confere "pareado"                      "$TOKEN" "^[0-9a-f]\{64\}$"
confere "PS5 pela rede com token = 403" "$(codigo -A "$UA_PS5" -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" -d "$CORPO0" $RD/api/cheats/ligar)" "403"
acao() { curl -s -A "$UA_CEL" -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" -d "$2" "$RD/api/cheats/$1"; }
corpo() { echo "{\"tid\":\"${3:-PPSA01234}\",\"versao\":\"01.000.002\",\"arquivo\":\"${2:-$ARQ}\",\"indice\":$1}"; }
lig() { acao ligar "$(corpo "$@")"; }
des() { acao desligar "$(corpo "$@")"; }

echo "--- simbolos: escrita so por kernel_proc_copyin (PS5) e /proc/<pid>/mem so no PC"
SEM_COMENT=$(sed -e 's://.*$::' "$ORIGEM/src/cheats.c" | perl -0pe 's:/\*.*?\*/::gs')
nao_tem "cheats.c sem ptrace/mdbg"     "$SEM_COMENT" "ptrace\|mdbg_\|pt_attach\|pt_mmap\|pt_syscall\|mprotect\|set_vmem\|mmap("
# syscall direto so para LER a lista de modulos (dl_get_list 0x217 e dl_get_info_2 0x2cd)
confere "cheats.c: syscalls so dl_get_*" "$(echo "$SEM_COMENT" | grep -o 'syscall([A-Za-z_0-9]*' | sort -u | tr '\n' ' ')" "^syscall(SYS_DL_GET_INFO_2 syscall(SYS_DL_GET_LIST $"
confere "cheats.c: numeros das syscalls" "$(echo "$SEM_COMENT" | grep '#define SYS_DL_GET' | tr '\n' ' ')" "SYS_DL_GET_LIST 0x217 .*SYS_DL_GET_INFO_2 0x2cd"
confere "cheats.c escreve por copyin"  "$SEM_COMENT" "kernel_proc_copyin(pid"
# O_RDWR so dentro do bloco de PC (#else ... #endif)
RDWR_PS5=$(echo "$SEM_COMENT" | awk '/^#ifdef __PROSPERO__/{d=1} /^#else/{d=0} /^#endif/{d=0} d' | grep -c 'O_RDWR')
confere "O_RDWR fora do codigo do PS5" "$RDWR_PS5" "^0$"
if [ -x /opt/ps5-payload-sdk/bin/prospero-clang ]; then
  (cd "$ORIGEM" && /opt/ps5-payload-sdk/bin/prospero-clang -Wall -Werror -O2 -Isrc -Ibuild -c src/cheats.c -o "$T/cheats.o" 2>&1)
  IMPORTA=$(/opt/ps5-payload-sdk/bin/llvm-nm -u "$T/cheats.o" 2>/dev/null)
  confere "PS5: cheats.o importa a leitura" "$IMPORTA" "kernel_proc_copyout"
  confere "PS5: cheats.o importa a escrita" "$IMPORTA" "kernel_proc_copyin"
  nao_tem "PS5: sem ptrace/mprotect/mdbg"   "$IMPORTA" "mdbg\|ptrace\|setlong\|setint\|setchar\|setshort\|mprotect\|set_vmem\|mmap"
  confere "PS5: protecao so por leitura"    "$IMPORTA" "kernel_get_vmem_protection"
else
  echo "PULADO sem o SDK do PS5 (conferencia do cheats.o)"
fi

echo "--- nenhum jogo aberto"
R=$(api)
confere "menu: tipo"                   "$R" '"tipo":"menu"'
confere "menu: nenhum arquivo"         "$R" '"arquivos":\[\]'
confere "escrita na fase 1"            "$R" '"somente_leitura":false,"escrita":true'
confere "ligar sem jogo: recusa"       "$(lig 0)" "cheats_jogo_mudou"

echo "--- jogo de PS5: escolha do arquivo e leitura"
echo PPSA01234 > "$T/abertos"
R=$(api)
confere "versao do param.json"         "$(jq "$R" "d['jogo']['versao'], d['jogo']['versao_de'], d['jogo']['mestre']")" "01.000.002 contentVersion 01.00"
confere "nome do jogo"                 "$R" '"nome":"Jogo de Teste BR"'
confere "arquivos escolhidos"          "$(jq "$R" "[a['arquivo'] for a in d['arquivos']]")" "\['PPSA01234_01.000.002.json', 'PPSA01234_01.000.002_aaaaaaaa.json', 'PPSA01234_01.000.002_dddddddd.json'\]"
confere "origens"                      "$(jq "$R" "[a['origem'] for a in d['arquivos']]")" "\['onionhen', 'catalogo', 'catalogo'\]"
nao_tem "versao errada fora"           "$R" "Nao deve aparecer"
confere "JSON quebrado: erro"          "$(jq "$R" "d['arquivos'][2].get('erro','')")" "esperava"
confere "processo achado"              "$(jq "$R" "d['processos'][0]")" "'pid': $PID_ALVO, 'nome': 'eboot.bin'"
confere "versao confere no arquivo"    "$(jq "$R" "d['arquivos'][1]['versao_confere']")" "True"
confere "creditos"                     "$(jq "$R" "d['arquivos'][1]['creditos']")" "Autor A"
confere "creditos (Authors)"           "$(jq "$R" "d['arquivos'][0]['creditos']")" "Autor C"
confere "Vida infinita: desligada"     "$(estado 'Vida infinita')" "^desligado$"
confere "Vida infinita: suportada"     "$(campo 'Vida infinita' suporte)" "^$"
confere "Vida infinita: indice"        "$(campo 'Vida infinita' indice)" "^0$"
confere "Vida infinita: bytes lidos"   "$(jq "$R" "d['arquivos'][1]['mods'][0]['trechos'][0]['lido']")" "^C680CC00000000$"
confere "Dinheiro: nao suportada"      "$(estado 'Dinheiro'), $(campo 'Dinheiro' suporte)" "^nao_suportada, area_extra$"
confere "Dinheiro: trecho cave"        "$(jq "$R" "d['arquivos'][1]['mods'][1]['trechos'][0]['estado'], d['arquivos'][1]['mods'][1]['trechos'][0]['tipo']")" "^cave area_extra$"
confere "Dinheiro: 2o trecho"          "$(jq "$R" "d['arquivos'][1]['mods'][1]['trechos'][1]['estado']")" "^desligado$"
confere "Nao bate: diferente"          "$(estado 'Nao bate')" "^diferente$"
confere "Nao bate: lido"               "$(jq "$R" "d['arquivos'][1]['mods'][2]['trechos'][0]['lido']")" "^9999999999$"
confere "secao != 0"                   "$(jq "$R" "d['arquivos'][1]['mods'][3]['trechos'][0]['estado']"), $(campo 'Secao 1' suporte)" "^secao, secao$"
confere "hex invalido"                 "$(jq "$R" "d['arquivos'][1]['mods'][4]['trechos'][0]['estado']"), $(campo 'Hex ruim' suporte)" "^invalido, invalido$"
confere "cave legivel (zeros)"         "$(jq "$R" "d['arquivos'][1]['mods'][5]['trechos'][0]['estado']"), $(campo 'Cave legivel' suporte)" "^cave, area_extra$"
confere "Tres trechos: desligada"      "$(estado 'Tres trechos')" "^desligado$"
confere "Meio errado: diferente"       "$(estado 'Meio errado')" "^diferente$"
confere "Absoluto: nao suportada"      "$(campo 'Absoluto' suporte)" "^absoluto$"
confere "Sem off: nao suportada"       "$(campo 'Sem off' suporte), $(jq "$R" "d['arquivos'][1]['mods'][10]['trechos'][0]['estado']")" "^sem_off, sem_off$"
confere "onion: chaves em outra caixa" "$(estado 'Hex com espacos')" "^desligado$"
# resumo por tipo: 18 trechos; as 2 areas extras (uma legivel, como no Terminator 2D) NAO entram nos conferiveis
confere "resumo: tipos"                "$(jq "$R" "[d['resumo'][k] for k in ('trechos','normais','caves','secao','absolutos','sem_off','invalidos')]")" "^\[16, 10, 2, 1, 1, 1, 1\]$"
confere "resumo: conferiveis/lidos"    "$(jq "$R" "[d['resumo'][k] for k in ('conferiveis','lidos','desligados','ligados','diferentes','erros')]")" "^\[12, 11, 8, 0, 2, 1\]$"
confere "resumo: cheats"               "$(jq "$R" "d['resumo']['suportadas'], d['resumo']['nao_suportadas']")" "^6 6$"
confere "base do eboot"                "$(jq "$R" "d['arquivos'][1]['base']")" "^0x"
confere "diario: resumo"               "$(cat $DADOS/glibren.log)" "cheats: ps5 PPSA01234 v01.000.002 (contentVersion): 3 arquivo(s) (json 3, shn 0, mc4 0, xml 0), 1 processo(s) primeiro eboot.bin; 16 trecho(s): 12 conferiveis"
confere "leitura nao mudou nada"       "$(area $PID_ALVO $OFF)" "^$AREA0$"

echo "--- ligar e desligar: a memoria volta identica"
RESP=$(lig 0)
confere "ligar Vida infinita"          "$RESP" '"ok":true,"estado":"ligado","nome":"Vida infinita","trechos":1'
confere "memoria: on gravado"          "$(area $PID_ALVO $OFF)" "^90909090909090"
R=$(api)
confere "estado: ligada pelo glibren"  "$(estado 'Vida infinita'), $(campo 'Vida infinita' aplicada)" "^ligado, True$"
confere "lista de aplicadas"           "$(jq "$R" "d['aplicadas']")" "'nome': 'Vida infinita'"
confere "resumo: 1 aplicada"           "$(jq "$R" "d['resumo']['aplicadas']")" "^1$"
AP=$(cat "$T/catalogo/aplicadas.json")
confere "aplicadas.json: jogo"         "$(jq "$AP" "d['pid'], d['app_id'], d['tid'], d['versao']")" "^$PID_ALVO -1 PPSA01234 01.000.002$"
confere "aplicadas.json: original"     "$(jq "$AP" "d['cheats'][0]['trechos'][0]['original'], d['cheats'][0]['trechos'][0]['on']")" "^C680CC00000000 90909090909090$"
confere "aplicadas.json: endereco"     "$(jq "$AP" "d['cheats'][0]['trechos'][0]['endereco']")" "^0x"
confere "ligar de novo: ja ligada"     "$(lig 0)" "cheats_ja_ligada"
confere "diario: ligou"                "$(cat $DADOS/glibren.log)" "cheats: ligou Vida infinita em PPSA01234 (pid $PID_ALVO, 1 trecho(s); leitura de volta OK)"
confere "diario: trecho"               "$(cat $DADOS/glibren.log)" "trecho 1 0x[0-9a-f]*: C680CC00000000 -> 90909090909090: lido de volta ok"
RESP=$(des 0)
confere "desligar Vida infinita"       "$RESP" '"ok":true,"estado":"desligado"'
confere "memoria identica"             "$(area $PID_ALVO $OFF)" "^$AREA0$"
confere "aplicadas.json vazio"         "$(jq "$(cat "$T/catalogo/aplicadas.json")" "d['cheats']")" "^\[\]$"
confere "diario: desligou"             "$(cat $DADOS/glibren.log)" "cheats: desligou Vida infinita em PPSA01234 (pid $PID_ALVO, 1 trecho(s); leitura de volta OK)"
confere "desligar de novo: nao ligada" "$(des 0)" "cheats_nao_ligada"
# 3 trechos + pedido por formulario
RESP=$(acao ligar "tid=PPSA01234&versao=01.000.002&arquivo=$ARQ&indice=6")
confere "ligar Tres trechos (form)"    "$RESP" '"ok":true,"estado":"ligado","nome":"Tres trechos","trechos":3'
confere "Tres trechos: on"             "$(area $PID_ALVO $OFF | cut -c129-176)" "^A1A2A3A400000000B1B2B3B400000000C1C2C3"
confere "desligar Tres trechos"        "$(des 6)" '"ok":true'
confere "memoria identica (3 trechos)" "$(area $PID_ALVO $OFF)" "^$AREA0$"

echo "--- recusas: bytes nao batem, nao suportadas, sobreposta, pedido invalido"
RESP=$(lig 2)
confere "Nao bate: recusa"             "$RESP" '"chave":"cheats_nao_bate"'
confere "Nao bate: motivo"             "$(jq "$RESP" "d['params']['trecho'], d['params']['lido'], d['params']['esperado']")" "^1 9999999999 1122334455$"
RESP=$(lig 7)
confere "Meio errado: recusa trecho 2" "$(jq "$RESP" "d['chave'], d['params']['trecho']")" "^cheats_nao_bate 2$"
confere "Meio errado: nada gravado"    "$(area $PID_ALVO $OFF)" "^$AREA0$"
for par in "1 area_extra" "3 secao" "4 invalido" "5 area_extra" "9 absoluto" "10 sem_off"; do
  set -- $par
  confere "nao suportada: indice $1 ($2)" "$(jq "$(lig $1)" "d['chave'], d['params']['motivo']")" "^cheats_nao_suportada $2$"
done
confere "nao suportadas: nada gravado" "$(area $PID_ALVO $OFF)" "^$AREA0$"
confere "diario: recusa com motivo"    "$(cat $DADOS/glibren.log)" "cheats: ligar Nao bate em PPSA01234 recusado: trecho 1 (0x[0-9a-f]*) tem 9999999999, o desligado do arquivo e 1122334455"
lig 0 > /dev/null
confere "sobreposta: recusa"           "$(lig 8)" '"chave":"cheats_sobreposta","erro":"mexe nos mesmos bytes de outra cheat ligada","params":{"nome":"Vida infinita"}'
des 0 > /dev/null
confere "sobreposta: memoria identica" "$(area $PID_ALVO $OFF)" "^$AREA0$"
confere "indice inexistente"           "$(lig 50)" "cheats_indice"
confere "arquivo com ..: 400"          "$(codigo -A "$UA_CEL" -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" -d "$(corpo 0 '../aplicadas.json')" $RD/api/cheats/ligar)" "400"
confere "arquivo de outro jogo"        "$(lig 0 CUSA00001_01.07_eeeeeeee.json)" "cheats_arquivo"
confere "tid diferente do aberto"      "$(lig 0 $ARQ PPSA09999)" "cheats_jogo_mudou"
confere "indice invalido: 400"         "$(codigo -A "$UA_CEL" -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" -d 'tid=PPSA01234&versao=01.000.002&arquivo=x.json&indice=-1' $RD/api/cheats/ligar)" "400"

echo "--- desfazer parcial (o 2o de 3 trechos falha)"
END2=$(jq "$(api)" "d['arquivos'][1]['mods'][6]['trechos'][1]['endereco']")
para
inicia GLR_TESTE_CHEATS_FALHAR="$END2"
RESP=$(lig 6)
confere "falha no trecho 2"            "$(jq "$RESP" "d['chave'], d['params']['trecho'], d['params']['desfeito']")" "^cheats_escrita 2 True$"
confere "desfeito: memoria identica"   "$(area $PID_ALVO $OFF)" "^$AREA0$"
confere "desfeito: nada registrado"    "$(jq "$(cat "$T/catalogo/aplicadas.json")" "d['cheats']")" "^\[\]$"
confere "desfeito: diario"             "$(cat $DADOS/glibren.log)" "cheats: ligar Tres trechos em PPSA01234 falhou no trecho 2 (0x[0-9a-f]*); desfeito: OK (jogo como antes)"
confere "desfeito: trecho 1 voltou"    "$(cat $DADOS/glibren.log)" "desfazer trecho 1 0x[0-9a-f]* -> 11223344: ok"
confere "estado depois do desfazer"    "$(R=$(api); estado 'Tres trechos')" "^desligado$"
para

echo "--- restaurar ao fechar: SIGTERM"
inicia
lig 0 > /dev/null; lig 6 > /dev/null
confere "duas ligadas"                 "$(jq "$(api)" "d['resumo']['aplicadas']")" "^2$"
nao_tem "memoria mudou"                "$(area $PID_ALVO $OFF)" "^$AREA0$"
kill -TERM $PID; wait $PID 2>/dev/null
confere "SIGTERM: memoria identica"    "$(area $PID_ALVO $OFF)" "^$AREA0$"
confere "SIGTERM: diario"              "$(cat $DADOS/glibren.log)" "cheats: desligou Vida infinita em PPSA01234 (pid $PID_ALVO, 1 trecho(s); leitura de volta OK) ao fechar o glibren"
confere "SIGTERM: encerrando"          "$(cat $DADOS/glibren.log)" "encerrando (SIGTERM)"
confere "SIGTERM: registro vazio"      "$(jq "$(cat "$T/catalogo/aplicadas.json")" "d['cheats']")" "^\[\]$"

echo "--- restaurar ao fechar: /api/sair (com o token)"
inicia
lig 0 > /dev/null
confere "ligada antes do sair"         "$(area $PID_ALVO $OFF)" "^90909090909090"
confere "sair"                         "$(curl -s -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" -X POST $RD/api/sair)" '"ok":true'
for i in $(seq 1 50); do kill -0 $PID 2>/dev/null || break; sleep 0.1; done
wait $PID 2>/dev/null
confere "sair: memoria identica"       "$(area $PID_ALVO $OFF)" "^$AREA0$"

echo "--- glibren morto com SIGKILL: a nova copia retoma as ligadas (mesmo pid) e desliga"
inicia
lig 0 > /dev/null
kill -KILL $PID; wait $PID 2>/dev/null
confere "SIGKILL: continua ligada"     "$(area $PID_ALVO $OFF)" "^90909090909090"
inicia
R=$(api)
confere "retomou a ligada"             "$(campo 'Vida infinita' aplicada)" "^True$"
confere "retomou: diario"              "$(cat $DADOS/glibren.log)" "1 cheat(s) ligada(s) de antes (PPSA01234 pid $PID_ALVO"
confere "desligar depois de retomar"   "$(des 0)" '"ok":true'
confere "retomou: memoria identica"    "$(area $PID_ALVO $OFF)" "^$AREA0$"

echo "--- outra ferramenta liga a cheat (o proprio alvo grava)"
kill -USR1 $ALVO; for i in $(seq 1 100); do area $PID_ALVO $OFF | grep -q '^90909090909090' && break; sleep 0.1; done
R=$(api)
confere "Vida infinita: ligada (fora)" "$(estado 'Vida infinita'), $(campo 'Vida infinita' aplicada)" "^ligado, False$"
confere "resumo: 1 ligado"             "$(jq "$R" "d['resumo']['ligados']")" "^1$"
confere "ligar: ja ligada por fora"    "$(lig 0)" "cheats_ligada_fora"
confere "desligar: nao foi o glibren"  "$(des 0)" "cheats_nao_ligada"
confere "nada mudou (continua on)"     "$(area $PID_ALVO $OFF)" "^90909090909090"
para

echo "--- o jogo mudou (outro pid): as ligadas viram perdidas e nada e gravado"
"$T/eboot.bin" "$T/alvo2.info" & ALVO2=$!
espera_info "$T/alvo2.info"
read -r PID2 OFF2 _ _ < "$T/alvo2.info"
echo "$PID2" > "$T/pid"
inicia
AREA2=$(area $PID2 $OFF2)
confere "ligar no jogo 2"              "$(lig 0)" '"ok":true'
AREA2_ON=$(area $PID2 $OFF2)
confere "jogo 2: on"                   "$AREA2_ON" "^90909090909090"
echo "$PID_ALVO" > "$T/pid"            # "outro jogo" (outro pid) aberto
confere "desligar com o pid mudado"    "$(des 0)" "cheats_perdida"
confere "jogo 2: nada gravado"         "$(area $PID2 $OFF2)" "^$AREA2_ON$"
confere "perdidas: diario"             "$(cat $DADOS/glibren.log)" "cheats: o jogo mudou (PPSA01234 pid $PID2 app -1 -> PPSA01234 pid $PID_ALVO app -1): 1 cheat(s) ligada(s) perdida(s), nada foi gravado: Vida infinita"
R=$(api)
confere "perdidas na API"              "$(jq "$R" "d['perdidas']['nomes'], d['resumo']['aplicadas']")" "^Vida infinita 0$"
confere "perdidas: registro vazio"     "$(jq "$(cat "$T/catalogo/aplicadas.json")" "d['cheats']")" "^\[\]$"
echo "$PID2" > "$T/pid"; lig 0 > /dev/null 2>&1   # ja esta on no jogo 2: recusa (por fora)
para
confere "sair: jogo 2 intacto"         "$(area $PID2 $OFF2)" "^$AREA2_ON$"
# jogo fechou (nenhum aberto): tambem vira perdida
kill $ALVO2 2>/dev/null; wait $ALVO2 2>/dev/null
echo "$PID_ALVO" > "$T/pid"
kill -KILL $ALVO 2>/dev/null; wait $ALVO 2>/dev/null
rm -f "$T/alvo.info"
"$T/eboot.bin" "$T/alvo.info" & ALVO=$!
espera_info "$T/alvo.info"
read -r PID_ALVO OFF OFFCAVE OFFPAD OFFX < "$T/alvo.info"
echo "$PID_ALVO" > "$T/pid"
inicia
lig 0 > /dev/null
: > "$T/abertos"
R=$(api)
confere "jogo fechou: perdida"         "$(jq "$R" "d['perdidas']['nomes']")" "^Vida infinita$"
para
confere "jogo fechou: nada restaurado" "$(area $PID_ALVO $OFF)" "^90909090909090"
echo PPSA01234 > "$T/abertos"
kill -KILL $ALVO 2>/dev/null; wait $ALVO 2>/dev/null
rm -f "$T/alvo.info"
"$T/eboot.bin" "$T/alvo.info" & ALVO=$!
espera_info "$T/alvo.info"
read -r PID_ALVO OFF OFFCAVE OFFPAD OFFX < "$T/alvo.info"
echo "$PID_ALVO" > "$T/pid"
kill -USR1 $ALVO; for i in $(seq 1 100); do area $PID_ALVO $OFF | grep -q '^90909090909090' && break; sleep 0.1; done
inicia


echo "--- Fase 2: .shn, .mc4 e .xml (Illusion), prioridade e arquivo repetido"
AREA_F2=$(area $PID_ALVO $OFF)
CAVE0=$(cave $PID_ALVO $OFFCAVE)
confere "alvo: area extra r-x zerada"  "$CAVE0" "^0\{128\}$"
mkdir -p "$T/catalogo/shn" "$T/catalogo/mc4"
SHN=PPSA01234_01.000.002_bbbb0001.shn
cat > "$T/catalogo/shn/$SHN" <<XML
<?xml version="1.0" encoding="utf-8"?>
<Trainer xmlns:xsd="http://www.w3.org/2001/XMLSchema" Game="Jogo de Teste" Moder="Autor SHN" Cusa="PPSA01234" Version="01.000.002" Process="eboot.bin">
  <Genres Name="Teste" />
  <Items />
  <Cheat Text="SHN municao &amp; vida" Description="do .shn" Control="Toggel">
    <Cheatline>
      <Offset>$(h 124)</Offset>
      <Section>0</Section>
      <ValueOn>90-90-90-90</ValueOn>
      <ValueOff>81-82-83-84</ValueOff>
    </Cheatline>
  </Cheat>
  <Cheat Text="SHN secao"><Cheatline><Offset>10</Offset><Section>3</Section><ValueOn>90</ValueOn><ValueOff>01</ValueOff></Cheatline></Cheat>
</Trainer>
XML
# .mc4 = o mesmo XML em Base64 de AES-256-CBC (chave/IV publicos do GoldHEN Cheat Manager), padding PKCS#7
mc4() { python3 -I - "$1" "$2" <<'PY'
import base64, sys
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
d = open(sys.argv[1], "rb").read(); p = 16 - len(d) % 16; d += bytes([p]) * p
e = Cipher(algorithms.AES(b"304c6528f659c766110239a51cl5dd9c"), modes.CBC(b"u@}kzW2u[u(8DWar")).encryptor()
open(sys.argv[2], "wb").write(base64.b64encode(e.update(d) + e.finalize()))
PY
}
cat > "$T/mc4.xml" <<XML
<?xml version="1.0" encoding="utf-8"?>
<Trainer Game="Jogo de Teste" Moder="Autor MC4" Cusa="PPSA01234" Version="01.000.002" Process="eboot.bin">
  <StartUP Text="MC inicial" description=""><Cheatline><Offset>$(h 112)</Offset><Section>0</Section><ValueOn>51-52-53-54</ValueOn><ValueOff>61-62-63-64</ValueOff></Cheatline></StartUP>
  <Cheat Text="MC comum"><Cheatline><Offset>$(h 120)</Offset><Section>0</Section><ValueOn>99-99</ValueOn><ValueOff>71-72</ValueOff></Cheatline></Cheat>
</Trainer>
XML
MC4=PPSA01234_01.000.002_cccc0001.mc4
mc4 "$T/mc4.xml" "$T/catalogo/mc4/$MC4"
mc4 "$T/catalogo/shn/$SHN" "$T/catalogo/mc4/PPSA01234_01.000.002_dddd0002.mc4"   # as mesmas cheats do .shn
echo 'isto nao e base64 !!' > "$T/onion/PPSA01234_01.000.002_eeee0003.mc4"
confere "mc4 codificado (nao e texto)"  "$(head -c 20 "$T/catalogo/mc4/$MC4")" "^[A-Za-z0-9+/]\{20\}$"
# .json com area extra de verdade (na pagina r-x do alvo) e uma cheat que salta para ela
CAVEJ=PPSA01234_01.000.002_ffff0004.json
REL=$(python3 -I -c "a = int('$OFF', 16) + 106; c = int('$OFFCAVE', 16); print(((c - (a + 5)) & 0xffffffff).to_bytes(4, 'little').hex().upper())")
cat > "$T/catalogo/json/$CAVEJ" <<JSON
{"name":"Jogo de Teste","version":"01.000.002","process":"eboot.bin","mods":[
 {"name":"Cave executavel","memory":[{"offset":"$(printf '%X' $((16#$OFFCAVE)))","on":"B801000000C3","off":"000000000000"},
                                    {"offset":"$(h 100)","on":"9090909090","off":"3132333435"}]},
 {"name":"Usa a cave","memory":[{"offset":"$(h 106)","on":"E9$REL","off":"4142434445"}]}],
 "credits":["Autor Cave"]}
JSON
# .xml do Illusion (no onionHEN): direto, padrao unico, ambiguo, ausente e outra versao
cat > "$T/onion/PPSA01234.xml" <<XML
<?xml version="1.0" encoding="UTF-8"?>
<Patch>
  <TitleID><ID>CUSA99999</ID><ID>PPSA01234</ID></TitleID>
  <Metadata Title="Jogo de Teste" Name="XML direto" Author="Autor XML" PatchVer="1.0" AppVer="01.000.002" AppElf="eboot.bin" ImageBase="0x0">
    <PatchList><Line Type="bytes" Address="0x$(h 16)" Value="F0480147"/><Line Type="bytes32" Address="0x$(h 24)" Value="0x0"/></PatchList>
  </Metadata>
  <Metadata Name="XML padrao" AppVer="mask" AppElf="eboot.bin">
    <PatchList><Line Type="mask" Address="A5 5A ?? 3C 7E E7 81 18" Value="1122" Offset= "+8"/></PatchList>
  </Metadata>
  <Metadata Name="XML ambiguo" AppVer="01.000.001, 01.000.002" AppElf="eboot.bin">
    <PatchList><Line Type="mask" Address="B66BD44D" Value="90"/></PatchList>
  </Metadata>
  <Metadata Name="XML ausente" AppVer="mask" AppElf="eboot.bin">
    <PatchList><Line><Type>mask</Type><Address>F1 E2 D3 C4 B5 A6 97 88</Address><Value>90</Value></Line></PatchList>
  </Metadata>
  <Metadata Name="Outra versao" AppVer="09.999.999" AppElf="eboot.bin">
    <PatchList><Line Type="bytes" Address="0x10" Value="90"/></PatchList>
  </Metadata>
  <Metadata Name="XML troca" AppVer="mask" AppElf="eboot.bin" ImageBase="0x0">
    <PatchList><Line Type="mask" Address="A5 5A ?? 3C 7E E7 81 18" Value="3344" Offset="+8"/><Line Type="bytes" Address="0x$(printf '%X' $((16#$OFFPAD + 48)))" Value="CAFE"/></PatchList>
  </Metadata>
  <Metadata Name="XML salto" AppVer="mask" AppElf="eboot.bin">
    <PatchList><Line Type="mask_jump32" Address="A5 5A ?? 3C 7E E7 81 18" Value="9090" Target="DE AD" Size="5"/></PatchList>
  </Metadata>
</Patch>
XML
R=$(api)
confere "prioridade json > shn > mc4 > xml" "$(jq "$R" "[a['arquivo'] for a in d['arquivos']]")" "\['PPSA01234_01.000.002.json', 'PPSA01234_01.000.002_aaaaaaaa.json', 'PPSA01234_01.000.002_dddddddd.json', 'PPSA01234_01.000.002_ffff0004.json', 'PPSA01234_01.000.002_bbbb0001.shn', 'PPSA01234_01.000.002_eeee0003.mc4', 'PPSA01234_01.000.002_cccc0001.mc4', 'PPSA01234.xml'\]"
confere "formatos"                     "$(jq "$R" "[a['formato'] for a in d['arquivos']], d['formatos']")" "\['json', 'json', 'json', 'json', 'shn', 'mc4', 'mc4', 'xml'\] {'json': 4, 'shn': 1, 'mc4': 2, 'xml': 1}"
confere "mc4 repetido do shn: fora"    "$(jq "$R" "d['ignorados']")" "\[{'arquivo': 'PPSA01234_01.000.002_dddd0002.mc4', 'formato': 'mc4', 'motivo': 'igual', 'igual_a': 'PPSA01234_01.000.002_bbbb0001.shn'}\]"
confere "mc4 invalido: erro"           "$(jq "$R" "[a.get('erro') for a in d['arquivos'] if a['arquivo'].endswith('eeee0003.mc4')][0]")" "^mc4: Base64 invalido$"
confere "area extra (teste) desligada" "$(jq "$R" "d['area_extra_teste'], d['fase']")" "^False 2$"
confere "shn: nome com entidade"       "$(jq "$R" "[(m['nome'], m['descricao'], m['estado'], m['suporte']) for a in d['arquivos'] if a['formato'] == 'shn' for m in a['mods']]")" "('SHN municao & vida', 'do .shn', 'desligado', ''), ('SHN secao', '', 'nao_suportada', 'secao')"
confere "shn: creditos (Moder)"        "$(jq "$R" "[a['creditos'] for a in d['arquivos'] if a['formato'] == 'shn'][0]")" "^\['Autor SHN'\]$"
confere "shn: trecho lido"             "$(jq "$R" "[m['trechos'][0].get('lido') for a in d['arquivos'] if a['formato'] == 'shn' for m in a['mods']]")" "^\['81828384', None\]$"
confere "mc4: codigo inicial"          "$(jq "$R" "[(m['nome'], m['inicial'], m['suporte'], m.get('depende', '')) for a in d['arquivos'] if a['arquivo'] == '$MC4' for m in a['mods']]")" "\[('MC inicial', True, '', ''), ('MC comum', False, 'precisa_inicial', 'MC inicial')\]"
confere "mc4: arquivo com codigo inicial" "$(jq "$R" "[a['codigo_inicial'] for a in d['arquivos'] if a['arquivo'] == '$MC4'][0]")" "^True$"
confere "cave: nao suportada (opcao off)" "$(jq "$R" "[(m['nome'], m['suporte'], m.get('depende', '')) for a in d['arquivos'] if a['arquivo'] == '$CAVEJ' for m in a['mods']]")" "\[('Cave executavel', 'area_extra', ''), ('Usa a cave', 'depende', 'Cave executavel')\]"
XMLR=$(jq "$R" "[(m['nome'], m['suporte'], m['leitura'], [x['estado'] for x in m['trechos']]) for a in d['arquivos'] if a['formato'] == 'xml' for m in a['mods']]")
confere "xml: so os patches desta versao" "$XMLR" "^\[('XML direto', '', 'ligado', \['ligado', 'ligado'\]), ('XML padrao', '', 'ligado', \['ligado'\]), ('XML ambiguo', 'padrao_ambiguo', 'sem_leitura', \['padrao_ambiguo'\]), ('XML ausente', 'padrao_ausente', 'sem_leitura', \['padrao_ausente'\]), ('XML troca', '', 'sem_leitura', \['sem_off', 'sem_off'\]), ('XML salto', 'area_extra', "
BASE_ALVO=$(jq "$R" "d['arquivos'][1]['base']")
confere "xml: padrao achado no lugar certo" "$(jq "$R" "[m['trechos'][0]['endereco'] for a in d['arquivos'] if a['formato'] == 'xml' for m in a['mods'] if m['nome'] == 'XML padrao'][0]")" "^$(printf '0x%x' $((BASE_ALVO + 16#$OFFPAD + 8)))$"
confere "xml: padrao com ??"           "$(jq "$R" "[m['trechos'][0]['padrao'] for a in d['arquivos'] if a['formato'] == 'xml' for m in a['mods'] if m['nome'] == 'XML padrao'][0]")" "^A55A??3C7EE78118$"
confere "resumo: padroes"              "$(jq "$R" "d['resumo']['padroes']")" "^5$"
confere "diario: padrao achado"        "$(cat $DADOS/glibren.log)" "cheats: padrao A55A??3C7EE78118 em eboot.bin (pid $PID_ALVO): achado em 0x"
confere "diario: padrao ambiguo"       "$(cat $DADOS/glibren.log)" "cheats: padrao B66BD44D em eboot.bin (pid $PID_ALVO): ambiguo"
confere "diario: faixas do modulo"     "$(cat $DADOS/glibren.log)" "cheats: faixas de eboot.bin (pid $PID_ALVO, base 0x[0-9a-f]*): maps .*/r-x"
confere "leitura nao mudou nada (f2)"  "$(area $PID_ALVO $OFF) $(cave $PID_ALVO $OFFCAVE)" "^$AREA_F2 $CAVE0$"

echo "--- Fase 2: escrita (.json/.shn/.mc4) e, na 0.9.26, .xml com os originais guardados"
confere "xml direto: ja ligado (recusa)" "$(jq "$(lig 0 PPSA01234.xml)" "d['chave']")" "^cheats_ligada_fora$"
confere "xml ambiguo: recusado"        "$(jq "$(lig 2 PPSA01234.xml)" "d['chave'], d['params']['motivo']")" "^cheats_nao_suportada padrao_ambiguo$"
confere "xml ausente: recusado"        "$(jq "$(lig 3 PPSA01234.xml)" "d['chave'], d['params']['motivo']")" "^cheats_nao_suportada padrao_ausente$"
confere "xml salto: area extra off"    "$(jq "$(lig 5 PPSA01234.xml)" "d['params']['motivo']")" "^area_extra$"
PAD0=$(area $PID_ALVO $OFFPAD)
confere "xml ambiguo/ausente: nada mudou" "$PAD0" "^A55AC33C7EE781181122"
confere "xml troca: ligar"             "$(lig 4 PPSA01234.xml)" '"ok":true,"estado":"ligado","nome":"XML troca","trechos":2'
PAD1=$(area $PID_ALVO $OFFPAD)
confere "xml troca: padrao +8 gravado" "$(echo "$PAD1" | cut -c17-20) $(echo "$PAD1" | cut -c97-100)" "^3344 CAFE$"
confere "xml troca: originais guardados" "$(jq "$(cat "$T/catalogo/aplicadas.json")" "[(c['nome'], c.get('fonte'), [(x['original'], x['on'], x['off']) for x in c['trechos']]) for c in d['cheats']]")" "^\[('XML troca', 'xml', \[('1122', '3344', '1122'), ('0000', 'CAFE', '0000')\])\]$"
confere "xml troca: estado ligado"     "$(jq "$(api)" "[(m['estado'], m['aplicada'], m['suporte']) for a in d['arquivos'] if a['formato'] == 'xml' for m in a['mods'] if m['nome'] == 'XML troca'][0]")" "^('ligado', True, '')$"
confere "xml: sobreposta recusada"     "$(jq "$(lig 1 PPSA01234.xml)" "d['chave'], d['params']['nome']")" "^cheats_sobreposta XML troca$"
confere "xml troca: diario"            "$(cat $DADOS/glibren.log)" "cheats:   trecho 1 0x[0-9a-f]*: 1122 -> 3344: lido de volta ok"
confere "xml troca: desligar"          "$(des 4 PPSA01234.xml)" '"ok":true,"estado":"desligado","nome":"XML troca"'
confere "xml troca: memoria identica"  "$(area $PID_ALVO $OFFPAD)" "^$PAD0$"
confere "xml troca: registro vazio"    "$(jq "$(cat "$T/catalogo/aplicadas.json")" "d['cheats']")" "^\[\]$"
# .xml com o processo mudado: liga no jogo 3, troca o pid, desligar = perdida e nada gravado em nenhum dos dois
"$T/eboot.bin" "$T/alvo3.info" & ALVO3=$!
espera_info "$T/alvo3.info"
read -r PID3 _ _ OFFPAD3 _ < "$T/alvo3.info"
echo "$PID3" > "$T/pid"
confere "xml jogo 3: ligar"            "$(lig 4 PPSA01234.xml)" '"ok":true'
PAD3=$(area $PID3 $OFFPAD3)
echo "$PID_ALVO" > "$T/pid"
confere "xml pid mudou: perdida"       "$(jq "$(des 4 PPSA01234.xml)" "d['chave']")" "^cheats_perdida$"
confere "xml pid mudou: jogo 3 intacto" "$(area $PID3 $OFFPAD3)" "^$PAD3$"
confere "xml pid mudou: jogo 1 intacto" "$(area $PID_ALVO $OFFPAD)" "^$PAD0$"
confere "xml pid mudou: diario"        "$(cat $DADOS/glibren.log)" "pid $PID3 app -1 -> PPSA01234 pid $PID_ALVO app -1): 1 cheat(s) ligada(s) perdida(s), nada foi gravado: XML troca"
kill $ALVO3 2>/dev/null; wait $ALVO3 2>/dev/null
confere "xml troca: ligar de novo"     "$(lig 4 PPSA01234.xml)" '"ok":true'
para
confere "xml: restaurado ao fechar"    "$(area $PID_ALVO $OFFPAD)" "^$PAD0$"
inicia
confere "mc4 invalido: arquivo"        "$(jq "$(lig 0 PPSA01234_01.000.002_eeee0003.mc4)" "d['chave']")" "^cheats_indice$"
confere "shn: ligar"                   "$(lig 0 $SHN)" '"ok":true,"estado":"ligado","nome":"SHN municao & vida","trechos":1'
confere "shn: on gravado"              "$(area $PID_ALVO $OFF | cut -c249-256)" "^90909090$"
confere "shn: estado ligado"           "$(jq "$(api)" "[(m['estado'], m['aplicada']) for a in d['arquivos'] if a['formato'] == 'shn' for m in a['mods']][0]")" "^('ligado', True)$"
confere "shn: desligar"                "$(des 0 $SHN)" '"ok":true,"estado":"desligado"'
confere "shn: memoria identica"        "$(area $PID_ALVO $OFF)" "^$AREA_F2$"
confere "mc4: comum sem o inicial"     "$(jq "$(lig 1 $MC4)" "d['chave'], d['params']['motivo'], d['params']['nome']")" "^cheats_nao_suportada precisa_inicial MC inicial$"
confere "mc4: ligar o inicial"         "$(lig 0 $MC4)" '"ok":true'
confere "mc4: ligar o comum"           "$(lig 1 $MC4)" '"ok":true'
confere "mc4: bytes ligados"           "$(area $PID_ALVO $OFF | cut -c225-244)" "^51525354000000009999$"
confere "mc4: inicial nao desliga antes" "$(jq "$(des 0 $MC4)" "d['chave'], d['params']['nome']")" "^cheats_dependente MC comum$"
confere "aplicadas.json: inicial"      "$(jq "$(cat "$T/catalogo/aplicadas.json")" "[(c['nome'], c['inicial']) for c in d['cheats']]")" "\[('MC inicial', True), ('MC comum', False)\]"
des 1 $MC4 > /dev/null
confere "mc4: desligar o inicial"      "$(des 0 $MC4)" '"ok":true'
confere "mc4: memoria identica"        "$(area $PID_ALVO $OFF)" "^$AREA_F2$"
confere "cave: ligar recusado (off)"   "$(jq "$(lig 0 $CAVEJ)" "d['params']['motivo']")" "^area_extra$"
confere "nada na area extra"           "$(cave $PID_ALVO $OFFCAVE)" "^$CAVE0$"
para

echo "--- 0.9.25: chave da area extra pela pagina (POST /api/cheats/area-extra)"
inicia
ae() { curl -s -A "$UA_CEL" -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" -d "$1" "$RD/api/cheats/area-extra"; }
confere "pagina: chave da area extra"  "$(curl -s -A "$UA_CEL" $U/cheats)" 'id="bArea"'
confere "pagina: texto da chave (3)"   "$(curl -s -A "$UA_CEL" $U/cheats | grep -c 'ae_texto: ')" "^3$"
confere "pagina: em uso (3 idiomas)"   "$(curl -s -A "$UA_CEL" $U/cheats | grep -c 'cheats_area_extra_em_uso')" "^3$"
confere "area-extra sem token = 401"   "$(codigo -A "$UA_CEL" -H 'X-GLR: 1' -d '{"ligado":true}' $RD/api/cheats/area-extra)" "401"
confere "area-extra sem token: parear" "$(curl -s -A "$UA_CEL" -H 'X-GLR: 1' -d '{"ligado":true}' $RD/api/cheats/area-extra)" "parear_necessario"
confere "area-extra sem X-GLR = 403"   "$(codigo -A "$UA_CEL" -H "X-GLR-Token: $TOKEN" -d '{"ligado":true}' $RD/api/cheats/area-extra)" "403"
confere "area-extra GET = 404/405"     "$(codigo -A "$UA_CEL" $RD/api/cheats/area-extra)" "40[45]"
confere "area-extra 127.0.0.1 = 403"   "$(codigo -A "$UA_CEL" -H 'X-GLR: 1' -d '{"ligado":true}' $U/api/cheats/area-extra)" "403"
confere "area-extra PS5 c/ token = 403" "$(codigo -A "$UA_PS5" -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" -d '{"ligado":true}' $RD/api/cheats/area-extra)" "403"
confere "area-extra corpo ruim = 400"  "$(codigo -A "$UA_CEL" -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" -d '{"ligado":"talvez"}' $RD/api/cheats/area-extra)" "400"
nao_tem "recusas nao gravaram"         "$(cat "$DADOS/config.ini")" "cheats_area_extra"
confere "area-extra: ligar"            "$(ae '{"ligado":true}')" '^{"ok":true,"ligado":true}$'
confere "config.ini: on"               "$(grep -c '^cheats_area_extra = on$' "$DADOS/config.ini")" "^1$"
confere "config.ini: sem .tmp"         "$(ls "$DADOS")" "config.ini"
nao_tem "config.ini: sem .tmp (2)"     "$(ls "$DADOS")" "config.ini.tmp"
confere "config.ini: resto mantido"    "$(cat "$DADOS/config.ini")" "^paired = "
confere "area-extra: GET informa"      "$(jq "$(api)" "d['area_extra_teste']")" "^True$"
confere "area-extra: ligar de novo"    "$(ae 'ligado=1')" '"ok":true,"ligado":true'
confere "config.ini: uma linha so"     "$(grep -c 'cheats_area_extra' "$DADOS/config.ini")" "^1$"
confere "diario: ligada pela pagina"   "$(cat $DADOS/glibren.log)" "cheats: area extra (teste) LIGADA pela pagina Cheats"
para
inicia
confere "area-extra: persiste (on)"    "$(jq "$(api)" "d['area_extra_teste']")" "^True$"
confere "area-extra: desligar"         "$(ae '{"ligado":false}')" '^{"ok":true,"ligado":false}$'
nao_tem "config.ini: linha saiu"       "$(cat "$DADOS/config.ini")" "cheats_area_extra"
para
inicia
confere "area-extra: persiste (off)"   "$(jq "$(api)" "d['area_extra_teste']")" "^False$"
confere "area-extra: ligar p/ a fase 2" "$(ae '{"ligado":true}')" '"ok":true,"ligado":true'
para

echo "--- Fase 2: area extra (opcao de teste cheats_area_extra = on)"
SOX=PPSA01234_01.000.002_99990005.json
cat > "$T/catalogo/json/$SOX" <<JSON
{"name":"Jogo de Teste","id":"PPSA01234","version":"01.000.002","process":"eboot.bin",
 "mods":[{"name":"Cave so exec","type":"checkbox","memory":[{"offset":"$OFFX","on":"B802000000C3","off":"000000000000"},
                                    {"offset":"$(h 0)","on":"90","off":"90"}]}]}
JSON
inicia
R=$(api)
# 0.9.26 recusava area extra "--x" (Terminator 2D no PS5 real); 0.9.32: liga como o onionHEN se a leitura pelo
# kernel da area der os zeros (no PC o /proc/<pid>/mem tambem ignora a protecao de usuario)
confere "--x: da para ligar (0.9.32)"  "$(campo 'Cave so exec' estado), $(campo 'Cave so exec' suporte)" "^desligado, $"
confere "--x: protecao lida"           "$(jq "$R" "[m['trechos'][0].get('prot') for a in d['arquivos'] if a['arquivo'] == '$SOX' for m in a['mods']][0]")" "^--x$"
confere "--x: resumo conta como nao"   "$(jq "$R" "d['resumo']['suportadas'] == sum(1 for a in d['arquivos'] for m in a['mods'] if m['estado'] != 'nao_suportada'), d['resumo']['nao_suportadas'] == sum(1 for a in d['arquivos'] for m in a['mods'] if m['estado'] == 'nao_suportada')")" "^True True$"
confere "--x: ligar"                   "$(lig 0 $SOX)" '"ok":true,"estado":"ligado","nome":"Cave so exec"'
confere "--x: area gravada"            "$(cave $PID_ALVO $OFFX)" "^B802000000C30000"
# 0.9.53: ligada pelo glibren continua "ligada" ao recarregar (antes: nao_suportada area_extra_nao_zerada, caso do MARVEL Cosmic Invasion)
R=$(api)
confere "--x ligada: recarregar = ligada" "$(campo 'Cave so exec' estado), $(campo 'Cave so exec' suporte), $(campo 'Cave so exec' aplicada)" "^ligado, , True$"
confere "--x ligada: resumo sem nao_suportada" "$(jq "$R" "[m['estado'] for a in d['arquivos'] if a['arquivo'] == '$SOX' for m in a['mods']]")" "^\['ligado'\]$"
confere "--x: ordem area -> trecho"    "$(grep -A2 'cheats: ligando Cave so exec' $DADOS/glibren.log | tail -2 | tr '\n' ' ')" "trecho 1 0x[0-9a-f]*: 000000000000 -> B802000000C3: lido de volta ok .*trecho 2"
confere "--x: desligar"                "$(des 0 $SOX)" '"ok":true,"estado":"desligado"'
confere "--x: zeros de volta"          "$(cave $PID_ALVO $OFFX)" "^$CAVE0$"
# 0.9.53: registro perdido (glibren morto + aplicadas.json apagado): aparece ligada e o botao desliga com o "off" do arquivo
B0=$(area $PID_ALVO $OFF | cut -c1-2)
confere "sem registro: ligar"          "$(lig 0 $SOX)" '"ok":true,"estado":"ligado"'
kill -KILL $PID; wait $PID 2>/dev/null
rm -f "$T/catalogo/aplicadas.json"
inicia
R=$(api)
confere "sem registro: aparece ligada" "$(campo 'Cave so exec' estado), $(campo 'Cave so exec' suporte), $(campo 'Cave so exec' aplicada), $(campo 'Cave so exec' adotavel)" "^ligado, , False, True$"
confere "sem registro: desligar"       "$(des 0 $SOX)" '"ok":true,"estado":"desligado"'
confere "sem registro: zeros de volta" "$(cave $PID_ALVO $OFFX)" "^$CAVE0$"
confere "sem registro: diario"         "$(cat $DADOS/glibren.log)" "Cave so exec em .* estava ligada sem registro do glibren"
confere "sem registro: sem registro sobrando" "$(jq "$(api)" "d['resumo']['aplicadas'], [m['estado'] for a in d['arquivos'] if a['arquivo'] == '$SOX' for m in a['mods']][0]")" "^0 desligado$"
grava $PID_ALVO $(h 0) $B0
# 0.9.53: area extra com conteudo de outro programa: motivo novo, ligar recusado, nada gravado
grava $PID_ALVO $OFFX CCCCCCCCCCCC
R=$(api)
confere "area de terceiro: motivo novo" "$(campo 'Cave so exec' estado), $(campo 'Cave so exec' suporte)" "^nao_suportada, area_extra_em_uso$"
confere "area de terceiro: ligar recusado" "$(jq "$(lig 0 $SOX)" "d['chave'], d['params']['motivo']")" "^cheats_nao_suportada area_extra_em_uso$"
confere "area de terceiro: nada gravado" "$(cave $PID_ALVO $OFFX)" "^CCCCCCCCCCCC0000"
grava $PID_ALVO $OFFX 000000000000
confere "area de terceiro: zerada de novo" "$(cave $PID_ALVO $OFFX)" "^$CAVE0$"
PAGINA=$(curl -s -A "$UA_CEL" $U/cheats)
confere "pagina: em uso (3 idiomas)"   "$(echo "$PAGINA" | grep -o '[ ,{]s_area_extra_em_uso:' | wc -l)" "^3$"
confere "pagina: em uso (pt)"          "$PAGINA" 's_area_extra_em_uso: "a área extra já está em uso por outro programa"'
confere "pagina: ligada fora (3 idiomas)" "$(echo "$PAGINA" | grep -c 's_area_extra_ligada_fora:')" "^3$"
confere "pagina: adotavel (3 idiomas)" "$(echo "$PAGINA" | grep -c 'm_adotavel:')" "^3$"
confere "pagina: adotavel desliga"     "$PAGINA" 'm.adotavel && m.estado === "ligado") ? "desligar"'
confere "--x: linha avisa so execucao" "$(curl -s -A "$UA_CEL" $U/cheats)" 'prots.includes("--x")) motivo = t("m_so_exec_ok")'
# --x que o kernel nao consegue ler = recusa (area_extra_ilegivel), nada gravado
para
inicia GLR_TESTE_CHEATS_FALHAR_LER="$(printf '0x%x' $((BASE_ALVO + 16#$OFFX)))"
R=$(api)
confere "--x ilegivel: recusa"         "$(campo 'Cave so exec' estado), $(campo 'Cave so exec' suporte)" "^nao_suportada, area_extra_ilegivel$"
confere "--x ilegivel: ligar recusado" "$(jq "$(lig 0 $SOX)" "d['chave'], d['params']['motivo']")" "^cheats_nao_suportada area_extra_ilegivel$"
confere "--x ilegivel: nada gravado"   "$(cave $PID_ALVO $OFFX)" "^$CAVE0$"
para
inicia
R=$(api)
PAGINA=$(curl -s -A "$UA_CEL" $U/cheats)
confere "pagina: --x liga (3 idiomas)" "$(echo "$PAGINA" | grep -c 'm_so_exec_ok:')" "^3$"
confere "pagina: so execucao (pt)"     "$PAGINA" 'm_so_exec: "não dá para ligar: a área do jogo é só execução ({p})"'
confere "pagina: so execucao (3 idiomas)" "$(echo "$PAGINA" | grep -c 'm_so_exec:')" "^3$"
confere "pagina: botao desligado"      "$PAGINA" 'semLeitura = m.suporte === "area_extra_sem_leitura"'
confere "xml salto: area do Target invalida" "$(campo 'XML salto' suporte)" "^area_extra_\|^padrao_"
rm -f "$T/catalogo/json/$SOX"
R=$(api)
confere "area extra: teste ligado"     "$(jq "$R" "d['area_extra_teste']")" "^True$"
confere "cave r-x: suportada"          "$(jq "$R" "[(m['nome'], m['suporte'], m.get('depende', '')) for a in d['arquivos'] if a['arquivo'] == '$CAVEJ' for m in a['mods']]")" "\[('Cave executavel', '', ''), ('Usa a cave', 'depende', 'Cave executavel')\]"
confere "cave r-x: protecao lida"      "$(jq "$R" "[m['trechos'][0].get('prot') for a in d['arquivos'] if a['arquivo'] == '$CAVEJ' for m in a['mods']][0]")" "^r-x$"
confere "cave em pagina rw: recusada"  "$(campo 'Cave legivel' suporte)" "^area_extra_nao_exec$"
confere "Dinheiro: area a criar (0.9.34)" "$(campo 'Dinheiro' suporte)" "^area_extra_criar$"
confere "area a criar: ligar recusado" "$(jq "$(lig 1 $ARQ)" "d['chave'], d['params']['motivo']")" "^cheats_nao_suportada area_extra_criar$"
PAGINA=$(curl -s -A "$UA_CEL" $U/cheats)
confere "pagina: motivo criar (3 idiomas)" "$(echo "$PAGINA" | grep -c 'm_criar:')" "^3$"
confere "pagina: motivo criar (pt)"    "$PAGINA" 'Carregue o MemDBG (página Payloads) ou use o onionHEN para esta cheat.'
confere "pagina: linha usa m_criar"    "$PAGINA" 'm.suporte === "area_extra_criar" ? t("m_criar")'
confere "pagina: ilegivel = existe (pt)" "$PAGINA" 's_area_extra_ilegivel: "a área extra existe, mas a leitura dela falhou"' 
confere "salto antes da cave: recusa"  "$(jq "$(lig 1 $CAVEJ)" "d['params']['motivo'], d['params']['nome']")" "^depende Cave executavel$"
confere "cave: ligar"                  "$(lig 0 $CAVEJ)" '"ok":true,"estado":"ligado","nome":"Cave executavel","trechos":2'
confere "cave: codigo gravado"         "$(cave $PID_ALVO $OFFCAVE)" "^B801000000C30000"
confere "cave: salto gravado"          "$(area $PID_ALVO $OFF | cut -c201-210)" "^9090909090$"
confere "cave: ordem area -> salto"    "$(grep -A2 'cheats: ligando Cave executavel' $DADOS/glibren.log | tail -2 | tr '\n' ' ')" "trecho 1 0x[0-9a-f]*: 000000000000 -> B801000000C3: lido de volta ok .*trecho 2 0x[0-9a-f]*: 3132333435 -> 9090909090"
confere "cave: estado ligado"          "$(jq "$(api)" "[m['estado'] for a in d['arquivos'] if a['arquivo'] == '$CAVEJ' for m in a['mods']][0]")" "^ligado$"
confere "salto: ligar depois da cave"  "$(lig 1 $CAVEJ)" '"ok":true'
confere "cave nao desliga com o salto ligado" "$(jq "$(des 0 $CAVEJ)" "d['chave'], d['params']['nome']")" "^cheats_dependente Usa a cave$"
confere "aplicadas.json: depende"      "$(jq "$(cat "$T/catalogo/aplicadas.json")" "[(c['nome'], c['depende']) for c in d['cheats']]")" "\[('Cave executavel', \[\]), ('Usa a cave', \[0\])\]"
# 0.9.25: desligar a area extra com cheats de area extra ligadas: recusado com os nomes; nada muda (nem o jogo)
ANTES_AE="$(area $PID_ALVO $OFF) $(cave $PID_ALVO $OFFCAVE)"
RESP=$(ae '{"ligado":false}')
confere "area-extra em uso: recusado"  "$(jq "$RESP" "d['ok'], d['chave'], d['params']['qtd']")" "^False cheats_area_extra_em_uso 2$"
confere "area-extra em uso: nomes"     "$(jq "$RESP" "d['params']['nomes']")" "^Cave executavel, Usa a cave$"
confere "area-extra em uso: config fica" "$(grep -c '^cheats_area_extra = on$' "$DADOS/config.ini")" "^1$"
confere "area-extra em uso: GET on"    "$(jq "$(api)" "d['area_extra_teste'], d['resumo']['aplicadas']")" "^True 2$"
confere "area-extra em uso: jogo igual" "$(area $PID_ALVO $OFF) $(cave $PID_ALVO $OFFCAVE)" "^$ANTES_AE$"
confere "diario: em uso"               "$(cat $DADOS/glibren.log)" "desligar a area extra (teste) recusado: 2 cheat(s) de area extra ligada(s): Cave executavel, Usa a cave"
kill -TERM $PID; wait $PID 2>/dev/null
confere "SIGTERM: tudo de volta"       "$(area $PID_ALVO $OFF) $(cave $PID_ALVO $OFFCAVE)" "^$AREA_F2 $CAVE0$"
confere "SIGTERM: salto antes da cave" "$(grep 'cheats: desligou' $DADOS/glibren.log | tail -2 | tr '\n' ' ')" "desligou Usa a cave .*desligou Cave executavel"
END_SALTO=$(printf '0x%x' $((BASE_ALVO + 16#$OFF + 100)))
inicia GLR_TESTE_CHEATS_FALHAR="$END_SALTO"
RESP=$(lig 0 $CAVEJ)
confere "cave: falha no salto"         "$(jq "$RESP" "d['chave'], d['params']['trecho'], d['params']['desfeito']")" "^cheats_escrita 2 True$"
confere "cave: desfeita (zeros)"       "$(area $PID_ALVO $OFF) $(cave $PID_ALVO $OFFCAVE)" "^$AREA_F2 $CAVE0$"
para
inicia
# sem cheats de area extra ligadas (a falha acima desfez tudo): desligar pela chave passa
confere "area-extra: desligar livre"   "$(ae '{"ligado":false}')" '"ok":true,"ligado":false'
para
inicia
confere "area extra: teste desligado"  "$(jq "$(api)" "d['area_extra_teste']")" "^False$"

echo "--- 0.9.40: area extra que o jogo nao tem, criada pelo MemDBG (servidor falso do protocolo MDBG)"
PMD=8786; MD=$T/memdbg; mkdir -p "$MD"
espera_arq() { for i in $(seq 1 150); do [ -e "$1" ] && return 0; sleep 0.1; done; echo "AVISO: $1 nao apareceu"; }
liga_md() { rm -f "$MD/pronto"; (exec python3 -I "$ORIGEM/testes/memdbg_falso.py" $PMD "$MD") >> "$T/memdbg.log" 2>&1 & PID_MD=$!; espera_arq "$MD/pronto"; }
regiao() { python3 -I -c "import json,sys; d=json.load(open('$MD/regioes.json')); a=int(sys.argv[1],16); o=int(sys.argv[2])-a; r=d[hex(a)]; print(r['prot'], r['hex'][2*o:2*o+2*int(sys.argv[3])])" "$@"; }
reg_ap() { jq "$(cat "$T/catalogo/aplicadas.json")" "[(c['nome'], c.get('memdbg')) for c in d['cheats']]"; }
para
inicia GLR_TESTE_MEMDBG_PORTA=$PMD GLR_TESTE_MEMDBG_CACHE_S=0
confere "memdbg: area extra ligada"    "$(ae '{"ligado":true}')" '"ok":true,"ligado":true'
R=$(api)
confere "sem MemDBG: area a criar"     "$(campo 'Dinheiro' suporte)" "^area_extra_criar$"
confere "sem MemDBG: GET informa"      "$(jq "$R" "d['memdbg']['rodando'], d['memdbg']['porta']")" "^False $PMD$"
confere "sem MemDBG: ligar recusado"   "$(jq "$(lig 1 $ARQ)" "d['chave'], d['params']['motivo']")" "^cheats_nao_suportada area_extra_criar$"
liga_md
R=$(api)
confere "MemDBG: rodando (HELLO)"      "$(jq "$R" "d['memdbg']['rodando'], d['memdbg']['versao'], d['memdbg']['nivel'], d['memdbg']['reserva']")" "^True 0.2.0-nightly.321.g6e31144 4 True$"
confere "MemDBG: HELLO com sessao"     "$(head -1 "$MD/log")" "^HELLO sessao$"
confere "MemDBG: sonda fecha (GOODBYE)" "$(sed -n 2p "$MD/log")" "^GOODBYE$"
confere "MemDBG: Dinheiro pode ligar"  "$(campo 'Dinheiro' suporte)|$(campo 'Dinheiro' estado)|$(campo 'Dinheiro' memdbg)" "^|desligado|True$"
confere "MemDBG: trecho a criar"       "$(jq "$R" "[x.get('criar') for a in d['arquivos'] if a['arquivo']=='$ARQ' for m in a['mods'] if m['nome']=='Dinheiro' for x in m['trechos']]")" "^\[True, None\]$"
nao_tem "MemDBG: outras sem memdbg"    "$(jq "$R" "[m['nome'] for a in d['arquivos'] for m in a['mods'] if m.get('memdbg')]")" "Vida"
R2=$(api)
confere "MemDBG: 2a sonda so PING"     "$(tail -2 "$MD/log" | tr '\n' ' ')" "^PING GOODBYE $"
DIN=$((BASE_ALVO + 0x7FFFFFFF000)); A16=$(printf '0x%x' $((DIN & ~0x3FFF))); DINX=$(printf '0x%x' $DIN)
: > "$MD/log"
confere "MemDBG: ligar"                "$(lig 1 $ARQ)" '"ok":true,"estado":"ligado","nome":"Dinheiro","trechos":2'
confere "MemDBG: ALLOC na dica (16 KB)" "$(grep ALLOC "$MD/log")" "^ALLOC pid=$PID_ALVO dica=$A16 tam=0x4000 prot=3 flags=1$"
confere "MemDBG: PROTECT rwx"          "$(grep PROTECT "$MD/log")" "^PROTECT pid=$PID_ALVO end=$A16 tam=0x4000 prot=7$"
confere "MemDBG: area gravada por ele" "$(grep WRITE "$MD/log")" "^WRITE pid=$PID_ALVO end=$DINX n=8 F048014708C74708$"
confere "MemDBG: conferida (READ)"     "$(grep -c "^READ pid=$PID_ALVO end=$DINX n=8" "$MD/log")" "^[2-9]$"
confere "MemDBG: bytes na reserva"     "$(regiao $A16 $DIN 8)" "^7 F048014708C74708$"
confere "MemDBG: salto pelo kernel"    "$(area $PID_ALVO $OFF | cut -c33-42)" "^E98E26A57C$"
nao_tem "MemDBG: salto nao vai por ele" "$(cat "$MD/log")" "n=5 E98E26A57C"
confere "MemDBG: ordem area -> salto"  "$(grep -A2 'cheats: ligando Dinheiro' $DADOS/glibren.log | tail -2 | tr '\n' ' ')" "trecho 1 0x[0-9a-f]*: 0000000000000000 -> F048014708C74708: lido de volta ok .*trecho 2 0x[0-9a-f]*: F048014708 -> E98E26A57C: lido de volta ok"
# um HELLO so no ligar (a sonda com cache 0 do teste usa PING); no PS5 a sonda tem cache de 20 s
confere "MemDBG: uma sessao (1 HELLO)" "$(grep -c '^HELLO' "$MD/log")" "^1$"
confere "registro: reserva guardada"   "$(reg_ap)" "^\[('Dinheiro', \[{'endereco': '$A16', 'tamanho': 16384}\])\]$"
confere "diario: ALLOC"                "$(cat $DADOS/glibren.log)" "cheats: MemDBG: PROCESS_ALLOC pid $PID_ALVO dica $A16 16384 bytes rw-: MEMDBG_OK em $A16"
confere "diario: versao do MemDBG"     "$(cat $DADOS/glibren.log)" "cheats: MemDBG 0.2.0-nightly.321.g6e31144 (nivel 4, capacidades 0x00c0110f) na porta $PMD"
R=$(api)
confere "MemDBG: estado ligado"        "$(campo 'Dinheiro' estado) $(campo 'Dinheiro' aplicada) $(campo 'Dinheiro' suporte)x" "^ligado True x$"
# outra cheat com area na MESMA reserva (Easy Score e 10x Score do Terminator 2D): usa a que ja existe
VIZ=PPSA01234_01.000.002_99990006.json
cat > "$T/catalogo/json/$VIZ" <<JSON
{"name":"Jogo de Teste","id":"PPSA01234","version":"01.000.002","process":"eboot.bin",
 "mods":[{"name":"Area vizinha","type":"checkbox","memory":[{"offset":"7FFFFFFF040","on":"AABB","off":"0000"}]}]}
JSON
R=$(api)
confere "vizinha: usa a reserva"       "$(campo 'Area vizinha' suporte)|$(campo 'Area vizinha' memdbg)" "^|True$"
: > "$MD/log"
confere "vizinha: ligar"               "$(lig 0 $VIZ)" '"ok":true,"estado":"ligado","nome":"Area vizinha"'
nao_tem "vizinha: sem ALLOC novo"      "$(cat "$MD/log")" "ALLOC"
confere "vizinha: gravada por ele"     "$(grep WRITE "$MD/log")" "n=2 AABB$"
: > "$MD/log"
confere "Dinheiro: desligar"           "$(des 1 $ARQ)" '"ok":true,"estado":"desligado","nome":"Dinheiro"'
confere "Dinheiro: salto de volta"     "$(area $PID_ALVO $OFF | cut -c33-42)" "^F048014708$"
confere "Dinheiro: zeros na area"      "$(regiao $A16 $DIN 8)" "^7 0000000000000000$"
nao_tem "Dinheiro: nao libera (em uso)" "$(cat "$MD/log")" "FREE"
confere "diario: reserva passa"        "$(cat $DADOS/glibren.log)" "area do MemDBG $A16 passa para Area vizinha"
confere "registro: reserva da vizinha" "$(reg_ap)" "^\[('Area vizinha', \[{'endereco': '$A16', 'tamanho': 16384}\])\]$"
: > "$MD/log"
confere "vizinha: desligar"            "$(des 0 $VIZ)" '"ok":true,"estado":"desligado"'
confere "vizinha: FREE"                "$(grep FREE "$MD/log")" "^FREE pid=$PID_ALVO end=$A16 tam=0x4000$"
confere "MemDBG: nada reservado"       "$(cat "$MD/regioes.json")" "^{}$"
confere "diario: FREE"                 "$(cat $DADOS/glibren.log)" "cheats: MemDBG: PROCESS_FREE $A16 (16384 bytes, pid $PID_ALVO): ok"
rm -f "$T/catalogo/json/$VIZ"
# ao fechar o glibren (SIGTERM): tira o salto e libera
confere "ligar de novo"                "$(lig 1 $ARQ)" '"ok":true'
: > "$MD/log"
para
confere "SIGTERM: salto de volta"      "$(area $PID_ALVO $OFF)" "^$AREA_F2$"
confere "SIGTERM: FREE"                "$(grep -c '^FREE' "$MD/log")" "^1$"
# glibren caiu (SIGKILL) com a cheat ligada: volta, le a reserva do aplicadas.json e libera ao desligar
inicia GLR_TESTE_MEMDBG_PORTA=$PMD GLR_TESTE_MEMDBG_CACHE_S=0
confere "ligar (antes do SIGKILL)"     "$(lig 1 $ARQ)" '"ok":true'
kill -KILL $PID; wait $PID 2>/dev/null
inicia GLR_TESTE_MEMDBG_PORTA=$PMD GLR_TESTE_MEMDBG_CACHE_S=0
R=$(api)
confere "SIGKILL: retomada ligada"     "$(campo 'Dinheiro' estado) $(campo 'Dinheiro' aplicada)" "^ligado True$"
: > "$MD/log"
confere "SIGKILL: desligar"            "$(des 1 $ARQ)" '"ok":true'
confere "SIGKILL: FREE da reserva lida" "$(grep FREE "$MD/log")" "^FREE pid=$PID_ALVO end=$A16 tam=0x4000$"
confere "SIGKILL: jogo como antes"     "$(area $PID_ALVO $OFF)" "^$AREA_F2$"
# MemDBG fechou com a cheat ligada: desligar ainda tira o salto (a area fica ate o jogo fechar)
confere "ligar (MemDBG vai fechar)"    "$(lig 1 $ARQ)" '"ok":true'
kill $PID_MD; wait $PID_MD 2>/dev/null
confere "MemDBG fechado: desligar"     "$(des 1 $ARQ)" '"ok":true,"estado":"desligado"'
confere "MemDBG fechado: salto de volta" "$(area $PID_ALVO $OFF)" "^$AREA_F2$"
confere "diario: area fica"            "$(cat $DADOS/glibren.log)" "a area fica reservada ate o jogo fechar"
confere "MemDBG fechado: registro vazio" "$(reg_ap)" "^\[\]$"
# recusas do MemDBG: nada gravado no jogo, nada reservado sobrando
liga_md
echo alloc_recusa > "$MD/modo"
confere "ALLOC recusado"               "$(jq "$(lig 1 $ARQ)" "d['chave'], d['params']['motivo'], d['params']['status']")" "^cheats_memdbg reserva_recusada MEMDBG_ERR_IO$"
confere "ALLOC recusado: jogo intacto" "$(area $PID_ALVO $OFF)" "^$AREA_F2$"
confere "ALLOC recusado: sem registro" "$(reg_ap)" "^\[\]$"
echo outro_endereco > "$MD/modo"; : > "$MD/log"
confere "outro endereco: recusa"       "$(jq "$(lig 1 $ARQ)" "d['chave'], d['params']['motivo']")" "^cheats_memdbg reserva_outro_endereco$"
confere "outro endereco: 16 KB e 4 KB" "$(grep -c '^ALLOC' "$MD/log") $(grep -c '^FREE' "$MD/log")" "^2 2$"
confere "outro endereco: nada sobra"   "$(cat "$MD/regioes.json")" "^{}$"
confere "outro endereco: jogo intacto" "$(area $PID_ALVO $OFF)" "^$AREA_F2$"
echo protect_recusa > "$MD/modo"; : > "$MD/log"
confere "PROTECT recusado"             "$(jq "$(lig 1 $ARQ)" "d['params']['motivo'], d['params']['status']")" "^reserva_recusada MEMDBG_ERR_PERMISSION$"
confere "PROTECT recusado: FREE"       "$(grep -c '^FREE' "$MD/log")" "^1$"
echo sem_alloc > "$MD/modo"
# a sonda guarda as capacidades do 1o HELLO (depois so PING); o ligar faz HELLO de novo e ve que nao reserva
confere "sem a capacidade: ligar"      "$(jq "$(lig 1 $ARQ)" "d['chave'], d['params']['motivo']")" "^cheats_memdbg reserva_sem_suporte$"
R=$(api)
confere "sem a capacidade de reservar" "$(campo 'Dinheiro' suporte)" "^reserva_sem_suporte$"
confere "sem a capacidade: GET"        "$(jq "$R" "d['memdbg']['rodando'], d['memdbg']['reserva']")" "^True False$"
rm -f "$MD/modo"
PAGINA=$(curl -s -A "$UA_CEL" $U/cheats)
for k in m_memdbg s_reserva_sem_suporte s_sem_memdbg s_reserva_recusada s_reserva_outro_endereco cheats_memdbg; do
  confere "pagina: $k (3 idiomas)"     "$(echo "$PAGINA" | grep -o "[^a-z_]$k:" | wc -l)" "^3$"
done
confere "pagina: linha do MemDBG"      "$PAGINA" 'if (!motivo && m.memdbg && m.estado !== "nao_suportada") motivo = t("m_memdbg")'
confere "area-extra: desligar"         "$(ae '{"ligado":false}')" '"ok":true,"ligado":false'
kill $PID_MD 2>/dev/null; wait $PID_MD 2>/dev/null
para
# o cliente do MemDBG so fala pelo socket (nada de ptrace/mmap/syscall/kernel no memdbg.c)
MD_SEM_COMENT=$(sed -e 's://.*$::' "$ORIGEM/src/memdbg.c" | perl -0pe 's:/\*.*?\*/::gs')
nao_tem "memdbg.c: so socket"          "$MD_SEM_COMENT" "ptrace\|syscall(\|mmap(\|mprotect\|kernel_\|/proc/"
confere "memdbg.c: so 127.0.0.1"       "$MD_SEM_COMENT" "htonl(INADDR_LOOPBACK)"
if [ -x /opt/ps5-payload-sdk/bin/prospero-clang ]; then
  (cd "$ORIGEM" && /opt/ps5-payload-sdk/bin/prospero-clang -Wall -Werror -O2 -Isrc -Ibuild -c src/memdbg.c -o "$T/memdbg.o" 2>&1)
  IMP_MD=$(/opt/ps5-payload-sdk/bin/llvm-nm -u "$T/memdbg.o" 2>/dev/null)
  confere "PS5: memdbg.o usa socket"     "$IMP_MD" "connect"
  nao_tem "PS5: memdbg.o sem kernel/ptrace" "$IMP_MD" "kernel_\|ptrace\|mdbg\|mmap\|mprotect\|syscall"
else
  echo "PULADO sem o SDK do PS5 (conferencia do memdbg.o)"
fi
inicia

echo "--- modulo que nao existe"
sed -i 's/"process": "eboot.bin"/"process": "mgs4\/mgs4.elf"/' "$T/catalogo/json/$ARQ"
R=$(api)
confere "sem base: processo"           "$(jq "$R" "d['arquivos'][1]['processo']")" "mgs4/mgs4.elf"
confere "outro processo: nao suportada" "$(estado 'Vida infinita'), $(campo 'Vida infinita' suporte)" "^nao_suportada, outro_processo$"
confere "sem base: trecho"             "$(jq "$R" "d['arquivos'][1]['mods'][0]['trechos'][0]['estado'], d['arquivos'][1]['mods'][0]['trechos'][0]['tipo']")" "^sem_base outro_processo$"
confere "outro processo: recusa"       "$(jq "$(lig 0)" "d['params']['motivo']")" "^outro_processo$"

echo "--- jogo de PS4 (param.sfo: maior entre VERSION e APP_VER)"
echo CUSA00001 > "$T/abertos"
R=$(api)
confere "PS4: tipo"                    "$R" '"tipo":"ps4"'
confere "PS4: versao"                  "$(jq "$R" "d['jogo']['versao'], d['jogo']['versao_de']")" "01.07 APP_VER"
confere "PS4: nome"                    "$R" '"nome":"Jogo PS4"'
confere "PS4: arquivo"                 "$(jq "$R" "[a['arquivo'] for a in d['arquivos']]")" "\['CUSA00001_01.07_eeeeeeee.json'\]"
confere "PS4: leitura (ligada pelo alvo)" "$(estado 'Municao')" "^ligado$"

echo "--- jogo sem cheats / sem versao"
echo PPSA09999 > "$T/abertos"
R=$(api)
confere "sem versao"                   "$(jq "$R" "d['jogo']['versao']")" "^$"
confere "sem arquivo"                  "$R" '"arquivos":\[\]'
para

echo "--- download do catalogo (zip local no lugar do GitHub)"
python3 -I - "$T/zip/catalogo.zip" <<'PY'
import sys, zipfile
with zipfile.ZipFile(sys.argv[1], "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("HEN-Cheats-Collection-master/", "")
    z.writestr("HEN-Cheats-Collection-master/cheats/json/PPSA01234_01.000.002_12345678.json",
               '{"name":"Do zip","version":"01.000.002","process":"eboot.bin","mods":[{"name":"Do zip","memory":[]}]}')
    z.writestr("HEN-Cheats-Collection-master/cheats/json/PPSA05344_04.001.000_de306fb7.json", '{"name":"Park Beyond","mods":[]}')
    z.writestr("HEN-Cheats-Collection-master/cheats/shn/PPSA01234_01.000.002.shn", "shn")
    z.writestr("HEN-Cheats-Collection-master/cheats/mc4/PPSA01234_01.000.002_99999999.mc4", "AAAA")
    z.writestr("HEN-Cheats-Collection-master/cheats/mc4/leiame.txt", "nao entra")
    z.writestr("HEN-Cheats-Collection-master/cheats/json.txt", "x")
    z.writestr("HEN-Cheats-Collection-master/README.md", "readme")
PY
(cd "$T/zip" && exec python3 -I -m http.server $PORTA_ZIP --bind 127.0.0.1 > /dev/null 2>&1) & SRV=$!
for i in $(seq 1 50); do [ "$(codigo http://127.0.0.1:$PORTA_ZIP/catalogo.zip)" = 200 ] && break; sleep 0.2; done
echo PPSA01234 > "$T/abertos"
inicia
R=$(curl -s -A "$UA_CEL" -X POST -H 'X-GLR: 1' $U/api/cheats/catalogo)
confere "catalogo: comecou"            "$R" '"ok":true'
for i in $(seq 1 100); do R=$(api); echo "$R" | grep -q '"estado":"pronto"\|"estado":"erro"' && break; sleep 0.3; done
confere "catalogo: pronto"             "$(jq "$R" "d['catalogo']['estado'], d['catalogo']['arquivos'], d['catalogo']['json'], d['catalogo']['shn'], d['catalogo']['mc4']")" "pronto 4 2 1 1"
confere "catalogo: so os .json"        "$(ls "$T/catalogo/json" | tr '\n' ' ')" "^PPSA01234_01.000.002_12345678.json PPSA05344_04.001.000_de306fb7.json $"
confere "catalogo: .shn"               "$(ls "$T/catalogo/shn" | tr '\n' ' ')" "^PPSA01234_01.000.002.shn $"
confere "catalogo: .mc4 (sem o .txt)"  "$(ls "$T/catalogo/mc4" | tr '\n' ' ')" "^PPSA01234_01.000.002_99999999.mc4 $"
confere "catalogo: substituiu a pasta" "$(jq "$R" "[a['arquivo'] for a in d['arquivos']]")" "PPSA01234_01.000.002_12345678.json"
nao_tem "catalogo: sem sobra"          "$(ls -a "$T/catalogo")" "\.novo\|\.antigo\|parcial"
confere "catalogo: aplicadas.json fica" "$(ls "$T/catalogo")" "aplicadas.json"
confere "catalogo: diario"             "$(cat $DADOS/glibren.log)" "cheats: catalogo pronto: 4 arquivos (2 .json, 1 .shn, 1 .mc4)"
# zip sem cheats: erro e a pasta antiga fica
python3 -I -c "import zipfile; zipfile.ZipFile('$T/zip/catalogo.zip','w').writestr('x/README.md','x')"
curl -s -A "$UA_CEL" -X POST -H 'X-GLR: 1' $U/api/cheats/catalogo > /dev/null
for i in $(seq 1 100); do R=$(api); echo "$R" | grep -q '"estado":"pronto"\|"estado":"erro"' && break; sleep 0.3; done
confere "zip sem cheats: erro"         "$(jq "$R" "d['catalogo']['erro']")" "o zip nao tem cheats (json, shn ou mc4)"
confere "zip sem cheats: shn/mc4 ficam" "$(ls "$T/catalogo/shn" "$T/catalogo/mc4" | grep -c 'PPSA01234')" "^2$"
confere "zip sem cheats: antiga fica"  "$(ls "$T/catalogo/json" | wc -l)" "^2$"
rm -f "$T/zip/catalogo.zip"
curl -s -A "$UA_CEL" -X POST -H 'X-GLR: 1' $U/api/cheats/catalogo > /dev/null
for i in $(seq 1 100); do R=$(api); echo "$R" | grep -q '"estado":"pronto"\|"estado":"erro"' && break; sleep 0.3; done
confere "sem o zip: HTTP 404"          "$(jq "$R" "d['catalogo']['erro']")" "HTTP 404"
para
kill $SRV 2>/dev/null


echo "--- parsers com os arquivos REAIS (HEN-Cheats-Collection; Illusion se houver)"
REAL=${GLR_CATALOGO_REAL:-/root/ref-cheats2/cat/HEN-Cheats-Collection-master/cheats}
ILL=${GLR_ILLUSION_REAL:-/root/ref-cheats2/illusion/patches}
if [ ! -d "$REAL/shn" ]; then   # sem copia local: baixa o zip do GitHub (13,8 MB)
  mkdir -p "$T/real" && curl -s -m 180 -L -o "$T/real/hen.zip" https://codeload.github.com/TeeKay87/HEN-Cheats-Collection/zip/refs/heads/master &&
    (cd "$T/real" && unzip -q hen.zip) && REAL="$T/real/HEN-Cheats-Collection-master/cheats"
fi
if [ -d "$REAL/shn" ] && python3 -I -c "import cryptography" 2>/dev/null; then
  if [ -d "$ILL/xml" ]; then SAIDA=$(python3 -I "$ORIGEM/testes/cheats_reais.py" "$BIN" "$REAL" "$ILL" 2>&1); else SAIDA=$(python3 -I "$ORIGEM/testes/cheats_reais.py" "$BIN" "$REAL" 2>&1); fi
  echo "$SAIDA" | grep -v '^DIVERGE' | sed 's/^/     /'
  confere "reais: nenhuma divergencia"  "$SAIDA" "^divergencias: 0$"
  confere "reais: .shn e .mc4 lidos"    "$SAIDA" "'shn': [0-9]\{4\}, 'mc4': [0-9]\{4\}"
  T2D=$("$BIN" --teste-cheat "$REAL/mc4/PPSA25872_01.002.000_6408e17e.mc4" PPSA25872 01.002.000)
  confere "Terminator 2D .mc4: 6 cheats" "$(jq "$T2D" "[c['nome'] for c in d['cheats']]")" "^\['Infinite-Health', 'Infinite-Grenades', 'Infinite-Time', 'Infinite-Weapon', 'one-Hit-Kill', 'Infinite-continues'\]$"
  T2J=$("$BIN" --teste-cheat "$REAL/json/PPSA25872_01.002.000_65e7730a.json" PPSA25872 01.002.000)
  confere "Terminator 2D .json: caves"  "$(jq "$T2J" "[(c['nome'], c['suporte']) for c in d['cheats']][3:]")" "^\[('Easy Score', 'area_extra'), ('10x Score', 'area_extra')\]$"
else
  echo "PULADO sem o catalogo real (GLR_CATALOGO_REAL) ou sem o modulo cryptography"
fi
kill $ALVO ${PID_MD:-} 2>/dev/null; wait $ALVO 2>/dev/null
rm -rf "$T"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
