// 0.9.54: cartao "Pastas do ShadowKraken" na pagina Payloads, em 360 e 1280 px: lista (existe, espaco, profundidade),
// remover com a pergunta que avisa dos jogos (cancelado e confirmado), adicionar pela janela de pastas ("Usar esta
// pasta") e API fora do ar (aviso, Adicionar desligado). Sem rolar de lado, botoes da mesma linha com a mesma largura,
// nada cortado, sem reticencias. Roda no Node do Windows com o Playwright do cache do npx, chamado pelo
// testes/teste_sk_pastas.sh com o glibren-pc, o ShadowKraken falso e um aparelho pareado (o token vai no localStorage).
//   node teste_sk_pastas_pagina.mjs http://<ip do WSL>:8972 <pasta do pacote playwright> <token> <raiz de teste> [fora]
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const [base, pw, token, raiz, modo, fotos] = process.argv.slice(2);   // fotos: pasta para salvar a imagem do cartao
const { chromium } = await import(pathToFileURL(path.join(pw, 'index.mjs')).href);
let ok = 0, falhas = 0;
const confere = (nome, cond, info = '') => { if (cond) { ok++; console.log('OK   ' + nome); } else { falhas++; console.log('FALHA ' + nome + (info ? ': ' + info : '')); } };

let navegador;
for (const channel of ['msedge', 'chrome']) { try { navegador = await chromium.launch({ channel }); break; } catch { /* outro */ } }
if (!navegador) { console.log('FALHA nenhum navegador abriu'); console.log('=== pagina 0 ok, 1 falhas'); process.exit(1); }

const medir = pagina => pagina.evaluate(() => {
  const larguras = [...document.querySelectorAll('.botoes')].filter(b => b.offsetParent).map(b =>
    [...b.querySelectorAll('button')].filter(x => x.offsetParent).map(x => Math.round(x.getBoundingClientRect().width)));
  const cortados = [...document.querySelectorAll('button, .linha, h2, h3, .skp-txt')].filter(e => e.offsetParent &&
    (getComputedStyle(e).textOverflow === 'ellipsis' || e.scrollWidth > e.clientWidth + 1)).map(e => e.className + ':' + e.textContent.slice(0, 30));
  const skp = document.querySelector('.item[data-id="shadowkraken"] .skp');
  const caixa = skp ? skp.getBoundingClientRect() : { left: 0, right: 0 };
  return { larguras, cortados, rola: document.scrollingElement.scrollWidth > innerWidth, cabe: caixa.left >= 0 && caixa.right <= innerWidth,
           reticencias: /…|\.\.\./.test(skp ? skp.textContent : '') };
});
const conferirMedidas = (n, m) => {
  confere(n('sem rolar de lado'), !m.rola);
  confere(n('cartao das pastas cabe na tela'), m.cabe);
  confere(n('botoes da mesma linha: mesma largura'), m.larguras.every(l => l.every(x => Math.abs(x - l[0]) <= 1)), JSON.stringify(m.larguras));
  confere(n('nenhum texto cortado'), m.cortados.length === 0, m.cortados.join(' | '));
  confere(n('sem reticencias'), !m.reticencias);
};

const sk = '.item[data-id="shadowkraken"]';
for (const tela of [{ w: 360, h: 780, nome: 'celular' }, { w: 1280, h: 800, nome: 'PC' }]) {
  const contexto = await navegador.newContext({ viewport: { width: tela.w, height: tela.h } });
  await contexto.addInitScript(tk => { try { localStorage.setItem('glrToken', tk); localStorage.removeItem('glrArqPasta'); } catch { /* sem armazenamento */ } }, token);
  const pagina = await contexto.newPage();
  const n = s => `${s} (${tela.nome})`;
  const txt = sel => pagina.$eval(sel, e => e.textContent).catch(() => '');
  await pagina.goto(base + '/payloads');
  await pagina.waitForFunction(m => {
    const b = document.querySelector('.item[data-id="shadowkraken"] .skp');
    return b && !b.hidden && (m === 'fora' ? /não respondeu/.test(b.textContent) : b.querySelectorAll('.skp-item').length >= 2);
  }, modo, { timeout: 30000 }).catch(() => {});
  confere(n('secao visivel'), await pagina.isVisible(sk + ' .skp'));
  confere(n('titulo'), (await txt(sk + ' .skp h3')).includes('📂 Pastas do ShadowKraken'), await txt(sk + ' .skp h3'));
  if (modo === 'fora') {
    confere(n('fora: aviso'), (await txt(sk + ' .skp-estado')).includes('O ShadowKraken não respondeu'), await txt(sk + ' .skp-estado'));
    confere(n('fora: sem lista'), (await pagina.$$(sk + ' .skp-item')).length === 0);
    confere(n('fora: Adicionar desligado'), await pagina.isDisabled(sk + ' .b-skp-add'));
    confere(n('fora: Atualizar ligado'), !(await pagina.isDisabled(sk + ' .b-skp-atu')));
    await pagina.locator(sk + ' .skp').scrollIntoViewIfNeeded();
    conferirMedidas(n, await medir(pagina));
    if (fotos) await pagina.locator(sk + ' .skp').screenshot({ path: path.join(fotos, `skp-fora-${tela.w}.png`) });
    await contexto.close();
    continue;
  }
  const lista = await pagina.$$eval(sk + ' .skp-item .skp-txt', es => es.map(e => e.textContent));
  confere(n('lista: homebrew com espaco'), /✅ \/data\/homebrew/.test(lista[0] || '') && /livres de/.test(lista[0] || ''), JSON.stringify(lista));
  confere(n('lista: gamez'), /\/mnt\/ext0\/gamez/.test(lista[1] || ''), JSON.stringify(lista));
  confere(n('profundidade 2'), (await txt(sk + ' .skp-info')).includes('profundidade 2: até 2 níveis para dentro'), await txt(sk + ' .skp-info'));
  confere(n('Adicionar e Atualizar'), await pagina.isVisible(sk + ' .b-skp-add') && await pagina.isVisible(sk + ' .b-skp-atu'));
  await pagina.locator(sk + ' .skp').scrollIntoViewIfNeeded();
  conferirMedidas(n, await medir(pagina));
  if (fotos) await pagina.locator(sk + ' .skp').screenshot({ path: path.join(fotos, `skp-${tela.w}.png`) });

  // remover: a pergunta avisa dos jogos; cancelado, nada muda
  let pergunta = '';
  pagina.once('dialog', d => { pergunta = d.message(); d.dismiss(); });
  await pagina.click(`${sk} [data-skp-rem="/mnt/ext0/gamez"]`);
  await pagina.waitForTimeout(800);
  confere(n('remover: pergunta'), pergunta.startsWith('Tirar /mnt/ext0/gamez das pastas do ShadowKraken?'), pergunta);
  confere(n('remover: aviso dos jogos'), pergunta.includes('Os jogos desta pasta saem da biblioteca do PS5'), pergunta);
  confere(n('remover: aviso da remocao automatica desligada'), pergunta.includes('A remoção automática está desligada no ShadowKraken'), pergunta);
  confere(n('remover cancelado: lista igual'), (await pagina.$$(sk + ' .skp-item')).length === 2);

  // adicionar pela janela de pastas
  await pagina.click(sk + ' .b-skp-add');
  await pagina.waitForSelector('#arqJanela.aberto');
  confere(n('janela: titulo'), (await txt('#arqTit')).includes('Escolha a pasta para o ShadowKraken vigiar'), await txt('#arqTit'));
  await pagina.evaluate(c => arqPasta(c, false), raiz + '/mnt/ext0/novos');
  await pagina.waitForFunction(c => document.getElementById('arqUsar').textContent.includes(c), raiz + '/mnt/ext0/novos', { timeout: 10000 }).catch(() => {});
  confere(n('janela: Usar esta pasta'), await pagina.isVisible('#arqUsar') && (await txt('#arqUsar')).includes('Usar esta pasta'), await txt('#arqUsar'));
  confere(n('janela: sem arquivos'), !(await pagina.$('#arqPastas [data-elf]')));
  const mj = await medir(pagina);
  confere(n('janela: botoes mesma largura'), mj.larguras.every(l => l.every(x => Math.abs(x - l[0]) <= 1)), JSON.stringify(mj.larguras));
  confere(n('janela: sem rolar de lado'), !mj.rola);
  pergunta = '';
  pagina.once('dialog', d => { pergunta = d.message(); d.accept(); });
  await pagina.click('#arqUsar');
  await pagina.waitForFunction(() => /Pasta adicionada/.test(document.getElementById('msg').textContent), null, { timeout: 20000 }).catch(() => {});
  confere(n('adicionar: pergunta'), pergunta.startsWith('Adicionar /mnt/ext0/novos às pastas do ShadowKraken?'), pergunta);
  confere(n('adicionar: mensagem'), (await txt('#msg')).includes('Pasta adicionada: /mnt/ext0/novos'), await txt('#msg'));
  confere(n('adicionar: janela fechou'), !(await pagina.isVisible('#arqJanela')));
  confere(n('adicionar: na lista'), (await pagina.$$eval(sk + ' .skp-item .skp-txt', es => es.map(e => e.textContent))).some(x => x.includes('/mnt/ext0/novos')));
  await pagina.locator(sk + ' .skp').scrollIntoViewIfNeeded();
  conferirMedidas(n, await medir(pagina));

  // remover confirmado (volta ao que era)
  pagina.once('dialog', d => d.accept());
  await pagina.click(`${sk} [data-skp-rem="/mnt/ext0/novos"]`);
  await pagina.waitForFunction(() => /Pasta removida/.test(document.getElementById('msg').textContent), null, { timeout: 20000 }).catch(() => {});
  confere(n('remover: mensagem'), (await txt('#msg')).includes('Pasta removida: /mnt/ext0/novos'), await txt('#msg'));
  confere(n('remover: saiu da lista'), (await pagina.$$(sk + ' .skp-item')).length === 2);
  await contexto.close();
}
await navegador.close();
console.log(`=== pagina ${ok} ok, ${falhas} falhas`);
process.exit(falhas ? 1 : 0);
