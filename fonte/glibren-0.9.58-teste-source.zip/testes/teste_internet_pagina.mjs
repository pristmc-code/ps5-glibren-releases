// 0.9.52: pagina /internet - mensagem do 429 da Cloudflare nos tres idiomas, texto inteiro (sem reticencias) e sem
// rolar de lado em 360 e 1280 px. Chamado pelo testes/teste_internet.sh depois de um teste que recebeu 429.
//   node teste_internet_pagina.mjs http://127.0.0.1:8797 <pasta do pacote playwright>
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const [base, pw] = process.argv.slice(2);
const { chromium } = await import(pathToFileURL(path.join(pw, 'index.mjs')).href);
let ok = 0, falhas = 0;
const confere = (nome, cond, info = '') => { if (cond) { ok++; console.log('OK   ' + nome); } else { falhas++; console.log('FALHA ' + nome + (info ? ': ' + info : '')); } };

let navegador;
for (const channel of ['msedge', 'chrome']) { try { navegador = await chromium.launch({ channel }); break; } catch { /* outro */ } }
if (!navegador) { console.log('FALHA nenhum navegador abriu'); console.log('=== pagina 0 ok, 1 falhas'); process.exit(1); }

const esperado = {
  'pt-BR': 'Cloudflare limitou os testes deste PS5 (código 429). Escolha um servidor da lista ou tente de novo em 2 min',
  en: 'Cloudflare limited the tests from this PS5 (code 429). Pick a server from the list or try again in 2 min',
  es: 'Cloudflare limitó las pruebas de esta PS5 (código 429). Elija un servidor de la lista o inténtelo de nuevo en 2 min',
};
for (const tela of [{ w: 360, h: 780, nome: '360 px' }, { w: 1280, h: 800, nome: '1280 px' }]) {
  for (const locale of ['pt-BR', 'en', 'es']) {
    const pagina = await navegador.newPage({ viewport: { width: tela.w, height: tela.h }, locale });
    const n = s => `${s} (${tela.nome}, ${locale})`;
    // o idioma da pagina vem do glibren (/api/estado), gravado pelo /api/idioma
    await fetch(base + '/api/idioma', { method: 'POST', headers: { 'X-GLR': '1', 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'idioma=' + locale });
    await pagina.goto(base + '/internet');
    await pagina.waitForFunction(() => (document.getElementById('erro')?.textContent || '').includes('429'), null, { timeout: 15000 }).catch(() => {});
    const erro = await pagina.$eval('#erro', e => ({ txt: e.textContent, larg: e.scrollWidth, vis: e.clientWidth }));
    confere(n('mensagem traduzida'), erro.txt.includes(esperado[locale]), erro.txt);
    confere(n('sem reticencias'), !/…|\.\.\./.test(erro.txt), erro.txt);
    confere(n('mensagem inteira (quebra linha, nao corta)'), erro.larg <= erro.vis + 1, `${erro.larg} > ${erro.vis}`);
    const rola = await pagina.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1);
    confere(n('sem rolagem lateral'), !rola);
    await pagina.close();
  }
}
await navegador.close();
console.log(`=== pagina ${ok} ok, ${falhas} falhas`);
process.exit(falhas ? 1 : 0);
