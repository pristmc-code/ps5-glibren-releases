#!/bin/bash
# 0.9.52: teste de velocidade da internet com servidor falso no lugar da Cloudflare, da lista do speedtest.net e dos
# servidores da lista (GLR_TESTE_INTERNET). Confere que resposta recusada (429, 403) nao vira velocidade, a mensagem do
# 429 da Cloudflare (com e sem Retry-After), que a Cloudflare limitada fica de fora sem novos pedidos, a troca para o
# proximo servidor da lista no automatico, upload recusado e o glibren.log. As fases duram 2 s no modo de teste.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_internet.sh
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8797; P_SRV=12497
U="http://127.0.0.1:$PORTA"
T=$(mktemp -d /tmp/glr-net.XXXXXX)
ok=0; falhou=0
confere() { if echo "$2" | grep -q -- "$3"; then echo "OK   $1"; ok=$((ok+1)); else echo "FALHOU $1 -> $2"; falhou=$((falhou+1)); fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then echo "FALHOU $1 -> $2"; falhou=$((falhou+1)); else echo "OK   $1"; ok=$((ok+1)); fi; }
igual() { if [ "$2" = "$3" ]; then echo "OK   $1"; ok=$((ok+1)); else echo "FALHOU $1 -> '$2' (esperado '$3')"; falhou=$((falhou+1)); fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
modo() { echo "$2" > "$T/modo_$1"; }      # modo <alvo> <valor>: cf_down, cf_up, s1, s2, lista
contagem() { cat "$T/conta_$1" 2>/dev/null || echo 0; }
zerar() { rm -f "$T"/conta_*; }

# Servidor falso. Modos (arquivo $T/modo_<alvo>):
#   cf_down: ok | 429 | 429ra (Retry-After: 120) | 429grande (corpo de 2 MB)   cf_up: ok | 429
#   s1/s2:   ok | prova (so o bloco de prova de 100000 bytes; o teste de verdade recebe 403)
#   lista:   "s1,s2" | "s1" | "" (lista vazia)
python3 -I - $P_SRV "$T" > "$T/srv.log" 2>&1 <<'EOF' &
import http.server, json, os, sys, threading
porta, pasta = int(sys.argv[1]), sys.argv[2]
trava = threading.Lock()
def modo(nome, padrao="ok"):
    try: return open(os.path.join(pasta, "modo_" + nome)).read().strip()
    except OSError: return padrao
def contar(nome):
    with trava:
        f = os.path.join(pasta, "conta_" + nome)
        try: n = int(open(f).read())
        except (OSError, ValueError): n = 0
        open(f, "w").write(str(n + 1))
class H(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def responder(self, cod, corpo=b"", extra=()):
        self.send_response(cod)
        for k, v in extra: self.send_header(k, v)
        self.send_header("Content-Length", str(len(corpo))); self.end_headers()
        if corpo: self.wfile.write(corpo)
    def bytes_pedidos(self):
        q = self.path.split("?", 1)[1] if "?" in self.path else ""
        for parte in q.split("&"):
            k, _, v = parte.partition("=")
            if k in ("bytes", "size"): return int(v)
        return 0
    def do_GET(self):
        p = self.path.split("?")[0]
        if p == "/servers":
            nomes = [n for n in modo("lista", "s1,s2").split(",") if n]
            lista = [{"host": f"{n}.teste:{porta}", "sponsor": n.upper(), "name": "Cidade " + n, "distance": 5 + i}
                     for i, n in enumerate(nomes)]
            return self.responder(200, json.dumps(lista).encode())
        if p == "/cf/__down":
            contar("cf_down"); m = modo("cf_down")
            if m == "429": return self.responder(429, b"rate limited")
            if m == "429ra": return self.responder(429, b"rate limited", [("Retry-After", "120")])
            if m == "429grande": return self.responder(429, b"x" * (2 * 1024 * 1024))
            return self.responder(200, b"\0" * min(self.bytes_pedidos(), 3_000_000))
        nome = p.strip("/").split("/")[0]
        if p.endswith("/download"):
            n = self.bytes_pedidos(); contar(nome + ("_prova" if n == 100000 else "_down"))
            if modo(nome) == "prova" and n != 100000: return self.responder(403, b"forbidden")
            return self.responder(200, b"\0" * min(n, 3_000_000))
        self.responder(404)
    def do_POST(self):
        n = int(self.headers.get("Content-Length", "0")); self.rfile.read(n)
        p = self.path.split("?")[0]
        if p == "/cf/__up":
            contar("cf_up")
            return self.responder(429, b"no") if modo("cf_up") == "429" else self.responder(200, b"ok")
        nome = p.strip("/").split("/")[0]
        contar(nome + "_up")
        return self.responder(403, b"no") if modo(nome) == "prova" else self.responder(200, b"ok")
    def log_message(self, *a): pass
http.server.ThreadingHTTPServer(("127.0.0.1", porta), H).serve_forever()
EOF
PID_SRV=$!
sleep 1

iniciar() {
  rm -rf "$T/dados"
  GLR_TESTE_INTERNET="http://127.0.0.1:$P_SRV/" "$BIN" -p $PORTA -d "$T/dados" > "$T/glr.log" 2>&1 &
  PID=$!
  for i in $(seq 1 40); do curl -s $U/api/internet > /dev/null && break; sleep 0.25; done
}
parar() { post -X POST $U/api/sair > /dev/null; wait $PID 2>/dev/null; }
testar() {   # testar <servidor>: inicia e espera terminar; devolve o estado
  post -X POST --data "servidor=$1" $U/api/internet > /dev/null
  for i in $(seq 1 120); do
    e=$(curl -s $U/api/internet)
    echo "$e" | grep -q '"rodando":false' && { echo "$e"; return; }
    sleep 0.25
  done
  curl -s $U/api/internet
}
campo() { python3 -c "import json,sys; d=json.load(sys.stdin); print($1)"; }
diario() { cat "$T/dados/glibren.log" 2>/dev/null; }

echo "--- Cloudflare escolhida: 429 com Retry-After no download"
iniciar; zerar
modo cf_down 429ra; modo cf_up ok
e=$(testar cloudflare)
igual "download falhou (nao vira numero)" "$(echo "$e" | campo "d['down']")" "-1.0"
igual "upload nao rodou" "$(contagem cf_up)" "0"
igual "upload sem valor" "$(echo "$e" | campo "d['up']")" "-1.0"
confere "mensagem 429 com minutos" "$(echo "$e" | campo "d['erro']")" "limitou os testes deste PS5 (codigo 429); escolha um servidor da lista ou tente de novo em 2 min"
igual "nada no historico" "$(echo "$e" | campo "len(d['historico'])")" "0"
d=$(contagem cf_down)
[ "$d" -le 4 ] && { echo "OK   no maximo 4 pedidos recusados ($d)"; ok=$((ok+1)); } || { echo "FALHOU pedidos recusados demais: $d"; falhou=$((falhou+1)); }
confere "log: servidor escolhido" "$(diario)" "internet: servidor Cloudflare (escolhido)"
confere "log: download falhou com o codigo" "$(diario)" "internet: download em Cloudflare falhou: 0 resposta(s) ok, .* recusada(s), ultimo codigo 429, Retry-After 120 s"

echo "--- Cloudflare limitada: nem pede de novo"
zerar
e=$(testar cloudflare)
igual "nenhum pedido novo a Cloudflare" "$(contagem cf_down)" "0"
confere "mensagem com minutos" "$(echo "$e" | campo "d['erro']")" "tente de novo em 2 min"
confere "log: limitada" "$(diario)" "Cloudflare escolhida, mas ela limitou este PS5 por mais 2 min"

echo "--- automatico com a Cloudflare limitada e a lista recusando o teste"
zerar; modo lista s1; modo s1 prova
e=$(testar auto)
igual "download falhou" "$(echo "$e" | campo "d['down']")" "-1.0"
confere "mensagem 429" "$(echo "$e" | campo "d['erro']")" "codigo 429"
igual "Cloudflare nao recebeu pedido" "$(contagem cf_down)" "0"
confere "log: s1 recusou o download" "$(diario)" "internet: download em S1 - Cidade s1 falhou: 0 resposta(s) ok, .* ultimo codigo 403"
parar

echo "--- Cloudflare: 429 sem Retry-After e corpo de erro grande"
iniciar; zerar
modo cf_down 429grande
e=$(testar cloudflare)
igual "download falhou (2 MB de erro nao contam)" "$(echo "$e" | campo "d['down']")" "-1.0"
confere "mensagem sem minutos" "$(echo "$e" | campo "d['erro']")" "por alguns minutos (codigo 429); escolha um servidor da lista ou tente de novo em alguns minutos"
parar

echo "--- automatico: s1 aceita a prova e recusa o teste, s2 funciona"
iniciar; zerar
modo lista s1,s2; modo s1 prova; modo s2 ok; modo cf_down ok; modo cf_up ok
e=$(testar auto)
d=$(echo "$e" | campo "d['down']"); u=$(echo "$e" | campo "d['up']")
python3 -c "import sys; sys.exit(0 if float('$d') > 0 and float('$u') > 0 else 1)" && { echo "OK   download e upload medidos no s2 ($d / $u)"; ok=$((ok+1)); } || { echo "FALHOU s2: $e"; falhou=$((falhou+1)); }
igual "servidor usado" "$(echo "$e" | campo "d['servidor']['nome']")" "S2"
igual "Cloudflare nao foi usada" "$(contagem cf_down)" "0"
confere "log: troca para o proximo da lista" "$(diario)" "internet: servidor S2 - Cidade s2 (automatico, o anterior recusou o download (codigo 403)"
igual "um resultado no historico" "$(echo "$e" | campo "len(d['historico'])")" "1"
parar

echo "--- automatico: lista vazia -> Cloudflare; upload recusado"
iniciar; zerar
modo lista ""; modo cf_down ok; modo cf_up 429
e=$(testar auto)
d=$(echo "$e" | campo "d['down']")
python3 -c "import sys; sys.exit(0 if float('$d') > 0 else 1)" && { echo "OK   download medido na Cloudflare ($d)"; ok=$((ok+1)); } || { echo "FALHOU download: $e"; falhou=$((falhou+1)); }
igual "upload recusado nao vira numero" "$(echo "$e" | campo "d['up']")" "-1.0"
confere "mensagem do upload" "$(echo "$e" | campo "d['erro']")" "o servidor recusou o upload (codigo 429)"
igual "download vai para o historico" "$(echo "$e" | campo "len(d['historico'])")" "1"
confere "log: motivo da Cloudflare" "$(diario)" "internet: servidor Cloudflare (automatico: nenhum dos 0 servidores da lista serviu; lista do speedtest.net vazia)"
confere "log: upload falhou" "$(diario)" "internet: upload em Cloudflare falhou"
parar

echo "--- Cloudflare normal"
iniciar; zerar
modo cf_down ok; modo cf_up ok
e=$(testar cloudflare)
python3 -c "import sys; d=$(echo "$e" | campo "d['down']"); u=$(echo "$e" | campo "d['up']"); sys.exit(0 if d > 0 and u > 0 else 1)" \
  && { echo "OK   download e upload medidos"; ok=$((ok+1)); } || { echo "FALHOU normal: $e"; falhou=$((falhou+1)); }
igual "sem erro" "$(echo "$e" | campo "d['erro']")" ""
confere "log: download medido" "$(diario)" "internet: download em Cloudflare: .* Mbps (.* bytes, .* resposta(s) ok, 0 recusada(s))"
parar

echo "--- pagina (mensagem nova, 360 e 1280 px) no Chromium/Edge do Windows, se houver"
NODE_WIN="/mnt/c/Program Files/nodejs/node.exe"
LAD=$(cmd.exe /c 'echo %LOCALAPPDATA%' 2>/dev/null | tr -d '')
PW=""; [ -n "$LAD" ] && PW=$(ls -d "$(wslpath "$LAD")"/npm-cache/_npx/*/node_modules/playwright 2>/dev/null | head -1)
if [ -x "$NODE_WIN" ] && [ -n "$PW" ]; then
  iniciar; zerar; modo cf_down 429ra
  testar cloudflare > /dev/null
  SAIDA=$("$NODE_WIN" "$(wslpath -w "$ORIGEM/testes/teste_internet_pagina.mjs")" "$U" "$(wslpath -w "$PW")" 2>&1)
  echo "$SAIDA"
  ok=$((ok + $(echo "$SAIDA" | grep -c '^OK '))); falhou=$((falhou + $(echo "$SAIDA" | grep -c '^FALHA')))
  echo "$SAIDA" | grep -q '^=== pagina' || { falhou=$((falhou+1)); echo "FALHA pagina: o script nao terminou"; }
  parar
else
  echo "PULADO: teste da pagina (sem node.exe ou Playwright no Windows)"
fi

kill $PID_SRV 2>/dev/null
rm -rf "$T"
echo "=== internet $ok ok, $falhou falhas"
[ $falhou -eq 0 ]
