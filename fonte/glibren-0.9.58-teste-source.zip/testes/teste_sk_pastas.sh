#!/bin/bash
# Testa as pastas vigiadas pelo ShadowKraken (0.9.54) na versao de PC, com um ShadowKraken falso (testes/smp_falso.py):
# listar (existe, espaco, profundidade, lista padrao), API fora do ar, API sem /settings, conferir (pasta inexistente,
# fora dos discos, link, dentro de outra vigiada, contem outra, PS4, downloads/packages, backup), adicionar e remover
# (so celular/PC pareado; o update reenvia os outros ajustes exatamente como vieram), lista padrao copiada, IP fixo,
# update recusado, campo exigido faltando, "shadowmount =" do glibren seguindo a lista e o diario (antes/depois).
# Os discos do PS5 ficam em $R (GLR_TESTE_SK_RAIZ): $R/data, $R/mnt/ext0, $R/mnt/usb0.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_sk_pastas.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8972; PORTA_SMP=18972
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R_URL="http://$IP:$PORTA"
T=/root/glr-skp; DADOS=$T/dados; R=$T/raiz; SKC=$T/sk-config.ini
UA_PS5='Mozilla/5.0 (PlayStation; PlayStation 5/12.00) AppleWebKit/605.1.15 (KHTML, like Gecko)'
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$(echo "$2" | head -c 900)] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
TOKEN=""
post() { curl -s -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" "$@"; }
codigo() { curl -s -o /dev/null -w '%{http_code}' -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" "$@"; }
estado() { curl -s "$L/api/sk/pastas"; }
conferir() { curl -s -G --data-urlencode "caminho=$1" ${2:+--data-urlencode "modo=$2"} "$L/api/sk/pastas/conferir"; }
adicionar() { post --data-urlencode "caminho=$1" "$R_URL/api/sk/pastas/adicionar"; }
remover() { post --data-urlencode "caminho=$1" "$R_URL/api/sk/pastas/remover"; }
# estado do ShadowKraken falso (settings + flags)
sk_estado() { python3 -I -c 'import json,sys; json.dump({"games":[],"images":[],"settings":json.loads(sys.argv[1]),"sk":json.loads(sys.argv[2])}, open(sys.argv[3],"w"))' "$1" "${2:-{\}}" "$T/smp/estado.json"; }
sk_conf() { python3 -I -c 'import json,sys; print(json.dumps(json.load(open(sys.argv[1])).get("settings",{}), sort_keys=True))' "$T/smp/estado.json"; }
ultimo_update() { grep '"/api/v1/settings/update"' "$T/smp/pedidos.jsonl" | tail -1; }
monit() { grep '^shadowmount' "$DADOS/config.ini" | tr '\n' '|'; }

pkill -f "smp_falso.py $PORTA_SMP" 2>/dev/null
rm -rf "$T"; mkdir -p "$DADOS" "$T/smp" "$T/outra"
mkdir -p "$R/data/homebrew/JogoA" "$R/data/shadowmount" "$R/data/vazia" "$R/mnt/ext0/gamez/sub" "$R/mnt/ext0/novos" \
  "$R/mnt/ext0/PS4" "$R/mnt/ext0/backup/Hades" "$R/mnt/ext0/downloads/packages" "$R/mnt/usb0/jogos"
ln -s "$R/data/homebrew" "$R/data/atalho"
printf '[general]\ndebug = off\n[api]\nport = 10101\nbind_address = 0.0.0.0\n[scan]\ndepth = 2\npath = /data/homebrew\n' > "$SKC"
printf 'language = pt-BR\nfolder = %s/\nfolder = %s/\nfolder = %s/\nshadowmount = %s/\n' \
  "$R/data/homebrew" "$R/mnt/ext0/gamez" "$T/outra" "$T/outra" > "$DADOS/config.ini"
CONF='{"scan_paths":["/data/homebrew","/mnt/ext0/gamez"],"api_enabled":true,"debug":true,"quiet_mode":false,"update_emulators":false,"allow_lan_access":true,"fan_target_temperature":65,"auto_update_ampr":false,"add_emulators":true,"fpkg_direct_mount":true,"auto_remove_missing_games":false,"auto_remove_missing_delay_seconds":1234,"fakelib_default_mode":"emulators"}'
sk_estado "$CONF"

# um ShadowKraken "instalado" no glibren (o cartao so aparece com ele), por "Instalar de arquivo"
python3 -I -c 'import sys; d=b"\x7fELF"+b"\0"*60+b"ShadowKraken 1.00-Dev.16-pristmc\0"; d+=bytes((i*7)%251 for i in range(6000-len(d))); open(sys.argv[1],"wb").write(d)' "$T/shadowkraken-1.00-Dev.16-pristmc.elf"
GLR_TESTE_SMP_PORTA=$PORTA_SMP GLR_TESTE_SMP_CONFIG="$SKC" GLR_TESTE_SK_RAIZ="$R" GLR_TESTE_SONDA_S=0 GLR_TESTE_ARQ_RAIZES="$T" \
  GLR_TESTE_GH="http://127.0.0.1:9" GLR_TESTE_BASE="http://127.0.0.1:9/" GLR_TESTE_SEM_REMOVIDOS=1 \
  "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!
sleep 1
curl -s -H 'X-GLR: 1' -X POST $R_URL/api/parear/pedir > /dev/null
C=$(grep -o 'pareamento [0-9]\{6\}' "$T/glr.log" | tail -1 | awk '{print $2}')
TOKEN=$(curl -s -H 'X-GLR: 1' -d codigo=$C -d nome=Teste $R_URL/api/parear | python3 -c 'import json,sys; print(json.load(sys.stdin)["token"])')
confere "pareado"                           "$TOKEN" "^[0-9a-f]\{64\}$"
confere "ShadowKraken instalado"            "$(post -d id=shadowkraken --data-urlencode caminho=$T/shadowkraken-1.00-Dev.16-pristmc.elf $R_URL/api/payloads/arquivo)" '"ok":true'

echo "--- API do ShadowKraken fora do ar"
confere "GET: sk_fora"                      "$(estado)" '"chave":"sk_fora"'
confere "GET: 503"                          "$(curl -s -o /dev/null -w '%{http_code}' $L/api/sk/pastas)" "503"
confere "conferir: sk_fora"                 "$(conferir /mnt/ext0/novos)" '"chave":"sk_fora"'
confere "adicionar: sk_fora"                "$(adicionar /mnt/ext0/novos)" '"chave":"sk_fora"'
confere "monitoradas intactas"              "$(monit)" "^shadowmount = $T/outra/|$"

(exec python3 -I "$ORIGEM/testes/smp_falso.py" $PORTA_SMP "$T/smp") >> "$T/smp.log" 2>&1 &
sleep 0.5

echo "--- listar"
E=$(estado)
confere "ok"                                "$E" '"ok":true,"profundidade":2,"padrao":false,"auto_remove":false,"ip_fixo":false'
confere "homebrew existe + espaco"          "$E" '{"caminho":"/data/homebrew","existe":true,"padrao":false,"livre":[0-9]*,"total":[0-9]*}'
confere "gamez existe"                      "$E" '"caminho":"/mnt/ext0/gamez","existe":true'
confere "Ativo segue o SK"                  "$(monit)" "^shadowmount = $R/data/homebrew/|shadowmount = $R/mnt/ext0/gamez/|$"
confere "diario: Ativo antes/depois"        "$(cat $DADOS/glibren.log)" "sk-pastas: \"Ativo\" (shadowmount =) segue o ShadowKraken: antes \[$T/outra/\], depois \[$R/data/homebrew/, $R/mnt/ext0/gamez/\]"
N=$(grep -c 'segue o ShadowKraken' $DADOS/glibren.log); estado > /dev/null
confere "sem mudanca: diario nao repete"    "$(grep -c 'segue o ShadowKraken' $DADOS/glibren.log)" "^$N$"
sk_estado '{"scan_paths":["/data/homebrew","/mnt/ext0/sumiu"]}'
confere "pasta que nao existe aparece"      "$(estado)" '"caminho":"/mnt/ext0/sumiu","existe":false,"padrao":false}'
sk_estado "$CONF"

echo "--- conferir (avisos e recusas)"
confere "inexistente = recusa"              "$(conferir /data/naoexiste)" '"chave":"sk_nao_existe"'
confere "fora dos discos = recusa"          "$(conferir /root)" '"chave":"sk_pasta_fora"'
confere "/data inteira = recusa"            "$(conferir /data)" '"chave":"sk_pasta_fora"'
confere "/mnt/shadowmnt = recusa"           "$(conferir /mnt/shadowmnt/x)" '"chave":"sk_pasta_fora"'
confere "pasta do SK = recusa"              "$(conferir /data/shadowmount)" '"chave":"sk_pasta_fora"'
confere "/mnt/usbX sem numero = recusa"     "$(conferir /mnt/usbx)" '"chave":"sk_pasta_fora"'
confere "com .. = recusa"                   "$(conferir /data/homebrew/../vazia)" '"chave":"sk_pasta_fora"'
confere "link = recusa"                     "$(conferir /data/atalho)" '"chave":"sk_link"'
confere "ja esta = recusa"                  "$(conferir /mnt/ext0/gamez/)" '"chave":"sk_ja_esta"'
confere "nova sem avisos"                   "$(conferir /mnt/ext0/novos)" '"ok":true,"caminho":"/mnt/ext0/novos","profundidade":2,"avisos":\[\]'
confere "caminho do PC aceito"              "$(conferir $R/mnt/ext0/novos)" '"caminho":"/mnt/ext0/novos"'
confere "dentro de outra (coberta)"         "$(conferir /mnt/ext0/gamez/sub)" '{"chave":"dentro_coberta","p":"/mnt/ext0/gamez"}'
mkdir -p "$R/mnt/ext0/gamez/sub/fundo"
confere "dentro de outra (mais funda)"      "$(conferir /mnt/ext0/gamez/sub/fundo)" '{"chave":"dentro_funda","p":"/mnt/ext0/gamez"}'
E=$(conferir /mnt/ext0)
confere "raiz do disco: contem gamez"       "$E" '{"chave":"contem","p":"/mnt/ext0/gamez"}'
confere "raiz do disco: PS4 ao alcance"     "$E" '"chave":"ps4"'
confere "raiz do disco: backup ao alcance"  "$E" '"chave":"backup"'
confere "PS4 da JB"                         "$(conferir /mnt/ext0/PS4)" '"avisos":\[{"chave":"ps4","p":""}\]'
confere "downloads/packages"                "$(conferir /mnt/ext0/downloads/packages)" '"avisos":\[{"chave":"ps4","p":""}\]'
confere "backup"                            "$(conferir /mnt/ext0/backup)" '"avisos":\[{"chave":"backup","p":""}\]'
confere "usb sem avisos"                    "$(conferir /mnt/usb0/jogos)" '"avisos":\[\]'
confere "remover: aviso dos jogos"          "$(conferir /mnt/ext0/gamez remover)" '"avisos":\[{"chave":"remove_jogos","p":""}\]'
confere "remover: nao esta"                 "$(conferir /mnt/usb0/jogos remover)" '"chave":"sk_nao_esta"'

echo "--- so pelo celular/PC pareado"
confere "127.0.0.1 = 403"                   "$(codigo --data-urlencode caminho=/mnt/ext0/novos $L/api/sk/pastas/adicionar)" "403"
confere "navegador do PS5 = 403"            "$(codigo -A "$UA_PS5" --data-urlencode caminho=/mnt/ext0/novos $R_URL/api/sk/pastas/adicionar)" "403"
confere "sem token = 401"                   "$(curl -s -o /dev/null -w '%{http_code}' -H 'X-GLR: 1' --data-urlencode caminho=/mnt/ext0/novos $R_URL/api/sk/pastas/adicionar)" "401"
confere "sem X-GLR = 403"                   "$(curl -s -o /dev/null -w '%{http_code}' -H "X-GLR-Token: $TOKEN" --data-urlencode caminho=/mnt/ext0/novos $R_URL/api/sk/pastas/remover)" "403"
confere "nada foi gravado"                  "$(grep -c settings/update $T/smp/pedidos.jsonl)" "^0$"
confere "adicionar inexistente = recusa"    "$(adicionar /data/naoexiste)" '"chave":"sk_nao_existe"'
confere "adicionar fora = recusa"           "$(adicionar /etc)" '"chave":"sk_pasta_fora"'
confere "ainda nada gravado"                "$(grep -c settings/update $T/smp/pedidos.jsonl)" "^0$"

echo "--- adicionar"
ANTES=$(sk_conf)
E=$(adicionar /mnt/ext0/novos)
confere "adicionou e releu"                 "$E" '"ok":true,"relido":true,"caminho":"/mnt/ext0/novos"'
confere "estado novo na resposta"           "$E" '"caminho":"/mnt/ext0/novos","existe":true'
U=$(ultimo_update)
confere "update: lista nova"                "$U" '"scan_paths": \["/data/homebrew", "/mnt/ext0/gamez", "/mnt/ext0/novos"\]'
confere "update: exigidos como vieram"      "$U" '"debug": true, "quiet_mode": false, "update_emulators": false, "allow_lan_access": true, "fan_target_temperature": 65'
confere "update: opcionais como vieram"     "$U" '"auto_update_ampr": false, "add_emulators": true, "fpkg_direct_mount": true, "auto_remove_missing_games": false, "auto_remove_missing_delay_seconds": 1234, "fakelib_default_mode": "emulators"'
nao_tem "update: sem campos so de leitura"  "$U" 'api_enabled\|scan_path_count\|"status"'
DEPOIS=$(sk_conf)
confere "outros ajustes preservados"        "$(python3 -I -c 'import json,sys; a,d=json.loads(sys.argv[1]),json.loads(sys.argv[2]); a.pop("scan_paths"); d.pop("scan_paths"); print("iguais" if a==d else "diferentes %s %s" % (a,d))' "$ANTES" "$DEPOIS")" "^iguais$"
nao_tem "sem /api/v1/scan depois"           "$(cat $T/smp/pedidos.jsonl)" '"/api/v1/scan"'
LOG=$(cat $DADOS/glibren.log)
confere "diario: antes/depois"              "$LOG" "sk-pastas: adicionou /mnt/ext0/novos; antes \[/data/homebrew, /mnt/ext0/gamez\]; depois \[/data/homebrew, /mnt/ext0/gamez, /mnt/ext0/novos\]"
confere "entrou na lista do glibren"        "$(grep '^folder' $DADOS/config.ini)" "folder = $R/mnt/ext0/novos/"
confere "diario: lista do glibren"          "$LOG" "sk-pastas: $R/mnt/ext0/novos entrou tambem na lista do glibren"
confere "Ativo inclui a nova"               "$(monit)" "shadowmount = $R/mnt/ext0/novos/"
confere "adicionar de novo = recusa"        "$(adicionar /mnt/ext0/novos)" '"chave":"sk_ja_esta"'

echo "--- remover"
E=$(remover /mnt/ext0/novos)
confere "removeu"                           "$E" '"ok":true,"relido":true,"caminho":"/mnt/ext0/novos","avisos":\[{"chave":"remove_jogos","p":""}\]'
confere "update: sem a pasta"               "$(ultimo_update)" '"scan_paths": \["/data/homebrew", "/mnt/ext0/gamez"\]'
confere "diario: removeu"                   "$(cat $DADOS/glibren.log)" "sk-pastas: removeu /mnt/ext0/novos; antes \[/data/homebrew, /mnt/ext0/gamez, /mnt/ext0/novos\]; depois \[/data/homebrew, /mnt/ext0/gamez\]"
nao_tem "Ativo sem a removida"              "$(monit)" "novos"
confere "lista do glibren fica"             "$(grep '^folder' $DADOS/config.ini)" "folder = $R/mnt/ext0/novos/"
confere "outros ajustes ainda iguais"       "$(python3 -I -c 'import json,sys; a,d=json.loads(sys.argv[1]),json.loads(sys.argv[2]); a.pop("scan_paths"); d.pop("scan_paths"); print("iguais" if a==d else "diferentes")' "$ANTES" "$(sk_conf)")" "^iguais$"
confere "remover a que nao esta"            "$(remover /mnt/usb0/jogos)" '"chave":"sk_nao_esta"'

echo "--- ultima pasta: o SK volta para a lista padrao"
sk_estado '{"scan_paths":["/mnt/usb0/jogos"]}'
E=$(remover /mnt/usb0/jogos)
confere "remover a ultima: aviso"           "$E" '{"chave":"remove_jogos","p":""},{"chave":"volta_padrao","p":""}'
confere "update: lista vazia"               "$(ultimo_update)" '"scan_paths": \[\]'

echo "--- lista padrao (scan_paths vazio)"
sk_estado '{"scan_paths":[]}'
E=$(estado)
confere "padrao: true"                      "$E" '"padrao":true'
confere "padrao: so as que existem"         "$E" '"pastas":\[{"caminho":"/data/homebrew","existe":true,"padrao":true,[^]]*{"caminho":"/mnt/usb0","existe":true,"padrao":true,[^]]*{"caminho":"/mnt/ext0","existe":true,"padrao":true'
nao_tem "padrao: sem etaHEN inexistente"    "$E" 'etaHEN'
confere "conferir: aviso copia padrao"      "$(conferir /data/vazia)" '{"chave":"copia_padrao","p":""}'
E=$(adicionar /data/vazia)
confere "adicionar com lista padrao"        "$E" '"ok":true,"relido":true'
confere "update: padrao + nova"             "$(ultimo_update)" '"scan_paths": \["/data/homebrew", "/mnt/usb0", "/mnt/ext0", "/data/vazia"\]'
sk_estado '{"scan_paths":[]}'
rmdir "$R/mnt/usb0/jogos" && mv "$R/mnt/usb0" "$R/mnt/usb0-fora" && mv "$R/mnt/ext0" "$R/mnt/ext0-fora"
confere "unica padrao: nao remove"          "$(remover /data/homebrew)" '"chave":"sk_ultima_padrao"'
mv "$R/mnt/usb0-fora" "$R/mnt/usb0" && mv "$R/mnt/ext0-fora" "$R/mnt/ext0"; mkdir -p "$R/mnt/usb0/jogos"

echo "--- ShadowKraken ligado num IP so"
sk_estado "$CONF"
sed -i 's/bind_address = 0.0.0.0/bind_address = 192.168.0.50/' "$SKC"
confere "estado: ip_fixo"                   "$(estado)" '"ip_fixo":true'
N=$(grep -c settings/update $T/smp/pedidos.jsonl)
confere "adicionar: recusa"                 "$(adicionar /mnt/usb0/jogos)" '"chave":"sk_ip_fixo"'
confere "nada gravado com IP fixo"          "$(grep -c settings/update $T/smp/pedidos.jsonl)" "^$N$"
sed -i 's/bind_address = 192.168.0.50/bind_address = 127.0.0.1/' "$SKC"
confere "127.0.0.1 grava normal"            "$(conferir /mnt/usb0/jogos)" '"ok":true'
sed -i 's/bind_address = 127.0.0.1/bind_address = 0.0.0.0/' "$SKC"

echo "--- ShadowKraken recusa o update"
sk_estado "$CONF" '{"recusar":true}'
confere "recusado: 502"                     "$(adicionar /mnt/usb0/jogos)" '"chave":"sk_recusou","erro":"Input/output error"'
confere "diario: recusado"                  "$(cat $DADOS/glibren.log)" "sk-pastas: adicionar /mnt/usb0/jogos recusado pelo ShadowKraken (HTTP 500: Input/output error); lista continua \[/data/homebrew, /mnt/ext0/gamez\]"
confere "lista do SK intacta"               "$(sk_conf)" '"scan_paths": \["/data/homebrew", "/mnt/ext0/gamez"\]'

echo "--- campo exigido faltando no GET"
sk_estado "$CONF" '{"sem_campo":"fan_target_temperature"}'
N=$(grep -c settings/update $T/smp/pedidos.jsonl)
confere "sem campo: nao grava"              "$(adicionar /mnt/usb0/jogos)" '"chave":"sk_sem_campo"'
confere "nenhum update enviado"             "$(grep -c settings/update $T/smp/pedidos.jsonl)" "^$N$"
sk_estado "$CONF" '{"sem_campo":"fakelib_default_mode"}'
E=$(adicionar /mnt/usb0/jogos)
confere "sem opcional: grava"               "$E" '"ok":true'
nao_tem "update sem o opcional"             "$(ultimo_update)" 'fakelib_default_mode'

echo "--- API sem /settings (ShadowMount+ antigo)"
sk_estado "$CONF" '{"sem_settings":true}'
confere "sem settings: 502"                 "$(estado)" '"chave":"sk_sem_settings"'
confere "adicionar: sem settings"           "$(adicionar /mnt/usb0/jogos)" '"chave":"sk_sem_settings"'

echo "--- 0.9.56: jogos instalados pelo sistema ([fpkg] installed)"
sk_estado "$CONF"
inst() { post -d "ligar=$1" "$R_URL/api/sk/instalados"; }
confere "estado: desligado"                 "$(estado)" '"instalados":false'
confere "sem token = 401"                   "$(curl -s -o /dev/null -w '%{http_code}' -H 'X-GLR: 1' -d ligar=1 $R_URL/api/sk/instalados)" "401"
confere "valor invalido = 400"              "$(inst 2)" '"chave":"sk_valor"'
ANTES=$(grep -v '^\[fpkg\]$\|^installed' "$SKC")
confere "ligar (sem secao [fpkg])"          "$(inst 1)" '"ok":true,"instalados":true,"mudou":true'
confere "secao criada no fim"               "$(tail -2 "$SKC" | tr '\n' '|')" '^\[fpkg\]|installed = on|$'
confere "resto igual (diff)"                "$(diff <(echo "$ANTES") <(grep -v '^\[fpkg\]$\|^installed' "$SKC" | sed '/^$/d') && echo igual)" "igual"
confere "estado: ligado"                    "$(estado)" '"instalados":true'
confere "ligar de novo: nao muda"           "$(inst 1)" '"mudou":false'
confere "diario: ligou"                     "$(cat $DADOS/glibren.log)" 'sk-instalados: \[fpkg\] installed = on'
confere "desligar"                          "$(inst 0)" '"ok":true,"instalados":false,"mudou":true'
confere "uma linha so, off"                 "$(grep -c '^installed' "$SKC") $(grep '^installed' "$SKC")" '^1 installed = off$'
printf '[fpkg]\ndirect_mount = on\n[fakelib]\ndefault_mode = full\n[api]\nport = 10101\nbind_address = 0.0.0.0\n' > "$SKC"
confere "[fpkg] no meio: ligar"             "$(inst 1)" '"instalados":true'
confere "installed dentro da [fpkg]"        "$(tr '\n' '|' < "$SKC")" '^\[fpkg\]|direct_mount = on|installed = on|\[fakelib\]|'
printf '[fpkg]\ninstalled = off ; comentario\ndirect_mount = on\ninstalled = yes\n' > "$SKC"
confere "repetida: le a ultima (yes)"       "$(estado)" '"instalados":true'
confere "repetida: desligar deixa uma"      "$(inst 0; tr '\n' '|' < "$SKC")" '\[fpkg\]|installed = off|direct_mount = on|$'
printf 'api_port = 10101\nscan_depth = 2\n' > "$SKC"
confere "v1 (sem secoes): ligar"            "$(inst 1; tr '\n' '|' < "$SKC")" 'scan_depth = 2|fpkg_installed = on|$'
confere "v1: estado ligado"                 "$(estado)" '"instalados":true'
printf '[general]\ndebug = off\n[api]\nport = 10101\nbind_address = 0.0.0.0\n[scan]\ndepth = 2\npath = /data/homebrew\n' > "$SKC"
confere "pagina: chave dos instalados"      "$(curl -s --compressed $L/payloads)" 'chk-sk-inst'
confere "pagina: textos instalados pt/en/es" "$(curl -s --compressed $L/payloads)" 'skp_inst: "Ejecutar también los juegos instalados por el sistema"'

echo "--- pagina"
P=$(curl -s --compressed $L/payloads)
confere "pagina: secao das pastas"          "$P" 'class="skp"'
confere "pagina: rota /api/sk/pastas"       "$P" '/api/sk/pastas/conferir'
confere "pagina: textos pt/en/es"           "$P" 'skp_tit: "📂 ShadowKraken folders"'

echo "--- pagina no Edge/Chrome do Windows (360 e 1280 px), se houver"
sk_estado "$CONF"
NODE_WIN="/mnt/c/Program Files/nodejs/node.exe"
LAD=$(cmd.exe /c 'echo %LOCALAPPDATA%' 2>/dev/null | tr -d '\r')
PW=""; [ -n "$LAD" ] && PW=$(ls -d "$(wslpath "$LAD")"/npm-cache/_npx/*/node_modules/playwright 2>/dev/null | head -1)
if [ -x "$NODE_WIN" ] && [ -n "$PW" ]; then
  for modo in normal fora; do
    [ $modo = fora ] && pkill -f "smp_falso.py $PORTA_SMP"
    SAIDA=$("$NODE_WIN" "$(wslpath -w "$ORIGEM/testes/teste_sk_pastas_pagina.mjs")" "$R_URL" "$(wslpath -w "$PW")" "$TOKEN" "$R" $modo ${GLR_FOTOS:-} 2>&1)
    echo "$SAIDA"
    ok=$((ok + $(echo "$SAIDA" | grep -c '^OK '))); falhas=$((falhas + $(echo "$SAIDA" | grep -c '^FALHA')))
    echo "$SAIDA" | grep -q '^=== pagina' || { falhas=$((falhas+1)); echo "FALHA pagina ($modo): o script nao terminou"; }
  done
  confere "pagina: diario adicionou/removeu"  "$(cat $DADOS/glibren.log)" "sk-pastas: removeu /mnt/ext0/novos; antes \[/data/homebrew, /mnt/ext0/gamez, /mnt/ext0/novos\]"
else
  echo "PULADO: teste da pagina (sem node.exe ou Playwright no Windows)"
fi

kill $PID 2>/dev/null; wait $PID 2>/dev/null
pkill -f "smp_falso.py $PORTA_SMP" 2>/dev/null
rm -rf "$T"
echo "=== $ok ok, $falhas falhas"
[ $falhas -eq 0 ]
