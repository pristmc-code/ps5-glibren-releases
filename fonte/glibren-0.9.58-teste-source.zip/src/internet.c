/* Game Library Renamer (payload PS5) - teste de velocidade da internet, feito pelo proprio PS5.

Servidores: os mais proximos do PS5 na lista publica do speedtest.net (a lista muda conforme a regiao de quem
pede) ou a Cloudflare (speed.cloudflare.com). No automatico mede o ping dos mais proximos e usa o mais rapido que
responder; se nenhum responder, usa a Cloudflare.
1. Ping/jitter: tempo para abrir uma conexao TCP com o servidor (uma ida e volta), 10 vezes.
2. Download: 4 conexoes em paralelo baixando blocos de 25 MB por ~10 s; conta os bytes recebidos (sem guardar).
3. Upload: 4 conexoes enviando blocos de 4 MB por ~8 s.
Velocidade em Mbps (megabits por segundo, como os sites de teste). Um teste por vez.
0.9.52: so respostas 2xx contam (antes o corpo de um 429 da Cloudflare contava como download e o teste parecia pular o
download); download sem nenhuma resposta 2xx e falha. No automatico um servidor da lista que recusa o teste passa para
o proximo da lista (pelo ping) e so no fim para a Cloudflare; um 429 da Cloudflare deixa ela de fora por Retry-After
(ou 5 min). O glibren.log registra o servidor escolhido, o motivo e o resultado de cada fase.
*/
#include "internet.h"

#include <ctype.h>
#include <netdb.h>
#include <netinet/in.h>
#include <pthread.h>
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#include "https.h"
#include "plataforma.h"

#define CLOUDFLARE "speed.cloudflare.com"
#define LISTA_URL "https://www.speedtest.net/api/js/servers?engine=js&https_functional=true&limit=10"
#define LISTA_VALIDADE (30 * 60)
#define MAX_SRV 10
#define CANDIDATOS 5
#define CONEXOES 4
#define TEMPO_DOWN 10.0
#define TEMPO_UP 8.0
#define BLOCO_DOWN 25000000
#define BLOCO_UP (4 * 1024 * 1024)
#define PINGS 10
#define MAX_HIST 20

typedef struct {
  double ping, jitter, down, up;
  time_t quando;
  char servidor[200];
} resultado_t;

typedef struct {
  char host[128];   /* host:porta */
  char nome[96];    /* empresa */
  char local[96];   /* cidade */
  int km;
} servidor_t;

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static int g_rodando;
static volatile int g_cancelar;
static char g_fase[16], g_erro[160];
static double g_ping = -1, g_jitter = -1, g_down = -1, g_up = -1, g_atual, g_progresso;
static resultado_t g_hist[MAX_HIST];
static int g_qtd;

static servidor_t g_srv[MAX_SRV];
static int g_nsrv;
static time_t g_lista_quando;

/* servidor do teste atual (ou do ultimo) */
static char g_usado_nome[96], g_usado_local[96], g_escolha[128];
static char g_url_down[256], g_url_up[256], g_ping_host[128], g_ping_porta[8];

/* contagem compartilhada pelas conexoes */
static long long g_bytes;
static double g_inicio, g_fim_previsto;
/* 0.9.52: respostas da fase atual (2xx e recusadas), ultimo codigo recusado e o maior Retry-After */
static int g_ok, g_recusas, g_codigo, g_retry;
static volatile int g_parar_fase;
/* 0.9.52: a Cloudflare respondeu 429: fica de fora do automatico (e avisa se escolhida) ate esta hora */
static time_t g_cf_ate;
/* 0.9.52: automatico: candidatos da lista ordenados pelo ping, e qual e o proximo a tentar */
static servidor_t g_cand[MAX_SRV];
static double g_cand_ping[MAX_SRV];
static int g_ncand, g_icand;

/* So no PC, so nos testes: servidor falso no lugar da Cloudflare e dos servidores da lista (GLR_TESTE_INTERNET=
   http://127.0.0.1:PORTA/). Os hosts da lista falsa sao "<nome>.teste:<porta>" -> <base><nome>/... */
static const char *base_teste(void) {
#ifndef __PROSPERO__
  const char *b = getenv("GLR_TESTE_INTERNET");
  if(b && !strncmp(b, "http://127.0.0.1:", 17)) return b;
#endif
  return NULL;
}

static const char *porta_teste(void) {
  static char porta[8];
  const char *b = base_teste();
  snprintf(porta, sizeof porta, "%.*s", (int)strspn(b + 17, "0123456789"), b + 17);
  return porta;
}

static double agora(void) {
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec / 1e6;
}

static void fase(const char *f) {
  pthread_mutex_lock(&g_trava);
  snprintf(g_fase, sizeof g_fase, "%s", f);
  g_atual = 0;
  g_progresso = 0;
  pthread_mutex_unlock(&g_trava);
}

static int recebeu(const void *dados, size_t n, void *ctx) {
  (void)dados;
  (void)ctx;
  pthread_mutex_lock(&g_trava);
  g_bytes += n;
  double d = agora() - g_inicio;
  if(d > 0.3) g_atual = g_bytes * 8 / d / 1e6;
  g_progresso = d / (g_fim_previsto - g_inicio);
  pthread_mutex_unlock(&g_trava);
  return g_cancelar || agora() >= g_fim_previsto;   /* tempo esgotado: para de receber */
}

/* 0.9.52: anota a resposta de um pedido da fase. Recusada (nao-2xx) ou sem conexao: as outras conexoes param depois
   do pedido atual (antes cada uma insistia e a Cloudflare recebia 4 pedidos recusados por rodada). */
static int anotar(int status, int retry) {
  pthread_mutex_lock(&g_trava);
  int ok = status >= 200 && status < 300;
  if(ok) {
    g_ok++;
  } else {
    g_recusas++;
    if(status > 0) g_codigo = status;
    if(retry > g_retry) g_retry = retry;
    g_parar_fase = 1;
  }
  pthread_mutex_unlock(&g_trava);
  return ok;
}

static void *conexao_down(void *arg) {
  (void)arg;
  while(!g_cancelar && !g_parar_fase && agora() < g_fim_previsto) {
    int retry = 0;
    if(!anotar(https_fluxo_ra(g_url_down, NULL, 0, recebeu, NULL, &retry), retry)) break;
  }
  return NULL;
}

static void *conexao_up(void *arg) {
  const char *corpo = arg;
  while(!g_cancelar && !g_parar_fase && agora() < g_fim_previsto) {
    int retry = 0;
    if(!anotar(https_fluxo_ra(g_url_up, corpo, BLOCO_UP, recebeu, NULL, &retry), retry)) break;
  }
  return NULL;
}

/* Roda as conexoes em paralelo por "segundos"; devolve a velocidade media em Mbps, ou -1 se nenhum pedido teve
   resposta 2xx (0.9.52: antes qualquer byte recebido, ate o corpo de um 429, virava uma velocidade). */
static double medir(void *(*fn)(void *), void *arg, double segundos) {
  pthread_t th[CONEXOES];
  int n = 0;
  g_bytes = 0;
  g_ok = g_recusas = g_codigo = g_retry = 0;
  g_parar_fase = 0;
  g_inicio = agora();
  g_fim_previsto = g_inicio + segundos;
  for(int i = 0; i < CONEXOES; i++) {
    if(!criar_thread(fn, arg, &th[n])) n++;
  }
  for(int i = 0; i < n; i++) pthread_join(th[i], NULL);
  double d = agora() - g_inicio;
  return g_ok > 0 && g_bytes > 0 && d > 0 ? g_bytes * 8 / d / 1e6 : -1;
}

/* Nome do servidor em uso, para o glibren.log. */
static void nome_usado(char *s, size_t tam) {
  pthread_mutex_lock(&g_trava);
  snprintf(s, tam, "%s%s%s", g_usado_nome, g_usado_local[0] ? " - " : "", g_usado_local);
  pthread_mutex_unlock(&g_trava);
}

/* Uma linha no glibren.log por fase medida. */
static void registrar_fase(const char *fase_nome, double mbps_medido) {
  char srv[200];
  nome_usado(srv, sizeof srv);
  if(mbps_medido >= 0)
    diario("internet: %s em %s: %.1f Mbps (%lld bytes, %d resposta(s) ok, %d recusada(s))", fase_nome, srv, mbps_medido,
           g_bytes, g_ok, g_recusas);
  else
    diario("internet: %s em %s falhou: %d resposta(s) ok, %d recusada(s), ultimo codigo %d, Retry-After %d s", fase_nome,
           srv, g_ok, g_recusas, g_codigo, g_retry);
}

static int eh_cloudflare(void) {
  pthread_mutex_lock(&g_trava);
  int cf = !strcmp(g_usado_nome, "Cloudflare");
  pthread_mutex_unlock(&g_trava);
  return cf;
}

/* Minutos (arredondados para cima) que a Cloudflare ainda fica de fora, ou 0. */
static int cf_minutos(void) {
  time_t t = time(NULL);
  return g_cf_ate > t ? (int)((g_cf_ate - t + 59) / 60) : 0;
}

/* Mensagem do 429 da Cloudflare (texto fixo sem acento: a pagina traduz). Com prazo conhecido (Retry-After ou o
   bloqueio ja anotado), diz os minutos. */
static void erro_cf_429(int com_prazo) {
  int min = cf_minutos();
  pthread_mutex_lock(&g_trava);
  if(com_prazo && min > 0)
    snprintf(g_erro, sizeof g_erro,
             "a Cloudflare limitou os testes deste PS5 (codigo 429); escolha um servidor da lista ou tente de novo em %d min",
             min);
  else
    snprintf(g_erro, sizeof g_erro,
             "a Cloudflare limitou os testes deste PS5 por alguns minutos (codigo 429); escolha um servidor da lista ou "
             "tente de novo em alguns minutos");
  pthread_mutex_unlock(&g_trava);
}

/* Uma ida e volta: tempo do connect() TCP na porta 443 (ms), ou -1. */
static double medir_ping(const struct sockaddr *end, socklen_t tam) {
  int fd = socket(end->sa_family, SOCK_STREAM, 0);
  if(fd < 0) return -1;
  struct timeval espera = {.tv_sec = 3};
  setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &espera, sizeof espera);
  double t0 = agora();
  int r = connect(fd, end, tam);
  double ms = (agora() - t0) * 1000;
  close(fd);
  return r ? -1 : ms;
}

static int comparar(const void *a, const void *b) {
  double x = *(const double *)a, y = *(const double *)b;
  return x < y ? -1 : x > y;
}

/* ---- lista de servidores (JSON do speedtest.net: lista de objetos simples) ---- */

/* Le um texto JSON a partir das aspas de abertura (desfaz \", \\, \/ e \uXXXX). */
static void ler_texto(const char *p, char *s, size_t tam) {
  size_t n = 0;
  for(p++; *p && *p != '"'; p++) {
    char tmp[4];
    int k = 1;
    tmp[0] = *p;
    if(*p == '\\' && p[1]) {
      p++;
      if(*p == 'u' && isxdigit((unsigned char)p[1]) && isxdigit((unsigned char)p[2]) && isxdigit((unsigned char)p[3]) &&
         isxdigit((unsigned char)p[4])) {
        char hex[5] = {p[1], p[2], p[3], p[4], 0};
        unsigned u = strtoul(hex, NULL, 16);
        p += 4;
        if(u < 0x80) {
          tmp[0] = (char)u;
        } else if(u < 0x800) {
          tmp[0] = (char)(0xC0 | u >> 6);
          tmp[1] = (char)(0x80 | (u & 0x3F));
          k = 2;
        } else {
          tmp[0] = (char)(0xE0 | u >> 12);
          tmp[1] = (char)(0x80 | ((u >> 6) & 0x3F));
          tmp[2] = (char)(0x80 | (u & 0x3F));
          k = 3;
        }
      } else {
        tmp[0] = *p == 'n' || *p == 't' ? ' ' : *p;
      }
    }
    if(n + k >= tam) break;
    memcpy(s + n, tmp, k);
    n += k;
  }
  s[n] = 0;
}

/* Valor de "chave" dentro do objeto [ini, fim). Devolve 1 se achou. */
static int campo(const char *ini, const char *fim, const char *chave, char *s, size_t tam) {
  char k[48];
  snprintf(k, sizeof k, "\"%s\":", chave);
  const char *p = strstr(ini, k);
  if(!p || p >= fim) return 0;
  p += strlen(k);
  while(*p == ' ') p++;
  if(*p == '"') {
    ler_texto(p, s, tam);
    return 1;
  }
  size_t n = strcspn(p, ",}");
  if(n >= tam) n = tam - 1;
  memcpy(s, p, n);
  s[n] = 0;
  return 1;
}

/* host:porta so com letras, numeros, ponto e hifen (vai para a URL e para o curl no PC); nome com pelo menos uma
   letra (R8: IP literal fica de fora) */
static int host_valido(const char *h) {
  const char *dois = strchr(h, ':');
  int letra = 0;
  if(!dois || dois == h || !dois[1] || strlen(h) >= 128) return 0;
  for(const char *p = h; p < dois; p++) {
    if(!isalnum((unsigned char)*p) && *p != '.' && *p != '-') return 0;
    letra |= isalpha((unsigned char)*p) != 0;
  }
  if(!letra) return 0;
  for(const char *p = dois + 1; *p; p++)
    if(!isdigit((unsigned char)*p)) return 0;
  return 1;
}

/* Busca a lista no speedtest.net (guarda por 30 min). */
static void carregar_lista(void) {
  pthread_mutex_lock(&g_trava);
  int valida = g_nsrv && time(NULL) - g_lista_quando < LISTA_VALIDADE;
  pthread_mutex_unlock(&g_trava);
  if(valida) return;
  buf_t b = {0};
  servidor_t novos[MAX_SRV];
  int n = 0;
  char lista_url[300];
  if(base_teste()) snprintf(lista_url, sizeof lista_url, "%sservers", base_teste());
  else snprintf(lista_url, sizeof lista_url, "%s", LISTA_URL);
  int status = https_get(lista_url, &b, 512 * 1024, 15);
  if(status == 200 && b.n) {
    buf_add(&b, "", 1);
    for(const char *p = strchr(b.d, '{'); p && n < MAX_SRV; p = strchr(p, '{')) {
      const char *fim = strchr(p, '}');
      if(!fim) break;
      servidor_t s = {0};
      char km[24] = "";
      if(campo(p, fim, "host", s.host, sizeof s.host) && host_valido(s.host)) {
        campo(p, fim, "sponsor", s.nome, sizeof s.nome);
        campo(p, fim, "name", s.local, sizeof s.local);
        campo(p, fim, "distance", km, sizeof km);
        s.km = atoi(km);
        novos[n++] = s;
        https_permitir_host(s.host);
      }
      p = fim + 1;
    }
  }
  buf_free(&b);
  if(!n) {   /* sem internet ou site fora: fica a lista anterior */
    diario("internet: lista do speedtest.net sem servidores (status %d); fica a anterior (%d)", status, g_nsrv);
    return;
  }
  for(int i = 1; i < n; i++) {   /* mais perto primeiro (a lista do site vem fora de ordem) */
    servidor_t s = novos[i];
    int j = i;
    for(; j > 0 && novos[j - 1].km > s.km; j--) novos[j] = novos[j - 1];
    novos[j] = s;
  }
  pthread_mutex_lock(&g_trava);
  memcpy(g_srv, novos, sizeof *novos * n);
  g_nsrv = n;
  g_lista_quando = time(NULL);
  pthread_mutex_unlock(&g_trava);
}

void internet_servidores(buf_t *b) {
  carregar_lista();
  pthread_mutex_lock(&g_trava);
  buf_str(b, "{\"ok\":true,\"servidores\":[");
  for(int i = 0; i < g_nsrv; i++) {
    buf_str(b, i ? ",{\"id\":" : "{\"id\":");
    buf_json(b, g_srv[i].host);
    buf_str(b, ",\"nome\":");
    buf_json(b, g_srv[i].nome);
    buf_str(b, ",\"local\":");
    buf_json(b, g_srv[i].local);
    buf_fmt(b, ",\"km\":%d}", g_srv[i].km);
  }
  buf_str(b, "]}");
  pthread_mutex_unlock(&g_trava);
}

static void usar_cloudflare(void) {
  if(base_teste()) {
    snprintf(g_url_down, sizeof g_url_down, "%scf/__down?bytes=%d", base_teste(), BLOCO_DOWN);
    snprintf(g_url_up, sizeof g_url_up, "%scf/__up", base_teste());
    snprintf(g_ping_host, sizeof g_ping_host, "127.0.0.1");
    snprintf(g_ping_porta, sizeof g_ping_porta, "%s", porta_teste());
  } else {
    snprintf(g_url_down, sizeof g_url_down, "https://" CLOUDFLARE "/__down?bytes=%d", BLOCO_DOWN);
    snprintf(g_url_up, sizeof g_url_up, "https://" CLOUDFLARE "/__up");
    snprintf(g_ping_host, sizeof g_ping_host, CLOUDFLARE);
    snprintf(g_ping_porta, sizeof g_ping_porta, "443");
  }
  pthread_mutex_lock(&g_trava);
  snprintf(g_usado_nome, sizeof g_usado_nome, "Cloudflare");
  g_usado_local[0] = 0;
  pthread_mutex_unlock(&g_trava);
}

/* Endereco de um caminho do servidor da lista (no teste: <base><nome>/<caminho>). */
static void url_servidor(const servidor_t *s, const char *caminho, char *url, size_t tam) {
  if(base_teste()) snprintf(url, tam, "%s%.*s/%s", base_teste(), (int)strcspn(s->host, ".:"), s->host, caminho);
  else snprintf(url, tam, "https://%s/%s", s->host, caminho);
}

static void usar_servidor(const servidor_t *s) {
  size_t n = strcspn(s->host, ":");
  char caminho[64];
  snprintf(caminho, sizeof caminho, "download?size=%d", BLOCO_DOWN);
  url_servidor(s, caminho, g_url_down, sizeof g_url_down);
  url_servidor(s, "upload", g_url_up, sizeof g_url_up);
  if(base_teste()) {
    snprintf(g_ping_host, sizeof g_ping_host, "127.0.0.1");
    snprintf(g_ping_porta, sizeof g_ping_porta, "%s", porta_teste());
  } else {
    snprintf(g_ping_host, sizeof g_ping_host, "%.*s", (int)n, s->host);
    snprintf(g_ping_porta, sizeof g_ping_porta, "%s", s->host + n + 1);
  }
  pthread_mutex_lock(&g_trava);
  snprintf(g_usado_nome, sizeof g_usado_nome, "%s", s->nome);
  snprintf(g_usado_local, sizeof g_usado_local, "%s", s->local);
  pthread_mutex_unlock(&g_trava);
}

/* Menor tempo de conexao TCP em "vezes" tentativas (ms), ou -1. */
static double ping_rapido(const servidor_t *s, int vezes) {
  size_t k = strcspn(s->host, ":");
  char host[128], porta[8];
  snprintf(host, sizeof host, "%.*s", (int)k, s->host);
  snprintf(porta, sizeof porta, "%s", s->host + k + 1);
  if(base_teste()) {
    snprintf(host, sizeof host, "127.0.0.1");
    snprintf(porta, sizeof porta, "%s", porta_teste());
  }
  struct addrinfo dica = {.ai_family = AF_INET, .ai_socktype = SOCK_STREAM}, *res = NULL;
  double melhor = -1;
  if(getaddrinfo(host, porta, &dica, &res) || !res) return -1;
  for(int i = 0; i < vezes && !g_cancelar; i++) {
    double ms = medir_ping(res->ai_addr, res->ai_addrlen);
    if(ms >= 0 && (melhor < 0 || ms < melhor)) melhor = ms;
  }
  freeaddrinfo(res);
  return melhor;
}

/* O servidor entrega um bloco pequeno? (alguns da lista recusam o teste) */
static int responde(const servidor_t *s) {
  char url[300];
  url_servidor(s, "download?size=100000", url, sizeof url);
  buf_t b = {0};
  int ok = https_get(url, &b, 1024 * 1024, 8) == 200 && b.n >= 50000;
  buf_free(&b);
  return ok;
}

/* Automatico: proximo candidato da lista (pelo ping) que entrega o bloco pequeno de prova; no fim, a Cloudflare (se
   nao estiver limitando este PS5). 0 = ok; -1 = nenhum (mensagem em g_erro). "motivo" vai para o glibren.log. */
static int proximo_automatico(const char *motivo) {
  while(g_icand < g_ncand && !g_cancelar) {
    const servidor_t *s = &g_cand[g_icand];
    double ping = g_cand_ping[g_icand];
    g_icand++;
    if(responde(s)) {
      usar_servidor(s);
      diario("internet: servidor %s - %s (automatico, %s; ping %.0f ms)", s->nome, s->local, motivo, ping);
      return 0;
    }
    diario("internet: %s - %s recusou o bloco de prova; tentando o proximo", s->nome, s->local);
  }
  if(g_cancelar) return -1;
  if(cf_minutos() > 0) {
    diario("internet: nenhum servidor da lista serviu e a Cloudflare limitou este PS5 por mais %d min", cf_minutos());
    erro_cf_429(1);
    return -1;
  }
  usar_cloudflare();
  diario("internet: servidor Cloudflare (automatico: nenhum dos %d servidores da lista serviu; %s)", g_ncand, motivo);
  return 0;
}

/* Define o servidor do teste. 0 = ok; -1 = o escolhido nao respondeu (mensagem em g_erro). */
static int escolher_servidor(const char *escolha) {
  if(!strcmp(escolha, "cloudflare")) {
    if(cf_minutos() > 0) {
      diario("internet: Cloudflare escolhida, mas ela limitou este PS5 por mais %d min", cf_minutos());
      erro_cf_429(1);
      return -1;
    }
    usar_cloudflare();
    diario("internet: servidor Cloudflare (escolhido)");
    return 0;
  }
  carregar_lista();
  servidor_t lista[MAX_SRV];
  pthread_mutex_lock(&g_trava);
  int n = g_nsrv;
  memcpy(lista, g_srv, sizeof *lista * n);
  pthread_mutex_unlock(&g_trava);

  if(escolha[0] && strcmp(escolha, "auto")) {   /* servidor escolhido na lista */
    for(int i = 0; i < n; i++) {
      if(strcmp(lista[i].host, escolha)) continue;
      if(responde(&lista[i])) {
        usar_servidor(&lista[i]);
        diario("internet: servidor %s - %s (escolhido)", lista[i].nome, lista[i].local);
        return 0;
      }
      break;
    }
    diario("internet: o servidor escolhido (%s) nao respondeu", escolha);
    pthread_mutex_lock(&g_trava);
    snprintf(g_erro, sizeof g_erro, "o servidor escolhido nao respondeu; escolha outro");
    pthread_mutex_unlock(&g_trava);
    return -1;
  }

  /* automatico: ping dos mais proximos; os que responderam, do menor ping para o maior */
  double ping[CANDIDATOS];
  int m = n < CANDIDATOS ? n : CANDIDATOS;
  for(int i = 0; i < m; i++) {
    ping[i] = g_cancelar ? -1 : ping_rapido(&lista[i], 3);
    pthread_mutex_lock(&g_trava);
    g_progresso = (double)(i + 1) / m;
    pthread_mutex_unlock(&g_trava);
  }
  g_ncand = g_icand = 0;
  for(int vez = 0; vez < m; vez++) {
    /* menor ping; empate (ate 1 ms de diferenca) fica com o mais perto da lista (ela vem ordenada pela distancia) */
    double menor = -1;
    for(int i = 0; i < m; i++)
      if(ping[i] >= 0 && (menor < 0 || ping[i] < menor)) menor = ping[i];
    if(menor < 0) break;
    int melhor = -1;
    for(int i = 0; i < m && melhor < 0; i++)
      if(ping[i] >= 0 && ping[i] <= menor + 1.0) melhor = i;
    g_cand[g_ncand] = lista[melhor];
    g_cand_ping[g_ncand++] = ping[melhor];
    ping[melhor] = -1;
  }
  char motivo[96];
  if(!n) snprintf(motivo, sizeof motivo, "lista do speedtest.net vazia");
  else if(!g_ncand) snprintf(motivo, sizeof motivo, "nenhum dos %d mais proximos respondeu ao ping", m);
  else snprintf(motivo, sizeof motivo, "menor ping");
  return proximo_automatico(motivo);
}

static void *testar(void *arg) {
  (void)arg;
  double down = -1, up = -1, ping = -1, jitter = -1;
  char *corpo = NULL;

  /* 0. servidor */
  fase("escolha");
  char escolha[128];
  pthread_mutex_lock(&g_trava);
  snprintf(escolha, sizeof escolha, "%s", g_escolha);
  pthread_mutex_unlock(&g_trava);
  if(escolher_servidor(escolha) || g_cancelar) goto fim;
  int automatico = strcmp(escolha, "cloudflare") && (!escolha[0] || !strcmp(escolha, "auto"));

de_novo:
  /* 1. ping */
  fase("ping");
  double tempos[PINGS];
  int qtd = 0;
  struct addrinfo dica = {.ai_family = AF_INET, .ai_socktype = SOCK_STREAM}, *res = NULL;
  if(!getaddrinfo(g_ping_host, g_ping_porta, &dica, &res) && res) {
    for(int i = 0; i < PINGS && !g_cancelar; i++) {
      double ms = medir_ping(res->ai_addr, res->ai_addrlen);
      if(ms >= 0) tempos[qtd++] = ms;
      pthread_mutex_lock(&g_trava);
      g_progresso = (double)(i + 1) / PINGS;
      if(ms >= 0) g_atual = ms;
      pthread_mutex_unlock(&g_trava);
      usleep(150000);
    }
  }
  if(res) freeaddrinfo(res);
  if(!qtd) {
    pthread_mutex_lock(&g_trava);
    snprintf(g_erro, sizeof g_erro, "sem conexao com o servidor de teste");
    pthread_mutex_unlock(&g_trava);
    goto fim;
  }
  /* descarta a primeira (aquece DNS/rota) e as muito fora do padrao (> 3x a mediana), como os sites de teste */
  double ordem[PINGS];
  memcpy(ordem, tempos, sizeof(double) * qtd);
  qsort(ordem, qtd, sizeof *ordem, comparar);
  double mediana = ordem[qtd / 2];
  double bons[PINGS];
  int n = 0;
  for(int i = qtd > 3 ? 1 : 0; i < qtd; i++) {
    if(tempos[i] <= mediana * 3) bons[n++] = tempos[i];
  }
  double soma_dif = 0;
  for(int i = 1; i < n; i++) soma_dif += bons[i] > bons[i - 1] ? bons[i] - bons[i - 1] : bons[i - 1] - bons[i];
  jitter = n > 1 ? soma_dif / (n - 1) : 0;
  qsort(bons, n, sizeof *bons, comparar);
  ping = n ? bons[n / 2] : mediana;   /* mediana */
  pthread_mutex_lock(&g_trava);
  g_ping = ping;
  g_jitter = jitter;
  pthread_mutex_unlock(&g_trava);

  /* 2. download */
  if(g_cancelar) goto fim;
  fase("download");
  /* no PC com servidor falso (testes) as fases duram 2 s */
  down = medir(conexao_down, NULL, base_teste() ? 2.0 : TEMPO_DOWN);
  if(!g_cancelar) registrar_fase("download", down);
  if(down < 0 && !g_cancelar) {
    int cf = eh_cloudflare();
    if(cf && g_codigo == 429) g_cf_ate = time(NULL) + (g_retry > 0 ? g_retry : 300);
    /* alguns servidores da lista aceitam o bloco pequeno de prova mas recusam o teste de verdade: o proximo da
       lista e, no fim, a Cloudflare */
    if(automatico && !cf) {
      char motivo[96];
      snprintf(motivo, sizeof motivo, "o anterior recusou o download (codigo %d)", g_codigo);
      if(proximo_automatico(motivo)) goto fim;
      pthread_mutex_lock(&g_trava);
      g_ping = g_jitter = -1;
      pthread_mutex_unlock(&g_trava);
      goto de_novo;
    }
    if(cf && g_codigo == 429) {
      erro_cf_429(g_retry > 0);
    } else {
      pthread_mutex_lock(&g_trava);
      if(g_codigo > 0)
        snprintf(g_erro, sizeof g_erro, "o servidor recusou o download (codigo %d); escolha outro", g_codigo);
      else
        snprintf(g_erro, sizeof g_erro, "o servidor nao completou o download; escolha outro");
      pthread_mutex_unlock(&g_trava);
    }
    goto fim;
  }
  pthread_mutex_lock(&g_trava);
  g_down = down;
  pthread_mutex_unlock(&g_trava);

  /* 3. upload */
  if(g_cancelar) goto fim;
  fase("upload");
  corpo = malloc(BLOCO_UP);
  if(corpo) {
    for(int i = 0; i < BLOCO_UP; i++) corpo[i] = (char)(i * 31 + 17);
    up = medir(conexao_up, corpo, base_teste() ? 2.0 : TEMPO_UP);
    if(!g_cancelar) registrar_fase("upload", up);
  }
  pthread_mutex_lock(&g_trava);
  g_up = up;
  /* 0.9.52: upload recusado: o download vale e vai para o historico; a tela diz o motivo */
  if(up < 0 && !g_cancelar && !g_erro[0]) {
    if(g_codigo > 0) snprintf(g_erro, sizeof g_erro, "o servidor recusou o upload (codigo %d)", g_codigo);
    else snprintf(g_erro, sizeof g_erro, "o servidor nao completou o upload");
  }
  if(!g_cancelar) {
    if(g_qtd == MAX_HIST) memmove(g_hist, g_hist + 1, sizeof *g_hist * --g_qtd);
    resultado_t novo = {ping, jitter, down, up, time(NULL), ""};
    snprintf(novo.servidor, sizeof novo.servidor, "%s%s%s", g_usado_nome, g_usado_local[0] ? " - " : "", g_usado_local);
    g_hist[g_qtd++] = novo;
  }
  pthread_mutex_unlock(&g_trava);

fim:
  free(corpo);
  pthread_mutex_lock(&g_trava);
  if(g_cancelar && !g_erro[0]) snprintf(g_erro, sizeof g_erro, "cancelado");
  g_fase[0] = 0;
  g_rodando = 0;
  pthread_mutex_unlock(&g_trava);
  return NULL;
}

int internet_testar(const char *servidor, char *msg, size_t tam) {
  pthread_mutex_lock(&g_trava);
  if(g_rodando) {
    pthread_mutex_unlock(&g_trava);
    snprintf(msg, tam, "ja tem um teste rodando");
    return -1;
  }
  snprintf(g_escolha, sizeof g_escolha, "%s", servidor ? servidor : "");
  g_usado_nome[0] = g_usado_local[0] = 0;
  g_rodando = 1;
  g_cancelar = 0;
  g_erro[0] = 0;
  g_ping = g_jitter = g_down = g_up = -1;
  pthread_mutex_unlock(&g_trava);
  if(criar_thread(testar, NULL, NULL)) {
    g_rodando = 0;
    snprintf(msg, tam, "nao iniciou o teste");
    return -1;
  }
  return 0;
}

void internet_cancelar(void) {
  g_cancelar = 1;
}

void internet_estado(buf_t *b) {
  pthread_mutex_lock(&g_trava);
  buf_fmt(b, "{\"ok\":true,\"rodando\":%s,\"fase\":", g_rodando ? "true" : "false");
  buf_json(b, g_fase);
  buf_fmt(b, ",\"atual\":%.2f,\"progresso\":%.3f,\"ping\":%.1f,\"jitter\":%.1f,\"down\":%.2f,\"up\":%.2f,\"erro\":", g_atual,
          g_progresso > 1 ? 1.0 : g_progresso, g_ping, g_jitter, g_down, g_up);
  buf_json(b, g_erro);
  buf_str(b, ",\"servidor\":{\"nome\":");
  buf_json(b, g_usado_nome);
  buf_str(b, ",\"local\":");
  buf_json(b, g_usado_local);
  buf_str(b, "},\"historico\":[");
  for(int i = 0; i < g_qtd; i++) {
    buf_fmt(b, "%s{\"ping\":%.1f,\"jitter\":%.1f,\"down\":%.2f,\"up\":%.2f,\"quando\":%lld,\"servidor\":", i ? "," : "",
            g_hist[i].ping, g_hist[i].jitter, g_hist[i].down, g_hist[i].up, (long long)g_hist[i].quando);
    buf_json(b, g_hist[i].servidor);
    buf_str(b, "}");
  }
  buf_str(b, "]}");
  pthread_mutex_unlock(&g_trava);
}
