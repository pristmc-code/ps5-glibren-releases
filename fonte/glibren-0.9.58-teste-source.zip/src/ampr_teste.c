/* Game Library Renamer (payload PS5) - 0.9.51: build de teste do ampr-emu-ng no ShadowKraken (ver ampr_teste.h).
   0.9.55: guarda e mostra o nome do arquivo escolhido (dados em <dados>/ampr-teste/).
   0.9.57: ampr-emu-ng no fakelib/ de um backport (jogos que nao sao .pkg).
   0.9.58: listas por jogo do ShadowKraken (ampr_add.txt e playgo_off.txt) pela pagina Payloads. */
#include "ampr_teste.h"

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "config.h"
#include "fps.h"
#include "lancador.h"
#include "payloads.h"
#include "plataforma.h"
#include "sha256.h"

#define AMPR_MIN (64u * 1024)          /* os runtimes reais tem 700-850 KB */
#define AMPR_MAX (8u * 1024 * 1024)    /* = MAX_CORPO do http.c */
#define AMPR_TRACE_MAX (32u * 1024 * 1024)
#define AMPR_PARADO_S 3                /* o trace so e copiado parado ha 3 s (o jogo ainda pode estar gravando) */

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static int g_ocupado;

/* ------------------------------------------------------------------ caminhos */

/* No PC os testes trocam /data por uma pasta (GLR_TESTE_MONTADOR, a mesma do diagnostico). */
static const char *raiz_data(void) {
#ifndef __PROSPERO__
  const char *r = getenv("GLR_TESTE_MONTADOR");
  if(r && *r) return r;
#endif
  return "/data";
}

/* [emulators] path = ... do /data/shadowmount/config.ini (padrao /data/shadowmount/emus). No PC, um caminho que comeca
   em /data vira a pasta de teste. */
static void pasta_emus(char *saida, size_t tam) {
  char cfg[700], linha[512], secao[64] = "", achado[400] = "";
  snprintf(cfg, sizeof cfg, "%s/shadowmount/config.ini", raiz_data());
  FILE *f = fopen(cfg, "r");
  if(f) {
    while(fgets(linha, sizeof linha, f)) {
      char *l = linha;
      while(*l == ' ' || *l == '\t') l++;
      l[strcspn(l, "\r\n")] = 0;
      if(*l == '[') {
        snprintf(secao, sizeof secao, "%.*s", (int)strcspn(l + 1, "]"), l + 1);
        continue;
      }
      if(strcasecmp(secao, "emulators")) continue;
      if(strncasecmp(l, "path", 4) || (l[4] != ' ' && l[4] != '=' && l[4] != '\t')) continue;
      char *v = strchr(l, '=');
      if(!v) continue;
      for(v++; *v == ' ' || *v == '\t'; v++) {}
      size_t n = strlen(v);
      while(n && (v[n - 1] == ' ' || v[n - 1] == '\t' || v[n - 1] == '/')) v[--n] = 0;
      if(v[0] == '/' && !strstr(v, "..")) snprintf(achado, sizeof achado, "%s", v);
    }
    fclose(f);
  }
  if(!achado[0]) snprintf(achado, sizeof achado, "/data/shadowmount/emus");
  if(!strncmp(achado, "/data/", 6) || !strcmp(achado, "/data")) snprintf(saida, tam, "%s%s", raiz_data(), achado + 5);
  else snprintf(saida, tam, "%s", achado);
}

static void caminho_runtime(char *saida, size_t tam, const char *ext) {
  char emus[600];
  pasta_emus(emus, sizeof emus);
  snprintf(saida, tam, "%s/ampr-emu-ng/libSceAmpr.sprx%s", emus, ext ? ext : "");
}

static void caminho_trace(char *saida, size_t tam) { snprintf(saida, tam, "%s/ampr_emu_trace.txt", raiz_data()); }
static void pasta_traces(char *saida, size_t tam) { snprintf(saida, tam, "%s/ampr-traces", g_pasta_dados); }

/* ------------------------------------------------------------------ conferir um runtime */

typedef struct {
  char versao[24];     /* "0.5.0" */
  char commit[16];     /* so no de depuracao ("5a8cca6"), quando acha */
  int depuracao;       /* 1 = build de depuracao (grava /data/ampr_emu_trace.txt) */
  char sha256[65];
  size_t tamanho;
} runtime_t;

static const char *achar(const char *d, size_t n, const char *agulha) {
  size_t k = strlen(agulha);
  if(n < k) return NULL;
  for(size_t i = 0; i + k <= n; i++)
    if(d[i] == agulha[0] && !memcmp(d + i, agulha, k)) return d + i;
  return NULL;
}

static int eh_hex(char c) { return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'); }

/* Confere o .sprx (ja na memoria). 0 = serve; senao o motivo em erro. */
static int conferir(const char *d, size_t n, runtime_t *rt, char *erro, size_t tam_erro) {
  memset(rt, 0, sizeof *rt);
  if(n < AMPR_MIN || n > AMPR_MAX) {
    snprintf(erro, tam_erro, "tamanho fora do limite (%zu bytes; aceito de 64 KB a 8 MB)", n);
    return -1;
  }
  if(memcmp(d, "\x4f\x15\x3d\x1d", 4) && memcmp(d, "\x7f" "ELF", 4)) {
    snprintf(erro, tam_erro, "nao e um SELF/ELF (.sprx)");
    return -1;
  }
  /* "ampr-emu-ng X.Y.Z" (o mesmo marcador que o ShadowKraken le em sm_ampr_ng_read_version) */
  const char *m = d;
  size_t resto = n;
  while((m = achar(m, resto, "ampr-emu-ng "))) {
    const char *v = m + 12;
    size_t i = 0;
    while(v + i < d + n && i < sizeof rt->versao - 1 && ((v[i] >= '0' && v[i] <= '9') || v[i] == '.')) i++;
    if(i >= 5 && v[0] >= '0' && v[0] <= '9') {
      memcpy(rt->versao, v, i);
      rt->versao[i] = 0;
      break;
    }
    resto = (size_t)(d + n - (m + 1));
    m++;
  }
  if(!rt->versao[0]) {
    snprintf(erro, tam_erro, "nao tem o marcador \"ampr-emu-ng X.Y.Z\": nao parece o ampr-emu-ng");
    return -1;
  }
  rt->depuracao = achar(d, n, "/data/ampr_emu_trace.txt") != NULL;
  if(rt->depuracao) {   /* build de depuracao: "...plain-fs 5a8cca6..." (commit curto ao lado dos nomes dos modos) */
    const char *c = achar(d, n, "plain-fs ");
    if(c) {
      c += 9;
      size_t i = 0;
      while(c + i < d + n && i < 12 && eh_hex(c[i])) i++;
      if(i >= 7) snprintf(rt->commit, sizeof rt->commit, "%.*s", (int)i, c);
    }
  }
  sha256_t s;
  uint8_t r[32];
  sha256_iniciar(&s);
  sha256_atualizar(&s, d, n);
  sha256_final(&s, r);
  sha256_hex(r, rt->sha256);
  rt->tamanho = n;
  return 0;
}

static int ler_arquivo(const char *c, buf_t *b, size_t max) {
  int fd = open(c, O_RDONLY | O_NOFOLLOW);
  struct stat st;
  if(fd < 0) return -1;
  if(fstat(fd, &st) || !S_ISREG(st.st_mode) || (size_t)st.st_size > max) {
    close(fd);
    errno = EFBIG;
    return -1;
  }
  char bloco[64 * 1024];
  ssize_t r;
  while((r = read(fd, bloco, sizeof bloco)) > 0) buf_add(b, bloco, (size_t)r);
  close(fd);
  return r < 0 ? -1 : 0;
}

/* Le e confere o runtime de um caminho (estado da pagina). 0 = existe e confere. */
static int runtime_de(const char *c, runtime_t *rt, time_t *quando) {
  struct stat st;
  if(lstat(c, &st) || !S_ISREG(st.st_mode)) return -1;
  if(quando) *quando = st.st_mtime;
  buf_t b = {0};
  char erro[200];
  int r = ler_arquivo(c, &b, AMPR_MAX) ? -1 : conferir(b.d, b.n, rt, erro, sizeof erro);
  buf_free(&b);
  return r;
}

static int ampr_criar_pastas(const char *c) {
  char t[700];
  snprintf(t, sizeof t, "%s", c);
  for(char *p = t + 1; *p; p++)
    if(*p == '/') {
      *p = 0;
      if(mkdir(t, 0777) && errno != EEXIST) return -1;
      *p = '/';
    }
  return mkdir(t, 0777) && errno != EEXIST ? -1 : 0;
}

/* ------------------------------------------------------------------ 0.9.55: dados do arquivo escolhido */

/* O dono nao sabia qual arquivo estava em uso (todos dizem "ampr-emu-ng 0.5.0"; o release nao traz o commit). O glibren
   guarda o nome do arquivo escolhido, de onde veio, tamanho, SHA-256, versao/commit e a data: "atual" = o em uso,
   "anterior" = o guardado para voltar. Ficam na pasta do glibren (<dados>/ampr-teste/), NAO na pasta de emuladores do
   ShadowKraken: o que fica la pode ir para o fakelib dos jogos. So valem se o SHA-256 guardado for o do arquivo (troca
   pelo FTP nao passa pelo glibren). Sem dados: reconhece pelo SHA-256 os builds de teste que fizemos (CONHECIDOS). */
typedef struct {
  char nome[160], origem[1024], sha256[65], versao[24], commit[16];
  long long tamanho, quando;
  int depuracao;
} meta_t;

#define ORIGEM_CELULAR "@celular"   /* enviado do celular/PC (a pagina traduz) */

typedef struct {
  const char *sha256, *nome, *corrige;   /* corrige: chave traduzida na pagina */
} conhecido_t;

static const conhecido_t CONHECIDOS[] = {
  {"0c0ac674522baafd87729ca8096102abccf9457c0d795a911d63a3232f351d28", "ampr-emu-ng-pr113-5a8cca6-release.sprx", "marvel"},
  {"b6888320e2ab2281cc068447ec09ee192d722c16ddae76258833e8f4c0e14845", "ampr-emu-ng-pr113-5a8cca6-debug.sprx", "marvel"},
  {"0696660c6c4eb267615ebe7f78677319fd8decaa768e33d98da75bbd9b84506f", "ampr-emu-ng-pr115-f7a31de-release.sprx", "hades"},
  {"fb834a5f2146f7839591db578e293caa68d56ffd6420f79f9bef8c3ca0f2bd20", "ampr-emu-ng-pr115-f7a31de-debug.sprx", "hades"},
  {"ac3fac933baceee8f5de7e112275e8b53862ccaa0036d2272fbb19cecf3d7c26", "ampr-emu-ng-pr113+pr115-a44b4d2-release.sprx", "marvel_hades"},
  {"dd382ee9554647e513555e4166f97468339f5c797bcf0af167ca75c30f561000", "ampr-emu-ng-pr113+pr115-a44b4d2-debug.sprx", "marvel_hades"},
};

/* GLR_TESTE_AMPR_CONHECIDO=<sha256>: so nos testes (os runtimes de mentira nao tem o SHA de um build real) */
static const conhecido_t *conhecido(const char *sha) {
  static const conhecido_t TESTE = {"", "ampr-emu-ng-teste-conhecido.sprx", "hades"};
  const char *t = getenv("GLR_TESTE_AMPR_CONHECIDO");
  if(t && *t && !strcmp(t, sha)) return &TESTE;
  for(size_t i = 0; i < sizeof CONHECIDOS / sizeof *CONHECIDOS; i++)
    if(!strcmp(CONHECIDOS[i].sha256, sha)) return &CONHECIDOS[i];
  return NULL;
}

static void caminho_meta(char *saida, size_t tam, const char *qual) {
  snprintf(saida, tam, "%s/ampr-teste/%s.txt", g_pasta_dados, qual);
}

/* chave=valor por linha; os valores nunca tem quebra de linha (nome_ok e o caminho do disco ja recusam controle) */
static int meta_gravar(const char *qual, const meta_t *m) {
  char c[700], tmp[720], pasta[700];
  caminho_meta(c, sizeof c, qual);
  snprintf(tmp, sizeof tmp, "%s.tmp", c);
  snprintf(pasta, sizeof pasta, "%s/ampr-teste", g_pasta_dados);
  if(ampr_criar_pastas(pasta)) return -1;
  FILE *f = fopen(tmp, "w");
  if(!f) return -1;
  fprintf(f, "nome=%s\norigem=%s\nsha256=%s\ntamanho=%lld\nversao=%s\ncommit=%s\ndepuracao=%d\nquando=%lld\n", m->nome, m->origem,
          m->sha256, m->tamanho, m->versao, m->commit, m->depuracao, m->quando);
  int ok = !fflush(f) && !fsync(fileno(f));
  if(fclose(f)) ok = 0;
  if(!ok || rename(tmp, c)) {
    unlink(tmp);
    return -1;
  }
  return 0;
}

static int meta_ler(const char *qual, meta_t *m) {
  char c[700], linha[1200];
  memset(m, 0, sizeof *m);
  caminho_meta(c, sizeof c, qual);
  FILE *f = fopen(c, "r");
  if(!f) return -1;
  while(fgets(linha, sizeof linha, f)) {
    linha[strcspn(linha, "\r\n")] = 0;
    char *v = strchr(linha, '=');
    if(!v) continue;
    *v++ = 0;
    if(!strcmp(linha, "nome")) snprintf(m->nome, sizeof m->nome, "%s", v);
    else if(!strcmp(linha, "origem")) snprintf(m->origem, sizeof m->origem, "%s", v);
    else if(!strcmp(linha, "sha256")) snprintf(m->sha256, sizeof m->sha256, "%s", v);
    else if(!strcmp(linha, "versao")) snprintf(m->versao, sizeof m->versao, "%s", v);
    else if(!strcmp(linha, "commit")) snprintf(m->commit, sizeof m->commit, "%s", v);
    else if(!strcmp(linha, "tamanho")) m->tamanho = atoll(v);
    else if(!strcmp(linha, "depuracao")) m->depuracao = atoi(v);
    else if(!strcmp(linha, "quando")) m->quando = atoll(v);
  }
  fclose(f);
  return m->nome[0] && strlen(m->sha256) == 64 ? 0 : -1;
}

/* O em uso virou o guardado: os dados vao junto (sem dados do atual, o anterior fica sem dados). */
static void meta_atual_para_anterior(void) {
  char a[700], b[700];
  caminho_meta(a, sizeof a, "atual");
  caminho_meta(b, sizeof b, "anterior");
  unlink(b);
  if(rename(a, b) && errno != ENOENT) unlink(a);
}

/* ------------------------------------------------------------------ gravar / voltar */

/* Jogo aberto: a troca so vale na proxima abertura e o fakelib dele esta montado; recusa. */
static int jogo_aberto(char *tid, size_t tam) { return app_de_jogo_aberto(tid, tam) == 1; }

/* .tmp + fsync + rename; o atual vira .anterior (*guardou = 1). 0 = ok. */
static int gravar(const buf_t *b, int *guardou, char *erro, size_t tam_erro) {
  *guardou = 0;
  char dest[700], tmp[720], ant[720], pasta[700];
  caminho_runtime(dest, sizeof dest, NULL);
  caminho_runtime(tmp, sizeof tmp, ".tmp");
  caminho_runtime(ant, sizeof ant, ".anterior");
  snprintf(pasta, sizeof pasta, "%s", dest);
  *strrchr(pasta, '/') = 0;
  if(ampr_criar_pastas(pasta)) {
    snprintf(erro, tam_erro, "nao criou a pasta %s (%s)", pasta, strerror(errno));
    return -1;
  }
  int fd = open(tmp, O_WRONLY | O_CREAT | O_TRUNC | O_NOFOLLOW, 0777);
  if(fd < 0) {
    snprintf(erro, tam_erro, "nao gravou %s (%s)", tmp, strerror(errno));
    return -1;
  }
  size_t feito = 0;
  while(feito < b->n) {
    ssize_t w = write(fd, b->d + feito, b->n - feito);
    if(w <= 0) break;
    feito += (size_t)w;
  }
  int ok = feito == b->n && !fsync(fd);
  if(close(fd)) ok = 0;
  if(!ok) {
    unlink(tmp);
    snprintf(erro, tam_erro, "erro ao gravar %s (%s)", tmp, strerror(errno));
    return -1;
  }
  chmod(tmp, 0777);
  struct stat st;
  if(!lstat(dest, &st) && S_ISREG(st.st_mode)) {
    unlink(ant);
    if(rename(dest, ant)) {
      unlink(tmp);
      snprintf(erro, tam_erro, "nao guardou o anterior (%s)", strerror(errno));
      return -1;
    }
    *guardou = 1;
  }
  if(rename(tmp, dest)) {
    snprintf(erro, tam_erro, "nao trocou o arquivo (%s)", strerror(errno));
    unlink(tmp);
    return -1;
  }
  int dfd = open(pasta, O_RDONLY);
  if(dfd >= 0) {
    fsync(dfd);
    close(dfd);
  }
  return 0;
}

static int comecar(pedido_t *p) {
  if(fps_agente_ps5(p->agente) || p->local) {
    responder_erro(p, 403, "ampr_so_celular", "o build de teste so muda pelo celular ou PC pareado", NULL);
    return -1;
  }
  char tid[16];
  if(jogo_aberto(tid, sizeof tid)) {
    responder_erro(p, 409, "ampr_jogo_aberto", "feche o jogo antes de trocar o ampr-emu-ng", tid);
    return -1;
  }
  pthread_mutex_lock(&g_trava);
  int ocupado = g_ocupado;
  g_ocupado = 1;
  pthread_mutex_unlock(&g_trava);
  if(ocupado) {
    responder_erro(p, 409, "ampr_ocupado", "outra troca do ampr-emu-ng esta andando: espere", NULL);
    return -1;
  }
  return 0;
}

static void terminar(void) {
  pthread_mutex_lock(&g_trava);
  g_ocupado = 0;
  pthread_mutex_unlock(&g_trava);
}

static void responder_ok(pedido_t *p, const runtime_t *rt, const char *nome) {
  buf_t r = {0};
  buf_str(&r, "{\"ok\":true,\"nome\":");
  buf_json(&r, nome);
  buf_str(&r, ",\"versao\":");
  buf_json(&r, rt->versao);
  buf_str(&r, ",\"commit\":");
  buf_json(&r, rt->commit);
  buf_fmt(&r, ",\"depuracao\":%s,\"tamanho\":%zu,\"sha256\":", rt->depuracao ? "true" : "false", rt->tamanho);
  buf_json(&r, rt->sha256);
  buf_str(&r, "}");
  responder_json(p, 200, &r);
  buf_free(&r);
}

static int nome_ok(const char *nome) {
  size_t n = strlen(nome);
  if(n < 6 || n >= 128 || strcasecmp(nome + n - 5, ".sprx")) return 0;
  for(const char *c = nome; *c; c++)
    if((unsigned char)*c < ' ' || *c == '/' || *c == '\\') return 0;
  return 1;
}

static void instalar(pedido_t *p, const buf_t *b, const char *nome, const char *origem, const char *origem_dados) {
  runtime_t rt;
  char erro[240] = "";
  int guardou = 0;
  if(conferir(b->d, b->n, &rt, erro, sizeof erro) || gravar(b, &guardou, erro, sizeof erro)) {
    diario("ampr-teste: recusado: %s (%s, %zu bytes)", erro, origem, b->n);
    terminar();
    responder_erro(p, 400, "ampr_arquivo_erro", erro, NULL);
    return;
  }
  if(guardou) meta_atual_para_anterior();
  meta_t m = {.tamanho = (long long)rt.tamanho, .quando = (long long)time(NULL), .depuracao = rt.depuracao};
  snprintf(m.nome, sizeof m.nome, "%s", nome);
  snprintf(m.origem, sizeof m.origem, "%s", origem_dados);
  snprintf(m.sha256, sizeof m.sha256, "%s", rt.sha256);
  snprintf(m.versao, sizeof m.versao, "%s", rt.versao);
  snprintf(m.commit, sizeof m.commit, "%s", rt.commit);
  if(meta_gravar("atual", &m)) diario("ampr-teste: aviso: nao guardou o nome do arquivo (%s)", strerror(errno));
  char dest[700];
  caminho_runtime(dest, sizeof dest, NULL);
  diario("ampr-teste: build de teste instalado: %s -> %s (ampr-emu-ng %s%s%s, %s, %zu bytes, sha256 %s); vale na proxima abertura de cada jogo",
         origem, dest, rt.versao, rt.commit[0] ? " " : "", rt.commit, rt.depuracao ? "depuracao" : "release", rt.tamanho, rt.sha256);
  terminar();
  responder_ok(p, &rt, nome);
}

void ampr_teste_rota_enviar(pedido_t *p) {
  char nome[160] = "", origem[200];
  param(p->query, "nome", 0, nome, sizeof nome);
  if(!nome_ok(nome)) {
    responder_erro(p, 400, "ampr_arquivo_nome", "escolha um arquivo .sprx", NULL);
    return;
  }
  if(comecar(p)) return;
  snprintf(origem, sizeof origem, "celular/PC: %s", nome);
  buf_t b = {.d = p->corpo, .n = p->corpo ? p->corpo_n : 0};
  instalar(p, &b, nome, origem, ORIGEM_CELULAR);
}

void ampr_teste_rota_arquivo(pedido_t *p) {
  char origem[1024] = "";
  param(p->corpo, "caminho", 0, origem, sizeof origem);
  const char *nome = strrchr(origem, '/');
  if(!nome || !nome_ok(nome + 1)) {
    responder_erro(p, 400, "ampr_arquivo_nome", "escolha um arquivo .sprx", NULL);
    return;
  }
  if(!payloads_caminho_de_disco(origem)) {
    responder_erro(p, 400, "ampr_arquivo_fora", "o arquivo tem de estar num disco do PS5 (/data, USB ou disco extra), sem links", NULL);
    return;
  }
  if(comecar(p)) return;
  buf_t b = {0};
  if(ler_arquivo(origem, &b, AMPR_MAX)) {
    char erro[240];
    snprintf(erro, sizeof erro, errno == EFBIG ? "tamanho fora do limite (aceito de 64 KB a 8 MB)" : "nao abriu o arquivo");
    buf_free(&b);
    diario("ampr-teste: recusado: %s (%s)", erro, origem);
    terminar();
    responder_erro(p, 400, "ampr_arquivo_erro", erro, NULL);
    return;
  }
  instalar(p, &b, nome + 1, origem, origem);
  buf_free(&b);
}

void ampr_teste_rota_embutido(pedido_t *p) {
  if(comecar(p)) return;
  char dest[700], ant[720];
  caminho_runtime(dest, sizeof dest, NULL);
  caminho_runtime(ant, sizeof ant, ".anterior");
  struct stat st;
  if(lstat(dest, &st)) {
    terminar();
    static const char ja[] = "{\"ok\":true,\"ja\":true}";
    responder(p, 200, "application/json", ja, sizeof ja - 1, NULL);
    return;
  }
  unlink(ant);
  if(!S_ISREG(st.st_mode) || rename(dest, ant)) {
    char erro[200];
    snprintf(erro, sizeof erro, "nao tirou o arquivo de teste (%s)", S_ISREG(st.st_mode) ? strerror(errno) : "nao e um arquivo");
    diario("ampr-teste: voltar ao embutido falhou: %s", erro);
    terminar();
    responder_erro(p, 400, "ampr_arquivo_erro", erro, NULL);
    return;
  }
  meta_atual_para_anterior();
  diario("ampr-teste: voltou ao ampr-emu-ng embutido no ShadowKraken (o de teste ficou em %s); vale na proxima abertura de cada jogo", ant);
  terminar();
  static const char feito[] = "{\"ok\":true,\"ja\":false}";
  responder(p, 200, "application/json", feito, sizeof feito - 1, NULL);
}

/* ------------------------------------------------------------------ copias do trace */

typedef struct {
  char nome[96];
  time_t quando;
  long long bytes;
} copia_t;

static int cmp_copia(const void *a, const void *b) {   /* mais nova primeiro (o nome comeca pela data-hora) */
  return strcmp(((const copia_t *)b)->nome, ((const copia_t *)a)->nome);
}

static int listar_copias(copia_t *c, int max) {
  char pasta[600];
  pasta_traces(pasta, sizeof pasta);
  DIR *d = opendir(pasta);
  if(!d) return 0;
  int n = 0;
  copia_t todas[64];
  struct dirent *e;
  while((e = readdir(d)) && n < 64) {
    size_t k = strlen(e->d_name);
    if(e->d_name[0] == '.' || k < 5 || k >= sizeof todas[0].nome || strcmp(e->d_name + k - 4, ".txt")) continue;
    char c2[700];
    struct stat st;
    snprintf(c2, sizeof c2, "%s/%s", pasta, e->d_name);
    if(lstat(c2, &st) || !S_ISREG(st.st_mode)) continue;
    snprintf(todas[n].nome, sizeof todas[n].nome, "%s", e->d_name);
    todas[n].quando = st.st_mtime;
    todas[n].bytes = (long long)st.st_size;
    n++;
  }
  closedir(d);
  qsort(todas, (size_t)n, sizeof todas[0], cmp_copia);
  for(int i = 0; i < n && i < max; i++) c[i] = todas[i];
  return n < max ? n : max;
}

/* Apaga as mais velhas, deixando AMPR_TRACES_MAX. */
static void podar(void) {
  char pasta[600];
  pasta_traces(pasta, sizeof pasta);
  copia_t c[64];
  DIR *d = opendir(pasta);
  if(!d) return;
  int n = 0;
  struct dirent *e;
  while((e = readdir(d)) && n < 64) {
    size_t k = strlen(e->d_name);
    if(e->d_name[0] == '.' || k < 5 || k >= sizeof c[0].nome || strcmp(e->d_name + k - 4, ".txt")) continue;
    snprintf(c[n++].nome, sizeof c[0].nome, "%s", e->d_name);
  }
  closedir(d);
  qsort(c, (size_t)n, sizeof c[0], cmp_copia);
  for(int i = AMPR_TRACES_MAX; i < n; i++) {
    char c2[700];
    snprintf(c2, sizeof c2, "%s/%s", pasta, c[i].nome);
    unlink(c2);
  }
}

/* Title ID no comeco do trace (PPSA/CUSA + 5 digitos); "" se nao achar. */
static void titulo_do_trace(const char *d, size_t n, char *tid) {
  tid[0] = 0;
  if(n > 64 * 1024) n = 64 * 1024;
  for(size_t i = 0; i + 9 <= n; i++) {
    if(memcmp(d + i, "PPSA", 4) && memcmp(d + i, "CUSA", 4)) continue;
    int ok = 1;
    for(int k = 4; k < 9; k++) ok &= d[i + k] >= '0' && d[i + k] <= '9';
    if(ok && (i + 9 == n || d[i + 9] < '0' || d[i + 9] > '9')) {
      memcpy(tid, d + i, 9);
      tid[9] = 0;
      return;
    }
  }
}

static int copiar_trace(const char *origem, const struct stat *st) {
  buf_t b = {0};
  if(ler_arquivo(origem, &b, AMPR_TRACE_MAX)) {
    buf_free(&b);
    return -1;
  }
  char pasta[600], tid[16], dest[760];
  pasta_traces(pasta, sizeof pasta);
  if(ampr_criar_pastas(pasta)) {
    buf_free(&b);
    return -1;
  }
  titulo_do_trace(b.d ? b.d : "", b.n, tid);
  if(!tid[0]) app_de_jogo_aberto(tid, sizeof tid);
  struct tm tm;
  time_t q = st->st_mtime;
  localtime_r(&q, &tm);
  snprintf(dest, sizeof dest, "%s/%04d-%02d-%02d_%02d%02d%02d%s%s.txt", pasta, tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
           tm.tm_hour, tm.tm_min, tm.tm_sec, tid[0] ? "-" : "", tid);
  FILE *f = fopen(dest, "wb");
  int ok = f && (!b.n || fwrite(b.d, 1, b.n, f) == b.n);
  if(f && fclose(f)) ok = 0;
  if(!ok) unlink(dest);
  else diario("ampr-teste: trace do ampr-emu-ng copiado: %s (%zu bytes%s%s)", strrchr(dest, '/') + 1, b.n, tid[0] ? ", " : "", tid);
  buf_free(&b);
  podar();
  return ok ? 0 : -1;
}

static int vigia_intervalo_ms(void) {
#ifndef __PROSPERO__
  const char *v = getenv("GLR_TESTE_AMPR_VIGIA_MS");
  if(v && atoi(v) > 0) return atoi(v);
#endif
  return 2000;
}

static int parado_s(void) {
#ifndef __PROSPERO__
  const char *v = getenv("GLR_TESTE_AMPR_PARADO_S");
  if(v) return atoi(v);
#endif
  return AMPR_PARADO_S;
}

static void *vigia(void *arg) {
  (void)arg;
  char c[700];
  caminho_trace(c, sizeof c);
  /* ao iniciar: o trace que ja existe e o do ultimo jogo; so copia se nao houver copia com a mesma data */
  long long visto_tam = -1;
  time_t visto_mtime = 0;
  copia_t ultima[1];
  struct stat st;
  if(!lstat(c, &st) && listar_copias(ultima, 1) == 1 && ultima[0].bytes == (long long)st.st_size) {
    visto_tam = (long long)st.st_size;
    visto_mtime = st.st_mtime;
  }
  for(;;) {
    usleep((useconds_t)vigia_intervalo_ms() * 1000);
    if(lstat(c, &st) || !S_ISREG(st.st_mode)) continue;
    if((long long)st.st_size == visto_tam && st.st_mtime == visto_mtime) continue;
    if(time(NULL) - st.st_mtime < parado_s()) continue;   /* ainda gravando */
    if(!copiar_trace(c, &st)) {
      visto_tam = (long long)st.st_size;
      visto_mtime = st.st_mtime;
    } else {
      visto_tam = (long long)st.st_size;   /* nao tenta de novo o mesmo arquivo a cada 2 s */
      visto_mtime = st.st_mtime;
    }
  }
  return NULL;
}

void ampr_teste_iniciar(void) {
  pthread_t t;
  if(!criar_thread(vigia, NULL, &t)) pthread_detach(t);
}

int ampr_teste_traces(char nomes[][96], char caminhos[][600], int max) {
  copia_t c[AMPR_TRACES_MAX];
  char pasta[600];
  pasta_traces(pasta, sizeof pasta);
  int n = listar_copias(c, max < AMPR_TRACES_MAX ? max : AMPR_TRACES_MAX);
  for(int i = 0; i < n; i++) {
    snprintf(nomes[i], 96, "ampr-trace-%s", c[i].nome);
    snprintf(caminhos[i], 600, "%s/%s", pasta, c[i].nome);
  }
  return n;
}

/* ------------------------------------------------------------------ estado */

static void runtime_json(buf_t *b, const char *chave, const char *c, const char *qual) {
  runtime_t rt;
  time_t q = 0;
  buf_fmt(b, ",\"%s\":", chave);
  if(runtime_de(c, &rt, &q)) {
    struct stat st;
    if(!lstat(c, &st)) {   /* existe mas nao confere: o ShadowKraken tambem nao usa */
      buf_str(b, "{\"valido\":false,\"caminho\":");
      buf_json(b, c);
      buf_str(b, "}");
    } else buf_str(b, "null");
    return;
  }
  buf_str(b, "{\"valido\":true,\"caminho\":");
  buf_json(b, c);
  buf_str(b, ",\"versao\":");
  buf_json(b, rt.versao);
  buf_str(b, ",\"commit\":");
  buf_json(b, rt.commit);
  buf_fmt(b, ",\"depuracao\":%s,\"tamanho\":%zu,\"desde\":%lld,\"sha256\":", rt.depuracao ? "true" : "false", rt.tamanho,
          (long long)q);
  buf_json(b, rt.sha256);
  meta_t m;
  int tem = !meta_ler(qual, &m) && !strcmp(m.sha256, rt.sha256);
  buf_str(b, ",\"nome\":");
  buf_json(b, tem ? m.nome : "");
  buf_str(b, ",\"origem\":");
  buf_json(b, tem ? m.origem : "");
  buf_fmt(b, ",\"instalado\":%lld,\"conhecido\":", tem ? m.quando : 0LL);
  const conhecido_t *k = conhecido(rt.sha256);
  if(k) {
    buf_str(b, "{\"nome\":");
    buf_json(b, k->nome);
    buf_str(b, ",\"corrige\":");
    buf_json(b, k->corrige);
    buf_str(b, "}");
  } else buf_str(b, "null");
  buf_str(b, "}");
}

void ampr_teste_json(buf_t *b) {
  char c[700], ant[720], emus[600];
  caminho_runtime(c, sizeof c, NULL);
  caminho_runtime(ant, sizeof ant, ".anterior");
  pasta_emus(emus, sizeof emus);
  buf_str(b, "{\"ok\":true,\"pasta_emus\":");
  buf_json(b, emus);
  runtime_json(b, "teste", c, "atual");
  runtime_json(b, "anterior", ant, "anterior");
  copia_t cp[AMPR_TRACES_MAX];
  int n = listar_copias(cp, AMPR_TRACES_MAX);
  buf_fmt(b, ",\"traces\":%d,\"ultimo_trace\":", n);
  if(n) {
    buf_str(b, "{\"nome\":");
    buf_json(b, cp[0].nome);
    buf_fmt(b, ",\"quando\":%lld,\"bytes\":%lld}", (long long)cp[0].quando, cp[0].bytes);
  } else buf_str(b, "null");
  pthread_mutex_lock(&g_trava);
  buf_fmt(b, ",\"ocupado\":%s}", g_ocupado ? "true" : "false");
  pthread_mutex_unlock(&g_trava);
}

void ampr_teste_rota_estado(pedido_t *p) {
  buf_t b = {0};
  ampr_teste_json(&b);
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* ------------------------------------------------------------------ 0.9.57: ampr-emu-ng no fakelib de um backport */

/* Jogo .exfat/pasta com backport (Horizon Zero Dawn Remastered, 0xa002c502 em 21/11): o ShadowKraken so poe o
   ampr-emu-ng no fakelib de um jogo que nao e .pkg quando o fakelib/ do jogo ou do backport ja traz um libSceAmpr.sprx
   (copy_emulator_files_to_cache troca so arquivos que existem la); sem ele o jogo usa o AMPR do sistema
   ("emulator_files=0" no log). Aqui o dono poe no <raiz>/backports/<TITULO...>/fakelib/ o mesmo runtime que o
   ShadowKraken usa (o de teste, senao o embutido) e tira de volta. O libSceAmpr.sprx que ja estava la fica guardado em
   <dados>/ampr-backport/ e volta no Tirar. A assinatura do cache de fakelib do jogo inclui os arquivos do fakelib/ do
   backport, entao vale na proxima abertura do jogo, sem reiniciar o ShadowKraken. */

#define BKP_MAX 64

/* As raizes que o ShadowKraken procura (sm_paths.h, as de disco); os backports ficam em <raiz>/backports. */
static const char *const RAIZES_BKP[] = {
  "/data/homebrew", "/data/etaHEN/games", "/mnt/ext0/homebrew", "/mnt/ext0/etaHEN/games", "/mnt/ext1/homebrew",
  "/mnt/ext1/etaHEN/games", "/mnt/usb0/homebrew", "/mnt/usb1/homebrew", "/mnt/usb2/homebrew", "/mnt/usb3/homebrew",
  "/mnt/usb4/homebrew", "/mnt/usb5/homebrew", "/mnt/usb6/homebrew", "/mnt/usb7/homebrew",
};

typedef struct {
  char caminho[600];   /* <raiz>/backports/<pasta> como o PS5 ve (/data/... mesmo no PC) */
  char real[700];      /* no disco (no PC, /data vira a pasta de teste) */
  char pasta[256];
  char titulo[10];
} backport_t;

static void caminho_real(const char *c, char *saida, size_t tam) {
  if(!strncmp(c, "/data/", 6)) snprintf(saida, tam, "%s%s", raiz_data(), c + 5);
  else snprintf(saida, tam, "%s", c);
}

/* "PPSA13427" no comeco do nome (backport_name_matches_title do ShadowKraken compara o comeco). */
static int titulo_de(const char *nome, char tid[10]) {
  for(int i = 0; i < 9; i++) {
    char c = nome[i];
    if(i < 4 ? !(c >= 'A' && c <= 'Z') : !(c >= '0' && c <= '9')) return -1;
  }
  snprintf(tid, 10, "%.9s", nome);
  return 0;
}

static int cmp_backport(const void *a, const void *b) {
  return strcmp(((const backport_t *)a)->caminho, ((const backport_t *)b)->caminho);
}

static int listar_backports(backport_t *v, int max) {
  int n = 0;
  for(size_t r = 0; r < sizeof RAIZES_BKP / sizeof *RAIZES_BKP && n < max; r++) {
    char raiz[600], real[700];
    snprintf(raiz, sizeof raiz, "%s/backports", RAIZES_BKP[r]);
    caminho_real(raiz, real, sizeof real);
    DIR *d = opendir(real);
    if(!d) continue;
    struct dirent *e;
    while((e = readdir(d)) && n < max) {
      char tid[10], c[1000];
      struct stat st;
      if(e->d_name[0] == '.' || titulo_de(e->d_name, tid) || strlen(e->d_name) >= sizeof v->pasta) continue;
      snprintf(c, sizeof c, "%s/%s", real, e->d_name);
      if(lstat(c, &st) || !S_ISDIR(st.st_mode)) continue;   /* sem links */
      backport_t *b = &v[n++];
      snprintf(b->caminho, sizeof b->caminho, "%s/%s", raiz, e->d_name);
      snprintf(b->real, sizeof b->real, "%s", c);
      snprintf(b->pasta, sizeof b->pasta, "%s", e->d_name);
      snprintf(b->titulo, sizeof b->titulo, "%s", tid);
    }
    closedir(d);
  }
  qsort(v, (size_t)n, sizeof *v, cmp_backport);
  return n;
}

static int versao_maior(const char *a, const char *b) {
  unsigned x[3] = {0}, y[3] = {0};
  sscanf(a, "%u.%u.%u", &x[0], &x[1], &x[2]);
  sscanf(b, "%u.%u.%u", &y[0], &y[1], &y[2]);
  for(int i = 0; i < 3; i++)
    if(x[i] != y[i]) return x[i] > y[i];
  return 0;
}

/* O runtime que o ShadowKraken usa: o de teste valido; senao o embutido que ele instala em fpkg-runtime (o "latest"
   so se for mais novo, como sm_ampr_resolve_ng_runtime). 0 = achou (caminho em saida). */
static int fonte_runtime(char *saida, size_t tam, runtime_t *rt, int *de_teste) {
  char c[720];
  caminho_runtime(c, sizeof c, NULL);
  *de_teste = 1;
  if(!runtime_de(c, rt, NULL)) {
    snprintf(saida, tam, "%s", c);
    return 0;
  }
  *de_teste = 0;
  char emb[700], ult[700];
  runtime_t re, ru;
  caminho_real("/data/shadowmount/fpkg-runtime/v0.4.1/ampr-emu-ng/libSceAmpr.sprx", emb, sizeof emb);
  caminho_real("/data/shadowmount/fpkg-runtime/latest/ampr-emu-ng/libSceAmpr.sprx", ult, sizeof ult);
  int tem_e = !runtime_de(emb, &re, NULL), tem_u = !runtime_de(ult, &ru, NULL);
  if(tem_u && (!tem_e || versao_maior(ru.versao, re.versao))) {
    *rt = ru;
    snprintf(saida, tam, "%s", ult);
    return 0;
  }
  if(tem_e) {
    *rt = re;
    snprintf(saida, tam, "%s", emb);
    return 0;
  }
  return -1;
}

/* Guarda do glibren por backport: <dados>/ampr-backport/<caminho com / trocado por _>.txt (+ .original.sprx). */
static void caminho_guarda(const backport_t *b, const char *ext, char *saida, size_t tam) {
  char nome[600];
  snprintf(nome, sizeof nome, "%s", b->caminho + 1);
  for(char *c = nome; *c; c++)
    if(*c == '/') *c = '_';
  snprintf(saida, tam, "%s/ampr-backport/%s%s", g_pasta_dados, nome, ext);
}

typedef struct {
  char sha256[65];     /* o que o glibren gravou */
  int tinha_original;  /* havia um libSceAmpr.sprx (guardado em .original.sprx) */
  int criou_pasta;     /* o fakelib/ nao existia */
} guarda_t;

static int guarda_ler(const backport_t *b, guarda_t *g) {
  char c[1200], linha[200];
  memset(g, 0, sizeof *g);
  caminho_guarda(b, ".txt", c, sizeof c);
  FILE *f = fopen(c, "r");
  if(!f) return -1;
  while(fgets(linha, sizeof linha, f)) {
    linha[strcspn(linha, "\r\n")] = 0;
    if(!strncmp(linha, "sha256=", 7)) snprintf(g->sha256, sizeof g->sha256, "%s", linha + 7);
    else if(!strncmp(linha, "tinha_original=", 15)) g->tinha_original = atoi(linha + 15);
    else if(!strncmp(linha, "criou_pasta=", 12)) g->criou_pasta = atoi(linha + 12);
  }
  fclose(f);
  return strlen(g->sha256) == 64 ? 0 : -1;
}

static int guarda_gravar(const backport_t *b, const guarda_t *g) {
  char c[1200], tmp[1220], pasta[700];
  snprintf(pasta, sizeof pasta, "%s/ampr-backport", g_pasta_dados);
  if(ampr_criar_pastas(pasta)) return -1;
  caminho_guarda(b, ".txt", c, sizeof c);
  snprintf(tmp, sizeof tmp, "%s.tmp", c);
  FILE *f = fopen(tmp, "w");
  if(!f) return -1;
  fprintf(f, "caminho=%s\nsha256=%s\ntinha_original=%d\ncriou_pasta=%d\nquando=%lld\n", b->caminho, g->sha256,
          g->tinha_original, g->criou_pasta, (long long)time(NULL));
  int ok = !fflush(f) && !fsync(fileno(f));
  if(fclose(f)) ok = 0;
  if(!ok || rename(tmp, c)) {
    unlink(tmp);
    return -1;
  }
  return 0;
}

/* .tmp + fsync + rename (o .tmp na mesma pasta). 0 = ok. */
static int gravar_arquivo(const char *dest, const char *d, size_t n) {
  char tmp[1300];
  snprintf(tmp, sizeof tmp, "%s.glibren.tmp", dest);
  int fd = open(tmp, O_WRONLY | O_CREAT | O_TRUNC | O_NOFOLLOW, 0777);
  if(fd < 0) return -1;
  size_t feito = 0;
  while(feito < n) {
    ssize_t w = write(fd, d + feito, n - feito);
    if(w <= 0) break;
    feito += (size_t)w;
  }
  int ok = feito == n && !fsync(fd);
  if(close(fd)) ok = 0;
  if(ok) chmod(tmp, 0777);
  if(!ok || rename(tmp, dest)) {
    int e = errno;
    unlink(tmp);
    errno = e;
    return -1;
  }
  return 0;
}

static void sha_de_arquivo(const char *c, char sha[65]) {
  sha[0] = 0;
  buf_t b = {0};
  if(!ler_arquivo(c, &b, AMPR_TRACE_MAX)) {
    sha256_t s;
    uint8_t r[32];
    sha256_iniciar(&s);
    sha256_atualizar(&s, b.d, b.n);
    sha256_final(&s, r);
    sha256_hex(r, sha);
  }
  buf_free(&b);
}

static void runtime_curto_json(buf_t *j, const runtime_t *rt) {
  buf_str(j, "\"versao\":");
  buf_json(j, rt->versao);
  buf_str(j, ",\"commit\":");
  buf_json(j, rt->commit);
  buf_fmt(j, ",\"depuracao\":%s,\"sha256\":", rt->depuracao ? "true" : "false");
  buf_json(j, rt->sha256);
  const conhecido_t *k = conhecido(rt->sha256);
  buf_str(j, ",\"conhecido\":");
  if(k) buf_json(j, k->nome);
  else buf_str(j, "null");
}

static void backport_json(buf_t *j, const backport_t *b) {
  char c[1000], sha[65];
  struct stat st;
  buf_str(j, "{\"caminho\":");
  buf_json(j, b->caminho);
  buf_str(j, ",\"pasta\":");
  buf_json(j, b->pasta);
  buf_str(j, ",\"titulo\":");
  buf_json(j, b->titulo);
  snprintf(c, sizeof c, "%s/fakelib", b->real);
  buf_fmt(j, ",\"fakelib\":%s,\"ampr\":", !lstat(c, &st) && S_ISDIR(st.st_mode) ? "true" : "false");
  snprintf(c, sizeof c, "%s/fakelib/libSceAmpr.sprx", b->real);
  runtime_t rt;
  int existe = !lstat(c, &st) && S_ISREG(st.st_mode);
  if(!existe) buf_str(j, "null");
  else if(runtime_de(c, &rt, NULL)) buf_str(j, "{\"ng\":false}");   /* outro AMPR (de quem fez o backport) */
  else {
    buf_str(j, "{\"ng\":true,");
    runtime_curto_json(j, &rt);
    buf_str(j, "}");
  }
  guarda_t g;
  int nosso = 0;
  if(existe && !guarda_ler(b, &g)) {
    sha_de_arquivo(c, sha);
    nosso = !strcmp(sha, g.sha256);
  }
  buf_fmt(j, ",\"nosso\":%s,\"original\":%s}", nosso ? "true" : "false", nosso && g.tinha_original ? "true" : "false");
}

static pthread_mutex_t g_trava_lista = PTHREAD_MUTEX_INITIALIZER;
static backport_t g_lista[BKP_MAX];   /* ~100 KB fora da pilha (pilha de thread pequena no PS5), so com g_trava_lista */

void ampr_backports_json(buf_t *j) {
  pthread_mutex_lock(&g_trava_lista);
  int n = listar_backports(g_lista, BKP_MAX);
  buf_str(j, "{\"ok\":true,\"fonte\":");
  char c[720];
  runtime_t rt;
  int de_teste;
  if(fonte_runtime(c, sizeof c, &rt, &de_teste)) buf_str(j, "null");
  else {
    buf_fmt(j, "{\"teste\":%s,", de_teste ? "true" : "false");
    runtime_curto_json(j, &rt);
    buf_str(j, "}");
  }
  /* <emus>/libSceAmpr.sprx (fora da pasta ampr-emu-ng): com "atualizar emuladores" ligado o ShadowKraken troca o do
     backport por ele quando o do backport nao e mais novo. A pagina avisa. */
  char emus[600], ea[700];
  pasta_emus(emus, sizeof emus);
  snprintf(ea, sizeof ea, "%s/libSceAmpr.sprx", emus);
  struct stat st;
  buf_str(j, ",\"listas\":");
  ampr_listas_json(j);
  buf_fmt(j, ",\"emus_ampr\":%s,\"backports\":[", !lstat(ea, &st) && S_ISREG(st.st_mode) ? "true" : "false");
  for(int i = 0; i < n; i++) {
    if(i) buf_str(j, ",");
    backport_json(j, &g_lista[i]);
  }
  buf_str(j, "]}");
  pthread_mutex_unlock(&g_trava_lista);
}

void ampr_backports_rota_estado(pedido_t *p) {
  buf_t b = {0};
  ampr_backports_json(&b);
  responder_json(p, 200, &b);
  buf_free(&b);
}

static void bkp_erro(pedido_t *p, int cod, const char *chave, const char *msg, const char *caminho) {
  diario("ampr-backport: %s: %s", caminho, msg);
  terminar();
  responder_erro(p, cod, chave, msg, NULL);
}

static void bkp_por(pedido_t *p, const backport_t *b) {
  char fonte[720], fk[800], dest[900], orig[1200], erro[300];
  runtime_t rt;
  int de_teste;
  if(fonte_runtime(fonte, sizeof fonte, &rt, &de_teste)) {
    bkp_erro(p, 400, "ampr_bkp_sem_fonte", "nao achou o ampr-emu-ng do ShadowKraken (nem o de teste nem o embutido)", b->caminho);
    return;
  }
  buf_t d = {0};
  if(ler_arquivo(fonte, &d, AMPR_MAX) || conferir(d.d, d.n, &rt, erro, sizeof erro)) {
    buf_free(&d);
    bkp_erro(p, 400, "ampr_bkp_sem_fonte", "o ampr-emu-ng do ShadowKraken nao confere", b->caminho);
    return;
  }
  snprintf(fk, sizeof fk, "%s/fakelib", b->real);
  snprintf(dest, sizeof dest, "%s/libSceAmpr.sprx", fk);
  caminho_guarda(b, ".original.sprx", orig, sizeof orig);
  guarda_t g, velho;
  memset(&g, 0, sizeof g);
  int tem_guarda = !guarda_ler(b, &velho);
  struct stat st;
  if(lstat(fk, &st)) {
    if(mkdir(fk, 0777) && errno != EEXIST) {
      snprintf(erro, sizeof erro, "nao criou %s/fakelib (%s)", b->caminho, strerror(errno));
      buf_free(&d);
      bkp_erro(p, 400, "ampr_arquivo_erro", erro, b->caminho);
      return;
    }
    chmod(fk, 0777);
    g.criou_pasta = 1;
  } else if(!S_ISDIR(st.st_mode)) {
    buf_free(&d);
    bkp_erro(p, 400, "ampr_arquivo_erro", "o fakelib do backport nao e uma pasta", b->caminho);
    return;
  }
  if(!lstat(dest, &st)) {
    if(!S_ISREG(st.st_mode)) {
      buf_free(&d);
      bkp_erro(p, 400, "ampr_arquivo_erro", "o libSceAmpr.sprx do backport nao e um arquivo", b->caminho);
      return;
    }
    char sha[65];
    sha_de_arquivo(dest, sha);
    if(tem_guarda && !strcmp(sha, velho.sha256)) {   /* o que esta la e nosso: o original ja esta guardado */
      g.tinha_original = velho.tinha_original;
      g.criou_pasta = velho.criou_pasta;
    } else {                                           /* de quem fez o backport: guarda antes de trocar */
      buf_t o = {0};
      char pasta[700];
      snprintf(pasta, sizeof pasta, "%s/ampr-backport", g_pasta_dados);
      if(ampr_criar_pastas(pasta) || ler_arquivo(dest, &o, AMPR_TRACE_MAX) || gravar_arquivo(orig, o.d, o.n)) {
        snprintf(erro, sizeof erro, "nao guardou o libSceAmpr.sprx que ja estava no backport (%s)", strerror(errno));
        buf_free(&o);
        buf_free(&d);
        bkp_erro(p, 400, "ampr_arquivo_erro", erro, b->caminho);
        return;
      }
      buf_free(&o);
      g.tinha_original = 1;
    }
  } else if(tem_guarda) g.criou_pasta = velho.criou_pasta;
  snprintf(g.sha256, sizeof g.sha256, "%s", rt.sha256);
  if(guarda_gravar(b, &g) || gravar_arquivo(dest, d.d, d.n)) {
    snprintf(erro, sizeof erro, "nao gravou %s/fakelib/libSceAmpr.sprx (%s)", b->caminho, strerror(errno));
    buf_free(&d);
    bkp_erro(p, 400, "ampr_arquivo_erro", erro, b->caminho);
    return;
  }
  buf_free(&d);
  int dfd = open(fk, O_RDONLY);
  if(dfd >= 0) {
    fsync(dfd);
    close(dfd);
  }
  diario("ampr-backport: %s/fakelib/libSceAmpr.sprx = ampr-emu-ng %s%s%s (%s, %s, sha256 %s)%s; vale na proxima abertura do %s",
         b->caminho, rt.versao, rt.commit[0] ? " " : "", rt.commit, de_teste ? "o de teste" : "o embutido",
         rt.depuracao ? "depuracao" : "release", rt.sha256, g.tinha_original ? "; o que estava la ficou guardado" : "", b->titulo);
  terminar();
  buf_t r = {0};
  buf_str(&r, "{\"ok\":true,\"titulo\":");
  buf_json(&r, b->titulo);
  buf_fmt(&r, ",\"teste\":%s,\"guardou\":%s,", de_teste ? "true" : "false", g.tinha_original ? "true" : "false");
  runtime_curto_json(&r, &rt);
  buf_str(&r, "}");
  responder_json(p, 200, &r);
  buf_free(&r);
}

static void bkp_tirar(pedido_t *p, const backport_t *b) {
  char fk[800], dest[900], orig[1200], erro[300], sha[65] = "";
  guarda_t g;
  struct stat st;
  snprintf(fk, sizeof fk, "%s/fakelib", b->real);
  snprintf(dest, sizeof dest, "%s/libSceAmpr.sprx", fk);
  caminho_guarda(b, ".original.sprx", orig, sizeof orig);
  int nosso = !guarda_ler(b, &g) && !lstat(dest, &st) && S_ISREG(st.st_mode);
  if(nosso) {
    sha_de_arquivo(dest, sha);
    nosso = !strcmp(sha, g.sha256);
  }
  if(!nosso) {
    bkp_erro(p, 409, "ampr_bkp_nao_nosso", "o libSceAmpr.sprx deste backport nao foi posto pelo glibren (ou foi trocado depois)", b->caminho);
    return;
  }
  if(g.tinha_original) {
    buf_t o = {0};
    if(ler_arquivo(orig, &o, AMPR_TRACE_MAX) || gravar_arquivo(dest, o.d, o.n)) {
      snprintf(erro, sizeof erro, "nao devolveu o libSceAmpr.sprx original (%s)", strerror(errno));
      buf_free(&o);
      bkp_erro(p, 400, "ampr_arquivo_erro", erro, b->caminho);
      return;
    }
    buf_free(&o);
    unlink(orig);
  } else if(unlink(dest)) {
    snprintf(erro, sizeof erro, "nao apagou %s/fakelib/libSceAmpr.sprx (%s)", b->caminho, strerror(errno));
    bkp_erro(p, 400, "ampr_arquivo_erro", erro, b->caminho);
    return;
  }
  if(g.criou_pasta) rmdir(fk);   /* so se ficou vazia */
  char c[1200];
  caminho_guarda(b, ".txt", c, sizeof c);
  unlink(c);
  diario("ampr-backport: %s: %s; vale na proxima abertura do %s", b->caminho,
         g.tinha_original ? "o libSceAmpr.sprx original voltou" : "o ampr-emu-ng saiu do fakelib", b->titulo);
  terminar();
  buf_t r = {0};
  buf_str(&r, "{\"ok\":true,\"titulo\":");
  buf_json(&r, b->titulo);
  buf_fmt(&r, ",\"voltou_original\":%s}", g.tinha_original ? "true" : "false");
  responder_json(p, 200, &r);
  buf_free(&r);
}

/* POST /api/ampr/backport (caminho=<raiz>/backports/<pasta>, acao=por|tirar). So caminhos da lista. */
void ampr_backport_rota(pedido_t *p) {
  char caminho[600] = "", acao[16] = "";
  param(p->corpo, "caminho", 0, caminho, sizeof caminho);
  param(p->corpo, "acao", 0, acao, sizeof acao);
  int por = !strcmp(acao, "por");
  if(!por && strcmp(acao, "tirar")) {
    responder_erro(p, 400, "ampr_bkp_acao", "acao tem de ser por ou tirar", NULL);
    return;
  }
  if(comecar(p)) return;
  pthread_mutex_lock(&g_trava_lista);
  int n = listar_backports(g_lista, BKP_MAX), i = 0;
  while(i < n && strcmp(g_lista[i].caminho, caminho)) i++;
  backport_t b;
  if(i < n) b = g_lista[i];
  pthread_mutex_unlock(&g_trava_lista);
  if(i == n) {
    bkp_erro(p, 404, "ampr_bkp_nao_achou", "backport nao encontrado (a lista mudou?)", caminho[0] ? caminho : "(vazio)");
    return;
  }
  if(por) bkp_por(p, &b);
  else bkp_tirar(p, &b);
}

/* ======================= 0.9.58: listas por jogo do ShadowKraken ======================= */
/* /data/shadowmount/ampr_add.txt (SK Dev.36): jogo que nao e .pkg (.exfat ou pasta, backport dentro do jogo) recebe o
   ampr-emu-ng do ShadowKraken. /data/shadowmount/playgo_off.txt (SK Dev.30): sem o stub do PlayGo. Um codigo por linha;
   o ShadowKraken le na proxima abertura do jogo (a lista entra na assinatura do cache). */
static const char *const LISTAS_SK[] = { "ampr_add", "playgo_off" };
#define LISTA_MAX 64

static int lista_valida(const char *nome) {
  for(size_t i = 0; i < sizeof LISTAS_SK / sizeof *LISTAS_SK; i++)
    if(!strcmp(nome, LISTAS_SK[i])) return 1;
  return 0;
}

static void caminho_lista(const char *nome, char *saida, size_t tam) {
  snprintf(saida, tam, "%s/shadowmount/%s.txt", raiz_data(), nome);
}

/* Codigos da lista (primeira palavra de cada linha, como o ShadowKraken le), sem repetir. */
static int lista_ler(const char *nome, char v[][10], int max) {
  char c[700], linha[256];
  caminho_lista(nome, c, sizeof c);
  FILE *f = fopen(c, "r");
  if(!f) return 0;
  int n = 0;
  while(n < max && fgets(linha, sizeof linha, f)) {
    char *l = linha, tid[10];
    while(*l == ' ' || *l == '\t') l++;
    l[strcspn(l, " \t\r\n#")] = 0;
    if(strlen(l) != 9 || titulo_de(l, tid)) continue;
    int rep = 0;
    for(int i = 0; i < n; i++) rep |= !strcmp(v[i], tid);
    if(!rep) snprintf(v[n++], 10, "%s", tid);
  }
  fclose(f);
  return n;
}

void ampr_listas_json(buf_t *j) {
  char v[LISTA_MAX][10];
  buf_str(j, "{");
  for(size_t i = 0; i < sizeof LISTAS_SK / sizeof *LISTAS_SK; i++) {
    int n = lista_ler(LISTAS_SK[i], v, LISTA_MAX);
    buf_fmt(j, "%s\"%s\":[", i ? "," : "", LISTAS_SK[i]);
    for(int k = 0; k < n; k++) buf_fmt(j, "%s\"%s\"", k ? "," : "", v[k]);
    buf_str(j, "]");
  }
  buf_str(j, "}");
}

/* POST /api/ampr/lista (lista=ampr_add|playgo_off, titulo=PPSA13427, acao=por|tirar). */
void ampr_lista_rota(pedido_t *p) {
  char nome[32] = "", titulo[32] = "", acao[16] = "", tid[10];
  param(p->corpo, "lista", 0, nome, sizeof nome);
  param(p->corpo, "titulo", 0, titulo, sizeof titulo);
  param(p->corpo, "acao", 0, acao, sizeof acao);
  for(char *c = titulo; *c; c++) if(*c >= 'a' && *c <= 'z') *c -= 32;
  int por = !strcmp(acao, "por");
  if(!lista_valida(nome) || (!por && strcmp(acao, "tirar"))) {
    responder_erro(p, 400, "ampr_lista_acao", "lista tem de ser ampr_add ou playgo_off e acao por ou tirar", NULL);
    return;
  }
  if(strlen(titulo) != 9 || titulo_de(titulo, tid)) {
    responder_erro(p, 400, "ampr_lista_titulo", "codigo do jogo invalido (ex.: PPSA13427)", NULL);
    return;
  }
  if(comecar(p)) return;
  char v[LISTA_MAX][10];
  pthread_mutex_lock(&g_trava_lista);
  int n = lista_ler(nome, v, LISTA_MAX), achou = -1;
  for(int i = 0; i < n; i++) if(!strcmp(v[i], tid)) achou = i;
  int mudou = 0, erro = 0;
  if(por && achou < 0) {
    if(n >= LISTA_MAX) erro = ENOSPC;
    else { snprintf(v[n++], 10, "%s", tid); mudou = 1; }
  } else if(!por && achou >= 0) {
    memmove(v[achou], v[achou + 1], (size_t)(n - achou - 1) * sizeof v[0]);
    n--;
    mudou = 1;
  }
  if(mudou) {
    buf_t b = {0};
    buf_fmt(&b, "# %s do ShadowKraken: um codigo de jogo por linha (glibren)\n", nome);
    for(int i = 0; i < n; i++) buf_fmt(&b, "%s\n", v[i]);
    char c[700], pasta[700];
    caminho_lista(nome, c, sizeof c);
    snprintf(pasta, sizeof pasta, "%s/shadowmount", raiz_data());
    mkdir(pasta, 0777);
    if(gravar_arquivo(c, b.d ? b.d : "", b.n)) erro = errno ? errno : EIO;
    buf_free(&b);
  }
  pthread_mutex_unlock(&g_trava_lista);
  terminar();
  if(erro) {
    diario("ampr-lista: %s %s %s: erro %s", nome, acao, tid, strerror(erro));
    responder_erro(p, 500, "ampr_lista_gravar", strerror(erro), NULL);
    return;
  }
  if(mudou) diario("ampr-lista: %s %s %s", nome, por ? "+" : "-", tid);
  buf_t r = {0};
  buf_fmt(&r, "{\"ok\":true,\"lista\":\"%s\",\"titulo\":\"%s\",\"acao\":\"%s\",\"mudou\":%s,\"listas\":", nome, tid, acao,
          mudou ? "true" : "false");
  ampr_listas_json(&r);
  buf_str(&r, "}");
  responder_json(p, 200, &r);
  buf_free(&r);
}
