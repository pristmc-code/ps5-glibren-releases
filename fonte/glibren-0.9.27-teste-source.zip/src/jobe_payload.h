/* Game Library Renamer (payload PS5) - 0.9.27: "Ligar o payload da Jobe" (bg-downloader, downloads da Jobee'sLair).

Manda ao elfldr (127.0.0.1:9021) uma copia do bg-downloader que JA esta no PS5 em /data/JobeesLair/bg (a baixada pela
propria Jobe, assinada, ou a embedded.elf que o app deixou), conferida antes:
  - bg-downloader.elf / bg-downloader.prev.elf: manifesto assinado (Ed25519 de "jobe-bg-signature-v1\n" + o manifesto,
    a mesma chave publica do glibren) + tamanho e SHA-256 do .elf iguais aos do manifesto; fora a versao marcada como
    ruim no self-update.json e a incompativel com o app (app.json);
  - embedded.elf: SHA-256 e tamanho iguais aos de um manifesto assinado (um dos de cima ou o da release
    bg-downloader-<versao do app.json> no GitHub, baixado na hora).
Vai a de versao mais alta. Nada e baixado alem do manifesto: sem copia da Jobe no PS5, recusa.
Status "no ar / fora do ar": a porta 34200 do payload responde (sem o token: nao conta como "o app falou"); a versao vem
do diario dele (bgdl.log, linha "==== iniciando bg-downloader X" com o pid do bgdl.pid). */
#pragma once

#include "http.h"

/* GET /api/jobe-payload (leitura livre): {"ok","no_ar","versao","pid","pasta","candidato":{...}|null,"ocupado","fase","erro","resultado"} */
void jobe_payload_rota_estado(pedido_t *p);
/* o mesmo JSON, num buffer (diagnostico) */
void jobe_payload_json(buf_t *b);
/* POST /api/jobe-payload/ligar: pareamento + X-GLR ja conferidos pelo api.c. Recusa outros programas do proprio PS5
   (menos o navegador), recusa se ja esta no ar (o novo derrubaria o antigo pelo lock) e um pedido por vez. */
void jobe_payload_rota_ligar(pedido_t *p);
