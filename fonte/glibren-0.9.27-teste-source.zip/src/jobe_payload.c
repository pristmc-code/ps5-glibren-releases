/* Game Library Renamer (payload PS5) - 0.9.27: "Ligar o payload da Jobe". Ver jobe_payload.h.

Formato da Jobe (app/native/bg_self.c do JobeesLair-glibren, glibren.49+), em /data/JobeesLair/bg:
  bg-downloader.elf/.json/.json.sig   o baixado atual (manifesto ASCII {"format":1,"name":"bg-downloader","version",
                                      "api","minAppApi","size","sha256"}; .sig = 128 hex de Ed25519("jobe-bg-signature-v1\n"
                                      + os bytes exatos do manifesto); bg-downloader.prev.* = o anterior
  embedded.elf                        copia do ELF embutido no app (sem assinatura propria)
  app.json                            {"api":N,"embedded":"X.Y.Z"} gravado pelo app
  self-update.json                    {"bad":["X.Y.Z",...],...}: versoes que nao subiram (nunca usar)
  bgdl.pid / bgdl.log                 o pid de quem segura o lock e o diario ("==== iniciando bg-downloader X (...), pid N")
Uma copia so (bg_downloader.c take_lock): a copia nova manda SIGTERM a antiga e assume o lock; por isso o glibren nao
manda outra quando a porta 34200 responde. Testes no PC: GLR_TESTE_JOBE_DIR, GLR_TESTE_JOBE_PORTA (porta do /health),
GLR_TESTE_JOBE_REL (base das releases, dentro de GLR_TESTE_BASE) e GLR_TESTE_ELFLDR. */
#include "jobe_payload.h"

#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#include "api.h"
#include "assinatura.h"
#include "fps.h"
#include "https.h"
#include "plataforma.h"
#include "sha256.h"

#define DOMINIO "jobe-bg-signature-v1\n"
#define REL_BASE "https://github.com/pristmc-code/JobeesLair-glibren/releases/download/bg-downloader-"
#define MAX_ELF (32u * 1024 * 1024)
#define MAX_MANIFESTO 4096
#define PORTA_SAUDE 34200
#define PORTA_ELFLDR 9021
#ifdef MSG_NOSIGNAL
#define SEM_SINAL MSG_NOSIGNAL
#else
#define SEM_SINAL 0
#endif

/* ------------------------------------------------------------------ caminhos e ambiente */

static void pasta(char *s, size_t tam) {
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_JOBE_DIR")) {
    snprintf(s, tam, "%s", getenv("GLR_TESTE_JOBE_DIR"));
    return;
  }
#endif
  snprintf(s, tam, "/data/JobeesLair/bg");
}

static void arquivo(const char *nome, char *s, size_t tam) {
  char p[400];
  pasta(p, sizeof p);
  snprintf(s, tam, "%s/%s", p, nome);
}

static int porta_env(const char *nome, int padrao) {
#ifndef __PROSPERO__
  if(getenv(nome) && atoi(getenv(nome)) > 0) return atoi(getenv(nome));
#else
  (void)nome;
#endif
  return padrao;
}

static void rel_base(char *s, size_t tam) {
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_JOBE_REL")) {
    snprintf(s, tam, "%s", getenv("GLR_TESTE_JOBE_REL"));
    return;
  }
#endif
  snprintf(s, tam, "%s", REL_BASE);
}

/* Le o arquivo inteiro (ate max bytes). 0 = ok. */
static int ler_tudo(const char *caminho, size_t max, buf_t *b) {
  int fd = open(caminho, O_RDONLY);
  if(fd < 0) return -1;
  struct stat st;
  if(fstat(fd, &st) || !S_ISREG(st.st_mode) || (unsigned long long)st.st_size > max) {
    close(fd);
    return -1;
  }
  char bloco[65536];
  for(;;) {
    ssize_t r = read(fd, bloco, sizeof bloco);
    if(r < 0 && errno == EINTR) continue;
    if(r < 0) {
      close(fd);
      return -1;
    }
    if(r == 0) break;
    if(b->n + (size_t)r > max) {
      close(fd);
      return -1;
    }
    buf_add(b, bloco, (size_t)r);
  }
  close(fd);
  return 0;
}

/* ------------------------------------------------------------------ versoes e JSON simples */

/* So X.Y.Z (numeros de ate 4 digitos), como no bg_self.c. 1 = valida. */
static int versao_ler(const char *t, int v[3]) {
  if(!t || !*t) return 0;
  const char *p = t;
  for(int i = 0; i < 3; i++) {
    int d = 0, x = 0;
    while(isdigit((unsigned char)*p) && d < 5) {
      x = x * 10 + (*p - '0');
      p++;
      d++;
    }
    if(!d || d > 4) return 0;
    v[i] = x;
    if(i < 2) {
      if(*p != '.') return 0;
      p++;
    }
  }
  return *p == 0;
}

/* >0: a mais nova; 0: igual; <0: mais velha. Uma invalida perde para qualquer valida. */
static int versao_cmp(const char *a, const char *b) {
  int x[3], y[3];
  int va = versao_ler(a, x), vb = versao_ler(b, y);
  if(!va || !vb) return va - vb;
  for(int i = 0; i < 3; i++)
    if(x[i] != y[i]) return x[i] > y[i] ? 1 : -1;
  return 0;
}

/* Valor do campo "chave" no primeiro nivel de um JSON pequeno e simples (string sem escapes ou numero inteiro).
   1 = achou. */
static int campo(const char *json, const char *chave, char *saida, size_t tam) {
  char padrao[64];
  snprintf(padrao, sizeof padrao, "\"%s\"", chave);
  saida[0] = 0;
  for(const char *p = strstr(json, padrao); p; p = strstr(p + 1, padrao)) {
    const char *c = p + strlen(padrao);
    while(*c == ' ' || *c == '\t' || *c == '\r' || *c == '\n') c++;
    if(*c != ':') continue;
    c++;
    while(*c == ' ' || *c == '\t' || *c == '\r' || *c == '\n') c++;
    size_t n = 0;
    if(*c == '"') {
      c++;
      while(*c && *c != '"' && *c != '\\' && n + 1 < tam) saida[n++] = *c++;
      if(*c != '"') return 0;
    } else {
      while((isdigit((unsigned char)*c) || (*c == '-' && !n)) && n + 1 < tam) saida[n++] = *c++;
      if(!n) return 0;
    }
    saida[n] = 0;
    return 1;
  }
  return 0;
}

static int hex64(const char *s) {
  if(strlen(s) != 64) return 0;
  for(const char *c = s; *c; c++)
    if(!((*c >= '0' && *c <= '9') || (*c >= 'a' && *c <= 'f'))) return 0;
  return 1;
}

typedef struct {
  char versao[24], sha[65];
  long long api, min_app;
  unsigned long long tam;
} manifesto_t;

/* Confere a assinatura e os campos. "" = ok; senao o motivo. */
static const char *manifesto_conferir(const buf_t *json, const buf_t *sig, manifesto_t *m) {
  memset(m, 0, sizeof *m);
  if(!json->n || json->n > MAX_MANIFESTO) return "manifesto ausente ou grande demais";
  for(size_t i = 0; i < json->n; i++)
    if((unsigned char)json->d[i] > 0x7e || (json->d[i] < ' ' && !strchr("\r\n\t", json->d[i]))) return "manifesto com caracteres invalidos";
  /* .sig: 128 hex (+ fim de linha) */
  unsigned char assin[64];
  size_t ns = sig->n;
  while(ns && (sig->d[ns - 1] == '\n' || sig->d[ns - 1] == '\r' || sig->d[ns - 1] == ' ')) ns--;
  if(ns != 128) return "assinatura ausente ou invalida";
  for(int i = 0; i < 64; i++) {
    unsigned v;
    char par[3] = {sig->d[i * 2], sig->d[i * 2 + 1], 0};
    if(!isxdigit((unsigned char)par[0]) || !isxdigit((unsigned char)par[1]) || sscanf(par, "%2x", &v) != 1) return "assinatura invalida";
    assin[i] = (unsigned char)v;
  }
  size_t nd = strlen(DOMINIO);
  char *dados = malloc(nd + json->n);
  if(!dados) return "sem memoria";
  memcpy(dados, DOMINIO, nd);
  memcpy(dados + nd, json->d, json->n);
  int ok = assinatura_valida(dados, nd + json->n, assin);
  free(dados);
  if(!ok) return "assinatura nao confere (nao e da Jobe)";
  char texto[MAX_MANIFESTO + 1], v[80];
  memcpy(texto, json->d, json->n);
  texto[json->n] = 0;
  if(!campo(texto, "name", v, sizeof v) || strcmp(v, "bg-downloader")) return "manifesto de outro programa";
  if(!campo(texto, "version", m->versao, sizeof m->versao) || !versao_ler(m->versao, (int[3]){0})) return "manifesto sem versao";
  if(!campo(texto, "sha256", m->sha, sizeof m->sha) || !hex64(m->sha)) return "manifesto sem sha256";
  if(!campo(texto, "size", v, sizeof v) || (m->tam = strtoull(v, NULL, 10)) == 0 || m->tam > MAX_ELF) return "manifesto sem tamanho";
  if(!campo(texto, "api", v, sizeof v)) return "manifesto sem api";
  m->api = atoll(v);
  m->min_app = campo(texto, "minAppApi", v, sizeof v) ? atoll(v) : m->api;
  return "";
}

/* ------------------------------------------------------------------ SHA-256 dos arquivos (com cache) */

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static struct {
  char caminho[420];
  long long tam, mtime, mtime_ns, ctime, ino;   /* segundos nao bastam: o arquivo pode mudar no mesmo segundo */
  char sha[65];
} g_cache[4];

#ifdef __APPLE__
#define MTIM_NS(st) ((st).st_mtimespec.tv_nsec)
#else
#define MTIM_NS(st) ((st).st_mtim.tv_nsec)
#endif
static int cache_igual(int i, const char *caminho, const struct stat *st) {
  return !strcmp(g_cache[i].caminho, caminho) && g_cache[i].tam == (long long)st->st_size && g_cache[i].mtime == (long long)st->st_mtime &&
         g_cache[i].mtime_ns == (long long)MTIM_NS(*st) && g_cache[i].ctime == (long long)st->st_ctime && g_cache[i].ino == (long long)st->st_ino;
}

/* sha256 + tamanho do arquivo. 0 = ok. */
static int sha_arquivo(const char *caminho, char sha[65], unsigned long long *tam) {
  struct stat st;
  if(stat(caminho, &st) || !S_ISREG(st.st_mode) || (unsigned long long)st.st_size > MAX_ELF) return -1;
  pthread_mutex_lock(&g_trava);
  for(int i = 0; i < 4; i++)
    if(cache_igual(i, caminho, &st)) {
      memcpy(sha, g_cache[i].sha, 65);
      *tam = (unsigned long long)st.st_size;
      pthread_mutex_unlock(&g_trava);
      return 0;
    }
  pthread_mutex_unlock(&g_trava);
  int fd = open(caminho, O_RDONLY);
  if(fd < 0) return -1;
  sha256_t s;
  sha256_iniciar(&s);
  char bloco[65536];
  unsigned long long n = 0;
  for(;;) {
    ssize_t r = read(fd, bloco, sizeof bloco);
    if(r < 0 && errno == EINTR) continue;
    if(r < 0) {
      close(fd);
      return -1;
    }
    if(!r) break;
    sha256_atualizar(&s, bloco, (size_t)r);
    n += (unsigned long long)r;
  }
  close(fd);
  uint8_t resumo[32];
  sha256_final(&s, resumo);
  sha256_hex(resumo, sha);
  *tam = n;
  pthread_mutex_lock(&g_trava);
  static int prox;
  int i = prox++ % 4;
  snprintf(g_cache[i].caminho, sizeof g_cache[i].caminho, "%s", caminho);
  g_cache[i].tam = (long long)n;
  g_cache[i].mtime = (long long)st.st_mtime;
  g_cache[i].mtime_ns = (long long)MTIM_NS(st);
  g_cache[i].ctime = (long long)st.st_ctime;
  g_cache[i].ino = (long long)st.st_ino;
  memcpy(g_cache[i].sha, sha, 65);
  pthread_mutex_unlock(&g_trava);
  return 0;
}

/* ------------------------------------------------------------------ candidatos */

typedef struct {
  char arquivo[40];   /* bg-downloader.elf, bg-downloader.prev.elf, embedded.elf */
  char versao[24];
  char como[16];      /* assinatura | sha | release */
  char motivo[160];   /* por que nao serve ("" = serve) */
  char sha[65];
  unsigned long long tam;
  int ok;             /* 1 = conferido; 0 = nao serve; -1 = embedded.elf: confere pela release ao ligar */
} cand_t;

typedef struct {
  long long app_api;
  char app_emb[24];
  cand_t c[3];
  manifesto_t assinados[3];   /* manifestos com assinatura valida (para conferir o embedded.elf) */
  int n_assinados;
  int pasta_existe;
} avaliacao_t;

static int ruim(const char *bad, const char *versao) {
  if(!bad) return 0;
  const char *ini = strstr(bad, "\"bad\"");
  if(!ini) return 0;
  const char *fim = strchr(ini, ']');
  char alvo[32];
  snprintf(alvo, sizeof alvo, "\"%s\"", versao);
  const char *achou = strstr(ini, alvo);
  return achou && (!fim || achou < fim);
}

static void avaliar_assinado(avaliacao_t *a, int i, const char *base, const char *bad) {
  cand_t *c = &a->c[i];
  char cj[480], cs[480], ce[480], nome[64];
  snprintf(nome, sizeof nome, "%s.json", base);
  arquivo(nome, cj, sizeof cj);
  snprintf(nome, sizeof nome, "%s.json.sig", base);
  arquivo(nome, cs, sizeof cs);
  snprintf(c->arquivo, sizeof c->arquivo, "%s.elf", base);
  arquivo(c->arquivo, ce, sizeof ce);
  snprintf(c->como, sizeof c->como, "assinatura");
  buf_t j = {0}, s = {0};
  struct stat st;
  if(stat(ce, &st)) {
    snprintf(c->motivo, sizeof c->motivo, "nao existe");
    goto fim;
  }
  if(ler_tudo(cj, MAX_MANIFESTO, &j) || ler_tudo(cs, 1024, &s)) {
    snprintf(c->motivo, sizeof c->motivo, "sem o manifesto assinado (.json/.json.sig)");
    goto fim;
  }
  manifesto_t m;
  const char *por = manifesto_conferir(&j, &s, &m);
  if(*por) {
    snprintf(c->motivo, sizeof c->motivo, "%s", por);
    goto fim;
  }
  snprintf(c->versao, sizeof c->versao, "%s", m.versao);
  if(a->n_assinados < 3) a->assinados[a->n_assinados++] = m;
  if(sha_arquivo(ce, c->sha, &c->tam)) {
    snprintf(c->motivo, sizeof c->motivo, "nao deu para ler o .elf");
    goto fim;
  }
  if(c->tam != m.tam || strcmp(c->sha, m.sha)) {
    snprintf(c->motivo, sizeof c->motivo, "o .elf nao e o do manifesto (tamanho ou SHA-256 diferente)");
    goto fim;
  }
  if(ruim(bad, m.versao)) {
    snprintf(c->motivo, sizeof c->motivo, "versao marcada como ruim pela Jobe (nao subiu)");
    goto fim;
  }
  if(a->app_api > 0 && (m.api < a->app_api || (m.api > a->app_api && m.min_app > a->app_api))) {
    snprintf(c->motivo, sizeof c->motivo, "incompativel com a Jobe instalada (api %lld, a Jobe usa %lld)", m.api, a->app_api);
    goto fim;
  }
  c->ok = 1;
fim:
  buf_free(&j);
  buf_free(&s);
}

/* Confere o embedded.elf pelo manifesto da release bg-downloader-<versao> (baixado agora). "" = ok. */
static const char *conferir_pela_release(const char *versao, const char *sha, unsigned long long tam) {
  char base[300], url[400];
  rel_base(base, sizeof base);
  buf_t j = {0}, s = {0};
  snprintf(url, sizeof url, "%s%s/bg-downloader.json", base, versao);
  int st1 = https_get(url, &j, MAX_MANIFESTO, 30);
  snprintf(url, sizeof url, "%s%s/bg-downloader.json.sig", base, versao);
  int st2 = st1 == 200 ? https_get(url, &s, 1024, 30) : -1;
  diario("jobe-payload: manifesto da release %s: HTTP %d / %d", versao, st1, st2);
  const char *por = "";
  manifesto_t m;
  if(st1 != 200 || st2 != 200) por = "sem o manifesto da release no GitHub (sem internet ou versao sem release)";
  else if(*(por = manifesto_conferir(&j, &s, &m))) {
  } else if(strcmp(m.versao, versao)) por = "o manifesto da release e de outra versao";
  else if(m.tam != tam || strcmp(m.sha, sha)) por = "o embedded.elf nao e o da release (tamanho ou SHA-256 diferente)";
  buf_free(&j);
  buf_free(&s);
  return por;
}

static void avaliar_embutido(avaliacao_t *a, int rede) {
  cand_t *c = &a->c[2];
  char ce[480];
  snprintf(c->arquivo, sizeof c->arquivo, "embedded.elf");
  arquivo(c->arquivo, ce, sizeof ce);
  struct stat st;
  if(stat(ce, &st)) {
    snprintf(c->motivo, sizeof c->motivo, "nao existe (a Jobe deixa ao abrir)");
    return;
  }
  if(sha_arquivo(ce, c->sha, &c->tam)) {
    snprintf(c->motivo, sizeof c->motivo, "nao deu para ler o .elf");
    return;
  }
  for(int i = 0; i < a->n_assinados; i++)
    if(a->assinados[i].tam == c->tam && !strcmp(a->assinados[i].sha, c->sha)) {
      snprintf(c->versao, sizeof c->versao, "%s", a->assinados[i].versao);
      snprintf(c->como, sizeof c->como, "sha");
      c->ok = 1;
      return;
    }
  if(!versao_ler(a->app_emb, (int[3]){0})) {
    snprintf(c->motivo, sizeof c->motivo, "sem a versao do embutido (app.json): abra a Jobe uma vez");
    return;
  }
  snprintf(c->versao, sizeof c->versao, "%s", a->app_emb);
  snprintf(c->como, sizeof c->como, "release");
  if(!rede) {
    c->ok = -1;   /* confere pela release do GitHub ao ligar */
    return;
  }
  const char *por = conferir_pela_release(a->app_emb, c->sha, c->tam);
  if(*por) snprintf(c->motivo, sizeof c->motivo, "%s", por);
  else c->ok = 1;
}

/* rede = 1: pode baixar o manifesto da release para conferir o embedded.elf (so ao ligar). */
static void avaliar(avaliacao_t *a, int rede) {
  memset(a, 0, sizeof *a);
  char p[400], cam[480];
  struct stat st;
  pasta(p, sizeof p);
  a->pasta_existe = !stat(p, &st) && S_ISDIR(st.st_mode);
  buf_t b = {0};
  arquivo("app.json", cam, sizeof cam);
  if(!ler_tudo(cam, 4096, &b)) {
    buf_add(&b, "", 1);
    char v[32];
    if(campo(b.d, "api", v, sizeof v)) a->app_api = atoll(v);
    campo(b.d, "embedded", a->app_emb, sizeof a->app_emb);
  }
  buf_free(&b);
  arquivo("self-update.json", cam, sizeof cam);
  int tem_bad = !ler_tudo(cam, 64 * 1024, &b);
  if(tem_bad) buf_add(&b, "", 1);
  avaliar_assinado(a, 0, "bg-downloader", tem_bad ? b.d : NULL);
  avaliar_assinado(a, 1, "bg-downloader.prev", tem_bad ? b.d : NULL);
  buf_free(&b);
  /* embedded.elf: so precisa da rede se ele for mais novo que o melhor baixado (ou se nao ha baixado que sirva) */
  const char *melhor = NULL;
  for(int i = 0; i < 2; i++)
    if(a->c[i].ok == 1 && (!melhor || versao_cmp(a->c[i].versao, melhor) > 0)) melhor = a->c[i].versao;
  avaliar_embutido(a, rede && (!melhor || versao_cmp(a->app_emb, melhor) > 0));
  if(a->c[2].ok == -1 && melhor && versao_cmp(a->app_emb, melhor) <= 0) {
    a->c[2].ok = 0;
    snprintf(a->c[2].motivo, sizeof a->c[2].motivo, "nao e mais novo que o baixado %s", melhor);
  }
}

/* O escolhido: o conferido de versao mais alta (pendente = -1 so quando nada conferido o supera). -1 = nenhum. */
static int escolhido(const avaliacao_t *a, int aceita_pendente) {
  int m = -1;
  for(int i = 0; i < 3; i++) {
    int ok = a->c[i].ok == 1 || (aceita_pendente && a->c[i].ok == -1);
    if(ok && (m < 0 || versao_cmp(a->c[i].versao, a->c[m].versao) > 0)) m = i;
  }
  return m;
}

/* ------------------------------------------------------------------ no ar? */

/* 1 = a porta do payload responde (HTTP), 0 = ninguem ouvindo. GET /health SEM o token: o payload responde 401 e nao
   conta como "o app falou" (com o token contaria, e o payload acharia que a Jobe esta aberta). */
static int no_ar(void) {
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if(fd < 0) return 0;
  struct timeval dois = {.tv_sec = 2};
  setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &dois, sizeof dois);
  setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &dois, sizeof dois);
#ifdef SO_NOSIGPIPE
  int sim = 1;
  setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &sim, sizeof sim);
#endif
  struct sockaddr_in end = {.sin_family = AF_INET, .sin_port = htons((uint16_t)porta_env("GLR_TESTE_JOBE_PORTA", PORTA_SAUDE))};
  end.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  if(connect(fd, (struct sockaddr *)&end, sizeof end)) {
    close(fd);
    return 0;
  }
  static const char PEDIDO[] = "GET /health HTTP/1.1\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n";
  send(fd, PEDIDO, sizeof PEDIDO - 1, SEM_SINAL);
  char r[16] = "";
  ssize_t n = recv(fd, r, sizeof r - 1, 0);
  close(fd);
  (void)n;
  return 1;   /* conectou: alguem segura a porta (respondendo ou nao, mandar outro derrubaria quem esta la) */
}

/* Versao e pid de quem esta no ar, pelo diario do payload (linha de inicio com o pid do bgdl.pid). 1 = achou. */
static int versao_no_ar(char *versao, size_t tam, int *pid) {
  versao[0] = 0;
  *pid = 0;
  char cam[480];
  buf_t b = {0};
  arquivo("bgdl.pid", cam, sizeof cam);
  if(!ler_tudo(cam, 64, &b)) {
    buf_add(&b, "", 1);
    *pid = atoi(b.d);
  }
  buf_free(&b);
  static const char *const DIARIOS[] = {"bgdl.log", "bgdl.log.old"};
  for(int d = 0; d < 2 && !versao[0]; d++) {
    arquivo(DIARIOS[d], cam, sizeof cam);
    int fd = open(cam, O_RDONLY);
    if(fd < 0) continue;
    struct stat st;
    if(fstat(fd, &st)) {
      close(fd);
      continue;
    }
    off_t ini = st.st_size > 512 * 1024 ? st.st_size - 512 * 1024 : 0;
    size_t n = (size_t)(st.st_size - ini);
    char *t = malloc(n + 1);
    ssize_t lidos = t ? pread(fd, t, n, ini) : -1;
    close(fd);
    if(lidos <= 0) {
      free(t);
      continue;
    }
    t[lidos] = 0;
    static const char MARCA[] = "==== iniciando bg-downloader ";
    for(char *p = strstr(t, MARCA); p; p = strstr(p + 1, MARCA)) {
      char v[24];
      int k = 0;
      const char *c = p + sizeof MARCA - 1;
      while(k < 23 && (isdigit((unsigned char)*c) || *c == '.')) v[k++] = *c++;
      v[k] = 0;
      const char *pp = strstr(c, ", pid ");
      const char *fim = strchr(c, '\n');
      int esse = pp && (!fim || pp < fim) ? atoi(pp + 6) : 0;
      if(versao_ler(v, (int[3]){0}) && (!*pid || esse == *pid)) snprintf(versao, tam, "%s", v);
    }
    free(t);
  }
  return versao[0] != 0;
}

/* ------------------------------------------------------------------ estado */

static struct {
  int ocupado;
  char fase[16];        /* "", conferindo, enviando, subindo */
  char erro[240];
  char resultado[200];
  time_t quando;
} g;

void jobe_payload_json(buf_t *saida) {
  avaliacao_t a;
  avaliar(&a, 0);
  char versao[24], dir[400];
  int pid = 0;
  int ar = no_ar();
  if(ar) versao_no_ar(versao, sizeof versao, &pid);
  else versao[0] = 0;
  pasta(dir, sizeof dir);
  buf_t b = {0};
  buf_fmt(&b, "{\"ok\":true,\"no_ar\":%s,\"versao\":", ar ? "true" : "false");
  buf_json(&b, versao);
  buf_fmt(&b, ",\"pid\":%d,\"pasta\":", ar ? pid : 0);
  buf_json(&b, dir);
  buf_fmt(&b, ",\"pasta_existe\":%s,\"app_api\":%lld,\"app_embutido\":", a.pasta_existe ? "true" : "false", a.app_api);
  buf_json(&b, a.app_emb);
  int e = escolhido(&a, 1);
  buf_str(&b, ",\"candidato\":");
  if(e < 0) buf_str(&b, "null");
  else {
    buf_str(&b, "{\"arquivo\":");
    buf_json(&b, a.c[e].arquivo);
    buf_str(&b, ",\"versao\":");
    buf_json(&b, a.c[e].versao);
    buf_str(&b, ",\"como\":");
    buf_json(&b, a.c[e].como);
    buf_fmt(&b, ",\"conferido\":%s,\"tamanho\":%llu,\"sha256\":", a.c[e].ok == 1 ? "true" : "false", a.c[e].tam);
    buf_json(&b, a.c[e].sha);
    buf_str(&b, "}");
  }
  buf_str(&b, ",\"arquivos\":[");
  for(int i = 0; i < 3; i++) {
    buf_str(&b, i ? ",{\"arquivo\":" : "{\"arquivo\":");
    buf_json(&b, a.c[i].arquivo);
    buf_str(&b, ",\"versao\":");
    buf_json(&b, a.c[i].versao);
    buf_fmt(&b, ",\"ok\":%d,\"motivo\":", a.c[i].ok);
    buf_json(&b, a.c[i].motivo);
    buf_str(&b, "}");
  }
  pthread_mutex_lock(&g_trava);
  buf_fmt(&b, "],\"ocupado\":%s,\"fase\":", g.ocupado ? "true" : "false");
  buf_json(&b, g.fase);
  buf_str(&b, ",\"erro\":");
  buf_json(&b, g.erro);
  buf_str(&b, ",\"resultado\":");
  buf_json(&b, g.resultado);
  buf_fmt(&b, ",\"quando\":%lld}", (long long)g.quando);
  pthread_mutex_unlock(&g_trava);
  buf_add(saida, b.d, b.n);
  buf_free(&b);
}

void jobe_payload_rota_estado(pedido_t *p) {
  buf_t b = {0};
  jobe_payload_json(&b);
  responder_json(p, 200, &b);
  buf_free(&b);
}

static void fase(const char *f) {
  pthread_mutex_lock(&g_trava);
  snprintf(g.fase, sizeof g.fase, "%s", f);
  pthread_mutex_unlock(&g_trava);
}

static void falhou(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
static void falhou(const char *fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  pthread_mutex_lock(&g_trava);
  vsnprintf(g.erro, sizeof g.erro, fmt, ap);
  pthread_mutex_unlock(&g_trava);
  va_end(ap);
  diario("jobe-payload: falhou: %s", g.erro);
}

/* ------------------------------------------------------------------ ligar */

/* Envia ao elfldr e le a saida ate "ready", "handoff" ou "busy" (o bg-downloader escreve uma delas) ou o fim.
   0 = enviado; "palavra" recebe o que ele disse ("" = nada). */
static int enviar_elfldr(const buf_t *elf, char *palavra, size_t tam) {
  palavra[0] = 0;
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if(fd < 0) return -1;
  struct timeval um = {.tv_sec = 1};
  setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &um, sizeof um);
  struct timeval dez = {.tv_sec = 10};
  setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &dez, sizeof dez);
#ifdef SO_NOSIGPIPE
  int sim = 1;
  setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &sim, sizeof sim);
#endif
  struct sockaddr_in end = {.sin_family = AF_INET, .sin_port = htons((uint16_t)porta_env("GLR_TESTE_ELFLDR", PORTA_ELFLDR))};
  end.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  int ok = !connect(fd, (struct sockaddr *)&end, sizeof end);
  for(size_t enviados = 0; ok && enviados < elf->n;) {
    ssize_t r = send(fd, elf->d + enviados, elf->n - enviados, SEM_SINAL);
    if(r <= 0) ok = 0;
    else enviados += (size_t)r;
  }
  if(ok) {
    shutdown(fd, SHUT_WR);
    char saida[2048];
    size_t n = 0;
    time_t limite = time(NULL) + 25;   /* o lock pode esperar ate ~18 s pela saida de outra copia */
    while(time(NULL) < limite && n + 1 < sizeof saida) {
      ssize_t r = recv(fd, saida + n, sizeof saida - 1 - n, 0);
      if(r == 0) break;
      if(r < 0) {
        if(errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) continue;
        break;
      }
      n += (size_t)r;
      saida[n] = 0;
      if(strstr(saida, "ready") || strstr(saida, "handoff") || strstr(saida, "busy") || strstr(saida, "[elfldr.elf]")) break;
    }
    saida[n] = 0;
    const char *w = strstr(saida, "ready") ? "ready" : strstr(saida, "handoff") ? "handoff" : strstr(saida, "busy") ? "busy"
                    : strstr(saida, "[elfldr.elf]") ? "recusado" : "";
    snprintf(palavra, tam, "%s", w);
  }
  close(fd);
  return ok ? 0 : -1;
}

static void *trabalhar(void *arg) {
  (void)arg;
  avaliacao_t a;
  buf_t elf = {0};
  fase("conferindo");
  avaliar(&a, 1);
  int e = escolhido(&a, 0);
  if(e < 0) {
    char motivos[400] = "";
    for(int i = 0; i < 3; i++) {
      size_t n = strlen(motivos);
      snprintf(motivos + n, sizeof motivos - n, "%s%s: %s", i ? "; " : "", a.c[i].arquivo, a.c[i].motivo);
    }
    falhou("nenhuma copia conferida do payload da Jobe (%s)", motivos);
    goto fim;
  }
  cand_t *c = &a.c[e];
  char cam[480], sha[65];
  arquivo(c->arquivo, cam, sizeof cam);
  /* le de novo e confere o que vai ser enviado (o arquivo pode ter mudado depois da conferencia) */
  if(ler_tudo(cam, MAX_ELF, &elf)) {
    falhou("nao deu para ler %s", c->arquivo);
    goto fim;
  }
  sha256_t s;
  uint8_t resumo[32];
  sha256_iniciar(&s);
  sha256_atualizar(&s, elf.d, elf.n);
  sha256_final(&s, resumo);
  sha256_hex(resumo, sha);
  if(elf.n != c->tam || strcmp(sha, c->sha) || elf.n < 4 || memcmp(elf.d, "\x7f" "ELF", 4)) {
    falhou("%s mudou durante a conferencia: nada enviado", c->arquivo);
    goto fim;
  }
  if(no_ar()) {
    falhou("o payload da Jobe subiu enquanto conferia: nada enviado");
    goto fim;
  }
  fase("enviando");
  diario("jobe-payload: enviando %s %s (%zu bytes, conferido por %s, sha256 %.16s...) ao elfldr", c->arquivo, c->versao, elf.n, c->como, sha);
  char palavra[16];
  if(enviar_elfldr(&elf, palavra, sizeof palavra)) {
    falhou("o elfldr (porta 9021) nao respondeu");
    goto fim;
  }
  diario("jobe-payload: o payload respondeu \"%s\"", palavra);
  if(!strcmp(palavra, "busy") || !strcmp(palavra, "recusado")) {
    falhou("%s", !strcmp(palavra, "busy") ? "outra copia do payload da Jobe segura o lock" : "o elfldr recusou o arquivo");
    goto fim;
  }
  fase("subindo");
  char versao[24] = "";
  int pid = 0, ar = 0;
  for(int i = 0; i < 60 && !ar; i++) {   /* ate 30 s (handoff: o novo assume pelo lock) */
    usleep(500000);
    ar = no_ar();
  }
  if(!ar) {
    falhou("enviado, mas o payload da Jobe nao respondeu em 30 s (veja %s no diagnostico)", "bgdl.log");
    goto fim;
  }
  for(int i = 0; i < 10 && !versao_no_ar(versao, sizeof versao, &pid); i++) usleep(300000);
  pthread_mutex_lock(&g_trava);
  snprintf(g.resultado, sizeof g.resultado, "%s%s%s (%s)", versao[0] ? "no ar v" : "no ar", versao, !strcmp(palavra, "handoff") ? ", passou a vez para a baixada mais nova" : "", c->arquivo);
  g.quando = time(NULL);
  pthread_mutex_unlock(&g_trava);
  diario("jobe-payload: %s", g.resultado);
fim:
  buf_free(&elf);
  pthread_mutex_lock(&g_trava);
  g.fase[0] = 0;
  g.ocupado = 0;
  pthread_mutex_unlock(&g_trava);
  return NULL;
}

void jobe_payload_rota_ligar(pedido_t *p) {
  int ps5 = fps_agente_ps5(p->agente);
  if(p->local && !ps5) {
    responder_erro(p, 403, "jobe_payload_so_aparelho", "so pelo celular, PC pareado ou navegador do PS5", NULL);
    return;
  }
  pthread_mutex_lock(&g_trava);
  if(g.ocupado) {
    pthread_mutex_unlock(&g_trava);
    responder_erro(p, 409, "jobe_payload_ocupado", "ja esta ligando o payload da Jobe: espere", NULL);
    return;
  }
  g.ocupado = 1;
  pthread_mutex_unlock(&g_trava);
  if(no_ar()) {
    char versao[24];
    int pid;
    versao_no_ar(versao, sizeof versao, &pid);
    pthread_mutex_lock(&g_trava);
    g.ocupado = 0;
    pthread_mutex_unlock(&g_trava);
    diario("jobe-payload: ligar recusado: ja esta no ar%s%s", versao[0] ? " v" : "", versao);
    responder_erro(p, 409, "jobe_payload_no_ar", "o payload da Jobe ja esta no ar (mandar outro derrubaria o que esta rodando)", versao);
    return;
  }
  pthread_mutex_lock(&g_trava);
  g.erro[0] = 0;
  g.resultado[0] = 0;
  snprintf(g.fase, sizeof g.fase, "conferindo");
  pthread_mutex_unlock(&g_trava);
  diario("jobe-payload: ligar pedido pelo %s", ps5 ? "navegador do PS5" : "aparelho pareado");
  if(criar_thread(trabalhar, NULL, NULL)) {
    pthread_mutex_lock(&g_trava);
    g.ocupado = 0;
    g.fase[0] = 0;
    pthread_mutex_unlock(&g_trava);
    responder_erro(p, 500, "jobe_payload_erro", "nao iniciou", NULL);
    return;
  }
  responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
}
