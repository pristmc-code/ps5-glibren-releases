#!/bin/bash
# 0.9.27: "Ligar o payload da Jobe" na versao de PC. Usa os arquivos REAIS da release bg-downloader-1.37.2 (assinados
# com a chave da Jobe = a chave publica embutida no glibren): confere a assinatura de verdade. Casos: baixado assinado,
# manifesto/ELF adulterados, versao marcada como ruim, incompativel com o app, embedded.elf conferido pela release
# (servidor local no lugar do GitHub), embedded.elf diferente da release, nada no PS5, pareamento/X-GLR/programa local,
# envio ao elfldr (falso) com "ready"/"busy", ja no ar (409, sem segundo envio) e a versao lida do bgdl.log.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_jobe_payload.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
REAL="$ORIGEM/../jobe/ferramentas/saida-bg-downloader-1.37.2"
PORTA=8896; PORTA_SRV=8897; PORTA_ELFLDR=8898; PORTA_JOBE=8899
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R="http://$IP:$PORTA"
T=/root/glr-jobepl-teste; DADOS=$T/dados; SRV=$T/srv; J=$T/jobe; A=$T/lista
UA_PS5='Mozilla/5.0 (PlayStation; PlayStation 5/12.00) AppleWebKit/605.1.15 (KHTML, like Gecko)'
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
codigo() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
estado() { curl -s "$L/api/jobe-payload"; }
espera_livre() { for i in $(seq 1 160); do estado | grep -q '"ocupado":false' && return; sleep 0.25; done; }
if [ ! -f "$REAL/bg-downloader.elf" ]; then echo "PULADO: sem $REAL"; echo "=== 0 ok, 0 falhas (pulado)"; exit 0; fi
rm -rf "$T"; mkdir -p "$DADOS" "$SRV/bg-downloader-1.37.2" "$J" "$A"
printf 'language = pt-BR\nfolder = %s/\n' "$A" > "$DADOS/config.ini"
cp "$REAL/bg-downloader.json" "$REAL/bg-downloader.json.sig" "$SRV/bg-downloader-1.37.2/"
SHA=$(sha256sum "$REAL/bg-downloader.elf" | cut -d' ' -f1)
(cd "$SRV" && exec python3 -m http.server $PORTA_SRV --bind 127.0.0.1) > "$T/srv.log" 2>&1 &
PID_SRV=$!

# elfldr de mentira: guarda o .elf, responde como o bg-downloader (modo) e, com "ready", "sobe" o payload: porta do
# /health (401 sem token), bgdl.pid e a linha de inicio no bgdl.log
cat > "$T/elfldr.py" <<'EOF'
import socket, sys, threading, os
porta, pasta, porta_jobe, jdir = int(sys.argv[1]), sys.argv[2], int(sys.argv[3]), sys.argv[4]
def saude():
    s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); s.bind(("127.0.0.1", porta_jobe)); s.listen(8)
    while True:
        c, _ = s.accept()
        try:
            pedido = c.recv(4096)
            open(pasta + "/saude.txt", "ab").write(pedido.split(b"\r\n")[0] + b" | " + (b"COM-TOKEN" if b"x-jobe-token" in pedido.lower() else b"sem-token") + b"\n")
            c.sendall(b'HTTP/1.1 401 Unauthorized\r\nContent-Length: 33\r\nConnection: close\r\n\r\n{"error":"missing or wrong token"}')
        except Exception: pass
        c.close()
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); s.bind(("127.0.0.1", porta)); s.listen(4)
n = 0
while True:
    c, _ = s.accept(); dados = b""
    while True:
        d = c.recv(65536)
        if not d: break
        dados += d
    n += 1
    open(pasta + "/recebido.elf", "wb").write(dados)
    open(pasta + "/conexoes", "w").write(str(n))
    modo = open(pasta + "/modo").read().strip()
    if modo == "ready":
        open(jdir + "/bgdl.pid", "w").write("4242\n")
        with open(jdir + "/bgdl.log", "a") as f:
            f.write("2026-11-14 00:40:00 ==== iniciando bg-downloader 1.30.0 (velho, api 30), pid 1111, pai 1\n")
            f.write("2026-11-14 00:41:00 ==== iniciando bg-downloader 1.37.2 (teste, api 37), pid 4242, pai 1\n")
        threading.Thread(target=saude, daemon=True).start()
        c.sendall(b"ready\n")
    elif modo == "busy":
        c.sendall(b"busy\n")
    c.close()
EOF
echo ready > "$T/modo"
python3 -I "$T/elfldr.py" $PORTA_ELFLDR "$T" $PORTA_JOBE "$J" > "$T/elfldr.log" 2>&1 &
PID_EL=$!

inicia() {
  GLR_TESTE_BASE="http://127.0.0.1:$PORTA_SRV/" GLR_TESTE_JOBE_REL="http://127.0.0.1:$PORTA_SRV/bg-downloader-" GLR_TESTE_JOBE_DIR="$J" \
  GLR_TESTE_JOBE_PORTA=$PORTA_JOBE GLR_TESTE_ELFLDR=$PORTA_ELFLDR "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
copia_real() { cp "$REAL/bg-downloader.elf" "$REAL/bg-downloader.json" "$REAL/bg-downloader.json.sig" "$J/"; }
printf '{"api":37,"embedded":"1.37.2"}' > "$J/app.json"
copia_real
inicia

echo "--- baixado assinado (arquivos reais da release 1.37.2)"
E=$(estado)
confere "fora do ar"                      "$E" '"no_ar":false'
confere "candidato: bg-downloader.elf"    "$E" '"candidato":{"arquivo":"bg-downloader.elf","versao":"1.37.2","como":"assinatura","conferido":true'
confere "sha256 do candidato"             "$E" "\"sha256\":\"$SHA\""
confere "app.json lido"                   "$E" '"app_api":37,"app_embutido":"1.37.2"'
confere "embutido ausente explicado"      "$E" '"arquivo":"embedded.elf","versao":"","ok":0,"motivo":"nao existe (a Jobe deixa ao abrir)"'
confere "pagina: botao"                   "$(curl -s $L/payloads)" 'Ligar o payload da Jobe'
confere "pagina: autoloader"              "$(curl -s $L/payloads)" 'autoload.txt'
# 0.9.27: o script da pagina Payloads nao rodava desde a 0.9.23 ("const conf" duas vezes no mesmo bloco = SyntaxError):
# confere a sintaxe dos scripts de TODAS as paginas (node --check), se houver node
NODE=$(command -v node || ls /opt/node-*/bin/node 2>/dev/null | head -1)
if [ -n "$NODE" ]; then
  for h in "$ORIGEM"/web/*.html; do
    python3 -I - "$h" "$T/js-$(basename "$h" .html).js" <<'EOF'
import re, sys
s = open(sys.argv[1], encoding="utf-8").read()
blocos = re.findall(r"<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>", s, re.S)
open(sys.argv[2], "w", encoding="utf-8").write("\n;\n".join("(async () => {\n" + b + "\n})" for b in blocos))
EOF
    confere "sintaxe JS: $(basename "$h")" "$("$NODE" --check "$T/js-$(basename "$h" .html).js" 2>&1 && echo sintaxe-ok)" "sintaxe-ok"
  done
else
  echo "PULADO: sem node para conferir a sintaxe dos scripts"
fi

echo "--- adulterados e recusas da Jobe"
sed -i 's/"api": 37/"api": 38/' "$J/bg-downloader.json"
confere "manifesto mudado: assinatura"    "$(estado)" '"arquivo":"bg-downloader.elf","versao":"","ok":0,"motivo":"assinatura nao confere (nao e da Jobe)"'
copia_real
printf 'X' | dd of="$J/bg-downloader.elf" bs=1 seek=100000 conv=notrunc 2>/dev/null
confere "ELF mudado: sha"                 "$(estado)" '"motivo":"o .elf nao e o do manifesto (tamanho ou SHA-256 diferente)"'
confere "ELF mudado: sem candidato"       "$(estado)" '"candidato":null'
copia_real
echo '{"bad":["1.37.2"],"strikes":{}}' > "$J/self-update.json"
confere "versao ruim recusada"            "$(estado)" 'marcada como ruim pela Jobe'
rm "$J/self-update.json"
printf '{"api":40,"embedded":"1.40.0"}' > "$J/app.json"
confere "incompativel com o app"          "$(estado)" 'incompativel com a Jobe instalada (api 37, a Jobe usa 40)'
printf '{"api":37,"embedded":"1.37.2"}' > "$J/app.json"
# a .prev tambem vale
for x in elf json json.sig; do mv "$J/bg-downloader.$x" "$J/bg-downloader.prev.$x"; done
confere "a anterior (.prev) serve"        "$(estado)" '"candidato":{"arquivo":"bg-downloader.prev.elf","versao":"1.37.2","como":"assinatura","conferido":true'
rm -f "$J"/bg-downloader.prev.*

echo "--- pareamento, X-GLR e programa local"
confere "rede sem pareamento: 401"        "$(codigo -H 'X-GLR: 1' -X POST $R/api/jobe-payload/ligar)" "401"
confere "sem X-GLR: 403"                  "$(codigo -X POST $L/api/jobe-payload/ligar)" "403"
confere "programa local: recusado"        "$(post -X POST $L/api/jobe-payload/ligar)" "jobe_payload_so_aparelho"
confere "GET livre pela rede"             "$(codigo $R/api/jobe-payload)" "200"

echo "--- nada conferido no PS5"
confere "sem copia: candidato null"       "$(estado)" '"candidato":null'
confere "ligar sem copia iniciou"         "$(post -A "$UA_PS5" -X POST $L/api/jobe-payload/ligar)" '"ok":true'
espera_livre
confere "sem copia: erro explicado"       "$(estado)" 'nenhuma copia conferida do payload da Jobe'
confere "sem copia: elfldr nao chamado"   "$(cat $T/conexoes 2>&1)" "No such"

echo "--- embedded.elf conferido pela release (servidor local no lugar do GitHub)"
cp "$REAL/bg-downloader.elf" "$J/embedded.elf"
E=$(estado)
confere "embutido: pendente ate ligar"    "$E" '"candidato":{"arquivo":"embedded.elf","versao":"1.37.2","como":"release","conferido":false'
printf 'X' | dd of="$J/embedded.elf" bs=1 seek=200000 conv=notrunc 2>/dev/null
post -A "$UA_PS5" -X POST $L/api/jobe-payload/ligar > /dev/null; espera_livre
confere "embutido diferente: recusado"    "$(estado)" 'o embedded.elf nao e o da release'
confere "embutido diferente: sem elfldr"  "$(cat $T/conexoes 2>&1)" "No such"
cp "$REAL/bg-downloader.elf" "$J/embedded.elf"
echo busy > "$T/modo"
post -A "$UA_PS5" -X POST $L/api/jobe-payload/ligar > /dev/null; espera_livre
confere "busy: erro do lock"              "$(estado)" 'outra copia do payload da Jobe segura o lock'
echo ready > "$T/modo"
confere "ligar (navegador do PS5) iniciou" "$(post -A "$UA_PS5" -X POST $L/api/jobe-payload/ligar)" '"ok":true'
confere "ocupado: segundo pedido recusado" "$(post -A "$UA_PS5" -X POST $L/api/jobe-payload/ligar)" 'jobe_payload_ocupado\|jobe_payload_no_ar'
espera_livre
E=$(estado)
confere "no ar"                           "$E" '"no_ar":true'
confere "versao do bgdl.log (pid certo)"  "$E" '"versao":"1.37.2","pid":4242'
confere "resultado"                       "$E" '"resultado":"no ar v1.37.2 (embedded.elf)"'
confere "elfldr recebeu o ELF real"       "$(cmp $REAL/bg-downloader.elf $T/recebido.elf && echo igual)" "igual"
G=$(cat $DADOS/glibren.log)
confere "diario: manifesto da release"    "$G" "manifesto da release 1.37.2: HTTP 200 / 200"
confere "diario: enviado"                 "$G" "enviando embedded.elf 1.37.2"
confere "diario: ready"                   "$G" 'o payload respondeu "ready"'
confere "health sem o token (nao finge ser o app)" "$(cat $T/saude.txt)" "GET /health HTTP/1.1 | sem-token"
confere "nunca com o token"               "$(grep -c COM-TOKEN $T/saude.txt)" "^0$"

echo "--- ja no ar: nao manda outro"
N=$(cat $T/conexoes)
copia_real
confere "ja no ar: 409 com a versao"      "$(post -A "$UA_PS5" -X POST $L/api/jobe-payload/ligar)" '"chave":"jobe_payload_no_ar".*"nome":"1.37.2"'
sleep 0.5
confere "ja no ar: elfldr nao chamado"    "$(cat $T/conexoes)" "^$N$"
confere "ja no ar: diario"                "$(cat $DADOS/glibren.log)" "ligar recusado: ja esta no ar v1.37.2"
# pareado pela rede tambem pode (e recebe o mesmo 409)
post -X POST $R/api/parear/pedir > /dev/null; sleep 0.3
C=$(grep -o 'pareamento [0-9]\{6\}' "$T/glr.log" | tail -1 | awk '{print $2}')
TK=$(post -d codigo=$C -d nome=teste $R/api/parear | grep -o '"token":"[0-9a-f]*"' | cut -d'"' -f4)
confere "pareado pela rede: 409 no ar"    "$(post -H "X-GLR-Token: $TK" -X POST $R/api/jobe-payload/ligar)" 'jobe_payload_no_ar'
para

kill $PID_SRV $PID_EL 2>/dev/null; wait $PID_SRV $PID_EL 2>/dev/null
echo "=== $ok ok, $falhas falhas"
[ $falhas -eq 0 ]
