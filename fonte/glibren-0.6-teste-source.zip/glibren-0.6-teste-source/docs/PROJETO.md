# Game Library Renamer — payload PS5 (ELF)

Notas de desenvolvimento (em portugues). A documentacao de uso esta no [README](../README.md).

Estado (03/11/2026): **versao 0.1-teste pronta para o primeiro teste no PS5**. Repositorio privado.
Testado so no PC (WSL, versao Linux do mesmo codigo): testes da API e da fila de tarefas ok, telas no
navegador do PC e num celular Android emulado, regra de nome JS = Python nos 71.345 titulos.
**Ainda nao rodou num PS5 real.**

## Funcoes adicionadas depois da 0.1 (03/11/2026)

- Tela tambem pelo PC e celular (http://IP-DO-PS5:8765), com layouts proprios para TV, PC e celular.
- Copiar / mover / excluir em lote (`src/tarefas.c`): fila com thread propria, `.part` ate terminar, confere
  espaco livre, nunca sobrescreve (ignora o que ja existe no destino), mover no mesmo disco = rename(),
  renomear junto e opcao do usuario (desligado), exclusao com aviso visivel por 3 s, le as pastas de novo no fim.
- Temperatura e ventoinha (`src/termico.c`, `src/sistema.c`, `web/temperatura.html`): CPU, SoC, SSD M.2,
  ventoinha %, grafico de 8 min, vista BASICO/AVANCADO (CPU por nucleo, RAM, IP, tempo ligado), alerta por
  notificacao, controle do alvo da ventoinha (50-85 °C, nunca acima do valor do sistema; reaplica a cada 2 s;
  recua para o automatico em conflito com outro programa ou apos 5 falhas).
- Teste de velocidade dos discos (`src/discos.c`, `web/discos.html`): SSD interno, armazenamento estendido e
  USB; 1/2/4/8 GB; arquivo temporario apagado no fim e sobras limpas ao iniciar.
- Teste de internet (`src/internet.c`, `web/internet.html`): ping/jitter (tempo de conexao TCP), download e
  upload com 4 conexoes; servidores proximos da lista publica do speedtest.net (pedida pelo PS5, segue a regiao)
  ou Cloudflare; automatico escolhe pelo menor ping e cai para a Cloudflare se falhar.
- Servidor reabre a porta depois do modo de repouso; fechamento gradual das conexoes (esperar o navegador
  fechar evita perder os ultimos bytes em redes lentas).
- Paginas param de consultar o PS5 quando a aba fica em segundo plano.
- Licenca: GPL-3.0-or-later (como o SDK).

## 0.2-teste (03/11/2026 noite): resultado do 1o teste no PS5 real e correcoes

Teste da 0.1 no PS5: o glibren-install.elf **nao criou o icone** e o payload **nao ficou rodando** (as vezes a
tela abria pelo celular e logo depois "o PS5 nao respondeu"). Comparado com o ProsperoMgr e o websrv (que
funcionam), a 0.2 passa a:
- elevar as permissoes do proprio processo antes de tudo (uid 0, rootdir/jaildir, authid 0x4801000000000013,
  caps e attrs) - sem o authid o PS5 recusa registrar o icone;
- nomear o processo `glibren.elf` (thr_set_name) e matar copias antigas com esse nome (lista kinfo_proc);
- `sceUserServiceInitialize`; ignorar SIGPIPE/SIGHUP e SO_NOSIGPIPE em cada conexao;
- threads com pilha de 1 MB (as conexoes usam buffers de 64 KB na pilha);
- reabrir a porta no SIGCONT (volta do repouso);
- diario em `/data/GameLibraryRenamer/glibren.log` + aviso na tela se cair (sinal fatal);
- **o proprio payload cria o icone** (metodo do ProsperoMgr: o tile aponta para a porta do proprio payload,
  127.0.0.1:8765), registrando a pasta /user/app/PMGL00001 como o websrv faz (sceAppInstUtilAppInstallTitleDir).
  O ProsperoMgr instala um PKG feito com as ferramentas oficiais da Sony - nao usamos isso.
  O icone so funciona com o payload rodando (igual ao ProsperoMgr). glibren-install.elf foi removido.
- Removido todo acesso a loja da Sony (capa de reserva da PS Store).

## 0.3-teste (03/11/2026): internet no PS5

No teste da 0.2 o payload rodou mas nao acessou a internet. A 0.3 troca a sceHttp2 pela sceHttp (como o ProsperoMgr):
contexto novo por pedido, DNS proprio (DNS do PS5 e reserva em 8.8.8.8/1.1.1.1; conecta pelo IP com Host e,
se o site recusar, pelo nome; lembra o que funcionou), tempo limite de 20 s, redirecionamentos seguidos aqui,
sceNetCtlInit depois de elevar as permissoes. **A verificacao do certificado continua ligada** (o ProsperoMgr
desliga; nao fizemos isso). Cada falha vai para o diario, que agora abre em http://IP-DO-PS5:8765/diario.

## 0.4-teste (03/11/2026): CPU/memoria, grafico e icone em Midia

- Memoria e nucleos nao apareciam no PS5. O ProsperoMgr nao mostra isso; o ps5-web-manager usa os mesmos sysctl.
  A 0.4 pergunta o tamanho do kern.cp_times antes (o kernel pode responder com espaco para mais CPUs que as
  existentes; ignora as zeradas), le os numeros com 4 ou 8 bytes, tenta hw.physmem/realmem/usermem e
  v_free+v_inactive+v_cache, CLOCK_UPTIME como reserva do tempo ligado, e registra no diario o sysctl que falhar.
- Grafico de temperatura pequeno no rodape no navegador do PS5 (WebKit nao estica svg com flex): agora fica numa
  area de tamanho proprio com o svg em posicao absoluta.
- Icone aparecia em Jogos: param.json com "applicationCategoryType": 65536 (o tile do ProsperoMgr usa esse valor);
  o payload reinstala o icone sozinho porque o conteudo mudou.
- Tela grande demais no PS5: o navegador do PS5 mostra uma area menor que a TV. O ProsperoMgr nao amplia nada no
  PS5 (so tira efeitos pesados). A 0.4 usa no PS5 os mesmos tamanhos do PC e tira o zoom de 1,25-1,3.
- Pagina Jogos: o texto explicativo vai para baixo dos botoes (largura toda), sem apertar o titulo.
- Botao de tela cheia aparecia no PS5 (o display do botao vencia o atributo hidden): regra [hidden] geral.

## 0.5-teste (03/11/2026): internet, CPU/memoria, botao parar

- Diario do teste 0.4: rede e DNS ok; toda conexao segura falhava (0x8095f00b/0x8095f010 pelo IP, 0x8095f00c pelo
  nome). O JobeesLair liga o SNI do sceHttps (opcao 0x80): "sem ele nenhum pedido a Cloudflare ou ao GitHub passa da
  negociacao". A 0.5 liga o SNI, tenta pelo nome com a verificacao do certificado ligada e, se a parte segura ainda
  falhar, passa a aceitar o certificado sem verificar (como o ProsperoMgr) - autorizado pelo usuario; o diario avisa.
- CPU/memoria: o PS5 nao tem kern.cp_times nem vm.stats/hw.physmem (errno 2; o PS5_DevTools confirma). Agora:
  CPU por nucleo pelo tempo das threads ociosas ("idle: cpuN"/"SceIdleCpuN") na lista de processos (kinfo_proc com
  threads); memoria = soma da residente de todos os processos sobre 16 GB, mostrada com "≈". Se nao achar as threads
  ociosas, o diario lista os nomes das threads do kernel.
- Botao "⏻ Parar payload" (era "Sair") com confirmacao.
- Teste de internet no PC/PS5 com o arranjo lado a lado (medidor menor a esquerda).

## Icone na aba Midia (0.1 - substituido pela 0.2 acima)

A tela e para usar **no proprio PS5**, por um icone na aba Midia (como outros payloads), que abre por
cima do app da loja que esta baixando (app comum fecharia o outro). Tambem abre pelo PC e celular.
Como funciona (mesmo esquema do instalador do ftpsrv, `install-ps5.c`):
- `glibren-install.elf` (enviado uma vez) cria `/user/app/PMGL00001/` com `payload.elf`,
  `iniciar.html`, `sce_sys/icon0.png` (512x512) e `sce_sys/param.json` (`deeplinkUri`
  `http://127.0.0.1:8080/fs/user/app/PMGL00001/iniciar.html`) e registra o titulo
  (sceAppInstUtilAppInstallTitleDir pelo NID Wudg3Xe3heE; reserva sceAppInstUtilAppInstallAll).
- O icone abre `iniciar.html` **pelo websrv (porta 8080)**: se o payload ja responde em 8765, vai para a tela;
  se nao, chama `/elfldr?elf=file://user/app/PMGL00001/payload.elf` do websrv e espera ate 30 s.
- Depende do websrv rodando (o icone do ftpsrv tambem depende).
- Tela no PS5: html.ps5 (user agent "PlayStation") com zoom 1.3, foco para o controle, confirmacao do
  "Renomear todos" dentro da pagina (confirm() pode nao funcionar no app de midia), sem botao Loja (sites da
  Sony nao abrem no PS5 desbloqueado) e sem YouTube (abriria o app).

## Como usar (teste)

1. Compilar: `wsl -d Ubuntu-24.04 -u root -- bash /mnt/d/##__GoogleDrive/###_Claude/ps5/payload/compilar.sh all pc`
   -> `payload/saida/glibren.elf` (PS5) e `glibren-pc` (Linux, teste).
2. Enviar `glibren-install.elf` para o PS5 (elfldr, porta 9021) uma vez: aparece o icone
   "Game Library Renamer" na aba Midia (notificacao confirma).
3. Abrir pelo icone (com o websrv ativo). Tambem funciona de outro aparelho em http://IP-DO-PS5:8765.
4. Dados no PS5: `/data/GameLibraryRenamer/` (config.ini, base_titulos.tsv, cache_consultas.json, icones/).

Testes no PC: `testes/teste_api.sh` (API, 31 casos), `testes/comparar_nomes.py base_titulos.tsv` (regra de nome),
`testes/demo.sh` (sobe a demo em http://localhost:8765 com pastas de mentira; `demo.sh parar`).

## Objetivo

Um payload `.elf` que roda no proprio PS5 (enviado pelo elfldr, porta 9021) e faz o mesmo que o app de PC,
sem FTP:

- abre um servidor web no PS5 (porta **8765**); a tela e a mesma pagina do app, aberta no navegador do PC,
  do celular ou do proprio PS5 em `http://IP-DO-PS5:8765`;
- **gerenciador de arquivos**: navegar pelas pastas do PS5 e escolher quais entram na lista de pastas
  (substitui a parte de FTP/IP/porta/usuario/senha/INI);
- o resto igual ao app atual: le a raiz das pastas escolhidas so quando a tela abre ou o usuario clica
  para atualizar (decisao do usuario: "igual hoje", sem vigiar nem renomear sozinho), mostra nome, capa,
  tamanho, novo nome, filtros, Renomear / Renomear todos, idiomas pt-BR/en/es, Loja/YouTube.

Decisoes do usuario (03/11/2026): app de PC e Android ficam como estao por enquanto; monitoramento
"igual hoje"; compilacao com **WSL** (instalado pelo usuario, faltava reiniciar o PC).

## Como e feito um payload (pesquisa)

- SDK: https://github.com/ps5-payload-dev/sdk (v0.45, 21/10/2026). So compila em Linux/macOS
  (clang-18 + lld-18). Instalacao: baixar `ps5-payload-sdk.zip` da release e descompactar em
  `/opt/ps5-payload-sdk`; `export PS5_PAYLOAD_SDK=/opt/ps5-payload-sdk`.
- Makefile: `include $(PS5_PAYLOAD_SDK)/toolchain/prospero.mk`; `$(CC) $(CFLAGS) -o x.elf ...`;
  envio: `$(PS5_DEPLOY) -h $(PS5_HOST) -p 9021 x.elf` (ou `nc -q0 IP 9021 < x.elf`).
- Libc estilo FreeBSD: sockets, pthread, `opendir/readdir/stat/rename`, `getifaddrs` (o ftpsrv usa
  para descobrir o IP e mostrar na notificacao).
- Notificacao na tela do PS5: `sceKernelSendNotificationRequest(0, &req, sizeof req, 0)` com struct
  `{ char useless1[45]; char message[3075]; }` (igual ao ftpsrv `notify.c`).
- Permissoes: o ftpsrv chama `kernel_set_ucred_authid(getpid(), 0x4801000000000013L)`; o exemplo
  `list_files` troca o rootdir (`kernel_set_proc_rootdir(pid, kernel_get_root_vnode())`) para ver o
  sistema de arquivos inteiro. Confirmar no PS5 qual dos dois e preciso para ler /data e /mnt/ext1.
- HTTPS a partir do payload: bibliotecas do proprio PS5 (`sceNetInit`, `sceSslInit`, `sceHttp2Init`,
  `sceHttp2CreateTemplate`, `sceHttp2CreateRequestWithURL`, `sceHttp2SendRequest`,
  `sceHttp2GetStatusCode`, `sceHttp2ReadData`) — exemplo `samples/http2_get` do SDK.
- Uma copia so: o ftpsrv procura outro processo com o mesmo nome (`sysctl` + `SYS_thr_set_name`) e mata
  antes de subir. Fazer igual.
- Portas ja usadas por outros payloads: 2121 (ftpsrv), 8080 (websrv), 9021 (elfldr), 1337 (etaHEN FTP).

## Arquitetura proposta

O payload em C fica **fino**; a logica que ja existe em Python vai para o JavaScript da pagina
(roda no navegador de quem abre a tela). Assim o C fica pequeno e facil de manter.

| Parte | Onde roda | O que faz |
|---|---|---|
| Servidor HTTP | payload (C) | serve a pagina embutida no ELF e a API JSON |
| Gerenciador de arquivos | payload (C) | `GET /api/fs?caminho=` lista pastas e arquivos (nome, tipo, tamanho) |
| Pastas e idioma | payload (C) | arquivo de config em `/data/GameLibraryRenamer/` |
| Leitura das pastas | payload (C) | `GET /api/escanear`: arquivos da raiz de cada pasta, com tamanho |
| Regras (compactado, patch, download em andamento, codigo no nome) | pagina (JS) | portadas de `ftp_ps5.py` |
| Renomear | payload (C) | `POST /api/renomear` com as mesmas travas: origem existe, destino nao existe, nome seguro, nao e download em andamento, tamanho nao mudou |
| Base de titulos (All_Titles.tsv, ~6 MB) | payload baixa (HTTPS) e guarda no PS5; a pagina carrega e consulta | atualiza 1x por dia |
| Nome novo (`nome_para_arquivo`) e limite do ShadowMountPlus | pagina (JS) | portado de `consulta_ps5.py` |
| Publisher, icone (prosperopatches/orbispatches/PS Store) | payload busca por HTTPS, so nesses sites (lista fixa) | icones guardados no PS5 |
| Loja / YouTube | pagina | links normais, abrem no navegador de quem esta usando |

Teste sem PS5: o mesmo codigo C compila para Linux (WSL) com `Makefile.pc`; a parte de HTTPS usa
`curl` no lugar da sceHttp2 e as "pastas do PS5" sao pastas de teste no WSL.

## Estrutura

```
README.md          documentacao de uso (ingles)
Makefile           build PS5 (make) e Linux/WSL para teste (make pc); paginas embutidas com xxd + gzip
compilar.sh        compila no WSL fora do Google Drive e copia para saida/
src/               servidor HTTP, API, arquivos, tarefas, termico, sistema, discos, internet, https, config
web/               paginas (index, temperatura, discos, internet, youtube) e icone
instalador/        glibren-install.elf: icone na aba Midia (PMGL00001)
testes/            demo, testes da API e da fila, comparacao da regra de nome
docs/              estas notas, ideias e capturas de tela
```

## Feito na 0.1-teste

- `src/http.c` servidor HTTP (thread por conexao); `src/api.c` rotas; `src/arquivos.c` gerenciador de arquivos,
  leitura das pastas e renomear (travas: nome seguro, origem existe, destino nao existe — exFAT: mesma inode pode,
  download em andamento, tamanho mudou); `src/config.c` config.ini (language + folder=); `src/https.c` sceHttp2
  no PS5 / curl no PC, so hosts da lista fixa; `src/plataforma.c` notificacao, IP, rootdir; `src/main.c`
  (segunda copia pede /api/sair para a antiga e assume a porta).
- `web/index.html`: copia da tela do PC sem FTP; gerenciador de arquivos (modal), POST como formulario + cabecalho
  X-GLR (bloqueia outros sites), consulta (base TSV lida pela tela, site via /api/web, cache no PS5 via /api/cache),
  icones via /icone/CODIGO?url=&url2= (site, reserva PS Store; falha = 5 min sem tentar), links Loja/YouTube abrem
  em aba nova. Sem lookbehind no JS (navegador do PS5 pode ser antigo). Aba Consulta manual removida (pedido do usuario).

## Pendencias / riscos

- Seguranca: qualquer aparelho da rede local pode abrir a pagina e renomear (como o FTP sem senha hoje).
  Avaliar um PIN opcional.
- Testar no PS5 real: permissoes de pasta (rootdir), HTTPS (sceHttp2: assinatura do Init com 4 conexoes,
  sem tempo limite configurado — funcoes sceHttp2Set*TimeOut existem mas sem assinatura documentada; downloads
  do PS5 estao serializados por um mutex), notificacao, navegador do PS5 (JS moderno: ??=, ?., \p{M}).

## Ambiente (feito em 03/11/2026)

WSL com Ubuntu-24.04 (instalado com `wsl --install -d Ubuntu-24.04 --no-launch`, usado como root, sem usuario
criado); clang-18, lld-18, make, curl, xxd, rsync; SDK v0.45 em /opt/ps5-payload-sdk. Do Git Bash, chamar o
wsl com `MSYS_NO_PATHCONV=1` (senao o caminho /mnt/... vira C:/Program Files/Git/mnt/...).

## Proximos passos

1. Usuario testa o `.elf` no PS5 e relata (notificacao, endereco, pastas, base, icones, renomear).
2. Ajustar o que falhar no PS5 (provavel: permissoes/rootdir, sceHttp2).
3. Depois: tempo limite no sceHttp2, PIN opcional, atalho no controle durante o jogo (ver IDEIAS.md),
   servir a base de titulos compactada, publicar (so com ordem).
