/* Game Library Renamer (payload PS5) - uso de CPU, memoria, IP e tempo ligado.

PS5: o console nao responde aos sysctl de CPU e memoria do FreeBSD (kern.cp_times, vm.stats.*, hw.physmem - errno 2
no 1o teste; o PS5_DevTools confirma que nao ha numero de memoria livre do sistema). Entao, pela lista de processos
do kernel (kinfo_proc):
- CPU por nucleo: tempo das threads ociosas de cada nucleo ("idle: cpuN" / "SceIdleCpuN"); uso = 100% menos o
  tempo ocioso no intervalo;
- memoria: soma da memoria residente de todos os processos (aproximada) sobre os 16 GB do PS5.
PC (teste): /proc/stat e /proc/meminfo. O uso de CPU e a diferenca entre duas leituras (2 s).
*/
#include "sistema.h"

#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <time.h>
#include <unistd.h>

#ifdef __PROSPERO__
#include <sys/sysctl.h>
#include <sys/time.h>
#include <sys/user.h>
#define RAM_PS5 (16LL * 1024 * 1024 * 1024)   /* GDDR6 do PS5 */
#endif

#include "plataforma.h"

#define MAX_NUCLEOS 32
#define INTERVALO_S 2

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static int g_nucleos;
static double g_uso[MAX_NUCLEOS], g_uso_total = -1;
static long long g_ram_total = -1, g_ram_livre = -1, g_ligado_s = -1;
static int g_ram_aprox;   /* 1 = memoria estimada pela soma dos processos (PS5) */

typedef struct {
  unsigned long long ocupado, total;
} tempos_t;

#ifdef __PROSPERO__
#include <errno.h>

/* Registra no diario so a primeira falha de cada leitura (para nao encher o arquivo a cada 2 s). */
static void falhou_uma_vez(int *ja, const char *nome) {
  if(*ja) return;
  *ja = 1;
  diario("sistema: sysctl %s indisponivel (errno %d)", nome, errno);
}
#endif

/* Le os tempos acumulados de cada nucleo. Devolve a quantidade de nucleos (0 = indisponivel). */
static int ler_tempos(tempos_t t[MAX_NUCLEOS]) {
#ifdef __PROSPERO__
  /* Threads ociosas de cada nucleo, na lista de processos com threads (kinfo_proc). ki_runtime = tempo de CPU (us). */
  static int avisou;
  int mib[3] = {CTL_KERN, KERN_PROC, KERN_PROC_ALL | KERN_PROC_INC_THREAD};
  size_t tam = 0;
  if(sysctl(mib, 3, NULL, &tam, NULL, 0) || !tam) {
    falhou_uma_vez(&avisou, "kern.proc (threads)");
    return 0;
  }
  tam += 256 * 1024;   /* a lista cresce entre as duas chamadas */
  uint8_t *b = malloc(tam);
  if(!b) return 0;
  if(sysctl(mib, 3, b, &tam, NULL, 0)) {
    falhou_uma_vez(&avisou, "kern.proc (threads)");
    free(b);
    return 0;
  }
  unsigned long long ocioso[MAX_NUCLEOS] = {0};
  int achou[MAX_NUCLEOS] = {0}, n = 0;
  char nomes_kernel[600] = "";   /* para o diario, se nao achar as threads ociosas */
  for(uint8_t *p = b; p + sizeof(int) <= b + tam;) {
    struct kinfo_proc *ki = (struct kinfo_proc *)p;
    if(ki->ki_structsize <= 0) break;
    const char *nome = ki->ki_tdname;
    int cpu = -1;
    if(!strncasecmp(nome, "idle: cpu", 9)) cpu = atoi(nome + 9);
    else if(!strncasecmp(nome, "SceIdleCpu", 10)) cpu = atoi(nome + 10);
    if(ki->ki_pid == 0 && strlen(nomes_kernel) + strlen(nome) + 3 < sizeof nomes_kernel && !strstr(nomes_kernel, nome)) {
      strcat(nomes_kernel, nome);
      strcat(nomes_kernel, ", ");
    }
    if(cpu >= 0 && cpu < MAX_NUCLEOS) {
      ocioso[cpu] += ki->ki_runtime;
      achou[cpu] = 1;
      if(cpu + 1 > n) n = cpu + 1;
    }
    p += ki->ki_structsize;
  }
  free(b);
  if(!n) {
    if(!avisou) {
      avisou = 1;
      diario("sistema: nenhuma thread ociosa de CPU na lista de processos; threads do kernel: %s", nomes_kernel);
    }
    return 0;
  }
  static int contou;
  if(!contou) {
    contou = 1;
    diario("sistema: %d nucleo(s) pelas threads ociosas", n);
  }
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  unsigned long long agora = (unsigned long long)ts.tv_sec * 1000000ULL + ts.tv_nsec / 1000;
  for(int i = 0; i < n; i++) {
    t[i].total = agora;
    t[i].ocupado = achou[i] && agora > ocioso[i] ? agora - ocioso[i] : agora;   /* delta: intervalo - tempo ocioso */
  }
  return n;
#else
  FILE *f = fopen("/proc/stat", "r");
  char linha[512];
  int n = 0;
  while(f && fgets(linha, sizeof linha, f) && n < MAX_NUCLEOS) {
    unsigned long long c[8] = {0};
    int id;
    if(strncmp(linha, "cpu", 3) || linha[3] < '0' || linha[3] > '9') continue;   /* "cpu " e o total */
    if(sscanf(linha, "cpu%d %llu %llu %llu %llu %llu %llu %llu", &id, &c[0], &c[1], &c[2], &c[3], &c[4], &c[5], &c[6]) < 5)
      continue;
    unsigned long long total = 0;
    for(int k = 0; k < 7; k++) total += c[k];
    t[n].total = total;
    t[n].ocupado = total - c[3] - c[4];   /* idle + iowait */
    n++;
  }
  if(f) fclose(f);
  return n;
#endif
}

static void ler_memoria(long long *total, long long *livre, long long *ligado) {
  *total = *livre = *ligado = -1;
#ifdef __PROSPERO__
  static int f_mem, f_boot;
  /* sysctl de memoria livre nao existem no PS5: soma a memoria residente (ki_rssize, em paginas) de todos os
     processos - inclui a memoria direta (GPU) dos jogos. Aproximado: paginas compartilhadas contam mais de uma vez. */
  int mib[3] = {CTL_KERN, KERN_PROC, KERN_PROC_PROC};
  size_t tam = 0;
  long long pagina = sysconf(_SC_PAGESIZE);
  if(pagina <= 0) pagina = 16384;
  if(!sysctl(mib, 3, NULL, &tam, NULL, 0) && tam) {
    tam += 64 * 1024;
    uint8_t *b = malloc(tam);
    if(b && !sysctl(mib, 3, b, &tam, NULL, 0)) {
      long long usada = 0;
      for(uint8_t *p = b; p + sizeof(int) <= b + tam;) {
        struct kinfo_proc *ki = (struct kinfo_proc *)p;
        if(ki->ki_structsize <= 0) break;
        if(ki->ki_rssize > 0) usada += (long long)ki->ki_rssize * pagina;
        p += ki->ki_structsize;
      }
      if(usada > RAM_PS5) usada = RAM_PS5;
      *total = RAM_PS5;
      *livre = RAM_PS5 - usada;
      g_ram_aprox = 1;
    } else falhou_uma_vez(&f_mem, "kern.proc (memoria)");
    free(b);
  } else falhou_uma_vez(&f_mem, "kern.proc (memoria)");
  struct timeval boot;
  tam = sizeof boot;
  if(!sysctlbyname("kern.boottime", &boot, &tam, NULL, 0) && boot.tv_sec > 0) *ligado = (long long)(time(NULL) - boot.tv_sec);
  else {
    struct timespec ts;
    if(!clock_gettime(CLOCK_UPTIME, &ts)) *ligado = ts.tv_sec;
    else falhou_uma_vez(&f_boot, "kern.boottime");
  }
#else
  FILE *f = fopen("/proc/meminfo", "r");
  char linha[256];
  long long v;
  while(f && fgets(linha, sizeof linha, f)) {
    if(sscanf(linha, "MemTotal: %lld kB", &v) == 1) *total = v * 1024;
    if(sscanf(linha, "MemAvailable: %lld kB", &v) == 1) *livre = v * 1024;
  }
  if(f) fclose(f);
  f = fopen("/proc/uptime", "r");
  double s;
  if(f && fscanf(f, "%lf", &s) == 1) *ligado = (long long)s;
  if(f) fclose(f);
#endif
}

static void *medir(void *arg) {
  (void)arg;
  tempos_t antes[MAX_NUCLEOS], agora[MAX_NUCLEOS];
  int n0 = ler_tempos(antes);
  for(;;) {
    sleep(INTERVALO_S);
    int n = ler_tempos(agora);
    long long total, livre, ligado;
    ler_memoria(&total, &livre, &ligado);
    pthread_mutex_lock(&g_trava);
    g_ram_total = total;
    g_ram_livre = livre;
    g_ligado_s = ligado;
    if(n && n == n0) {
      unsigned long long ocup = 0, tot = 0;
      for(int i = 0; i < n; i++) {
        unsigned long long dt = agora[i].total - antes[i].total, doc = agora[i].ocupado - antes[i].ocupado;
        g_uso[i] = dt ? 100.0 * doc / dt : 0;
        ocup += doc;
        tot += dt;
      }
      g_nucleos = n;
      g_uso_total = tot ? 100.0 * ocup / tot : 0;
    } else {
      g_nucleos = 0;
      g_uso_total = -1;
    }
    pthread_mutex_unlock(&g_trava);
    memcpy(antes, agora, sizeof antes);
    n0 = n;
  }
  return NULL;
}

void sistema_iniciar(void) {
  criar_thread(medir, NULL, NULL);
}

void sistema_json(buf_t *b) {
  char ip[64] = "";
  meu_ip(ip, sizeof ip);
  pthread_mutex_lock(&g_trava);
  buf_fmt(b, "\"sistema\":{\"cpu\":%.1f,\"nucleos\":[", g_uso_total);
  for(int i = 0; i < g_nucleos; i++) buf_fmt(b, "%s%.1f", i ? "," : "", g_uso[i]);
  buf_fmt(b, "],\"ram_total\":%lld,\"ram_livre\":%lld,\"ram_aprox\":%d,\"ligado_s\":%lld,\"ip\":", g_ram_total, g_ram_livre,
          g_ram_aprox, g_ligado_s);
  buf_json(b, ip);
  buf_str(b, "}");
  pthread_mutex_unlock(&g_trava);
}
