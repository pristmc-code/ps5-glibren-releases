/* Game Library Renamer (payload PS5) - atualizacao pelo proprio PS5.

As versoes ficam no repositorio publico pristmc-code/ps5-glibren-releases (so os .elf, o codigo e privado):
  versao.json        {"versao": "0.7-teste", "notas": "..."}
  glibren.elf        o payload
  glibren.elf.sig    assinatura Ed25519 (64 bytes) do glibren.elf, feita no PC de quem publica
Atualizar: baixa o .elf e a assinatura, confere com a chave publica embutida (um arquivo adulterado ou de outra
pessoa e recusado - importante porque a conexao pode estar sem verificar o certificado), grava em
/data/GameLibraryRenamer/glibren.elf e envia para o elfldr do proprio PS5 (127.0.0.1:9021). A copia nova encerra
esta (mesmo nome de processo).
*/
#include "atualizacao.h"

#include <arpa/inet.h>
#include <ctype.h>
#include <netinet/in.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

#include "api.h"
#include "assinatura.h"
#include "config.h"
#include "https.h"
#include "plataforma.h"

#define BASE "https://raw.githubusercontent.com/pristmc-code/ps5-glibren-releases/main/"
#define MAX_ELF (16 * 1024 * 1024)
#define VALIDADE_S (15 * 60)
#define PORTA_ELFLDR 9021

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static char g_nova[32], g_notas[600], g_fase[16], g_erro[200];
static time_t g_verificado;
static int g_rodando;

/* "0.7-teste" -> 0007000; compara so os numeros */
static long numero_versao(const char *v) {
  long partes[3] = {0, 0, 0};
  for(int i = 0; i < 3 && *v; i++) {
    partes[i] = strtol(v, (char **)&v, 10);
    if(*v != '.') break;
    v++;
  }
  return partes[0] * 1000000 + partes[1] * 1000 + partes[2];
}

/* Texto de "chave" num JSON simples (sem escapes alem de \" e \n). */
static void campo_json(const char *json, const char *chave, char *saida, size_t tam) {
  char k[48];
  snprintf(k, sizeof k, "\"%s\"", chave);
  saida[0] = 0;
  const char *p = strstr(json, k);
  if(!p) return;
  p = strchr(p + strlen(k), ':');
  if(!p) return;
  while(*++p == ' ') {}
  if(*p != '"') return;
  size_t n = 0;
  for(p++; *p && *p != '"' && n + 1 < tam; p++) {
    if(*p == '\\' && p[1]) {
      p++;
      saida[n++] = *p == 'n' ? '\n' : *p;
    } else {
      saida[n++] = *p;
    }
  }
  saida[n] = 0;
}

static void verificar(int forcar) {
  pthread_mutex_lock(&g_trava);
  int recente = !forcar && g_verificado && time(NULL) - g_verificado < VALIDADE_S;
  pthread_mutex_unlock(&g_trava);
  if(recente) return;
  buf_t b = {0};
  if(https_get(BASE "versao.json", &b, 64 * 1024, 15) == 200) {
    buf_add(&b, "", 1);
    char versao[32], notas[600];
    campo_json(b.d, "versao", versao, sizeof versao);
    campo_json(b.d, "notas", notas, sizeof notas);
    pthread_mutex_lock(&g_trava);
    if(versao[0] && numero_versao(versao) > numero_versao(VERSAO)) {
      snprintf(g_nova, sizeof g_nova, "%s", versao);
      snprintf(g_notas, sizeof g_notas, "%s", notas);
    } else {
      g_nova[0] = g_notas[0] = 0;
    }
    g_verificado = time(NULL);
    pthread_mutex_unlock(&g_trava);
  }
  buf_free(&b);
}

void atualizacao_estado(buf_t *json, int forcar) {
  verificar(forcar);
  pthread_mutex_lock(&g_trava);
  buf_str(json, "{\"ok\":true,\"atual\":");
  buf_json(json, VERSAO);
  buf_str(json, ",\"nova\":");
  buf_json(json, g_nova);
  buf_str(json, ",\"notas\":");
  buf_json(json, g_notas);
  buf_str(json, ",\"fase\":");
  buf_json(json, g_fase);
  buf_str(json, ",\"erro\":");
  buf_json(json, g_erro);
  buf_fmt(json, ",\"rodando\":%s}", g_rodando ? "true" : "false");
  pthread_mutex_unlock(&g_trava);
}

static void fase(const char *f, const char *erro) {
  pthread_mutex_lock(&g_trava);
  snprintf(g_fase, sizeof g_fase, "%s", f);
  snprintf(g_erro, sizeof g_erro, "%s", erro ? erro : "");
  if(erro) g_rodando = 0;
  pthread_mutex_unlock(&g_trava);
  if(erro) diario("atualizacao: %s", erro);
}

/* Entrega o .elf ao elfldr do proprio PS5, que o executa (a copia nova encerra esta). */
static int enviar_elfldr(const void *dados, size_t n) {
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if(fd < 0) return -1;
  struct sockaddr_in end = {.sin_family = AF_INET, .sin_port = htons(PORTA_ELFLDR)};
  end.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  int ok = !connect(fd, (struct sockaddr *)&end, sizeof end);
  for(size_t enviados = 0; ok && enviados < n;) {
    ssize_t r = send(fd, (const char *)dados + enviados, n - enviados, 0);
    if(r <= 0) ok = 0;
    else enviados += r;
  }
  close(fd);
  return ok ? 0 : -1;
}

static void *atualizar(void *arg) {
  (void)arg;
  buf_t elf = {0}, sig = {0};
  char destino[600], parcial[640];
  fase("baixando", NULL);
  if(https_get(BASE "glibren.elf", &elf, MAX_ELF, 60) != 200 || elf.n < 1024) {
    fase("", "nao foi possivel baixar a versao nova");
    goto fim;
  }
  if(https_get(BASE "glibren.elf.sig", &sig, 1024, 15) != 200 || sig.n != 64) {
    fase("", "nao foi possivel baixar a assinatura da versao nova");
    goto fim;
  }
  fase("verificando", NULL);
  if(!assinatura_valida(elf.d, elf.n, (const unsigned char *)sig.d)) {
    fase("", "assinatura invalida: atualizacao recusada (arquivo adulterado ou de outra origem)");
    goto fim;
  }
  fase("instalando", NULL);
  snprintf(destino, sizeof destino, "%s/glibren.elf", g_pasta_dados);
  snprintf(parcial, sizeof parcial, "%s.part", destino);
  FILE *f = fopen(parcial, "wb");
  int gravou = f && fwrite(elf.d, 1, elf.n, f) == elf.n;
  if(f && fclose(f)) gravou = 0;
  if(!gravou || rename(parcial, destino)) {
    unlink(parcial);
    fase("", "nao foi possivel gravar a versao nova no PS5");
    goto fim;
  }
  diario("atualizacao: versao nova verificada e gravada em %s", destino);
  fase("reiniciando", NULL);
#ifdef __PROSPERO__
  if(enviar_elfldr(elf.d, elf.n)) {
    fase("", "versao nova gravada, mas o elfldr (porta 9021) nao respondeu: envie glibren.elf de novo");
    goto fim;
  }
  diario("atualizacao: enviada ao elfldr; a versao nova assume");
#else
  (void)enviar_elfldr;
  diario("atualizacao (PC): nao envia ao elfldr");
#endif
fim:
  buf_free(&elf);
  buf_free(&sig);
  return NULL;
}

int atualizacao_iniciar(char *msg, size_t tam) {
  pthread_mutex_lock(&g_trava);
  if(g_rodando) {
    pthread_mutex_unlock(&g_trava);
    snprintf(msg, tam, "a atualizacao ja esta em andamento");
    return -1;
  }
  if(!g_nova[0]) {
    pthread_mutex_unlock(&g_trava);
    snprintf(msg, tam, "nenhuma versao nova");
    return -1;
  }
  g_rodando = 1;
  g_erro[0] = 0;
  pthread_mutex_unlock(&g_trava);
  if(criar_thread(atualizar, NULL, NULL)) {
    fase("", "nao iniciou a atualizacao");
    snprintf(msg, tam, "nao iniciou a atualizacao");
    return -1;
  }
  return 0;
}
