/* Game Library Renamer (payload PS5) - downloads HTTPS (sceHttp no PS5, curl no PC). */
#include "https.h"

#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>

#define USER_AGENT "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Safari/537.36"

static const char *HOSTS[] = {
  "raw.githubusercontent.com",                    /* base de titulos (andshrew/PlayStation-Titles) */
  "prosperopatches.com", "cdn.prosperopatches.com", /* PS5: nome do publisher e icone */
  "orbispatches.com", "cdn.orbispatches.com",       /* PS4 */
  "speed.cloudflare.com",                           /* teste de velocidade da internet */
  "www.speedtest.net",                              /* lista de servidores de teste perto do PS5 */
  NULL};

/* Servidores de teste de internet vindos da lista do speedtest.net (mudam conforme a regiao do PS5). */
#define MAX_EXTRAS 16
static char g_extras[MAX_EXTRAS][128];
static int g_n_extras;
static pthread_mutex_t g_trava_hosts = PTHREAD_MUTEX_INITIALIZER;

void https_permitir_host(const char *host) {
  size_t n = strcspn(host, ":");
  if(!n || n >= sizeof g_extras[0]) return;
  pthread_mutex_lock(&g_trava_hosts);
  int ja = 0;
  for(int i = 0; i < g_n_extras && !ja; i++) ja = strlen(g_extras[i]) == n && !strncasecmp(g_extras[i], host, n);
  if(!ja) {
    if(g_n_extras == MAX_EXTRAS) {   /* cheia: descarta o mais antigo */
      memmove(g_extras[0], g_extras[1], sizeof g_extras[0] * (MAX_EXTRAS - 1));
      g_n_extras--;
    }
    memcpy(g_extras[g_n_extras], host, n);
    g_extras[g_n_extras++][n] = 0;
  }
  pthread_mutex_unlock(&g_trava_hosts);
}

int url_permitida(const char *url) {
  if(strncmp(url, "https://", 8)) return 0;
  /* so caracteres comuns de URL (tambem evita qualquer problema ao passar para o curl no PC) */
  for(const char *p = url; *p; p++) {
    if(!strchr("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~:/?#[]@!$&()*+,;=%", *p)) return 0;
    if(*p == '\'' || *p == '$' || *p == '(' || *p == ')' || *p == ';') return 0;
  }
  const char *host = url + 8;
  size_t n = strcspn(host, "/:?#");
  for(int i = 0; HOSTS[i]; i++) {
    if(strlen(HOSTS[i]) == n && !strncasecmp(host, HOSTS[i], n)) return 1;
  }
  int ok = 0;
  pthread_mutex_lock(&g_trava_hosts);
  for(int i = 0; i < g_n_extras && !ok; i++) ok = strlen(g_extras[i]) == n && !strncasecmp(host, g_extras[i], n);
  pthread_mutex_unlock(&g_trava_hosts);
  return ok;
}

#ifdef __PROSPERO__
/* PS5: biblioteca sceHttp do proprio console, do jeito que o ProsperoMgr usa (a 0.1 usava a sceHttp2 e nao
   conseguiu acessar a internet no PS5 real):
   - um contexto novo (pool de rede, SSL, HTTP, modelo) para cada pedido, fechado no fim;
   - SNI ligado (opcao 0x80 do sceHttps), como no JobeesLair: sem ele o GitHub e a Cloudflare recusam a negociacao
     segura (era o 0x8095f00c da 0.3/0.4). O certificado e verificado pelo PS5;
   - se mesmo assim a parte segura falhar (erro 0x8095fxxx), passa a aceitar o certificado sem verificar, como o
     ProsperoMgr - autorizado pelo usuario em 03/11/2026 (sites publicos; nada de senha ou dado pessoal enviado);
     a conexao continua criptografada e o diario registra quando isso acontece;
   - o nome do site e resolvido aqui: DNS do proprio PS5 e, se falhar, DNS publico (8.8.8.8 / 1.1.1.1); conecta
     pelo IP com o cabecalho Host e, se o site recusar (alguns exigem o nome na conexao), tenta pelo nome;
   - tempo limite de 20 s em cada etapa e redirecionamentos seguidos aqui (ate 5). */
#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/time.h>

#include "plataforma.h"

int sceNetInit(void);
int sceNetPoolCreate(const char *, int, int);
int sceNetPoolDestroy(int);
int sceNetCtlInit(void);
int sceSslInit(size_t);
int sceSslTerm(int);
int sceHttpInit(int, int, size_t);
int sceHttpTerm(int);
int sceHttpCreateTemplate(int, const char *, int, int);
int sceHttpDeleteTemplate(int);
int sceHttpSetAutoRedirect(int, int);
int sceHttpSetResponseHeaderMaxSize(int, size_t);
int sceHttpsSetSslCallback(int, void *, void *);
int sceHttpsEnableOption(int, unsigned int);
int sceHttpSetResolveTimeOut(int, unsigned int);
int sceHttpSetConnectTimeOut(int, unsigned int);
int sceHttpSetSendTimeOut(int, unsigned int);
int sceHttpSetRecvTimeOut(int, unsigned int);
int sceHttpCreateConnectionWithURL(int, const char *, int);
int sceHttpDeleteConnection(int);
int sceHttpCreateRequestWithURL(int, int, const char *, uint64_t);
int sceHttpDeleteRequest(int);
int sceHttpAddRequestHeader(int, const char *, const char *, unsigned int);
int sceHttpSendRequest(int, const void *, size_t);
int sceHttpGetStatusCode(int, int *);
int sceHttpGetAllResponseHeaders(int, char **, size_t *);
int sceHttpReadData(int, void *, size_t);

#define METODO_GET 0
#define METODO_POST 1
#define ESPERA_US (20u * 1000u * 1000u)
#define MAX_REDIRECIONAR 5

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;   /* downloads comuns: um por vez */
static pthread_mutex_t g_trava_dns = PTHREAD_MUTEX_INITIALIZER;

#define HTTPS_SNI 0x80
#define ERRO_SSL(r) (((unsigned)(r) & 0xfffff000u) == 0x8095f000u)
static volatile int g_sem_verificar;   /* 1 depois que a verificacao do certificado falhou (ver o inicio) */

/* Chamada pelo PS5 na verificacao do certificado: 0 = aceitar (so no modo sem verificar, ver o inicio). */
static int aceitar_certificado(void) {
  return 0;
}

void https_iniciar(void) {
  int r1 = sceNetInit(), r2 = sceNetCtlInit();
  diario("rede: sceNetInit 0x%08x, sceNetCtlInit 0x%08x", (unsigned)r1, (unsigned)r2);
}

/* ---- DNS ---- */

#define MAX_DNS 24
static struct {
  char host[128], ip[48];
  int modo;   /* 0 = ainda nao sabe; 1 = pelo IP funcionou; 2 = so pelo nome */
} g_dns[MAX_DNS];
static int g_n_dns;

static int dns_sistema(const char *host, char *ip, size_t tam) {
  struct addrinfo dica = {.ai_family = AF_INET, .ai_socktype = SOCK_STREAM}, *res = NULL;
  if(getaddrinfo(host, NULL, &dica, &res) || !res) return -1;
  const char *ok = inet_ntop(AF_INET, &((struct sockaddr_in *)res->ai_addr)->sin_addr, ip, tam);
  freeaddrinfo(res);
  return ok ? 0 : -1;
}

/* Pergunta direto a um DNS publico por UDP (registro A). */
static int dns_publico(const char *host, char *ip, size_t tam) {
  static const char *servidores[] = {"8.8.8.8", "1.1.1.1"};
  uint8_t q[512], r[1500];
  uint16_t id = (uint16_t)arc4random();
  size_t n = 0;
  q[n++] = id >> 8;
  q[n++] = id & 0xff;
  q[n++] = 0x01;   /* recursao desejada */
  q[n++] = 0x00;
  q[n++] = 0x00;
  q[n++] = 0x01;   /* 1 pergunta */
  memset(q + n, 0, 6);
  n += 6;
  for(const char *p = host; *p;) {
    size_t rot = strcspn(p, ".");
    if(!rot || rot > 63 || n + rot + 6 > sizeof q) return -1;
    q[n++] = (uint8_t)rot;
    memcpy(q + n, p, rot);
    n += rot;
    p += rot;
    if(*p == '.') p++;
  }
  q[n++] = 0;
  q[n++] = 0;
  q[n++] = 1;   /* tipo A */
  q[n++] = 0;
  q[n++] = 1;   /* classe IN */
  for(size_t s = 0; s < sizeof servidores / sizeof *servidores; s++) {
    int fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if(fd < 0) continue;
    struct timeval espera = {.tv_sec = 4};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &espera, sizeof espera);
    struct sockaddr_in end = {.sin_family = AF_INET, .sin_port = htons(53)};
    inet_pton(AF_INET, servidores[s], &end.sin_addr);
    ssize_t lidos = -1;
    if(!connect(fd, (struct sockaddr *)&end, sizeof end) && send(fd, q, n, 0) == (ssize_t)n) lidos = recv(fd, r, sizeof r, 0);
    close(fd);
    if(lidos < 12 || ((r[0] << 8) | r[1]) != id || !(r[2] & 0x80)) continue;
    int respostas = (r[6] << 8) | r[7];
    size_t pos = 12;
    /* pula a pergunta */
    while(pos < (size_t)lidos && r[pos]) pos += (r[pos] & 0xc0) == 0xc0 ? 1 : r[pos] + 1;
    pos += 5;
    for(int a = 0; a < respostas && pos + 12 <= (size_t)lidos; a++) {
      if((r[pos] & 0xc0) == 0xc0) pos += 2;
      else {
        while(pos < (size_t)lidos && r[pos]) pos += r[pos] + 1;
        pos++;
      }
      if(pos + 10 > (size_t)lidos) break;
      int tipo = (r[pos] << 8) | r[pos + 1], comp = (r[pos + 8] << 8) | r[pos + 9];
      pos += 10;
      if(tipo == 1 && comp == 4 && pos + 4 <= (size_t)lidos) {
        snprintf(ip, tam, "%u.%u.%u.%u", r[pos], r[pos + 1], r[pos + 2], r[pos + 3]);
        return 0;
      }
      pos += comp;
    }
  }
  return -1;
}

/* Indice do host no cache (resolve na primeira vez), ou -1. */
static int resolver(const char *host) {
  int i;
  pthread_mutex_lock(&g_trava_dns);
  for(i = 0; i < g_n_dns; i++)
    if(!strcmp(g_dns[i].host, host)) break;
  if(i == g_n_dns) {
    char ip[48] = "";
    pthread_mutex_unlock(&g_trava_dns);
    int ok = !dns_sistema(host, ip, sizeof ip) || !dns_publico(host, ip, sizeof ip);
    pthread_mutex_lock(&g_trava_dns);
    if(!ok) {
      diario("DNS: nao resolveu %s", host);
      i = -1;
    } else {
      i = g_n_dns < MAX_DNS ? g_n_dns++ : MAX_DNS - 1;
      snprintf(g_dns[i].host, sizeof g_dns[i].host, "%s", host);
      snprintf(g_dns[i].ip, sizeof g_dns[i].ip, "%s", ip);
      g_dns[i].modo = 0;
    }
  }
  pthread_mutex_unlock(&g_trava_dns);
  return i;
}

/* ---- pedidos ---- */

typedef struct {
  int pool, ssl, http, modelo, con, req, sem_verificar;
} contexto_t;

static void tempo_limite(int id) {
  sceHttpSetResolveTimeOut(id, ESPERA_US);
  sceHttpSetConnectTimeOut(id, ESPERA_US);
  sceHttpSetSendTimeOut(id, ESPERA_US);
  sceHttpSetRecvTimeOut(id, ESPERA_US);
}

static void fechar_pedido(contexto_t *c) {
  if(c->req >= 0) sceHttpDeleteRequest(c->req);
  if(c->con >= 0) sceHttpDeleteConnection(c->con);
  c->req = c->con = -1;
}

static void fechar(contexto_t *c) {
  fechar_pedido(c);
  if(c->modelo >= 0) sceHttpDeleteTemplate(c->modelo);
  if(c->http >= 0) sceHttpTerm(c->http);
  if(c->ssl >= 0) sceSslTerm(c->ssl);
  if(c->pool >= 0) sceNetPoolDestroy(c->pool);
}

static int abrir_contexto(contexto_t *c, int sem_verificar) {
  memset(c, 0xff, sizeof *c);   /* tudo -1 */
  c->sem_verificar = sem_verificar;
  if((c->pool = sceNetPoolCreate("glibren", 512 * 1024, 0)) < 0 || (c->ssl = sceSslInit(384 * 1024)) < 0 ||
     (c->http = sceHttpInit(c->pool, c->ssl, 256 * 1024)) < 0 ||
     (c->modelo = sceHttpCreateTemplate(c->http, USER_AGENT, 2, 1)) < 0) {
    diario("https: contexto falhou (pool %d ssl %d http %d modelo %d)", c->pool, c->ssl, c->http, c->modelo);
    return -1;
  }
  sceHttpSetResponseHeaderMaxSize(c->modelo, 0x4000);
  sceHttpSetAutoRedirect(c->modelo, 0);   /* redirecionamento seguido aqui, com o nosso DNS */
  sceHttpsEnableOption(c->modelo, HTTPS_SNI);   /* nome do site na negociacao segura */
  if(sem_verificar) sceHttpsSetSslCallback(c->modelo, (void *)aceitar_certificado, NULL);
  tempo_limite(c->modelo);
  return 0;
}

/* Um pedido (sem seguir redirecionamento). por_ip: conecta no IP resolvido aqui, com o cabecalho Host.
   Devolve 0 ou o codigo de erro do PS5. */
static int enviar(contexto_t *c, const char *url, int metodo, const void *corpo, size_t tam, int por_ip, int *status) {
  char host[128], url_ip[2048];
  const char *ini = strstr(url, "://");
  if(!ini) return -1;
  ini += 3;
  size_t n = strcspn(ini, "/:?#");
  if(!n || n >= sizeof host) return -1;
  memcpy(host, ini, n);
  host[n] = 0;
  const char *alvo = url;
  if(por_ip) {
    int i = resolver(host);
    if(i < 0) return -1;
    snprintf(url_ip, sizeof url_ip, "%.*s%s%s", (int)(ini - url), url, g_dns[i].ip, ini + n);
    alvo = url_ip;
  }
  int r;
  if((c->con = sceHttpCreateConnectionWithURL(c->modelo, alvo, 0)) < 0) {
    r = c->con;
    goto erro;
  }
  tempo_limite(c->con);
  if((c->req = sceHttpCreateRequestWithURL(c->con, metodo, alvo, corpo ? tam : 0)) < 0) {
    r = c->req;
    goto erro;
  }
  tempo_limite(c->req);
  if(por_ip) sceHttpAddRequestHeader(c->req, "Host", host, 0);
  if(corpo) sceHttpAddRequestHeader(c->req, "Content-Type", "application/octet-stream", 0);
  if((r = sceHttpSendRequest(c->req, corpo, corpo ? tam : 0)) || (r = sceHttpGetStatusCode(c->req, status))) goto erro;
  return 0;
erro:
  diario("https: %s %s (%s%s) falhou 0x%08x", metodo == METODO_POST ? "POST" : "GET", host, por_ip ? "pelo IP" : "pelo nome",
         c->sem_verificar ? ", sem verificar certificado" : "", (unsigned)r);
  fechar_pedido(c);
  return r ? r : -1;
}

static int ler_location(int req, const char *base, char *saida, size_t tam) {
  char *cabs = NULL;
  size_t n = 0;
  if(sceHttpGetAllResponseHeaders(req, &cabs, &n) || !cabs) return -1;
  for(const char *l = cabs, *fim = cabs + n; l < fim;) {
    const char *eol = memchr(l, '\n', fim - l);
    size_t t = eol ? (size_t)(eol - l) : (size_t)(fim - l);
    while(t && (l[t - 1] == '\r' || l[t - 1] == ' ')) t--;
    if(t > 9 && !strncasecmp(l, "location:", 9)) {
      const char *v = l + 9;
      size_t vt = t - 9;
      while(vt && *v == ' ') v++, vt--;
      if(!vt) return -1;
      if(*v == '/') {   /* relativo: mesmo site */
        const char *h = strstr(base, "://");
        if(!h) return -1;
        h += 3;
        size_t pre = (h - base) + strcspn(h, "/");
        snprintf(saida, tam, "%.*s%.*s", (int)pre, base, (int)vt, v);
      } else {
        snprintf(saida, tam, "%.*s", (int)vt, v);
      }
      return 0;
    }
    if(!eol) break;
    l = eol + 1;
  }
  return -1;
}

/* Abre a URL seguindo redirecionamentos (so para sites permitidos). Devolve o status HTTP, -1 (falhou) ou
   -2 (falhou na parte segura: certificado/negociacao). */
static int abrir_url(contexto_t *c, const char *url, int metodo, const void *corpo, size_t tam) {
  char atual[2048];
  snprintf(atual, sizeof atual, "%s", url);
  for(int salto = 0;; salto++) {
    if(!url_permitida(atual)) return -1;
    char host[128];
    const char *ini = strstr(atual, "://") + 3;
    size_t n = strcspn(ini, "/:?#");
    snprintf(host, sizeof host, "%.*s", (int)(n < sizeof host ? n : sizeof host - 1), ini);
    int status = 0;
    /* pelo nome primeiro (com SNI o certificado confere com o site); pelo IP com o nosso DNS so se o nome falhar
       por outro motivo (DNS do PS5) - pelo IP o certificado nunca confere, entao so vale sem verificar. */
    int r = enviar(c, atual, metodo, corpo, tam, 0, &status);
    if(r && (!ERRO_SSL(r) || c->sem_verificar) && resolver(host) >= 0) r = enviar(c, atual, metodo, corpo, tam, 1, &status);
    if(r) return ERRO_SSL(r) ? -2 : -1;
    if(status >= 400) diario("https: %s respondeu %d", host, status);   /* ex.: 403 = o site bloqueou */
    if(status >= 300 && status < 400 && salto < MAX_REDIRECIONAR) {
      char prox[2048];
      if(!ler_location(c->req, atual, prox, sizeof prox)) {
        snprintf(atual, sizeof atual, "%s", prox);
        fechar_pedido(c);
        continue;
      }
    }
    return status;
  }
}

/* Contexto + pedido. Se a parte segura falhar com a verificacao do certificado ligada, passa (uma vez por todas)
   ao modo sem verificar e tenta de novo. O contexto fica aberto (fechar() depois). */
static int pedir(contexto_t *c, const char *url, int metodo, const void *corpo, size_t tam) {
  if(abrir_contexto(c, g_sem_verificar)) return -1;
  int status = abrir_url(c, url, metodo, corpo, tam);
  if(status == -2 && !c->sem_verificar) {
    if(!g_sem_verificar) diario("https: certificado nao verificado pelo PS5 - passando a aceitar sem verificar (autorizado)");
    g_sem_verificar = 1;
    fechar(c);
    if(abrir_contexto(c, 1)) return -1;
    status = abrir_url(c, url, metodo, corpo, tam);
  }
  return status;
}

int https_get(const char *url, buf_t *saida, size_t max, int segundos) {
  (void)segundos;   /* tempo limite fixo de 20 s por etapa */
  if(!url_permitida(url)) return -1;
  pthread_mutex_lock(&g_trava);
  contexto_t c;
  int status = pedir(&c, url, METODO_GET, NULL, 0);
  if(status > 0) {
    char bloco[16 * 1024];
    int n;
    while((n = sceHttpReadData(c.req, bloco, sizeof bloco)) > 0) {
      if(saida->n + n > max) {
        status = -1;
        break;
      }
      buf_add(saida, bloco, n);
    }
    if(n < 0) {
      diario("https: leitura falhou 0x%08x (%s)", (unsigned)n, url);
      status = -1;
    }
  }
  fechar(&c);
  pthread_mutex_unlock(&g_trava);
  return status;
}

int https_fluxo(const char *url, const void *corpo, size_t tam_corpo, https_recebeu_t recebeu, void *ctx) {
  if(!url_permitida(url)) return -1;
  /* sem a trava geral: o teste de internet usa varias conexoes ao mesmo tempo, cada uma com o seu contexto */
  contexto_t c;
  int status = pedir(&c, url, corpo ? METODO_POST : METODO_GET, corpo, tam_corpo);
  if(status > 0) {
    if(corpo) recebeu(tam_corpo, ctx);
    else {
      static __thread char bloco[64 * 1024];
      int n;
      while((n = sceHttpReadData(c.req, bloco, sizeof bloco)) > 0) {
        if(recebeu(n, ctx)) break;
      }
    }
  }
  fechar(&c);
  return status;
}

#else /* PC (teste no Linux/WSL): usa o curl */

void https_iniciar(void) {}

int https_get(const char *url, buf_t *saida, size_t max, int segundos) {
  if(!url_permitida(url)) return -1;
  char tmp[] = "/tmp/glr-XXXXXX";
  int fd = mkstemp(tmp);
  if(fd < 0) return -1;
  close(fd);
  char cmd[3000];
  snprintf(cmd, sizeof cmd, "curl -s -L --max-time %d -A '%s' -o '%s' -w '%%{http_code}' '%s'", segundos, USER_AGENT, tmp, url);
  int status = -1;
  FILE *p = popen(cmd, "r");
  if(p) {
    if(fscanf(p, "%d", &status) != 1 || status == 0) status = -1;
    pclose(p);
  }
  FILE *f = fopen(tmp, "rb");
  if(f && status > 0) {
    char bloco[16 * 1024];
    size_t n;
    while((n = fread(bloco, 1, sizeof bloco, f)) > 0) {
      if(saida->n + n > max) {
        status = -1;
        break;
      }
      buf_add(saida, bloco, n);
    }
  }
  if(f) fclose(f);
  unlink(tmp);
  return status;
}

int https_fluxo(const char *url, const void *corpo, size_t tam_corpo, https_recebeu_t recebeu, void *ctx) {
  if(!url_permitida(url)) return -1;
  char cmd[1200], tmp[] = "/tmp/glr-up-XXXXXX";
  if(corpo) {
    int fd = mkstemp(tmp);
    if(fd < 0) return -1;
    if(write(fd, corpo, tam_corpo) != (ssize_t)tam_corpo) {
      close(fd);
      unlink(tmp);
      return -1;
    }
    close(fd);
    snprintf(cmd, sizeof cmd, "curl -s -o /dev/null --max-time 30 -w '%%{http_code}' -X POST --data-binary @'%s' '%s'", tmp, url);
  } else {
    snprintf(cmd, sizeof cmd, "curl -s --max-time 30 '%s'", url);
  }
  int status = -1;
  FILE *p = popen(cmd, "r");
  if(p) {
    if(corpo) {
      if(fscanf(p, "%d", &status) == 1 && status > 0) recebeu(tam_corpo, ctx);
    } else {
      char bloco[64 * 1024];
      size_t n;
      status = 200;
      while((n = fread(bloco, 1, sizeof bloco, p)) > 0) {
        if(recebeu(n, ctx)) break;
      }
    }
    pclose(p);
  }
  if(corpo) unlink(tmp);
  return status;
}

#endif
