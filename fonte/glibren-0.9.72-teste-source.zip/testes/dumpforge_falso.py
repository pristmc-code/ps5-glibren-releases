# Dump Forge falso (0.9.30) para os testes da conversao: imita a API local do ps5-dump-forge v0.5.6 (um pedido por
# conexao, Content-Length, {"error": "..."} nas recusas):
#   GET /api/session; POST /api/start_job {"request": ...} -> id; GET /api/jobs; POST /api/cancel_job {"id": N}.
# Modo (arquivo <pasta>/modo, lido a cada start_job): ok (termina bem), erro (termina com Err), lento (nunca termina,
# serve para cancelar), recusa (start_job responde 400). Cada GET /api/jobs anda um passo em cada trabalho:
# progresso 0/1000 -> 500/1000 -> Done. Os pedidos recebidos vao para <pasta>/pedidos.jsonl. 0.9.36: <pasta>/cria faz o
# "ok" criar a saida (ver criar_saida).
# 0.9.41: pedido de instalacao ({"request": {..., "install": "<pkg>"}}), modo em <pasta>/modo_inst: ok (todo byte servido),
# codigo (Err "the PS5 refused the package: 0x80A30002 (not enough free space)"), desconhecido (Err com 0x80B2FFFF),
# lento (nunca termina), recusa (start_job 400). Instalacao que comeca com outra ainda andando = linha em
# <pasta>/sobreposto (o glibren manda uma por vez).
#   python3 -I dumpforge_falso.py <porta> <pasta>
import json, os, socket, sys, threading

porta, pasta = int(sys.argv[1]), sys.argv[2]
jobs, trava, prox = {}, threading.Lock(), [1]


def modo():
    try:
        return open(pasta + "/modo").read().strip()
    except OSError:
        return "ok"


def responder(c, status, corpo):
    dados = json.dumps(corpo).encode()
    c.sendall(b"HTTP/1.1 %d X\r\nContent-Type: application/json\r\nContent-Length: %d\r\nConnection: close\r\n\r\n" % (status, len(dados)) + dados)


def criar_saida(req):
    """0.9.36: com <pasta>/cria, a conversao "ok" cria a saida de verdade (o glibren confere antes de mover o original):
    "vazio" = arquivo de 0 bytes; pasta (format folder) = eboot.bin + sce_sys/param.json com o titulo de <pasta>/titulo."""
    try:
        cria = open(pasta + "/cria").read().strip()
    except OSError:
        return
    saida = req["output"]
    if req.get("format") == "folder":
        try:
            titulo = open(pasta + "/titulo", encoding="utf-8").read().strip()
        except OSError:
            titulo = "Jogo Pasta"
        os.makedirs(saida + "/sce_sys", exist_ok=True)
        open(saida + "/eboot.bin", "w").write("elf")
        param = {"titleId": "PPSA02222", "localizedParameters": {"defaultLanguage": "en-US", "en-US": {"titleName": titulo}}}
        open(saida + "/sce_sys/param.json", "w", encoding="utf-8").write(json.dumps(param))
    elif cria == "pkg5":   # 0.9.70: .pkg com o cabecalho de PS5 (a Fila PKG confere)
        open(saida, "wb").write(b"\x7fFIH" + b"x" * 60)
    else:
        open(saida, "w").write("" if cria == "vazio" else "convertido")


def modo_inst():
    try:
        return open(pasta + "/modo_inst").read().strip()
    except OSError:
        return "ok"


def snap_inst(i, j):
    passo, total = j["passo"], j["total"]
    if j["fim"]:
        return
    if j["cancelar"]:
        j["fim"] = {"kind": "done", "job": i, "result": {"Err": "cancelled; if the PS5 still lists the download, delete it there"}}
    elif passo == 0:
        j["prog"] = {"kind": "progress", "job": i, "stage": "preflight", "done": 1, "total": 1}
    elif j["modo"] == "codigo":
        j["fim"] = {"kind": "done", "job": i, "result": {"Err": "the PS5 refused the package: 0x80A30002 (not enough free space)"}}
    elif j["modo"] == "desconhecido":
        j["fim"] = {"kind": "done", "job": i, "result": {"Err": "the PS5 refused the package: 0x80B2FFFF"}}
    elif passo == 1:
        j["prog"] = {"kind": "progress", "job": i, "stage": "install", "done": total // 2, "total": total}
    elif j["modo"] == "ok":
        j["fim"] = {"kind": "done", "job": i, "result": {"Ok": {"output": j["req"]["install"], "bytes": total, "files": 1,
                                                              "checks": ["install: the PS5 fetched all %d bytes" % total],
                                                              "verify": {"mode": "fast"}}}}
    j["passo"] += 1


def snapshot():
    lista = []
    for i, j in sorted(jobs.items()):
        passo = j["passo"]
        if j["req"].get("install"):
            snap_inst(i, j)
        elif not j["fim"]:
            if passo == 0 and not j["cancelar"]:
                j["prog"] = {"kind": "progress", "job": i, "stage": "write", "done": 0, "total": 1000}
            elif passo == 1 and not j["cancelar"]:
                j["prog"] = {"kind": "progress", "job": i, "stage": "verify", "done": 500, "total": 1000}
            elif j["cancelar"]:
                j["fim"] = {"kind": "done", "job": i, "result": {"Err": "cancelled"}}
            elif j["modo"] == "erro":
                j["fim"] = {"kind": "done", "job": i, "result": {"Err": "preflight: no param.json in the source"}}
            elif j["modo"] == "ok":
                criar_saida(j["req"])
                j["fim"] = {"kind": "done", "job": i, "result": {"Ok": {"output": j["req"]["output"], "bytes": 123456789, "files": 3,
                                                                      "checks": ["ok"], "verify": {"mode": "fast"}}}}
            j["passo"] += 1
        lista.append({"id": i, "request": j["req"], "stages": ["write", "verify"], "progress": j["prog"], "done": j["fim"],
                      "log": ["linha \"com aspas\" e \\ barra"] * 3, "log_total": 3})
    return {"instance": "falso", "jobs": lista}


def atender(c):
    try:
        dados = b""
        while b"\r\n\r\n" not in dados:
            d = c.recv(65536)
            if not d:
                return
            dados += d
        cab, corpo = dados.split(b"\r\n\r\n", 1)
        linhas = cab.decode().split("\r\n")
        metodo, rota = linhas[0].split(" ")[:2]
        n = 0
        for l in linhas[1:]:
            if l.lower().startswith("content-length:"):
                n = int(l.split(":")[1])
        while len(corpo) < n:
            corpo += c.recv(65536)
        with trava:
            if metodo == "GET" and rota == "/api/session":
                responder(c, 200, {"app": "ps5-dump-forge", "version": "0.5.6"})
            elif metodo == "GET" and rota == "/api/jobs":
                responder(c, 200, snapshot())
            elif metodo == "POST" and rota == "/api/start_job":
                pedido = json.loads(corpo)
                open(pasta + "/pedidos.jsonl", "a").write(json.dumps(pedido) + "\n")
                inst = pedido["request"].get("install")
                m = modo_inst() if inst else modo()
                if inst and any(x["req"].get("install") and not x["fim"] for x in jobs.values()):
                    open(pasta + "/sobreposto", "a").write(inst + "\n")
                if m == "recusa":
                    responder(c, 400, {"error": (inst or pedido["request"]["source"]) + ": not a folder or a regular file"})
                else:
                    i = prox[0]
                    prox[0] += 1
                    total = os.path.getsize(inst) if inst and os.path.isfile(inst) else 1000
                    jobs[i] = {"req": pedido["request"], "modo": m, "passo": 0, "prog": None, "fim": None, "cancelar": False, "total": total}
                    responder(c, 200, i)
            elif metodo == "POST" and rota == "/api/cancel_job":
                i = json.loads(corpo)["id"]
                if i in jobs:
                    jobs[i]["cancelar"] = True
                open(pasta + "/cancelados", "a").write("%d\n" % i)
                responder(c, 200, None)
            else:
                responder(c, 404, {"error": "unknown route"})
    except Exception as e:  # noqa: BLE001 - o teste so precisa ver a falha no log
        print("erro:", e, flush=True)
    finally:
        c.close()


s = socket.socket()
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("127.0.0.1", porta))
s.listen(16)
while True:
    c, _ = s.accept()
    threading.Thread(target=atender, args=(c,), daemon=True).start()
