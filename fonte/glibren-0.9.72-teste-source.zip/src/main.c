/* Game Library Renamer - payload para PS5.

Sobe um servidor web no PS5 (porta 8765). A tela abre no navegador do PC, do celular ou do proprio
PS5 em http://IP-DO-PS5:8765. Uso: enviar o .elf para o elfldr (porta 9021).
Opcoes (teste no PC): -p PORTA  -d PASTA_DE_DADOS
*/
#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#include "ampr_teste.h"
#include "api.h"
#include "atualizacao.h"
#include "bateria.h"
#include "cheats.h"
#include "config.h"
#include "conversao.h"
#include "fila_pkg.h"
#include "payloads.h"
#include "http.h"
#include "https.h"
#include "plataforma.h"
#include "relogio.h"
#include "tarefas.h"
#include "termico.h"
#include "sistema.h"
#include "discos.h"

#ifdef __PROSPERO__
#define PASTA_DADOS "/data/GameLibraryRenamer"
#else
#define PASTA_DADOS "./dados"
#endif

/* Outra copia ja esta rodando na porta (ex.: versao antiga): pede para ela sair. */
static void encerrar_copia_anterior(int porta) {
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  struct sockaddr_in end = {0};
  end.sin_family = AF_INET;
  end.sin_port = htons(porta);
  end.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  if(fd >= 0 && !connect(fd, (struct sockaddr *)&end, sizeof end)) {
    const char *pedido = "POST /api/sair HTTP/1.1\r\nHost: 127.0.0.1\r\nX-GLR: 1\r\nContent-Length: 0\r\n\r\n";
    send(fd, pedido, strlen(pedido), 0);
    char resposta[256];
    while(recv(fd, resposta, sizeof resposta, 0) > 0) {}
  }
  if(fd >= 0) close(fd);
}

/* O PS5 manda SIGCONT ao sair do modo de repouso: a rede volta e a porta precisa ser reaberta. */
static void ao_voltar_do_repouso(int sinal) {
  (void)sinal;
  servidor_reabrir();
  relogio_acordou();   /* o relogio pode ter andado errado no repouso: confere logo */
}

/* SIGTERM (0.9.18): em vez de cair na hora, para o servidor e deixa o main restaurar as cheats ligadas. No
   desligamento pedido pelo glibren o SIGTERM do sistema e esperado: sai na hora, como antes. Se a restauracao
   travar, o alarme de 10 s encerra o processo (acao padrao do SIGALRM). */
static volatile sig_atomic_t g_sigterm;
static void ao_terminar(int sinal) {
  (void)sinal;
  if(plataforma_desligando()) _exit(0);
  g_sigterm = 1;
  alarm(10);
  servidor_parar();
}

int main(int argc, char *argv[]) {
  const char *pasta_dados = PASTA_DADOS;
  int c;
#ifndef __PROSPERO__
  /* teste dos parsers de cheat com arquivos reais (so PC): nao inicia o servidor */
  if(argc == 5 && !strcmp(argv[1], "--teste-cheat")) return cheats_teste_arquivo(argv[2], argv[3], argv[4]);
#endif
  while((c = getopt(argc, argv, "p:d:")) != -1) {
    if(c == 'p') g_porta = atoi(optarg);
    else if(c == 'd') pasta_dados = optarg;
  }
  plataforma_iniciar(pasta_dados);   /* permissoes, nome do processo, copias antigas, diario */
  config_iniciar(pasta_dados);
  if(atualizacao_ao_iniciar()) return EXIT_SUCCESS;   /* o autoloader mandou a versao antiga: a gravada assume */
  https_iniciar();
  api_atualizar_base(0);
  tarefas_iniciar();
  termico_iniciar();
  sistema_iniciar();
  relogio_iniciar();
  discos_limpar_sobras();
  signal(SIGCONT, ao_voltar_do_repouso);
  signal(SIGTERM, ao_terminar);   /* depois do plataforma_iniciar (que liga o aviso de queda para os outros sinais) */
  plataforma_instalar_icone(g_porta);
  conversao_iniciar();
  fila_pkg_iniciar();   /* 0.9.70: Fila PKG (continua sozinha se estava rodando) */   /* 0.9.48: lista de conversoes gravada + adocao das que ja estao no Dump Forge */
  ampr_teste_iniciar();   /* 0.9.51: copias do /data/ampr_emu_trace.txt (build de depuracao do ampr-emu-ng) */
  bateria_iniciar();   /* 0.9.64: retoma (mesmo boot) ou desfaz (PS5 reiniciado) uma bateria automatica que estava andando */
  payloads_autoload_iniciar();   /* 0.9.41: payloads marcados "Carregar ao iniciar o glibren" (thread; espera o elfldr) */
  diario("servidor na porta %d", g_porta);

  for(int tentativa = 0; tentativa < 10; tentativa++) {
    char ip[64] = "IP-DO-PS5";
    meu_ip(ip, sizeof ip);
    /* servidor_rodar so volta em erro (ou ao sair pela tela) */
    /* 0.9.33: a versao carregada tambem (como os outros payloads); vale para a copia nova depois de uma atualizacao */
    if(tentativa == 0) notificar("Game Library Renamer %s\nabra http://%s:%d", VERSAO, ip, g_porta);
    if(!servidor_rodar(g_porta, api_tratar)) {
      diario("%s", g_sigterm ? "encerrando (SIGTERM)" : "encerrado pela tela (Sair)");
      cheats_restaurar_ao_sair();   /* cheats ligadas voltam ao original se o jogo ainda for o mesmo */
      return EXIT_SUCCESS;
    }
    diario("porta %d: %s", g_porta, strerror(errno));
    if(errno != EADDRINUSE) break;
    encerrar_copia_anterior(g_porta);
    sleep(1);
  }
  cheats_restaurar_ao_sair();
  notificar("Game Library Renamer: nao foi possivel usar a porta %d", g_porta);
  diario("desistiu: porta %d ocupada", g_porta);
  return EXIT_FAILURE;
}
