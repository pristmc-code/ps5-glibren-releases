/* Game Library Renamer (payload PS5) - 0.9.64: controle virtual so para a bateria fechar o jogo. Ver pad_virtual.h.
   SPDX-License-Identifier: GPL-3.0-or-later
   Nucleo portado do nosso teste-pad (ps5/teste-controle/teste-pad/main.c), baseado em Darkatek7/ProsperoSunshine
   (src/platform/ps5/pad.c, GPL-3) e Gl0ttis/ps5-mcp (src/pad.c, src/backend.h, GPL-3).
   0.9.67: vinculo ao usuario pela libSceMbus do teste-pad 1.3 (ProsperoSunshine PR #33 e phantomptr/ps5upload
   mbus-probe), a receita que FUNCIONOU no PS5 Pro 12.00 em 23/11/2026: add no usuario em primeiro plano,
   sceMbusInit(0,0) numa thread com 3 s de prazo, sceMbusBindDeviceWithUserId(handle do add, usuario) repetido
   enquanto der 0x809b0005. Mesmo vinculado, o PS5 abre "Quem esta usando este controle?" com o foco no usuario: o
   X que escolhe o usuario e o 1o passo da sequencia de fechar do plano (bateria.c). */
#include "pad_virtual.h"

#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/ioctl.h>
#include <time.h>
#include <unistd.h>

#include "plataforma.h"

#define BLOCO 0xA8
#define IOCTL_ADD 0xC018482AUL      /* ProsperoSunshine pad.c */
#define IOCTL_INSERT 0x8018482CUL
#define IOCTL_DELETE 0x80104850UL
#define CLASSE_PAD 3
#define SUBTIPO_PAD 1
#define USUARIO_SEM_DONO 1
#define INTERVALO_MS 8              /* ps5-mcp: pad que fica quieto vira "solto" e depois "sumiu" */

static const struct {
  const char *nome;
  uint32_t v;
} BOTOES[] = {   /* ps5-mcp src/backend.h */
    {"create", 0x00000001u}, {"l3", 0x00000002u},       {"r3", 0x00000004u},        {"options", 0x00000008u},
    {"cima", 0x00000010u},   {"direita", 0x00000020u},  {"baixo", 0x00000040u},     {"esquerda", 0x00000080u},
    {"l2", 0x00000100u},     {"r2", 0x00000200u},       {"l1", 0x00000400u},        {"r1", 0x00000800u},
    {"triangulo", 0x00001000u}, {"circulo", 0x00002000u}, {"cruz", 0x00004000u},    {"x", 0x00004000u},
    {"quadrado", 0x00008000u}, {"ps", 0x00010000u},     {"touchpad", 0x00100000u},
};

uint32_t pad_botao(const char *nome) {
  for(size_t i = 0; i < sizeof BOTOES / sizeof BOTOES[0]; i++)
    if(!strcasecmp(BOTOES[i].nome, nome)) return BOTOES[i].v;
  return 0;
}

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;   /* um pad por vez (so a bateria usa) */

static void dormir_ms(unsigned ms) {
  struct timespec t = {(time_t)(ms / 1000), (long)(ms % 1000) * 1000000L};
  while(nanosleep(&t, &t) != 0 && errno == EINTR) {
  }
}

#ifdef __PROSPERO__
#include <ps5/kernel.h>

int sceUserServiceGetForegroundUser(uint32_t *) __attribute__((weak));
int sceKernelLoadStartModule(const char *, size_t, const void *, uint32_t, const void *, int *) __attribute__((weak));

static int g_fd = -1, g_handle = -1;
static uint8_t g_bloco[BLOCO];

static void estado_repouso(uint32_t botoes) {
  /* botoes @0xC, analogicos @0x10..0x13 = 0x80, byte @0x17 = 1, orientacao @0x78 = (0,0,0,1), giro @0x88 = 0,
     aceleracao @0x94 = (0,1,0) -- o repouso do Remote Play (ProsperoSunshine) */
  const float orient[4] = {0, 0, 0, 1}, giro[3] = {0, 0, 0}, grav[3] = {0, 1, 0};
  memset(g_bloco, 0, sizeof g_bloco);
  memcpy(g_bloco + 0x0C, &botoes, 4);
  g_bloco[0x10] = g_bloco[0x11] = g_bloco[0x12] = g_bloco[0x13] = 0x80;
  g_bloco[0x17] = 1;
  memcpy(g_bloco + 0x78, orient, sizeof orient);
  memcpy(g_bloco + 0x88, giro, sizeof giro);
  memcpy(g_bloco + 0x94, grav, sizeof grav);
}

static int inserir(void) {
  struct {
    uint32_t handle;
    uint32_t pad;
    uint64_t estado;
    uint8_t zero;
    uint8_t pad2[7];
  } req = {(uint32_t)g_handle, 0, (uint64_t)(uintptr_t)g_bloco, 0, {0}};
  return ioctl(g_fd, IOCTL_INSERT, &req) == 0 ? 0 : -(errno ? errno : EIO);
}

static unsigned g_falhas;
static void segurar(unsigned ms) {
  unsigned passos = ms / INTERVALO_MS;
  if(!passos) passos = 1;
  for(unsigned i = 0; i < passos; i++) {
    if(inserir()) g_falhas++;
    dormir_ms(INTERVALO_MS);
  }
}

static int adicionar(int usuario, int *handle_saida) {
  uint8_t desc[BLOCO];
  memset(desc, 0, sizeof desc);
  desc[0] = CLASSE_PAD;
  memcpy(desc + 0x1C, &usuario, 4);
  desc[0x20] = SUBTIPO_PAD;
  int handle = -1;
  struct {
    uint32_t op;
    uint32_t pad;
    uint64_t desc;
    uint64_t handle;
  } req = {3, 0, (uint64_t)(uintptr_t)desc, (uint64_t)(uintptr_t)&handle};
  errno = 0;
  int r = ioctl(g_fd, IOCTL_ADD, &req), e = errno;
  diario("pad: add(usuario 0x%x) -> %d errno %d handle %d", (unsigned)usuario, r, r ? e : 0, handle);
  *handle_saida = handle;
  if(r) return -(e ? e : EIO);
  return handle < 0 ? -EIO : 0;
}

static void apagar(void) {
  if(g_fd < 0 || g_handle < 0) return;
  struct {
    uint8_t op;
    uint8_t pad[7];
    uint32_t handle;
    uint32_t pad2;
  } del = {5, {0}, (uint32_t)g_handle, 0};
  int r = ioctl(g_fd, IOCTL_DELETE, &del);
  diario("pad: delete(handle %d) -> %d%s", g_handle, r, r ? " (erro)" : "");
  g_handle = -1;
}

/* 0.9.67: vinculo pela libSceMbus (funcoes por NID no proprio processo; ver o topo). Igual ao teste-pad 1.3. */
#define NID_MBUS_INIT "wRPXMGtkOq0" /* sceMbusInit */
#define NID_MBUS_BIND "Cpo6sQmnZgU" /* sceMbusBindDeviceWithUserId */
#define NID_MBUS_INFO "RsKVKhSWt28" /* sceMbusGetDeviceInfo_ */
#define MBUS_SEM_APARELHO 0x809b0005u
#define MBUS_INFO_TAM 0x100
#define MBUS_INFO_DONO 0xC8
#define BIND_TENTATIVAS 30
#define INIT_ESPERA_MS 3000

typedef int (*mbus_init_fn)(uint64_t, uint64_t);
typedef int (*mbus_bind_fn)(uint64_t, int32_t);
typedef int (*mbus_info_fn)(uint64_t, void *, uint32_t);

static mbus_init_fn g_mbus_init;
static volatile int g_init_rc, g_init_feito, g_init_ok;

static void *mbus_resolver(uint32_t modulo, const char *nid, const char *nome) {
  intptr_t p = kernel_dynlib_resolve(getpid(), modulo, nid);
  diario("pad: resolver %s (%s) -> 0x%lx", nome, nid, (unsigned long)p);
  if(p <= 0x10000 || (uint64_t)p >= 0x0000800000000000ull) return NULL;   /* falha: chamar derrubaria o glibren */
  return (void *)p;
}

static void *thread_init(void *arg) {
  (void)arg;
  g_init_rc = g_mbus_init(0, 0);
  g_init_feito = 1;
  return NULL;
}

/* 0 = pad ligado ao usuario; senao segue sem vinculo (o PS5 pergunta o usuario do mesmo jeito). O sceMbusInit roda
   uma vez por glibren (o ps5upload viu ele travar: thread com prazo de 3 s; travou = nunca mais tenta). */
static int vincular(uint32_t usuario) {
  static int travou;
  if(travou) return -1;
  uint32_t modulo = 0;
  if(kernel_dynlib_handle(getpid(), "libSceMbus.sprx", &modulo) != 0) {
    if(!sceKernelLoadStartModule) return -1;
    int inicio = 0;
    int h = sceKernelLoadStartModule("/system/common/lib/libSceMbus.sprx", 0, NULL, 0, NULL, &inicio);
    diario("pad: sceKernelLoadStartModule(libSceMbus) -> 0x%x", (unsigned)h);
    if(h < 0) return -1;
    modulo = (uint32_t)h;
  }
  g_mbus_init = (mbus_init_fn)mbus_resolver(modulo, NID_MBUS_INIT, "sceMbusInit");
  mbus_bind_fn fbind = (mbus_bind_fn)mbus_resolver(modulo, NID_MBUS_BIND, "sceMbusBindDeviceWithUserId");
  mbus_info_fn finfo = (mbus_info_fn)mbus_resolver(modulo, NID_MBUS_INFO, "sceMbusGetDeviceInfo_");
  if(!g_mbus_init || !fbind) return -1;
  if(!g_init_ok) {
    pthread_t t;
    g_init_feito = 0;
    if(pthread_create(&t, NULL, thread_init, NULL) != 0) return -1;
    for(int ms = 0; ms < INIT_ESPERA_MS && !g_init_feito; ms += 10) dormir_ms(10);
    if(!g_init_feito) {
      diario("pad: sceMbusInit TRAVOU (mais de %d ms); seguindo sem vinculo", INIT_ESPERA_MS);
      pthread_detach(t);
      travou = 1;
      return -1;
    }
    pthread_join(t, NULL);
    g_init_ok = 1;
    diario("pad: sceMbusInit(0,0) -> 0x%08x", (unsigned)g_init_rc);
  }
  int rc = (int)MBUS_SEM_APARELHO, n = 0;
  for(n = 0; n < BIND_TENTATIVAS && (unsigned)rc == MBUS_SEM_APARELHO; n++) {
    if(n) dormir_ms(1);
    rc = fbind((uint64_t)(uint32_t)g_handle, (int32_t)usuario);
  }
  diario("pad: sceMbusBindDeviceWithUserId(%d, 0x%x) -> 0x%08x em %d tentativa(s)", g_handle, (unsigned)usuario, (unsigned)rc, n);
  if(finfo) {
    uint8_t info[MBUS_INFO_TAM];
    uint32_t dono = 0;
    memset(info, 0, sizeof info);
    int ri = finfo((uint64_t)(uint32_t)g_handle, info, sizeof info);
    if(ri == 0) memcpy(&dono, info + MBUS_INFO_DONO, sizeof dono);
    diario("pad: sceMbusGetDeviceInfo_ -> 0x%08x, dono 0x%x", (unsigned)ri, (unsigned)dono);
  }
  return rc == 0 ? 0 : -1;
}

int pad_abrir(int repouso_ms, char *erro, size_t tam_erro) {
  pthread_mutex_lock(&g_trava);
  uint32_t usuario = 0;
  if(!sceUserServiceGetForegroundUser || sceUserServiceGetForegroundUser(&usuario)) usuario = 0;
  errno = 0;
  g_fd = open("/dev/hid", O_RDONLY);
  if(g_fd < 0) {
    int e = errno;
    snprintf(erro, tam_erro, "open /dev/hid errno %d", e);
    pthread_mutex_unlock(&g_trava);
    return -(e ? e : EIO);
  }
  int handle = -1, r = -1;
  if(usuario > USUARIO_SEM_DONO) r = adicionar((int)usuario, &handle);
  if(r) r = adicionar(USUARIO_SEM_DONO, &handle);   /* ps5-mcp (13.60): o add pode recusar o usuario real */
  if(r) {
    snprintf(erro, tam_erro, "add errno %d", -r);
    close(g_fd);
    g_fd = -1;
    pthread_mutex_unlock(&g_trava);
    return r;
  }
  g_handle = handle;
  g_falhas = 0;
  if(usuario > USUARIO_SEM_DONO) vincular(usuario);   /* 0.9.67; falhar nao impede: a janela do usuario aparece igual */
  estado_repouso(0);
  r = inserir();
  if(r) {
    snprintf(erro, tam_erro, "insert errno %d", -r);
    apagar();
    close(g_fd);
    g_fd = -1;
    pthread_mutex_unlock(&g_trava);
    return r;
  }
  segurar((unsigned)(repouso_ms > 0 ? repouso_ms : 1500));
  return 0;   /* fica com g_trava ate pad_fechar */
}

int pad_apertar(uint32_t botoes, int segurar_ms, int depois_ms) {
  if(g_fd < 0 || g_handle < 0) return -1;
  unsigned antes = g_falhas;
  estado_repouso(botoes);
  segurar((unsigned)(segurar_ms > 0 ? segurar_ms : 150));
  estado_repouso(0);
  segurar((unsigned)(depois_ms > 0 ? depois_ms : 1));
  return g_falhas > antes ? -1 : 0;
}

void pad_esperar(int ms) {
  if(g_fd < 0 || g_handle < 0) {
    dormir_ms((unsigned)(ms > 0 ? ms : 0));
    return;
  }
  estado_repouso(0);
  segurar((unsigned)(ms > 0 ? ms : 1));
}

void pad_fechar(void) {
  if(g_fd < 0) return;
  apagar();
  close(g_fd);
  g_fd = -1;
  diario("pad: controle virtual apagado (%u reenvios falharam)", g_falhas);
  pthread_mutex_unlock(&g_trava);
}

#else
/* PC: simulado. GLR_TESTE_PAD=falha -> nao cria; cada aperto vai para GLR_TESTE_PAD_LOG. */
static int g_aberto;

static void anotar(const char *fmt, const char *a, int ms) {
  const char *arq = getenv("GLR_TESTE_PAD_LOG");
  if(!arq || !*arq) return;
  FILE *f = fopen(arq, "a");
  if(!f) return;
  fprintf(f, fmt, a, ms);
  fclose(f);
}

int pad_abrir(int repouso_ms, char *erro, size_t tam_erro) {
  const char *m = getenv("GLR_TESTE_PAD");
  if(m && !strcmp(m, "falha")) {
    snprintf(erro, tam_erro, "open /dev/hid errno %d", EACCES);
    return -EACCES;
  }
  pthread_mutex_lock(&g_trava);
  g_aberto = 1;
  anotar("abrir %s%d\n", "", repouso_ms);
  return 0;
}

int pad_apertar(uint32_t botoes, int segurar_ms, int depois_ms) {
  if(!g_aberto) return -1;
  const char *nome = "?";
  for(size_t i = 0; i < sizeof BOTOES / sizeof BOTOES[0]; i++)
    if(BOTOES[i].v == botoes) {
      nome = BOTOES[i].nome;
      break;
    }
  anotar("botao %s %d\n", nome, segurar_ms);
  dormir_ms((unsigned)((depois_ms > 0 ? depois_ms : 0) / 20));   /* testes: 20x mais rapido */
  return 0;
}

void pad_esperar(int ms) {
  anotar("espera %s%d\n", "", ms);
  dormir_ms((unsigned)((ms > 0 ? ms : 0) / 20));
}

void pad_fechar(void) {
  if(!g_aberto) return;
  g_aberto = 0;
  anotar("fechar %s%d\n", "", 0);
  pthread_mutex_unlock(&g_trava);
}
#endif
