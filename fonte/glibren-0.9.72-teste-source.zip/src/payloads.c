/* Game Library Renamer (payload PS5) - payloads de terceiros para teste (0.9.20). Ver payloads.h.

Regras:
  - so os itens do catalogo abaixo (id fora da lista = recusado); URL, tamanho e SHA-256 fixados aqui;
  - o arquivo baixado E o arquivo guardado sao conferidos pelo SHA-256 antes de enviar ao elfldr (adulterado = recusado
    e apagado);
  - 0.9.22: os itens marcados "shellui" (tela cheia e PrefBar) mexem na mesma interface: um ativo nesta sessao do PS5
    bloqueia os outros; "uma_vez" (PrefBar fica rodando) nao ativa duas vezes. .ativado = "hora pid_da_SceShellUI";
    vale depois do kern.boottime e com a mesma ShellUI;
  - um trabalho por vez; nada com jogo/app aberto (se a interface do PS5 reiniciar, o jogo fecharia sem salvar);
  - rota POST com X-GLR e pareamento (api.c). O navegador do PS5 (e outros programas do proprio PS5, que o pareamento
    deixa passar) so pode acionar o item marcado "navegador" (tela cheia): e o unico que faz sentido ali, e e o mesmo
    gesto de quem esta com o controle na mao diante da TV;
  - item "navegador" (modelo do PS5 Web File Manager, botao de tela cheia): responde, 250 ms, volta a tela inicial
    (sceShellUIUtilLaunchByUri "pshomeui:navigateToHome"), 1 s, envia ao elfldr, espera o resultado e reabre o navegador
    na pagina pedida (sceSystemServiceLaunchWebBrowser), mesmo se falhar, para ninguem ficar perdido na tela inicial.
O resultado vem da saida do proprio payload: o elfldr (ps5-payload-dev) liga stdin/stdout/stderr do payload a conexao
que o enviou. O ps5-web-browser-fullscreen escreve "Result=N; ..." (0 = ok, 2 = ok mas o INI nao gravou, 1 = falhou) e
"Notification: <texto>".
0.9.24: POST /api/navegador/abrir reaproveita a tela inicial + abrir_navegador para o celular abrir o navegador do PS5
numa pagina da lista fixa DESTINOS (o PS5 nao tem o app de navegador na tela: so abre pelo icone do glibren).
0.9.35: ZhiThemes (itsRealZhi/ZhiThemes, so pre-release) tambem e "shellui": injeta na SceShellUI; rodando agora por
GET 127.0.0.1:4444/version (GLR_TESTE_ZHITHEMES_PORTA no PC).
0.9.40: MemDBG (seregonwar/MemDBG): rodando agora pelo HELLO do protocolo MDBG na 9020 (src/memdbg.c, cache de 20 s;
GLR_TESTE_MEMDBG_PORTA no PC); o glibren usa o MemDBG so como cliente (area extra das cheats).
0.9.72: Disk Space Analyzer (igorwojda/ps5-disk-space-analyzer): rodando agora pelo nome do processo.
0.9.59: CoreDump Dumper (jamesst20/PS5-CoreDump-Dumper): rodando agora pelo nome do processo (coredump-dump.elf); a
lista dos dumps guardados e o envio ficam em src/coredump.c.
Testes no PC: GLR_TESTE_ELFLDR (porta do elfldr falso), GLR_TESTE_PAYLOADS_URL (base no lugar do GitHub, servidor local
de GLR_TESTE_BASE), GLR_TESTE_PAYLOAD_SHA/GLR_TESTE_PAYLOAD_TAM (outro arquivo no lugar do .elf real), GLR_TESTE_FW. */
#include "payloads.h"

#include <arpa/inet.h>
#include <dirent.h>
#include <errno.h>
#include <limits.h>
#include <strings.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#include "api.h"
#include "config.h"
#include "fps.h"
#include "https.h"
#include "lancador.h"
#include "plataforma.h"
#include "prefbar.h"
#include "sha256.h"
#include "conversao.h"
#include "apps.h"
#include "github_rel.h"
#include "memdbg.h"
#include "coredump.h"
#include "atualizacao.h"

#ifdef __PROSPERO__
#include <ps5/kernel.h>
#include <sys/sysctl.h>
#include <sys/user.h>
int sceKernelLoadStartModule(const char *, size_t, const void *, uint32_t, void *, int *) __attribute__((weak));
int sceSystemServiceLaunchWebBrowser(const char *, void *) __attribute__((weak));
int sceUserServiceGetForegroundUser(uint32_t *) __attribute__((weak));
#endif

#define PORTA_ELFLDR 9021
#define MAX_SAIDA (16 * 1024)
#ifdef MSG_NOSIGNAL
#define SEM_SINAL MSG_NOSIGNAL   /* elfldr fechou no meio: erro, nao queda */
#else
#define SEM_SINAL 0
#endif

typedef struct {
  const char *id, *nome, *autor, *licenca, *repo, *tag, *url, *arquivo, *sha256;
  unsigned long long tamanho;
  const char *firmwares;              /* testados em console (autor e comunidade), separados por espaco */
  const char *descricao[3];           /* pt-BR, en, es */
  const char *desfazer[3];
  const char *aviso[3];
  int espera_s;                       /* quanto esperar a saida do payload (ele termina sozinho) */
  int navegador;                      /* 1 = tela cheia do navegador: volta a home, aplica e reabre */
  int shellui;                        /* 0.9.22: 1 = mexe na interface do PS5 (SceShellUI): so um destes por sessao */
  int uma_vez;                        /* 0.9.22: 1 = fica rodando; ativar de novo na mesma sessao = duas copias (recusado) */
  const char *confirmados;            /* 0.9.23: firmwares que NOS testamos no PS5 real (separados por espaco) */
  const char *confirmado_em;          /* 0.9.23: em que console e data */
  int sonda;                          /* 0.9.33: como saber se esta rodando agora (SONDA_*) */
  /* 0.9.33: acompanhado pelo GitHub (gh_repo != NULL): versao, URL, tamanho e SHA-256 vem da ultima release (API do
     GitHub, digest do asset); arquivo = "<id>.elf"; tag/url/sha256/tamanho acima ficam vazios */
  const char *gh_repo, *gh_padrao;
  int gh_pre;                         /* 1 = a mais nova inclusive pre-release ("experimental") */
  unsigned long long gh_max;          /* tamanho maximo aceito */
  int aviso_smp;                      /* 1 = nao roda junto com o ShadowMount+: ativar pede confirmo=1 */
  const char *removido_em;            /* 0.9.34: repositorio removido do GitHub (DD/MM/AAAA): nao consulta nem instala;
                                         sem arquivo guardado o item nem aparece; guardado continua para Ativar/Remover/Voltar */
  int de_arquivo;                     /* 0.9.41: aceita "Instalar de arquivo" (.elf posto pelo usuario num disco do PS5) */
  const char *arq_padrao;             /* 0.9.41: o nome do .elf tem de conter isto (sem diferenca de maiusculas) */
  int embutido;                       /* 0.9.64: o .elf vem dentro do glibren (nosso payload; sha256/tamanho fixos acima) */
} item_t;

enum { SONDA_NENHUMA = 0, SONDA_DUMPFORGE, SONDA_KRAKEN, SONDA_SHADOWKRAKEN, SONDA_BLUEV, SONDA_ZHITHEMES, SONDA_MEMDBG, SONDA_KSTUFF,
       SONDA_COREDUMP, SONDA_NANODNS, SONDA_DISCO };
#define PORTA_BLUEV 7733
#define PORTA_ZHITHEMES 4444
#define PORTA_KRAKEN 8097
#define PROCESSO_SMP "shadowmountplus.elf"   /* nome que o ShadowMount+ E o ShadowKraken dao a si mesmos */
/* 0.9.30 guardava o Dump Forge fixo com o nome do asset: adotado como versao instalada se o SHA-256 bater */
#define DF_LEGADO_ARQ "ps5-dump-forge-0.5.6-ps5.elf"
#define DF_LEGADO_SHA "f0415aab6ded1cdf875418b6683ab56aeae3721492af99fba71b08c2c351f82f"
#define DF_LEGADO_TAM 18549840ULL

static const item_t ITENS[] = {
  {"web-browser-fullscreen", "PS5 Web Browser Fullscreen", "owendswang", "GPL-3.0-or-later",
   /* 0.9.33: acompanhado pelo GitHub (antes: v0.1b fixa, sha256 520977607a22ecdf..., 463.848 B) */
   "https://github.com/owendswang/ps5-web-browser-fullscreen", "", "", "web-browser-fullscreen.elf", "", 0ULL,
   "4.03 6.50 7.00 7.61 10.01 10.20 11.20 12.02 12.20 13.00 13.60",
   {"Deixa o navegador do PS5 em tela cheia (1920x1080, sem a moldura). Corrige a interface do PS5 (ShellUI) só na memória: nenhum arquivo do sistema é alterado.",
    "Makes the PS5 web browser fullscreen (1920x1080, without the frame). Patches the PS5 interface (ShellUI) in memory only: no system file is changed.",
    "Pone el navegador de la PS5 en pantalla completa (1920x1080, sin el marco). Corrige la interfaz de la PS5 (ShellUI) solo en la memoria: ningún archivo del sistema se modifica."},
   {"Reinicie o PS5 (trocar o idioma do sistema também desfaz). O glibren não usa o \"restore\" do autor: no 11.60 ele derrubou a interface.",
    "Restart the PS5 (changing the system language also undoes it). glibren does not use the author's \"restore\": on 11.60 it crashed the interface.",
    "Reinicie la PS5 (cambiar el idioma del sistema también lo deshace). glibren no usa el \"restore\" del autor: en 11.60 tumbó la interfaz."},
   {"O PS5 volta à tela inicial, aplica e reabre o navegador. Outros cartões do sistema podem mudar de tamanho enquanto valer.",
    "The PS5 goes back to the home screen, applies it and reopens the browser. Other system cards may change size while it lasts.",
    "La PS5 vuelve a la pantalla de inicio, lo aplica y reabre el navegador. Otras tarjetas del sistema pueden cambiar de tamaño mientras dure."},
   30, 1, 1, 0,
   /* 0.9.23: o usuario testou a v0.1b no PS5 Pro 12.00 em 13/11/2026: "funcionou perfeito e desativou quando reiniciei" */
   "12.00", "PS5 Pro, 13/11/2026", SONDA_NENHUMA,
   /* so a ultima release normal (a "test" e pre-release); o "restore" do autor fica de fora pelo padrao */
   "owendswang/ps5-web-browser-fullscreen", "web-browser-fullscreen-*.elf", 0, 8ULL * 1024 * 1024, 0},
  /* 0.9.22: PrefBar (numeros por cima do jogo). Fica rodando: espera um jogo abrir e a interface do PS5 ficar estavel e
     so entao se injeta na SceShellUI (o README manda carregar e DEPOIS abrir o jogo). Nao escreve nada na saida quando
     da certo: o glibren espera 4 s por um erro do elfldr e solta a conexao. */
  {"prefbar", "PrefBar", "X1NONs", "GPL-3.0",
   /* 0.9.33: acompanhado pelo GitHub (antes: v0.3.0 fixa, sha256 e4379590115ef87b..., 964.272 B) */
   "https://github.com/X1NONs/PrefBar", "", "", "prefbar.elf", "", 0ULL,
   "7.xx 8.xx 9.xx 10.xx 11.xx 12.xx 13.xx",
   {"Mostra FPS, 1% low, CPU e GPU (uso, temperatura, MHz), ventoinha, RAM, VRAM e consumo numa barra por cima do jogo. Ative fora do jogo e depois abra o jogo: a barra aparece alguns segundos depois. Três toques no touchpad mostram ou escondem.",
    "Shows FPS, 1% low, CPU and GPU (usage, temperature, MHz), fan, RAM, VRAM and power in a bar over the game. Activate it outside the game, then open the game: the bar shows up a few seconds later. Triple-tap the touchpad to show or hide it.",
    "Muestra FPS, 1% low, CPU y GPU (uso, temperatura, MHz), ventilador, RAM, VRAM y consumo en una barra sobre el juego. Actívelo fuera del juego y luego abra el juego: la barra aparece unos segundos después. Tres toques en el touchpad la muestran u ocultan."},
   {"Reinicie o PS5 (nada fica instalado; para limpar tudo, apague a pasta /data/prefbar).",
    "Restart the PS5 (nothing stays installed; to clean everything, delete the /data/prefbar folder).",
    "Reinicie la PS5 (nada queda instalado; para limpiar todo, borre la carpeta /data/prefbar)."},
   {"Espere ~2 min depois de ligar o PS5. Não use junto com a tela cheia do navegador: os dois mexem na interface do PS5 (ShellUI). Não testado no PS5 Pro 12.00.",
    "Wait ~2 min after turning the PS5 on. Do not use it together with the browser fullscreen: both change the PS5 interface (ShellUI). Not tested on the PS5 Pro 12.00.",
    "Espere ~2 min después de encender la PS5. No lo use junto con la pantalla completa del navegador: los dos modifican la interfaz de la PS5 (ShellUI). No probado en la PS5 Pro 12.00."},
   4, 0, 1, 1, NULL, NULL, SONDA_NENHUMA,
   /* o nome do .elf muda a cada versao (perfbar-complete.elf, PrefBar-complete_V0.2.1.elf, Prefbar_V0.3.0.elf): cada
      release tem um .elf so, e ele tem de ser unico */
   "X1NONs/PrefBar", "*.elf", 0, 8ULL * 1024 * 1024, 0},
  /* 0.9.30: ps5-dump-forge (motor da conversao de formato do glibren, src/conversao.c). Fica rodando, com a API em
     127.0.0.1:8095 e a pagina dele em http://<ip do PS5>:8095. 0.9.33: acompanhado pelo GitHub (antes: v0.5.6 fixa). */
  {"dump-forge", "PS5 Dump Forge", "quer3q", "GPL-3.0",
   "https://github.com/quer3q/ps5-dump-forge", "", "", "dump-forge.elf", "", 0ULL,
   "",
   {"Converte jogos entre pasta, .exfat, .ffpkg, .ffpfs, .ffpfsc, .pkg (FPKG) e pastas compactadas (zstd e LZ4, com o ampr-emu-ng). É o motor do botão Converter da lista de jogos do glibren e da conversão da Jobe; também tem a própria página em http://IP-do-PS5:8095.",
    "Converts games between folder, .exfat, .ffpkg, .ffpfs, .ffpfsc, .pkg (FPKG) and packed folders (zstd and LZ4, with ampr-emu-ng). It is the engine behind the Convert button in glibren's game list and Jobe's conversion; it also has its own page at http://PS5-IP:8095.",
    "Convierte juegos entre carpeta, .exfat, .ffpkg, .ffpfs, .ffpfsc, .pkg (FPKG) y carpetas comprimidas (zstd y LZ4, con ampr-emu-ng). Es el motor del botón Convertir de la lista de juegos de glibren y de la conversión de Jobe; también tiene su propia página en http://IP-de-la-PS5:8095."},
   {"Feche pela página dele (http://IP-do-PS5:8095) ou reinicie o PS5. Nada fica instalado no sistema.",
    "Close it from its page (http://PS5-IP:8095) or restart the PS5. Nothing is installed in the system.",
    "Ciérrelo desde su página (http://IP-de-la-PS5:8095) o reinicie la PS5. Nada queda instalado en el sistema."},
   {"Usa a porta 8095: a conversão do glibren e da Jobe fala com ele por ela (não ligue outro programa nessa porta). Arquivo grande (~18 MB). Fica rodando até reiniciar o PS5; uma versão nova só vale depois de fechar a que está rodando. Não testado por nós no PS5 Pro 12.00.",
    "Uses port 8095: glibren's and Jobe's conversion talk to it there (do not run another program on that port). Large file (~18 MB). It keeps running until the PS5 restarts; a new version only takes effect after closing the running one. Not tested by us on the PS5 Pro 12.00.",
    "Usa el puerto 8095: la conversión de glibren y de Jobe habla con él por ahí (no use otro programa en ese puerto). Archivo grande (~18 MB). Sigue ejecutándose hasta reiniciar la PS5; una versión nueva solo vale después de cerrar la que está en ejecución. No probado por nosotros en la PS5 Pro 12.00."},
   4, 0, 0, 1, NULL, NULL, SONDA_DUMPFORGE,
   "quer3q/ps5-dump-forge", "ps5-dump-forge-*-ps5.elf", 0, 64ULL * 1024 * 1024, 0},
  /* 0.9.33: kraken-mount (monta jogos em pasta e FPKG direto, com o ampr-emu-ng). Interface em :8097 (GET /api/state traz
     "version" e "waiting"). Espera o ShadowMount+ PARAR antes de montar qualquer coisa (README/DESIGN do autor). */
  {"kraken-mount", "Kraken Mount", "quer3q", "GPL-3.0",
   "https://github.com/quer3q/kraken-mount", "", "", "kraken-mount.elf", "", 0ULL,
   "",
   {"Monta jogos em pasta (normal, zstd e LZ4) e .pkg FPKG direto, sem instalar, com o ampr-emu-ng embutido. Tem a própria página em http://IP-do-PS5:8097.",
    "Mounts games as folders (plain, zstd and LZ4) and FPKG .pkg directly, without installing, with ampr-emu-ng built in. It has its own page at http://PS5-IP:8097.",
    "Monta juegos en carpeta (normal, zstd y LZ4) y .pkg FPKG directo, sin instalar, con ampr-emu-ng incluido. Tiene su propia página en http://IP-de-la-PS5:8097."},
   {"Feche pela página dele (http://IP-do-PS5:8097) ou reinicie o PS5.",
    "Close it from its page (http://PS5-IP:8097) or restart the PS5.",
    "Ciérrelo desde su página (http://IP-de-la-PS5:8097) o reinicie la PS5."},
   {"Não roda junto com o ShadowMount+ (nem com o ShadowKraken): enquanto um deles estiver rodando, o kraken-mount fica esperando e não monta nada. O glibren nunca fecha o ShadowMount+: tire-o do autoload e reinicie o PS5 antes, ou use o ShadowKraken. Não testado por nós no PS5 Pro 12.00.",
    "Does not run together with ShadowMount+ (nor with ShadowKraken): while one of them is running, kraken-mount waits and mounts nothing. glibren never closes ShadowMount+: remove it from autoload and restart the PS5 first, or use ShadowKraken. Not tested by us on the PS5 Pro 12.00.",
    "No funciona junto con ShadowMount+ (ni con ShadowKraken): mientras uno de ellos esté en ejecución, kraken-mount espera y no monta nada. glibren nunca cierra ShadowMount+: quítelo del autoload y reinicie la PS5 antes, o use ShadowKraken. No probado por nosotros en la PS5 Pro 12.00."},
   4, 0, 0, 1, NULL, NULL, SONDA_KRAKEN,
   "quer3q/kraken-mount", "kraken-mount.elf", 0, 32ULL * 1024 * 1024, 1},
  /* 0.9.33: ShadowKraken (fork do ShadowMount+ com o backend FPKG do kraken). So pre-releases "Dev". Usa o MESMO nome de
     processo do SMP (shadowmountplus.elf) e, ao subir, pede para a copia que esta rodando (SMP ou ele) sair (SIGTERM) e
     fica no lugar (main.c dele). API igual a do SMP (POST /api/v1/version, porta 10101 por padrao). */
  {"shadowkraken", "ShadowKraken", "MNeroba", "GPL-3.0",
   "https://github.com/MNeroba/ShadowKraken", "", "", "shadowkraken-PristMC.elf", "", 0ULL,   /* 0.9.41: nome fixo (antes shadowkraken.elf) */
   "",
   {"ShadowMount+ com o suporte a FPKG do kraken-mount num payload só: monta pastas, imagens (.exfat/.ffpkg/.ffpfs/.ffpfsc) e .pkg FPKG (experimental). Usa no lugar do ShadowMount+. Página em http://IP-do-PS5:10101.",
    "ShadowMount+ with kraken-mount's FPKG support in a single payload: mounts folders, images (.exfat/.ffpkg/.ffpfs/.ffpfsc) and FPKG .pkg (experimental). Used instead of ShadowMount+. Page at http://PS5-IP:10101.",
    "ShadowMount+ con el soporte FPKG de kraken-mount en un solo payload: monta carpetas, imágenes (.exfat/.ffpkg/.ffpfs/.ffpfsc) y .pkg FPKG (experimental). Se usa en lugar de ShadowMount+. Página en http://IP-de-la-PS5:10101."},
   {"Reinicie o PS5 (o ShadowMount+ do autoload volta). Para não voltar, tire o ShadowKraken de onde você o liga.",
    "Restart the PS5 (ShadowMount+ from autoload comes back). To keep it from coming back, remove ShadowKraken from where you start it.",
    "Reinicie la PS5 (vuelve el ShadowMount+ del autoload). Para que no vuelva, quite ShadowKraken de donde lo inicia."},
   {"Experimental (só versões \"Dev\"). Substitui o ShadowMount+: se ele estiver rodando, o próprio ShadowKraken pede para ele fechar e fica no lugar (o glibren não fecha nada). Não use junto com o kraken-mount. Não testado por nós no PS5 Pro 12.00.",
    "Experimental (\"Dev\" builds only). Replaces ShadowMount+: if it is running, ShadowKraken itself asks it to close and takes its place (glibren closes nothing). Do not use together with kraken-mount. Not tested by us on the PS5 Pro 12.00.",
    "Experimental (solo versiones \"Dev\"). Sustituye a ShadowMount+: si está en ejecución, el propio ShadowKraken le pide que se cierre y ocupa su lugar (glibren no cierra nada). No lo use junto con kraken-mount. No probado por nosotros en la PS5 Pro 12.00."},
   4, 0, 0, 1, NULL, NULL, SONDA_SHADOWKRAKEN,
   "MNeroba/ShadowKraken", "ShadowKraken.elf", 1, 32ULL * 1024 * 1024, 1, "17/11/2026",   /* 0.9.34: repo 404 desde 17/11/2026 */
   1, "shadowkraken"},   /* 0.9.41: o ShadowKraken do dono e um build proprio: "Instalar de arquivo" */
  /* 0.9.34: BlueV (som do PS5 em Bluetooth A2DP). Pagina propria em :7733 sem senha; GET /api/status responde enquanto
     roda (sem a versao: docs/program.md e src/service/service.cpp do autor). A release tambem tem bluev.elf.sha256: o
     padrao "bluev.elf" casa so com o .elf. */
  {"bluev", "BlueV", "0xZ3n0x", "GPL-3.0",
   "https://github.com/0xZ3n0x/BlueV", "", "", "bluev.elf", "", 0ULL,
   "",
   {"Som do PS5 em caixas e fones Bluetooth (A2DP). Funciona com adaptador Bluetooth USB (CSR 4.0 testado) ou com o chip do próprio PS5, que é dividido com o controle. Controle pela página na porta 7733 ou pelo atalho BlueV na tela inicial.",
    "PS5 sound on Bluetooth speakers and headphones (A2DP). Works with a USB Bluetooth adapter (CSR 4.0 tested) or with the PS5's own chip, which is shared with the controller. Control it from the page on port 7733 or from the BlueV shortcut on the home screen.",
    "Sonido de la PS5 en altavoces y auriculares Bluetooth (A2DP). Funciona con adaptador Bluetooth USB (CSR 4.0 probado) o con el chip de la propia PS5, que se comparte con el mando. Control desde la página en el puerto 7733 o desde el acceso BlueV en la pantalla de inicio."},
   {"Pare pela página dele (http://IP-do-PS5:7733, \"Stop BlueV\") ou reinicie o PS5.",
    "Stop it from its page (http://PS5-IP:7733, \"Stop BlueV\") or restart the PS5.",
    "Deténgalo desde su página (http://IP-de-la-PS5:7733, \"Stop BlueV\") o reinicie la PS5."},
   {"Usa a porta 7733 sem senha: qualquer aparelho da rede abre a página dele (dá para limitar ao próprio PS5 nela). Fica rodando até parar pela página ou reiniciar o PS5. Não testado por nós no PS5 Pro 12.00.",
    "Uses port 7733 without a password: any device on the network can open its page (it can be limited to the PS5 itself there). It keeps running until stopped from the page or the PS5 restarts. Not tested by us on the PS5 Pro 12.00.",
    "Usa el puerto 7733 sin contraseña: cualquier aparato de la red abre su página (se puede limitar a la propia PS5 en ella). Sigue ejecutándose hasta detenerlo desde la página o reiniciar la PS5. No probado por nosotros en la PS5 Pro 12.00."},
   4, 0, 0, 1, NULL, NULL, SONDA_BLUEV,
   "0xZ3n0x/BlueV", "bluev.elf", 0, 16ULL * 1024 * 1024, 0, NULL},
  /* 0.9.35: ZhiThemes (temas na tela inicial real do PS5). Injeta um modulo na SceShellUI (so na memoria; grava so em
     /data/ZhiThemes/) e fica um processo vigia que reinjeta se a ShellUI reiniciar. Editor em :4444 sem senha (INADDR_ANY,
     src/source/shellui/src/theme_web.cpp do autor); GET /version responde "zhithemes 0.1.0-alpha (build ...) ..." enquanto
     roda. Mandar de novo troca a copia que esta rodando sem reiniciar (POST /quit + vigia novo, main.cpp do autor): nao e
     "uma_vez". So tem pre-release (v0.1.0-alpha); a release tambem traz ZhiThemes-themes.zip (temas, fora do glibren). */
  {"zhithemes", "ZhiThemes", "itsRealZhi", "GPL-3.0",
   "https://github.com/itsRealZhi/ZhiThemes", "", "", "zhithemes.elf", "", 0ULL,
   "9.xx 10.xx 11.xx 12.xx 13.xx",
   {"Temas na tela inicial do PS5: pastas de jogos, capas verticais, papel de parede com imagem ou vídeo, fonte, barra de cima nova, Configurações e Troféus com o tema. Edite pelo PC ou celular em http://IP-do-PS5:4444. Firmware 9.00 a 13.60. Os temas prontos ficam no arquivo ZhiThemes-themes.zip da release (o glibren não instala).",
    "Themes for the PS5 home screen: game folders, vertical covers, picture or video wallpaper, font, a new top bar, themed Settings and Trophies. Edit it from a PC or phone at http://PS5-IP:4444. Firmware 9.00 to 13.60. Ready-made themes are in the release's ZhiThemes-themes.zip file (glibren does not install them).",
    "Temas en la pantalla de inicio de la PS5: carpetas de juegos, portadas verticales, fondo con imagen o vídeo, fuente, barra superior nueva, Ajustes y Trofeos con el tema. Edítelo desde el PC o el móvil en http://IP-de-la-PS5:4444. Firmware 9.00 a 13.60. Los temas listos están en el archivo ZhiThemes-themes.zip de la release (glibren no los instala)."},
   {"Reinicie o PS5 sem mandar o payload de novo: o PS5 volta ao normal. Para desligar só o tema: no editor ou em Opções > ZhiThemes, \"PS5 default\". Para apagar tudo, apague a pasta /data/ZhiThemes.",
    "Restart the PS5 without sending the payload again: the PS5 goes back to normal. To turn only the theme off: in the editor or in Options > ZhiThemes, \"PS5 default\". To delete everything, delete the /data/ZhiThemes folder.",
    "Reinicie la PS5 sin volver a enviar el payload: la PS5 vuelve a la normalidad. Para apagar solo el tema: en el editor o en Opciones > ZhiThemes, \"PS5 default\". Para borrar todo, borre la carpeta /data/ZhiThemes."},
   {"Alpha. Altera a tela inicial de verdade do PS5 (só na memória; grava apenas em /data/ZhiThemes). Ative sem jogo aberto. Não roda junto com etaHEN, OnionHEN ou AniketosHEN (ele mesmo recusa e avisa) nem com outro payload que mexe na interface do PS5. Modo seguro: 2 travamentos da tela inicial em 3 min desligam o tema. Usa a porta 4444 sem senha: qualquer aparelho da rede abre o editor. Não testado por nós no PS5 Pro 12.00.",
    "Alpha. It changes the PS5's real home screen (in memory only; it writes only to /data/ZhiThemes). Activate it with no game open. It does not run together with etaHEN, OnionHEN or AniketosHEN (it refuses by itself and says so) nor with another payload that changes the PS5 interface. Safe mode: 2 home screen crashes within 3 min turn the theme off. Uses port 4444 without a password: any device on the network can open the editor. Not tested by us on the PS5 Pro 12.00.",
    "Alpha. Cambia la pantalla de inicio real de la PS5 (solo en la memoria; escribe solo en /data/ZhiThemes). Actívelo sin juego abierto. No funciona junto con etaHEN, OnionHEN o AniketosHEN (él mismo lo rechaza y avisa) ni con otro payload que modifique la interfaz de la PS5. Modo seguro: 2 caídas de la pantalla de inicio en 3 min apagan el tema. Usa el puerto 4444 sin contraseña: cualquier aparato de la red abre el editor. No probado por nosotros en la PS5 Pro 12.00."},
   4, 0, 1, 0, NULL, NULL, SONDA_ZHITHEMES,
   "itsRealZhi/ZhiThemes", "ZhiThemes.elf", 1, 24ULL * 1024 * 1024, 0, NULL},
  /* 0.9.40: MemDBG (seregonwar/MemDBG, GPL-3): depurador de memoria aberto. O glibren e so CLIENTE do protocolo MDBG
     dele (src/memdbg.c) para reservar a "area extra" das cheats que precisam de uma area que o jogo nao tem. Portas do
     MemDBG (README e docs/protocol.md do autor): TCP 9020 (protocolo MDBG, 0.0.0.0 no console, sem senha), TCP 744
     (compativel com o ps5debug, ligada por padrao no console), UDP 9022 (descoberta) e 9023 (log). Nenhuma e usada pelo
     resto do setup (elfldr 9021, glibren 8765, Jobe 34200/34201, tube 34210, BlueV 7733, ZhiThemes 4444, Dump Forge
     8095, SMP 10101, kraken 8097); a 744 e a do ps5debug/ps5debug-NG (nao usar junto). Rodando agora: HELLO na 9020
     (versao e feature level). Releases "nightly-AAAAMMDD-g<commit>" (release normal, nao pre-release; digest no GitHub). */
  {"memdbg", "MemDBG", "seregonwar", "GPL-3.0",
   "https://github.com/seregonwar/MemDBG", "", "", "memdbg.elf", "", 0ULL,
   "",
   {"Depurador de memória aberto. O glibren usa ele só para criar a \"área extra\" de cheats que precisam de uma área que o jogo não tem (ex.: Easy Score e 10x Score do Terminator 2D), com a chave \"Área extra (teste)\" ligada na página Cheats. Ative com o jogo fechado, antes de abrir o jogo.",
    "Open memory debugger. glibren uses it only to create the \"extra area\" of cheats that need an area the game does not have (e.g. Easy Score and 10x Score in Terminator 2D), with the \"Extra area (test)\" switch on in the Cheats page. Activate it with the game closed, before opening the game.",
    "Depurador de memoria abierto. glibren lo usa solo para crear el \"área extra\" de trucos que necesitan un área que el juego no tiene (ej.: Easy Score y 10x Score de Terminator 2D), con el interruptor \"Área extra (prueba)\" activado en la página Trucos. Actívelo con el juego cerrado, antes de abrir el juego."},
   {"Reinicie o PS5 (ele fica rodando até reiniciar). As áreas que o glibren pediu são liberadas ao desligar cada cheat; fechar o jogo também apaga elas.",
    "Restart the PS5 (it keeps running until a restart). The areas glibren asked for are freed when each cheat is turned off; closing the game also erases them.",
    "Reinicie la PS5 (sigue ejecutándose hasta reiniciar). Las áreas que glibren pidió se liberan al desactivar cada truco; cerrar el juego también las borra."},
   {"Ferramenta de depuração aberta na rede, sem senha: qualquer aparelho da rede lê e grava a memória dos jogos pelas portas TCP 9020 e 744 (a do ps5debug; não carregue os dois juntos) e usa UDP 9022 e 9023. Carregue só quando for usar e reinicie o PS5 depois. Cada conexão nova mostra a notificação \"MemDBG ... connected\". Não testado por nós no PS5 Pro 12.00.",
    "Debugging tool open on the network, with no password: any device on the network can read and write game memory through TCP ports 9020 and 744 (the ps5debug one; do not load both together) and it uses UDP 9022 and 9023. Load it only when you are going to use it and restart the PS5 afterwards. Each new connection shows the \"MemDBG ... connected\" notification. Not tested by us on the PS5 Pro 12.00.",
    "Herramienta de depuración abierta en la red, sin contraseña: cualquier aparato de la red lee y escribe la memoria de los juegos por los puertos TCP 9020 y 744 (el de ps5debug; no cargue los dos juntos) y usa UDP 9022 y 9023. Cárguelo solo cuando lo vaya a usar y reinicie la PS5 después. Cada conexión nueva muestra la notificación \"MemDBG ... connected\". No probado por nosotros en la PS5 Pro 12.00."},
   4, 0, 0, 1, NULL, NULL, SONDA_MEMDBG,
   "seregonwar/MemDBG", "MemDBG-ps5.elf", 0, 8ULL * 1024 * 1024, 0, NULL},
  /* 0.9.59: CoreDump Dumper (jamesst20/PS5-CoreDump-Dumper, MIT; o mesmo autor das correcoes do ampr-emu-ng). Fica
     rodando: vigia /devlog/system/sce_coredumps.0 e copia cada travamento de jogo para /data/ps5-coredump-dumper/
     <TitleID>_<hora>/ antes de o PS5 apagar (src/config.h e README do autor). Sem porta de rede. Carregar de novo troca
     a copia que esta rodando (SIGKILL na antiga, src/instance.c). Rodando agora: o nome do processo coredump-dump.elf
     (thr_set_name). Release normal com digest no GitHub (coredump-dumper-v1.00.elf, 194.336 B). */
  {"coredump", "CoreDump Dumper", "jamesst20", "MIT",
   "https://github.com/jamesst20/PS5-CoreDump-Dumper", "", "", "coredump.elf", "", 0ULL,
   "",
   {"Guarda o CoreDump quando um jogo trava: o PS5 cria o arquivo e apaga em poucos segundos, e ele copia antes para /data/ps5-coredump-dumper (dump, captura de tela, vídeo curto e o log do kernel). Ative antes de abrir o jogo. Os dumps guardados aparecem aqui embaixo, com Enviar ao Claude e Apagar.",
    "Keeps the CoreDump when a game crashes: the PS5 creates the file and deletes it within seconds, and it copies it first to /data/ps5-coredump-dumper (dump, screenshot, short video and the kernel log). Activate it before opening the game. The saved dumps show up below, with Send to Claude and Delete.",
    "Guarda el CoreDump cuando un juego se cuelga: la PS5 crea el archivo y lo borra en pocos segundos, y él lo copia antes a /data/ps5-coredump-dumper (dump, captura de pantalla, vídeo corto y el log del kernel). Actívelo antes de abrir el juego. Los dumps guardados aparecen aquí abajo, con Enviar a Claude y Borrar."},
   {"Reinicie o PS5 (ele fica rodando até reiniciar). Os dumps guardados ficam em /data/ps5-coredump-dumper até você apagar.",
    "Restart the PS5 (it keeps running until a restart). The saved dumps stay in /data/ps5-coredump-dumper until you delete them.",
    "Reinicie la PS5 (sigue ejecutándose hasta reiniciar). Los dumps guardados quedan en /data/ps5-coredump-dumper hasta que los borre."},
   {"Cada dump pode ter de dezenas de MB a alguns GB no SSD interno: apague depois de enviar. O dump é a memória do jogo e pode ter dados da sua conta; ele vai só para o repositório privado de diagnósticos e o Claude confere antes de repassar a alguém. Não testado por nós no PS5 Pro 12.00.",
    "Each dump can take from tens of MB to a few GB on the internal SSD: delete it after sending. The dump is the game memory and may contain data from your account; it goes only to the private diagnostics repository and Claude checks it before passing it on to anyone. Not tested by us on the PS5 Pro 12.00.",
    "Cada dump puede ocupar de decenas de MB a algunos GB en el SSD interno: bórrelo después de enviarlo. El dump es la memoria del juego y puede tener datos de su cuenta; va solo al repositorio privado de diagnósticos y Claude lo revisa antes de pasarlo a nadie. No probado por nosotros en la PS5 Pro 12.00."},
   4, 0, 0, 0, NULL, NULL, SONDA_COREDUMP,
   "jamesst20/PS5-CoreDump-Dumper", "coredump-dumper-v*.elf", 0, 4ULL * 1024 * 1024, 0, NULL},
  /* 0.9.66: nanoDNS (drakmor/nanoDNS, GPL-3; o mesmo autor do ShadowMount+). Servidor DNS no proprio PS5 (porta 53 em
     127.0.0.1): bloqueia a Sony pelas regras de /data/nanodns/nanodns.ini e repassa o resto aos DNS publicos do arquivo.
     So vale com o DNS do console em 127.0.0.1 (primario e secundario). Le o .ini so ao subir; mandar de novo encerra a
     copia que esta rodando (terminate_existing_instances, SIGKILL) e rele o arquivo: nao e "uma_vez". Rodando agora: o
     nome do processo nanodns.elf (thr_set_name). Release normal com digest (nanodns.elf, 132.352 B na 0.4). O glibren
     edita o .ini pela pagina Payloads (src/nanodns.c). */
  {"nanodns", "nanoDNS", "drakmor", "GPL-3.0",
   "https://github.com/drakmor/nanoDNS", "", "", "nanodns.elf", "", 0ULL,
   "",
   {"Servidor DNS no próprio PS5: bloqueia os endereços da Sony pelas regras do arquivo /data/nanodns/nanodns.ini e manda o resto para os DNS públicos escolhidos lá. Só funciona com o DNS do PS5 (primário e secundário) em 127.0.0.1. Edite o arquivo aqui embaixo; ele só vale depois de ativar o nanoDNS de novo.",
    "DNS server on the PS5 itself: blocks Sony addresses with the rules in /data/nanodns/nanodns.ini and sends the rest to the public DNS servers chosen there. It only works with the PS5 DNS (primary and secondary) set to 127.0.0.1. Edit the file below; it only takes effect after activating nanoDNS again.",
    "Servidor DNS en la propia PS5: bloquea las direcciones de Sony con las reglas del archivo /data/nanodns/nanodns.ini y envía el resto a los DNS públicos elegidos allí. Solo funciona con el DNS de la PS5 (primario y secundario) en 127.0.0.1. Edite el archivo aquí abajo; solo vale después de activar nanoDNS de nuevo."},
   {"Volte o DNS do PS5 para o que você usava antes (Configurações > Rede) e reinicie o PS5. Para apagar tudo, apague a pasta /data/nanodns.",
    "Set the PS5 DNS back to what you used before (Settings > Network) and restart the PS5. To delete everything, delete the /data/nanodns folder.",
    "Vuelva a poner el DNS de la PS5 que usaba antes (Ajustes > Red) y reinicie la PS5. Para borrar todo, borre la carpeta /data/nanodns."},
   {"Com o DNS do PS5 em 127.0.0.1, sem o nanoDNS rodando o PS5 fica sem internet (é a falha segura: nada da Sony responde). Confira se o seu jailbreak não depende do DNS que você usa hoje antes de trocar. Um arquivo sem a seção [overrides] não bloqueia nada da Sony. Não testado por nós no PS5 Pro 12.00.",
    "With the PS5 DNS on 127.0.0.1, without nanoDNS running the PS5 has no internet (the safe failure: nothing from Sony answers). Check that your jailbreak does not depend on the DNS you use today before switching. A file without the [overrides] section blocks nothing from Sony. Not tested by us on the PS5 Pro 12.00.",
    "Con el DNS de la PS5 en 127.0.0.1, sin nanoDNS en ejecución la PS5 queda sin internet (es el fallo seguro: nada de Sony responde). Compruebe que su jailbreak no depende del DNS que usa hoy antes de cambiar. Un archivo sin la sección [overrides] no bloquea nada de Sony. No probado por nosotros en la PS5 Pro 12.00."},
   4, 0, 0, 0, NULL, NULL, SONDA_NANODNS,
   "drakmor/nanoDNS", "nanodns.elf", 0, 4ULL * 1024 * 1024, 0, NULL},
  /* 0.9.72: Disk Space Analyzer (igorwojda/ps5-disk-space-analyzer, GPL-3.0; pedido do dono em 27/11). Mostra o espaco
     por pasta/jogo/arquivo (interno, M.2, USB) na web, porta 8833 (FindFreePort: a seguinte livre se ocupada); cria o
     atalho DSAN00002 na aba Midia (/user/app, sceAppInstUtil, como o ps5-web-file-manager). Apagar desinstala pelo
     sistema e atualiza o app.db. A chave "Full screen" dele embute o ps5-web-browser-fullscreen (mexe no navegador):
     desligada por padrao. Fica rodando; mandar de novo encerra a copia antiga (SIGKILL, src/main.cpp): nao e "uma_vez".
     Rodando agora: o nome do processo disk-space-analyzer.elf (thr_set_name). Release normal com digest
     (disk-space-analyzer-v1.0.0-beta4.elf, 1.837.320 B, 27/11). */
  {"disk-space-analyzer", "Disk Space Analyzer", "igorwojda", "GPL-3.0",
   "https://github.com/igorwojda/ps5-disk-space-analyzer", "", "", "disk-space-analyzer.elf", "", 0ULL,
   "",
   {"Mostra para onde foi o espaço dos discos (interno, M.2 e USB): pastas por tamanho, o espaço real de cada jogo (jogo, atualização, DLC, saves, capturas) e os maiores arquivos. Abre pelo atalho na aba Mídia ou em http://IP-DO-PS5:8833 no celular ou PC; também gera um relatório em HTML.",
    "Shows where the drive space went (internal, M.2 and USB): folders by size, each game's real size (game, update, DLC, saves, captures) and the biggest files. Opens from the shortcut in the Media tab or at http://PS5-IP:8833 on the phone or PC; it also makes an HTML report.",
    "Muestra adónde fue el espacio de los discos (interno, M.2 y USB): carpetas por tamaño, el espacio real de cada juego (juego, actualización, DLC, partidas, capturas) y los archivos más grandes. Se abre desde el acceso en la pestaña Multimedia o en http://IP-DE-LA-PS5:8833 en el móvil o PC; también genera un informe en HTML."},
   {"Reinicie o PS5 (ele fica rodando até reiniciar). O atalho \"Disk Space Analyzer\" da aba Mídia pode ser apagado pela tela inicial.",
    "Restart the PS5 (it keeps running until a restart). The \"Disk Space Analyzer\" shortcut in the Media tab can be deleted from the home screen.",
    "Reinicie la PS5 (sigue ejecutándose hasta reiniciar). El acceso \"Disk Space Analyzer\" de la pestaña Multimedia se puede borrar desde la pantalla de inicio."},
   {"Beta. Use para olhar: apagar desinstala jogos pelo sistema e mexe na lista de jogos do PS5 (app.db), sem volta. Não use enquanto a Fila PKG ou uma conversão estiver rodando. A porta 8833 fica aberta na rede, sem senha (quem estiver na rede também pode apagar). Deixe a chave \"Full screen\" dele desligada se usar a Tela cheia ou a PrefBar do glibren. Não testado por nós no PS5 Pro 12.00.",
    "Beta. Use it to look: deleting uninstalls games through the system and changes the PS5 game list (app.db), with no way back. Do not use it while the PKG Queue or a conversion is running. Port 8833 is open on the network, with no password (anyone on the network can also delete). Keep its \"Full screen\" switch off if you use glibren's Full screen or PrefBar. Not tested by us on the PS5 Pro 12.00.",
    "Beta. Úselo para mirar: borrar desinstala juegos por el sistema y cambia la lista de juegos de la PS5 (app.db), sin vuelta atrás. No lo use mientras la Cola PKG o una conversión esté en marcha. El puerto 8833 queda abierto en la red, sin contraseña (cualquiera en la red también puede borrar). Deje su interruptor \"Full screen\" apagado si usa la Pantalla completa o la PrefBar de glibren. No probado por nosotros en la PS5 Pro 12.00."},
   4, 0, 0, 0, NULL, NULL, SONDA_DISCO,
   "igorwojda/ps5-disk-space-analyzer", "disk-space-analyzer-v*.elf", 0, 8ULL * 1024 * 1024, 0, NULL},
  /* 0.9.41: kstuff do proprio usuario (ex.: Kstuff-NG_v1.00.elf; sem repositorio: o glibren nao busca a origem). So
     "Instalar de arquivo" (nome com "kstuff"); SHA-256 = o do arquivo copiado (.info). Rodando agora = a mesma
     pergunta que o proprio kstuff faz antes de subir ("ps5-kstuff is already loaded", ps5-kstuff/main.c do
     kstuff-lite): getppid com 0xffffffff nos 32 bits altos de rax; com o kstuff no kernel volta 0 (uelf/kekcall.c),
     sem ele volta o pid do pai. Outra resposta = "desconhecido" (nunca carrega sozinho). */
  {"kstuff", "kstuff (arquivo seu)", "—", "—", "", "", "", "kstuff-PristMC.elf", "", 0ULL,
   "",
   {"O kstuff que você usa (por exemplo Kstuff-NG_v1.00.elf), copiado de um disco do PS5 para o glibren. Mostra o nome do arquivo, o tamanho e o SHA-256; não tem versão do GitHub nem atualização automática.",
    "The kstuff you use (for example Kstuff-NG_v1.00.elf), copied from a PS5 drive into glibren. Shows the file name, size and SHA-256; no GitHub version and no automatic update.",
    "El kstuff que usted usa (por ejemplo Kstuff-NG_v1.00.elf), copiado de un disco de la PS5 a glibren. Muestra el nombre del archivo, el tamaño y el SHA-256; sin versión de GitHub ni actualización automática."},
   {"Reinicie o PS5 (o kstuff fica no kernel até desligar).",
    "Restart the PS5 (kstuff stays in the kernel until it is turned off).",
    "Reinicie la PS5 (kstuff queda en el kernel hasta apagarla)."},
   {"kstuff mexe no kernel; use só um arquivo em que você confia; o glibren não verifica a origem. Carregar duas vezes pode travar o PS5: o glibren só carrega sozinho quando tem certeza de que ele não está ativo, e nunca duas vezes no mesmo boot.",
    "kstuff changes the kernel; use only a file you trust; glibren does not check where it came from. Loading it twice can freeze the PS5: glibren only loads it on its own when it is sure it is not active, and never twice in the same boot.",
    "kstuff modifica el kernel; use solo un archivo en el que confíe; glibren no verifica su origen. Cargarlo dos veces puede colgar la PS5: glibren solo lo carga por su cuenta cuando está seguro de que no está activo, y nunca dos veces en el mismo arranque."},
   10, 0, 0, 1, NULL, NULL, SONDA_KSTUFF,
   NULL, NULL, 0, 16ULL * 1024 * 1024, 0, NULL, 1, "kstuff"},
  /* 0.9.64: teste-pad, nosso payload de teste do controle virtual (ps5/teste-controle/teste-pad, GPL-3.0-or-later; fonte em
     proprios/teste-pad/ com os creditos: Darkatek7/ProsperoSunshine e Gl0ttis/ps5-mcp, GPL-3). Vem DENTRO do glibren
     (embutido): "Baixar" so grava a copia em /data/glibren/payloads, conferida pelo SHA-256 fixo daqui. Roda ~7 s e sai
     sozinho; o log /data/teste-pad.log vai no diagnostico. Regra do dono (23/11): todo payload novo do processo entra aqui.
     0.9.65: 1.3 (liga o pad ao usuario pela libSceMbus, X escolhe o usuario na janela do PS5, DIREITA 3x): OK no 12.00. */
  {"teste-pad", "teste-pad (controle virtual)", "PristMC", "GPL-3.0-or-later", "", "1.3", "", "teste-pad.elf",
   "ed41532b846855adcfed25b4954f35fe98f557194d691d23d4ae17c7a3d6d6b5", 112256ULL,
   "",
   {"Nosso payload de teste: cria um DualSense virtual só com /dev/hid (sem ptrace, sem injeção), liga ao seu usuário, aperta X (escolhe o usuário na janela que o PS5 abre) e DIREITA 3 vezes na tela inicial, e apaga o controle. Mostra se o método limpo funciona no seu firmware. Deixe a tela inicial aberta, sem jogo; se a janela de usuário não abrir, o X abre o jogo selecionado. O log /data/teste-pad.log vai no diagnóstico.",
    "Our test payload: creates a virtual DualSense using only /dev/hid (no ptrace, no injection), binds it to your user, presses X (picks the user in the window the PS5 opens) and RIGHT 3 times on the home screen, and removes the controller. Shows whether the clean method works on your firmware. Leave the home screen open, with no game; if the user window does not open, X starts the selected game. The /data/teste-pad.log log goes with the diagnostics.",
    "Nuestro payload de prueba: crea un DualSense virtual solo con /dev/hid (sin ptrace, sin inyección), lo vincula a su usuario, pulsa X (elige el usuario en la ventana que abre la PS5) y DERECHA 3 veces en la pantalla de inicio, y borra el mando. Muestra si el método limpio funciona en su firmware. Deje la pantalla de inicio abierta, sin juego; si la ventana de usuario no se abre, X inicia el juego seleccionado. El log /data/teste-pad.log va con el diagnóstico."},
   {"Nada a desfazer: ele apaga o controle virtual e sai sozinho em ~12 s.",
    "Nothing to undo: it removes the virtual controller and exits on its own in ~12 s.",
    "Nada que deshacer: borra el mando virtual y sale solo en ~12 s."},
   {"Teste: não testado no PS5 Pro 12.00. Pode aparecer a pergunta do controle; a seleção da tela inicial pode andar duas vezes para a direita.",
    "Test: not tested on the PS5 Pro 12.00. The controller question may show up; the home screen selection may move right twice.",
    "Prueba: no probado en la PS5 Pro 12.00. Puede aparecer la pregunta del mando; la selección de la pantalla de inicio puede moverse dos veces a la derecha."},
   15, 0, 0, 0, NULL, NULL, SONDA_NENHUMA,
   NULL, NULL, 0, 0, 0, NULL, 0, NULL, 1},
  /* 0.9.64: websrv (ps5-payload-dev/websrv, John Tornblom, GPL-3.0-or-later): servidor web de homebrew na porta 8080. O dono
     pediu na pagina Payloads para os testes do Remote Play sem PSN. Acompanhado pelo GitHub com digest; a v0.35 (a mais
     nova, 10/10/2026) e pre-release, por isso gh_pre = 1. Fica rodando (laco websrv_listen + mDNS); carregar de novo: a
     segunda copia nao consegue a porta e fica tentando a cada 3 s (src/main.c do autor). Sem sonda de "rodando agora". */
  {"websrv", "websrv", "John Törnblom (ps5-payload-dev)", "GPL-3.0-or-later",
   "https://github.com/ps5-payload-dev/websrv", "", "", "websrv.elf", "", 0ULL,
   "",
   {"Servidor web de homebrew do ps5-payload-dev na porta 8080 (abra http://IP-DO-PS5:8080 no celular ou PC). O dono quer usar nos testes do Remote Play sem PSN.",
    "ps5-payload-dev homebrew web server on port 8080 (open http://PS5-IP:8080 on the phone or PC). The owner wants it for the Remote Play without PSN tests.",
    "Servidor web de homebrew de ps5-payload-dev en el puerto 8080 (abra http://IP-DE-LA-PS5:8080 en el móvil o PC). El dueño lo quiere para las pruebas de Remote Play sin PSN."},
   {"Reinicie o PS5 (ele fica rodando até reiniciar).",
    "Restart the PS5 (it keeps running until a restart).",
    "Reinicie la PS5 (sigue ejecutándose hasta reiniciar)."},
   {"Abre a porta 8080 na rede, sem senha. A versão mais nova (v0.35) é pre-release do autor. Não testado por nós no PS5 Pro 12.00.",
    "Opens port 8080 on the network, with no password. The newest version (v0.35) is an author pre-release. Not tested by us on the PS5 Pro 12.00.",
    "Abre el puerto 8080 en la red, sin contraseña. La versión más nueva (v0.35) es pre-release del autor. No probado por nosotros en la PS5 Pro 12.00."},
   4, 0, 0, 0, NULL, NULL, SONDA_NENHUMA,
   "ps5-payload-dev/websrv", "websrv-ps5.elf", 1, 8ULL * 1024 * 1024, 0, NULL},
};

/* 0.9.64: o teste-pad vem dentro do glibren (proprios/teste-pad/teste-pad.elf, conferido pelo SHA-256 fixo do item) */
__asm__(".section .rodata\n.global glr_teste_pad_elf\n.global glr_teste_pad_elf_tam\n.align 16\nglr_teste_pad_elf:\n"
        ".incbin \"proprios/teste-pad/teste-pad.elf\"\nglr_teste_pad_elf_fim:\n.align 8\nglr_teste_pad_elf_tam:\n"
        ".quad glr_teste_pad_elf_fim - glr_teste_pad_elf\n.previous\n");
extern const uint8_t glr_teste_pad_elf[];
extern const uint64_t glr_teste_pad_elf_tam;
#define N_ITENS ((int)(sizeof ITENS / sizeof ITENS[0]))

typedef struct {
  char fase[16];        /* "", baixando, conferindo, home, aplicando, reabrindo */
  char erro[300];
  char saida[600];      /* resumo da saida do payload (Result/Notification) */
  time_t ativado_em;
  unsigned long long baixados, total;   /* total: tamanho do download em andamento (0.9.33) */
  /* cache do SHA-256 do arquivo guardado (refeito quando tamanho/data mudam) */
  long long cache_tam, cache_mtime;
  int cache_ok;
  char cache_sha[65];   /* 0.9.33: o SHA-256 esperado quando o cache foi feito (muda ao atualizar/voltar) */
  /* 0.9.33: ultima release no GitHub (itens acompanhados) */
  gh_release_t disp;
  int disp_ok;          /* 1 = disp valida (asset unico com digest) */
  int gh_res, gh_http;  /* resultado da ultima resposta do GitHub (GH_*; 0.9.39: so as que valem o cache) e o HTTP da ultima tentativa */
  int gh_falha;         /* 0.9.39: erro da ultima tentativa que nao trouxe resposta (rede/http/limite/json); 0 = a ultima respondeu */
  time_t consultado;    /* hora da ultima consulta que respondeu (cache de 1 h) */
  time_t tentou;        /* hora da ultima tentativa (botao: no maximo 1 por minuto) */
  int consultando;
  /* 0.9.33: rodando agora? (cache de 8 s) */
  time_t sonda_em;
  int rodando;          /* 1 sim, 0 nao */
  char rodando_versao[64];
  char rodando_obs[32]; /* kraken: "waiting" (ex.: "shadowmount") */
  unsigned rodando_nivel; /* 0.9.40: feature level do protocolo (MemDBG); 0 = nao se aplica */
  /* 0.9.41: carregar ao iniciar o glibren: "" (nada feito), "esperando", "carregado", "ja_rodando", "erro" + motivo */
  char auto_res[12];
  char auto_erro[300];
} estado_t;

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static estado_t g_est[N_ITENS];
static int g_ocupado;

/* ------------------------------------------------------------------ catalogo e pastas */

static const char *sha_item(const item_t *it) {
#ifndef __PROSPERO__
  if(!it->gh_repo && !it->embutido && getenv("GLR_TESTE_PAYLOAD_SHA")) return getenv("GLR_TESTE_PAYLOAD_SHA");
#endif
  return it->sha256;
}

static unsigned long long tam_item(const item_t *it) {
#ifndef __PROSPERO__
  if(!it->gh_repo && !it->embutido && getenv("GLR_TESTE_PAYLOAD_TAM")) return strtoull(getenv("GLR_TESTE_PAYLOAD_TAM"), NULL, 10);
#endif
  return it->tamanho;
}

static void caminho(const item_t *it, const char *ext, char *saida, size_t tam);

/* ------------------------------------------------------------------ 0.9.33: versao instalada (itens do GitHub) */

typedef struct {
  char versao[64], sha256[65], asset[128];
  unsigned long long tamanho;
  char origem[300];   /* 0.9.41: instalado de arquivo: de onde veio (ex.: /data/pldmgr/payloads/Kstuff-NG_v1.00.elf) */
} info_t;

/* <id>.info ou <id>.anterior.info: "versao=..", "sha256=..", "tamanho=..", "asset=..". 0 = leu e e valido.
   Revisao 0.9.41: linha de ate 1 KB (a "origem=" de um arquivo do usuario tem ate 299 caracteres); uma linha maior que o
   buffer e descartada inteira (o resto dela nunca vira outra chave). */
static int info_ler(const item_t *it, int anterior, info_t *in) {
  char arq[600], linha_[1024];
  memset(in, 0, sizeof *in);
  caminho(it, anterior ? ".anterior.info" : ".info", arq, sizeof arq);
  FILE *f = fopen(arq, "r");
  if(!f) return -1;
  while(fgets(linha_, sizeof linha_, f)) {
    if(!strchr(linha_, '\n') && !feof(f)) {   /* linha comprida demais: pula ate o fim dela */
      int ch;
      while((ch = fgetc(f)) != EOF && ch != '\n') {}
      continue;
    }
    linha_[strcspn(linha_, "\r\n")] = 0;
    char *ig = strchr(linha_, '=');
    if(!ig) continue;
    *ig++ = 0;
    if(!strcmp(linha_, "versao")) snprintf(in->versao, sizeof in->versao, "%s", ig);
    else if(!strcmp(linha_, "sha256")) snprintf(in->sha256, sizeof in->sha256, "%s", ig);
    else if(!strcmp(linha_, "asset")) snprintf(in->asset, sizeof in->asset, "%s", ig);
    else if(!strcmp(linha_, "tamanho")) in->tamanho = strtoull(ig, NULL, 10);
    else if(!strcmp(linha_, "origem")) snprintf(in->origem, sizeof in->origem, "%s", ig);
  }
  fclose(f);
  return gh_nome_ok(in->versao, sizeof in->versao) && strlen(in->sha256) == 64 && strspn(in->sha256, "0123456789abcdef") == 64 &&
                 in->tamanho > 0 && in->tamanho <= it->gh_max
             ? 0
             : -1;
}

/* Grava em <destino>.tmp, fsync e rename (atomico). 0 = ok. */
static int info_gravar(const char *destino, const info_t *in) {
  char tmp[640];
  snprintf(tmp, sizeof tmp, "%s.tmp", destino);
  FILE *f = fopen(tmp, "w");
  if(!f) return -1;
  fprintf(f, "versao=%s\nsha256=%s\ntamanho=%llu\nasset=%s\n", in->versao, in->sha256, in->tamanho, in->asset);
  if(in->origem[0] && !strchr(in->origem, '\n')) fprintf(f, "origem=%s\n", in->origem);
  int ok = !fflush(f) && !fsync(fileno(f));
  if(fclose(f) || !ok || rename(tmp, destino)) {
    unlink(tmp);
    return -1;
  }
  return 0;
}

/* SHA-256 e tamanho esperados do arquivo guardado: fixos no catalogo, ou os da versao instalada (GitHub). 0 = sabe. */
static int esperado(const item_t *it, char *sha, unsigned long long *tam) {
  if(!it->gh_repo && !it->de_arquivo) {
    snprintf(sha, 65, "%s", sha_item(it));
    *tam = tam_item(it);
    return 0;
  }
  info_t in;
  if(info_ler(it, 0, &in)) return -1;
  snprintf(sha, 65, "%s", in.sha256);
  *tam = in.tamanho;
  return 0;
}

static void url_item(const item_t *it, char *saida, size_t tam) {
#ifndef __PROSPERO__
  const char *base = getenv("GLR_TESTE_PAYLOADS_URL");
  if(base && *base) {
    snprintf(saida, tam, "%s%s", base, it->arquivo);
    return;
  }
#endif
  snprintf(saida, tam, "%s", it->url);
}

static void pasta(char *saida, size_t tam) {
#ifdef __PROSPERO__
  snprintf(saida, tam, "/data/glibren/payloads");
#else
  snprintf(saida, tam, "%s/payloads", g_pasta_dados);   /* PC: dentro da pasta de dados do teste */
#endif
}

/* ext NULL = o .elf; ".ativado" = hora da ultima ativacao. 0.9.41: itens de arquivo guardam a anterior como
   "<nome fixo>.anterior" (shadowkraken-PristMC.elf.anterior, kstuff-PristMC.elf.anterior). */
static void caminho(const item_t *it, const char *ext, char *saida, size_t tam) {
  char p[512];
  pasta(p, sizeof p);
  if(ext && it->de_arquivo && !strcmp(ext, ".anterior.elf")) snprintf(saida, tam, "%s/%s.anterior", p, it->arquivo);
  else if(ext) snprintf(saida, tam, "%s/%s%s", p, it->id, ext);
  else snprintf(saida, tam, "%s/%s", p, it->arquivo);
}

static int achar(const char *id) {
  for(int i = 0; i < N_ITENS; i++)
    if(!strcmp(ITENS[i].id, id)) return i;
  return -1;
}

/* o .elf do item esta guardado na pasta do glibren */
static int instalado(const item_t *it) {
  char arq[600];
  struct stat st;
  caminho(it, NULL, arq, sizeof arq);
  return !lstat(arq, &st);
}

/* Segundos do relogio monotonico (prazos: nao pulam quando o relogio do PS5 e acertado) */
static long long mono_s(void) {
  struct timespec ts;
  if(clock_gettime(CLOCK_MONOTONIC, &ts)) return (long long)time(NULL);
  return (long long)ts.tv_sec;
}

/* "12.00" (vazio = nao sabe) */
static void firmware(char *saida, size_t tam) {
  saida[0] = 0;
#ifdef __PROSPERO__
  uint32_t v = kernel_get_fw_version();
  if(v) snprintf(saida, tam, "%x.%02x", (unsigned)((v >> 24) & 0xff), (unsigned)((v >> 16) & 0xff));
#else
  if(getenv("GLR_TESTE_FW")) snprintf(saida, tam, "%s", getenv("GLR_TESTE_FW"));
#endif
}

/* "4.03 12.02" contem "12.02"? (palavra inteira). 0.9.22: "12.xx" na lista vale para qualquer 12.yy. */
static int palavra(const char *lista, const char *fw) {
  size_t n = strlen(fw);
  for(const char *p = lista; n && (p = strstr(p, fw)); p++)
    if((p == lista || p[-1] == ' ') && (p[n] == 0 || p[n] == ' ')) return 1;
  return 0;
}

static int na_lista(const char *lista, const char *fw) {
  if(palavra(lista, fw)) return 1;
  char familia[16];
  const char *ponto = strchr(fw, '.');
  if(!ponto || ponto - fw > 3) return 0;
  snprintf(familia, sizeof familia, "%.*s.xx", (int)(ponto - fw), fw);
  return palavra(lista, familia);
}

/* Hora em que o PS5 ligou (os patches da interface valem ate reiniciar). 0.9.22: kern.boottime no PS5 (o mesmo do
   "Ligado ha" da Temperatura); reserva: relogio monotonico. */
static time_t ligou_em(void) {
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_BOOT")) return (time_t)atoll(getenv("GLR_TESTE_BOOT"));   /* 0.9.41: testes do marcador do kstuff */
#endif
#ifdef __PROSPERO__
  struct timeval boot;
  size_t tam = sizeof boot;
  if(!sysctlbyname("kern.boottime", &boot, &tam, NULL, 0) && boot.tv_sec > 0) return boot.tv_sec;
#endif
  struct timespec ts;
  if(clock_gettime(CLOCK_MONOTONIC, &ts)) return 0;
  return time(NULL) - ts.tv_sec;
}

/* 0.9.22: pid da SceShellUI (a interface do PS5). Os patches vivem na memoria dela: se ela reiniciar (pid novo), o
   patch acabou. 0 = nao sabe. PC: GLR_TESTE_SHELLUI_PID. */
static int pid_shellui(void) {
#ifdef __PROSPERO__
  int mib[3] = {CTL_KERN, KERN_PROC, KERN_PROC_PROC}, pid = 0;
  size_t tam = 0;
  if(sysctl(mib, 3, NULL, &tam, NULL, 0) || !tam) return 0;
  tam += 64 * 1024;
  uint8_t *b = malloc(tam);
  if(!b) return 0;
  if(!sysctl(mib, 3, b, &tam, NULL, 0)) {
    for(uint8_t *q = b; q + sizeof(int) <= b + tam;) {
      struct kinfo_proc *ki = (struct kinfo_proc *)q;
      if(ki->ki_structsize <= 0) break;
      if(!strcmp(ki->ki_comm, "SceShellUI")) {
        pid = ki->ki_pid;
        break;
      }
      q += ki->ki_structsize;
    }
  }
  free(b);
  return pid;
#else
  const char *v = getenv("GLR_TESTE_SHELLUI_PID");
  return v ? atoi(v) : 0;
#endif
}

/* ------------------------------------------------------------------ arquivo guardado */

/* Le o arquivo e confere tamanho e SHA-256. 1 = ok (b recebe o conteudo, se nao for NULL). */
static int arquivo_confere_em(const char *arq, const char *sha_esp, unsigned long long esperado, buf_t *b) {
  char hex[65];
  int fd = open(arq, O_RDONLY | O_NOFOLLOW);
  if(fd < 0) return 0;
  unsigned long long lidos = 0;
  sha256_t s;
  sha256_iniciar(&s);
  char bloco[64 * 1024];
  ssize_t r;
  int ok = 1;
  while(ok && (r = read(fd, bloco, sizeof bloco)) > 0) {
    lidos += (unsigned long long)r;
    if(lidos > esperado) ok = 0;
    else {
      sha256_atualizar(&s, bloco, (size_t)r);
      if(b) buf_add(b, bloco, (size_t)r);
    }
  }
  if(r < 0) ok = 0;
  close(fd);
  uint8_t resumo[32];
  sha256_final(&s, resumo);
  sha256_hex(resumo, hex);
  return ok && lidos == esperado && !strcmp(hex, sha_esp);
}

static int arquivo_confere(const item_t *it, buf_t *b) {
  char arq[600], sha[65];
  unsigned long long tam;
  if(esperado(it, sha, &tam)) return 0;
  caminho(it, NULL, arq, sizeof arq);
  return arquivo_confere_em(arq, sha, tam, b);
}

/* Pronto (guardado e conferido)? Usa o cache pelo tamanho/data do arquivo. Chamar sem a trava. */
static int pronto(int i) {
  char arq[600];
  struct stat st;
  caminho(&ITENS[i], NULL, arq, sizeof arq);
  if(lstat(arq, &st) || !S_ISREG(st.st_mode)) return 0;
  char sha[65];
  unsigned long long tam;
  if(esperado(&ITENS[i], sha, &tam)) return 0;
  pthread_mutex_lock(&g_trava);
  int sabe = g_est[i].cache_tam == (long long)st.st_size && g_est[i].cache_mtime == (long long)st.st_mtime && !strcmp(g_est[i].cache_sha, sha),
      ok = g_est[i].cache_ok;
  pthread_mutex_unlock(&g_trava);
  if(sabe) return ok;
  ok = arquivo_confere_em(arq, sha, tam, NULL);
  pthread_mutex_lock(&g_trava);
  g_est[i].cache_tam = (long long)st.st_size;
  g_est[i].cache_mtime = (long long)st.st_mtime;
  g_est[i].cache_ok = ok;
  snprintf(g_est[i].cache_sha, sizeof g_est[i].cache_sha, "%s", sha);
  pthread_mutex_unlock(&g_trava);
  return ok;
}

/* ------------------------------------------------------------------ estado */

static void fase(int i, const char *f) {
  pthread_mutex_lock(&g_trava);
  snprintf(g_est[i].fase, sizeof g_est[i].fase, "%s", f);
  pthread_mutex_unlock(&g_trava);
}

static void falhou(int i, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
static void falhou(int i, const char *fmt, ...) {
  char msg[300];
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(msg, sizeof msg, fmt, ap);
  va_end(ap);
  pthread_mutex_lock(&g_trava);
  snprintf(g_est[i].erro, sizeof g_est[i].erro, "%s", msg);
  g_est[i].fase[0] = 0;
  pthread_mutex_unlock(&g_trava);
  diario("payloads: %s: erro: %s", ITENS[i].id, msg);
}

/* Hora da ativacao nesta sessao do PS5, ou 0. O arquivo .ativado guarda "hora pid_da_ShellUI" (0.9.22; antes so a
   hora; o arquivo vale mais que a memoria: e o que sobra depois de reabrir o glibren). Ativado antes de o PS5 ligar,
   ou com outra ShellUI (ela reiniciou), ja foi desfeito. */
static time_t ativado_em(int i) {
  char arq[600];
  long long v = 0;
  int pid = 0;
  pthread_mutex_lock(&g_trava);
  time_t mem = g_est[i].ativado_em;
  pthread_mutex_unlock(&g_trava);
  caminho(&ITENS[i], ".ativado", arq, sizeof arq);
  FILE *f = fopen(arq, "r");
  if(f) {
    int n = fscanf(f, "%lld %d", &v, &pid);
    if(n < 1) v = 0;
    if(n < 2) pid = 0;
    fclose(f);
  } else v = (long long)mem;   /* arquivo nao gravou: vale o da memoria */
  time_t t = (time_t)v;
  if(t <= ligou_em() + 5) return 0;   /* antes de o PS5 ligar: ja foi desfeito */
  int agora = pid ? pid_shellui() : 0;
  if(pid && agora && agora != pid) return 0;   /* a interface do PS5 reiniciou: o patch foi junto */
  return t;
}

/* ------------------------------------------------------------------ 0.9.33: esta rodando agora? */

#define SONDA_CACHE_S 8

/* PC: GLR_TESTE_SONDA_S (0 = sem cache) para os testes nao esperarem */
static int sonda_cache_s(void) {
#ifndef __PROSPERO__
  const char *v = getenv("GLR_TESTE_SONDA_S");
  if(v && *v) return atoi(v);
#endif
  return SONDA_CACHE_S;
}

/* GET em 127.0.0.1:porta (ate max bytes, espera_s). Status HTTP ou -1; corpo (sem cabecalho, terminado em \0) em resp. */
static int http_local(int porta, const char *rota, buf_t *resp, size_t max, int espera_s) {
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if(fd < 0) return -1;
  struct timeval t = {.tv_sec = espera_s};
  setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &t, sizeof t);
  setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &t, sizeof t);
#ifdef SO_NOSIGPIPE
  int sim = 1;
  setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &sim, sizeof sim);
#endif
  struct sockaddr_in end = {.sin_family = AF_INET, .sin_port = htons((uint16_t)porta)};
  end.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  char ped[256];
  int n = snprintf(ped, sizeof ped, "GET %s HTTP/1.1\r\nHost: 127.0.0.1:%d\r\nConnection: close\r\n\r\n", rota, porta);
  buf_t tudo = {0};
  int ok = !connect(fd, (struct sockaddr *)&end, sizeof end) && send(fd, ped, (size_t)n, SEM_SINAL) == n;
  time_t limite = time(NULL) + espera_s + 1;
  char bloco[16384];
  while(ok && time(NULL) <= limite) {
    ssize_t r = recv(fd, bloco, sizeof bloco, 0);
    if(r <= 0) break;
    if(tudo.n + (size_t)r > max) break;
    buf_add(&tudo, bloco, (size_t)r);
  }
  close(fd);
  int st = -1;
  if(ok && tudo.n > 12 && !strncmp(tudo.d, "HTTP/1.", 7)) {
    buf_add(&tudo, "", 1);
    st = atoi(tudo.d + 9);
    const char *c = strstr(tudo.d, "\r\n\r\n");
    if(c) buf_str(resp, c + 4);
    buf_add(resp, "", 1);
  }
  buf_free(&tudo);
  return st;
}

/* valor "x" da ULTIMA ocorrencia de "chave":"x" (so letras, numeros e . - + _) */
static void valor_final(const char *json, const char *chave, char *saida, size_t tam) {
  char padrao[48];
  snprintf(padrao, sizeof padrao, "\"%s\":\"", chave);
  const char *ult = NULL;
  for(const char *p = json; (p = strstr(p, padrao)); p++) ult = p;
  size_t k = 0;
  if(ult)
    for(const char *c = ult + strlen(padrao); *c && *c != '"' && k + 1 < tam; c++)
      if(strchr("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.-+_", *c)) saida[k++] = *c;
  saida[k] = 0;
}

static int porta_bluev(void) {
#ifndef __PROSPERO__
  const char *v = getenv("GLR_TESTE_BLUEV_PORTA");
  if(v && atoi(v) > 0) return atoi(v);
#endif
  return PORTA_BLUEV;
}

static int porta_zhithemes(void) {
#ifndef __PROSPERO__
  const char *v = getenv("GLR_TESTE_ZHITHEMES_PORTA");
  if(v && atoi(v) > 0) return atoi(v);
#endif
  return PORTA_ZHITHEMES;
}

static int porta_kraken(void) {
#ifndef __PROSPERO__
  const char *v = getenv("GLR_TESTE_KRAKEN_PORTA");
  if(v && atoi(v) > 0) return atoi(v);
#endif
  return PORTA_KRAKEN;
}

/* 0.9.43: a porta 8097 e do kraken-mount E do TITAN CORE (devchmod/TITAN-CORE, GPL-3: derivado do kraken-mount, com
   o kstuff-lite 1.11 e o ShadowMount+ 1.7beta10 embutidos e ligados por ele mesmo). Os dois respondem GET /api/state
   com "version"; so o TITAN traz "services" com "kstuff_bundle" (src/stack.rs dele) e responde GET
   /api/installer/status (src/web.rs). Cache de SONDA_CACHE_S, compartilhado pela sonda do kraken-mount e pelo aviso. */
static struct {
  time_t em;
  int titan, kraken;
  char versao[64], obs[32];
} g_p8097;
static pthread_mutex_t g_trava_8097 = PTHREAD_MUTEX_INITIALIZER;

static void p8097_estado(int *titan, int *kraken, char *versao, size_t tam_v, char *obs, size_t tam_o) {
  pthread_mutex_lock(&g_trava_8097);
  time_t agora = time(NULL);
  if(!g_p8097.em || agora - g_p8097.em >= sonda_cache_s() || agora < g_p8097.em) {
    buf_t r = {0};
    int st = http_local(porta_kraken(), "/api/state", &r, 4 * 1024 * 1024, 2), t = 0;
    memset(&g_p8097, 0, sizeof g_p8097);
    if(st == 200 && r.d) {
      t = strstr(r.d, "\"kstuff_bundle\"") != NULL;
      if(!t) {
        buf_t s = {0};
        t = http_local(porta_kraken(), "/api/installer/status", &s, 64 * 1024, 2) == 200 && s.d && s.d[0] == '{';
        buf_free(&s);
      }
      g_p8097.titan = t;
      g_p8097.kraken = !t;
      valor_final(r.d, "version", g_p8097.versao, sizeof g_p8097.versao);
      if(!t) valor_final(r.d, "waiting", g_p8097.obs, sizeof g_p8097.obs);
    }
    buf_free(&r);
    g_p8097.em = time(NULL);
  }
  if(titan) *titan = g_p8097.titan;
  if(kraken) *kraken = g_p8097.kraken;
  if(versao) snprintf(versao, tam_v, "%s", g_p8097.versao);
  if(obs) snprintf(obs, tam_o, "%s", g_p8097.obs);
  pthread_mutex_unlock(&g_trava_8097);
}

/* 1 = o TITAN CORE esta rodando (versao, se pedida); sem_cache = pergunta agora */
static int titan_rodando(char *versao, size_t tam, int sem_cache) {
  if(sem_cache) {
    pthread_mutex_lock(&g_trava_8097);
    g_p8097.em = 0;
    pthread_mutex_unlock(&g_trava_8097);
  }
  int t;
  p8097_estado(&t, NULL, versao, tam, NULL, 0);
  return t;
}

#define TITAN_MOTIVO "o TITAN CORE esta rodando: ele ja carrega o kstuff e o ShadowMount+ dele; tire-o do carregamento automatico e reinicie o PS5 antes"

/* 1 = este item nao pode subir junto com o TITAN CORE (montadores e kstuff) */
static int briga_com_titan(const item_t *it) {
  return it->sonda == SONDA_SHADOWKRAKEN || it->sonda == SONDA_KRAKEN || it->sonda == SONDA_KSTUFF;
}

/* ShadowMount+ / ShadowKraken (mesmo processo, mesma API): cache de SONDA_CACHE_S */
static struct {
  time_t em;
  int api, processo;
  char versao[64];
} g_smp;
static pthread_mutex_t g_trava_smp = PTHREAD_MUTEX_INITIALIZER;

static void smp_estado(int *api, int *processo, char *versao, size_t tam) {
  pthread_mutex_lock(&g_trava_smp);
  time_t agora = time(NULL);
  if(!g_smp.em || agora - g_smp.em >= sonda_cache_s() || agora < g_smp.em) {
    char v[64];
    int a = apps_smp_versao(v, sizeof v);
    g_smp.api = a;
    g_smp.processo = plataforma_processo_rodando(PROCESSO_SMP);
    snprintf(g_smp.versao, sizeof g_smp.versao, "%s", a ? v : "");
    g_smp.em = time(NULL);
  }
  *api = g_smp.api;
  *processo = g_smp.processo;
  snprintf(versao, tam, "%s", g_smp.versao);
  pthread_mutex_unlock(&g_trava_smp);
}

/* As versoes do ShadowKraken sao tags "1.00-Dev.N..." (git describe); as do ShadowMount+ nao tem "Dev". */
static int versao_shadowkraken(const char *v) {
  return strstr(v, "-Dev") != NULL;
}

static time_t ativado_em(int i);

/* ------------------------------------------------------------------ 0.9.41: kstuff ativo nesta sessao? */

#ifdef __PROSPERO__
/* glr_kekcall(alvo, nr): rax = nr e salta para alvo (o "mov r10, rcx; syscall; ...; ret" do getpid da libkernel, 7
   bytes depois do "mov rax, 0x14"): a mesma chamada que o kstuff usa (ps5-kstuff/main.c: dlsym(libkernel, "getpid") + 7).
   O ret de la volta para quem chamou glr_kekcall. */
__asm__(".text\n.p2align 4\nglr_kekcall:\n  mov %rsi, %rax\n  jmp *%rdi\n");
uint64_t glr_kekcall(void *alvo, uint64_t nr) __asm__("glr_kekcall");
#endif

/* Os 12 primeiros bytes do getpid da libkernel: "mov rax, 0x14; mov r10, rcx; syscall". O salto vai para o "mov r10,
   rcx" (+7); se o codigo no endereco nao for este, a sonda nao executa nada ("desconhecido"). */
static const unsigned char KSTUFF_GETPID[12] = {0x48, 0xc7, 0xc0, 0x14, 0x00, 0x00, 0x00, 0x49, 0x89, 0xca, 0x0f, 0x05};
static void *g_ks_alvo;   /* getpid + 7, so com os bytes conferidos (NULL = desconhecido) */
static pthread_once_t g_ks_uma_vez = PTHREAD_ONCE_INIT;

/* Uma vez por glibren (pthread_once: quem chega junto espera, ninguem ve a busca pela metade): acha o getpid da
   libkernel e confere os bytes dele lendo pelo kernel (kernel_proc_copyout do SDK, o mesmo da leitura das cheats: o
   codigo das bibliotecas e execute-only no PS5, uma leitura direta derrubaria o glibren). PC: GLR_TESTE_KSTUFF_BYTES =
   os 12 bytes em hexadecimal (sem a variavel = os esperados). */
static void kstuff_preparar(void) {
  unsigned char b[12];
  int achou = 0, leu = 0;
#ifdef __PROSPERO__
  static const char *const LIBS[] = {"libkernel_sys.sprx", "libkernel.sprx", NULL};
  pid_t eu = getpid();
  intptr_t a = 0;
  for(int k = 0; LIBS[k] && !a; k++) {
    uint32_t h = 0;
    if(kernel_dynlib_handle(eu, LIBS[k], &h) || !h) continue;
    a = kernel_dynlib_dlsym(eu, h, "getpid");
  }
  achou = a != 0;
  leu = achou && !kernel_proc_copyout(eu, a, b, sizeof b);
  if(leu && !memcmp(b, KSTUFF_GETPID, sizeof b)) g_ks_alvo = (void *)(a + 7);
#else
  const char *v = getenv("GLR_TESTE_KSTUFF_BYTES");
  memcpy(b, KSTUFF_GETPID, sizeof b);
  achou = leu = 1;
  if(v && *v) {
    memset(b, 0, sizeof b);
    for(size_t k = 0; k < sizeof b && v[2 * k] && v[2 * k + 1]; k++) {
      char h[3] = {v[2 * k], v[2 * k + 1], 0};
      b[k] = (unsigned char)strtoul(h, NULL, 16);
    }
  }
  if(!memcmp(b, KSTUFF_GETPID, sizeof b)) g_ks_alvo = (void *)KSTUFF_GETPID;   /* PC: so "pronta" */
#endif
  diario("kstuff: sonda %s", g_ks_alvo ? "pronta (getpid da libkernel + 7, bytes conferidos)"
                             : !achou ? "sem o getpid da libkernel: estado desconhecido"
                             : !leu  ? "nao leu os bytes do getpid: estado desconhecido (nada executado)"
                                     : "o getpid da libkernel nao tem os bytes esperados: estado desconhecido (nada executado)");
}

/* 1 = o kstuff responde (getppid com 0xffffffff nos 32 bits altos de rax volta 0: uelf/kekcall.c do kstuff-lite, o
   mesmo teste do "ps5-kstuff is already loaded"); 0 = nao (volta o pid do pai, como um getppid comum); -1 = nao deu
   para saber (outra resposta, getpid da libkernel nao achado ou com outros bytes). Nada e escrito: so uma chamada de
   sistema de leitura. Revisao 0.9.41: so executa se o kstuff estiver instalado no glibren (quem nao usa o kstuff pelo
   glibren nunca passa por aqui) e com os bytes do endereco conferidos.
   PC: GLR_TESTE_KSTUFF = arquivo com "ativo" ou "nao" (outro conteudo ou sem arquivo = desconhecido); cada execucao
   acrescenta uma linha em <GLR_TESTE_KSTUFF>.exec (os testes conferem quando NADA foi executado). */
static int kstuff_ativo(void) {
  int ks = -1;
  for(int k = 0; k < N_ITENS && ks < 0; k++)
    if(ITENS[k].sonda == SONDA_KSTUFF) ks = k;
  if(ks < 0 || !instalado(&ITENS[ks])) return -1;
  pthread_once(&g_ks_uma_vez, kstuff_preparar);
  if(!g_ks_alvo) return -1;
#ifdef __PROSPERO__
  pid_t pai = getppid();
  if(pai <= 0) return -1;
  uint64_t r = glr_kekcall(g_ks_alvo, 0xffffffff00000027ULL);
  if(r == 0) return 1;
  if(r == (uint64_t)pai) return 0;
  return -1;
#else
  const char *arq = getenv("GLR_TESTE_KSTUFF");
  char v[32] = "", ex[600];
  if(arq) {
    snprintf(ex, sizeof ex, "%s.exec", arq);
    FILE *e = fopen(ex, "a");
    if(e) {
      fputs("x\n", e);
      fclose(e);
    }
  }
  FILE *f = arq ? fopen(arq, "r") : NULL;
  if(f) {
    if(!fgets(v, sizeof v, f)) v[0] = 0;
    fclose(f);
  }
  v[strcspn(v, "\r\n")] = 0;
  return !strcmp(v, "ativo") ? 1 : !strcmp(v, "nao") ? 0 : -1;
#endif
}

/* Marcador do boot: o glibren mandou o kstuff ao elfldr neste boot. Nunca carrega de novo sozinho com o marcador
   valendo. Revisao 0.9.41: kstuff.boot = "v2 <id do boot> <kern.boottime> <tempo ligado>" e o mesmo boot e decidido
   sem depender so do relogio (que o PS5 acerta pela rede e que o repouso desloca):
     - tempo ligado (monotonico) menor que o da gravacao = outro boot;
     - id do boot = o endereco do kernel (KASLR: muda a cada boot e fica igual o boot inteiro, repouso inclusive); se os
       dois lados tem o id, vale ele;
     - sem o id: mesmo boot se o kern.boottime andou menos que o tempo ligado na gravacao (+5 s). Um boot novo comeca
       DEPOIS da gravacao, entao o boottime dele anda pelo menos esse tempo; um acerto de relogio menor nao confunde.
   Na duvida o resultado e "mesmo boot" (o lado seguro: nao carrega sozinho). O formato antigo (so o boottime) vale
   com a regra antiga (+-5 s). PC: GLR_TESTE_BOOT (boottime), GLR_TESTE_UPTIME e GLR_TESTE_BOOT_ID (hexadecimal). */
static void kstuff_marcador(char *saida, size_t tam) {
  char p[512];
  pasta(p, sizeof p);
  snprintf(saida, tam, "%s/kstuff.boot", p);
}

static long long ligado_ha(void) {
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_UPTIME")) return atoll(getenv("GLR_TESTE_UPTIME"));
#endif
  return mono_s();
}

static unsigned long long boot_id(void) {
#ifdef __PROSPERO__
  return (unsigned long long)KERNEL_ADDRESS_DATA_BASE;
#else
  const char *v = getenv("GLR_TESTE_BOOT_ID");
  return v && *v ? strtoull(v, NULL, 16) : 0;
#endif
}

static int kstuff_carregou_neste_boot(void) {
  char arq[600], v[128] = "";
  kstuff_marcador(arq, sizeof arq);
  FILE *f = fopen(arq, "r");
  if(!f) return 0;
  if(!fgets(v, sizeof v, f)) v[0] = 0;
  fclose(f);
  long long b1 = (long long)ligou_em(), u1 = ligado_ha(), b0 = 0, u0 = -1;
  unsigned long long id1 = boot_id(), id0 = 0;
  if(strncmp(v, "v2 ", 3)) {   /* formato antigo: so o boottime */
    b0 = atoll(v);
    return v[0] && b0 > 0 && b0 - b1 <= 5 && b1 - b0 <= 5;
  }
  if(sscanf(v + 3, "%llx %lld %lld", &id0, &b0, &u0) != 3 || b0 <= 0 || u0 < 0) return 0;
  if(u1 + 2 < u0) return 0;              /* o relogio monotonico recomecou: outro boot */
  if(id0 && id1) return id0 == id1;      /* o mesmo endereco do kernel = o mesmo boot */
  return b1 - b0 < u0 + 5;
}

static int kstuff_gravar_marcador(void) {
  char arq[600], tmp[620], p[512];
  pasta(p, sizeof p);
  mkdir_p(p);
  kstuff_marcador(arq, sizeof arq);
  snprintf(tmp, sizeof tmp, "%s.tmp", arq);
  FILE *f = fopen(tmp, "w");
  if(!f) return -1;
  fprintf(f, "v2 %llx %lld %lld\n", boot_id(), (long long)ligou_em(), ligado_ha());
  int ok = !fflush(f) && !fsync(fileno(f));
  if(fclose(f) || !ok || rename(tmp, arq)) {
    unlink(tmp);
    return -1;
  }
  diario("payloads: kstuff: marcador do boot gravado");
  return 0;
}

static void kstuff_apagar_marcador(void) {
  char arq[600];
  kstuff_marcador(arq, sizeof arq);
  if(!unlink(arq)) diario("payloads: kstuff: marcador do boot apagado (nada chegou ao elfldr)");
}

static void sondar(int i) {
  const item_t *it = &ITENS[i];
  pthread_mutex_lock(&g_trava);
  time_t em = g_est[i].sonda_em, agora = time(NULL);
  pthread_mutex_unlock(&g_trava);
  if(em && agora - em < sonda_cache_s() && agora >= em) return;
  int rodando = 0, sem_cache = 0;
  unsigned nivel = 0;
  char versao[64] = "", obs[32] = "";
  if(it->sonda == SONDA_MEMDBG) {   /* 0.9.40: HELLO na 9020 (cache proprio de 20 s, compartilhado com as cheats) */
    mdg_info_t mi;
    mdg_estado(&mi);
    rodando = mi.rodando;
    nivel = mi.rodando ? mi.nivel : 0;
    if(mi.rodando) snprintf(versao, sizeof versao, "%s", mi.versao);
  } else if(it->sonda == SONDA_KSTUFF) {   /* 0.9.41 */
    if(!instalado(it)) snprintf(obs, sizeof obs, "sem_arquivo");   /* quem nao usa o kstuff pelo glibren: nada executado */
    else {
      int k = kstuff_ativo();
      rodando = k == 1;
      if(k < 0) {
        snprintf(obs, sizeof obs, "desconhecido");
        sem_cache = 1;   /* "nao sei" nao fica guardado: a proxima pergunta sonda de novo */
      }
    }
  } else if(it->sonda == SONDA_DUMPFORGE) rodando = conversao_dumpforge_versao(versao, sizeof versao);
  else if(it->sonda == SONDA_COREDUMP) rodando = plataforma_processo_rodando(COREDUMP_PROCESSO);   /* 0.9.59 */
  else if(it->sonda == SONDA_NANODNS) rodando = plataforma_processo_rodando("nanodns.elf");   /* 0.9.66 */
  else if(it->sonda == SONDA_DISCO) rodando = plataforma_processo_rodando("disk-space-analyzer.elf");   /* 0.9.72 */
  else if(it->sonda == SONDA_BLUEV) {   /* 0.9.34: /api/status responde = rodando (nao traz a versao) */
    buf_t r = {0};
    int st = http_local(porta_bluev(), "/api/status", &r, 256 * 1024, 2);
    rodando = st == 200 && r.d && strstr(r.d, "\"state\"") != NULL;
    buf_free(&r);
  } else if(it->sonda == SONDA_ZHITHEMES) {
    /* 0.9.35: GET /version (texto, sem efeito colateral) = "zhithemes <versao> (build ...) ...". Um tema do OnionHEN
       responde "onionhen ...": nao conta. */
    buf_t r = {0};
    int st = http_local(porta_zhithemes(), "/version", &r, 4096, 2);
    if(st == 200 && r.d && !strncmp(r.d, "zhithemes ", 10)) {
      rodando = 1;
      size_t k = 0;
      for(const char *c = r.d + 10; *c && *c != ' ' && k + 1 < sizeof versao; c++)
        if(strchr("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.-+_", *c)) versao[k++] = *c;
      versao[k] = 0;
    }
    buf_free(&r);
  } else if(it->sonda == SONDA_KRAKEN) {   /* 0.9.43: o TITAN CORE (mesma porta) nao conta como kraken-mount */
    if(!em) titan_rodando(NULL, 0, 1);   /* sonda do item sem cache (rodando_agora): a da porta tambem */
    int kr;
    p8097_estado(NULL, &kr, versao, sizeof versao, obs, sizeof obs);
    rodando = kr;
    if(!kr) versao[0] = obs[0] = 0;
  } else if(it->sonda == SONDA_SHADOWKRAKEN) {
    int api, proc;
    char v[64];
    smp_estado(&api, &proc, v, sizeof v);
    if(api && versao_shadowkraken(v)) {
      rodando = 1;
      snprintf(versao, sizeof versao, "%s", v);
    } else if(!api && proc && ativado_em(i)) rodando = 1;   /* API desligada: vale o processo + ativado nesta sessao */
  }
  pthread_mutex_lock(&g_trava);
  g_est[i].sonda_em = sem_cache ? 0 : time(NULL);
  g_est[i].rodando = rodando;
  snprintf(g_est[i].rodando_versao, sizeof g_est[i].rodando_versao, "%s", versao);
  snprintf(g_est[i].rodando_obs, sizeof g_est[i].rodando_obs, "%s", obs);   /* 0.9.41: kstuff "desconhecido" sem rodando */
  g_est[i].rodando_nivel = nivel;
  pthread_mutex_unlock(&g_trava);
}

/* 1 = a versao rodando nao e a instalada ("v0.5.6" = "0.5.6"; "1.00-Dev.3" casa com "1.00-Dev.3-dirty", nao com "1.00-Dev.30") */
static int versao_diferente(const char *rodando, const char *instalada) {
  if(!rodando[0] || !instalada[0]) return 0;
  /* 0.9.40: nightly do MemDBG: tag "nightly-20261112-g6e31144", versao rodando "0.2.0-nightly.321.g6e31144" (o
     commit e o que vale) */
  const char *g = !strncmp(instalada, "nightly-", 8) ? strrchr(instalada, '-') : NULL;
  if(g && g[1] == 'g' && g[2]) return strstr(rodando, g + 1) == NULL;
  if(*rodando == 'v' || *rodando == 'V') rodando++;
  if(*instalada == 'v' || *instalada == 'V') instalada++;
  size_t n = strlen(instalada);
  if(strncmp(rodando, instalada, n)) return 1;
  char c = rodando[n];
  return c && ((c >= '0' && c <= '9') || c == '.');
}

/* 0.9.22: o item esta valendo nesta sessao (ativado pelo glibren ou, no PrefBar, rodando por outro caminho: os
   arquivos de estado dele mudaram depois que o PS5 ligou). 0.9.33: itens com sonda valem pelo que esta rodando. */
static int ativo_na_sessao(int i) {
  if(ITENS[i].sonda) {
    sondar(i);
    pthread_mutex_lock(&g_trava);
    int r = g_est[i].rodando;
    pthread_mutex_unlock(&g_trava);
    return r;
  }
  if(ativado_em(i)) return 1;
  return !strcmp(ITENS[i].id, "prefbar") && prefbar_rodou_desde((long long)ligou_em());
}

/* Outro item que mexe na ShellUI e esta ativo nesta sessao (indice) ou -1. */
static int conflito_com(int i) {
  if(!ITENS[i].shellui) return -1;
  for(int j = 0; j < N_ITENS; j++)
    if(j != i && ITENS[j].shellui && ativo_na_sessao(j)) return j;
  return -1;
}

/* 0.9.41: pode carregar ao iniciar o glibren? Nao: os que mexem na interface do PS5 (grupo "um por sessao": tela cheia,
   PrefBar, ZhiThemes) e os sem como saber se ja estao rodando (sem sonda: carregaria duas vezes). Sobram Dump Forge,
   BlueV, MemDBG, os montadores (kraken-mount e ShadowKraken, no maximo um) e o kstuff (regras proprias). */
static int autoload_pode(const item_t *it) {
  return !it->shellui && !it->navegador && it->sonda != SONDA_NENHUMA;
}

/* ------------------------------------------------------------------ 0.9.33: GitHub (ultima release) */

#define GH_CACHE_S 3600     /* abrir a pagina: pergunta de novo so depois de 1 h */
#define GH_BOTAO_S 60       /* botao "Procurar atualizacoes": no maximo uma vez por minuto por item */
#define GH_CACHE_SUMIU_S (24 * 3600)   /* 0.9.34: repositorio 404 (removido/privado): abrir a pagina so pergunta 1x por dia */

/* PC: GLR_TESTE_GH_CACHE_S troca o cache de 1 h e o limite do botao (o de 24 h do 404 fica) */
static int gh_cache_s(int botao) {
#ifndef __PROSPERO__
  const char *t = getenv("GLR_TESTE_GH_CACHE_S");
  if(t && *t) return atoi(t);
#endif
  return botao ? GH_BOTAO_S : GH_CACHE_S;
}

/* 0.9.34: repositorio removido do GitHub (no PC, GLR_TESTE_SEM_REMOVIDOS=1 ignora, para os testes instalarem antes) */
static int removido(const item_t *it) {
#ifndef __PROSPERO__
  const char *t = getenv("GLR_TESTE_SEM_REMOVIDOS");
  if(t && *t == '1') return 0;
#endif
  return it->removido_em != NULL;
}

/* Quanto vale a ultima resposta do GitHub (404 vale um dia) */
static int cache_item(const estado_t *e) {
  return e->gh_res == GH_REPO_SUMIU ? GH_CACHE_SUMIU_S : gh_cache_s(0);
}

static int g_procurando;

/* Pergunta ao GitHub (bloqueia; fora da trava). */
static void consultar(int i) {
  const item_t *it = &ITENS[i];
  gh_release_t r;
  int http = -1;
  int res = gh_consultar(it->gh_repo, it->gh_pre, it->gh_padrao, &r, &http);
  time_t agora = time(NULL);
  pthread_mutex_lock(&g_trava);
  estado_t *e = &g_est[i];
  e->gh_http = http;
  e->tentou = agora;
  if(res == GH_OK || res == GH_SEM_ASSET || res == GH_VARIOS_ASSETS || res == GH_SEM_RELEASE || res == GH_REPO_SUMIU) {
    e->gh_res = res;
    e->gh_falha = 0;
    e->consultado = agora;   /* resposta definitiva do GitHub: vale o cache */
    e->disp = r;
    e->disp_ok = res == GH_OK && r.sha256[0] && r.tamanho > 0 && r.tamanho <= it->gh_max;
  } else e->gh_falha = res;   /* 0.9.39: sem resposta (limite, rede...): a ultima resposta boa (disp/gh_res) continua valendo */
  pthread_mutex_unlock(&g_trava);
  if(res == GH_OK)
    diario("payloads: %s: GitHub: %s%s, asset %s, %llu bytes, sha256 %.16s%s", it->id, r.tag, r.pre ? " (pre-release)" : "", r.asset,
           r.tamanho, r.sha256[0] ? r.sha256 : "(sem digest)", r.sha256[0] ? "..." : "");
  else diario("payloads: %s: GitHub: resultado %d (HTTP %d)", it->id, res, http);
}

/* forcar = botao (ignora o cache de 1 h, respeita 1 por minuto). Devolve quantos itens precisam perguntar. */
static int precisa(int i, int forcar, time_t agora) {
  const estado_t *e = &g_est[i];
  if(!ITENS[i].gh_repo || e->consultando || removido(&ITENS[i])) return 0;
  if(e->tentou && agora - e->tentou < gh_cache_s(1) && agora >= e->tentou) return 0;
  if(forcar) return 1;
  return !e->consultado || agora - e->consultado >= cache_item(e) || agora < e->consultado;
}

/* Pergunta pelos itens marcados "consultando" (marcados pela rota, antes da thread: o estado ja sai certo). */
static void *procurar(void *arg) {
  (void)arg;
  for(int i = 0; i < N_ITENS; i++) {
    pthread_mutex_lock(&g_trava);
    int vai = g_est[i].consultando;
    pthread_mutex_unlock(&g_trava);
    if(!vai) continue;
    consultar(i);
    pthread_mutex_lock(&g_trava);
    g_est[i].consultando = 0;
    pthread_mutex_unlock(&g_trava);
  }
  pthread_mutex_lock(&g_trava);
  g_procurando = 0;
  pthread_mutex_unlock(&g_trava);
  return NULL;
}

/* Ate a 0.9.32 os itens eram fixos e o arquivo tinha o nome do asset: se bater com o SHA-256 que era fixo, vira a
   versao instalada (nao baixa de novo). Uma vez por execucao. */
static const struct {
  const char *id, *arquivo, *versao, *sha256;
  unsigned long long tamanho;
} LEGADOS[] = {
  {"web-browser-fullscreen", "web-browser-fullscreen-v0.1b.elf", "v0.1b", "520977607a22ecdf51c8d8b75360486026e0bd8780ded8026c3456fac7997a97", 463848ULL},
  {"prefbar", "Prefbar_V0.3.0.elf", "v0.3.0", "e4379590115ef87b2f0310b502321d7da30783536d939bfb1c4c0e511972af30", 964272ULL},
  {"dump-forge", DF_LEGADO_ARQ, "v0.5.6", DF_LEGADO_SHA, DF_LEGADO_TAM},
};

static void migrar_legado(void) {
  for(size_t k = 0; k < sizeof LEGADOS / sizeof LEGADOS[0]; k++) {
    int i = achar(LEGADOS[k].id);
    if(i < 0 || !ITENS[i].gh_repo) continue;
    const item_t *it = &ITENS[i];
    char p[512], velho[600], novo[600], info[600];
    info_t in;
    pasta(p, sizeof p);
    snprintf(velho, sizeof velho, "%s/%s", p, LEGADOS[k].arquivo);
    caminho(it, NULL, novo, sizeof novo);
    caminho(it, ".info", info, sizeof info);
    struct stat st;
    if(lstat(velho, &st) || !S_ISREG(st.st_mode) || !info_ler(it, 0, &in) || !lstat(novo, &st)) continue;
    if(!arquivo_confere_em(velho, LEGADOS[k].sha256, LEGADOS[k].tamanho, NULL)) {
      diario("payloads: %s nao confere com o SHA-256 de antes: ignorado", LEGADOS[k].arquivo);
      continue;
    }
    memset(&in, 0, sizeof in);
    snprintf(in.versao, sizeof in.versao, "%s", LEGADOS[k].versao);
    snprintf(in.sha256, sizeof in.sha256, "%s", LEGADOS[k].sha256);
    snprintf(in.asset, sizeof in.asset, "%s", LEGADOS[k].arquivo);
    in.tamanho = LEGADOS[k].tamanho;
    if(!rename(velho, novo) && !info_gravar(info, &in)) diario("payloads: %s %s guardado antes adotado como versao instalada", it->id, in.versao);
  }
  /* 0.9.41: itens de arquivo com nome fixo novo (shadowkraken.elf -> shadowkraken-PristMC.elf; a anterior
     shadowkraken.anterior.elf -> shadowkraken-PristMC.elf.anterior): o que ja estava guardado continua valendo */
  for(int i = 0; i < N_ITENS; i++) {
    const item_t *it = &ITENS[i];
    if(!it->de_arquivo) continue;
    char p[512], velho[600], novo[600];
    struct stat st;
    pasta(p, sizeof p);
    snprintf(velho, sizeof velho, "%s/%s.elf", p, it->id);
    caminho(it, NULL, novo, sizeof novo);
    if(strcmp(velho, novo) && !lstat(velho, &st) && S_ISREG(st.st_mode) && lstat(novo, &st) && !rename(velho, novo))
      diario("payloads: %s: guardado renomeado para %s", it->id, it->arquivo);
    snprintf(velho, sizeof velho, "%s/%s.anterior.elf", p, it->id);
    caminho(it, ".anterior.elf", novo, sizeof novo);
    if(strcmp(velho, novo) && !lstat(velho, &st) && S_ISREG(st.st_mode) && lstat(novo, &st)) rename(velho, novo);
  }
}

static pthread_once_t g_migrou = PTHREAD_ONCE_INIT;

void payloads_firmware(char *saida, size_t tam) {
  firmware(saida, tam);
}

void payloads_rota_estado(pedido_t *p) {
  buf_t b = {0};
  payloads_json(&b);
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* 0.9.41 (0.9.44: aqui em cima, os atalhos da janela de arquivo usam no JSON). Onde procurar / de onde aceitar, na ordem: a pasta do ps5-payload-manager (itsPLK: /data/pldmgr/payloads/, onde o
   dono ja guarda o kstuff; e /data/pldmgr/, so os arquivos; o autoload.txt dele nao e tocado), depois /data,
   /mnt/usb0..7 e /mnt/ext0..1 (ate 2 pastas para dentro; /data/pldmgr nao e lida de novo). PC: GLR_TESTE_PLDMGR (no
   lugar de /data/pldmgr) e GLR_TESTE_ARQ_RAIZES (discos, separados por ':'). */
typedef struct {
  char dir[256];
  int nivel;   /* 0 = so os arquivos da pasta; 2 = ate 2 pastas para dentro */
} raiz_t;

static void pldmgr_dir(char *saida, size_t tam) {
#ifdef __PROSPERO__
  snprintf(saida, tam, "/data/pldmgr");
#else
  const char *v = getenv("GLR_TESTE_PLDMGR");
  snprintf(saida, tam, "%s", v ? v : "");
#endif
}

static int raizes(raiz_t *r, int max) {
  int n = 0;
  char pm[256];
  pldmgr_dir(pm, sizeof pm);
  if(pm[0] && n + 2 <= max) {
    snprintf(r[n].dir, sizeof r[n].dir, "%s/payloads", pm);
    r[n++].nivel = 0;
    snprintf(r[n].dir, sizeof r[n].dir, "%s", pm);
    r[n++].nivel = 0;
  }
#ifdef __PROSPERO__
  static const char *const DISCOS[] = {"/data", "/mnt/usb0", "/mnt/usb1", "/mnt/usb2", "/mnt/usb3", "/mnt/usb4", "/mnt/usb5",
                                       "/mnt/usb6", "/mnt/usb7", "/mnt/ext0", "/mnt/ext1", NULL};
  for(int k = 0; DISCOS[k] && n < max; k++) {
    snprintf(r[n].dir, sizeof r[n].dir, "%s", DISCOS[k]);
    r[n++].nivel = 2;
  }
#else
  const char *v = getenv("GLR_TESTE_ARQ_RAIZES");
  char c[1024];
  snprintf(c, sizeof c, "%s", v ? v : "");
  for(char *sv = NULL, *t = strtok_r(c, ":", &sv); t && n < max; t = strtok_r(NULL, ":", &sv)) {
    snprintf(r[n].dir, sizeof r[n].dir, "%s", t);
    r[n++].nivel = 2;
  }
#endif
  return n;
}

/* "pldmgr" = veio da pasta do ps5-payload-manager; "disco" = outro lugar */
static const char *fonte_de(const char *caminho) {
  char pm[256];
  pldmgr_dir(pm, sizeof pm);
  size_t t = strlen(pm);
  return t && !strncmp(caminho, pm, t) && caminho[t] == '/' ? "pldmgr" : "disco";
}

/* 0.9.21: o mesmo JSON do GET /api/payloads, tambem para o diagnostico */
void payloads_json(buf_t *saida) {
  static const char *const LING[] = {"pt-BR", "en", "es"};
  static const char *const CAMPOS[] = {"descricao", "desfazer", "aviso"};
  char fw[16], arq[600];
  pthread_once(&g_migrou, migrar_legado);
  firmware(fw, sizeof fw);
  buf_t b = {0};
  buf_str(&b, "{\"ok\":true,\"firmware\":");
  buf_json(&b, fw);
  /* 0.9.33: ShadowMount+ (ou ShadowKraken, que usa o mesmo processo e a mesma API) rodando agora? */
  {
    int api, proc;
    char v[64];
    smp_estado(&api, &proc, v, sizeof v);
    const char *tipo = api ? (versao_shadowkraken(v) ? "shadowkraken" : "smp") : proc ? "desconhecido" : "";
    buf_fmt(&b, ",\"smp\":{\"api\":%s,\"processo\":%s,\"versao\":", api ? "true" : "false", proc ? "true" : "false");
    buf_json(&b, v);
    buf_str(&b, ",\"tipo\":");
    buf_json(&b, tipo);
    buf_fmt(&b, "},\"gh_bloqueado_ate\":%lld,\"gh_livre_em\":%lld", gh_bloqueado_ate(), gh_livre_em());
  }
  /* 0.9.44: atalhos da janela "Instalar de arquivo" (navegar nas pastas): as raizes aceitas que existem, menos a pasta
     de cima do payload manager (a "payloads" dele vem primeiro), no maximo 3 */
  {
    raiz_t r[16];
    int n = raizes(r, 16), saiu = 0;
    char pm[256];
    pldmgr_dir(pm, sizeof pm);
    buf_str(&b, ",\"arq_atalhos\":[");
    for(int k = 0; k < n && saiu < 3; k++) {
      struct stat st;
      if((pm[0] && !strcmp(r[k].dir, pm)) || stat(r[k].dir, &st) || !S_ISDIR(st.st_mode)) continue;
      buf_str(&b, saiu++ ? ",{\"caminho\":" : "{\"caminho\":");
      buf_json(&b, r[k].dir);
      buf_fmt(&b, ",\"pm\":%s}", !strcmp(fonte_de(r[k].dir), "pldmgr") ? "true" : "false");
    }
    buf_str(&b, "]");
  }
  /* 0.9.43: TITAN CORE rodando agora (ele liga o kstuff e o ShadowMount+ dele: a pagina avisa) */
  {
    char v[64];
    int t = titan_rodando(v, sizeof v, 0);
    buf_fmt(&b, ",\"titan\":{\"rodando\":%s,\"versao\":", t ? "true" : "false");
    buf_json(&b, t ? v : "");
    buf_str(&b, "}");
  }
  pthread_mutex_lock(&g_trava);
  buf_fmt(&b, ",\"ocupado\":%s,\"agora\":%lld,\"itens\":[", g_ocupado ? "true" : "false", (long long)time(NULL));
  pthread_mutex_unlock(&g_trava);
  for(int i = 0, n = 0; i < N_ITENS; i++) {
    const item_t *it = &ITENS[i];
    int rem = it->gh_repo && removido(it);
    if(rem && !it->de_arquivo) {   /* 0.9.34: sem nada guardado nao da para instalar: o item some (0.9.41: menos o de arquivo) */
      char a1[600], a2[600];
      struct stat s1;
      caminho(it, NULL, a1, sizeof a1);
      caminho(it, ".anterior.elf", a2, sizeof a2);
      if(lstat(a1, &s1) && lstat(a2, &s1)) continue;
    }
    int ok = pronto(i);
    time_t ativ = ativado_em(i);
    if(it->sonda && !ativo_na_sessao(i)) ativ = 0;   /* 0.9.30/0.9.33: saiu (fechado pela pagina dele) */
    info_t inst, ant;
    int tem_inst = it->gh_repo && !info_ler(it, 0, &inst), tem_ant = it->gh_repo && !info_ler(it, 1, &ant);
    struct stat st;
    caminho(it, NULL, arq, sizeof arq);
    int existe = !lstat(arq, &st);
    /* 0.9.22: exclusao mutua dos que mexem na ShellUI (quem esta ativo nesta sessao do PS5 bloqueia os outros);
       "rodando" = PrefBar rodando nesta sessao sem ter sido ativado pelo glibren */
    int outro = conflito_com(i), ativo = ativo_na_sessao(i);
    pthread_mutex_lock(&g_trava);
    estado_t e = g_est[i];
    pthread_mutex_unlock(&g_trava);
    if(rem) {
      e.disp_ok = 0;
      e.consultado = 0;
      e.gh_res = GH_REPO_SUMIU;
      e.gh_falha = 0;
    }
    const char *estado = e.fase[0] ? e.fase : e.erro[0] ? "erro" : ativ ? "ativado" : ativo ? "rodando" : ok ? "pronto" : "nao_baixado";
    buf_str(&b, n++ ? ",{" : "{");
    buf_str(&b, "\"id\":"); buf_json(&b, it->id);
    buf_str(&b, ",\"nome\":"); buf_json(&b, it->nome);
    buf_str(&b, ",\"autor\":"); buf_json(&b, it->autor);
    buf_str(&b, ",\"licenca\":"); buf_json(&b, it->licenca);
    buf_str(&b, ",\"repo\":"); buf_json(&b, it->repo);
    if(it->gh_repo) {
      /* 0.9.33: o que esta instalado; senao, o que o GitHub oferece */
      gh_release_t d = e.disp;
      char url[600] = "";
      if(e.disp_ok) gh_url_asset(it->gh_repo, &d, url, sizeof url);
      buf_str(&b, ",\"tag\":"); buf_json(&b, tem_inst ? inst.versao : e.disp_ok ? d.tag : "");
      buf_str(&b, ",\"url\":"); buf_json(&b, url);
      buf_str(&b, ",\"sha256\":"); buf_json(&b, tem_inst ? inst.sha256 : e.disp_ok ? d.sha256 : "");
      buf_fmt(&b, ",\"tamanho\":%llu", tem_inst ? inst.tamanho : e.disp_ok ? d.tamanho : 0ULL);
      static const char *const ERROS[] = {"", "rede", "http", "limite", "json", "sem_release", "sem_asset", "varios_assets",
                                         "repo_indisponivel"};
      /* 0.9.39: "erro" = o da ultima tentativa (limite, rede...) se ela nao respondeu; senao, o da ultima resposta.
         "disponivel", "atualizar" e "pode_instalar" vem todos da ultima resposta boa ("cache":true = ela e de antes de
         uma tentativa que falhou; a data e o consultado_em). Antes, com o limite, "disponivel" ficava null e o resto
         continuava true (botao "Atualizar para" sem a linha "No GitHub"). */
      int falha = e.gh_falha < 0 && e.gh_falha >= -8 ? -e.gh_falha : 0;
      int ie = falha ? falha : e.gh_res < 0 && e.gh_res >= -8 ? -e.gh_res : 0;
      if(rem) ie = 8;   /* nao consulta: vale o que se sabe */
      int sem_digest = !falha && e.consultado && e.gh_res == GH_OK && !d.sha256[0];
      int grande = !falha && e.consultado && e.gh_res == GH_OK && d.sha256[0] && (d.tamanho == 0 || d.tamanho > it->gh_max);
      int tem_disp = e.consultado && e.gh_res == GH_OK && d.tag[0];
      buf_str(&b, ",\"gh\":{\"repo\":"); buf_json(&b, it->gh_repo);
      buf_str(&b, ",\"padrao\":"); buf_json(&b, it->gh_padrao);
      buf_str(&b, ",\"removido_em\":"); buf_json(&b, rem ? it->removido_em : "");
      buf_fmt(&b, ",\"pre_releases\":%s,\"instalada\":", it->gh_pre ? "true" : "false");
      if(tem_inst) {
        buf_str(&b, "{\"versao\":"); buf_json(&b, inst.versao);
        buf_str(&b, ",\"asset\":"); buf_json(&b, inst.asset);
        buf_str(&b, ",\"sha256\":"); buf_json(&b, inst.sha256);
        buf_fmt(&b, ",\"tamanho\":%llu}", inst.tamanho);
      } else buf_str(&b, "null");
      buf_str(&b, ",\"anterior\":");
      if(tem_ant) {
        buf_str(&b, "{\"versao\":"); buf_json(&b, ant.versao);
        buf_fmt(&b, ",\"tamanho\":%llu}", ant.tamanho);
      } else buf_str(&b, "null");
      buf_str(&b, ",\"disponivel\":");
      if(tem_disp) {
        buf_str(&b, "{\"versao\":"); buf_json(&b, d.tag);
        buf_fmt(&b, ",\"pre\":%s,\"asset\":", d.pre ? "true" : "false"); buf_json(&b, d.asset);
        buf_fmt(&b, ",\"tamanho\":%llu,\"sha256\":", d.tamanho); buf_json(&b, d.sha256);
        buf_str(&b, ",\"publicado\":"); buf_json(&b, d.publicado);
        buf_str(&b, "}");
      } else buf_str(&b, "null");
      buf_str(&b, ",\"erro\":");
      buf_json(&b, sem_digest ? "sem_digest" : grande ? "grande" : ERROS[ie]);
      int pode = e.disp_ok && tem_disp;   /* nunca "pode instalar" sem "disponivel" */
      int atualizar = pode && (!tem_inst || strcmp(inst.sha256, d.sha256));
      buf_fmt(&b, ",\"cache\":%s,\"http\":%d,\"consultado_em\":%lld,\"tentou_em\":%lld,\"consultando\":%s,\"atualizar\":%s,\"pode_instalar\":%s}",
              tem_disp && falha ? "true" : "false", e.gh_http, (long long)e.consultado, (long long)e.tentou, e.consultando ? "true" : "false",
              atualizar ? "true" : "false", pode ? "true" : "false");
    } else {
      info_t ai;   /* 0.9.41: arquivo do usuario (kstuff): o que esta guardado */
      int tem_ai = it->de_arquivo && !info_ler(it, 0, &ai);
      buf_str(&b, ",\"tag\":"); buf_json(&b, it->tag);
      buf_str(&b, ",\"url\":"); buf_json(&b, it->url);
      buf_str(&b, ",\"sha256\":"); buf_json(&b, tem_ai ? ai.sha256 : it->sha256);
      buf_fmt(&b, ",\"tamanho\":%llu,\"gh\":null", tem_ai ? ai.tamanho : it->tamanho);
    }
    /* 0.9.33: rodando agora (null = o glibren nao tem como saber) */
    if(it->sonda) {
      buf_fmt(&b, ",\"rodando\":%s,\"rodando_versao\":", e.rodando ? "true" : "false");
      buf_json(&b, e.rodando ? e.rodando_versao : "");
      buf_str(&b, ",\"rodando_obs\":");
      buf_json(&b, e.rodando ? e.rodando_obs : "");
      buf_fmt(&b, ",\"versao_diferente\":%s,\"rodando_nivel\":%u", e.rodando && tem_inst && versao_diferente(e.rodando_versao, inst.versao) ? "true" : "false",
              e.rodando ? e.rodando_nivel : 0);
    } else buf_fmt(&b, ",\"rodando\":%s,\"rodando_versao\":\"\",\"rodando_obs\":\"\",\"versao_diferente\":false,\"rodando_nivel\":0", ativo ? "true" : "null");
    buf_fmt(&b, ",\"aviso_smp\":%s,\"total\":%llu", it->aviso_smp ? "true" : "false", e.total);
    buf_str(&b, ",\"firmwares\":"); buf_json(&b, it->firmwares);
    buf_str(&b, ",\"confirmados\":"); buf_json(&b, it->confirmados ? it->confirmados : "");
    buf_str(&b, ",\"confirmado_em\":"); buf_json(&b, it->confirmado_em ? it->confirmado_em : "");
    /* 0.9.22: "12.xx" na lista do autor = so a faixa que ele diz suportar (nao um teste no 12.00): "faixa_do_autor".
       0.9.23: um firmware que nos confirmamos no PS5 real tambem conta como testado ("confirmado_no_seu") */
    int nosso = fw[0] && it->confirmados && palavra(it->confirmados, fw);
    int exato = fw[0] && (nosso || palavra(it->firmwares, fw)), faixa = fw[0] && !exato && na_lista(it->firmwares, fw);
    buf_fmt(&b, ",\"testado_no_seu\":%s,\"faixa_do_autor\":%s,\"confirmado_no_seu\":%s", !fw[0] ? "null" : exato ? "true" : "false",
            faixa ? "true" : "false", nosso ? "true" : "false");
    const char *const *textos[] = {it->descricao, it->desfazer, it->aviso};
    for(int c = 0; c < 3; c++) {
      buf_fmt(&b, ",\"%s\":{", CAMPOS[c]);
      for(int l = 0; l < 3; l++) {
        buf_str(&b, l ? "," : "");
        buf_json(&b, LING[l]);
        buf_str(&b, ":");
        buf_json(&b, textos[c][l]);
      }
      buf_str(&b, "}");
    }
    buf_fmt(&b, ",\"shellui\":%s,\"uma_vez\":%s,\"ativo_sessao\":%s,\"rodando_fora\":%s,\"bloqueado_por\":", it->shellui ? "true" : "false",
            it->uma_vez ? "true" : "false", ativo ? "true" : "false", ativo && !ativ ? "true" : "false");
    buf_json(&b, outro >= 0 ? ITENS[outro].nome : "");
    buf_fmt(&b, ",\"navegador\":%s,\"estado\":", it->navegador ? "true" : "false");
    buf_json(&b, estado);
    buf_fmt(&b, ",\"guardado\":%s,\"conferido\":%s,\"ativado_em\":%lld,\"baixados\":%llu,\"erro\":", existe ? "true" : "false",
            ok ? "true" : "false", (long long)ativ, e.baixados);
    buf_json(&b, e.erro);
    buf_str(&b, ",\"saida\":");
    buf_json(&b, e.saida);
    /* 0.9.41: carregar ao iniciar o glibren (so os itens que podem; o MemDBG com aviso na pagina) */
    buf_fmt(&b, ",\"autoload_pode\":%s,\"autoload\":%s,\"autoload_res\":", autoload_pode(it) ? "true" : "false",
            autoload_pode(it) && config_payload_autoload(it->id) ? "true" : "false");
    buf_json(&b, e.auto_res);
    buf_str(&b, ",\"autoload_erro\":");
    buf_json(&b, e.auto_erro);
    /* 0.9.41: "Instalar de arquivo" (ShadowKraken do dono, kstuff): o arquivo guardado (nome, tamanho, SHA-256, versao) */
    buf_fmt(&b, ",\"de_arquivo\":%s,\"arquivo_fixo\":", it->de_arquivo ? "true" : "false");
    buf_json(&b, it->de_arquivo ? it->arquivo : "");   /* "instalado como shadowkraken-PristMC.elf" */
    buf_str(&b, ",\"arq_padrao\":");
    buf_json(&b, it->arq_padrao ? it->arq_padrao : "");
    buf_str(&b, ",\"arquivo_seu\":");
    info_t as;
    if(it->de_arquivo && !info_ler(it, 0, &as)) {
      buf_str(&b, "{\"nome\":"); buf_json(&b, as.asset);
      buf_fmt(&b, ",\"tamanho\":%llu,\"sha256\":", as.tamanho); buf_json(&b, as.sha256);
      buf_str(&b, ",\"versao\":"); buf_json(&b, as.versao);
      buf_str(&b, ",\"origem\":"); buf_json(&b, as.origem);
      buf_str(&b, "}");
    } else buf_str(&b, "null");
    buf_str(&b, ",\"arquivo_anterior\":");
    if(it->de_arquivo && !info_ler(it, 1, &as)) {
      buf_str(&b, "{\"nome\":"); buf_json(&b, as.asset);
      buf_str(&b, ",\"versao\":"); buf_json(&b, as.versao);
      buf_str(&b, "}");
    } else buf_str(&b, "null");
    if(it->sonda == SONDA_KSTUFF) {   /* "Esta carregado?": sim, nao ou desconhecido (nunca carrega sozinho) */
      buf_str(&b, ",\"carregado\":");
      /* "" = sem o arquivo instalado (a sonda nem roda) */
      buf_json(&b, e.rodando ? "sim" : !strcmp(e.rodando_obs, "desconhecido") ? "desconhecido" : !strcmp(e.rodando_obs, "sem_arquivo") ? "" : "nao");
      buf_fmt(&b, ",\"marcador_boot\":%s", kstuff_carregou_neste_boot() ? "true" : "false");
    }
    buf_str(&b, "}");
  }
  buf_str(&b, "]}");
  buf_add(saida, b.d, b.n);
  buf_free(&b);
}

int payloads_ocupado(void) {
  pthread_mutex_lock(&g_trava);
  int o = g_ocupado;
  pthread_mutex_unlock(&g_trava);
  return o;
}

/* ------------------------------------------------------------------ baixar */

typedef struct {
  int fd, excedeu, erro_gravar, i;
  unsigned long long n, limite;
  sha256_t sha;
} download_t;

static int recebeu(const void *dados, size_t n, void *ctx) {
  download_t *d = ctx;
  if(!dados) return 0;
  if(d->n + n > d->limite) {
    d->excedeu = 1;
    return 1;
  }
  for(size_t feitos = 0; feitos < n;) {
    ssize_t r = write(d->fd, (const char *)dados + feitos, n - feitos);
    if(r <= 0) {
      d->erro_gravar = 1;
      return 1;
    }
    feitos += (size_t)r;
  }
  sha256_atualizar(&d->sha, dados, n);
  d->n += n;
  pthread_mutex_lock(&g_trava);
  g_est[d->i].baixados = d->n;
  pthread_mutex_unlock(&g_trava);
  return 0;
}

/* 0.9.64: item embutido (teste-pad): grava a copia que vem dentro do glibren, conferida pelo SHA-256 fixo. 0 = ok. */
static int extrair_embutido(int i) {
  const item_t *it = &ITENS[i];
  char p[512], arq[600], parcial[620], hex[65];
  uint8_t resumo[32];
  sha256_t sh;
  sha256_iniciar(&sh);
  sha256_atualizar(&sh, glr_teste_pad_elf, (size_t)glr_teste_pad_elf_tam);
  sha256_final(&sh, resumo);
  sha256_hex(resumo, hex);
  if(glr_teste_pad_elf_tam != tam_item(it) || strcmp(hex, sha_item(it))) {
    falhou(i, "a copia embutida nao confere com o SHA-256 fixado (veio %.16s...)", hex);
    return -1;
  }
  pasta(p, sizeof p);
  caminho(it, NULL, arq, sizeof arq);
  snprintf(parcial, sizeof parcial, "%s.part", arq);
  if(mkdir_p(p)) {
    falhou(i, "nao criou a pasta %s (%s)", p, strerror(errno));
    return -1;
  }
  unlink(parcial);
  int fd = open(parcial, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644);
  if(fd < 0) {
    falhou(i, "nao criou %s (%s)", parcial, strerror(errno));
    return -1;
  }
  size_t feito = 0, n = (size_t)glr_teste_pad_elf_tam;
  while(feito < n) {
    ssize_t w = write(fd, glr_teste_pad_elf + feito, n - feito);
    if(w <= 0) break;
    feito += (size_t)w;
  }
  int ok = feito == n && !fsync(fd);
  if(close(fd)) ok = 0;
  if(!ok || rename(parcial, arq)) {
    unlink(parcial);
    falhou(i, "erro ao gravar no PS5");
    return -1;
  }
  diario("payloads: %s: copia embutida gravada e conferida (sha256 %.16s...) em %s", it->id, hex, arq);
  return 0;
}

/* Baixa, confere o SHA-256 e guarda. 0 = ok. */
static int baixar(int i) {
  const item_t *it = &ITENS[i];
  if(it->embutido) return extrair_embutido(i);   /* 0.9.64 */
  char p[512], arq[600], parcial[620], url[700], hex[65];
  pasta(p, sizeof p);
  caminho(it, NULL, arq, sizeof arq);
  snprintf(parcial, sizeof parcial, "%s.part", arq);
  url_item(it, url, sizeof url);
  fase(i, "baixando");
  if(mkdir_p(p)) {
    falhou(i, "nao criou a pasta %s (%s)", p, strerror(errno));
    return -1;
  }
  download_t d;
  memset(&d, 0, sizeof d);
  d.i = i;
  d.limite = tam_item(it);
  sha256_iniciar(&d.sha);
  unlink(parcial);
  if((d.fd = open(parcial, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644)) < 0) {
    falhou(i, "nao criou %s (%s)", parcial, strerror(errno));
    return -1;
  }
  int status = https_baixar(url, recebeu, &d);
  int erro_fechar = fsync(d.fd);
  erro_fechar |= close(d.fd);
  diario("payloads: %s: download %s status %d, %llu bytes", it->id, url, status, d.n);
  if(status != 200 || d.excedeu || d.erro_gravar || erro_fechar || d.n != d.limite) {
    unlink(parcial);
    if(status != 200) falhou(i, "nao foi possivel baixar (HTTP %d)", status);
    else if(d.excedeu || d.n != d.limite) falhou(i, "tamanho diferente do fixado (%llu de %llu bytes): recusado", d.n, d.limite);
    else falhou(i, "erro ao gravar no PS5");
    return -1;
  }
  fase(i, "conferindo");
  uint8_t resumo[32];
  sha256_final(&d.sha, resumo);
  sha256_hex(resumo, hex);
  if(strcmp(hex, sha_item(it))) {
    unlink(parcial);
    falhou(i, "SHA-256 nao confere: arquivo recusado (veio %.16s..., esperado %.16s...)", hex, sha_item(it));
    return -1;
  }
  if(rename(parcial, arq)) {
    unlink(parcial);
    falhou(i, "nao guardou o arquivo (%s)", strerror(errno));
    return -1;
  }
  diario("payloads: %s: baixado e conferido (sha256 %.16s...) em %s", it->id, hex, arq);
  return 0;
}

/* ------------------------------------------------------------------ 0.9.33: instalar/atualizar e voltar (GitHub) */

/* Baixa a ultima release (consultada antes) para <id>.elf.tmp, confere tamanho e SHA-256 com o digest que a API do
   GitHub informou, guarda a versao atual como anterior e troca (rename). Sem digest = recusado. 0 = ok (ou ja estava). */
static int instalar_gh(int i) {
  const item_t *it = &ITENS[i];
  char p[512], arq[600], tmp[620], info[600], ant[620], ant_info[620], url[700], hex[65];
  if(removido(it)) {
    falhou(i, "repositorio removido do GitHub em %s: nada para instalar ou atualizar", it->removido_em);
    return -1;
  }
  pthread_mutex_lock(&g_trava);
  int velho = !g_est[i].consultado || time(NULL) - g_est[i].consultado >= cache_item(&g_est[i]);
  pthread_mutex_unlock(&g_trava);
  if(velho) {   /* sem consulta recente: pergunta agora (respeita o limite) */
    fase(i, "consultando");
    consultar(i);
  }
  pthread_mutex_lock(&g_trava);
  gh_release_t d = g_est[i].disp;
  int disp_ok = g_est[i].disp_ok, res = g_est[i].gh_falha ? g_est[i].gh_falha : g_est[i].gh_res, consultado = g_est[i].consultado != 0;
  pthread_mutex_unlock(&g_trava);
  if(!disp_ok) {
    if(res == GH_LIMITE) {   /* 0.9.39: limite proprio (30/h) ou pausa depois de 403/429: diz quando volta */
      long long livre = gh_livre_em(), agora = (long long)time(NULL);
      falhou(i, "limite de consultas ao GitHub: tente de novo em %lld min", livre > agora ? (livre - agora + 59) / 60 : 1LL);
    }
    else if(res == GH_REDE) falhou(i, "sem resposta do GitHub (internet do PS5?)");
    else if(res == GH_SEM_ASSET) falhou(i, "a ultima release nao tem o arquivo %s", it->gh_padrao);
    else if(res == GH_VARIOS_ASSETS) falhou(i, "a ultima release tem mais de um arquivo %s: recusado", it->gh_padrao);
    else if(res == GH_SEM_RELEASE) falhou(i, "o repositorio nao tem release publicada");
    else if(res == GH_REPO_SUMIU) falhou(i, "repositorio indisponivel no GitHub (removido ou privado)");
    else if(consultado && res == GH_OK && !d.sha256[0])
      falhou(i, "a API do GitHub nao informou o SHA-256 (digest) de %s: sem conferencia, nao instala", d.asset);
    else if(consultado && res == GH_OK) falhou(i, "tamanho do arquivo fora do limite (%llu bytes): recusado", d.tamanho);
    else falhou(i, "nao deu para consultar o GitHub (resultado %d)", res);
    return -1;
  }
  info_t atual;
  if(!info_ler(it, 0, &atual) && !strcmp(atual.sha256, d.sha256) && pronto(i)) {
    diario("payloads: %s: %s ja instalada", it->id, d.tag);
    return 0;
  }
  pasta(p, sizeof p);
  caminho(it, NULL, arq, sizeof arq);
  caminho(it, ".info", info, sizeof info);
  caminho(it, ".anterior.elf", ant, sizeof ant);
  caminho(it, ".anterior.info", ant_info, sizeof ant_info);
  snprintf(tmp, sizeof tmp, "%s.tmp", arq);
  gh_url_asset(it->gh_repo, &d, url, sizeof url);
  if(mkdir_p(p)) {
    falhou(i, "nao criou a pasta %s (%s)", p, strerror(errno));
    return -1;
  }
  download_t dl;
  memset(&dl, 0, sizeof dl);
  dl.i = i;
  dl.limite = d.tamanho;
  sha256_iniciar(&dl.sha);
  pthread_mutex_lock(&g_trava);
  g_est[i].total = d.tamanho;
  g_est[i].baixados = 0;
  snprintf(g_est[i].fase, sizeof g_est[i].fase, "baixando");
  pthread_mutex_unlock(&g_trava);
  unlink(tmp);
  if((dl.fd = open(tmp, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644)) < 0) {
    falhou(i, "nao criou %s (%s)", tmp, strerror(errno));
    return -1;
  }
  int status = https_baixar(url, recebeu, &dl);
  int erro_fechar = fsync(dl.fd);
  erro_fechar |= close(dl.fd);
  diario("payloads: %s: download %s status %d, %llu bytes", it->id, url, status, dl.n);
  if(status != 200 || dl.excedeu || dl.erro_gravar || erro_fechar || dl.n != dl.limite) {
    unlink(tmp);
    if(status != 200) falhou(i, "nao foi possivel baixar (HTTP %d)", status);
    else if(dl.excedeu || dl.n != dl.limite) falhou(i, "tamanho diferente do informado pelo GitHub (%llu de %llu bytes): recusado", dl.n, dl.limite);
    else falhou(i, "erro ao gravar no PS5");
    return -1;
  }
  fase(i, "conferindo");
  uint8_t resumo[32];
  sha256_final(&dl.sha, resumo);
  sha256_hex(resumo, hex);
  if(strcmp(hex, d.sha256)) {
    unlink(tmp);
    falhou(i, "SHA-256 nao confere com o digest do GitHub: arquivo recusado (veio %.16s..., esperado %.16s...)", hex, d.sha256);
    return -1;
  }
  info_t novo;
  memset(&novo, 0, sizeof novo);
  snprintf(novo.versao, sizeof novo.versao, "%s", d.tag);
  snprintf(novo.sha256, sizeof novo.sha256, "%s", d.sha256);
  snprintf(novo.asset, sizeof novo.asset, "%s", d.asset);
  novo.tamanho = d.tamanho;
  /* a atual (conferida) vira a anterior; uma atual que nao confere e descartada */
  struct stat st;
  if(!lstat(arq, &st)) {
    if(!info_ler(it, 0, &atual) && arquivo_confere(it, NULL) && !rename(arq, ant) && !info_gravar(ant_info, &atual))
      diario("payloads: %s: %s guardada como anterior", it->id, atual.versao);
    else unlink(arq);
  }
  if(rename(tmp, arq) || info_gravar(info, &novo)) {
    unlink(tmp);
    falhou(i, "nao guardou o arquivo (%s)", strerror(errno));
    return -1;
  }
  diario("payloads: %s: %s instalada (sha256 %.16s... conferido com o digest do GitHub)", it->id, d.tag, hex);
  return 0;
}

/* Troca a instalada pela anterior (a anterior e conferida pelo SHA-256 dela antes). A que sai vira a anterior. */
static int voltar(int i) {
  const item_t *it = &ITENS[i];
  char arq[600], info[600], ant[620], ant_info[620], troca[640];
  info_t in_ant, in_atual;
  caminho(it, NULL, arq, sizeof arq);
  caminho(it, ".info", info, sizeof info);
  caminho(it, ".anterior.elf", ant, sizeof ant);
  caminho(it, ".anterior.info", ant_info, sizeof ant_info);
  snprintf(troca, sizeof troca, "%s.troca", arq);
  fase(i, "conferindo");
  if(info_ler(it, 1, &in_ant) || !arquivo_confere_em(ant, in_ant.sha256, in_ant.tamanho, NULL)) {
    falhou(i, "a versao anterior guardada nao confere (ou nao existe): nada trocado");
    return -1;
  }
  int tem_atual = !info_ler(it, 0, &in_atual) && arquivo_confere(it, NULL);
  if(tem_atual ? rename(arq, troca) : 0) {
    falhou(i, "nao trocou (%s)", strerror(errno));
    return -1;
  }
  if(rename(ant, arq)) {
    if(tem_atual) rename(troca, arq);
    falhou(i, "nao trocou (%s)", strerror(errno));
    return -1;
  }
  info_gravar(info, &in_ant);
  if(tem_atual && !rename(troca, ant)) info_gravar(ant_info, &in_atual);
  else {
    unlink(troca);
    unlink(ant_info);
  }
  diario("payloads: %s: voltou para %s (anterior agora: %s)", it->id, in_ant.versao, tem_atual ? in_atual.versao : "nenhuma");
  return 0;
}

/* ------------------------------------------------------------------ PS5: tela inicial e navegador */

static int ir_para_home(void) {
#ifdef __PROSPERO__
  if(!sceKernelLoadStartModule || !sceUserServiceGetForegroundUser) return -1;
  int modulo = sceKernelLoadStartModule("/system_ex/common_ex/lib/libSceShellUIUtil.sprx", 0, NULL, 0, NULL, NULL);
  if(modulo < 0) {
    diario("payloads: libSceShellUIUtil nao carregou (0x%08x)", (unsigned)modulo);
    return modulo;
  }
  int (*iniciar)(void) = (void *)kernel_dynlib_dlsym(-1, (uint32_t)modulo, "sceShellUIUtilInitialize");
  int (*por_uri)(const char *, void *) = (void *)kernel_dynlib_dlsym(-1, (uint32_t)modulo, "sceShellUIUtilLaunchByUri");
  if(!iniciar || !por_uri) {
    diario("payloads: libSceShellUIUtil sem as funcoes esperadas");
    return -1;
  }
  int r = iniciar();
  if(r < 0) diario("payloads: sceShellUIUtilInitialize 0x%08x", (unsigned)r);
  struct {
    uint32_t tamanho, usuario;
  } par = {8, 0};
  sceUserServiceGetForegroundUser(&par.usuario);
  r = por_uri("pshomeui:navigateToHome?bootCondition=psButton", &par);
  diario("payloads: tela inicial 0x%08x", (unsigned)r);
  return r;
#else
  diario("payloads (PC): voltaria para a tela inicial");
  return 0;
#endif
}

static int abrir_navegador(const char *url) {
#ifdef __PROSPERO__
  if(!sceSystemServiceLaunchWebBrowser) return -1;
  int r = sceSystemServiceLaunchWebBrowser(url, NULL);
  diario("payloads: navegador reaberto em %s (0x%08x)", url, (unsigned)r);
  return r;
#else
  diario("payloads (PC): abriria o navegador em %s", url);
  return 0;
#endif
}

/* ------------------------------------------------------------------ elfldr */

/* Envia ao elfldr e le a saida do payload ate ele terminar (ou espera_s). 0 = enviado. */
/* 0.9.41: conectou = 1 se o elfldr aceitou a conexao (0 = ainda nao esta no ar: o carregar ao iniciar tenta de novo) */
static int porta_elfldr(void) {
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_ELFLDR")) return atoi(getenv("GLR_TESTE_ELFLDR"));
#endif
  return PORTA_ELFLDR;
}

/* 0.9.41 (revisao): o elfldr ja aceita conexao? (conecta e fecha sem mandar nada; o elfldr descarta conexao vazia) */
static int elfldr_no_ar(void) {
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if(fd < 0) return 0;
  struct sockaddr_in end = {.sin_family = AF_INET, .sin_port = htons((uint16_t)porta_elfldr())};
  end.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  int ok = !connect(fd, (struct sockaddr *)&end, sizeof end);
  close(fd);
  return ok;
}

static int enviar_elfldr_ex(const void *dados, size_t n, int espera_s, buf_t *saida, int *conectou) {
  if(conectou) *conectou = 0;
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if(fd < 0) return -1;
  int porta = porta_elfldr();
  struct timeval um = {.tv_sec = 1};
  setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &um, sizeof um);
  struct timeval dez = {.tv_sec = 10};
  setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &dez, sizeof dez);
#ifdef SO_NOSIGPIPE
  int sim = 1;
  setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &sim, sizeof sim);
#endif
  struct sockaddr_in end = {.sin_family = AF_INET, .sin_port = htons(porta)};
  end.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  int ok = !connect(fd, (struct sockaddr *)&end, sizeof end);
  if(ok && conectou) *conectou = 1;
  for(size_t enviados = 0; ok && enviados < n;) {
    ssize_t r = send(fd, (const char *)dados + enviados, n - enviados, SEM_SINAL);
    if(r <= 0) ok = 0;
    else enviados += (size_t)r;
  }
  if(ok) {
    shutdown(fd, SHUT_WR);   /* fim do .elf; a leitura continua: a saida do payload chega por aqui */
    long long limite = mono_s() + espera_s;
    char bloco[2048];
    while(mono_s() < limite) {
      ssize_t r = recv(fd, bloco, sizeof bloco, 0);
      if(r == 0) break;   /* o payload terminou */
      if(r < 0) {
        if(errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) continue;
        break;
      }
      if(saida->n + (size_t)r <= MAX_SAIDA) buf_add(saida, bloco, (size_t)r);
    }
  }
  close(fd);
  buf_add(saida, "", 1);
  return ok ? 0 : -1;
}

/* Linha que comeca com "prefixo" (sem o prefixo e o fim de linha; so ASCII visivel). 1 = achou. */
static int linha(const char *texto, const char *prefixo, char *saida, size_t tam) {
  saida[0] = 0;
  size_t np = strlen(prefixo);
  for(const char *p = texto; p && *p;) {
    if(!strncmp(p, prefixo, np)) {
      size_t k = 0;
      for(const char *c = p + np; *c && *c != '\n' && *c != '\r' && k + 1 < tam; c++) saida[k++] = (*c >= ' ' && *c <= '~') ? *c : '?';
      saida[k] = 0;
      return 1;
    }
    p = strchr(p, '\n');
    if(p) p++;
  }
  return 0;
}

/* ------------------------------------------------------------------ trabalho */

typedef struct {
  int i, ativar, voltar;
  int confirmou_ks;    /* 0.9.41: kstuff: o usuario respondeu "Tenho certeza de que o kstuff nao esta carregado" */
  char reabrir[300];   /* URL completa para reabrir o navegador ("" = nao reabre) */
} trabalho_t;

/* 0.9.41 (revisao): pode mandar o kstuff agora (Ativar)? NULL = pode; senao a chave do motivo:
   "ativo" (a sonda diz que ele esta carregado: nunca, nem com confirmacao), "boot" (o glibren ja o mandou neste boot) ou
   "desconhecido" (a sonda nao diz claramente "nao carregado"); estes dois so com a confirmacao explicita. */
static const char *kstuff_impede(int confirmou) {
  int k = kstuff_ativo();
  if(k == 1) return "ativo";
  if(confirmou) return NULL;
  if(kstuff_carregou_neste_boot()) return "boot";
  return k == 0 ? NULL : "desconhecido";
}

static void gravar_ativado(const item_t *it, time_t quando) {
  char arq[600], tmp[620];
  caminho(it, ".ativado", arq, sizeof arq);
  snprintf(tmp, sizeof tmp, "%s.tmp", arq);
  FILE *f = fopen(tmp, "w");
  if(!f) return;
  int pid = it->shellui ? pid_shellui() : 0;   /* 0.9.33: so os patches da ShellUI morrem com ela */
  fprintf(f, "%lld %d\n", (long long)quando, pid);   /* quem foi ativado (o arquivo) e quando, nesta ShellUI */
  int ok = !fflush(f) && !fsync(fileno(f));
  if(fclose(f) || !ok || rename(tmp, arq)) unlink(tmp);
  else diario("payloads: %s: ativacao gravada (hora %lld, ShellUI pid %d, PS5 ligado desde %lld)", it->id, (long long)quando, pid,
              (long long)ligou_em());
}

/* 0.9.41 (revisao): o .elf e o proprio glibren (marcador "GLIBREN-VERSAO:<versao>")? Nunca vai ao elfldr como payload
   de terceiro nem e instalado num item: o glibren novo derrubaria este e o "carregar ao iniciar" mandaria de novo. */
static int eh_glibren(const void *d, size_t n) {
  char v[32];
  atualizacao_versao_elf(d, n, v, sizeof v);
  return v[0] != 0;
}

/* Envia ao elfldr e interpreta a saida. 0 = ativado. 0.9.41: sem_elfldr != NULL (carregar ao iniciar) = o elfldr
   ainda nao aceita conexao: devolve -2 sem marcar erro (*sem_elfldr = 1), para tentar de novo. marcador = 1: o kstuff
   grava o marcador do boot aqui (Ativar); 0 = quem chamou ja cuidou dele (carregar ao iniciar: grava uma vez so). */
static int aplicar_ex(int i, const buf_t *elf, int *sem_elfldr, int marcador) {
  const item_t *it = &ITENS[i];
  buf_t saida = {0};
  int r = -1, conectou = 0;
  char res[200] = "", aviso[400] = "", resumo[600] = "";
  if(sem_elfldr) *sem_elfldr = 0;
  if(eh_glibren(elf->d, elf->n)) {
    falhou(i, "este arquivo e o proprio glibren, nao o %s: nao enviado", it->nome);
    return -1;
  }
  fase(i, "aplicando");
  if(!sem_elfldr) diario("payloads: %s: enviando ao elfldr (%zu bytes)", it->id, elf->n);
  /* 0.9.41: kstuff: o marcador do boot vai ANTES (mesmo se o glibren cair no meio, nao manda de novo sozinho). Revisao:
     um marcador que JA valia (carga anterior neste boot) nunca e apagado aqui; so o que esta chamada gravou e so se
     nada chegou ao elfldr. */
  int marcou = 0;
  if(marcador && it->sonda == SONDA_KSTUFF && !kstuff_carregou_neste_boot()) marcou = !kstuff_gravar_marcador();
  if(enviar_elfldr_ex(elf->d, elf->n, it->espera_s, &saida, &conectou)) {
    if(marcou && !conectou) kstuff_apagar_marcador();   /* nada saiu daqui: o marcador que esta chamada gravou nao vale */
    if(sem_elfldr && !conectou) {
      *sem_elfldr = 1;
      fase(i, "");
      r = -2;
      goto fim;
    }
    falhou(i, "o elfldr (porta 9021) nao respondeu");
    goto fim;
  }
  if(sem_elfldr) diario("payloads: %s: enviado ao elfldr ao iniciar o glibren (%zu bytes)", it->id, elf->n);
  int tem_res = linha(saida.d, "Result=", res, sizeof res);
  if(!linha(saida.d, "Notification: ", aviso, sizeof aviso)) linha(saida.d, "[elfldr.elf] ", aviso, sizeof aviso);
  snprintf(resumo, sizeof resumo, "%s%s%s%s", tem_res ? "Result=" : "", res, tem_res && aviso[0] ? " | " : "", aviso);
  diario("payloads: %s: saida do payload: %s", it->id, resumo[0] ? resumo : "(nada)");
  pthread_mutex_lock(&g_trava);
  snprintf(g_est[i].saida, sizeof g_est[i].saida, "%s", resumo);
  pthread_mutex_unlock(&g_trava);
  int codigo = tem_res ? atoi(res) : -1;
  if(tem_res && codigo != 0 && codigo != 2) {
    falhou(i, "o payload informou falha: %s", aviso[0] ? aviso : res);
    goto fim;
  }
  if(!tem_res && strstr(saida.d, "[elfldr.elf]")) {
    falhou(i, "o elfldr recusou: %s", aviso);
    goto fim;
  }
  time_t agora = time(NULL);
  gravar_ativado(it, agora);
  pthread_mutex_lock(&g_trava);
  g_est[i].ativado_em = agora;
  g_est[i].erro[0] = 0;
  pthread_mutex_unlock(&g_trava);
  diario("payloads: %s: ativado%s", it->id, tem_res ? "" : " (o payload nao confirmou; veja a notificacao do PS5)");
  r = 0;
fim:
  buf_free(&saida);
  return r;
}

static int aplicar(int i, const buf_t *elf) {
  return aplicar_ex(i, elf, NULL, 1);
}

static void *trabalhar(void *arg) {
  trabalho_t t = *(trabalho_t *)arg;
  free(arg);
  const item_t *it = &ITENS[t.i];
  buf_t elf = {0};
  int home = 0;
  if(t.voltar) {
    voltar(t.i);
    goto fim;
  }
  if(it->gh_repo) {
    /* 0.9.33: Baixar = instalar/atualizar para a ultima; Ativar sem nada instalado instala a ultima antes */
    if((!t.ativar || !pronto(t.i)) && instalar_gh(t.i)) goto fim;
  } else if(it->de_arquivo && !pronto(t.i)) {   /* 0.9.41: kstuff: so "Instalar de arquivo" */
    falhou(t.i, "instale o arquivo antes (Instalar de arquivo)");
    goto fim;
  } else if(!it->de_arquivo && !pronto(t.i) && baixar(t.i)) goto fim;
  if(!t.ativar) goto fim;
  /* confere de novo o arquivo guardado (pode ter sido trocado no disco depois do download) */
  fase(t.i, "conferindo");
  if(!arquivo_confere(it, &elf)) {
    char arq[600];
    caminho(it, NULL, arq, sizeof arq);
    unlink(arq);
    falhou(t.i, "o arquivo guardado nao confere com o SHA-256 %s: apagado (baixe de novo)", it->gh_repo ? "da versao instalada" : "fixado");
    goto fim;
  }
  if(it->navegador) {
    fase(t.i, "home");
    usleep(250000);   /* a resposta chega ao navegador antes de sair dele */
    home = !ir_para_home();
    if(home) usleep(1000000);
  }
  if(it->sonda == SONDA_KSTUFF) {   /* 0.9.41 (revisao): confere de novo logo antes de mandar (com g_ocupado) */
    const char *m = kstuff_impede(t.confirmou_ks);
    if(m) {
      falhou(t.i, "%s", !strcmp(m, "ativo")  ? "o kstuff ja esta carregado: nao mandado de novo"
                        : !strcmp(m, "boot") ? "o glibren ja mandou o kstuff neste boot: confirme na pagina para mandar de novo"
                                             : "nao deu para saber se o kstuff ja esta carregado: confirme na pagina");
      goto fim;
    }
  }
  aplicar(t.i, &elf);
  if(it->navegador && t.reabrir[0]) {
    fase(t.i, "reabrindo");
    if(!home) usleep(250000);
    abrir_navegador(t.reabrir);   /* mesmo se falhou: ninguem fica perdido na tela inicial */
  }
fim:
  buf_free(&elf);
  pthread_mutex_lock(&g_trava);
  g_est[t.i].fase[0] = 0;
  g_ocupado = 0;
  pthread_mutex_unlock(&g_trava);
  return NULL;
}

/* Pagina para reabrir: "/" + letras, numeros e - _ . / ? = & (sem "//" nem ".."). */
static int caminho_reabrir_ok(const char *c) {
  if(c[0] != '/' || c[1] == '/' || strstr(c, "..") || strlen(c) > 200) return 0;
  for(const char *p = c; *p; p++)
    if(!((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') || (*p >= '0' && *p <= '9') || strchr("-_./?=&", *p))) return 0;
  return 1;
}

static void rota_acao(pedido_t *p, int ativar, int volta);

void payloads_rota_acao(pedido_t *p, int ativar) {
  rota_acao(p, ativar, 0);
}

void payloads_rota_voltar(pedido_t *p) {
  rota_acao(p, 0, 1);
}

/* 0.9.34: POST /api/payloads/remover (id): apaga o que o glibren guardou de um item acompanhado pelo GitHub (o .elf, a
   anterior, os .info e o .ativado). Nao fecha o que ja esta rodando. Mesmas regras do voltar (pareamento + X-GLR, so celular/PC). */
void payloads_rota_remover(pedido_t *p) {
  char id[64] = "";
  param(p->corpo, "id", 0, id, sizeof id);
  int i = achar(id);
  if(i < 0 || (!ITENS[i].gh_repo && !ITENS[i].de_arquivo)) {
    responder_erro(p, 404, "payload_fora_da_lista", "este payload nao esta na lista do glibren", NULL);
    return;
  }
  if(fps_agente_ps5(p->agente) || p->local) {
    responder_erro(p, 403, "payload_so_celular", "payloads de teste so pelo celular ou PC pareado", NULL);
    return;
  }
  const item_t *it = &ITENS[i];
  pthread_mutex_lock(&g_trava);
  if(g_ocupado) {
    pthread_mutex_unlock(&g_trava);
    responder_erro(p, 409, "payload_ocupado", "outro payload esta sendo baixado ou ativado: espere", NULL);
    return;
  }
  static const char *const EXT[] = {NULL, ".info", ".anterior.elf", ".anterior.info", ".ativado"};
  int apagados = 0;
  for(int k = 0; k < 5; k++) {
    char arq[620];
    caminho(it, EXT[k], arq, sizeof arq);
    if(!unlink(arq)) apagados++;
  }
  g_est[i].cache_tam = -1;
  g_est[i].ativado_em = 0;
  g_est[i].erro[0] = 0;
  g_est[i].saida[0] = 0;
  pthread_mutex_unlock(&g_trava);
  diario("payloads: %s: removido do glibren pelo aparelho pareado (%d arquivos)", it->id, apagados);
  responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
}

/* POST /api/payloads/procurar (forcar=1 = botao): pergunta ao GitHub numa thread (cache de 1 h; botao 1x/min). */
void payloads_rota_procurar(pedido_t *p) {
  char forcar[4] = "";
  param(p->corpo, "forcar", 0, forcar, sizeof forcar);
  int f = !strcmp(forcar, "1"), vai = 0, n = 0;
  pthread_once(&g_migrou, migrar_legado);
  time_t agora = time(NULL);
  long long bloq = gh_bloqueado_ate();
  pthread_mutex_lock(&g_trava);
  if(!g_procurando && !bloq)
    for(int i = 0; i < N_ITENS; i++)
      if(precisa(i, f, agora)) {
        g_est[i].consultando = 1;
        n++;
      }
  if(n) {
    g_procurando = 1;
    vai = 1;
  }
  pthread_mutex_unlock(&g_trava);
  if(vai && criar_thread(procurar, NULL, NULL)) {
    pthread_mutex_lock(&g_trava);
    g_procurando = 0;
    for(int i = 0; i < N_ITENS; i++) g_est[i].consultando = 0;
    pthread_mutex_unlock(&g_trava);
    vai = 0;
  }
  char r[128];
  int k = snprintf(r, sizeof r, "{\"ok\":true,\"iniciado\":%s,\"itens\":%d,\"bloqueado_ate\":%lld}", vai ? "true" : "false", vai ? n : 0, bloq);
  responder(p, 200, "application/json", r, (size_t)k, NULL);
}

static void rota_acao(pedido_t *p, int ativar, int volta) {
  char id[64] = "", reabrir[256] = "", tid[16] = "", confirmo[4] = "";
  param(p->corpo, "id", 0, id, sizeof id);
  param(p->corpo, "confirmo", 0, confirmo, sizeof confirmo);
  param(p->corpo, "reabrir", 0, reabrir, sizeof reabrir);
  int i = achar(id);
  if(i < 0) {
    for(char *c = id; *c; c++) if(*c < ' ' || *c > '~') *c = '?';
    diario("payloads: pedido recusado: \"%.60s\" nao esta na lista", id);
    responder_erro(p, 404, "payload_fora_da_lista", "este payload nao esta na lista do glibren", NULL);
    return;
  }
  const item_t *it = &ITENS[i];
  int ps5 = fps_agente_ps5(p->agente);
  if((ps5 || p->local) && !(it->navegador && ps5)) {
    responder_erro(p, 403, "payload_so_celular", "payloads de teste so pelo celular ou PC pareado", NULL);
    return;
  }
  if(volta) {
    info_t in;
    if((!it->gh_repo && !it->de_arquivo) || info_ler(it, 1, &in)) {
      responder_erro(p, 409, "payload_sem_anterior", "nao ha versao anterior guardada deste payload", NULL);
      return;
    }
  }
  if(reabrir[0] && !caminho_reabrir_ok(reabrir)) {
    responder_erro(p, 400, "payload_reabrir", "pagina para reabrir invalida", NULL);
    return;
  }
  if(ativar) {
    int r = app_de_jogo_aberto(tid, sizeof tid);
    if(r == 1) {
      responder_erro(p, 409, "payload_jogo_aberto", "feche o jogo ou app antes: se a interface do PS5 reiniciar, ele fecha sem salvar", tid);
      return;
    }
    if(r < 0) diario("payloads: nao deu para saber se ha jogo aberto; seguindo");
    /* 0.9.22: so um patch da ShellUI por sessao do PS5 (o PrefBar e a tela cheia mexem na mesma interface) */
    int outro = conflito_com(i);
    if(outro >= 0) {
      diario("payloads: %s recusado: %s ja esta ativo nesta sessao do PS5 (os dois mexem na ShellUI)", it->id, ITENS[outro].id);
      responder_erro(p, 409, "payload_conflito", "outro payload que mexe na interface do PS5 ja esta ativo: reinicie o PS5 antes", ITENS[outro].nome);
      return;
    }
    /* 0.9.43: com o TITAN CORE rodando, nada de outro montador nem de outro kstuff (ele ja ligou os dele): recusado
       sempre (sem confirmacao: dois kstuff podem travar o PS5) */
    if(briga_com_titan(it)) {
      char tv[64];
      if(titan_rodando(tv, sizeof tv, 1)) {
        diario("payloads: %s recusado: o TITAN CORE (v%s) esta rodando", it->id, tv);
        responder_erro(p, 409, "payload_titan", TITAN_MOTIVO, tv);
        return;
      }
    }
    /* 0.9.33: kraken-mount e ShadowKraken nao rodam junto com o ShadowMount+: so com a confirmacao explicita da pagina
       (o glibren nunca fecha o ShadowMount+) */
    if(it->aviso_smp && strcmp(confirmo, "1")) {
      int api, proc;
      char v[64];
      smp_estado(&api, &proc, v, sizeof v);
      responder_erro(p, 409, "payload_confirmar_smp", "confirme: este payload nao roda junto com o ShadowMount+", api || proc ? "rodando" : "parado");
      return;
    }
    if(it->uma_vez && ativo_na_sessao(i)) {
      diario("payloads: %s recusado: ja esta rodando nesta sessao do PS5", it->id);
      responder_erro(p, 409, "payload_ja_ativo", "ja esta ativo nesta sessao do PS5 (ativar de novo criaria uma segunda copia)", it->nome);
      return;
    }
    /* 0.9.41 (revisao): kstuff carregado duas vezes pode travar o PS5. Sem a sonda dizendo claramente "nao carregado", ou
       com o marcador deste boot, so com a pergunta da pagina respondida ("Tenho certeza de que o kstuff nao esta
       carregado": confirmo_kstuff=1). A sonda dizendo "carregado" recusa sempre (payload_ja_ativo). O trabalho confere
       tudo de novo logo antes de mandar. */
    if(it->sonda == SONDA_KSTUFF && instalado(it)) {
      char ck[4] = "";
      param(p->corpo, "confirmo_kstuff", 0, ck, sizeof ck);
      const char *m = kstuff_impede(!strcmp(ck, "1"));
      if(m && !strcmp(m, "ativo")) {
        diario("payloads: kstuff recusado: a sonda diz que ele ja esta carregado");
        responder_erro(p, 409, "payload_ja_ativo", "ja esta ativo nesta sessao do PS5 (ativar de novo criaria uma segunda copia)", it->nome);
        return;
      }
      if(m) {
        diario("payloads: kstuff: Ativar pede confirmacao (%s)", m);
        responder_erro(p, 409, "payload_kstuff_confirmar",
                       !strcmp(m, "boot") ? "o glibren ja mandou o kstuff neste boot: confirme que ele nao esta carregado"
                                          : "nao deu para saber se o kstuff esta carregado: confirme que ele nao esta",
                       m);
        return;
      }
    }
  }
  trabalho_t *t = calloc(1, sizeof *t);
  if(!t) {
    responder_erro(p, 500, "payload_erro", "sem memoria", NULL);
    return;
  }
  t->i = i;
  t->ativar = ativar;
  t->voltar = volta;
  if(ativar && it->sonda == SONDA_KSTUFF) {
    char ck[4] = "";
    param(p->corpo, "confirmo_kstuff", 0, ck, sizeof ck);
    t->confirmou_ks = !strcmp(ck, "1");
    if(t->confirmou_ks) diario("payloads: kstuff: o usuario confirmou que ele nao esta carregado");
  }
  if(reabrir[0]) snprintf(t->reabrir, sizeof t->reabrir, "http://127.0.0.1:%d%s", g_porta, reabrir);
  pthread_mutex_lock(&g_trava);
  if(g_ocupado) {
    pthread_mutex_unlock(&g_trava);
    free(t);
    responder_erro(p, 409, "payload_ocupado", "outro payload esta sendo baixado ou ativado: espere", NULL);
    return;
  }
  g_ocupado = 1;
  g_est[i].erro[0] = 0;
  g_est[i].saida[0] = 0;
  g_est[i].baixados = 0;
  g_est[i].total = 0;
  snprintf(g_est[i].fase, sizeof g_est[i].fase, "%s", "conferindo");
  pthread_mutex_unlock(&g_trava);
  diario("payloads: %s: %s pedido pelo %s%s", it->id, volta ? "voltar a versao anterior" : ativar ? "ativar" : "baixar", ps5 ? "navegador do PS5" : "aparelho pareado",
         t->reabrir[0] ? " (reabre o navegador depois)" : "");
  if(criar_thread(trabalhar, t, NULL)) {
    free(t);
    pthread_mutex_lock(&g_trava);
    g_ocupado = 0;
    g_est[i].fase[0] = 0;
    pthread_mutex_unlock(&g_trava);
    responder_erro(p, 500, "payload_erro", "nao iniciou", NULL);
    return;
  }
  responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
}

/* ------------------------------------------------------------------ 0.9.24: abrir o navegador do PS5 pelo celular */

#define PORTA_JOBE_WEB 34201   /* servidor web da Jobe no PS5 (/app e /teste) */

/* Lista FIXA: nada de URL vinda do pedido. porta 0 = a do glibren; porta -1 = caminho e o endereco inteiro
   (0.9.29: "internet" abre o Google para navegar, ja que o navegador do PS5 nao tem barra de endereco). */
static const struct {
  const char *id;
  int porta;
  const char *caminho;
} DESTINOS[] = {
  {"jobe", PORTA_JOBE_WEB, "/app"},
  {"jobe_teste", PORTA_JOBE_WEB, "/teste"},
  {"glibren", 0, "/"},
  {"glibren_payloads", 0, "/payloads"},
  {"internet", -1, "https://www.google.com/"},
  {NULL, 0, NULL},
};

static void *abrir_destino(void *arg) {
  char *url = arg;
  usleep(250000);
  int home = !ir_para_home();   /* como no item de tela cheia: da tela inicial o navegador abre limpo */
  usleep(home ? 1000000 : 250000);
  abrir_navegador(url);
  free(url);
  pthread_mutex_lock(&g_trava);
  g_ocupado = 0;
  pthread_mutex_unlock(&g_trava);
  return NULL;
}

void payloads_rota_navegador(pedido_t *p) {
  char destino[32] = "", tid[16] = "";
  param(p->corpo, "destino", 0, destino, sizeof destino);
  int d = 0;
  while(DESTINOS[d].id && strcmp(DESTINOS[d].id, destino)) d++;
  if(!DESTINOS[d].id) {
    for(char *c = destino; *c; c++) if(*c < ' ' || *c > '~') *c = '?';
    diario("navegador: pedido recusado: \"%.30s\" nao esta na lista", destino);
    responder_erro(p, 404, "navegador_destino", "esta pagina nao esta na lista do glibren", NULL);
    return;
  }
  if(fps_agente_ps5(p->agente) || p->local) {
    responder_erro(p, 403, "navegador_so_celular", "abrir o navegador do PS5 so pelo celular ou PC pareado", NULL);
    return;
  }
  int r = app_de_jogo_aberto(tid, sizeof tid);
  if(r == 1) {
    responder_erro(p, 409, "navegador_jogo_aberto", "feche o jogo ou app aberto antes: abrir o navegador por cima de outro app pode travar o PS5", tid);
    return;
  }
  if(r < 0) diario("navegador: nao deu para saber se ha jogo aberto; seguindo");
  char *url = malloc(96);
  if(!url) {
    responder_erro(p, 500, "navegador_erro", "sem memoria", NULL);
    return;
  }
  if(DESTINOS[d].porta < 0) snprintf(url, 96, "%s", DESTINOS[d].caminho);
  else snprintf(url, 96, "http://127.0.0.1:%d%s", DESTINOS[d].porta ? DESTINOS[d].porta : g_porta, DESTINOS[d].caminho);
  pthread_mutex_lock(&g_trava);
  if(g_ocupado) {
    pthread_mutex_unlock(&g_trava);
    free(url);
    responder_erro(p, 409, "payload_ocupado", "outro payload esta sendo baixado ou ativado: espere", NULL);
    return;
  }
  g_ocupado = 1;
  pthread_mutex_unlock(&g_trava);
  diario("navegador: abrir %s pedido pelo aparelho pareado", url);
  if(criar_thread(abrir_destino, url, NULL)) {
    free(url);
    pthread_mutex_lock(&g_trava);
    g_ocupado = 0;
    pthread_mutex_unlock(&g_trava);
    responder_erro(p, 500, "navegador_erro", "nao iniciou", NULL);
    return;
  }
  responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
}

/* ------------------------------------------------------------------ 0.9.41: carregar ao iniciar o glibren */

/* PC: GLR_TESTE_AUTOLOAD_ESPERA_S troca os 60 s de espera pelo elfldr; GLR_TESTE_KSTUFF_ESPERA_S os 15 s que o kstuff
   tem para confirmar que ficou ativo */
static int espera_teste(const char *var, int padrao) {
#ifndef __PROSPERO__
  const char *v = getenv(var);
  if(v && *v) return atoi(v);
#else
  (void)var;
#endif
  return padrao;
}
#define AUTOLOAD_ESPERA_S espera_teste("GLR_TESTE_AUTOLOAD_ESPERA_S", 60)
#define KSTUFF_CONFIRMA_S espera_teste("GLR_TESTE_KSTUFF_ESPERA_S", 15)

static void auto_marca(int i, const char *res, const char *erro) {
  pthread_mutex_lock(&g_trava);
  snprintf(g_est[i].auto_res, sizeof g_est[i].auto_res, "%s", res);
  snprintf(g_est[i].auto_erro, sizeof g_est[i].auto_erro, "%s", erro ? erro : "");
  pthread_mutex_unlock(&g_trava);
  if(!strcmp(res, "erro")) diario("payloads: %s: nao carregou ao iniciar: %s", ITENS[i].id, erro ? erro : "");
}

/* Rodando agora, sem nenhum cache (a sonda do item e, no ShadowKraken, a API do ShadowMount+/ShadowKraken) */
static int rodando_agora(int i) {
  if(ITENS[i].sonda == SONDA_SHADOWKRAKEN) {
    pthread_mutex_lock(&g_trava_smp);
    g_smp.em = 0;
    pthread_mutex_unlock(&g_trava_smp);
  }
  pthread_mutex_lock(&g_trava);
  g_est[i].sonda_em = 0;
  pthread_mutex_unlock(&g_trava);
  return ativo_na_sessao(i);
}

enum { AL_ENVIADO = 0, AL_ERRO = -1, AL_RODANDO = 1, AL_BOOT = 2 };

/* O arquivo guardado (conferido pelo SHA-256) vai ao elfldr como no botao Ativar. Revisao 0.9.41:
     1. espera a porta 9021 aceitar conexao (o elfldr pode subir depois do glibren) ANTES de ler o arquivo;
     2. pega a vez (g_ocupado: nada de Ativar/Instalar pela pagina no meio);
     3. le e confere o SHA-256 UMA vez;
     4. logo antes de CADA envio, ainda com a vez: o item nao esta rodando (sonda sem cache); no kstuff, a sonda diz
        claramente "nao carregado" e nao ha marcador de outra carga neste boot. O marcador do kstuff e gravado uma vez,
        antes do primeiro envio, e so e apagado (uma vez) se nenhum envio chegou ao elfldr;
     5. se a conexao cair antes de mandar (elfldr reiniciando), tenta de novo a cada 2 s ate o prazo (monotonico).
   Devolve AL_ENVIADO, AL_RODANDO (ja rodando: nada enviado), AL_BOOT (kstuff: marcador deste boot) ou AL_ERRO (motivo). */
static int autoload_enviar(int i, long long limite, char *motivo, size_t tam) {
  const item_t *it = &ITENS[i];
  int ks = it->sonda == SONDA_KSTUFF;
  motivo[0] = 0;
  while(!elfldr_no_ar()) {
    if(mono_s() >= limite) {
      snprintf(motivo, tam, "o elfldr (porta 9021) nao respondeu em %d s", AUTOLOAD_ESPERA_S);
      return AL_ERRO;
    }
    sleep(1);
  }
  for(;;) {
    pthread_mutex_lock(&g_trava);
    int ocupado = g_ocupado;
    if(!ocupado) {
      g_ocupado = 1;
      g_est[i].erro[0] = 0;
      g_est[i].saida[0] = 0;
    }
    pthread_mutex_unlock(&g_trava);
    if(!ocupado) break;
    sleep(1);   /* o aparelho pareado esta baixando/ativando algo: espera a vez */
  }
  buf_t elf = {0};
  int r = AL_ERRO, gravou = 0, chegou = 0;
  fase(i, "conferindo");
  diario("payloads: %s: ao iniciar: conferindo o arquivo guardado (SHA-256)", it->id);
  if(!arquivo_confere(it, &elf)) falhou(i, "o arquivo guardado nao confere com o SHA-256 da versao instalada (instale de novo)");
  else
    for(;;) {
      if(ks) {
        int k = kstuff_ativo();
        if(!gravou && kstuff_carregou_neste_boot()) {
          r = AL_BOOT;
          break;
        }
        if(k == 1) {
          r = AL_RODANDO;
          break;
        }
        if(k != 0) {
          snprintf(motivo, tam, "nao deu para saber se o kstuff ja esta ativo; carregue manualmente");
          r = AL_ERRO;
          break;
        }
        if(!gravou) {
          if(kstuff_gravar_marcador()) {
            snprintf(motivo, tam, "nao gravou o marcador do boot do kstuff: nao mandado");
            r = AL_ERRO;
            break;
          }
          gravou = 1;
        }
      } else if(rodando_agora(i)) {
        r = AL_RODANDO;
        break;
      }
      int sem = 0;
      int a = aplicar_ex(i, &elf, &sem, 0);
      if(a != -2) {
        chegou = 1;
        r = a == 0 ? AL_ENVIADO : AL_ERRO;
        break;
      }
      if(mono_s() >= limite) {
        snprintf(motivo, tam, "o elfldr (porta 9021) nao respondeu em %d s", AUTOLOAD_ESPERA_S);
        r = AL_ERRO;
        break;
      }
      sleep(2);
    }
  buf_free(&elf);
  if(gravou && !chegou) kstuff_apagar_marcador();
  pthread_mutex_lock(&g_trava);
  g_ocupado = 0;
  g_est[i].fase[0] = 0;
  if(r == AL_ERRO && !motivo[0]) snprintf(motivo, tam, "%s", g_est[i].erro);
  pthread_mutex_unlock(&g_trava);
  return r;
}

/* resultado de autoload_enviar na pagina (AL_ENVIADO fica com quem chamou) */
static void autoload_resultado(int i, int r, const char *motivo) {
  if(r == AL_BOOT) {
    auto_marca(i, "boot", NULL);
    diario("payloads: %s: o glibren ja o mandou neste boot: nao repete", ITENS[i].id);
  } else if(r == AL_RODANDO) {
    auto_marca(i, "ja_rodando", NULL);
    diario("payloads: %s: ja esta rodando: nao carregado ao iniciar", ITENS[i].id);
  } else auto_marca(i, "erro", motivo);
}

/* kstuff primeiro e com regras proprias (carregar duas vezes pode travar o kernel): so com a sonda dizendo claramente
   "nao carregado" e sem o marcador deste boot (conferidos aqui e de novo logo antes do envio); depois espera ele
   confirmar que ficou ativo. */
static void autoload_kstuff(int i, long long limite) {
  const item_t *it = &ITENS[i];
  char motivo[300];
  if(titan_rodando(NULL, 0, 1)) {   /* 0.9.43: o TITAN ja ligou o kstuff-lite dele */
    auto_marca(i, "erro", TITAN_MOTIVO);
    return;
  }
  if(kstuff_carregou_neste_boot()) {
    autoload_resultado(i, AL_BOOT, NULL);
    return;
  }
  int k = kstuff_ativo();
  if(k == 1) {
    autoload_resultado(i, AL_RODANDO, NULL);
    return;
  }
  if(k < 0) {
    auto_marca(i, "erro", "nao deu para saber se o kstuff ja esta ativo; carregue manualmente");
    return;
  }
  auto_marca(i, "esperando", NULL);
  int r = autoload_enviar(i, limite, motivo, sizeof motivo);
  if(r != AL_ENVIADO) {
    autoload_resultado(i, r, motivo);
    return;
  }
  long long fim = mono_s() + KSTUFF_CONFIRMA_S;
  for(long long ini = mono_s();; sleep(1)) {
    if(kstuff_ativo() == 1) {
      auto_marca(i, "carregado", NULL);
      diario("payloads: %s: carregado ao iniciar o glibren (ativo depois de %lld s)", it->id, mono_s() - ini);
      return;
    }
    if(mono_s() >= fim) break;
  }
  snprintf(motivo, sizeof motivo, "enviado, mas o kstuff nao confirmou que ficou ativo em %d s", KSTUFF_CONFIRMA_S);
  auto_marca(i, "erro", motivo);
}

static void autoload_item(int i, long long limite) {
  const item_t *it = &ITENS[i];
  char motivo[300];
  if(briga_com_titan(it) && titan_rodando(NULL, 0, 1)) {   /* 0.9.43: o TITAN ja ligou o ShadowMount+ dele */
    auto_marca(i, "erro", TITAN_MOTIVO);
    return;
  }
  if(it->sonda == SONDA_KRAKEN) {
    /* montadores exclusivos: o kraken-mount fica de fora se o ShadowKraken tambem estiver marcado (config editada a mao) */
    if(config_payload_autoload("shadowkraken")) {
      auto_marca(i, "erro", "o ShadowKraken tambem esta marcado para carregar ao iniciar (so um montador)");
      return;
    }
    /* com o ShadowMount+ (ou o ShadowKraken, mesmo processo) no ar o kraken-mount so ficaria esperando */
    int api, proc;
    char v[64];
    pthread_mutex_lock(&g_trava_smp);
    g_smp.em = 0;   /* agora, sem o cache */
    pthread_mutex_unlock(&g_trava_smp);
    smp_estado(&api, &proc, v, sizeof v);
    if(api || proc) {
      auto_marca(i, "erro", versao_shadowkraken(v) ? "o ShadowKraken ja esta rodando: o kraken-mount ficaria esperando sem montar nada"
                                                   : "o ShadowMount+ ja esta rodando: o kraken-mount ficaria esperando sem montar nada");
      return;
    }
  }
  if(rodando_agora(i)) {   /* nunca duas vezes (o ShadowKraken: "Rodando agora" pela API dele, mesmo processo do SMP) */
    autoload_resultado(i, AL_RODANDO, NULL);
    return;
  }
  auto_marca(i, "esperando", NULL);
  int r = autoload_enviar(i, limite, motivo, sizeof motivo);
  if(r != AL_ENVIADO) {
    autoload_resultado(i, r, motivo);
    return;
  }
  auto_marca(i, "carregado", NULL);
  diario("payloads: %s: carregado ao iniciar o glibren", it->id);
}

/* Ordem: 0 = kstuff; 1 = montador (ShadowKraken ou kraken-mount: os jogos montam cedo); 2 = os outros (Dump Forge,
   BlueV, MemDBG), na ordem da pagina. */
static int autoload_ordem(const item_t *it) {
  if(it->sonda == SONDA_KSTUFF) return 0;
  if(it->sonda == SONDA_SHADOWKRAKEN || it->sonda == SONDA_KRAKEN) return 1;
  return 2;
}

/* Uma rodada por glibren, um item por vez: o kstuff (os outros so depois de ele confirmar ou desistir), o montador e os
   outros. Prazo do elfldr com o relogio monotonico. */
static void *autoload_trabalho(void *arg) {
  (void)arg;
  pthread_once(&g_migrou, migrar_legado);
  long long limite = mono_s() + AUTOLOAD_ESPERA_S;
  for(int ordem = 0; ordem < 3; ordem++)
    for(int i = 0; i < N_ITENS; i++) {
      const item_t *it = &ITENS[i];
      if(autoload_ordem(it) != ordem || !autoload_pode(it) || !config_payload_autoload(it->id)) continue;
      if(!instalado(it)) {
        diario("payloads: %s: marcado para carregar ao iniciar, mas nao esta instalado: nada feito", it->id);
        continue;
      }
      if(ordem == 0) autoload_kstuff(i, limite);
      else autoload_item(i, limite);
    }
  return NULL;
}

/* 0.9.43: vigia do TITAN CORE. Ele pode subir antes ou depois do glibren (autoload de outro gerenciador), entao o
   glibren olha a porta 8097 a cada TITAN_VIGIA_S (so um GET local; sem nada na porta a conexao e recusada na hora).
   Se o TITAN estiver rodando E o glibren tiver um montador ou o kstuff ligado (rodando agora ou marcado para carregar
   ao iniciar), avisa uma vez na tela do PS5 e no diario; avisa de novo so se o TITAN sair e voltar.
   PC: GLR_TESTE_TITAN_VIGIA_S (segundos). */
#define TITAN_VIGIA_S 30

static int titan_vigia_s(void) {
#ifndef __PROSPERO__
  const char *v = getenv("GLR_TESTE_TITAN_VIGIA_S");
  if(v && atoi(v) > 0) return atoi(v);
#endif
  return TITAN_VIGIA_S;
}

/* O que do glibren briga com o TITAN agora ("" = nada): ShadowKraken rodando, ou marcado para carregar ao iniciar
   (ShadowKraken, kraken-mount, kstuff) */
static void titan_briga(char *o, size_t tam) {
  o[0] = 0;
  int api, proc;
  char v[64];
  smp_estado(&api, &proc, v, sizeof v);
  if(api && versao_shadowkraken(v)) snprintf(o, tam, "o ShadowKraken esta rodando");
  for(int i = 0; i < N_ITENS && !o[0]; i++)
    if(briga_com_titan(&ITENS[i]) && config_payload_autoload(ITENS[i].id) && instalado(&ITENS[i]))
      snprintf(o, tam, "o %s esta marcado no glibren para carregar ao iniciar", ITENS[i].nome);
}

static void *titan_vigia(void *arg) {
  (void)arg;
  int avisou = 0;
  for(;;) {
    sleep((unsigned)titan_vigia_s());
    char v[64], o[160];
    if(!titan_rodando(v, sizeof v, 1)) {
      avisou = 0;
      continue;
    }
    if(avisou) continue;
    titan_briga(o, sizeof o);
    if(!o[0]) continue;
    avisou = 1;
    diario("payloads: TITAN CORE v%s rodando junto com o glibren: %s (o TITAN ja carrega o kstuff e o ShadowMount+ dele)", v, o);
    notificar("Game Library Renamer: o TITAN CORE esta rodando e %s. Use so um: tire o TITAN do carregamento automatico e reinicie o PS5.", o);
  }
  return NULL;
}

void payloads_autoload_iniciar(void) {
  static int iniciou;
  if(iniciou) return;
  iniciou = 1;
  if(criar_thread(titan_vigia, NULL, NULL)) diario("payloads: vigia do TITAN CORE: nao iniciou");
  int algum = 0;
  for(int i = 0; i < N_ITENS && !algum; i++) algum = autoload_pode(&ITENS[i]) && config_payload_autoload(ITENS[i].id);
  if(!algum) return;
  if(criar_thread(autoload_trabalho, NULL, NULL)) diario("payloads: carregar ao iniciar: nao iniciou");
}

/* POST /api/payloads/autoload (id, ligado = 1|0): a chave "Carregar ao iniciar o glibren" (config.ini payload_autoload).
   Montadores exclusivos: ligar o kraken-mount desliga o ShadowKraken e vice-versa ("desligou" = o nome do outro). */
void payloads_rota_autoload(pedido_t *p) {
  char id[64] = "", v[8] = "";
  param(p->corpo, "id", 0, id, sizeof id);
  param(p->corpo, "ligado", 0, v, sizeof v);
  int i = achar(id);
  if(i < 0) {
    responder_erro(p, 404, "payload_fora_da_lista", "este payload nao esta na lista do glibren", NULL);
    return;
  }
  if(!autoload_pode(&ITENS[i])) {
    responder_erro(p, 400, "payload_autoload_proibido", "este payload nao pode ser carregado sozinho ao iniciar", NULL);
    return;
  }
  if(strcmp(v, "1") && strcmp(v, "0")) {
    responder_erro(p, 400, "requisicao_invalida", "ligado = 1 ou 0", NULL);
    return;
  }
  if(fps_agente_ps5(p->agente) || p->local) {
    responder_erro(p, 403, "payload_so_celular", "payloads de teste so pelo celular ou PC pareado", NULL);
    return;
  }
  const char *outro = NULL;
  if(v[0] == '1' && ITENS[i].sonda == SONDA_KRAKEN) outro = "shadowkraken";
  if(v[0] == '1' && ITENS[i].sonda == SONDA_SHADOWKRAKEN) outro = "kraken-mount";
  int desligou = -1;
  if(outro && config_payload_autoload(outro)) {
    if(config_gravar_payload_autoload(outro, 0)) {
      responder_erro(p, 500, "payload_erro", "nao gravou o config.ini", NULL);
      return;
    }
    desligou = achar(outro);
    diario("payloads: %s: carregar ao iniciar desligado (so um montador)", outro);
  }
  if(config_gravar_payload_autoload(ITENS[i].id, v[0] == '1')) {
    responder_erro(p, 500, "payload_erro", "nao gravou o config.ini", NULL);
    return;
  }
  diario("payloads: %s: carregar ao iniciar %s", ITENS[i].id, v[0] == '1' ? "ligado" : "desligado");
  buf_t b = {0};
  buf_fmt(&b, "{\"ok\":true,\"autoload\":%s,\"desligou\":", v[0] == '1' ? "true" : "false");
  buf_json(&b, desligou >= 0 ? ITENS[desligou].nome : "");
  buf_str(&b, "}");
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* ------------------------------------------------------------------ 0.9.41: instalar de arquivo (ShadowKraken, kstuff) */

#define MAX_ACHADOS 50
#define MAX_VISTOS 5000


/* nome com o padrao (sem diferenca de maiusculas) e terminado em .elf */
/* um .elf qualquer (o usuario escolhe qualquer um para o item): termina em .elf, nome simples */
static int nome_elf_ok(const char *nome) {
  size_t n = strlen(nome);
  if(n < 5 || n >= 128 || strcasecmp(nome + n - 4, ".elf")) return 0;
  for(const char *c = nome; *c; c++)
    if((unsigned char)*c < ' ' || *c == '/' || *c == '\\') return 0;
  return 1;
}

/* sugerido para o item: o nome tem o padrao (sem diferenca de maiusculas: "Kstuff-NG_v1.00.elf") */
static int nome_sugerido(const item_t *it, const char *nome) {
  size_t n = strlen(nome), k = strlen(it->arq_padrao);
  for(size_t a = 0; a + k <= n; a++)
    if(!strncasecmp(nome + a, it->arq_padrao, k)) return 1;
  return 0;
}

static int ler_elf(const item_t *it, const char *origem, buf_t *b, info_t *novo, char *erro, size_t tam_erro);
static int conferir_elf(const item_t *it, const buf_t *b, const char *origem, info_t *novo, char *erro, size_t tam_erro);
static const char *comparar_instalado(const item_t *it, const info_t *f);

typedef struct {
  char caminho[1024];
  long long tamanho;
  int sugerido;
} achado_t;

typedef struct {
  const item_t *it;
  achado_t *lista;
  int achados, vistos;
  char nossa[512], pm[256];
} busca_t;

static void procurar_em(busca_t *bs, const char *dir, int nivel, int max) {
  if(bs->achados >= MAX_ACHADOS || bs->vistos >= MAX_VISTOS || !strcmp(dir, bs->nossa)) return;
  if(nivel > 0 && bs->pm[0] && !strcmp(dir, bs->pm)) return;   /* a do payload manager ja foi lida primeiro */
  DIR *d = opendir(dir);
  if(!d) return;
  struct dirent *e;
  while((e = readdir(d)) && bs->achados < MAX_ACHADOS && bs->vistos < MAX_VISTOS) {
    bs->vistos++;
    if(e->d_name[0] == '.') continue;
    char c[1024];
    snprintf(c, sizeof c, "%s/%s", dir, e->d_name);
    struct stat st;
    if(lstat(c, &st)) continue;
    if(S_ISDIR(st.st_mode) && nivel < max) procurar_em(bs, c, nivel + 1, max);
    else if(S_ISREG(st.st_mode) && nome_elf_ok(e->d_name) && (unsigned long long)st.st_size <= bs->it->gh_max) {
      achado_t *a = &bs->lista[bs->achados++];
      snprintf(a->caminho, sizeof a->caminho, "%s", c);
      a->tamanho = (long long)st.st_size;
      a->sugerido = nome_sugerido(bs->it, e->d_name);
    }
  }
  closedir(d);
}

/* 0.9.41 (revisao): .elf nao sugerido: so o barato (regular, sem link, tamanho, magia ELF), sem ler o arquivo inteiro.
   "" = serve; senao o motivo. */
static const char *elf_basico(const item_t *it, const char *c) {
  int fd = open(c, O_RDONLY | O_NOFOLLOW);
  struct stat st;
  unsigned char m[4] = {0};
  const char *e = "";
  if(fd < 0 || fstat(fd, &st) || !S_ISREG(st.st_mode)) e = "nao abriu o arquivo";
  else if(st.st_size < 1024 || (unsigned long long)st.st_size > it->gh_max) e = "tamanho fora do limite";
  else if(read(fd, m, 4) != 4 || memcmp(m, "\x7f" "ELF", 4)) e = "nao e um ELF";
  if(fd >= 0) close(fd);
  return e;
}

static int g_buscando;   /* 0.9.41 (revisao): uma busca de arquivos por vez (le discos inteiros) */

/* GET /api/payloads/arquivos?id=: TODOS os .elf da pasta do payload manager e dos discos (ate 2 pastas para dentro), os
   com o nome do item primeiro ("sugerido"). Revisao 0.9.41: so os sugeridos sao lidos inteiros (versao pelo marcador,
   SHA-256 e o que ele e perto do instalado); os outros so tem a conferencia barata ("nao_conferido": o SHA-256 e feito
   ao instalar). Uma busca por vez: a segunda recebe 409 "payload_busca_ocupada". Leitura livre; nada e renomeado nem
   apagado na origem. PC: GLR_TESTE_BUSCA_ESPERA_MS segura a busca (teste da segunda). */
void payloads_rota_arquivos(pedido_t *p) {
  char id[64] = "";
  param(p->query, "id", 0, id, sizeof id);
  int i = achar(id);
  if(i < 0 || !ITENS[i].de_arquivo) {
    responder_erro(p, 404, "payload_fora_da_lista", "este payload nao aceita instalar de arquivo", NULL);
    return;
  }
  pthread_mutex_lock(&g_trava);
  int ocupada = g_buscando;
  g_buscando = 1;
  pthread_mutex_unlock(&g_trava);
  if(ocupada) {
    responder_erro(p, 409, "payload_busca_ocupada", "outra busca de arquivos esta andando: espere ela terminar", NULL);
    return;
  }
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_BUSCA_ESPERA_MS")) usleep((useconds_t)atoi(getenv("GLR_TESTE_BUSCA_ESPERA_MS")) * 1000);
#endif
  raiz_t r[16];
  int n = raizes(r, 16);
  achado_t *lista = calloc(MAX_ACHADOS, sizeof *lista);
  if(!lista) {
    pthread_mutex_lock(&g_trava);
    g_buscando = 0;
    pthread_mutex_unlock(&g_trava);
    responder_erro(p, 500, "payload_erro", "sem memoria", NULL);
    return;
  }
  busca_t bs = {&ITENS[i], lista, 0, 0, "", ""};
  pasta(bs.nossa, sizeof bs.nossa);
  pldmgr_dir(bs.pm, sizeof bs.pm);
  for(int k = 0; k < n; k++) procurar_em(&bs, r[k].dir, 0, r[k].nivel);
  buf_t b = {0};
  buf_str(&b, "{\"ok\":true,\"padrao\":");
  buf_json(&b, ITENS[i].arq_padrao);
  buf_str(&b, ",\"arquivos\":[");
  int saidos = 0;
  for(int vez = 1; vez >= 0; vez--)   /* sugeridos primeiro */
    for(int k = 0; k < bs.achados; k++) {
      const achado_t *a = &lista[k];
      if(a->sugerido != vez) continue;
      info_t f;
      char erro[200] = "";
      int bom;
      memset(&f, 0, sizeof f);
      if(a->sugerido) {   /* lido inteiro: versao, SHA-256, comparacao */
        buf_t dados = {0};
        bom = !ler_elf(&ITENS[i], a->caminho, &dados, &f, erro, sizeof erro);
        buf_free(&dados);
      } else {
        snprintf(erro, sizeof erro, "%s", elf_basico(&ITENS[i], a->caminho));
        bom = !erro[0];
      }
      buf_str(&b, saidos++ ? ",{\"caminho\":" : "{\"caminho\":");
      buf_json(&b, a->caminho);
      buf_fmt(&b, ",\"tamanho\":%lld,\"fonte\":\"%s\",\"sugerido\":%s,\"versao\":", a->tamanho, fonte_de(a->caminho),
              a->sugerido ? "true" : "false");
      buf_json(&b, bom ? f.versao : "");
      buf_str(&b, ",\"sha256\":");
      buf_json(&b, bom ? f.sha256 : "");
      buf_str(&b, ",\"estado\":");
      buf_json(&b, !bom ? "invalido" : a->sugerido ? comparar_instalado(&ITENS[i], &f) : "nao_conferido");
      buf_str(&b, ",\"erro\":");
      buf_json(&b, bom ? "" : erro);
      buf_str(&b, "}");
    }
  buf_fmt(&b, "],\"cortado\":%s}", bs.achados >= MAX_ACHADOS || bs.vistos >= MAX_VISTOS ? "true" : "false");
  free(lista);
  pthread_mutex_lock(&g_trava);
  g_buscando = 0;
  pthread_mutex_unlock(&g_trava);
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* kstuff: "kstuff" (sem diferenca de maiusculas) seguido, em ate 12 caracteres de letras/-/_/espaco, de "v1.00" ou "1.00"
   (o primeiro achado; sem marcador = "" e a pagina mostra o nome original + SHA-256). */
static void marcador_kstuff(const char *d, size_t n, char *saida, size_t tam) {
  saida[0] = 0;
  for(size_t k = 0; k + 6 <= n; k++) {
    if(strncasecmp(d + k, "kstuff", 6)) continue;
    size_t a = k + 6, lim = a + 12;
    while(a < n && a < lim && ((d[a] >= 'a' && d[a] <= 'z') || (d[a] >= 'A' && d[a] <= 'Z') || d[a] == '-' || d[a] == '_' || d[a] == ' ') &&
          !((d[a] == 'v' || d[a] == 'V') && a + 1 < n && d[a + 1] >= '0' && d[a + 1] <= '9'))
      a++;
    if(a < n && (d[a] == 'v' || d[a] == 'V')) a++;
    size_t f = a;
    int pontos = 0;
    while(f < n && ((d[f] >= '0' && d[f] <= '9') || (d[f] == '.' && f + 1 < n && d[f + 1] >= '0' && d[f + 1] <= '9'))) pontos += d[f++] == '.';
    if(f > a && pontos >= 1 && f - a < tam && f - a < 24 && d[a] >= '0' && d[a] <= '9') {
      memcpy(saida, d + a, f - a);
      saida[f - a] = 0;
      return;
    }
  }
}

/* Marcador de versao dentro do ELF do ShadowKraken ("1.00-Dev.7-pristmc"): o mais comprido em volta de "-Dev." */
static void marcador_versao(const char *d, size_t n, char *saida, size_t tam) {
  saida[0] = 0;
  size_t melhor = 0;
  static const char OK_FIM[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._+-";
  for(size_t k = 0; k + 5 <= n; k++) {
    if(memcmp(d + k, "-Dev.", 5)) continue;
    size_t a = k;
    while(a > 0 && ((d[a - 1] >= '0' && d[a - 1] <= '9') || d[a - 1] == '.')) a--;
    size_t f = k + 5;
    while(f < n && d[f] && strchr(OK_FIM, d[f])) f++;
    size_t len = f - a;
    if(a == k || !(d[a] >= '0' && d[a] <= '9') || len >= tam || len >= 64 || len <= melhor) continue;
    melhor = len;
    memcpy(saida, d + a, len);
    saida[len] = 0;
  }
  if(saida[0] && !gh_nome_ok(saida, tam)) saida[0] = 0;
}

/* Compara versoes pelos numeros na ordem ("1.00-Dev.7-pristmc" -> 1, 0, 7; "1.01" -> 1, 1). >0 = a mais nova. */
static int comparar_versao(const char *a, const char *b) {
  while(*a || *b) {
    while(*a && (*a < '0' || *a > '9')) a++;
    while(*b && (*b < '0' || *b > '9')) b++;
    if(!*a || !*b) return *a ? 1 : *b ? -1 : 0;
    unsigned long x = strtoul(a, (char **)&a, 10), y = strtoul(b, (char **)&b, 10);
    if(x != y) return x > y ? 1 : -1;
  }
  return 0;
}

/* Le e confere um .elf de origem (regular, sem link, tamanho, ELF) e acha o SHA-256 e a versao (marcador). 0 = ok. */
static int ler_elf(const item_t *it, const char *origem, buf_t *b, info_t *novo, char *erro, size_t tam_erro) {
  int fd = open(origem, O_RDONLY | O_NOFOLLOW);
  struct stat st;
  if(fd < 0 || fstat(fd, &st) || !S_ISREG(st.st_mode)) {
    if(fd >= 0) close(fd);
    snprintf(erro, tam_erro, "nao abriu o arquivo");
    return -1;
  }
  if(st.st_size < 1024 || (unsigned long long)st.st_size > it->gh_max) {
    close(fd);
    snprintf(erro, tam_erro, "tamanho fora do limite (%lld bytes)", (long long)st.st_size);
    return -1;
  }
  char bloco[64 * 1024];
  ssize_t r;
  while((r = read(fd, bloco, sizeof bloco)) > 0 && b->n <= it->gh_max) buf_add(b, bloco, (size_t)r);
  close(fd);
  if(r < 0 || b->n != (size_t)st.st_size) {
    snprintf(erro, tam_erro, "erro ao ler o arquivo");
    return -1;
  }
  return conferir_elf(it, b, origem, novo, erro, tam_erro);
}

/* Confere o .elf ja lido (tamanho, ELF, nao e o glibren, marcador do ShadowKraken) e acha o SHA-256 e a versao. origem =
   o caminho no PS5 ou, no envio pelo celular/PC (0.9.45), o nome do arquivo no aparelho. 0 = ok. */
static int conferir_elf(const item_t *it, const buf_t *b, const char *origem, info_t *novo, char *erro, size_t tam_erro) {
  if(b->n < 1024 || b->n > it->gh_max) {
    snprintf(erro, tam_erro, "tamanho fora do limite (%zu bytes)", b->n);
    return -1;
  }
  if(memcmp(b->d, "\x7f" "ELF", 4)) {
    snprintf(erro, tam_erro, "nao e um ELF");
    return -1;
  }
  sha256_t s;
  uint8_t resumo[32];
  sha256_iniciar(&s);
  sha256_atualizar(&s, b->d, b->n);
  sha256_final(&s, resumo);
  memset(novo, 0, sizeof *novo);
  sha256_hex(resumo, novo->sha256);
  /* 0.9.41 (revisao): o proprio glibren nunca entra num item (ciclo: o glibren novo derrubaria este e o carregar ao
     iniciar mandaria de novo) */
  if(eh_glibren(b->d, b->n)) {
    snprintf(erro, tam_erro, "este arquivo e o proprio glibren, nao o %s", it->nome);
    return -1;
  }
  if(it->sonda == SONDA_SHADOWKRAKEN) {
    marcador_versao(b->d, b->n, novo->versao, sizeof novo->versao);
    if(!novo->versao[0]) {   /* 0.9.41 (revisao): no lugar do ShadowKraken so um ELF com o marcador de versao dele */
      snprintf(erro, tam_erro, "sem o marcador de versao do ShadowKraken (ex.: 1.00-Dev.7-pristmc): nao parece o ShadowKraken");
      return -1;
    }
  } else if(it->sonda == SONDA_KSTUFF) marcador_kstuff(b->d, b->n, novo->versao, sizeof novo->versao);
  if(!novo->versao[0] || !gh_nome_ok(novo->versao, sizeof novo->versao)) snprintf(novo->versao, sizeof novo->versao, "arquivo");
  const char *nome = strrchr(origem, '/');
  snprintf(novo->asset, sizeof novo->asset, "%s", nome ? nome + 1 : origem);
  snprintf(novo->origem, sizeof novo->origem, "%s", origem);
  novo->tamanho = b->n;
  return 0;
}

/* Este arquivo x o instalado: "nao_instalado", "igual" (mesmo SHA-256), "mais_nova"/"mais_velha" (pelo marcador de
   versao, quando os dois tem) ou "diferente" (sem versao para comparar). */
static const char *comparar_instalado(const item_t *it, const info_t *f) {
  info_t inst;
  if(info_ler(it, 0, &inst)) return "nao_instalado";
  if(!strcmp(inst.sha256, f->sha256)) return "igual";
  if(strcmp(inst.versao, "arquivo") && strcmp(f->versao, "arquivo")) {
    int c = comparar_versao(f->versao, inst.versao);
    if(c) return c > 0 ? "mais_nova" : "mais_velha";
  }
  return "diferente";
}

/* Le, confere (ELF, tamanho) e copia para a pasta de payloads com o NOME FIXO do item (shadowkraken.elf, kstuff.elf: o
   autoinicio e o Ativar apontam sempre para ele, nunca para a origem, cujo nome muda a cada versao). Troca atomica
   (.tmp + fsync + rename); a instalada (conferida) vira a .anterior ("Voltar"). */
static int gravar_elf(int i, const buf_t *b, const info_t *novo, char *erro, size_t tam_erro);
static int instalar_arquivo(int i, const char *origem, info_t *novo, char *erro, size_t tam_erro) {
  buf_t b = {0};
  int res = ler_elf(&ITENS[i], origem, &b, novo, erro, tam_erro) ? -1 : gravar_elf(i, &b, novo, erro, tam_erro);
  buf_free(&b);
  return res;
}

/* 0.9.45: a gravacao do instalar_arquivo, separada para o envio pelo celular/PC usar o mesmo caminho */
static int gravar_elf(int i, const buf_t *b, const info_t *novo, char *erro, size_t tam_erro) {
  const item_t *it = &ITENS[i];
  char p[512], arq[600], tmp[620], info[600], ant[620], ant_info[620], hex[65];
  struct stat st;
  snprintf(hex, sizeof hex, "%s", novo->sha256);
  pasta(p, sizeof p);
  caminho(it, NULL, arq, sizeof arq);
  caminho(it, ".info", info, sizeof info);
  caminho(it, ".anterior.elf", ant, sizeof ant);
  caminho(it, ".anterior.info", ant_info, sizeof ant_info);
  snprintf(tmp, sizeof tmp, "%s.tmp", arq);
  if(mkdir_p(p)) {
    snprintf(erro, tam_erro, "nao criou a pasta %s", p);
    return -1;
  }
  unlink(tmp);
  int out = open(tmp, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644);
  int ok = out >= 0;
  for(size_t feitos = 0; ok && feitos < b->n;) {
    ssize_t w = write(out, b->d + feitos, b->n - feitos);
    if(w <= 0) ok = 0;
    else feitos += (size_t)w;
  }
  if(out >= 0) {
    ok = ok && !fsync(out);
    ok = !close(out) && ok;
  }
  if(!ok || !arquivo_confere_em(tmp, hex, novo->tamanho, NULL)) {   /* o que ficou no disco confere antes de trocar */
    unlink(tmp);
    snprintf(erro, tam_erro, ok ? "a copia gravada nao confere com o SHA-256 da origem" : "erro ao gravar no PS5");
    return -1;
  }
  info_t atual;
  if(!lstat(arq, &st)) {
    if(!info_ler(it, 0, &atual) && arquivo_confere(it, NULL) && strcmp(atual.sha256, hex) && !rename(arq, ant) && !info_gravar(ant_info, &atual))
      diario("payloads: %s: %s guardada como anterior", it->id, atual.versao);
    else unlink(arq);
  }
  if(rename(tmp, arq) || info_gravar(info, novo)) {
    unlink(tmp);
    snprintf(erro, tam_erro, "nao guardou o arquivo");
    return -1;
  }
  return 0;
}

/* 0.9.45: POST /api/payloads/enviar?id=&nome= com o .elf inteiro no corpo: "Enviar do celular/PC" (pedido do dono: mandar
   as versoes do ShadowKraken baixadas no celular sem copiar para um disco do PS5). Mesmas regras e conferencias do
   "Instalar de arquivo" (pareamento + X-GLR, so celular/PC, nome .elf, ELF, tamanho, nao e o glibren, marcador do
   ShadowKraken) e a mesma gravacao (nome fixo, SHA-256, a instalada vira a anterior). O corpo vai ate 40 MB (http.c). */
void payloads_rota_enviar(pedido_t *p) {
  char id[64] = "", nome[160] = "", origem[200];
  param(p->query, "id", 0, id, sizeof id);
  param(p->query, "nome", 0, nome, sizeof nome);
  int i = achar(id);
  if(i < 0 || !ITENS[i].de_arquivo) {
    responder_erro(p, 404, "payload_fora_da_lista", "este payload nao aceita instalar de arquivo", NULL);
    return;
  }
  if(fps_agente_ps5(p->agente) || p->local) {
    responder_erro(p, 403, "payload_so_celular", "payloads de teste so pelo celular ou PC pareado", NULL);
    return;
  }
  if(!nome_elf_ok(nome)) {
    responder_erro(p, 400, "payload_arquivo_nome", "escolha um arquivo .elf", NULL);
    return;
  }
  const item_t *it = &ITENS[i];
  snprintf(origem, sizeof origem, "celular/PC: %s", nome);
  buf_t b = {.d = p->corpo, .n = p->corpo ? p->corpo_n : 0};
  info_t novo;
  char erro[200] = "";
  if(conferir_elf(it, &b, origem, &novo, erro, sizeof erro)) {
    diario("payloads: %s: envio recusado: %s (%s, %zu bytes)", it->id, erro, nome, b.n);
    responder_erro(p, 400, "payload_arquivo_erro", erro, NULL);
    return;
  }
  snprintf(novo.asset, sizeof novo.asset, "%s", nome);   /* o conferir_elf tira o nome da origem pela ultima "/" */
  pthread_mutex_lock(&g_trava);
  if(g_ocupado) {
    pthread_mutex_unlock(&g_trava);
    responder_erro(p, 409, "payload_ocupado", "outro payload esta sendo baixado ou ativado: espere", NULL);
    return;
  }
  g_ocupado = 1;
  snprintf(g_est[i].fase, sizeof g_est[i].fase, "conferindo");
  pthread_mutex_unlock(&g_trava);
  int res = gravar_elf(i, &b, &novo, erro, sizeof erro);
  pthread_mutex_lock(&g_trava);
  g_ocupado = 0;
  g_est[i].fase[0] = 0;
  g_est[i].cache_tam = -1;
  if(!res) g_est[i].erro[0] = 0;
  pthread_mutex_unlock(&g_trava);
  if(res) {
    diario("payloads: %s: envio recusado: %s (%s)", it->id, erro, nome);
    responder_erro(p, 400, "payload_arquivo_erro", erro, NULL);
    return;
  }
  diario("payloads: %s: instalado pelo celular/PC: %s (versao %s, %llu bytes, sha256 %s)", it->id, nome, novo.versao, novo.tamanho, novo.sha256);
  buf_t r = {0};
  buf_str(&r, "{\"ok\":true,\"versao\":");
  buf_json(&r, novo.versao);
  buf_str(&r, ",\"nome\":");
  buf_json(&r, novo.asset);
  buf_fmt(&r, ",\"fonte\":\"celular\",\"tamanho\":%llu,\"sha256\":", novo.tamanho);
  buf_json(&r, novo.sha256);
  buf_str(&r, "}");
  responder_json(p, 200, &r);
  buf_free(&r);
}

int payloads_caminho_de_disco(const char *origem) {
  char real[PATH_MAX], nossa[512];
  raiz_t r[16];
  int n = raizes(r, 16), dentro = 0;
  pasta(nossa, sizeof nossa);
  if(origem[0] != '/' || !strrchr(origem, '/') || !realpath(origem, real) || strcmp(real, origem)) return 0;
  for(int k = 0; k < n && !dentro; k++) {
    size_t t = strlen(r[k].dir);
    dentro = !strncmp(origem, r[k].dir, t) && origem[t] == '/';
  }
  if(dentro && !strncmp(origem, nossa, strlen(nossa)) && origem[strlen(nossa)] == '/') dentro = 0;
  return dentro;
}

/* POST /api/payloads/arquivo (id, caminho): "Instalar de arquivo" - um .elf de um disco do PS5 (nome com o padrao do
   item) copiado para a pasta de payloads do glibren. Mesmas regras do remover (pareamento + X-GLR, so celular/PC). */
void payloads_rota_arquivo(pedido_t *p) {
  char id[64] = "", origem[1024] = "", real[PATH_MAX];
  param(p->corpo, "id", 0, id, sizeof id);
  param(p->corpo, "caminho", 0, origem, sizeof origem);
  int i = achar(id);
  if(i < 0 || !ITENS[i].de_arquivo) {
    responder_erro(p, 404, "payload_fora_da_lista", "este payload nao aceita instalar de arquivo", NULL);
    return;
  }
  if(fps_agente_ps5(p->agente) || p->local) {
    responder_erro(p, 403, "payload_so_celular", "payloads de teste so pelo celular ou PC pareado", NULL);
    return;
  }
  const item_t *it = &ITENS[i];
  const char *nome = strrchr(origem, '/');
  /* caminho absoluto, sem links nem "..": o realpath tem de ser ele mesmo, dentro de um dos discos e fora da nossa pasta */
  int dentro = 0;
  char nossa[512];
  raiz_t r[16];
  int n = raizes(r, 16);
  pasta(nossa, sizeof nossa);
  if(origem[0] == '/' && nome && realpath(origem, real) && !strcmp(real, origem))
    for(int k = 0; k < n && !dentro; k++) {
      size_t t = strlen(r[k].dir);
      dentro = !strncmp(origem, r[k].dir, t) && origem[t] == '/';
    }
  if(dentro && !strncmp(origem, nossa, strlen(nossa)) && origem[strlen(nossa)] == '/') dentro = 0;
  if(!dentro) {
    responder_erro(p, 400, "payload_arquivo_fora", "o arquivo tem de estar num disco do PS5 (/data, USB ou disco extra), sem links", NULL);
    return;
  }
  if(!nome_elf_ok(nome + 1)) {
    responder_erro(p, 400, "payload_arquivo_nome", "escolha um arquivo .elf", NULL);
    return;
  }
  pthread_mutex_lock(&g_trava);
  if(g_ocupado) {
    pthread_mutex_unlock(&g_trava);
    responder_erro(p, 409, "payload_ocupado", "outro payload esta sendo baixado ou ativado: espere", NULL);
    return;
  }
  g_ocupado = 1;
  snprintf(g_est[i].fase, sizeof g_est[i].fase, "conferindo");
  pthread_mutex_unlock(&g_trava);
  info_t novo;
  char erro[200] = "";
  int res = instalar_arquivo(i, origem, &novo, erro, sizeof erro);
  pthread_mutex_lock(&g_trava);
  g_ocupado = 0;
  g_est[i].fase[0] = 0;
  g_est[i].cache_tam = -1;
  if(!res) g_est[i].erro[0] = 0;
  pthread_mutex_unlock(&g_trava);
  if(res) {
    diario("payloads: %s: instalar de arquivo recusado: %s (%s)", it->id, erro, origem);
    responder_erro(p, 400, "payload_arquivo_erro", erro, NULL);
    return;
  }
  diario("payloads: %s: instalado de arquivo: %s (versao %s, %llu bytes, sha256 %s)", it->id, origem, novo.versao, novo.tamanho, novo.sha256);
  buf_t b = {0};
  buf_str(&b, "{\"ok\":true,\"versao\":");
  buf_json(&b, novo.versao);
  buf_str(&b, ",\"nome\":");
  buf_json(&b, novo.asset);
  buf_fmt(&b, ",\"fonte\":\"%s\",\"tamanho\":%llu,\"sha256\":", fonte_de(origem), novo.tamanho);
  buf_json(&b, novo.sha256);
  buf_str(&b, "}");
  responder_json(p, 200, &b);
  buf_free(&b);
}
