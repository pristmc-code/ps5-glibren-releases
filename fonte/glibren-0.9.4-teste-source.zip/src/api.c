/* Game Library Renamer (payload PS5) - rotas da API e arquivos servidos para a pagina.

A logica de nomes (codigo no nome, compactados, patch, nome novo, ShadowMountPlus) fica no JavaScript
da pagina; aqui ficam so o acesso ao disco do PS5 e a internet (que o navegador nao pode fazer por CORS).
*/
#include "api.h"

#include <dirent.h>
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "apps.h"
#include "arquivos.h"
#include "config.h"
#include "http.h"
#include "https.h"
#include "jogo_local.h"
#include "plataforma.h"
#include "relogio.h"
#include "tarefas.h"
#include "termico.h"
#include "discos.h"
#include "internet.h"

#include <sys/statvfs.h>
#include "web_icone.h"
#include "atualizacao.h"
#include "web_index.h"
#include "web_youtube.h"
#include "web_telacheia.h"
#include "web_temperatura.h"
#include "web_discos.h"
#include "web_internet.h"

#define URL_BASE "https://raw.githubusercontent.com/andshrew/PlayStation-Titles/main/All_Titles.tsv"
#define VALIDADE_BASE_S (24 * 3600)   /* a base e baixada de novo uma vez por dia */
#define MAX_BASE (64 * 1024 * 1024)
#define MAX_ICONE (2 * 1024 * 1024)
#define MAX_PAGINA (4 * 1024 * 1024)
#define MAX_CACHE (8 * 1024 * 1024)

int g_porta = 8765;

/* ------------------------------------------------------------------ base de titulos */

static pthread_mutex_t g_trava_base = PTHREAD_MUTEX_INITIALIZER;
static char g_base_situacao[16] = "carregando";
static char g_base_erro[256];

static void arquivo_dados(char *saida, size_t tam, const char *nome) {
  snprintf(saida, tam, "%s/%s", g_pasta_dados, nome);
}

static void *baixar_base(void *forcar) {
  char arquivo[600], tmp[610];
  struct stat st;
  arquivo_dados(arquivo, sizeof arquivo, "base_titulos.tsv");
  snprintf(tmp, sizeof tmp, "%s.tmp", arquivo);
  int tem = !stat(arquivo, &st) && st.st_size > 0;
  if(tem && !forcar && time(NULL) - st.st_mtime < VALIDADE_BASE_S) {
    pthread_mutex_lock(&g_trava_base);
    snprintf(g_base_situacao, sizeof g_base_situacao, "ok");
    pthread_mutex_unlock(&g_trava_base);
    return NULL;
  }
  pthread_mutex_lock(&g_trava_base);
  snprintf(g_base_situacao, sizeof g_base_situacao, tem ? "ok" : "baixando");
  pthread_mutex_unlock(&g_trava_base);

  buf_t b = {0};
  int status = https_get(URL_BASE, &b, MAX_BASE, 180);
  char erro[256] = "";
  if(status != 200) snprintf(erro, sizeof erro, "nao foi possivel baixar a base (%d)", status);
  else if(b.n < 8 || strncmp(b.d, "titleId\t", 8)) snprintf(erro, sizeof erro, "arquivo baixado nao tem o formato esperado");
  else {
    FILE *f = fopen(tmp, "wb");
    if(!f || fwrite(b.d, 1, b.n, f) != b.n || fclose(f) || rename(tmp, arquivo))
      snprintf(erro, sizeof erro, "nao foi possivel gravar a base (%s)", strerror(errno));
  }
  buf_free(&b);

  pthread_mutex_lock(&g_trava_base);
  snprintf(g_base_erro, sizeof g_base_erro, "%s", erro);
  tem = !stat(arquivo, &st) && st.st_size > 0;
  snprintf(g_base_situacao, sizeof g_base_situacao, tem ? "ok" : "indisponivel");
  pthread_mutex_unlock(&g_trava_base);
  return NULL;
}

void api_atualizar_base(int forcar) {
  criar_thread(baixar_base, forcar ? (void *)1 : NULL, NULL);
}

static void base_json(buf_t *b) {
  char arquivo[600];
  struct stat st;
  arquivo_dados(arquivo, sizeof arquivo, "base_titulos.tsv");
  pthread_mutex_lock(&g_trava_base);
  buf_str(b, "{\"situacao\":");
  buf_json(b, g_base_situacao);
  buf_str(b, ",\"erro\":");
  buf_json(b, g_base_erro);
  if(!stat(arquivo, &st)) buf_fmt(b, ",\"baixada_em\":%lld,\"tamanho\":%lld", (long long)st.st_mtime, (long long)st.st_size);
  buf_str(b, "}");
  pthread_mutex_unlock(&g_trava_base);
}

/* ------------------------------------------------------------------ icones */

static const struct {
  const char *ext, *tipo;
} TIPOS[] = {{".webp", "image/webp"}, {".jpg", "image/jpeg"}, {".png", "image/png"}};

static int codigo_valido(const char *c) {
  if(strlen(c) != 9) return 0;
  for(int i = 0; i < 4; i++) if(c[i] < 'A' || c[i] > 'Z') return 0;
  for(int i = 4; i < 9; i++) if(c[i] < '0' || c[i] > '9') return 0;
  return 1;
}

/* O CDN dos sites nao envia Content-Type: identifica a imagem pelos primeiros bytes. */
static int tipo_imagem(const buf_t *b) {
  const unsigned char *d = (const unsigned char *)b->d;
  if(b->n > 12 && !memcmp(d, "RIFF", 4) && !memcmp(d + 8, "WEBP", 4)) return 0;
  if(b->n > 3 && d[0] == 0xff && d[1] == 0xd8 && d[2] == 0xff) return 1;
  if(b->n > 8 && !memcmp(d, "\x89PNG\r\n\x1a\n", 8)) return 2;
  return -1;
}

/* "icones":["PPSA08329",...] - os ja guardados no PS5 (a tela so pede os outros depois dos detalhes). */
static void icones_json(buf_t *b) {
  char pasta[600];
  arquivo_dados(pasta, sizeof pasta, "icones");
  DIR *d = opendir(pasta);
  int n = 0;
  buf_str(b, "\"icones\":[");
  struct dirent *e;
  while(d && (e = readdir(d))) {
    char codigo[16];
    if(e->d_name[0] == '.' || strlen(e->d_name) < 9) continue;
    snprintf(codigo, sizeof codigo, "%.9s", e->d_name);
    if(!codigo_valido(codigo)) continue;
    buf_str(b, n++ ? "," : "");
    buf_json(b, codigo);
  }
  if(d) closedir(d);
  buf_fmt(b, "],\"icones_qtd\":%d", n);
}

/* Icone que falhou e tentado de novo so depois de 5 minutos (como o app de PC). */
#define NOVA_TENTATIVA_ICONE_S 300
#define MAX_SEM_ICONE 256
static pthread_mutex_t g_trava_icone = PTHREAD_MUTEX_INITIALIZER;
static struct {
  char codigo[10];
  time_t quando;
} g_sem_icone[MAX_SEM_ICONE];

static int falhou_ha_pouco(const char *codigo) {
  int r = 0;
  pthread_mutex_lock(&g_trava_icone);
  for(int i = 0; i < MAX_SEM_ICONE; i++) {
    if(!strcmp(g_sem_icone[i].codigo, codigo) && time(NULL) - g_sem_icone[i].quando < NOVA_TENTATIVA_ICONE_S) r = 1;
  }
  pthread_mutex_unlock(&g_trava_icone);
  return r;
}

static void marcar_sem_icone(const char *codigo) {
  pthread_mutex_lock(&g_trava_icone);
  int livre = 0;
  for(int i = 0; i < MAX_SEM_ICONE; i++) {
    if(!strcmp(g_sem_icone[i].codigo, codigo)) { livre = i; break; }
    if(g_sem_icone[i].quando < g_sem_icone[livre].quando) livre = i;   /* o mais antigo */
  }
  snprintf(g_sem_icone[livre].codigo, sizeof g_sem_icone[livre].codigo, "%s", codigo);
  g_sem_icone[livre].quando = time(NULL);
  pthread_mutex_unlock(&g_trava_icone);
}

static void rota_icone(pedido_t *p, const char *codigo) {
  char pasta[600], arquivo[700], url[2048];
  if(!codigo_valido(codigo)) {
    responder(p, 404, "text/plain", "", 0, NULL);
    return;
  }
  arquivo_dados(pasta, sizeof pasta, "icones");
  for(size_t i = 0; i < 3; i++) {
    snprintf(arquivo, sizeof arquivo, "%s/%s%s", pasta, codigo, TIPOS[i].ext);
    if(!responder_arquivo(p, arquivo, TIPOS[i].tipo, "max-age=604800")) return;
  }
  /* Ainda nao baixado: a pagina manda a URL do site do jogo (so sites da lista fixa; nada da loja da Sony). */
  if(falhou_ha_pouco(codigo)) {
    responder(p, 404, "text/plain", "", 0, NULL);
    return;
  }
  buf_t b = {0};
  int tipo = -1, status = 0;
  if(param(p->query, "url", 0, url, sizeof url) && url_permitida(url) && (status = https_get(url, &b, MAX_ICONE, 6)) == 200)
    tipo = tipo_imagem(&b);
  if(strstr(p->query, "url")) {
    const unsigned char *d = (const unsigned char *)(b.d ? b.d : "");
    if(tipo < 0) diario("icone %s: falhou (status %d, %zu bytes, inicio %02x%02x%02x%02x, url %.80s)", codigo, status, b.n,
                        b.n > 0 ? d[0] : 0, b.n > 1 ? d[1] : 0, b.n > 2 ? d[2] : 0, b.n > 3 ? d[3] : 0, url);
    else diario("icone %s: baixado (%zu bytes, %s)", codigo, b.n, TIPOS[tipo].ext + 1);
  }
  if(tipo < 0) {
    if(strstr(p->query, "url")) marcar_sem_icone(codigo);
    responder(p, 404, "text/plain", "", 0, NULL);
  } else {
    mkdir_p(pasta);
    snprintf(arquivo, sizeof arquivo, "%s/%s%s", pasta, codigo, TIPOS[tipo].ext);
    FILE *f = fopen(arquivo, "wb");
    if(f) {
      fwrite(b.d, 1, b.n, f);
      fclose(f);
    }
    responder(p, 200, TIPOS[tipo].tipo, b.d, b.n, "max-age=604800");
  }
  buf_free(&b);
}

/* ------------------------------------------------------------------ rotas */

static void rota_estado(pedido_t *p) {
  char ip[64] = "";
  buf_t b = {0};
  meu_ip(ip, sizeof ip);
  buf_str(&b, "{\"ok\":true,\"versao\":");
  buf_json(&b, VERSAO);
  buf_str(&b, ",\"ip\":");
  buf_json(&b, ip);
  buf_fmt(&b, ",\"porta\":%d,\"pasta_dados\":", g_porta);
  buf_json(&b, g_pasta_dados);
  buf_str(&b, ",");
  config_json(&b);
  buf_str(&b, ",\"base\":");
  base_json(&b);
  buf_str(&b, ",");
  icones_json(&b);
  buf_str(&b, "}");
  responder_json(p, 200, &b);
  buf_free(&b);
}

static void rota_fs(pedido_t *p) {
  char caminho[1024] = "/";
  param(p->query, "caminho", 0, caminho, sizeof caminho);
  if(!caminho_valido(caminho)) {
    responder_erro(p, 400, "pasta_invalida", "caminho invalido", NULL);
    return;
  }
  buf_t b = {0};
  int erro = arquivos_listar(caminho, &b);
  if(erro) responder_erro(p, 404, "pasta_nao_abre", strerror(erro), caminho);
  else responder_json(p, 200, &b);
  buf_free(&b);
}

/* monitoradas: grava as pastas marcadas como do ShadowMount (todas de uma vez; nenhuma = desmarca todas). */
static void rota_pastas(pedido_t *p, int monitoradas) {
  static char pastas[MAX_PASTAS][1024];
  static pthread_mutex_t trava = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_lock(&trava);
  int qtd = 0;
  while(qtd < MAX_PASTAS && param(p->corpo, "pasta", qtd, pastas[qtd], sizeof pastas[qtd])) qtd++;
  int r = monitoradas ? config_gravar_monitoradas(pastas, qtd) : config_gravar(pastas, qtd, NULL);
  pthread_mutex_unlock(&trava);
  if(r) {
    responder_erro(p, 400, "pasta_invalida", monitoradas ? "a pasta nao esta na lista" : "o caminho deve comecar com /", NULL);
    return;
  }
  buf_t b = {0};
  buf_str(&b, "{\"ok\":true,");
  config_json(&b);
  buf_str(&b, "}");
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* Arquivos ocultos da lista de jogos: grava a lista inteira (nenhum = mostra todos de novo).
   mostrados = 1: lista dos .complete que o usuario mandou mostrar (nenhum = todos voltam a ficar ocultos sozinhos). */
static void rota_ocultos(pedido_t *p, int mostrados) {
  static char nomes[MAX_OCULTOS][TAM_OCULTO];
  static pthread_mutex_t trava = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_lock(&trava);
  int qtd = 0;
  while(qtd < MAX_OCULTOS && param(p->corpo, "nome", qtd, nomes[qtd], sizeof nomes[qtd])) qtd++;
  int r = mostrados ? config_gravar_mostrados(nomes, qtd) : config_gravar_ocultos(nomes, qtd);
  pthread_mutex_unlock(&trava);
  if(r) {
    responder_erro(p, 400, "nome_invalido", "nome de arquivo invalido", NULL);
    return;
  }
  buf_t b = {0};
  buf_str(&b, "{\"ok\":true,");
  config_json(&b);
  buf_str(&b, "}");
  responder_json(p, 200, &b);
  buf_free(&b);
}

static void rota_renomear(pedido_t *p) {
  char pasta[1024] = "", de[300] = "", para[300] = "", tamanho[32] = "";
  param(p->corpo, "pasta", 0, pasta, sizeof pasta);
  param(p->corpo, "de", 0, de, sizeof de);
  param(p->corpo, "para", 0, para, sizeof para);
  long long tam = param(p->corpo, "tamanho", 0, tamanho, sizeof tamanho) && *tamanho ? atoll(tamanho) : -1;
  ren_t r = arquivos_renomear(pasta, de, para, tam);
  if(r == REN_OK) {
    responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
    return;
  }
  const char *nome = r == REN_DESTINO_EXISTE ? para : de;
  char msg[400];
  snprintf(msg, sizeof msg, "%s: %s", ren_chave(r), r == REN_FALHOU ? strerror(errno) : nome);
  responder_erro(p, 200, ren_chave(r), msg, nome);
}

/* memmem nao existe na libc do PS5 */
static int contem(const char *d, size_t n, const char *s) {
  size_t m = strlen(s);
  for(size_t i = 0; i + m <= n; i++) if(!memcmp(d + i, s, m)) return 1;
  return 0;
}

/* Nome, Title ID e icone de dentro do arquivo do jogo (sem internet); so arquivos das pastas configuradas. */
static void rota_local(pedido_t *p) {
  char pasta[1024] = "", nome[300] = "", caminho[1400], icones[600], formato[16] = "";
  char pastas[MAX_PASTAS][1024];
  param(p->query, "pasta", 0, pasta, sizeof pasta);
  param(p->query, "nome", 0, nome, sizeof nome);
  int qtd = config_ler(pastas, NULL), permitida = 0;
  size_t np = strlen(pasta);
  while(np > 1 && pasta[np - 1] == '/') pasta[--np] = 0;   /* "/data/homebrew/" = "/data/homebrew" */
  for(int i = 0; i < qtd && !permitida; i++) {
    size_t nc = strlen(pastas[i]);
    while(nc > 1 && pastas[i][nc - 1] == '/') nc--;
    permitida = nc == np && !strncmp(pastas[i], pasta, nc);
  }
  if(!permitida || !caminho_valido(pasta) || !nome_valido(nome)) {
    responder_erro(p, 400, "requisicao_invalida", "pasta ou nome invalido", NULL);
    return;
  }
  snprintf(caminho, sizeof caminho, "%s/%s", strcmp(pasta, "/") ? pasta : "", nome);
  arquivo_dados(icones, sizeof icones, "icones");
  info_jogo_t info;
  buf_t b = {0};
  if(jogo_local(caminho, icones, &info, formato, sizeof formato)) {
    buf_str(&b, "{\"ok\":true,\"achou\":false}");
  } else {
    buf_str(&b, "{\"ok\":true,\"achou\":true,\"title_id\":");
    buf_json(&b, info.title_id);
    buf_str(&b, ",\"nome\":");
    buf_json(&b, info.nome);
    buf_str(&b, ",\"content_id\":");
    buf_json(&b, info.content_id);
    buf_str(&b, ",\"formato\":");
    buf_json(&b, formato);
    snprintf(icones + strlen(icones), sizeof icones - strlen(icones), "/%s.png", info.title_id);
    struct stat st;
    buf_fmt(&b, ",\"icone\":%s}", stat(icones, &st) ? "false" : "true");
  }
  responder_json(p, 200, &b);
  buf_free(&b);
}

static void rota_web(pedido_t *p) {
  /* Paginas dos sites de patches (nome do publisher e URL do icone); a pagina le o HTML. */
  char url[2048];
  /* so os sites de patches: nada do GitHub (base, versoes, apps) nem do teste de internet */
  if(!param(p->query, "url", 0, url, sizeof url) || !url_permitida(url) || strncmp(url, "https://", 8) || strstr(url, "github") ||
     strstr(url, "speed.cloudflare")) {
    responder(p, 403, "text/plain", "", 0, NULL);
    return;
  }
  buf_t b = {0};
  int status = https_get(url, &b, MAX_PAGINA, 30);
  if(status == 200 && !(b.n && contem(b.d, b.n, "og:title"))) {   /* pagina sem os dados do jogo: registra o que veio */
    const unsigned char *d = (const unsigned char *)(b.d ? b.d : "");
    diario("pagina %.80s: veio sem og:title (%zu bytes, inicio %02x%02x%02x%02x)", url, b.n, b.n > 0 ? d[0] : 0,
           b.n > 1 ? d[1] : 0, b.n > 2 ? d[2] : 0, b.n > 3 ? d[3] : 0);
  } else if(status < 0) {
    diario("pagina %.80s: falhou", url);
  }
  if(status < 0) responder(p, 502, "text/plain", "", 0, NULL);
  else responder(p, status, "text/html; charset=utf-8", b.d ? b.d : "", b.n, NULL);
  buf_free(&b);
}

static void rota_cache_gravar(pedido_t *p) {
  char arquivo[600], tmp[610];
  arquivo_dados(arquivo, sizeof arquivo, "cache_consultas.json");
  snprintf(tmp, sizeof tmp, "%s.tmp", arquivo);
  if(!p->corpo_n || p->corpo_n > MAX_CACHE || p->corpo[0] != '{') {
    responder_erro(p, 400, "requisicao_invalida", "requisicao invalida", NULL);
    return;
  }
  FILE *f = fopen(tmp, "wb");
  int ok = f && fwrite(p->corpo, 1, p->corpo_n, f) == p->corpo_n;
  if(f && fclose(f)) ok = 0;
  if(ok && !rename(tmp, arquivo)) responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  else responder_erro(p, 500, "falha_gravar", strerror(errno), NULL);
}

/* Copiar / mover / excluir em lote: tipo, destino e, para cada arquivo, pasta + de + para (na mesma ordem). */
static void rota_tarefas(pedido_t *p) {
  char tipo[16] = "", destino[1024] = "", pasta[1024], de[300], para[300];
  param(p->corpo, "tipo", 0, tipo, sizeof tipo);
  param(p->corpo, "destino", 0, destino, sizeof destino);
  tarefa_tipo_t tt = !strcmp(tipo, "copiar") ? TAR_COPIAR : !strcmp(tipo, "mover") ? TAR_MOVER : TAR_EXCLUIR;
  if(strcmp(tipo, "copiar") && strcmp(tipo, "mover") && strcmp(tipo, "excluir")) {
    responder_erro(p, 400, "requisicao_invalida", "tipo invalido", NULL);
    return;
  }
  int criadas = 0, recusadas = 0;
  for(int i = 0; param(p->corpo, "pasta", i, pasta, sizeof pasta); i++) {
    de[0] = para[0] = 0;
    param(p->corpo, "de", i, de, sizeof de);
    param(p->corpo, "para", i, para, sizeof para);
    /* copiar/mover um arquivo que ja esta na pasta de destino: ignorado (nunca vira renomear) */
    if(tt != TAR_EXCLUIR && !strcmp(pasta, destino)) {
      recusadas++;
      continue;
    }
    if(tarefas_adicionar(tt, pasta, de, destino, para)) criadas++;
    else recusadas++;
  }
  buf_t b = {0};
  buf_fmt(&b, "{\"ok\":%s,\"criadas\":%d,\"recusadas\":%d}", criadas ? "true" : "false", criadas, recusadas);
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* ATIVAR: copia um jogo "so armazenado" para uma pasta do ShadowMount escolhida aqui, sem perguntar.
   Destino: entre as pastas marcadas (fora a de origem) que existem e ainda nao tem esse arquivo, a que fica com mais
   espaco livre depois do que a fila ja prometeu (tarefas_reservado); precisa caber o arquivo + MARGEM_ATIVAR.
   E sempre COPIA (o original fica onde esta). */
#define MARGEM_ATIVAR (512LL * 1024 * 1024)

static void erro_ativar(pedido_t *p, const char *chave, const char *msg, long long precisa, long long maior) {
  buf_t b = {0};
  buf_str(&b, "{\"ok\":false,\"chave\":");
  buf_json(&b, chave);
  buf_str(&b, ",\"erro\":");
  buf_json(&b, msg);
  buf_fmt(&b, ",\"params\":{\"precisa\":%lld,\"maior\":%lld}}", precisa, maior);
  responder_json(p, 200, &b);
  buf_free(&b);
}

static void rota_ativar(pedido_t *p) {
  char pasta[1024] = "", nome[300] = "", origem[1400], alvo[1400], monit[MAX_PASTAS][1024];
  param(p->corpo, "pasta", 0, pasta, sizeof pasta);
  param(p->corpo, "nome", 0, nome, sizeof nome);
  struct stat st;
  size_t np = strlen(pasta);
  snprintf(origem, sizeof origem, "%s%s%s", pasta, (np && pasta[np - 1] == '/') ? "" : "/", nome);
  if(!caminho_valido(pasta) || !nome_valido(nome) || lstat(origem, &st) || !S_ISREG(st.st_mode)) {
    erro_ativar(p, "ativar_origem", "o arquivo nao existe mais", 0, 0);
    return;
  }
  int qtd = config_monitoradas(monit, MAX_PASTAS);
  if(!qtd) {
    erro_ativar(p, "ativar_sem_pasta", "nenhuma pasta marcada como do ShadowMount", 0, 0);
    return;
  }
  for(int i = 0; i < qtd; i++) {
    if(!strcmp(monit[i], pasta)) {
      erro_ativar(p, "ativar_ja_ativo", "o jogo ja esta numa pasta do ShadowMount", 0, 0);
      return;
    }
  }
  if(tarefas_tem(pasta, nome)) {
    erro_ativar(p, "ativar_na_fila", "este arquivo ja esta na fila", 0, 0);
    return;
  }
  long long precisa = (long long)st.st_size + MARGEM_ATIVAR, maior = -1;
  int escolhida = -1, validas = 0;
  for(int i = 0; i < qtd; i++) {
    size_t n = strlen(monit[i]);
    snprintf(alvo, sizeof alvo, "%s%s%s", monit[i], (n && monit[i][n - 1] == '/') ? "" : "/", nome);
    struct stat sd;
    if(!lstat(alvo, &sd)) {   /* mesmo nome numa pasta do ShadowMount: ja esta ativo la (nunca sobrescreve) */
      erro_ativar(p, "ativar_ja_ativo", "ja existe uma copia ativa deste arquivo", 0, 0);
      return;
    }
    struct statvfs v;
    if(stat(monit[i], &sd) || !S_ISDIR(sd.st_mode) || statvfs(monit[i], &v)) continue;   /* disco desligado */
    validas++;
    long long livre = (long long)v.f_bavail * (long long)v.f_frsize - tarefas_reservado(monit[i]);
    if(livre > maior) {
      maior = livre;
      if(livre >= precisa) escolhida = i;
    }
  }
  if(!validas) {
    erro_ativar(p, "ativar_sem_disco", "as pastas do ShadowMount nao estao acessiveis", 0, 0);
    return;
  }
  long long maior_livre = maior > 0 ? maior : 0;
  if(escolhida < 0) {
    diario("ativar: %s sem espaco (precisa %lld, maior livre %lld)", nome, precisa, maior_livre);
    erro_ativar(p, "ativar_sem_espaco", "sem espaco nas pastas do ShadowMount", precisa, maior_livre);
    return;
  }
  int id = tarefas_adicionar(TAR_COPIAR, pasta, nome, monit[escolhida], "");
  if(!id) {
    erro_ativar(p, "ativar_origem", "nao foi possivel por na fila", 0, 0);
    return;
  }
  diario("ativar: %s de %s para %s (precisa %lld com margem, livre %lld)", nome, pasta, monit[escolhida], precisa, maior);
  buf_t b = {0};
  buf_fmt(&b, "{\"ok\":true,\"id\":%d,\"destino\":", id);
  buf_json(&b, monit[escolhida]);
  buf_fmt(&b, ",\"livre\":%lld,\"precisa\":%lld}", maior, precisa);
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* Espaco livre da pasta (para a tela mostrar no destino). */
static void rota_espaco(pedido_t *p) {
  char caminho[1024] = "/";
  param(p->query, "caminho", 0, caminho, sizeof caminho);
  struct statvfs v;
  buf_t b = {0};
  if(!caminho_valido(caminho) || statvfs(caminho, &v)) buf_str(&b, "{\"ok\":false}");
  else buf_fmt(&b, "{\"ok\":true,\"livre\":%lld,\"total\":%lld}", (long long)v.f_bavail * (long long)v.f_frsize,
               (long long)v.f_blocks * (long long)v.f_frsize);
  responder_json(p, 200, &b);
  buf_free(&b);
}

void api_tratar(pedido_t *p) {
  char arquivo[600];
  int get = !strcmp(p->metodo, "GET") || !strcmp(p->metodo, "HEAD");
  int post = !strcmp(p->metodo, "POST");

  if(get && (!strcmp(p->caminho, "/") || !strcmp(p->caminho, "/index.html"))) {
    responder_pagina(p, web_index_html, web_index_html_len, web_index_gz, web_index_gz_len);
  } else if(get && (!strcmp(p->caminho, "/favicon.ico") || !strcmp(p->caminho, "/icone.png"))) {
    responder(p, 200, "image/png", web_icone_png, web_icone_png_len, "max-age=86400");
  } else if(get && !strcmp(p->caminho, "/teste-tela-cheia")) {
    responder_pagina(p, web_telacheia_html, web_telacheia_html_len, web_telacheia_gz, web_telacheia_gz_len);
  } else if(get && !strcmp(p->caminho, "/api/diag")) {
    /* linhas de diagnostico das paginas de teste (ex.: tela cheia) para o diario; limite contra abuso */
    static time_t janela;
    static int qtd;
    char msg[400] = "";
    param(p->query, "msg", 0, msg, sizeof msg);
    for(char *c = msg; *c; c++) if((unsigned char)*c < ' ') *c = ' ';
    if(time(NULL) - janela > 60) {
      janela = time(NULL);
      qtd = 0;
    }
    if(msg[0] && qtd++ < 60) diario("diag: %s", msg);
    responder(p, 204, "text/plain", "", 0, NULL);
  } else if(get && !strcmp(p->caminho, "/youtube")) {
    /* pagina de teste: o PS5 toca o player embutido do YouTube? */
    responder_pagina(p, web_youtube_html, web_youtube_html_len, web_youtube_gz, web_youtube_gz_len);
  } else if(get && !strcmp(p->caminho, "/diario")) {
    /* diario do payload (glibren.log): passos, falhas de rede e quedas - para ver sem FTP */
    arquivo_dados(arquivo, sizeof arquivo, "glibren.log");
    if(responder_arquivo(p, arquivo, "text/plain; charset=utf-8", "no-store"))
      responder(p, 200, "text/plain; charset=utf-8", "(diario vazio)\n", 15, NULL);
  } else if(get && !strcmp(p->caminho, "/app-log")) {
    /* diagnostico dos apps de YouTube: hora do PS5 + final do yt.log do ytps5 (com o app aberto) */
    char id[48] = "ytps5";
    param(p->query, "id", 0, id, sizeof id);
    buf_t b = {0};
    apps_log(id, &b);
    responder(p, 200, "text/plain; charset=utf-8", b.d, b.n, "no-store");
    buf_free(&b);
  } else if(get && !strcmp(p->caminho, "/api/estado")) {
    rota_estado(p);
  } else if(get && !strcmp(p->caminho, "/api/fs")) {
    rota_fs(p);
  } else if(get && !strcmp(p->caminho, "/api/tarefas")) {
    buf_t b = {0};
    tarefas_json(&b);
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(get && !strcmp(p->caminho, "/api/termico")) {
    char hist[4] = "";
    param(p->query, "historico", 0, hist, sizeof hist);
    buf_t b = {0};
    termico_json(&b, hist[0] == '1');
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(get && !strcmp(p->caminho, "/internet")) {
    responder_pagina(p, web_internet_html, web_internet_html_len, web_internet_gz, web_internet_gz_len);
  } else if(get && !strcmp(p->caminho, "/api/internet/servidores")) {
    buf_t b = {0};
    internet_servidores(&b);
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(get && !strcmp(p->caminho, "/api/internet")) {
    buf_t b = {0};
    internet_estado(&b);
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(get && !strcmp(p->caminho, "/discos")) {
    responder_pagina(p, web_discos_html, web_discos_html_len, web_discos_gz, web_discos_gz_len);
  } else if(get && (!strcmp(p->caminho, "/api/discos") || !strcmp(p->caminho, "/api/velocidade"))) {
    buf_t b = {0};
    if(!strcmp(p->caminho, "/api/discos")) discos_listar(&b);
    else discos_estado(&b);
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(get && !strcmp(p->caminho, "/temperatura")) {
    responder_pagina(p, web_temperatura_html, web_temperatura_html_len, web_temperatura_gz, web_temperatura_gz_len);
  } else if(get && !strcmp(p->caminho, "/api/espaco")) {
    rota_espaco(p);
  } else if(get && !strcmp(p->caminho, "/api/escanear")) {
    buf_t b = {0};
    arquivos_escanear(&b);
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(get && !strcmp(p->caminho, "/base_titulos.tsv")) {
    arquivo_dados(arquivo, sizeof arquivo, "base_titulos.tsv");
    if(responder_arquivo(p, arquivo, "text/tab-separated-values; charset=utf-8", "no-cache"))
      responder(p, 404, "text/plain", "", 0, NULL);
  } else if(get && !strncmp(p->caminho, "/icone/", 7)) {
    rota_icone(p, p->caminho + 7);
  } else if(get && !strcmp(p->caminho, "/api/local")) {
    rota_local(p);
  } else if(get && !strcmp(p->caminho, "/api/web")) {
    rota_web(p);
  } else if(get && !strcmp(p->caminho, "/api/navegador")) {
    /* a pagina conta se o navegador mostra .webp (os icones dos sites vem nesse formato); uma linha por navegador */
    static char ja[4][24];
    char webp[4] = "", ua[200] = "";
    param(p->query, "webp", 0, webp, sizeof webp);
    param(p->query, "ua", 0, ua, sizeof ua);
    for(char *c = ua; *c; c++) if(*c < ' ' || *c > '~') *c = '?';
    int i = 0;
    while(i < 4 && ja[i][0] && strncmp(ja[i], ua + (strlen(ua) > 23 ? strlen(ua) - 23 : 0), 23)) i++;
    if(i < 4 && !ja[i][0]) {
      snprintf(ja[i], sizeof ja[i], "%s", ua + (strlen(ua) > 23 ? strlen(ua) - 23 : 0));
      diario("navegador: webp %s (%s)", !strcmp(webp, "1") ? "sim" : "NAO", ua);
    }
    responder(p, 204, "text/plain", "", 0, NULL);
  } else if(get && !strcmp(p->caminho, "/api/cache")) {
    arquivo_dados(arquivo, sizeof arquivo, "cache_consultas.json");
    if(responder_arquivo(p, arquivo, "application/json; charset=utf-8", "no-store"))
      responder(p, 200, "application/json", "{}", 2, NULL);
  } else if(post && !p->pedido_do_app) {
    /* Sem o cabecalho X-GLR: formulario de outro site tentando mexer no PS5. */
    responder(p, 403, "text/plain", "", 0, NULL);
  } else if(post && !strcmp(p->caminho, "/api/pastas")) {
    rota_pastas(p, 0);
  } else if(post && !strcmp(p->caminho, "/api/monitoradas")) {
    rota_pastas(p, 1);
  } else if(post && !strcmp(p->caminho, "/api/ocultos")) {
    rota_ocultos(p, 0);
  } else if(post && !strcmp(p->caminho, "/api/mostrados")) {
    rota_ocultos(p, 1);
  } else if(post && !strcmp(p->caminho, "/api/idioma")) {
    char idioma[16] = "";
    param(p->corpo, "idioma", 0, idioma, sizeof idioma);
    if(config_gravar(NULL, 0, idioma)) responder_erro(p, 400, "idioma_invalido", "idioma invalido", NULL);
    else responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && (!strcmp(p->caminho, "/api/termico/limite") || !strcmp(p->caminho, "/api/termico/alerta"))) {
    char c[8] = "", msg[200] = "";
    param(p->corpo, "c", 0, c, sizeof c);
    int r = strstr(p->caminho, "limite") ? termico_definir_limite(atoi(c), msg, sizeof msg) : termico_definir_alerta(atoi(c));
    if(r) responder_erro(p, 200, "ventoinha", msg[0] ? msg : "valor invalido", NULL);
    else {
      buf_t b = {0};
      termico_json(&b, 0);
      responder_json(p, 200, &b);
      buf_free(&b);
    }
  } else if(post && !strcmp(p->caminho, "/api/internet")) {
    char msg[200] = "", servidor[128] = "";
    param(p->corpo, "servidor", 0, servidor, sizeof servidor);
    if(internet_testar(servidor, msg, sizeof msg)) responder_erro(p, 200, "internet", msg, NULL);
    else responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && !strcmp(p->caminho, "/api/internet/cancelar")) {
    internet_cancelar();
    responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && !strcmp(p->caminho, "/api/velocidade")) {
    char caminho[256] = "", mb[8] = "", msg[200] = "";
    param(p->corpo, "caminho", 0, caminho, sizeof caminho);
    param(p->corpo, "mb", 0, mb, sizeof mb);
    if(discos_testar(caminho, atoi(mb), msg, sizeof msg)) responder_erro(p, 200, "velocidade", msg, NULL);
    else responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && !strcmp(p->caminho, "/api/velocidade/cancelar")) {
    discos_cancelar();
    responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && !strcmp(p->caminho, "/api/tarefas")) {
    rota_tarefas(p);
  } else if(post && !strcmp(p->caminho, "/api/ativar")) {
    rota_ativar(p);
  } else if(post && !strcmp(p->caminho, "/api/tarefas/cancelar")) {
    char id[16] = "";
    param(p->corpo, "id", 0, id, sizeof id);
    if(tarefas_cancelar(atoi(id))) responder_erro(p, 200, "tarefa_terminou", "a tarefa ja terminou", NULL);
    else responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && !strcmp(p->caminho, "/api/tarefas/limpar")) {
    tarefas_limpar_terminadas();
    responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && !strcmp(p->caminho, "/api/renomear")) {
    rota_renomear(p);
  } else if(post && !strcmp(p->caminho, "/api/cache")) {
    rota_cache_gravar(p);
  } else if(post && !strcmp(p->caminho, "/api/limpar-cache")) {
    arquivo_dados(arquivo, sizeof arquivo, "cache_consultas.json");
    unlink(arquivo);
    responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && !strcmp(p->caminho, "/api/atualizar-base")) {
    api_atualizar_base(1);
    responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(get && !strcmp(p->caminho, "/api/atualizacao")) {
    buf_t b = {0};
    atualizacao_estado(&b, strstr(p->query, "verificar=1") != NULL);
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(post && !strcmp(p->caminho, "/api/atualizar")) {
    char msg[200] = "";
    if(atualizacao_iniciar(msg, sizeof msg)) responder_erro(p, 200, "atualizacao", msg, NULL);
    else responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(get && !strcmp(p->caminho, "/api/apps")) {
    buf_t b = {0};
    apps_json(&b, strstr(p->query, "verificar=1") != NULL);
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(post && !strcmp(p->caminho, "/api/apps/instalar")) {
    char id[48] = "", msg[200] = "";
    param(p->corpo, "id", 0, id, sizeof id);
    if(apps_instalar(id, msg, sizeof msg)) responder_erro(p, 200, "apps", msg, NULL);
    else responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && !strcmp(p->caminho, "/api/apps/desinstalar")) {
    char id[48] = "", msg[200] = "";
    param(p->corpo, "id", 0, id, sizeof id);
    if(apps_desinstalar(id, msg, sizeof msg)) responder_erro(p, 200, "apps", msg, NULL);
    else responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && !strcmp(p->caminho, "/api/youtube")) {
    /* botao YouTube no PS5: grava a busca no app de YouTube instalado e abre o app */
    char busca[1024] = "", chave[32] = "", msg[200] = "";
    param(p->corpo, "busca", 0, busca, sizeof busca);
    buf_t b = {0};
    if(apps_youtube(busca, &b, chave, sizeof chave, msg, sizeof msg)) responder_erro(p, 200, chave, msg, NULL);
    else responder_json(p, 200, &b);
    buf_free(&b);
  } else if(get && !strcmp(p->caminho, "/api/relogio")) {
    buf_t b = {0};
    buf_str(&b, "{\"ok\":true,");
    relogio_json(&b);
    buf_str(&b, "}");
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(post && (!strcmp(p->caminho, "/api/relogio") || !strcmp(p->caminho, "/api/relogio/conferir"))) {
    /* liga/desliga (auto=1|0) ou confere agora (espera o resultado: poucos segundos, ate ~30 s) */
    char ligado[4] = "";
    if(!strcmp(p->caminho, "/api/relogio/conferir")) relogio_conferir_agora();
    else if(!param(p->corpo, "auto", 0, ligado, sizeof ligado) || (strcmp(ligado, "0") && strcmp(ligado, "1")) ||
            relogio_definir_auto(ligado[0] == '1')) {
      responder_erro(p, 400, "relogio", "valor invalido", NULL);
      return;
    }
    buf_t b = {0};
    buf_str(&b, "{\"ok\":true,");
    relogio_json(&b);
    buf_str(&b, "}");
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(post && !strcmp(p->caminho, "/api/energia")) {
    /* desligar o PS5 ou modo de repouso (TV com defeito: sem o menu na tela). So POST com X-GLR, como o resto. */
    char acao[16] = "", msg[200] = "";
    param(p->corpo, "acao", 0, acao, sizeof acao);
    if(energia_pedir(acao, msg, sizeof msg)) responder_erro(p, 200, "energia", msg, NULL);
    else responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && !strcmp(p->caminho, "/api/sair")) {
    responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
    servidor_parar();
  } else if(get || post) {
    responder(p, 404, "text/plain", "", 0, NULL);
  } else {
    responder(p, 405, "text/plain", "", 0, NULL);
  }
}
