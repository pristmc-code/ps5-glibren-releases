#!/bin/bash
# 0.9.70: Fila PKG na versao de PC, com o Dump Forge FALSO (testes/dumpforge_falso.py, saida .pkg com cabecalho de PS5).
# Interno = /root/glr-filapkg/data; externo = /dev/shm/glr-filapkg-ext (outro disco: exercita a copia com SHA-256).
# Casos: analisar (plano: converter so .exfat sem .pkg, mover .exfat/.pkg, PS4 em PS4pkg, zstd/pasta/zip ficam),
# ordem (interno primeiro, menor primeiro), Dump Forge fora = pausa com motivo, iniciar, glibren morto no meio e
# religado (continua sozinho), copia igual no destino (a origem sai), fim (nada de .exfat/.pkg no interno), pagina.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_filapkg.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8931; PORTA_DF=8932
L="http://127.0.0.1:$PORTA"
T=/root/glr-filapkg; DADOS=$T/dados; INT=$T/data; EXT=/dev/shm/glr-filapkg-ext
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [${2:0:600}] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
post() { curl -s -H 'X-GLR: 1' -X POST -d x=1 "$@"; }
estado() { curl -s "$L/api/filapkg"; }
liga_df() { (exec python3 -I "$ORIGEM/testes/dumpforge_falso.py" $PORTA_DF "$T/df") >> "$T/df.log" 2>&1 & PID_DF=$!; sleep 0.5; }
liga_glr() {
  GLR_TESTE_SONDA_S=0 GLR_TESTE_CONV_VIGIA_S=1 GLR_TESTE_DUMPFORGE_PORTA=$PORTA_DF GLR_TESTE_FILAPKG_INTERNO=$INT \
    GLR_TESTE_FILAPKG_EXTERNO=$EXT GLR_TESTE_FILAPKG_FOLGA_MB=1 "$BIN" -p $PORTA -d "$DADOS" >> "$T/glr.log" 2>&1 & PID=$!
  sleep 1
}
espera() {   # espera o estado $1 (ate $2 s)
  for _ in $(seq 1 $(( $2 * 2 ))); do estado | grep -q "\"estado\":\"$1\"" && return 0; sleep 0.5; done
  return 1
}
pkg5() { printf '\x7fFIH' > "$1"; head -c "$2" /dev/urandom >> "$1"; }

rm -rf "$T" "$EXT"
mkdir -p "$DADOS" "$INT/homebrew/PastaJogo-PPSA05555/sce_sys" "$INT/BACKUP/Bk" "$EXT/PS5exfat" "$EXT/PS5pkg" "$EXT/testes" "$EXT/user/app" "$T/df"
printf 'language = pt-BR\nfolder = %s/\nfolder = %s/\n' "$INT/homebrew" "$EXT/testes" > "$DADOS/config.ini"
H=$INT/homebrew
head -c 30000 /dev/urandom > "$H/Grande-PPSA34015-US-PS5.exfat"           # interno, sem .pkg: converte e sai
head -c 5000 /dev/urandom > "$H/Tem-PPSA00002-US-PS5.exfat"               # interno, ja tem .pkg: so sai
pkg5 "$H/Tem-PPSA00002-US-PS5.pkg" 3000
printf '\x7fCNT' > "$H/Velho-CUSA03745-EU-PS4.pkg"; head -c 2000 /dev/urandom >> "$H/Velho-CUSA03745-EU-PS4.pkg"   # PS4
head -c 4000 /dev/urandom > "$H/Zst-PPSA12771-US-PS5-zstd.exfat"          # fica
echo '{}' > "$H/PastaJogo-PPSA05555/sce_sys/param.json"; echo elf > "$H/PastaJogo-PPSA05555/eboot.bin"   # fica
echo z > "$H/Baixado-PPSA07777.zip"                                         # fica
head -c 7000 /dev/urandom > "$H/Dup-PPSA00007-US-PS5.exfat"; cp "$H/Dup-PPSA00007-US-PS5.exfat" "$EXT/PS5exfat/"   # igual nos dois
head -c 6000 /dev/urandom > "$INT/BACKUP/Bk/Bk-PPSA00003-US-PS5.exfat"     # BACKUP/<jogo>/: converte e sai
head -c 9000 /dev/urandom > "$EXT/PS5exfat/Ext-PPSA00004-US-PS5.exfat"     # externo, ja no lugar: so converte
pkg5 "$EXT/PS5exfat/Conv-PPSA00005-US-PS5.pkg" 100                          # .pkg no lugar errado: troca de pasta
head -c 8000 /dev/urandom > "$EXT/testes/Teste-PPSA00006-US-PS5.exfat"    # converte e vai para PS5exfat
pkg5 "$EXT/user/app/Instalado-PPSA09999.pkg" 10                             # pasta do sistema: nunca
SHA_GRANDE=$(sha256sum "$H/Grande-PPSA34015-US-PS5.exfat" | cut -c1-64)
echo pkg5 > "$T/df/cria"; echo ok > "$T/df/modo"
liga_glr

echo "--- estado inicial e analisar"
confere "estado vazio"                     "$(estado)" '"estado":"vazio"'
confere "analisar sem X-GLR: 403"          "$(curl -s -o /dev/null -w '%{http_code}' -X POST -d x=1 $L/api/filapkg/analisar)" "403"
post $L/api/filapkg/analisar > /dev/null
espera pronto 20 || echo "(analise nao terminou)"
E=$(estado)
confere "analise: pronto"                  "$E" '"estado":"pronto"'
confere "analise: externo"                 "$E" "\"externo\":\"$EXT\""
confere "analise: 5 conversoes"            "$E" '"converter":5,'
confere "converter Grande (interno)"       "$E" "\"tipo\":\"converter\"[^}]*\"origem\":\"$H/Grande-PPSA34015-US-PS5.exfat\",\"destino\":\"$EXT/PS5pkg/Grande-PPSA34015-US-PS5.pkg\""
confere "converter Dup pelo interno"       "$E" "\"origem\":\"$H/Dup-PPSA00007-US-PS5.exfat\",\"destino\":\"$EXT/PS5pkg/Dup-PPSA00007-US-PS5.pkg\""
confere "converter Ext (externo)"          "$E" "\"origem\":\"$EXT/PS5exfat/Ext-PPSA00004-US-PS5.exfat\",\"destino\":\"$EXT/PS5pkg/"
confere "converter Teste (externo)"        "$E" "\"origem\":\"$EXT/testes/Teste-PPSA00006-US-PS5.exfat\",\"destino\":\"$EXT/PS5pkg/"
nao_tem "Tem (ja tem .pkg) nao converte"   "$E" "\"tipo\":\"converter\"[^}]*Tem-PPSA00002-US-PS5.exfat\",\"destino\":\"$EXT/PS5pkg"
confere "PS4 vai para PS4pkg"              "$E" "\"destino\":\"$EXT/PS4pkg/Velho-CUSA03745-EU-PS4.pkg\""
confere ".pkg do externo troca de pasta"   "$E" "\"origem\":\"$EXT/PS5exfat/Conv-PPSA00005-US-PS5.pkg\",\"destino\":\"$EXT/PS5pkg/Conv-PPSA00005-US-PS5.pkg\""
confere "BACKUP/<jogo> entra"              "$E" "\"origem\":\"$INT/BACKUP/Bk/Bk-PPSA00003-US-PS5.exfat\",\"destino\":\"$EXT/PS5pkg/"
nao_tem "zstd nao entra no plano"          "$(echo "$E" | sed 's/"sobras".*//')" 'Zst-PPSA12771'
nao_tem "pasta do sistema nunca"           "$E" 'Instalado-PPSA09999'
confere "sobras: zstd"                     "$E" "\"sobras\":\[.*Zst-PPSA12771-US-PS5-zstd.exfat"
confere "sobras: pasta de jogo"            "$E" "\"sobras\":\[.*PastaJogo-PPSA05555"
confere "sobras: zip"                      "$E" "\"sobras\":\[.*Baixado-PPSA07777.zip"
# ordem: os com algo no interno primeiro (menor primeiro: PS4 2 KB, Tem 8 KB, Bk 6 KB...), Ext e Teste depois
N_VELHO=$(echo "$E" | grep -o '"n":[0-9]*,"tipo":"[a-z]*","tam":[0-9]*,"interno":[a-z]*,"tid":"CUSA03745"' | head -1 | grep -o '"n":[0-9]*' | cut -d: -f2)
N_GRANDE=$(echo "$E" | grep -o '"n":[0-9]*,"tipo":"converter","tam":[0-9]*,"interno":[a-z]*,"tid":"PPSA34015"' | grep -o '"n":[0-9]*' | cut -d: -f2)
N_EXT=$(echo "$E" | grep -o '"n":[0-9]*,"tipo":"converter","tam":[0-9]*,"interno":[a-z]*,"tid":"PPSA00004"' | grep -o '"n":[0-9]*' | cut -d: -f2)
confere "ordem: PS4 pequeno antes do Grande" "$([ "${N_VELHO:-99}" -lt "${N_GRANDE:-0}" ] && echo sim)" sim
confere "ordem: Grande (interno) antes do Ext" "$([ "${N_GRANDE:-99}" -lt "${N_EXT:-0}" ] && echo sim)" sim
nao_tem "analisar nao mexe em nada"        "$(find $EXT/PS5pkg $EXT/PS4pkg -name '*.pkg' 2>/dev/null)" 'pkg'

echo "--- Dump Forge fora: a fila pausa com o motivo"
post $L/api/filapkg/iniciar > /dev/null
espera pausado 20 || echo "(nao pausou)"
E=$(estado)
confere "sem Dump Forge: pausada"          "$E" '"estado":"pausado"'
confere "sem Dump Forge: motivo"           "$E" '"erro":"o Dump Forge nao esta no ar'
confere "PS4 ja foi (antes da 1a conversao)" "$(ls $EXT/PS4pkg)" 'Velho-CUSA03745-EU-PS4.pkg'
confere "PS4 saiu do interno"              "$(ls $H)" '^Tem'
nao_tem "PS4 saiu do interno (2)"          "$(ls $H)" 'Velho'

echo "--- com o Dump Forge; glibren morto no meio e religado"
liga_df
post $L/api/filapkg/continuar > /dev/null
sleep 3
kill -9 $PID 2>/dev/null; wait $PID 2>/dev/null
confere "estado gravado: rodando"          "$(cat $DADOS/fila-pkg.json)" '"estado":"rodando"'
liga_glr
espera terminado 90 || echo "(nao terminou)"
E=$(estado)
confere "terminada"                        "$E" '"estado":"terminado"'
confere "nenhum erro"                      "$E" '"erros":0,'
confere "continuou depois de religar"      "$(cat $DADOS/glibren.log)" 'filapkg: continua de onde parou'
for j in Grande-PPSA34015 Tem-PPSA00002 Dup-PPSA00007 Bk-PPSA00003 Ext-PPSA00004 Conv-PPSA00005 Teste-PPSA00006; do
  confere "PS5pkg: $j"                     "$(ls $EXT/PS5pkg)" "$j-US-PS5.pkg"
done
for j in Grande-PPSA34015 Tem-PPSA00002 Dup-PPSA00007 Bk-PPSA00003 Ext-PPSA00004 Teste-PPSA00006; do
  confere "PS5exfat: $j"                   "$(ls $EXT/PS5exfat)" "$j-US-PS5.exfat"
done
nao_tem "PS5exfat: Dup nao duplicou"       "$(ls $EXT/PS5exfat)" 'Dup-PPSA00007-US-PS5 (2)'
nao_tem "PS5exfat: nenhum .pkg"            "$(ls $EXT/PS5exfat)" '\.pkg$'
nao_tem "PS5exfat: sobra de copia"         "$(ls -a $EXT/PS5exfat $EXT/PS5pkg)" 'glr-part'
confere "copia do Grande igual (SHA-256)"  "$(sha256sum $EXT/PS5exfat/Grande-PPSA34015-US-PS5.exfat)" "$SHA_GRANDE"
confere ".pkg gerado tem cabecalho PS5"    "$(head -c 4 $EXT/PS5pkg/Grande-PPSA34015-US-PS5.pkg | od -c)" 'F   I   H'
nao_tem "interno: nenhum .exfat/.pkg normal" "$(find $INT -name '*.exfat' -o -name '*.pkg' | grep -v zstd)" '\.'
confere "interno: zstd ficou"              "$(ls $H)" 'Zst-PPSA12771-US-PS5-zstd.exfat'
confere "interno: pasta de jogo ficou"     "$(ls $H)" 'PastaJogo-PPSA05555'
confere "interno: zip ficou"               "$(ls $H)" 'Baixado-PPSA07777.zip'
confere "sistema intocado"                 "$(ls $EXT/user/app)" 'Instalado-PPSA09999.pkg'
confere "Dup: origem saiu por ser igual"   "$(cat $DADOS/glibren.log)" 'copia igual (SHA-256) no destino'
confere "conversao nao foi para o BACKUP"  "$(ls $INT/BACKUP/Bk 2>/dev/null | wc -l)" '^0$'
nao_tem "nada no BACKUP do externo"        "$(ls $EXT 2>/dev/null)" 'BACKUP'
confere "sobras no fim: 3"                 "$E" '"sobras_total":3'
confere "destinos na lista do glibren"     "$(cat $DADOS/config.ini)" "$EXT/PS5pkg"
P=$(post $L/api/filapkg/iniciar)
confere "iniciar depois de terminar: recusa" "$P" 'analise primeiro'

echo "--- de novo: nada a fazer"
post $L/api/filapkg/analisar > /dev/null
espera pronto 20
E=$(estado)
confere "segunda analise: 0 passos"        "$E" '"converter":0,"mover":0,'

echo "--- pagina"
PG=$(curl -s --compressed $L/payloads)
confere "pagina: secao Fila PKG"           "$PG" 'id="fp"'
confere "pagina: texto pt"                 "$PG" 'Fila PKG'
confere "pagina: rota"                     "$PG" '/api/filapkg/'

kill $PID $PID_DF 2>/dev/null; wait 2>/dev/null
rm -rf "$EXT"
echo "== teste_filapkg: $ok ok, $falhas falha(s)"
[ $falhas -eq 0 ]
