/* Game Library Renamer (payload PS5) - 0.9.70: Fila PKG. Ver fila_pkg.h (o que entra e as decisoes do dono).

Regras de seguranca:
  - analisar so le e monta o plano (nada e mexido); o plano aparece na pagina antes de "Iniciar";
  - discos: interno = /data; externo = o primeiro /mnt/extN ou /mnt/usbN que tem PS5exfat ou PS5pkg (no PC, testes:
    GLR_TESTE_FILAPKG_INTERNO e GLR_TESTE_FILAPKG_EXTERNO);
  - onde procura: as pastas da lista do glibren, as do ShadowKraken, <interno>/homebrew, <interno>/etaHEN/games,
    <interno>/BACKUP e a raiz do externo; dois niveis (uma subpasta), BACKUP com mais um (BACKUP/<jogo>/<arquivo>);
    pastas escondidas e as do sistema (user, system...) ficam de fora; links nunca;
  - codigo do jogo pelo nome (AAAA00000) ou de dentro do arquivo (jogo_local); PS4/PS5 pelo cabecalho do .pkg
    (\x7FCNT = PS4) ou pelo codigo (CUSA = PS4);
  - um passo por vez, numa thread; converter = conversao_fila_pedir (o original nunca vai para o BACKUP) e saida
    conferida (arquivo > 0 com cabecalho de .pkg de PS5); falhou = a saida incompleta e apagada;
  - antes de converter ou mover, o arquivo e solto do ShadowKraken (backup_soltar); jogo aberto ou sem resposta = o
    passo fica "adiado" e e tentado de novo a cada 60 s, depois dos outros;
  - mover no mesmo disco = rename; entre discos = copia para <nome>.glr-part com SHA-256, fsync, rename, le a copia de
    novo e compara o SHA-256; so entao apaga a origem. Destino com o mesmo nome: igual (SHA-256) = a origem e uma copia
    a mais e sai; diferente = o novo ganha " (2)";
  - espaco: converter pede o tamanho da origem + 5 GB livres no externo; copiar, o tamanho + 1 GB. Faltou = a fila pausa
    com o motivo; Dump Forge fora do ar tambem pausa;
  - pausar = termina o passo atual e para; parar = cancela a conversao/copia atual (apaga o que ficou pela metade);
    o plano fica e "Continuar"/"Iniciar" segue dali; "Repetir" poe os passos com erro na fila de novo;
  - o estado fica em <dados>/fila-pkg.json: o glibren atualizado ou reiniciado continua sozinho (a conversao no Dump
    Forge segue; a copia recomeca do zero);
  - no inicio as pastas de destino sao criadas e entram na lista do glibren; so no fim entram na do ShadowKraken (ele
    poderia montar um .pkg ainda sendo gravado em PS5pkg); as pastas que ele ja olhava continuam (o que a fila nao mexe
    fica la). O interno e lido de novo no fim: o que sobrou de jogo la aparece na pagina. Durante a fila os jogos
    movidos somem da biblioteca do ShadowKraken ate o fim (o dono nao joga durante a fila). */
#include "fila_pkg.h"

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <time.h>
#include <unistd.h>

#include "arquivos.h"
#include "backup.h"
#include "bateria.h"
#include "config.h"
#include "conversao.h"
#include "imagem.h"
#include "jogo_local.h"
#include "json_min.h"
#include "plataforma.h"
#include "sha256.h"
#include "sk_pastas.h"
#include "tarefas.h"

#define MAX_ITENS 800
#define MAX_PASSOS 900
#define MAX_JOGOS 400
#define MAX_RAIZES 48
#define MAX_AVISOS 64
#define MAX_SOBRAS 64
#define TAM_C 1100
#define GB (1024ULL * 1024 * 1024)
#define BLOCO (8 * 1024 * 1024)
#define SYNC_BYTES (256LL * 1024 * 1024)
#define ADIADO_S 60

typedef struct {
  char caminho[TAM_C], nome[300];
  char tipo[8];        /* "exfat" ou "pkg" */
  char tid[16], plat[4];
  int interno;
  unsigned long long tam;
} item_t;

typedef struct {
  char tid[16], nome[300], plat[4];
  int interno;
  unsigned long long tam;
} jogo_t;

typedef struct {
  int jogo;
  char tipo;           /* 'c' converter, 'm' mover */
  char origem[TAM_C], destino[TAM_C];
  unsigned long long tam, feitos, total;
  char estado[12];     /* fila, rodando, feito, erro, adiado */
  char erro[300];
  unsigned long long conv;   /* id do glibren na lista de conversoes */
  double vel;                /* bytes/s da copia */
} passo_t;

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static char g_estado[16] = "vazio";   /* vazio, analisando, pronto, rodando, pausando, pausado, parando, terminado */
static char g_interno[512], g_externo[512], g_erro[400], g_msg[300];
static jogo_t g_jogos[MAX_JOGOS];
static int g_nj;
static passo_t g_passos[MAX_PASSOS];
static int g_np;
static char g_avisos[MAX_AVISOS][300];
static int g_na;
static char g_sobras[MAX_SOBRAS][TAM_C];   /* jogos que ficam no interno (formatos que a fila nao mexe) */
static int g_ns, g_sobras_total;
static long long g_analisado, g_terminado, g_ultimo_adiado;
static int g_thread, g_parar, g_atual = -1;

static void salvar(void);

/* ------------------------------------------------------------------ discos e nomes */

static int comeca(const char *c, const char *raiz) {
  size_t n = strlen(raiz);
  return n && !strncmp(c, raiz, n) && (c[n] == '/' || !c[n]);
}

static void achar_discos(void) {
  const char *ti = getenv("GLR_TESTE_FILAPKG_INTERNO"), *te = getenv("GLR_TESTE_FILAPKG_EXTERNO");
  snprintf(g_interno, sizeof g_interno, "%s", ti && *ti ? ti : "/data");
  g_externo[0] = 0;
  if(te && *te) {
    snprintf(g_externo, sizeof g_externo, "%s", te);
    return;
  }
  static const char *const TIPOS[] = {"ext", "usb"};
  for(int t = 0; t < 2 && !g_externo[0]; t++)
    for(int n = 0; n < 8 && !g_externo[0]; n++) {
      char d[64], c[96];
      struct stat st;
      snprintf(d, sizeof d, "/mnt/%s%d", TIPOS[t], n);
      snprintf(c, sizeof c, "%s/PS5exfat", d);
      int tem = !stat(c, &st) && S_ISDIR(st.st_mode);
      snprintf(c, sizeof c, "%s/PS5pkg", d);
      tem = tem || (!stat(c, &st) && S_ISDIR(st.st_mode));
      if(tem) snprintf(g_externo, sizeof g_externo, "%s", d);
    }
}

static void destino_pasta(const char *qual, char *saida, size_t tam) { snprintf(saida, tam, "%s/%s", g_externo, qual); }

/* "-zstd"/"_lz4" etc. antes da extensao ou no meio do nome: versao compactada (a fila nao mexe) */
static int compactado(const char *nome) {
  static const char *const MARCA[] = {"zstd", "lz4", NULL};
  size_t n = strlen(nome);
  for(int m = 0; MARCA[m]; m++) {
    size_t k = strlen(MARCA[m]);
    for(size_t i = 1; i + k <= n; i++) {
      char antes = nome[i - 1], depois = i + k < n ? nome[i + k] : '.';
      if((antes == '-' || antes == '_') && !strncasecmp(nome + i, MARCA[m], k) && (depois == '-' || depois == '_' || depois == '.'))
        return 1;
    }
  }
  return 0;
}

static int termina(const char *s, const char *fim) {
  size_t a = strlen(s), b = strlen(fim);
  return a > b && !strcasecmp(s + a - b, fim);
}

static int tid_no_nome(const char *nome, char *tid, size_t tam) {
  for(size_t i = 0; nome[i]; i++) {
    int ok = 1;
    for(int k = 0; k < 9 && ok; k++) {
      char c = nome[i + k];
      ok = k < 4 ? (c >= 'A' && c <= 'Z') : (c >= '0' && c <= '9');
    }
    if(ok && !(nome[i + 9] >= '0' && nome[i + 9] <= '9') && !(i && nome[i - 1] >= 'A' && nome[i - 1] <= 'Z')) {
      snprintf(tid, tam, "%.9s", nome + i);
      return 1;
    }
  }
  return 0;
}

/* cabecalho do .pkg: "PS4" (\x7FCNT), "PS5" (\x7FFIH ou \x7FLIH) ou "" */
static void plat_pkg(const char *caminho, char *plat, size_t tam) {
  unsigned char h[4] = {0};
  plat[0] = 0;
  int fd = open(caminho, O_RDONLY);
  if(fd < 0) return;
  ssize_t n = read(fd, h, sizeof h);
  close(fd);
  if(n != 4 || h[0] != 0x7F) return;
  if(!memcmp(h + 1, "CNT", 3)) snprintf(plat, tam, "PS4");
  else if(!memcmp(h + 1, "FIH", 3) || !memcmp(h + 1, "LIH", 3)) snprintf(plat, tam, "PS5");
}

static void avisar(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
static void avisar(const char *fmt, ...) {
  if(g_na >= MAX_AVISOS) return;
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(g_avisos[g_na++], sizeof g_avisos[0], fmt, ap);
  va_end(ap);
}

/* ------------------------------------------------------------------ analisar */

typedef struct {
  item_t *it;
  int n;
  char raizes[MAX_RAIZES][TAM_C];
  int nr;
  char icones[600];
} busca_t;

static int ja_vista(busca_t *b, const char *pasta) {
  for(int i = 0; i < b->nr; i++)
    if(!strcmp(b->raizes[i], pasta)) return 1;
  if(b->nr < MAX_RAIZES) snprintf(b->raizes[b->nr++], TAM_C, "%s", pasta);
  return 0;
}

static int pasta_sistema(const char *nome) {
  static const char *const SIS[] = {"user", "system", "system_data", "system_tmp", "sce_sys", "app", "appmeta", "playgo",
                                    "$RECYCLE.BIN", "System Volume Information", NULL};
  for(int i = 0; SIS[i]; i++)
    if(!strcasecmp(nome, SIS[i])) return 1;
  return 0;
}

static void sobrou(const char *caminho) {
  g_sobras_total++;
  if(g_ns < MAX_SOBRAS) snprintf(g_sobras[g_ns++], TAM_C, "%s", caminho);
}

static void varrer(busca_t *b, const char *pasta, int nivel) {
  char limpa[TAM_C];
  snprintf(limpa, sizeof limpa, "%s", pasta);
  size_t lp = strlen(limpa);
  while(lp > 1 && limpa[lp - 1] == '/') limpa[--lp] = 0;
  if(!comeca(limpa, g_interno) && !comeca(limpa, g_externo)) return;
  if(ja_vista(b, limpa)) return;
  DIR *d = opendir(limpa);
  if(!d) return;
  struct dirent *e;
  while((e = readdir(d))) {
    const char *nm = e->d_name;
    if(nm[0] == '.' || strlen(nm) >= 300) continue;
    char c[TAM_C];
    snprintf(c, sizeof c, "%s/%s", limpa, nm);
    struct stat st;
    if(lstat(c, &st)) continue;
    int interno = comeca(c, g_interno);
    if(S_ISDIR(st.st_mode)) {
      if(arquivos_pasta_de_jogo(c)) {
        if(interno) sobrou(c);
        continue;
      }
      if(pasta_sistema(nm)) continue;
      if(!strcasecmp(nm, "BACKUP")) varrer(b, c, 1);   /* BACKUP/<jogo>/<arquivo> */
      else if(nivel < 2) varrer(b, c, nivel + 1);
      continue;
    }
    if(!S_ISREG(st.st_mode) || termina(nm, SUFIXO_PARCIAL) || em_download(limpa, nm)) continue;
    int exfat = termina(nm, ".exfat"), pkg = termina(nm, ".pkg");
    if((!exfat && !pkg) || (exfat && compactado(nm))) {
      static const char *const OUTROS[] = {".ffpkg", ".ffpfs", ".ffpfsc", ".exfat", ".zip", ".7z", ".rar", NULL};
      for(int i = 0; OUTROS[i] && interno; i++)
        if(termina(nm, OUTROS[i])) {
          sobrou(c);
          break;
        }
      continue;
    }
    if(b->n >= MAX_ITENS) {
      avisar("jogos demais: so os primeiros %d arquivos entraram no plano", MAX_ITENS);
      continue;
    }
    item_t *it = &b->it[b->n];
    memset(it, 0, sizeof *it);
    snprintf(it->caminho, sizeof it->caminho, "%s", c);
    snprintf(it->nome, sizeof it->nome, "%s", nm);
    snprintf(it->tipo, sizeof it->tipo, "%s", pkg ? "pkg" : "exfat");
    it->interno = interno;
    it->tam = (unsigned long long)st.st_size;
    if(!tid_no_nome(nm, it->tid, sizeof it->tid)) {
      info_jogo_t info;
      char fmt[16];
      if(!jogo_local(c, b->icones, &info, fmt, sizeof fmt) && info.title_id[0])
        snprintf(it->tid, sizeof it->tid, "%s", info.title_id);
    }
    if(pkg) plat_pkg(c, it->plat, sizeof it->plat);
    if(!it->plat[0]) snprintf(it->plat, sizeof it->plat, "%s", !strncmp(it->tid, "CUSA", 4) ? "PS4" : "PS5");
    b->n++;
  }
  closedir(d);
}

static int ordem_jogos(const void *a, const void *b) {
  const jogo_t *x = a, *y = b;
  if(x->interno != y->interno) return y->interno - x->interno;
  return x->tam < y->tam ? -1 : x->tam > y->tam;
}

static void pasta_de(const char *caminho, char *saida, size_t tam) {
  snprintf(saida, tam, "%s", caminho);
  char *b = strrchr(saida, '/');
  if(b) *b = 0;
}

static void novo_passo(int jogo, char tipo, const char *origem, const char *destino, unsigned long long tam) {
  if(g_np >= MAX_PASSOS) return;
  passo_t *p = &g_passos[g_np++];
  memset(p, 0, sizeof *p);
  p->jogo = jogo;
  p->tipo = tipo;
  snprintf(p->origem, sizeof p->origem, "%s", origem);
  snprintf(p->destino, sizeof p->destino, "%s", destino);
  p->tam = tam;
  snprintf(p->estado, sizeof p->estado, "fila");
}

/* destino ja usado por outro passo do plano */
static int destino_planejado(const char *d) {
  for(int i = 0; i < g_np; i++)
    if(!strcmp(g_passos[i].destino, d)) return 1;
  return 0;
}

/* monta o plano a partir dos itens (com a trava) */
static void planejar(item_t *it, int n) {
  g_nj = g_np = 0;
  char dpkg[600], dexfat[600], dps4[600];
  destino_pasta("PS5pkg", dpkg, sizeof dpkg);
  destino_pasta("PS5exfat", dexfat, sizeof dexfat);
  destino_pasta("PS4pkg", dps4, sizeof dps4);
  int jogo_de[MAX_ITENS];
  for(int i = 0; i < n; i++) {
    int j;
    for(j = 0; j < g_nj; j++)
      if(it[i].tid[0] ? !strcmp(g_jogos[j].tid, it[i].tid) : !strcmp(g_jogos[j].nome, it[i].nome)) break;
    if(j == g_nj) {
      if(g_nj >= MAX_JOGOS) {
        jogo_de[i] = -1;
        continue;
      }
      memset(&g_jogos[j], 0, sizeof g_jogos[j]);
      snprintf(g_jogos[j].tid, sizeof g_jogos[j].tid, "%s", it[i].tid);
      snprintf(g_jogos[j].nome, sizeof g_jogos[j].nome, "%s", it[i].nome);
      char *ext = strrchr(g_jogos[j].nome, '.');
      if(ext) *ext = 0;
      snprintf(g_jogos[j].plat, sizeof g_jogos[j].plat, "%s", it[i].plat);
      g_nj++;
    }
    jogo_de[i] = j;
    g_jogos[j].interno |= it[i].interno;
    g_jogos[j].tam += it[i].tam;
    if(!it[i].tid[0]) avisar("%s: sem codigo do jogo (nem no nome nem dentro)", it[i].caminho);
  }
  /* ordem: com algo no interno primeiro, depois do menor para o maior (decisao do dono) */
  int ordem[MAX_JOGOS];
  jogo_t copia[MAX_JOGOS];
  memcpy(copia, g_jogos, (size_t)g_nj * sizeof *copia);
  for(int j = 0; j < g_nj; j++) ordem[j] = j;
  for(int a = 1; a < g_nj; a++)
    for(int b = a; b > 0 && ordem_jogos(&copia[ordem[b]], &copia[ordem[b - 1]]) < 0; b--) {
      int t = ordem[b];
      ordem[b] = ordem[b - 1];
      ordem[b - 1] = t;
    }
  int novo[MAX_JOGOS];
  for(int k = 0; k < g_nj; k++) {
    g_jogos[k] = copia[ordem[k]];
    novo[ordem[k]] = k;
  }
  for(int k = 0; k < g_nj; k++) {
    int tem_pkg = 0, fonte = -1;
    for(int i = 0; i < n; i++) {
      if(jogo_de[i] < 0 || novo[jogo_de[i]] != k) continue;
      if(!strcmp(it[i].tipo, "pkg")) tem_pkg = 1;
      else if(fonte < 0 || (it[i].interno && !it[fonte].interno)) fonte = i;
    }
    jogo_t *g = &g_jogos[k];
    if(!tem_pkg && fonte >= 0) {
      if(strcmp(g->plat, "PS5")) {
        avisar("%s (%s): jogo de PS4 sem .pkg: o .exfat so e movido", g->nome, g->tid);
      } else {
        char base[300], dest[TAM_C];
        snprintf(base, sizeof base, "%s", it[fonte].nome);
        base[strlen(base) - 6] = 0;   /* tira ".exfat" */
        snprintf(dest, sizeof dest, "%s/%s.pkg", dpkg, base);
        struct stat st;
        for(int s = 2; (!lstat(dest, &st) || destino_planejado(dest)) && s < 20; s++)
          snprintf(dest, sizeof dest, "%s/%s (%d).pkg", dpkg, base, s);
        novo_passo(k, 'c', it[fonte].caminho, dest, it[fonte].tam);
      }
    }
    for(int i = 0; i < n; i++) {
      if(jogo_de[i] < 0 || novo[jogo_de[i]] != k) continue;
      const char *alvo = strcmp(it[i].tipo, "pkg") ? dexfat : strcmp(it[i].plat, "PS4") ? dpkg : dps4;
      char pasta[TAM_C], dest[TAM_C];
      pasta_de(it[i].caminho, pasta, sizeof pasta);
      if(!strcmp(pasta, alvo)) continue;
      snprintf(dest, sizeof dest, "%s/%s", alvo, it[i].nome);
      novo_passo(k, 'm', it[i].caminho, dest, it[i].tam);
    }
  }
}

static void *analisar(void *arg) {
  (void)arg;
  busca_t *b = calloc(1, sizeof *b);
  item_t *it = calloc(MAX_ITENS, sizeof *it);
  pthread_mutex_lock(&g_trava);
  g_na = g_ns = g_sobras_total = 0;
  g_erro[0] = g_msg[0] = 0;
  achar_discos();
  pthread_mutex_unlock(&g_trava);
  if(!b || !it || !g_externo[0]) {
    pthread_mutex_lock(&g_trava);
    snprintf(g_erro, sizeof g_erro, "%s", !g_externo[0] ? "nao achei as pastas PS5exfat ou PS5pkg em nenhum disco externo (/mnt/extN ou /mnt/usbN)" : "sem memoria");
    snprintf(g_estado, sizeof g_estado, "vazio");
    g_thread = 0;
    pthread_mutex_unlock(&g_trava);
    free(b);
    free(it);
    salvar();
    return NULL;
  }
  b->it = it;
  snprintf(b->icones, sizeof b->icones, "%s/icones", g_pasta_dados);
  /* pastas da lista do glibren e do ShadowKraken + as padrao + a raiz do externo */
  static char lista[MAX_PASTAS][1024];
  char idioma[16], c[TAM_C];
  int nl = config_ler(lista, idioma);
  for(int i = 0; i < nl; i++) varrer(b, lista[i], 1);
  static char sk[64][SK_PASTA_TAM];
  int padrao = 0, prof = 1, ns = sk_pastas_listar(sk, 64, &padrao, &prof);
  const char *rsk = getenv("GLR_TESTE_SK_RAIZ");
  for(int i = 0; i < ns; i++) {
    snprintf(c, sizeof c, "%s%s", rsk && *rsk ? rsk : "", sk[i]);
    varrer(b, c, 1);
  }
  static const char *const PADRAO[] = {"homebrew", "etaHEN/games", "BACKUP", "backup", NULL};
  for(int i = 0; PADRAO[i]; i++) {
    snprintf(c, sizeof c, "%s/%s", g_interno, PADRAO[i]);
    varrer(b, c, 1);
  }
  varrer(b, g_externo, 1);
  pthread_mutex_lock(&g_trava);
  planejar(it, b->n);
  g_analisado = (long long)time(NULL);
  g_terminado = 0;
  snprintf(g_estado, sizeof g_estado, "pronto");
  g_thread = 0;
  int np = g_np, nj = g_nj;
  pthread_mutex_unlock(&g_trava);
  diario("filapkg: analise: %d arquivos, %d jogos, %d passos; externo %s; %d avisos; %d coisas que ficam no interno",
         b->n, nj, np, g_externo, g_na, g_sobras_total);
  free(b);
  free(it);
  salvar();
  return NULL;
}

/* ------------------------------------------------------------------ executar */

/* folga exigida alem do tamanho (testes no PC: GLR_TESTE_FILAPKG_FOLGA_MB) */
static unsigned long long folga(unsigned long long padrao) {
#ifndef __PROSPERO__
  const char *v = getenv("GLR_TESTE_FILAPKG_FOLGA_MB");
  if(v && *v) return strtoull(v, NULL, 10) * 1024 * 1024;
#endif
  return padrao;
}

static unsigned long long livre(const char *pasta) {
  struct statvfs v;
  if(statvfs(pasta, &v)) return 0;
  return (unsigned long long)v.f_bavail * v.f_frsize;
}

static int sha_arquivo(const char *c, unsigned char res[32], volatile int *parar) {
  int fd = open(c, O_RDONLY);
  if(fd < 0) return -1;
  char *buf = malloc(BLOCO);
  if(!buf) {
    close(fd);
    return -1;
  }
  sha256_t s;
  sha256_iniciar(&s);
  ssize_t n;
  int r = 0;
  while((n = read(fd, buf, BLOCO)) > 0) {
    sha256_atualizar(&s, buf, (size_t)n);
    if(*parar) {
      r = -2;
      break;
    }
  }
  if(n < 0) r = -1;
  free(buf);
  close(fd);
  if(!r) sha256_final(&s, res);
  return r;
}

static void progresso(int i, unsigned long long feitos, unsigned long long total, double vel) {
  pthread_mutex_lock(&g_trava);
  g_passos[i].feitos = feitos;
  g_passos[i].total = total;
  if(vel > 0) g_passos[i].vel = vel;
  pthread_mutex_unlock(&g_trava);
}

static double agora_s(void) {
  struct timespec t;
  clock_gettime(CLOCK_MONOTONIC, &t);
  return t.tv_sec + t.tv_nsec / 1e9;
}

/* copia com SHA-256, fsync e rename; le a copia de novo e compara. 0 = ok; -2 = parado; senao erro (msg). */
static int copiar_conferindo(int i, const char *origem, const char *destino, unsigned long long tam, char *msg, size_t tm) {
  char parcial[TAM_C + 16];
  snprintf(parcial, sizeof parcial, "%s%s", destino, SUFIXO_PARCIAL);
  unlink(parcial);
  int in = open(origem, O_RDONLY), out = -1;
  if(in < 0) {
    snprintf(msg, tm, "nao abriu a origem: %s", strerror(errno));
    return -1;
  }
  out = open(parcial, O_WRONLY | O_CREAT | O_EXCL, 0666);
  if(out < 0) {
    snprintf(msg, tm, "nao criou a copia: %s", strerror(errno));
    close(in);
    return -1;
  }
  char *buf = malloc(BLOCO);
  sha256_t s;
  sha256_iniciar(&s);
  unsigned long long feito = 0;
  long long desde_sync = 0;
  double t0 = agora_s(), tv = t0;
  unsigned long long fv = 0;
  int r = buf ? 0 : -1;
  if(!buf) snprintf(msg, tm, "sem memoria");
  while(!r) {
    ssize_t n = read(in, buf, BLOCO);
    if(n < 0) {
      snprintf(msg, tm, "erro lendo a origem: %s", strerror(errno));
      r = -1;
      break;
    }
    if(!n) break;
    sha256_atualizar(&s, buf, (size_t)n);
    for(ssize_t w = 0; w < n;) {
      ssize_t k = write(out, buf + w, (size_t)(n - w));
      if(k <= 0) {
        snprintf(msg, tm, "erro gravando a copia: %s", k < 0 ? strerror(errno) : "disco cheio");
        r = -1;
        break;
      }
      w += k;
    }
    feito += (unsigned long long)n;
    desde_sync += n;
    if(desde_sync >= SYNC_BYTES) {
      fsync(out);
      desde_sync = 0;
    }
    double t = agora_s();
    if(t - tv >= 1) {
      progresso(i, feito, tam * 2, (feito - fv) / (t - tv));
      tv = t;
      fv = feito;
    }
    if(g_parar) r = -2;
  }
  close(in);
  if(!r && fsync(out)) {
    snprintf(msg, tm, "erro gravando a copia (fsync): %s", strerror(errno));
    r = -1;
  }
  close(out);
  free(buf);
  unsigned char a[32], c[32];
  if(!r) sha256_final(&s, a);
  if(!r && feito != tam) {
    snprintf(msg, tm, "a origem mudou de tamanho durante a copia");
    r = -1;
  }
  if(!r && rename(parcial, destino)) {
    snprintf(msg, tm, "nao deu o nome final a copia: %s", strerror(errno));
    r = -1;
  }
  if(r) {
    unlink(parcial);
    return r;
  }
  progresso(i, tam, tam * 2, 0);
  int v = sha_arquivo(destino, c, &g_parar);
  if(v || memcmp(a, c, 32)) {
    unlink(destino);
    if(v == -2) return -2;
    snprintf(msg, tm, "%s", v ? "nao leu a copia para conferir" : "a copia nao bate com a origem (SHA-256): apagada, a origem ficou");
    return -1;
  }
  progresso(i, tam * 2, tam * 2, 0);
  return 0;
}

/* resultado de um passo */
static void fim_passo(int i, const char *estado, const char *fmt, ...) __attribute__((format(printf, 3, 4)));
static void fim_passo(int i, const char *estado, const char *fmt, ...) {
  pthread_mutex_lock(&g_trava);
  passo_t *p = &g_passos[i];
  snprintf(p->estado, sizeof p->estado, "%s", estado);
  p->erro[0] = 0;
  if(fmt) {
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(p->erro, sizeof p->erro, fmt, ap);
    va_end(ap);
  }
  char o[TAM_C], e[300];
  snprintf(o, sizeof o, "%s", p->origem);
  snprintf(e, sizeof e, "%s", p->erro);
  char tipo = p->tipo;
  pthread_mutex_unlock(&g_trava);
  diario("filapkg: %s %s: %s%s%s%s", tipo == 'c' ? "converter" : "mover", estado, o, e[0] ? " (" : "", e, e[0] ? ")" : "");
  salvar();
}

/* pausa a fila inteira com um motivo (sem espaco, Dump Forge fora...) */
static void pausar_com(int i, const char *motivo) {
  pthread_mutex_lock(&g_trava);
  snprintf(g_passos[i].estado, sizeof g_passos[i].estado, "fila");
  snprintf(g_erro, sizeof g_erro, "%s", motivo);
  snprintf(g_estado, sizeof g_estado, "pausado");
  pthread_mutex_unlock(&g_trava);
  diario("filapkg: pausada: %s", motivo);
  salvar();
}

static int soltar(int i, const char *caminho) {
  backup_res_t r;
  if(!backup_soltar(caminho, &r)) return 0;
  fim_passo(i, "adiado", "o ShadowKraken nao soltou o jogo (%s%s%s): tento de novo daqui a pouco", r.chave, r.detalhe[0] ? ": " : "", r.detalhe);
  return 1;
}

static void converter(int i) {
  passo_t p;
  pthread_mutex_lock(&g_trava);
  p = g_passos[i];
  pthread_mutex_unlock(&g_trava);
  struct stat st;
  if(!p.conv) {
    if(!lstat(p.destino, &st)) {
      fim_passo(i, "erro", "o destino ja existe: %s", p.destino);
      return;
    }
    if(lstat(p.origem, &st)) {
      fim_passo(i, "erro", "a origem sumiu");
      return;
    }
    if(soltar(i, p.origem)) return;
    char pasta[TAM_C];
    pasta_de(p.destino, pasta, sizeof pasta);
    if(livre(pasta) < p.tam + folga(5 * GB)) {
      char m[200];
      snprintf(m, sizeof m, "falta espaco no externo para converter %s (precisa de %llu GB livres)", strrchr(p.origem, '/') + 1, (p.tam + folga(5 * GB)) / GB);
      pausar_com(i, m);
      return;
    }
    char erro[300];
    unsigned long long id = conversao_fila_pedir(p.origem, p.destino, erro, sizeof erro);
    if(!id) {
      if(strstr(erro, "Dump Forge")) pausar_com(i, erro);
      else fim_passo(i, "erro", "%s", erro);
      return;
    }
    pthread_mutex_lock(&g_trava);
    g_passos[i].conv = id;
    pthread_mutex_unlock(&g_trava);
    salvar();
    p.conv = id;
  }
  int cancelou = 0;
  for(;;) {
    char est[16], erro[400];
    unsigned long long f = 0, t = 0;
    if(conversao_fila_estado(p.conv, est, sizeof est, &f, &t, erro, sizeof erro)) {
      snprintf(est, sizeof est, "perdido");
      snprintf(erro, sizeof erro, "a conversao sumiu da lista do glibren");
    }
    progresso(i, f, t, 0);
    if(!strcmp(est, "feito")) break;
    if(!strcmp(est, "erro") || !strcmp(est, "cancelado") || !strcmp(est, "perdido")) {
      if(!lstat(p.destino, &st) && S_ISREG(st.st_mode)) unlink(p.destino);   /* saida pela metade (so a nossa) */
      pthread_mutex_lock(&g_trava);
      g_passos[i].conv = 0;
      pthread_mutex_unlock(&g_trava);
      if(cancelou || g_parar) fim_passo(i, "fila", NULL);
      else fim_passo(i, "erro", "conversao %s: %s", est, erro);
      return;
    }
    if(g_parar && !cancelou) {
      conversao_fila_cancelar(p.conv);
      cancelou = 1;
    }
    sleep(2);
  }
  char plat[4];
  plat_pkg(p.destino, plat, sizeof plat);
  if(lstat(p.destino, &st) || st.st_size <= 0 || strcmp(plat, "PS5")) {
    fim_passo(i, "erro", "o Dump Forge terminou mas o .pkg nao confere (falta, vazio ou cabecalho errado): %s", p.destino);
    return;
  }
  fim_passo(i, "feito", "%llu MB -> %llu MB", p.tam >> 20, (unsigned long long)st.st_size >> 20);
}

static void mover(int i) {
  passo_t p;
  pthread_mutex_lock(&g_trava);
  p = g_passos[i];
  pthread_mutex_unlock(&g_trava);
  struct stat so, sd;
  if(lstat(p.origem, &so)) {
    if(!lstat(p.destino, &sd)) fim_passo(i, "feito", "ja estava no destino");
    else fim_passo(i, "erro", "a origem sumiu");
    return;
  }
  if(soltar(i, p.origem)) return;
  char pasta[TAM_C], destino[TAM_C];
  pasta_de(p.destino, pasta, sizeof pasta);
  mkdir_p(pasta);
  snprintf(destino, sizeof destino, "%s", p.destino);
  if(!lstat(destino, &sd)) {
    if(S_ISREG(sd.st_mode) && sd.st_size == so.st_size) {
      unsigned char a[32], b[32];
      progresso(i, 0, p.tam * 2, 0);
      int ra = sha_arquivo(p.origem, a, &g_parar), rb = ra ? ra : sha_arquivo(destino, b, &g_parar);
      if(ra == -2 || rb == -2) {
        fim_passo(i, "fila", NULL);
        return;
      }
      if(!ra && !rb && !memcmp(a, b, 32)) {
        if(unlink(p.origem)) fim_passo(i, "erro", "copia igual ja esta no destino, mas nao apagou a origem: %s", strerror(errno));
        else fim_passo(i, "feito", "ja havia uma copia igual (SHA-256) no destino: a origem saiu");
        return;
      }
    }
    char base[TAM_C], *ext;
    snprintf(base, sizeof base, "%s", p.destino);
    ext = strrchr(base, '.');
    char sufixo[16] = "";
    if(ext && ext > strrchr(base, '/')) {
      snprintf(sufixo, sizeof sufixo, "%s", ext);
      *ext = 0;
    }
    for(int s = 2; !lstat(destino, &sd) && s < 50; s++) snprintf(destino, sizeof destino, "%s (%d)%s", base, s, sufixo);
    if(!lstat(destino, &sd)) {
      fim_passo(i, "erro", "o destino ja existe");
      return;
    }
    pthread_mutex_lock(&g_trava);
    snprintf(g_passos[i].destino, sizeof g_passos[i].destino, "%s", destino);
    pthread_mutex_unlock(&g_trava);
  }
  struct stat sp;
  if(!stat(pasta, &sp) && sp.st_dev == so.st_dev) {
    if(rename(p.origem, destino)) fim_passo(i, "erro", "nao trocou de pasta: %s", strerror(errno));
    else fim_passo(i, "feito", NULL);
    return;
  }
  if(livre(pasta) < p.tam + folga(GB)) {
    char m[200];
    snprintf(m, sizeof m, "falta espaco no externo para mover %s (precisa de %llu GB livres)", strrchr(p.origem, '/') + 1, (p.tam + folga(GB)) / GB);
    pausar_com(i, m);
    return;
  }
  char msg[300] = "";
  int r = copiar_conferindo(i, p.origem, destino, (unsigned long long)so.st_size, msg, sizeof msg);
  if(r == -2) {
    fim_passo(i, "fila", NULL);
    return;
  }
  if(r) {
    fim_passo(i, "erro", "%s", msg);
    return;
  }
  if(unlink(p.origem)) fim_passo(i, "erro", "copiado e conferido, mas nao apagou a origem: %s", strerror(errno));
  else fim_passo(i, "feito", "copiado, conferido pelo SHA-256 e apagado da origem");
}

static void terminar(void) {
  char dpkg[600], dexfat[600], dps4[600], erro[300] = "";
  destino_pasta("PS5pkg", dpkg, sizeof dpkg);
  destino_pasta("PS5exfat", dexfat, sizeof dexfat);
  destino_pasta("PS4pkg", dps4, sizeof dps4);
  /* lista do ShadowKraken: os destinos + as pastas que ainda tem coisa que a fila nao mexe (ficam la ate o dono ver) */
  const char *ps[3] = {dpkg, dexfat, dps4};
  if(sk_pastas_definir(ps, 3, 0, erro, sizeof erro)) diario("filapkg: pastas do ShadowKraken nao mudaram: %s", erro);
  backup_pedir_releitura();
  /* le o interno de novo: o que sobrou */
  busca_t *b = calloc(1, sizeof *b);
  item_t *it = calloc(MAX_ITENS, sizeof *it);
  pthread_mutex_lock(&g_trava);
  g_ns = g_sobras_total = 0;
  pthread_mutex_unlock(&g_trava);
  if(b && it) {
    b->it = it;
    snprintf(b->icones, sizeof b->icones, "%s/icones", g_pasta_dados);
    static const char *const PADRAO[] = {"homebrew", "etaHEN/games", "BACKUP", "backup", NULL};
    char c[TAM_C];
    for(int i = 0; PADRAO[i]; i++) {
      snprintf(c, sizeof c, "%s/%s", g_interno, PADRAO[i]);
      varrer(b, c, 1);
    }
    static char lista[MAX_PASTAS][1024];
    char idioma[16];
    int nl = config_ler(lista, idioma);
    for(int i = 0; i < nl; i++)
      if(comeca(lista[i], g_interno)) varrer(b, lista[i], 1);
    pthread_mutex_lock(&g_trava);
    for(int i = 0; i < b->n; i++)
      if(it[i].interno) sobrou(it[i].caminho);   /* .exfat/.pkg que nao sairam (erro) */
    pthread_mutex_unlock(&g_trava);
  }
  free(b);
  free(it);
  pthread_mutex_lock(&g_trava);
  snprintf(g_estado, sizeof g_estado, "terminado");
  g_terminado = (long long)time(NULL);
  int ns = g_sobras_total;
  pthread_mutex_unlock(&g_trava);
  diario("filapkg: terminada; %d coisas de jogo ficaram no interno", ns);
}

static void *executor(void *arg) {
  (void)arg;
  for(;;) {
    pthread_mutex_lock(&g_trava);
    if(!strcmp(g_estado, "pausando")) snprintf(g_estado, sizeof g_estado, "pausado");
    if(!strcmp(g_estado, "parando")) snprintf(g_estado, sizeof g_estado, "pronto");
    if(strcmp(g_estado, "rodando")) {
      g_thread = 0;
      g_atual = -1;
      g_parar = 0;
      pthread_mutex_unlock(&g_trava);
      salvar();
      return NULL;
    }
    int i = -1, adiados = 0;
    for(int k = 0; k < g_np && i < 0; k++)
      if(!strcmp(g_passos[k].estado, "rodando")) i = k;   /* continua o que estava andando (glibren reiniciou) */
    for(int k = 0; k < g_np && i < 0; k++)
      if(!strcmp(g_passos[k].estado, "fila")) i = k;
    for(int k = 0; k < g_np; k++) adiados += !strcmp(g_passos[k].estado, "adiado");
    if(i < 0 && adiados) {
      long long t = (long long)time(NULL);
      if(t - g_ultimo_adiado >= ADIADO_S) {
        g_ultimo_adiado = t;
        for(int k = 0; k < g_np; k++)
          if(!strcmp(g_passos[k].estado, "adiado")) snprintf(g_passos[k].estado, sizeof g_passos[k].estado, "fila");
      }
      snprintf(g_msg, sizeof g_msg, "%d passo(s) esperando o jogo ser fechado ou solto pelo ShadowKraken", adiados);
      pthread_mutex_unlock(&g_trava);
      sleep(2);
      continue;
    }
    if(i < 0) {
      g_msg[0] = 0;
      pthread_mutex_unlock(&g_trava);
      terminar();
      continue;
    }
    g_msg[0] = 0;
    g_atual = i;
    snprintf(g_passos[i].estado, sizeof g_passos[i].estado, "rodando");
    char tipo = g_passos[i].tipo;
    pthread_mutex_unlock(&g_trava);
    salvar();
    if(tipo == 'c') converter(i);
    else mover(i);
    pthread_mutex_lock(&g_trava);
    g_atual = -1;
    pthread_mutex_unlock(&g_trava);
  }
}

static void ligar_executor(void) {
  /* com a trava */
  if(g_thread) return;
  g_thread = 1;
  if(criar_thread(executor, NULL, NULL)) {
    g_thread = 0;
    snprintf(g_estado, sizeof g_estado, "pausado");
    snprintf(g_erro, sizeof g_erro, "nao criou a thread da fila");
  }
}

/* ------------------------------------------------------------------ gravar e ler */

static void arquivo(char *s, size_t t) { snprintf(s, t, "%s/fila-pkg.json", g_pasta_dados); }

static void salvar(void) {
  buf_t b = {0};
  pthread_mutex_lock(&g_trava);
  buf_str(&b, "{\"versao\":1,\"estado\":");
  buf_json(&b, g_estado);
  buf_str(&b, ",\"interno\":");
  buf_json(&b, g_interno);
  buf_str(&b, ",\"externo\":");
  buf_json(&b, g_externo);
  buf_str(&b, ",\"erro\":");
  buf_json(&b, g_erro);
  buf_fmt(&b, ",\"analisado\":%lld,\"terminado\":%lld,\"sobras_total\":%d,\"jogos\":[", g_analisado, g_terminado, g_sobras_total);
  for(int j = 0; j < g_nj; j++) {
    buf_str(&b, j ? ",{\"tid\":" : "{\"tid\":");
    buf_json(&b, g_jogos[j].tid);
    buf_str(&b, ",\"nome\":");
    buf_json(&b, g_jogos[j].nome);
    buf_str(&b, ",\"plat\":");
    buf_json(&b, g_jogos[j].plat);
    buf_fmt(&b, ",\"interno\":%d,\"tam\":%llu}", g_jogos[j].interno, g_jogos[j].tam);
  }
  buf_str(&b, "],\"passos\":[");
  for(int i = 0; i < g_np; i++) {
    const passo_t *p = &g_passos[i];
    buf_fmt(&b, "%s{\"jogo\":%d,\"tipo\":\"%c\",\"tam\":%llu,\"conv\":%llu,\"origem\":", i ? "," : "", p->jogo, p->tipo, p->tam, p->conv);
    buf_json(&b, p->origem);
    buf_str(&b, ",\"destino\":");
    buf_json(&b, p->destino);
    buf_str(&b, ",\"estado\":");
    buf_json(&b, p->estado);
    buf_str(&b, ",\"erro\":");
    buf_json(&b, p->erro);
    buf_str(&b, "}");
  }
  buf_str(&b, "],\"avisos\":[");
  for(int i = 0; i < g_na; i++) {
    if(i) buf_str(&b, ",");
    buf_json(&b, g_avisos[i]);
  }
  buf_str(&b, "],\"sobras\":[");
  for(int i = 0; i < g_ns; i++) {
    if(i) buf_str(&b, ",");
    buf_json(&b, g_sobras[i]);
  }
  buf_str(&b, "]}\n");
  pthread_mutex_unlock(&g_trava);
  char a[700], tmp[720];
  arquivo(a, sizeof a);
  snprintf(tmp, sizeof tmp, "%s.novo", a);
  FILE *f = fopen(tmp, "wb");
  if(f) {
    int ok = fwrite(b.d, 1, b.n, f) == b.n;
    ok = !fclose(f) && ok;
    if(ok) rename(tmp, a);
    else unlink(tmp);
  }
  buf_free(&b);
}

static void txt(const js_t *o, const char *chave, char *saida, size_t tam) {
  js_t v;
  if(js_campo(o, chave, &v) && !js_nulo(&v)) js_string(&v, saida, tam);
}

static int ler_jogo(const js_t *item, void *ctx) {
  (void)ctx;
  if(g_nj >= MAX_JOGOS) return 0;
  jogo_t *j = &g_jogos[g_nj++];
  memset(j, 0, sizeof *j);
  js_t v;
  txt(item, "tid", j->tid, sizeof j->tid);
  txt(item, "nome", j->nome, sizeof j->nome);
  txt(item, "plat", j->plat, sizeof j->plat);
  if(js_campo(item, "interno", &v)) j->interno = (int)js_num(&v);
  if(js_campo(item, "tam", &v)) j->tam = js_num(&v);
  return 1;
}

static int ler_passo(const js_t *item, void *ctx) {
  (void)ctx;
  if(g_np >= MAX_PASSOS) return 0;
  passo_t *p = &g_passos[g_np];
  memset(p, 0, sizeof *p);
  js_t v;
  char tipo[4] = "";
  txt(item, "tipo", tipo, sizeof tipo);
  p->tipo = tipo[0] == 'c' ? 'c' : 'm';
  if(js_campo(item, "jogo", &v)) p->jogo = (int)js_num(&v);
  if(js_campo(item, "tam", &v)) p->tam = js_num(&v);
  if(js_campo(item, "conv", &v)) p->conv = js_num(&v);
  txt(item, "origem", p->origem, sizeof p->origem);
  txt(item, "destino", p->destino, sizeof p->destino);
  txt(item, "estado", p->estado, sizeof p->estado);
  txt(item, "erro", p->erro, sizeof p->erro);
  if(p->jogo < 0 || p->jogo >= g_nj || !p->origem[0]) return 1;
  /* copia que estava andando recomeca do zero; conversao continua (o Dump Forge e outro processo) */
  if(!strcmp(p->estado, "rodando") && p->tipo == 'm') snprintf(p->estado, sizeof p->estado, "fila");
  g_np++;
  return 1;
}

static int ler_texto(const js_t *item, void *ctx) {
  int sobras = ctx != NULL;
  js_t j = *item;
  if(sobras) {
    if(g_ns < MAX_SOBRAS) js_string(&j, g_sobras[g_ns++], TAM_C);
  } else if(g_na < MAX_AVISOS) {
    js_string(&j, g_avisos[g_na++], sizeof g_avisos[0]);
  }
  return 1;
}

void fila_pkg_iniciar(void) {
  char a[700];
  arquivo(a, sizeof a);
  FILE *f = fopen(a, "rb");
  if(!f) return;
  buf_t b = {0};
  char tmp[65536];
  size_t n;
  while((n = fread(tmp, 1, sizeof tmp, f)) > 0) buf_add(&b, tmp, n);
  fclose(f);
  if(!b.d) return;
  js_t raiz = {b.d, b.d + b.n}, v;
  pthread_mutex_lock(&g_trava);
  txt(&raiz, "estado", g_estado, sizeof g_estado);
  txt(&raiz, "interno", g_interno, sizeof g_interno);
  txt(&raiz, "externo", g_externo, sizeof g_externo);
  txt(&raiz, "erro", g_erro, sizeof g_erro);
  if(js_campo(&raiz, "analisado", &v)) g_analisado = (long long)js_num(&v);
  if(js_campo(&raiz, "terminado", &v)) g_terminado = (long long)js_num(&v);
  if(js_campo(&raiz, "sobras_total", &v)) g_sobras_total = (int)js_num(&v);
  if(js_campo(&raiz, "jogos", &v)) js_cada(&v, ler_jogo, NULL);
  if(js_campo(&raiz, "passos", &v)) js_cada(&v, ler_passo, NULL);
  if(js_campo(&raiz, "avisos", &v)) js_cada(&v, ler_texto, NULL);
  if(js_campo(&raiz, "sobras", &v)) js_cada(&v, ler_texto, (void *)1);
  if(!strcmp(g_estado, "analisando")) snprintf(g_estado, sizeof g_estado, "vazio");
  if(!strcmp(g_estado, "pausando")) snprintf(g_estado, sizeof g_estado, "pausado");
  if(!strcmp(g_estado, "parando")) snprintf(g_estado, sizeof g_estado, "pronto");
  int continuar = !strcmp(g_estado, "rodando");
  if(continuar) {
    diario("filapkg: continua de onde parou (%d passos no plano)", g_np);
    ligar_executor();
  }
  pthread_mutex_unlock(&g_trava);
  buf_free(&b);
}

/* ------------------------------------------------------------------ rotas */

static void estado_json(buf_t *b) {
  pthread_mutex_lock(&g_trava);
  char dpkg[600], dexfat[600], dps4[600];
  destino_pasta("PS5pkg", dpkg, sizeof dpkg);
  destino_pasta("PS5exfat", dexfat, sizeof dexfat);
  destino_pasta("PS4pkg", dps4, sizeof dps4);
  int conv = 0, mov = 0, feitos = 0, erros = 0, adiados = 0, jogos_com = 0, jogos_feitos = 0, jogo_atual = 0;
  unsigned long long b_conv = 0, b_int = 0;
  int ultimo = -1;
  for(int i = 0; i < g_np; i++) {
    const passo_t *p = &g_passos[i];
    if(p->tipo == 'c') {
      conv++;
      b_conv += p->tam;
    } else {
      mov++;
      if(comeca(p->origem, g_interno)) b_int += p->tam;
    }
    feitos += !strcmp(p->estado, "feito");
    erros += !strcmp(p->estado, "erro");
    adiados += !strcmp(p->estado, "adiado");
    if(p->jogo != ultimo) {
      jogos_com++;
      ultimo = p->jogo;
    }
    if(g_atual >= 0 && p->jogo == g_passos[g_atual].jogo && !jogo_atual) jogo_atual = jogos_com;
  }
  /* jogos terminados = todos os passos do jogo feitos */
  for(int j = 0, k = 0; j < g_nj; j++) {
    int tem = 0, todos = 1;
    for(; k < g_np && g_passos[k].jogo == j; k++) {
      tem = 1;
      todos &= !strcmp(g_passos[k].estado, "feito");
    }
    jogos_feitos += tem && todos;
  }
  buf_str(b, "{\"ok\":true,\"estado\":");
  buf_json(b, g_estado);
  buf_str(b, ",\"interno\":");
  buf_json(b, g_interno);
  buf_str(b, ",\"externo\":");
  buf_json(b, g_externo);
  buf_str(b, ",\"destinos\":{\"pkg\":");
  buf_json(b, dpkg);
  buf_str(b, ",\"exfat\":");
  buf_json(b, dexfat);
  buf_str(b, ",\"ps4\":");
  buf_json(b, dps4);
  buf_str(b, "},\"erro\":");
  buf_json(b, g_erro);
  buf_str(b, ",\"msg\":");
  buf_json(b, g_msg);
  buf_fmt(b, ",\"analisado\":%lld,\"terminado\":%lld,\"agora\":%lld,\"jogos\":%d,\"jogos_com_passos\":%d,\"jogos_feitos\":%d,"
             "\"converter\":%d,\"mover\":%d,\"feitos\":%d,\"erros\":%d,\"adiados\":%d,\"bytes_converter\":%llu,"
             "\"bytes_sair_interno\":%llu,\"livre_externo\":%llu,\"sobras_total\":%d,\"dumpforge\":%s",
          g_analisado, g_terminado, (long long)time(NULL), g_nj, jogos_com, jogos_feitos, conv, mov, feitos, erros, adiados,
          b_conv, b_int, g_externo[0] ? livre(g_externo) : 0ULL, g_sobras_total, conversao_dumpforge_no_ar() ? "true" : "false");
  if(g_atual >= 0) {
    const passo_t *p = &g_passos[g_atual];
    buf_fmt(b, ",\"atual\":{\"jogo\":%d,\"jogos\":%d,\"tipo\":\"%s\",\"feitos\":%llu,\"total\":%llu,\"vel\":%.0f,\"nome\":",
            jogo_atual, jogos_com, p->tipo == 'c' ? "converter" : "mover", p->feitos, p->total, p->vel);
    buf_json(b, g_jogos[p->jogo].nome);
    buf_str(b, ",\"tid\":");
    buf_json(b, g_jogos[p->jogo].tid);
    buf_str(b, ",\"origem\":");
    buf_json(b, p->origem);
    buf_str(b, ",\"destino\":");
    buf_json(b, p->destino);
    buf_str(b, "}");
  }
  buf_str(b, ",\"passos\":[");
  for(int i = 0; i < g_np; i++) {
    const passo_t *p = &g_passos[i];
    const jogo_t *j = &g_jogos[p->jogo];
    buf_fmt(b, "%s{\"n\":%d,\"tipo\":\"%s\",\"tam\":%llu,\"interno\":%s,\"tid\":", i ? "," : "", i + 1,
            p->tipo == 'c' ? "converter" : "mover", p->tam, comeca(p->origem, g_interno) ? "true" : "false");
    buf_json(b, j->tid);
    buf_str(b, ",\"nome\":");
    buf_json(b, j->nome);
    buf_str(b, ",\"plat\":");
    buf_json(b, j->plat);
    buf_str(b, ",\"origem\":");
    buf_json(b, p->origem);
    buf_str(b, ",\"destino\":");
    buf_json(b, p->destino);
    buf_str(b, ",\"estado\":");
    buf_json(b, p->estado);
    buf_str(b, ",\"erro\":");
    buf_json(b, p->erro);
    buf_str(b, "}");
  }
  buf_str(b, "],\"avisos\":[");
  for(int i = 0; i < g_na; i++) {
    if(i) buf_str(b, ",");
    buf_json(b, g_avisos[i]);
  }
  buf_str(b, "],\"sobras\":[");
  for(int i = 0; i < g_ns; i++) {
    if(i) buf_str(b, ",");
    buf_json(b, g_sobras[i]);
  }
  buf_str(b, "]}");
  pthread_mutex_unlock(&g_trava);
}

void fila_pkg_rota_estado(pedido_t *p) {
  buf_t b = {0};
  estado_json(&b);
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* cria as pastas de destino e poe na lista do ShadowKraken e do glibren (sem a trava) */
static int preparar_destinos(char *erro, size_t tam) {
  char dpkg[600], dexfat[600], dps4[600];
  destino_pasta("PS5pkg", dpkg, sizeof dpkg);
  destino_pasta("PS5exfat", dexfat, sizeof dexfat);
  destino_pasta("PS4pkg", dps4, sizeof dps4);
  const char *ps[3] = {dpkg, dexfat, dps4};
  for(int i = 0; i < 3; i++)
    if(mkdir_p(ps[i])) {
      snprintf(erro, tam, "nao criou a pasta %s: %s", ps[i], strerror(errno));
      return -1;
    }
  /* so na lista do glibren agora: o ShadowKraken so passa a olhar as pastas no fim (senao ele poderia montar um .pkg
     que o Dump Forge ainda esta gravando em PS5pkg) */
  {
    static char lista[MAX_PASTAS][1024];
    char idioma[16];
    int n = config_ler(lista, idioma);
    for(int i = 0; i < 3 && n < MAX_PASTAS; i++) {
      int tem = 0;
      for(int k = 0; k < n && !tem; k++) tem = !strncmp(lista[k], ps[i], strlen(ps[i])) && (!lista[k][strlen(ps[i])] || !strcmp(lista[k] + strlen(ps[i]), "/"));
      if(!tem) snprintf(lista[n++], sizeof lista[0], "%s/", ps[i]);
    }
    config_gravar(lista, n, NULL);
  }
  return 0;
}

void fila_pkg_rota_acao(pedido_t *p, const char *acao) {
  char erro[300] = "";
  int st = 200;
  if(!strcmp(acao, "analisar")) {
    pthread_mutex_lock(&g_trava);
    if(g_thread || !strcmp(g_estado, "rodando") || !strcmp(g_estado, "pausando") || !strcmp(g_estado, "parando")) {
      snprintf(erro, sizeof erro, "a fila esta andando: pare antes de analisar de novo");
      st = 409;
    } else {
      snprintf(g_estado, sizeof g_estado, "analisando");
      g_thread = 1;
      g_np = g_nj = 0;
      g_atual = -1;
      if(criar_thread(analisar, NULL, NULL)) {
        g_thread = 0;
        snprintf(g_estado, sizeof g_estado, "vazio");
        snprintf(erro, sizeof erro, "nao criou a thread");
        st = 500;
      }
    }
    pthread_mutex_unlock(&g_trava);
  } else if(!strcmp(acao, "iniciar") || !strcmp(acao, "continuar")) {
    if(bateria_ocupada()) {
      snprintf(erro, sizeof erro, "a bateria automatica esta rodando: espere ou pare a bateria");
      st = 409;
    } else {
      pthread_mutex_lock(&g_trava);
      int pode = !strcmp(g_estado, "pronto") || !strcmp(g_estado, "pausado");
      pthread_mutex_unlock(&g_trava);
      if(!pode) {
        snprintf(erro, sizeof erro, "nada para iniciar: analise primeiro (ou a fila ja esta andando)");
        st = 409;
      } else if(!preparar_destinos(erro, sizeof erro)) {
        pthread_mutex_lock(&g_trava);
        g_erro[0] = 0;
        g_parar = 0;
        g_ultimo_adiado = 0;
        snprintf(g_estado, sizeof g_estado, "rodando");
        ligar_executor();
        pthread_mutex_unlock(&g_trava);
        diario("filapkg: %s (%d passos)", acao, g_np);
      } else {
        st = 500;
      }
    }
  } else if(!strcmp(acao, "pausar")) {
    pthread_mutex_lock(&g_trava);
    if(!strcmp(g_estado, "rodando")) snprintf(g_estado, sizeof g_estado, g_thread ? "pausando" : "pausado");
    pthread_mutex_unlock(&g_trava);
  } else if(!strcmp(acao, "parar")) {
    pthread_mutex_lock(&g_trava);
    if(!strcmp(g_estado, "rodando") || !strcmp(g_estado, "pausando")) {
      snprintf(g_estado, sizeof g_estado, g_thread ? "parando" : "pronto");
      g_parar = 1;
    } else if(!strcmp(g_estado, "pausado")) {
      snprintf(g_estado, sizeof g_estado, "pronto");
    }
    pthread_mutex_unlock(&g_trava);
  } else if(!strcmp(acao, "repetir")) {
    pthread_mutex_lock(&g_trava);
    int n = 0;
    for(int i = 0; i < g_np; i++)
      if(!strcmp(g_passos[i].estado, "erro") || !strcmp(g_passos[i].estado, "adiado")) {
        snprintf(g_passos[i].estado, sizeof g_passos[i].estado, "fila");
        g_passos[i].erro[0] = 0;
        g_passos[i].conv = 0;
        n++;
      }
    if(n && !strcmp(g_estado, "terminado")) snprintf(g_estado, sizeof g_estado, "pronto");
    pthread_mutex_unlock(&g_trava);
  } else {
    responder_erro(p, 404, "filapkg_acao", "acao desconhecida", acao);
    return;
  }
  if(st != 200) {
    responder_erro(p, st, "filapkg_recusado", erro, NULL);
    return;
  }
  salvar();
  buf_t b = {0};
  estado_json(&b);
  responder_json(p, 200, &b);
  buf_free(&b);
}

int fila_pkg_copiando(void) {
  pthread_mutex_lock(&g_trava);
  int r = g_atual >= 0 && g_passos[g_atual].tipo == 'm';
  pthread_mutex_unlock(&g_trava);
  return r;
}

int fila_pkg_ativa(void) {
  pthread_mutex_lock(&g_trava);
  int r = !strcmp(g_estado, "rodando") || !strcmp(g_estado, "pausando") || !strcmp(g_estado, "parando");
  pthread_mutex_unlock(&g_trava);
  return r;
}
