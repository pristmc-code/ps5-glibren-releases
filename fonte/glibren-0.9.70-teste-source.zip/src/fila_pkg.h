/* Game Library Renamer (payload PS5) - 0.9.70: Fila PKG (pedido do dono em 24/11/2026).

Analisa os jogos do SSD interno e do disco externo que tem as pastas PS5exfat/PS5pkg e so mexe em .exfat e .pkg:
  - .exfat de PS5 (sem -zstd/-lz4 no nome) de um jogo que ainda nao tem .pkg -> vira .pkg em <externo>/PS5pkg (Dump
    Forge), e depois o .exfat vai para <externo>/PS5exfat;
  - .exfat (sem -zstd/-lz4) de jogo que ja tem .pkg -> so vai para <externo>/PS5exfat;
  - .pkg de PS5 -> <externo>/PS5pkg; .pkg de PS4 -> <externo>/PS4pkg (os do interno sao copiados, conferidos pelo
    SHA-256 e so entao apagados; no mesmo disco e so rename);
  - o resto (pastas de jogo, .ffpkg/.ffpfs/.ffpfsc, -zstd/-lz4, zip/7z/rar) fica onde esta; o plano lista o que esta
    no interno para o dono ver depois.
Decisoes do dono (24/11): um trabalho por vez; jogos que tem algo no interno primeiro, depois do menor para o maior;
so converter os .exfat; .pkg de PS4 em PS4pkg; a bateria hc2-aj1 foi cancelada.
Ver fila_pkg.c para as regras de seguranca. */
#pragma once

#include "http.h"
#include "util.h"

/* le <dados>/fila-pkg.json e, se a fila estava rodando, continua (chamar depois de conversao_iniciar) */
void fila_pkg_iniciar(void);
/* GET /api/filapkg (leitura livre) */
void fila_pkg_rota_estado(pedido_t *p);
/* POST /api/filapkg/<acao>: analisar, iniciar, pausar, continuar, parar, repetir (pareamento ja conferido) */
void fila_pkg_rota_acao(pedido_t *p, const char *acao);
/* 1 = a fila esta copiando agora (a atualizacao do glibren espera) */
int fila_pkg_copiando(void);
/* 1 = a fila esta rodando, pausando ou esperando (a bateria nao comeca junto) */
int fila_pkg_ativa(void);
