#!/bin/bash
# Testa os payloads de teste (0.9.20; PrefBar e exclusao mutua na 0.9.22) na versao de PC: catalogo fixo, SHA-256 fixado (errado = recusado), item fora da
# lista, pareamento (401), navegador do PS5 so no item de tela cheia, jogo aberto, envio ao elfldr (falso) com a saida
# do payload lida pelo mesmo socket, status e o que fica gravado. Servidor local no lugar do GitHub (GLR_TESTE_BASE +
# GLR_TESTE_PAYLOADS_URL) e um arquivo de teste no lugar do .elf real (GLR_TESTE_PAYLOAD_SHA/TAM). No fim, se houver
# internet, confere que o SHA-256 fixado no codigo e o do asset real da release.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_payloads.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8891; PORTA_SRV=8892; PORTA_ELFLDR=8893
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R="http://$IP:$PORTA"
T=/root/glr-payl; DADOS=$T/dados; SRV=$T/srv; A=$T/lista
ID=web-browser-fullscreen; ARQ=web-browser-fullscreen-v0.1b.elf
UA_PS5='Mozilla/5.0 (PlayStation; PlayStation 5/12.00) AppleWebKit/605.1.15 (KHTML, like Gecko)'
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
codigo() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
estado() { curl -s "$L/api/payloads"; }
item0() { estado | sed "s/},{\"id\":\"prefbar\".*//"; }   # so o 1o item (tela cheia)
espera_livre() { for i in $(seq 1 80); do estado | grep -q '"ocupado":false' && return; sleep 0.25; done; }
rm -rf "$T"; mkdir -p "$DADOS" "$SRV" "$A"
printf 'language = pt-BR\nfolder = %s/\n' "$A" > "$DADOS/config.ini"

# "payload" de teste servido pelo servidor local
head -c 300000 /dev/urandom > "$SRV/$ARQ"
SHA=$(sha256sum "$SRV/$ARQ" | cut -d' ' -f1); TAM=$(stat -c %s "$SRV/$ARQ")
PB=prefbar; ARQ_PB=Prefbar_V0.3.0.elf
cp "$SRV/$ARQ" "$SRV/$ARQ_PB"   # 0.9.22: o mesmo arquivo de teste no lugar do PrefBar (GLR_TESTE_PAYLOAD_SHA vale para os dois)
(cd "$SRV" && exec python3 -m http.server $PORTA_SRV --bind 127.0.0.1) > "$T/srv.log" 2>&1 &
PID_SRV=$!

# elfldr de mentira: le o .elf ate o fim (shutdown do glibren), guarda e responde como o payload (modo no arquivo)
cat > "$T/elfldr.py" <<'EOF'
import socket, sys
porta, pasta = int(sys.argv[1]), sys.argv[2]
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); s.bind(("127.0.0.1", porta)); s.listen(4)
n = 0
while True:
    c, _ = s.accept(); dados = b""
    while True:
        d = c.recv(65536)
        if not d: break
        dados += d
    n += 1
    open(pasta + "/recebido.elf", "wb").write(dados)
    modo = open(pasta + "/modo").read().strip()
    if modo == "ok":
        c.sendall(b"Web browser fullscreen apply fw=12000000 ShellUI=93\nVerified NPXS40036 +1a2b width 6 bytes\n"
                  b"Result=0; RAM patch only; /data INI=unchanged\nNotification: Browser fullscreen succeeded. Reopen the browser. (send=0)\n")
    elif modo == "falha":
        c.sendall(b"Result=1; RAM patch only; /data INI=failure\nNotification: Browser fullscreen failed: browser discovery or validation error. "
                  b"Diagnostics, if saved: /data/web-browser-fullscreen.ini (send=0)\n")
    elif modo == "recusa":
        c.sendall(b"[elfldr.elf] Error spawning payload\n\r\0")
    elif modo == "fica":   # 0.9.22: payload que fica rodando (PrefBar): nao escreve nada nem fecha
        globals().setdefault("abertos", []).append(c)
        open(pasta + "/conexoes", "w").write(str(n))
        continue
    c.close()
    open(pasta + "/conexoes", "w").write(str(n))
EOF
echo ok > "$T/modo"
python3 -I "$T/elfldr.py" $PORTA_ELFLDR "$T" > "$T/elfldr.log" 2>&1 &
PID_EL=$!

inicia() {
  GLR_TESTE_BASE="http://127.0.0.1:$PORTA_SRV/" GLR_TESTE_PAYLOADS_URL="http://127.0.0.1:$PORTA_SRV/" GLR_TESTE_PAYLOAD_SHA="$1" \
  GLR_TESTE_PAYLOAD_TAM="$2" GLR_TESTE_ELFLDR="${3:-$PORTA_ELFLDR}" GLR_TESTE_FW=12.00 GLR_TESTE_ABERTOS="$T/abertos" GLR_TESTE_SHELLUI_PID=123 \
    "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
inicia "$SHA" "$TAM"

echo "--- status e catalogo"
E=$(estado)
confere "lista o item de tela cheia"      "$E" "\"id\":\"$ID\""
confere "estado: nao baixado"             "$E" '"estado":"nao_baixado"'
confere "firmware do PS5"                 "$E" '"firmware":"12.00"'
confere "12.00 confirmado por nos (0.9.23)" "$E" "\"id\":\"$ID\".*\"confirmados\":\"12.00\",\"confirmado_em\":\"PS5 Pro, 13/11/2026\",\"testado_no_seu\":true,\"faixa_do_autor\":false,\"confirmado_no_seu\":true"
confere "PrefBar: sem confirmacao nossa"  "$E" '"id":"prefbar".*"confirmados":"","confirmado_em":"","testado_no_seu":false,"faixa_do_autor":true,"confirmado_no_seu":false'
confere "pagina: texto do confirmado"     "$(curl -s $L/payloads)" 'confirmado por nós no {c}'
confere "sha256 fixado na resposta"       "$E" '"sha256":"520977607a22ecdf51c8d8b75360486026e0bd8780ded8026c3456fac7997a97"'
confere "url do asset da release"         "$E" '"url":"https://github.com/owendswang/ps5-web-browser-fullscreen/releases/download/v0.1b/web-browser-fullscreen-v0.1b.elf"'
confere "como desfazer em 3 idiomas"      "$E" '"desfazer":{"pt-BR":"Reinicie o PS5'
confere "GET livre pela rede"             "$(codigo $R/api/payloads)" "200"
confere "pagina /payloads"                "$(curl -s $L/payloads | head -c 2000)" "<title>Payloads de teste</title>"
confere "script /ps5tela.js"              "$(curl -s $L/ps5tela.js)" "web-browser-fullscreen"

confere "lista o PrefBar"                 "$E" "\"id\":\"$PB\""
confere "PrefBar: sha256 fixado"          "$E" '"sha256":"e4379590115ef87b2f0310b502321d7da30783536d939bfb1c4c0e511972af30"'
confere "PrefBar: url da release v0.3.0"  "$E" '"url":"https://github.com/X1NONs/PrefBar/releases/download/v0.3.0/Prefbar_V0.3.0.elf"'
confere "PrefBar: tamanho"                "$E" '"tamanho":964272'
confere "PrefBar: 12.00 so na faixa"      "$E" '"id":"prefbar".*"testado_no_seu":false,"faixa_do_autor":true'
confere "PrefBar: aviso dos 2 min"        "$E" 'Espere ~2 min depois de ligar o PS5'
confere "PrefBar: aviso da tela cheia"    "$E" 'Não use junto com a tela cheia do navegador'
confere "PrefBar: aviso do 12.00"         "$E" 'Não testado no PS5 Pro 12.00'
confere "PrefBar: como desfazer"          "$E" '"desfazer":{"pt-BR":"Reinicie o PS5 (nada fica instalado'
confere "PrefBar: mexe na ShellUI"        "$E" '"id":"prefbar".*"shellui":true,"uma_vez":true'
confere "PrefBar: navegador do PS5 nao"   "$(post -A "$UA_PS5" -d id=$PB $L/api/payloads/ativar)" "payload_so_celular"

echo "--- recusas"
confere "fora da lista: 404"              "$(codigo -H 'X-GLR: 1' -d id=outro-payload $L/api/payloads/ativar)" "404"
confere "fora da lista: chave"            "$(post -d id=../../etc $L/api/payloads/baixar)" "payload_fora_da_lista"
confere "fora da lista: diario"           "$(cat $DADOS/glibren.log)" 'pedido recusado: "outro-payload" nao esta na lista'
confere "rede sem pareamento: ativar 401" "$(codigo -H 'X-GLR: 1' -d id=$ID $R/api/payloads/ativar)" "401"
confere "rede sem pareamento: baixar 401" "$(codigo -H 'X-GLR: 1' -d id=$ID $R/api/payloads/baixar)" "401"
confere "rede navegador PS5 sem par: 401" "$(codigo -A "$UA_PS5" -H 'X-GLR: 1' -d id=$ID $R/api/payloads/ativar)" "401"
confere "sem X-GLR: 403"                  "$(codigo -d id=$ID $L/api/payloads/ativar)" "403"
confere "local sem ser o navegador: 403"  "$(post -d id=$ID $L/api/payloads/ativar)" "payload_so_celular"
confere "reabrir invalido: 400"           "$(codigo -A "$UA_PS5" -H 'X-GLR: 1' -d id=$ID -d 'reabrir=//outro.site/' $L/api/payloads/ativar)" "400"
echo PPSA01234 > "$T/abertos"
confere "jogo aberto: recusado"           "$(post -A "$UA_PS5" -d id=$ID $L/api/payloads/ativar)" '"chave":"payload_jogo_aberto".*"nome":"PPSA01234"'
: > "$T/abertos"
sleep 0.3
confere "nada baixado nas recusas"        "$(ls $DADOS/payloads 2>&1)" "No such\|^$"
confere "elfldr nao chamado"              "$(cat $T/conexoes 2>&1)" "No such"
para

echo "--- SHA-256 errado e tamanho errado"
inicia "0000000000000000000000000000000000000000000000000000000000000000" "$TAM"
confere "baixar (sha errado) iniciou"     "$(post -A "$UA_PS5" -d id=$ID $L/api/payloads/baixar)" '"ok":true'
espera_livre
E=$(estado)
confere "sha errado: estado erro"         "$E" '"estado":"erro"'
confere "sha errado: motivo"              "$E" 'SHA-256 nao confere: arquivo recusado'
confere "sha errado: nada guardado"       "$(ls $DADOS/payloads | tr '\n' ' ')" "^$"
confere "sha errado: diario"              "$(cat $DADOS/glibren.log)" "SHA-256 nao confere"
confere "ativar (sha errado) iniciou"     "$(post -A "$UA_PS5" -d id=$ID $L/api/payloads/ativar)" '"ok":true'
espera_livre
confere "sha errado: elfldr nao chamado"  "$(cat $T/conexoes 2>&1)" "No such"
# 0.9.22: PrefBar com SHA-256 errado tambem e recusado (pareado pela rede)
post -X POST $R/api/parear/pedir > /dev/null; sleep 0.3
C=$(grep -o 'pareamento [0-9]\{6\}' "$T/glr.log" | tail -1 | awk '{print $2}')
TK0=$(post -d codigo=$C -d nome=teste $R/api/parear | grep -o '"token":"[0-9a-f]*"' | cut -d'"' -f4)
confere "PrefBar sha errado: iniciou"     "$(post -H "X-GLR-Token: $TK0" -d id=$PB $R/api/payloads/ativar)" '"ok":true'
espera_livre
E=$(estado)
confere "PrefBar sha errado: recusado"    "$E" '"id":"prefbar".*SHA-256 nao confere: arquivo recusado'
confere "PrefBar sha errado: nada guardado" "$(ls $DADOS/payloads | grep -c Prefbar)" "^0$"
confere "PrefBar sha errado: sem elfldr"  "$(cat $T/conexoes 2>&1)" "No such"
para
inicia "$SHA" "$((TAM - 1))"
post -A "$UA_PS5" -d id=$ID $L/api/payloads/baixar > /dev/null; espera_livre
confere "tamanho maior que o fixado"      "$(estado)" "tamanho diferente do fixado"
confere "tamanho errado: nada guardado"   "$(ls $DADOS/payloads | tr '\n' ' ')" "^$"
para

echo "--- baixar, pareamento e ativar (elfldr falso)"
inicia "$SHA" "$TAM"
C=""; post -X POST $R/api/parear/pedir > /dev/null; sleep 0.3
C=$(grep -o 'pareamento [0-9]\{6\}' "$T/glr.log" | tail -1 | awk '{print $2}')
TOKEN=$(post -d codigo=$C -d nome=teste $R/api/parear | grep -o '"token":"[0-9a-f]*"' | cut -d'"' -f4)
confere "pareou pela rede"                "$TOKEN" "^[0-9a-f]\{64\}$"
confere "baixar pareado iniciou"          "$(post -H "X-GLR-Token: $TOKEN" -d id=$ID $R/api/payloads/baixar)" '"ok":true'
espera_livre
E=$(estado)
confere "baixado: pronto"                 "$E" '"estado":"pronto"'
confere "baixado: conferido"              "$E" '"conferido":true'
confere "guardado igual ao servidor"      "$(cmp $SRV/$ARQ $DADOS/payloads/$ARQ && echo igual)" "igual"
confere "sem .part"                       "$(ls $DADOS/payloads | grep -c part)" "^0$"
confere "ativar pareado iniciou"          "$(post -H "X-GLR-Token: $TOKEN" -d id=$ID -d reabrir=/ $R/api/payloads/ativar)" '"ok":true'
confere "ocupado: segundo pedido recusado" "$(post -H "X-GLR-Token: $TOKEN" -d id=$ID $R/api/payloads/ativar)" "payload_ocupado"
espera_livre
E=$(estado)
confere "ativado"                         "$E" '"estado":"ativado"'
confere "hora da ativacao"                "$E" '"ativado_em":[1-9]'
confere "saida do payload no status"      "$E" '"saida":"Result=0; RAM patch only; /data INI=unchanged | Browser fullscreen succeeded. Reopen the browser. (send=0)"'
confere "elfldr recebeu o arquivo"        "$(cmp $SRV/$ARQ $T/recebido.elf && echo igual)" "igual"
G=$(cat $DADOS/glibren.log)
confere "diario: tela inicial antes"      "$G" "voltaria para a tela inicial"
confere "diario: enviado"                 "$G" "enviando ao elfldr ($TAM bytes)"
confere "diario: saida"                   "$G" "saida do payload: Result=0"
confere "diario: ativado"                 "$G" "payloads: $ID: ativado"
confere "diario: reabre o navegador"      "$G" "abriria o navegador em http://127.0.0.1:$PORTA/"
confere "hora e ShellUI gravadas"         "$(cat $DADOS/payloads/$ID.ativado)" "^[1-9][0-9]* 123$"
para
inicia "$SHA" "$TAM"
confere "depois de reabrir: ativado"      "$(estado)" '"estado":"ativado"'
echo "0" > "$DADOS/payloads/$ID.ativado"
confere "antes do PS5 ligar: so pronto"   "$(estado)" '"estado":"pronto"'

echo "--- exclusao mutua PrefBar x tela cheia (0.9.22)"
gravado=$(cat $DADOS/payloads/$ID.ativado)
echo "$(date +%s) 123" > "$DADOS/payloads/$ID.ativado"
E=$(estado)
confere "tela cheia ativa: PrefBar bloqueado" "$E" '"id":"prefbar".*"bloqueado_por":"PS5 Web Browser Fullscreen"'
confere "PrefBar recusado: 409 conflito"  "$(post -H "X-GLR-Token: $TOKEN" -d id=$PB $R/api/payloads/ativar)" '"chave":"payload_conflito".*"nome":"PS5 Web Browser Fullscreen"'
confere "conflito no diario"              "$(cat $DADOS/glibren.log)" "prefbar recusado: web-browser-fullscreen ja esta ativo"
echo "$(date +%s) 999" > "$DADOS/payloads/$ID.ativado"
confere "ShellUI reiniciou: patch acabou" "$(item0)" '"ativo_sessao":false'
echo 0 > "$DADOS/payloads/$ID.ativado"
echo fica > "$T/modo"
confere "PrefBar ativar iniciou"          "$(post -H "X-GLR-Token: $TOKEN" -d id=$PB $R/api/payloads/ativar)" '"ok":true'
espera_livre
E=$(estado)
confere "PrefBar ativado"                 "$E" '"id":"prefbar".*"estado":"ativado"'
confere "PrefBar: quem e quando gravado"  "$(cat $DADOS/payloads/$PB.ativado)" "^[1-9][0-9]* 123$"
confere "PrefBar: elfldr recebeu"         "$(cmp $SRV/$ARQ_PB $T/recebido.elf && echo igual)" "igual"
confere "tela cheia bloqueada"            "$E" '"id":"web-browser-fullscreen".*"bloqueado_por":"PrefBar"'
confere "tela cheia (PS5) recusada"       "$(post -A "$UA_PS5" -d id=$ID -d reabrir=/ $L/api/payloads/ativar)" '"chave":"payload_conflito".*"nome":"PrefBar"'
confere "PrefBar 2a vez: recusado"        "$(post -H "X-GLR-Token: $TOKEN" -d id=$PB $R/api/payloads/ativar)" '"chave":"payload_ja_ativo"'
echo 0 > "$DADOS/payloads/$PB.ativado"
confere "reiniciou o PS5: tela cheia livre" "$(item0)" '"bloqueado_por":""'
mkdir -p "$DADOS/prefbar"; touch "$DADOS/prefbar/status.kv"
E=$(estado)
confere "PrefBar rodando por fora: visto" "$E" '"id":"prefbar".*"estado":"rodando"'
confere "PrefBar por fora: tela cheia recusada" "$(post -A "$UA_PS5" -d id=$ID $L/api/payloads/ativar)" "payload_conflito"
touch -d '2000-01-01' "$DADOS/prefbar/status.kv"
confere "status antigo (antes de ligar): livre" "$(item0)" '"bloqueado_por":""'
echo ok > "$T/modo"
echo "$gravado" > "$DADOS/payloads/$ID.ativado"

echo "--- navegador do PS5 (127.0.0.1): tela cheia permitida, reabre a pagina"
: > "$DADOS/glibren.log"
confere "PS5: ativar e reabrir"           "$(post -A "$UA_PS5" -d id=$ID -d 'reabrir=/temperatura' $L/api/payloads/ativar)" '"ok":true'
espera_livre
confere "PS5: ativado"                    "$(estado)" '"estado":"ativado"'
confere "PS5: reabre na mesma pagina"     "$(cat $DADOS/glibren.log)" "abriria o navegador em http://127.0.0.1:$PORTA/temperatura"
confere "PS5: pedido pelo navegador"      "$(cat $DADOS/glibren.log)" "ativar pedido pelo navegador do PS5"

echo "--- payload informa falha / elfldr recusa"
echo falha > "$T/modo"; : > "$DADOS/glibren.log"
post -A "$UA_PS5" -d id=$ID -d reabrir=/ $L/api/payloads/ativar > /dev/null; espera_livre
E=$(estado)
confere "falha: estado erro"              "$E" '"estado":"erro"'
confere "falha: motivo do payload"        "$E" "o payload informou falha: Browser fullscreen failed: browser discovery or validation error"
confere "falha: reabre mesmo assim"       "$(cat $DADOS/glibren.log)" "abriria o navegador em"
echo recusa > "$T/modo"
post -A "$UA_PS5" -d id=$ID $L/api/payloads/ativar > /dev/null; espera_livre
confere "elfldr recusou"                  "$(estado)" "o elfldr recusou: Error spawning payload"
echo ok > "$T/modo"
post -A "$UA_PS5" -d id=$ID $L/api/payloads/ativar > /dev/null; espera_livre
confere "depois do erro, ativa de novo"   "$(estado)" '"estado":"ativado","guardado":true'

echo "--- arquivo guardado adulterado"
# guardado adulterado: nao e enviado; o glibren baixa de novo e confere antes de enviar
printf 'X' | dd of="$DADOS/payloads/$ARQ" bs=1 seek=1000 conv=notrunc 2>/dev/null
: > "$DADOS/glibren.log"
confere "adulterado: nao esta mais pronto" "$(estado)" '"conferido":false'
post -A "$UA_PS5" -d id=$ID $L/api/payloads/ativar > /dev/null; espera_livre
confere "adulterado: baixou de novo"       "$(cat $DADOS/glibren.log)" "baixado e conferido"
confere "adulterado: enviou o certo"       "$(cmp $SRV/$ARQ $T/recebido.elf && echo igual)" "igual"
# guardado adulterado E o servidor com outro arquivo: recusado, nada enviado
printf 'X' | dd of="$DADOS/payloads/$ARQ" bs=1 seek=1000 conv=notrunc 2>/dev/null
cp "$SRV/$ARQ" "$T/original.elf"; printf 'Y' | dd of="$SRV/$ARQ" bs=1 seek=2000 conv=notrunc 2>/dev/null
N_ANTES=$(cat $T/conexoes)
post -A "$UA_PS5" -d id=$ID $L/api/payloads/ativar > /dev/null; espera_livre
confere "servidor adulterado: recusado"    "$(estado)" "SHA-256 nao confere: arquivo recusado"
confere "servidor adulterado: nada enviado" "$(cat $T/conexoes)" "^$N_ANTES$"
confere "servidor adulterado: nada guardado" "$(ls $DADOS/payloads | grep -c "^web-browser.*elf")" "^1$"
confere "o adulterado guardado nao vale"   "$(estado)" '"conferido":false'
cp "$T/original.elf" "$SRV/$ARQ"; rm -f "$DADOS/payloads/$ARQ"
para

echo "--- elfldr fora do ar"
inicia "$SHA" "$TAM" 8899
post -A "$UA_PS5" -d id=$ID $L/api/payloads/ativar > /dev/null; espera_livre
confere "sem elfldr: erro"                "$(estado)" "o elfldr (porta 9021) nao respondeu"
confere "sem elfldr: baixou de novo"      "$(cmp $SRV/$ARQ $DADOS/payloads/$ARQ && echo igual)" "igual"
para

echo "--- SHA-256 fixado = asset real da release (internet)"
REAL=/root/glr-cache-payloads/$ARQ; mkdir -p /root/glr-cache-payloads
[ -s "$REAL" ] || curl -sfL -m 60 -o "$REAL" "https://github.com/owendswang/ps5-web-browser-fullscreen/releases/download/v0.1b/$ARQ" || rm -f "$REAL"
if [ -s "$REAL" ]; then
  confere "sha256 do asset real"          "$(sha256sum $REAL | cut -d' ' -f1)" "^520977607a22ecdf51c8d8b75360486026e0bd8780ded8026c3456fac7997a97$"
  confere "tamanho do asset real"         "$(stat -c %s $REAL)" "^463848$"
else
  echo "PULADO asset real (sem internet)"
fi
# 0.9.22: o mesmo para o PrefBar v0.3.0
REAL_PB=/root/glr-cache-payloads/Prefbar_V0.3.0.elf
[ -s "$REAL_PB" ] || curl -sfL -m 90 -o "$REAL_PB" "https://github.com/X1NONs/PrefBar/releases/download/v0.3.0/Prefbar_V0.3.0.elf" || rm -f "$REAL_PB"
if [ -s "$REAL_PB" ]; then
  confere "PrefBar: sha256 do asset real" "$(sha256sum $REAL_PB | cut -d' ' -f1)" "^e4379590115ef87b2f0310b502321d7da30783536d939bfb1c4c0e511972af30$"
  confere "PrefBar: tamanho do asset real" "$(stat -c %s $REAL_PB)" "^964272$"
else
  echo "PULADO asset real do PrefBar (sem internet)"
fi

kill $PID_SRV $PID_EL 2>/dev/null; wait 2>/dev/null
rm -rf "$T"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
