#!/bin/bash
# Testa a 0.9.22 na versao de PC: numeros novos (MHz da CPU/GPU, RAM/VRAM, uso por nucleo) que somem sem a funcao,
# filtro de valor absurdo, watchdog nas chamadas novas, 1% low e pior quadro no FPS, e a configuracao do PrefBar
# (prefbar.conf validado e gravado de forma atomica, mantendo as outras linhas).
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_desempenho.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8894
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R="http://$IP:$PORTA"
T=/root/glr-desemp; DADOS=$T/dados; A=$T/lista
CONF=$DADOS/prefbar/prefbar.conf
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
codigo() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
inicia() { env "$@" "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
desemp() { curl -s "$L/api/termico" | grep -o '"desempenho":{[^}]*}'; }
# a thread do sistema le a cada 2 s; o 1o pedido liga a leitura
aquece() { curl -s "$L/api/termico" > /dev/null; sleep "${1:-5}"; }
rm -rf "$T"; mkdir -p "$DADOS" "$A"
printf 'language = pt-BR\nfolder = %s/\n' "$A" > "$DADOS/config.ini"

echo "--- numeros novos (todas as funcoes presentes)"
inicia GLR_TESTE_X=1
aquece 5
D=$(desemp)
confere "MHz da CPU"                      "$D" '"cpu_mhz":3500'
confere "MHz da GPU (dominio 20)"         "$D" '"gpu_mhz":[0-9]\{4\}'
confere "RAM [usada,total]"               "$D" '"ram_mb":\[[0-9]*,13312\]'
confere "VRAM [usada,total]"              "$D" '"vram_mb":\[[0-9]*,4608\]'
confere "uso por nucleo (8)"              "$D" '"nucleos":\[[0-9.]*,[0-9.]*,[0-9.]*,[0-9.]*,[0-9.]*,[0-9.]*,[0-9.]*,[0-9.]*\]'
S=$(curl -s "$L/api/termico" | grep -o '"sistema":{[^}]*}')
confere "nucleos da Temperatura pelo sce" "$S" '"nucleos_fonte":"sce"'
F=$(curl -s "$L/api/fps")
confere "FPS tambem traz os numeros"      "$F" '"desempenho":{"cpu_mhz":3500'
confere "diario: funcoes achadas"         "$(cat $DADOS/glibren.log)" "desempenho: funcoes (PC, simuladas): CpuFrequency=ok"
confere "pagina Temperatura: blocos novos" "$(curl -s $L/temperatura)" 'id="avExtra"'
confere "pagina FPS: 1% low e pior"       "$(curl -s $L/fps)" 'id="low1".*\|id="pior"'
para

echo "--- sem as funcoes: as linhas somem"
inicia GLR_TESTE_SEM_DESEMPENHO=todas
aquece 5
D=$(desemp)
confere "sem MHz da CPU"                  "$D" '"cpu_mhz":-1'
confere "sem MHz da GPU"                  "$D" '"gpu_mhz":-1'
confere "sem RAM do kernel"               "$D" '"ram_mb":-1'
confere "sem VRAM"                        "$D" '"vram_mb":-1'
confere "sem uso por nucleo"              "$D" '"nucleos":\[\]'
nao_tem "Temperatura volta ao metodo antigo" "$(curl -s $L/api/termico)" '"nucleos_fonte":"sce"'
confere "diario: ausentes"                "$(cat $DADOS/glibren.log)" "CpuFrequency=ausente"
para
inicia GLR_TESTE_SEM_DESEMPENHO=sceKernelGetSocClock,get_page_table_stats
aquece 5
D=$(desemp)
confere "so a GPU some (CPU fica)"        "$D" '"cpu_mhz":3500,"gpu_mhz":-1'
confere "RAM e VRAM somem"                "$D" '"ram_mb":-1,"vram_mb":-1'
para

echo "--- VRAM absurda: segura o ultimo bom e depois some"
inicia GLR_TESTE_VRAM_ABSURDA=1
aquece 4
D=$(desemp)
confere "VRAM absurda nunca aparece"      "$D" '"vram_mb":-1'
confere "RAM continua"                    "$D" '"ram_mb":\[[0-9]*,13312\]'
confere "diario: VRAM recusada"           "$(cat $DADOS/glibren.log)" "desempenho: VRAM recusada (total 999999"
para

echo "--- watchdog: chamada nova que trava"
inicia GLR_TESTE_SCE_TRAVA=sceKernelGetCpuFrequency GLR_TESTE_SCE_TRAVA_S=30
aquece 5
D=$(desemp)
confere "travou: MHz da CPU some"         "$D" '"cpu_mhz":-1'
confere "travou: o resto continua"        "$D" '"gpu_mhz":[0-9]\{4\}'
confere "travou: watchdog marcou"         "$(curl -s $L/api/termico)" '"mortas":\["sceKernelGetCpuFrequency"\]'
confere "pagina responde"                 "$(codigo $L/api/termico)" "200"
para

echo "--- sem ninguem olhando: nao le"
: > "$DADOS/glibren.log"
inicia GLR_TESTE_X=1
sleep 5
confere "nada lido antes do 1o pedido"    "$(grep -c 'desempenho: funcoes' $DADOS/glibren.log)" "^0$"
para

echo "--- FPS: 1% low e pior quadro"
inicia GLR_TESTE_FPS=60
curl -s "$L/api/fps" > /dev/null
for i in $(seq 1 8); do sleep 1; curl -s "$L/api/fps" > /dev/null; done
F=$(curl -s "$L/api/fps")
confere "1% low perto de 60"              "$F" '"low1":5[0-9]\.[0-9]\|"low1":6[0-2]\.[0-9]'
confere "pior quadro perto de 17 ms"      "$F" '"pior_ms":1[5-9]\.[0-9]\|"pior_ms":2[0-2]\.[0-9]'
confere "quadros na janela"               "$F" '"quadros":[1-9][0-9][0-9]'
para
inicia GLR_TESTE_FPS=60 GLR_TESTE_FPS_PAUSA_MS=150
curl -s "$L/api/fps" > /dev/null
for i in $(seq 1 8); do sleep 1; curl -s "$L/api/fps" > /dev/null; done
F=$(curl -s "$L/api/fps")
confere "quadro lento: pior >= 150 ms"    "$F" '"pior_ms":1[5-9][0-9]\.[0-9]'
confere "quadro lento: 1% low baixo"      "$F" '"low1":[0-9]\.[0-9]\|"low1":[1-3][0-9]\.[0-9]'
para
inicia GLR_TESTE_FPS_ERRO=13
curl -s "$L/api/fps" > /dev/null; sleep 2
confere "sem /dev/dce: sem 1% low"        "$(curl -s $L/api/fps)" '"low1":-1,"pior_ms":-1'
para

echo "--- prefbar.conf: leitura, validacao e gravacao atomica"
inicia GLR_TESTE_X=1
C=$(curl -s $L/api/prefbar/conf)
confere "sem arquivo: existe false"       "$C" '"existe":false'
confere "padroes do PrefBar"              "$C" '"overlay_font":"26".*"text_color":"#F2F2F2"'
confere "campos com faixa"                "$C" '{"chave":"overlay_x","tipo":"int","min":0,"max":1800'
confere "rede sem pareamento: 401"        "$(codigo -H 'X-GLR: 1' -d overlay=1 $R/api/prefbar/conf)" "401"
confere "sem X-GLR: 403"                  "$(codigo -d overlay=1 $L/api/prefbar/conf)" "403"
for ruim in overlay_font=9 overlay_font=97 overlay_x=1801 overlay_y=-1 overlay=2 overlay_x=1e3 overlay_x=+5 'text_color=%23GGGGGG' \
            text_color=00E5FF 'text_color=%2300E5FF0' overlay_horizontal_align=meio overlay_format=COMPACT overlay_corner=1 \
            'text_color=%2300E5FF%0Adiag%3D1' gpu_temp_label= ; do
  confere "recusa $ruim"                  "$(post -d "$ruim" $L/api/prefbar/conf)" '"ok":false'
done
confere "campo desconhecido recusado"     "$(post -d diag=1 $L/api/prefbar/conf)" "prefbar_campo_desconhecido"
confere "um ruim no meio: nada gravado"   "$(post -d overlay_horizontal=1 -d overlay_font=500 $L/api/prefbar/conf)" "prefbar_valor_invalido"
confere "nada gravado nas recusas"        "$(ls $DADOS/prefbar 2>&1)" "No such\|^$"
R1=$(post -d overlay_horizontal=1 -d 'text_color=%2300E5FF' -d overlay_horizontal_align=left $L/api/prefbar/conf)
confere "grava sem arquivo: cria"         "$R1" '"existe":true'
confere "arquivo criado com os campos"    "$(cat $CONF)" "overlay_horizontal=1"
confere "cor gravada"                     "$(cat $CONF)" "text_color=#00E5FF"
# arquivo do PrefBar com comentarios, secoes, chave desconhecida, valor invalido e chave repetida
cat > "$CONF" <<'EOF'
# PrefBar 0.3.0 configuration

[overlay]
overlay=1
text_color=#F2F2F2
overlay_font = 26
overlay_x=24
overlay_font=30
[diagnostics]
diag=0
poll_us=2000
show_vram=7
EOF
C=$(curl -s $L/api/prefbar/conf)
confere "le valor com espacos e o ultimo" "$C" '"overlay_font":"30"'
confere "valor invalido apontado"         "$C" '"invalidos":\["show_vram"\]'
R2=$(post -d overlay_font=40 -d show_vram=0 -d show_power=0 $L/api/prefbar/conf)
confere "grava: ok"                       "$R2" '"ok":true'
G=$(cat $CONF)
confere "troca todas as ocorrencias"      "$(grep -c '^overlay_font=40$' $CONF)" "^2$"
nao_tem "nao sobra o valor antigo"        "$G" "overlay_font=30"
confere "mantem comentario"               "$G" "# PrefBar 0.3.0 configuration"
confere "mantem secao"                    "$G" "\[diagnostics\]"
confere "mantem chave desconhecida"       "$G" "poll_us=2000"
confere "mantem diag"                     "$G" "diag=0"
confere "corrige o invalido"              "$G" "show_vram=0"
confere "acrescenta o que faltava"        "$G" "show_power=0"
nao_tem "sem .tmp sobrando"               "$(ls -a $DADOS/prefbar)" "\.tmp"
confere "diario: gravado"                 "$(cat $DADOS/glibren.log)" "prefbar: prefbar.conf gravado (3 campo(s))"
# atomico: o .tmp e criado com O_EXCL e trocado por rename; um .tmp velho nao atrapalha e um link no lugar e recusado
echo lixo > "$CONF.tmp"
confere "tmp velho: grava mesmo assim"    "$(post -d text_shadow=0 $L/api/prefbar/conf)" '"ok":true'
confere "tmp velho: conteudo certo"       "$(cat $CONF)" "text_shadow=0"
INODE1=$(stat -c %i $CONF); post -d text_shadow=1 $L/api/prefbar/conf > /dev/null; INODE2=$(stat -c %i $CONF)
if [ "$INODE1" != "$INODE2" ]; then ok=$((ok+1)); echo "OK   rename troca o arquivo (inode novo)"; else falhas=$((falhas+1)); echo "FALHA rename: mesmo inode"; fi
cp $CONF $T/conf.antes; mv $CONF $T/conf.real; ln -s $T/conf.real $CONF
confere "link no lugar: recusado"         "$(post -d text_shadow=0 $L/api/prefbar/conf)" '"ok":false'
confere "link: alvo intacto"              "$(cmp $T/conf.real $T/conf.antes && echo igual)" "igual"
rm -f $CONF; mv $T/conf.real $CONF
head -c 70000 /dev/zero | tr '\0' 'a' > "$CONF"
confere "arquivo grande demais: recusado" "$(post -d overlay=0 $L/api/prefbar/conf)" "prefbar_ilegivel"
confere "grande demais: intacto"          "$(stat -c %s $CONF)" "^70000$"
printf 'overlay=1\n%0300d\n' 0 > "$CONF"
confere "linha longa apontada"            "$(curl -s $L/api/prefbar/conf)" '"linha_longa":true'
para

kill $(jobs -p) 2>/dev/null; wait 2>/dev/null
rm -rf "$T"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
