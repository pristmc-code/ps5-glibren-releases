"""Confere os parsers de cheat do glibren (C) contra uma leitura independente em Python, com os arquivos REAIS.

    python3 -I testes/cheats_reais.py GLIBREN_PC PASTA_CHEATS [PASTA_ILLUSION]

PASTA_CHEATS = a pasta "cheats" do HEN-Cheats-Collection (com json/, shn/ e mc4/). PASTA_ILLUSION (opcional) = a
pasta "patches" do PS4-PS5-Game-Patch (xml/ e xml_prospero/). Para cada arquivo roda "GLIBREN_PC --teste-cheat
ARQUIVO TID VERSAO" e compara cheats, trechos (offset, tipo, bytes on/off), padroes e codigos iniciais com o que o
Python le (json, xml.etree e AES pelo modulo cryptography). Sai com 1 se algum arquivo divergir.
So le arquivos; nao toca em memoria de processo nenhum.
"""
import base64
import json
import os
import struct
import subprocess
import sys
import xml.etree.ElementTree as ET

CHAVE = b"304c6528f659c766110239a51cl5dd9c"
IV = b"u@}kzW2u[u(8DWar"


def mc4_xml(dados):
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    d = base64.b64decode(dados.strip())
    x = Cipher(algorithms.AES(CHAVE), modes.CBC(IV)).decryptor()
    x = x.update(d) + x.finalize()
    return x[: -x[-1]]


def hexb(s):
    s = "".join(c for c in (s or "") if c not in " \t\r\n-_")
    if not s:
        return b""
    try:
        return bytes.fromhex(s) if len(s) % 2 == 0 else None
    except ValueError:
        return None


def classificar(offset, on, off, secao, absoluto):
    s = offset.strip()
    s = s[2:] if s.lower().startswith("0x") else s
    try:
        o = int(s, 16) if s and len(s) <= 16 and all(c in "0123456789abcdefABCDEF" for c in s) else None
    except ValueError:
        o = None
    bon, boff = hexb(on), hexb(off)
    # trecho maior que 4096 bytes (MAX_TRECHO do glibren, como na 0.9.18) = invalido de proposito
    if o is None or not bon or boff is None or (boff and len(boff) != len(bon)) or len(bon) > 4096:
        return {"tipo": "invalido"}
    if secao:
        t = "secao"
    elif boff and not any(boff):
        t = "area_extra"
    elif absoluto:
        t = "absoluto"
    elif not boff:
        t = "sem_off"
    else:
        t = "normal"
    return {"tipo": t, "offset": o, "on": bon.hex().upper(), "off": boff.hex().upper() if boff else ""}


def ler_trainer(texto):
    raiz = ET.fromstring(texto)
    cheats = []
    for x in raiz:
        if x.tag not in ("Cheat", "StartUP"):
            continue
        tr = []
        for l in x.findall("Cheatline"):
            g = lambda k: (l.find(k).text or "") if l.find(k) is not None else ""
            sec = g("Section").strip()
            ab = g("Absolute").strip().lower()
            secao = (int(sec) if sec.isdigit() else -1) if sec else 0
            t = classificar(g("Offset"), g("ValueOn"), g("ValueOff"), secao, ab in ("true", "1"))
            if secao < 0:
                t = {"tipo": "invalido"}
            tr.append(t)
        cheats.append({"nome": (x.get("Text") or "").strip(), "inicial": x.tag == "StartUP", "trechos": tr})
    return cheats


def ler_json(texto):
    d = json.loads(texto)
    out = []
    for m in d.get("mods", []):
        if not isinstance(m, dict):
            continue
        tr = []
        for x in m.get("memory", []):
            if not isinstance(x, dict):
                continue
            sec = x.get("section", 0)
            ab = x.get("absolute", False)
            tr.append(classificar(str(x.get("offset", "")), str(x.get("on", "")), str(x.get("off", "")),
                                  sec if isinstance(sec, int) and not isinstance(sec, bool) else 0, ab is True))
        out.append({"nome": m.get("name", ""), "inicial": False, "trechos": tr})
    return out


def comparar(nome, esperado, lido):
    erros = []
    if len(esperado) != len(lido["cheats"]):
        return ["%s: %d cheats no Python, %d no glibren" % (nome, len(esperado), len(lido["cheats"]))]
    for i, (e, g) in enumerate(zip(esperado, lido["cheats"])):
        if e["nome"].strip() != g["nome"].strip() and " ".join(e["nome"].split()) != " ".join(g["nome"].split()):
            erros.append("%s cheat %d: nome %r != %r" % (nome, i, e["nome"], g["nome"]))
        if e["inicial"] != g["inicial"]:
            erros.append("%s cheat %d: inicial" % (nome, i))
        if len(e["trechos"]) != len(g["trechos"]):
            erros.append("%s cheat %d: %d trechos != %d" % (nome, i, len(e["trechos"]), len(g["trechos"])))
            continue
        for k, (te, tg) in enumerate(zip(e["trechos"], g["trechos"])):
            if te["tipo"] != tg["tipo"]:
                erros.append("%s cheat %d trecho %d: tipo %s != %s" % (nome, i, k, te["tipo"], tg["tipo"]))
            elif te["tipo"] != "invalido" and (te["offset"] != int(tg["offset"], 16) or te["on"] != tg["on"] or te["off"] != tg["off"]):
                erros.append("%s cheat %d trecho %d: bytes/offset diferentes" % (nome, i, k))
    return erros


def rodar(binario, caminho, tid, versao):
    r = subprocess.run([binario, "--teste-cheat", caminho, tid, versao], capture_output=True, timeout=60)
    return json.loads(r.stdout.decode("utf-8", "replace"))


# ---- Illusion: valores esperados
def int_le(v, largura):
    v = v.strip()
    neg = v.startswith("-")
    if neg:
        v = v[1:]
    if v.lower().startswith("0x"):
        n = int(v[2:], 16)
    elif v[:1] in "#$" and v:
        n = int(v[1:], 16)
    else:
        n = int(v, 10)
    if neg:
        n = (1 << (largura * 8)) - n
    return n.to_bytes(largura, "little")


def utf8_esc(v):
    out = bytearray()
    i = 0
    b = v.encode("utf-8")
    while i < len(b):
        c = b[i]
        if c == 0x5C and i + 1 < len(b):
            n = chr(b[i + 1])
            if n in "ntr0\\":
                out.append({"n": 10, "t": 9, "r": 13, "0": 0, "\\": 0x5C}[n]); i += 2; continue
            if n == "x":
                out.append(int(b[i + 2:i + 4], 16)); i += 4; continue
            raise ValueError
        out.append(c); i += 1
    return bytes(out)


def valor_ill(tipo, v):
    if tipo == "bytes":
        s = v.strip()
        s = s[2:] if s.lower().startswith("0x") else s[1:] if s[:1] in "#$" and s else s
        return hexb(s)
    if tipo in ("byte", "bytes16", "bytes32", "bytes64"):
        return int_le(v, {"byte": 1, "bytes16": 2, "bytes32": 4, "bytes64": 8}[tipo])
    if tipo == "float32":
        return struct.pack("<f", float(v))
    if tipo == "float64":
        return struct.pack("<d", float(v))
    if tipo == "utf8":
        return utf8_esc(v)
    if tipo == "utf16":
        return utf8_esc(v).decode("utf-8").encode("utf-16-le")
    return None


def campo(no, nome):
    a = no.get(nome)
    f = no.findall(nome)
    if a is not None and f or len(f) > 1:
        return None
    if a is not None:
        return a.strip()
    return (f[0].text or "").strip() if f else ""


def ler_illusion(caminho, tid, versao):
    raiz = ET.parse(caminho).getroot()
    out = []
    for m in raiz.findall("Metadata"):
        av = campo(m, "AppVer") or ""
        if not any(x.strip() == versao or x.strip().lower() == "mask" for x in av.split(",")):
            continue
        base = campo(m, "ImageBase") or ""
        base = int(base, 16) if base.lower().startswith("0x") else int(base or "4194304")
        tr = []
        pl = m.findall("PatchList")
        for l in (pl[0] if len(pl) == 1 else []):
            tipo = campo(l, "Type") or ""
            if tipo in ("mask", "mask_jump32"):
                tr.append({"tipo": "padrao" if tipo == "mask" else "padrao_salto", "on": (hexb(campo(l, "Value")) or b"").hex().upper()})
                continue
            try:
                end = campo(l, "Address")
                a = int(end, 16) if end.lower().startswith("0x") else int(end, 8) if end.startswith("0") and len(end) > 1 else int(end)
                b = valor_ill(tipo, campo(l, "Value") or "")
                tr.append({"tipo": "sem_off", "offset": a - base, "on": b.hex().upper(), "off": ""} if b and a >= base else {"tipo": "invalido"})
            except Exception:
                tr.append({"tipo": "invalido"})
        out.append({"nome": campo(m, "Name") or "?", "inicial": False, "trechos": tr})
    return out


def comparar_ill(nome, esperado, lido):
    erros = []
    if len(esperado) != len(lido["cheats"]):
        return ["%s: %d patches no Python, %d no glibren" % (nome, len(esperado), len(lido["cheats"]))]
    for i, (e, g) in enumerate(zip(esperado, lido["cheats"])):
        if g.get("invalido"):
            continue   # bloco que o glibren recusou inteiro (campo desconhecido/ambiguo): conferido a parte
        if len(e["trechos"]) != len(g["trechos"]):
            erros.append("%s patch %d: %d linhas != %d" % (nome, i, len(e["trechos"]), len(g["trechos"])))
            continue
        for k, (te, tg) in enumerate(zip(e["trechos"], g["trechos"])):
            if te["tipo"] != tg["tipo"]:
                erros.append("%s patch %d linha %d: tipo %s != %s" % (nome, i, k, te["tipo"], tg["tipo"]))
            elif te["tipo"] == "sem_off" and (te["offset"] != int(tg["offset"], 16) or te["on"] != tg["on"]):
                erros.append("%s patch %d linha %d: offset/valor diferentes (%s %s)" % (nome, i, k, te["on"], tg["on"]))
            elif te["tipo"].startswith("padrao") and te["on"] != tg["on"]:
                erros.append("%s patch %d linha %d: valor do padrao diferente" % (nome, i, k))
    return erros


def main():
    binario, pasta = sys.argv[1], sys.argv[2]
    ill = sys.argv[3] if len(sys.argv) > 3 else None
    total = {"json": 0, "shn": 0, "mc4": 0, "xml": 0}
    cheats = trechos = iniciais = arquivos_ini = deps = 0
    tipos = {}
    erros = []
    for fmt in ("json", "shn", "mc4"):
        d = os.path.join(pasta, fmt)
        for nome in sorted(os.listdir(d)):
            caminho = os.path.join(d, nome)
            partes = nome.rsplit(".", 1)[0].split("_")
            tid, versao = partes[0], partes[1]
            dados = open(caminho, "rb").read()
            try:
                if fmt == "json":
                    esperado = ler_json(dados.decode("utf-8-sig"))
                elif fmt == "shn":
                    esperado = ler_trainer(dados)
                else:
                    esperado = ler_trainer(mc4_xml(dados))
            except Exception as e:
                esperado = None
            lido = rodar(binario, caminho, tid, versao)
            total[fmt] += 1
            if esperado is None:
                if not lido["erro"]:
                    erros.append("%s: o Python recusou e o glibren leu" % nome)
                continue
            if lido["erro"]:
                erros.append("%s: glibren recusou: %s" % (nome, lido["erro"]))
                continue
            erros += comparar(nome, esperado, lido)
            cheats += len(lido["cheats"])
            arquivos_ini += lido["codigo_inicial"]
            for c in lido["cheats"]:
                iniciais += c["inicial"]
                deps += c["ndep"] != 0
                for t in c["trechos"]:
                    trechos += 1
                    tipos[t["tipo"]] = tipos.get(t["tipo"], 0) + 1
    if ill:
        for sub in ("xml", "xml_prospero"):
            d = os.path.join(ill, sub)
            if not os.path.isdir(d):
                continue
            for nome in sorted(os.listdir(d)):
                caminho = os.path.join(d, nome)
                if not nome.endswith(".xml"):
                    continue
                try:
                    raiz = ET.parse(caminho).getroot()
                    ids = [i.text.strip() for i in raiz.find("TitleID").findall("ID")]
                    vers = [campo(m, "AppVer") for m in raiz.findall("Metadata")]
                except Exception:
                    continue
                for versao in sorted(set(v2.strip() for v in vers if v for v2 in v.split(",")))[:3]:
                    if versao.lower() == "mask":
                        versao = "01.00"
                    lido = rodar(binario, caminho, ids[0], versao)
                    total["xml"] += 1
                    if lido["erro"]:
                        erros.append("%s: glibren recusou: %s" % (nome, lido["erro"]))
                        continue
                    erros += comparar_ill(nome + " v" + versao, ler_illusion(caminho, ids[0], versao), lido)
                    for c in lido["cheats"]:
                        for t in c["trechos"]:
                            tipos["xml:" + t["tipo"]] = tipos.get("xml:" + t["tipo"], 0) + 1
    print("arquivos:", total)
    print("cheats: %d (codigos iniciais %d em %d arquivos; com dependencia de area extra %d); trechos: %d" % (cheats, iniciais, arquivos_ini, deps, trechos))
    print("tipos:", dict(sorted(tipos.items())))
    for e in erros[:40]:
        print("DIVERGE", e)
    print("divergencias:", len(erros))
    return 1 if erros else 0


if __name__ == "__main__":
    sys.exit(main())
