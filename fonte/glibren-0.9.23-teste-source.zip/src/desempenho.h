/* Game Library Renamer (payload PS5) - numeros de desempenho (0.9.22): MHz da CPU e da GPU, RAM e VRAM pelo kernel e
   uso de CPU por nucleo. So le enquanto alguem olha as paginas Temperatura ou FPS (pedido nos ultimos 15 s).
   Ideia vista no PrefBar (X1NONs, GPL-3.0); codigo proprio. Ver desempenho.c. */
#pragma once

#include "util.h"

/* Alguem esta olhando (GET /api/termico ou /api/fps): liga as leituras por ~15 s. */
void desempenho_pedido(void);
/* Uma rodada de leituras (a thread do sistema chama a cada 2 s; nao faz nada se ninguem pediu). */
void desempenho_amostrar(void);
/* "desempenho":{...} (sem chaves em volta). Cada numero e -1 (ou some da lista) quando a funcao falta ou falhou. */
void desempenho_json(buf_t *b);
/* Uso por nucleo recente (ate max): devolve a quantidade (0 = sem dado) e o uso total em *total. */
int desempenho_nucleos(double *uso, int max, double *total);
