/* Game Library Renamer (payload PS5) - configuracao do PrefBar pelo celular (0.9.22). Ver prefbar.h.

Credito: PrefBar e de X1NON (X1NONs/PrefBar, GPL-3.0). Daqui so os nomes das chaves, os valores aceitos e as regras
de leitura do arquivo (linha "chave=valor", a ultima ocorrencia vale, linha longa demais invalida o arquivo).

Gravacao: o arquivo inteiro e lido (ate 64 KiB), as linhas das chaves editadas recebem o valor novo (todas as
ocorrencias, porque no PrefBar a ultima vence), as que faltam vao para o fim; comentarios, secoes e chaves que o
glibren nao conhece ficam como estavam. Grava em prefbar.conf.tmp (O_EXCL, sem seguir link), fsync, rename e fsync
da pasta: uma queda no meio deixa o arquivo antigo inteiro. */
#include "prefbar.h"

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "config.h"
#include "plataforma.h"

#define MAX_ARQUIVO (64 * 1024)
#define MAX_LINHA 255   /* o PrefBar le com fgets(256): linha maior invalida o arquivo inteiro */

typedef enum { BOOL, INT, OPCAO, COR } tipo_t;

typedef struct {
  const char *chave;
  tipo_t tipo;
  int min, max;
  const char *opcoes;    /* OPCAO: separadas por espaco */
  const char *padrao;
} campo_t;

/* Faixas e padroes da v0.3.0 (config_apply_value). So o que faz sentido mudar pelo celular. */
static const campo_t CAMPOS[] = {
  {"overlay", BOOL, 0, 1, NULL, "1"},
  {"overlay_horizontal", BOOL, 0, 1, NULL, "0"},
  {"overlay_horizontal_align", OPCAO, 0, 0, "left center right", "center"},
  {"overlay_horizontal_spacing", OPCAO, 0, 0, "short medium long", "medium"},
  {"overlay_format", OPCAO, 0, 0, "compact classic", "compact"},
  {"overlay_corner", OPCAO, 0, 0, "0 2", "0"},
  {"overlay_x", INT, 0, 1800, NULL, "24"},
  {"overlay_y", INT, 0, 1000, NULL, "24"},
  {"overlay_font", INT, 10, 96, NULL, "26"},
  {"text_color", COR, 0, 0, NULL, "#F2F2F2"},
  {"text_shadow", BOOL, 0, 1, NULL, "1"},
  {"show_fps", BOOL, 0, 1, NULL, "1"},
  {"show_frametime", BOOL, 0, 1, NULL, "1"},
  {"show_1percent_low", BOOL, 0, 1, NULL, "1"},
  {"show_cpu_usage", BOOL, 0, 1, NULL, "1"},
  {"show_cpu_temp", BOOL, 0, 1, NULL, "1"},
  {"show_cpu_clock", BOOL, 0, 1, NULL, "1"},
  {"show_gpu_temp", BOOL, 0, 1, NULL, "1"},
  {"gpu_temp_label", OPCAO, 0, 0, "gpu soc", "gpu"},
  {"show_gpu_clock", BOOL, 0, 1, NULL, "1"},
  {"show_fan_duty", BOOL, 0, 1, NULL, "1"},
  {"show_ram", BOOL, 0, 1, NULL, "1"},
  {"show_vram", BOOL, 0, 1, NULL, "1"},
  {"show_power", BOOL, 0, 1, NULL, "1"},
  {"touchpad_toggle", BOOL, 0, 1, NULL, "1"},
  {"notifications", BOOL, 0, 1, NULL, "1"},
};
#define N_CAMPOS ((int)(sizeof CAMPOS / sizeof CAMPOS[0]))

void prefbar_pasta(char *saida, size_t tam) {
#ifdef __PROSPERO__
  snprintf(saida, tam, "/data/prefbar");
#else
  snprintf(saida, tam, "%s/prefbar", g_pasta_dados);
#endif
}

static void arquivo_conf(char *saida, size_t tam) {
  char p[512];
  prefbar_pasta(p, sizeof p);
  snprintf(saida, tam, "%s/prefbar.conf", p);
}

static int achar(const char *chave) {
  for(int i = 0; i < N_CAMPOS; i++)
    if(!strcmp(CAMPOS[i].chave, chave)) return i;
  return -1;
}

/* Inteiro como o PrefBar le (strtol inteiro, sem sobras, dentro da faixa). */
static int inteiro_ok(const char *v, int min, int max) {
  if(!*v || strlen(v) > 6) return 0;
  const char *c = v;
  if(*c == '-') c++;
  if(!*c) return 0;
  for(; *c; c++)
    if(*c < '0' || *c > '9') return 0;
  long n = strtol(v, NULL, 10);
  return n >= min && n <= max;
}

static int opcao_ok(const char *v, const char *opcoes) {
  size_t n = strlen(v);
  if(!n) return 0;
  for(const char *p = opcoes; *p;) {
    size_t k = strcspn(p, " ");
    if(k == n && !strncmp(p, v, n)) return 1;
    p += k;
    while(*p == ' ') p++;
  }
  return 0;
}

static int valor_ok(const campo_t *c, const char *v) {
  switch(c->tipo) {
  case BOOL:
  case INT:
    return inteiro_ok(v, c->min, c->max);
  case OPCAO:
    return opcao_ok(v, c->opcoes);
  case COR:
    if(strlen(v) != 7 || v[0] != '#') return 0;
    for(int i = 1; i < 7; i++)
      if(!strchr("0123456789abcdefABCDEF", v[i])) return 0;
    return 1;
  }
  return 0;
}

int prefbar_valor_ok(const char *chave, const char *valor) {
  int i = achar(chave);
  return i >= 0 && valor_ok(&CAMPOS[i], valor);
}

/* Tira espacos (e \r) das pontas, como o PrefBar. */
static char *aparar(char *s) {
  while(*s == ' ' || *s == '\t') s++;
  size_t n = strlen(s);
  while(n && (s[n - 1] == ' ' || s[n - 1] == '\t' || s[n - 1] == '\r' || s[n - 1] == '\n')) s[--n] = 0;
  return s;
}

/* Le o arquivo inteiro (ate MAX_ARQUIVO). 1 = existe e foi lido; 0 = nao existe; -1 = erro/grande demais/link. */
static int ler_arquivo(buf_t *b) {
  char arq[600];
  arquivo_conf(arq, sizeof arq);
  struct stat st;
  if(lstat(arq, &st)) return errno == ENOENT ? 0 : -1;
  if(!S_ISREG(st.st_mode) || st.st_size > MAX_ARQUIVO) return -1;
  int fd = open(arq, O_RDONLY | O_NOFOLLOW);
  if(fd < 0) return -1;
  char bloco[8192];
  ssize_t r;
  while((r = read(fd, bloco, sizeof bloco)) > 0) {
    if(b->n + (size_t)r > MAX_ARQUIVO) {
      close(fd);
      return -1;
    }
    buf_add(b, bloco, (size_t)r);
  }
  close(fd);
  if(r < 0) return -1;
  buf_add(b, "", 1);
  b->n--;
  return 1;
}

/* Valor atual de cada campo no texto (a ultima ocorrencia vale). valores[i] = "" se nao achou; invalido[i] = 1 se o
   texto tem um valor que o PrefBar recusaria (ele usaria o padrao). *linha_longa = 1 se ha linha > 255 caracteres. */
static void interpretar(const char *texto, char valores[][16], int *invalido, int *linha_longa) {
  for(int i = 0; i < N_CAMPOS; i++) {
    valores[i][0] = 0;
    invalido[i] = 0;
  }
  *linha_longa = 0;
  for(const char *p = texto; p && *p;) {
    const char *fim = strchr(p, '\n');
    size_t n = fim ? (size_t)(fim - p) : strlen(p);
    if(n > MAX_LINHA) *linha_longa = 1;
    char linha[512];
    if(n < sizeof linha) {
      memcpy(linha, p, n);
      linha[n] = 0;
      char *l = aparar(linha);
      char *igual = strchr(l, '=');
      if(*l && *l != '#' && *l != ';' && *l != '[' && igual) {
        *igual = 0;
        char *k = aparar(l), *v = aparar(igual + 1);
        int i = achar(k);
        if(i >= 0) {
          int ok = valor_ok(&CAMPOS[i], v);
          invalido[i] = !ok;
          snprintf(valores[i], sizeof valores[i], "%s", ok ? v : "");
        }
      }
    }
    p = fim ? fim + 1 : NULL;
  }
}

/* Algum arquivo de estado/log do PrefBar mudou depois que o PS5 ligou? (prefbar.conf fica de fora: o glibren grava) */
int prefbar_rodou_desde(long long desde) {
  static const char *const ARQS[] = {"controller.log", "injector.log", "status.txt", "status.kv", "debug.log", NULL};
  char p[512], arq[600];
  prefbar_pasta(p, sizeof p);
  for(int i = 0; ARQS[i]; i++) {
    struct stat st;
    snprintf(arq, sizeof arq, "%s/%s", p, ARQS[i]);
    if(!lstat(arq, &st) && S_ISREG(st.st_mode) && (long long)st.st_mtime > desde + 5) return 1;
  }
  return 0;
}

void prefbar_rota_ler(pedido_t *p) {
  buf_t texto = {0}, b = {0};
  char arq[600], valores[N_CAMPOS][16];
  int invalido[N_CAMPOS], longa = 0;
  arquivo_conf(arq, sizeof arq);
  int r = ler_arquivo(&texto);
  interpretar(r > 0 ? texto.d : "", valores, invalido, &longa);
  buf_str(&b, "{\"ok\":true,\"existe\":");
  buf_str(&b, r > 0 ? "true" : "false");
  buf_fmt(&b, ",\"ilegivel\":%s,\"linha_longa\":%s,\"caminho\":", r < 0 ? "true" : "false", longa ? "true" : "false");
  buf_json(&b, arq);
  buf_str(&b, ",\"valores\":{");
  for(int i = 0; i < N_CAMPOS; i++) {
    buf_fmt(&b, "%s\"%s\":", i ? "," : "", CAMPOS[i].chave);
    buf_json(&b, valores[i][0] ? valores[i] : CAMPOS[i].padrao);
  }
  buf_str(&b, "},\"no_arquivo\":[");
  int n = 0;
  for(int i = 0; i < N_CAMPOS; i++)
    if(valores[i][0]) buf_fmt(&b, "%s\"%s\"", n++ ? "," : "", CAMPOS[i].chave);
  buf_str(&b, "],\"invalidos\":[");
  n = 0;
  for(int i = 0; i < N_CAMPOS; i++)
    if(invalido[i]) buf_fmt(&b, "%s\"%s\"", n++ ? "," : "", CAMPOS[i].chave);
  buf_str(&b, "],\"campos\":[");
  static const char *const TIPOS[] = {"bool", "int", "opcao", "cor"};
  for(int i = 0; i < N_CAMPOS; i++) {
    const campo_t *c = &CAMPOS[i];
    buf_fmt(&b, "%s{\"chave\":\"%s\",\"tipo\":\"%s\",\"min\":%d,\"max\":%d,\"padrao\":", i ? "," : "", c->chave, TIPOS[c->tipo], c->min, c->max);
    buf_json(&b, c->padrao);
    buf_str(&b, ",\"opcoes\":");
    buf_json(&b, c->opcoes ? c->opcoes : "");
    buf_str(&b, "}");
  }
  buf_str(&b, "]}");
  responder_json(p, 200, &b);
  buf_free(&b);
  buf_free(&texto);
}

/* Decodifica %XX e + de um pedaco urlencoded. 0 = cabe. */
static int decodificar(const char *s, size_t n, char *saida, size_t tam) {
  size_t o = 0;
  for(size_t i = 0; i < n; i++) {
    if(o + 1 >= tam) return -1;
    char c = s[i];
    if(c == '+') c = ' ';
    else if(c == '%') {
      static const char HEX[] = "0123456789abcdef";
      const char *a = i + 2 < n ? strchr(HEX, s[i + 1] | 0x20) : NULL, *z = a ? strchr(HEX, s[i + 2] | 0x20) : NULL;
      if(!a || !z || !s[i + 1] || !s[i + 2]) return -1;
      c = (char)((a - HEX) * 16 + (z - HEX));
      i += 2;
    }
    if((unsigned char)c < ' ' || c == 0x7f) return -1;   /* nada de quebra de linha nem controle no arquivo */
    saida[o++] = c;
  }
  saida[o] = 0;
  return 0;
}

/* Grava o texto novo de forma atomica. 0 = ok (msg vazia); -1 com a mensagem. */
static int gravar(const char *texto, size_t n, char *msg, size_t tam) {
  char pasta[512], arq[600], tmp[620];
  prefbar_pasta(pasta, sizeof pasta);
  arquivo_conf(arq, sizeof arq);
  snprintf(tmp, sizeof tmp, "%s.tmp", arq);
  struct stat st;
  if(!lstat(arq, &st) && !S_ISREG(st.st_mode)) {
    snprintf(msg, tam, "o prefbar.conf nao e um arquivo comum: nada gravado");
    return -1;
  }
  if(mkdir_p(pasta)) {
    snprintf(msg, tam, "nao criou a pasta %s (%s)", pasta, strerror(errno));
    return -1;
  }
  unlink(tmp);
  int fd = open(tmp, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644);
  if(fd < 0) {
    snprintf(msg, tam, "nao criou o arquivo temporario (%s)", strerror(errno));
    return -1;
  }
  int ok = 1;
  for(size_t feitos = 0; ok && feitos < n;) {
    ssize_t r = write(fd, texto + feitos, n - feitos);
    if(r <= 0) ok = 0;
    else feitos += (size_t)r;
  }
  if(ok && fsync(fd)) ok = 0;
  if(close(fd)) ok = 0;
  if(!ok || rename(tmp, arq)) {
    snprintf(msg, tam, "erro ao gravar o prefbar.conf (%s): o arquivo antigo ficou como estava", strerror(errno));
    unlink(tmp);
    return -1;
  }
  int d = open(pasta, O_RDONLY);
  if(d >= 0) {
    fsync(d);
    close(d);
  }
  msg[0] = 0;
  return 0;
}

void prefbar_rota_gravar(pedido_t *p) {
  char novos[N_CAMPOS][16];
  int mudou[N_CAMPOS] = {0}, qtd = 0;
  const char *corpo = p->corpo ? p->corpo : "";
  /* 1) valida tudo antes de mexer no arquivo */
  for(const char *c = corpo; *c;) {
    const char *fim = strchr(c, '&');
    size_t n = fim ? (size_t)(fim - c) : strlen(c);
    const char *igual = memchr(c, '=', n);
    char k[64], v[64];
    if(n && (!igual || decodificar(c, (size_t)(igual - c), k, sizeof k) || decodificar(igual + 1, n - (size_t)(igual - c) - 1, v, sizeof v))) {
      responder_erro(p, 400, "prefbar_pedido_invalido", "pedido invalido", NULL);
      return;
    }
    if(n) {
      int i = achar(k);
      if(i < 0) {
        responder_erro(p, 400, "prefbar_campo_desconhecido", "campo desconhecido", k);
        return;
      }
      if(!valor_ok(&CAMPOS[i], v)) {
        diario("prefbar: valor recusado para %s", CAMPOS[i].chave);
        responder_erro(p, 400, "prefbar_valor_invalido", "valor fora do que o PrefBar aceita", CAMPOS[i].chave);
        return;
      }
      if(!mudou[i]) qtd++;
      mudou[i] = 1;
      snprintf(novos[i], sizeof novos[i], "%s", v);
    }
    c = fim ? fim + 1 : c + n;
  }
  if(!qtd) {
    responder_erro(p, 400, "prefbar_nada", "nenhum campo para gravar", NULL);
    return;
  }
  /* 2) monta o texto novo a partir do atual */
  buf_t atual = {0}, novo = {0};
  int r = ler_arquivo(&atual);
  if(r < 0) {
    buf_free(&atual);
    responder_erro(p, 409, "prefbar_ilegivel", "o prefbar.conf atual nao pode ser lido (grande demais ou nao e arquivo comum): nada gravado", NULL);
    return;
  }
  int escrito[N_CAMPOS] = {0};
  if(r == 0) buf_str(&novo, "# PrefBar configuration (criado pelo glibren; o PrefBar acrescenta o resto ao abrir)\n");
  for(const char *c = r > 0 ? atual.d : ""; c && *c;) {
    const char *fim = strchr(c, '\n');
    size_t n = fim ? (size_t)(fim - c) : strlen(c);
    char linha[512];
    int trocou = 0;
    if(n < sizeof linha) {
      memcpy(linha, c, n);
      linha[n] = 0;
      char *l = aparar(linha);
      char *igual = strchr(l, '=');
      if(*l && *l != '#' && *l != ';' && *l != '[' && igual) {
        *igual = 0;
        int i = achar(aparar(l));
        if(i >= 0 && mudou[i]) {
          buf_fmt(&novo, "%s=%s\n", CAMPOS[i].chave, novos[i]);
          escrito[i] = 1;
          trocou = 1;
        }
      }
    }
    if(!trocou) {
      buf_add(&novo, c, n);
      buf_str(&novo, "\n");
    }
    c = fim ? fim + 1 : NULL;
  }
  int cabecalho = 0;
  for(int i = 0; i < N_CAMPOS; i++) {
    if(!mudou[i] || escrito[i]) continue;
    if(!cabecalho && r > 0) buf_str(&novo, "\n# glibren\n");
    cabecalho = 1;
    buf_fmt(&novo, "%s=%s\n", CAMPOS[i].chave, novos[i]);
  }
  buf_free(&atual);
  if(novo.n > MAX_ARQUIVO) {
    buf_free(&novo);
    responder_erro(p, 409, "prefbar_ilegivel", "o prefbar.conf ficaria grande demais: nada gravado", NULL);
    return;
  }
  char msg[300];
  if(gravar(novo.d ? novo.d : "", novo.n, msg, sizeof msg)) {
    buf_free(&novo);
    diario("prefbar: %s", msg);
    responder_erro(p, 500, "prefbar_gravar", msg, NULL);
    return;
  }
  buf_free(&novo);
  diario("prefbar: prefbar.conf gravado (%d campo(s)); o PrefBar le de novo quando um jogo abrir", qtd);
  prefbar_rota_ler(p);
}
