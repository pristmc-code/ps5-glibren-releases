/* Game Library Renamer (payload PS5) - numeros de desempenho (0.9.22). Ver desempenho.h.

Leituras (todas pelo watchdog sce_com_prazo(): uma funcao que trava fica fora e a linha some da pagina):
  - MHz da CPU: sceKernelGetCpuFrequency() devolve Hz (vale 100 MHz..10 GHz);
  - MHz da GPU: sceKernelGetSocClock(uint32_t[32]); o dominio 20 e o relogio da GPU em MHz (vale 100..5000);
  - RAM e VRAM: get_page_table_stats(1, 1, &total, &livre) e (1, 2, ...), em MB (vale total 1..20480 e livre <= total);
  - uso por nucleo: sceKernelGetCpuUsage(lista, &n) da o tempo de CPU de cada thread do sistema (0x28 bytes cada:
    ?, tid, tempo de usuario {s, ns}, tempo de sistema {s, ns}); as threads ociosas "SceIdleCpuN" (nome por
    sceKernelGetThreadName, procurado uma vez) dizem quanto cada nucleo ficou parado: uso = 100% - ocioso/intervalo.
As funcoes sao declaradas weak (firmware sem elas = NULL, o payload carrega igual). Se o simbolo fraco nao vier, procura
pelo nome e depois pelo NID em libkernel_sys.sprx/libkernel.sprx (kernel_dynlib_dlsym / kernel_dynlib_resolve).
Leitura absurda (fora da faixa): segura o ultimo valor bom por ate 5 rodadas (10 s) e depois a linha some.
Fontes: as funcoes, o dominio 20, os tipos (1,1)/(1,2) e o nome das threads ociosas foram vistos no PrefBar
(X1NONs/PrefBar, GPL-3.0, src/ps5/telemetry/prefbar_telemetry.c), que por sua vez cita o etaHEN; codigo proprio.
A confirmar no PS5 Pro 12.00 (tudo ❓): se as funcoes existem para um payload e se os numeros fazem sentido.

No PC (testes) os valores sao simulados: GLR_TESTE_SEM_DESEMPENHO = nomes separados por virgula (ou "todas") que
"faltam" no firmware; GLR_TESTE_VRAM_ABSURDA = 1 faz a VRAM vir absurda (testa o filtro). */
#include "desempenho.h"

#include <math.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "plataforma.h"
#include "sce_prazo.h"

#define PRAZO_MS 800
#define OLHANDO_S 15          /* pedido nos ultimos 15 s: le */
#define SEGURA 5              /* rodadas que seguram o ultimo valor bom */
#define MAX_NUC 16
#define MAX_THREADS 4096
#define POOL_MAX_MB 20480

typedef struct {
  int valor, ruins;   /* valor -1 = sem leitura */
} seguro_t;

typedef struct {
  int total, livre, ruins, ok;
} pool_t;

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static long long g_pedido_ms;
static seguro_t g_cpu_mhz = {-1, 0}, g_gpu_mhz = {-1, 0};
static pool_t g_ram, g_vram;
static int g_nuc;                     /* nucleos com leitura (0 = sem) */
static double g_uso[MAX_NUC], g_uso_total = -1;
static long long g_uso_ms;            /* quando o uso por nucleo foi calculado */
/* so a thread do sistema mexe nestes */
static long long g_ocioso_antes[MAX_NUC], g_ms_antes;
static int g_tem_antes;

static long long agora_ms(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (long long)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

void desempenho_pedido(void) {
  pthread_mutex_lock(&g_trava);
  g_pedido_ms = agora_ms();
  pthread_mutex_unlock(&g_trava);
}

/* ------------------------------------------------------------------ funcoes do sistema */

typedef struct {
  int32_t ignorado;
  uint32_t tid;
  int64_t usuario_s, usuario_ns, sistema_s, sistema_ns;
} uso_thread_t;
_Static_assert(sizeof(uso_thread_t) == 0x28, "sceKernelGetCpuUsage: 0x28 bytes por thread");

typedef struct {
  int n;                        /* nucleos achados */
  long long ocioso_us[MAX_NUC]; /* tempo acumulado das threads ociosas */
} ocioso_t;
_Static_assert(sizeof(ocioso_t) <= SCE_PRAZO_SAIDA, "cabe na saida do watchdog");

#ifdef __PROSPERO__
#include <ps5/kernel.h>
#include <ps5/nid.h>

long sceKernelGetCpuFrequency(void) __attribute__((weak));
int sceKernelGetSocClock(uint32_t *) __attribute__((weak));
int get_page_table_stats(int, int, int *, int *) __attribute__((weak));
int sceKernelGetCpuUsage(uso_thread_t *, int32_t *) __attribute__((weak));
int sceKernelGetThreadName(uint32_t, char *) __attribute__((weak));

static long (*f_freq)(void);
static int (*f_relogio)(uint32_t *);
static int (*f_pts)(int, int, int *, int *);
static int (*f_uso)(uso_thread_t *, int32_t *);
static int (*f_nome)(uint32_t, char *);

/* Simbolo fraco, ou pelo nome, ou pelo NID nas bibliotecas do kernel. "fonte" diz qual deu certo (diario). */
static void *resolver(void *fraco, const char *nome, const char **fonte) {
  *fonte = "fraco";
  if(fraco) return fraco;
  static const char *const LIBS[] = {"libkernel_sys.sprx", "libkernel.sprx", NULL};
  pid_t pid = getpid();
  for(int i = 0; LIBS[i]; i++) {
    uint32_t h = 0;
    if(kernel_dynlib_handle(pid, LIBS[i], &h) || !h) continue;
    intptr_t a = kernel_dynlib_dlsym(pid, h, nome);
    *fonte = "nome";
    if(!a) {
      char nid[12];
      if(nid_encode(nome, nid)) {
        a = kernel_dynlib_resolve(pid, h, nid);
        *fonte = "nid";
      }
    }
    if(a) return (void *)a;
  }
  *fonte = "ausente";
  return NULL;
}

static void resolver_todas(void) {
  static int feito;
  if(feito) return;
  feito = 1;
  const char *a, *b, *c, *d, *e;
  f_freq = (long (*)(void))resolver((void *)sceKernelGetCpuFrequency, "sceKernelGetCpuFrequency", &a);
  f_relogio = (int (*)(uint32_t *))resolver((void *)sceKernelGetSocClock, "sceKernelGetSocClock", &b);
  f_pts = (int (*)(int, int, int *, int *))resolver((void *)get_page_table_stats, "get_page_table_stats", &c);
  f_uso = (int (*)(uso_thread_t *, int32_t *))resolver((void *)sceKernelGetCpuUsage, "sceKernelGetCpuUsage", &d);
  f_nome = (int (*)(uint32_t, char *))resolver((void *)sceKernelGetThreadName, "sceKernelGetThreadName", &e);
  diario("desempenho: funcoes: CpuFrequency=%s SocClock=%s page_table_stats=%s CpuUsage=%s ThreadName=%s", a, b, c, d, e);
}

static int fn_freq(const void *e, void *s) {
  (void)e;
  if(!f_freq) return -1;
  *(long long *)s = (long long)f_freq();
  return 0;
}
static int fn_relogio(const void *e, void *s) {
  (void)e;
  return f_relogio ? f_relogio((uint32_t *)s) : -1;   /* s tem 512 bytes zerados; ela escreve 32 x uint32 */
}
static int fn_pts(const void *e, void *s) {
  int *o = s;
  return f_pts ? f_pts(1, *(const int *)e, &o[0], &o[1]) : -1;
}
/* Tempo das threads ociosas de cada nucleo. Lista e tids das ociosas ficam guardados aqui (so uma chamada por vez:
   se uma travar, o watchdog nao chama de novo ate ela voltar). */
static int fn_ocioso(const void *e, void *s) {
  (void)e;
  static uso_thread_t *lista;
  static uint32_t tid[MAX_NUC];
  static int achados, procurou;
  if(!f_uso) return -1;
  if(!lista && !(lista = calloc(MAX_THREADS, sizeof *lista))) return -1;
  int32_t n = MAX_THREADS;
  if(f_uso(lista, &n) || n <= 0) return -1;
  if(n > MAX_THREADS) n = MAX_THREADS;
  if(!achados && f_nome && procurou < 3) {   /* procura as ociosas (no maximo 3 vezes por sessao) */
    procurou++;
    for(int i = 0; i < n; i++) {
      char nome[0x40];
      memset(nome, 0, sizeof nome);
      if(f_nome(lista[i].tid, nome)) continue;
      nome[sizeof nome - 1] = 0;
      if(!strncmp(nome, "SceIdleCpu", 10)) {
        int c = atoi(nome + 10);
        if(c >= 0 && c < MAX_NUC && !tid[c]) {
          tid[c] = lista[i].tid;
          if(c + 1 > achados) achados = c + 1;
        }
      }
    }
  }
  ocioso_t *o = s;
  o->n = 0;
  for(int c = 0; c < achados; c++) {
    o->ocioso_us[c] = -1;
    for(int i = 0; tid[c] && i < n; i++)
      if(lista[i].tid == tid[c]) {
        o->ocioso_us[c] = (lista[i].usuario_s + lista[i].sistema_s) * 1000000LL + (lista[i].usuario_ns + lista[i].sistema_ns) / 1000;
        break;
      }
  }
  o->n = achados;
  return achados ? 0 : 1;
}
#else
/* PC: valores simulados pelo mesmo caminho do watchdog */
static int falta(const char *nome) {
  const char *l = getenv("GLR_TESTE_SEM_DESEMPENHO");
  if(!l || !*l) return 0;
  if(!strcmp(l, "todas")) return 1;
  size_t n = strlen(nome);
  for(const char *p = l; *p;) {
    size_t k = strcspn(p, ",");
    if(k == n && !strncmp(p, nome, n)) return 1;
    p += k;
    if(*p == ',') p++;
  }
  return 0;
}
static void resolver_todas(void) {
  static int feito;
  if(feito) return;
  feito = 1;
  diario("desempenho: funcoes (PC, simuladas): CpuFrequency=%s SocClock=%s page_table_stats=%s CpuUsage=%s",
         falta("sceKernelGetCpuFrequency") ? "ausente" : "ok", falta("sceKernelGetSocClock") ? "ausente" : "ok",
         falta("get_page_table_stats") ? "ausente" : "ok", falta("sceKernelGetCpuUsage") ? "ausente" : "ok");
}
static double sim(void) {
  return 0.5 + 0.5 * sin((double)agora_ms() / 7000.0);
}
static int fn_freq(const void *e, void *s) {
  (void)e;
  if(falta("sceKernelGetCpuFrequency")) return -1;
  *(long long *)s = 3500000000LL;
  return 0;
}
static int fn_relogio(const void *e, void *s) {
  (void)e;
  if(falta("sceKernelGetSocClock")) return -1;
  uint32_t *d = s;
  for(int i = 0; i < 32; i++) d[i] = (uint32_t)(400 + i);
  d[20] = (uint32_t)(1600 + 630 * sim());
  return 0;
}
static int fn_pts(const void *e, void *s) {
  int *o = s, tipo = *(const int *)e;
  if(falta("get_page_table_stats")) return -1;
  if(tipo == 2 && getenv("GLR_TESTE_VRAM_ABSURDA")) {
    o[0] = 999999;
    o[1] = 5;
    return 0;
  }
  o[0] = tipo == 1 ? 13312 : 4608;
  o[1] = (int)(o[0] * (0.25 + 0.4 * sim()));
  return 0;
}
static int fn_ocioso(const void *e, void *s) {
  (void)e;
  if(falta("sceKernelGetCpuUsage")) return -1;
  ocioso_t *o = s;
  long long agora = agora_ms() * 1000;
  o->n = 8;
  for(int c = 0; c < 8; c++) o->ocioso_us[c] = (long long)(agora * (0.2 + 0.09 * c));   /* nucleo c: ocioso 20%..83% */
  return 0;
}
#endif

/* ------------------------------------------------------------------ rodada */

static int chamar(const char *nome, sce_fn_t fn, int arg, void *saida, size_t n) {
  int ret = -1;
  if(sce_com_prazo(nome, fn, &arg, sizeof arg, saida, n, PRAZO_MS, &ret) != SCE_OK) return -1;
  return ret;
}

/* Valor bom: guarda; ruim (ou sem leitura): segura o ultimo bom por SEGURA rodadas. */
static void guardar(seguro_t *g, int v, int bom) {
  if(bom) {
    g->valor = v;
    g->ruins = 0;
  } else if(g->valor >= 0 && ++g->ruins > SEGURA) {
    g->valor = -1;
  }
}

static void guardar_pool(pool_t *g, int total, int livre, int leu, const char *nome) {
  int bom = leu && total > 0 && total <= POOL_MAX_MB && livre >= 0 && livre <= total;
  if(bom) {
    g->total = total;
    g->livre = livre;
    g->ruins = 0;
    g->ok = 1;
    return;
  }
  if(leu) {
    static int avisos;
    if(avisos++ < 5) diario("desempenho: %s recusada (total %d, livre %d MB): %s", nome, total, livre,
                            g->ok && g->ruins < SEGURA ? "segura o ultimo valor bom" : "linha escondida");
  }
  if(g->ok && ++g->ruins > SEGURA) g->ok = 0;
}

void desempenho_amostrar(void) {
  pthread_mutex_lock(&g_trava);
  int olhando = g_pedido_ms && agora_ms() - g_pedido_ms <= OLHANDO_S * 1000LL;
  pthread_mutex_unlock(&g_trava);
  if(!olhando) {
    g_tem_antes = 0;   /* a proxima rodada recomeca a conta do uso por nucleo */
    return;
  }
  resolver_todas();

  long long hz = 0;
  int ok_freq = !chamar("sceKernelGetCpuFrequency", fn_freq, 0, &hz, sizeof hz) && hz >= 100000000LL && hz <= 10000000000LL;
  uint32_t dom[SCE_PRAZO_SAIDA / 4];
  memset(dom, 0, sizeof dom);
  int ok_gpu = !chamar("sceKernelGetSocClock", fn_relogio, 0, dom, sizeof dom) && dom[20] >= 100 && dom[20] <= 5000;
  int r[2] = {0, 0}, v[2] = {0, 0};
  int leu_ram = !chamar("get_page_table_stats", fn_pts, 1, r, sizeof r);
  int leu_vram = !chamar("get_page_table_stats", fn_pts, 2, v, sizeof v);
  ocioso_t oc;
  memset(&oc, 0, sizeof oc);
  int ok_oc = !chamar("sceKernelGetCpuUsage", fn_ocioso, 0, &oc, sizeof oc) && oc.n > 0 && oc.n <= MAX_NUC;
  long long ms = agora_ms();

  pthread_mutex_lock(&g_trava);
  guardar(&g_cpu_mhz, (int)((hz + 500000) / 1000000), ok_freq);
  guardar(&g_gpu_mhz, (int)dom[20], ok_gpu);
  guardar_pool(&g_ram, r[0], r[1], leu_ram, "RAM");
  guardar_pool(&g_vram, v[0], v[1], leu_vram, "VRAM");
  if(ok_oc && g_tem_antes && ms > g_ms_antes) {
    double dt = (double)(ms - g_ms_antes) * 1000.0, soma = 0;
    int n = 0;
    for(int c = 0; c < oc.n; c++) {
      if(oc.ocioso_us[c] < 0 || g_ocioso_antes[c] < 0) {
        g_uso[c] = -1;
        continue;
      }
      double ocioso = (double)(oc.ocioso_us[c] - g_ocioso_antes[c]) / dt;
      if(ocioso < 0) ocioso = 0;
      if(ocioso > 1) ocioso = 1;
      g_uso[c] = (1 - ocioso) * 100;
      soma += g_uso[c];
      n++;
    }
    g_nuc = n ? oc.n : 0;
    g_uso_total = n ? soma / n : -1;
    g_uso_ms = ms;
  } else if(!ok_oc) {
    g_nuc = 0;
    g_uso_total = -1;
  }
  pthread_mutex_unlock(&g_trava);
  if(ok_oc) {
    memcpy(g_ocioso_antes, oc.ocioso_us, sizeof g_ocioso_antes);
    g_ms_antes = ms;
    g_tem_antes = 1;
  } else {
    g_tem_antes = 0;
  }
}

int desempenho_nucleos(double *uso, int max, double *total) {
  pthread_mutex_lock(&g_trava);
  int n = g_nuc && agora_ms() - g_uso_ms <= 6000 ? g_nuc : 0;
  if(n > max) n = max;
  for(int i = 0; i < n; i++) uso[i] = g_uso[i];
  *total = n ? g_uso_total : -1;
  pthread_mutex_unlock(&g_trava);
  return n;
}

static void pool_json(buf_t *b, const char *nome, const pool_t *p) {
  if(p->ok) buf_fmt(b, ",\"%s\":[%d,%d]", nome, p->total - p->livre, p->total);
  else buf_fmt(b, ",\"%s\":-1", nome);
}

void desempenho_json(buf_t *b) {
  double uso[MAX_NUC], total;
  int n = desempenho_nucleos(uso, MAX_NUC, &total);
  pthread_mutex_lock(&g_trava);
  buf_fmt(b, "\"desempenho\":{\"cpu_mhz\":%d,\"gpu_mhz\":%d", g_cpu_mhz.valor, g_gpu_mhz.valor);
  pool_json(b, "ram_mb", &g_ram);
  pool_json(b, "vram_mb", &g_vram);
  pthread_mutex_unlock(&g_trava);
  buf_fmt(b, ",\"cpu\":%.1f,\"nucleos\":[", n ? total : -1.0);
  for(int i = 0; i < n; i++) buf_fmt(b, "%s%.1f", i ? "," : "", uso[i] < 0 ? -1.0 : uso[i]);
  buf_str(b, "]}");
}
