/* Game Library Renamer (payload PS5) - cheats do jogo aberto (Fase 0: leitura; Fase 1: ligar e desligar; Fase 2:
formatos .shn, .mc4 e .xml e prototipo da area extra, desligado por padrao).

Mostra no celular/PC as cheats do catalogo (.json, .shn, .mc4; .xml do Illusion so leitura) para o jogo e a versao
abertos, le os bytes atuais da memoria do jogo e liga/desliga as cheats com as regras de seguranca descritas no topo
de src/cheats.c.
Ver ps5/ESTUDO-cheats-onionhen.md. */
#pragma once

#include "util.h"

/* GET /api/cheats: {"ok":true,"jogo":{...},"catalogo":{...},"arquivos":[...],"cheats":[...]} com a leitura atual. */
void cheats_json(buf_t *b);
/* POST /api/cheats/catalogo: comeca a baixar o HEN-Cheats-Collection (em segundo plano). 0 = comecou; senao msg. */
int cheats_catalogo_baixar(char *msg, size_t tam);
/* POST /api/cheats/ligar (ligar=1) e /api/cheats/desligar (ligar=0). corpo: JSON {"tid","versao","arquivo","indice"}
   ou formulario com os mesmos campos. Escreve a resposta JSON em r e devolve o status HTTP. */
int cheats_acao(int ligar, const char *corpo, size_t n, buf_t *r);
/* Ao fechar o glibren: desliga as cheats ligadas se o jogo ainda for o mesmo (senao so registra no diario). */
void cheats_restaurar_ao_sair(void);
/* 0.9.21 (diagnostico): caminho do aplicadas.json */
void cheats_caminho_aplicadas(char *s, size_t tam);
#ifndef __PROSPERO__
/* Teste dos parsers (so PC): imprime o arquivo de cheat lido em JSON. 0 = leu; 1 = arquivo com erro. */
int cheats_teste_arquivo(const char *caminho, const char *tid, const char *versao);
#endif
