/* Game Library Renamer (payload PS5) - configuracao do PrefBar pelo celular (0.9.22).

O PrefBar (X1NONs, GPL-3.0, https://github.com/X1NONs/PrefBar) le /data/prefbar/prefbar.conf: linhas "chave=valor",
comentarios com # ou ;, rotulos [secao] ignorados, valor fora da faixa = padrao do PrefBar, linha com mais de 255
caracteres = arquivo inteiro recusado. O formato e as faixas abaixo foram lidos no fonte da v0.3.0
(src/ps5/telemetry/prefbar_telemetry.c, config_apply_value) e no Docs/HOW_IT_WORKS.md; o codigo e proprio.
O PrefBar rele o arquivo quando um jogo novo abre (nao precisa reiniciar o PS5). */
#pragma once

#include "http.h"

/* Pasta do PrefBar: /data/prefbar no PS5; <pasta de dados>/prefbar no PC (testes). */
void prefbar_pasta(char *saida, size_t tam);
/* 1 = o PrefBar escreveu os arquivos de estado/log dele depois que o PS5 ligou (rodou nesta sessao, mesmo se foi
   enviado por outro programa). desde = hora em que o PS5 ligou. */
int prefbar_rodou_desde(long long desde);
/* GET /api/prefbar/conf: {"ok","existe","caminho","valores":{...},"padroes":{...},"invalidos":[...],"campos":[...]} */
void prefbar_rota_ler(pedido_t *p);
/* POST /api/prefbar/conf (chave=valor no corpo; pareamento + X-GLR ja conferidos pelo api.c). Valida tudo antes de
   gravar; grava de forma atomica (.tmp + fsync + rename), mantendo as outras linhas do arquivo. */
void prefbar_rota_gravar(pedido_t *p);
/* Para os testes e o diagnostico: valida um valor (1 = aceito pelo PrefBar). */
int prefbar_valor_ok(const char *chave, const char *valor);
