/* Game Library Renamer (payload PS5) - CoreDumps do CoreDump Dumper (0.9.59). Ver coredump.h. */
#include "coredump.h"

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "api.h"
#include "config.h"
#include "diagnostico.h"
#include "plataforma.h"
#include "sha256.h"

#define CD_PEDACO (4u * 1024 * 1024)                /* cada PUT: ate 4 MiB do arquivo (~5,4 MB em base64) */
#define CD_MAX_TOTAL (768ULL * 1024 * 1024)          /* por pasta */
#define CD_MAX_ARQ 64
#define CD_MAX_LISTA 30
#define CD_TENTATIVAS 3

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static struct {
  int rodando;
  char estado[12];        /* idle, running, done, failed */
  char nome[96];          /* pasta do CoreDump Dumper */
  char destino[160];      /* coredump/<nome>_<hora> no repositorio */
  char arquivo[96];       /* o que esta subindo agora */
  char erro[16];
  int http;
  unsigned long long enviados, total;
  long long em;
} g_e = {0, "idle", "", "", "", "", 0, 0, 0, 0};

/* ------------------------------------------------------------------ caminhos e nomes */

static const char *raiz(void) {
#ifndef __PROSPERO__
  const char *e = getenv("GLR_TESTE_COREDUMPS");
  if(e && *e) return e;
#endif
  return "/data/ps5-coredump-dumper";
}

static void arquivo_enviados(char *s, size_t tam) { snprintf(s, tam, "%s/coredump-enviados.txt", g_pasta_dados); }

/* nome de pasta ou arquivo do CoreDump Dumper: letras, digitos, . _ -; sem comecar com ponto */
static int nome_ok(const char *n) {
  size_t k = strlen(n);
  return k && k < 90 && n[0] != '.' &&
         strspn(n, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._-") == k;
}

/* "PPSA01552_1794577085": titulo (antes do ultimo _) e hora (depois) */
static void separar(const char *nome, char *titulo, size_t tam, long long *hora) {
  const char *u = strrchr(nome, '_');
  *hora = 0;
  if(u && u[1] && strspn(u + 1, "0123456789") == strlen(u + 1)) *hora = atoll(u + 1);
  size_t k = u ? (size_t)(u - nome) : strlen(nome);
  if(k >= tam) k = tam - 1;
  memcpy(titulo, nome, k);
  titulo[k] = 0;
}

typedef struct {
  char nome[96];
  unsigned long long bytes;
} arq_t;

/* Os arquivos comuns da pasta (sem subpastas nem links). -1 se a pasta nao existe; -2 se tem algo estranho. */
static int ler_pasta(const char *nome, arq_t *a, int max, unsigned long long *total, int *pronto) {
  char d[700];
  snprintf(d, sizeof d, "%s/%s", raiz(), nome);
  DIR *dir = opendir(d);
  if(!dir) return -1;
  int n = 0, estranho = 0;
  *total = 0;
  if(pronto) *pronto = 0;
  struct dirent *e;
  while((e = readdir(dir))) {
    if(!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
    char c[800];
    struct stat st;
    snprintf(c, sizeof c, "%s/%s", d, e->d_name);
    if(lstat(c, &st) || !S_ISREG(st.st_mode) || !nome_ok(e->d_name) || n >= max) {
      estranho = 1;
      continue;
    }
    if(pronto && !strcmp(e->d_name, "_manifest.txt")) *pronto = 1;
    snprintf(a[n].nome, sizeof a[n].nome, "%s", e->d_name);
    a[n].bytes = (unsigned long long)st.st_size;
    *total += a[n].bytes;
    n++;
  }
  closedir(dir);
  return estranho ? -2 : n;
}

/* "coredump/..." do envio anterior desta pasta (registro do glibren), ou "" */
static void ja_enviado(const char *nome, char *destino, size_t tam) {
  destino[0] = 0;
  char c[600], linha[400];
  arquivo_enviados(c, sizeof c);
  FILE *f = fopen(c, "r");
  if(!f) return;
  size_t k = strlen(nome);
  while(fgets(linha, sizeof linha, f)) {
    linha[strcspn(linha, "\r\n")] = 0;
    if(!strncmp(linha, nome, k) && linha[k] == ' ') snprintf(destino, tam, "%s", linha + k + 1);   /* o ultimo vale */
  }
  fclose(f);
}

static void anotar_enviado(const char *nome, const char *destino) {
  char c[600];
  arquivo_enviados(c, sizeof c);
  FILE *f = fopen(c, "a");
  if(!f) return;
  fprintf(f, "%s %s\n", nome, destino);
  fclose(f);
}

/* ------------------------------------------------------------------ lista */

typedef struct {
  char nome[96];
  long long hora;
} dump_t;

static int mais_novo(const void *a, const void *b) {
  const dump_t *x = a, *y = b;
  if(x->hora != y->hora) return x->hora < y->hora ? 1 : -1;
  return strcmp(x->nome, y->nome);
}

void coredump_json(buf_t *b) {
  dump_t v[CD_MAX_LISTA * 4];
  int n = 0;
  DIR *dir = opendir(raiz());
  struct dirent *e;
  while(dir && (e = readdir(dir)) && n < (int)(sizeof v / sizeof v[0])) {
    char c[700], titulo[64];
    struct stat st;
    if(!nome_ok(e->d_name)) continue;
    snprintf(c, sizeof c, "%s/%s", raiz(), e->d_name);
    if(lstat(c, &st) || !S_ISDIR(st.st_mode)) continue;
    snprintf(v[n].nome, sizeof v[n].nome, "%s", e->d_name);
    separar(e->d_name, titulo, sizeof titulo, &v[n].hora);
    n++;
  }
  if(dir) closedir(dir);
  qsort(v, (size_t)n, sizeof v[0], mais_novo);
  if(n > CD_MAX_LISTA) n = CD_MAX_LISTA;
  buf_str(b, "{\"ok\":true,\"pasta\":");
  buf_json(b, raiz());
  buf_fmt(b, ",\"rodando\":%s,\"limite\":%llu,\"dumps\":[", plataforma_processo_rodando(COREDUMP_PROCESSO) ? "true" : "false",
          CD_MAX_TOTAL);
  for(int i = 0; i < n; i++) {
    arq_t a[CD_MAX_ARQ];
    unsigned long long total = 0;
    int pronto = 0, k = ler_pasta(v[i].nome, a, CD_MAX_ARQ, &total, &pronto);
    char titulo[64], destino[200];
    long long hora;
    separar(v[i].nome, titulo, sizeof titulo, &hora);
    ja_enviado(v[i].nome, destino, sizeof destino);
    buf_str(b, i ? ",{\"nome\":" : "{\"nome\":");
    buf_json(b, v[i].nome);
    buf_str(b, ",\"titulo\":");
    buf_json(b, titulo);
    buf_fmt(b, ",\"hora\":%lld,\"arquivos\":%d,\"bytes\":%llu,\"pronto\":%s,\"estranho\":%s,\"enviado\":", hora, k < 0 ? 0 : k,
            total, pronto ? "true" : "false", k == -2 ? "true" : "false");
    if(destino[0]) buf_json(b, destino);
    else buf_str(b, "null");
    buf_str(b, "}");
  }
  pthread_mutex_lock(&g_trava);
  buf_fmt(b, "],\"envio\":{\"estado\":\"%s\",\"nome\":", g_e.estado);
  buf_json(b, g_e.nome);
  buf_str(b, ",\"destino\":");
  buf_json(b, g_e.destino);
  buf_str(b, ",\"arquivo\":");
  buf_json(b, g_e.arquivo);
  buf_fmt(b, ",\"erro\":\"%s\",\"http\":%d,\"enviados\":%llu,\"total\":%llu,\"em\":%lld}}", g_e.erro, g_e.http, g_e.enviados,
          g_e.total, g_e.em);
  pthread_mutex_unlock(&g_trava);
}

void coredump_rota_estado(pedido_t *p) {
  buf_t b = {0};
  coredump_json(&b);
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* ------------------------------------------------------------------ envio */

static void terminar(const char *estado, const char *erro, int http) {
  pthread_mutex_lock(&g_trava);
  snprintf(g_e.estado, sizeof g_e.estado, "%s", estado);
  snprintf(g_e.erro, sizeof g_e.erro, "%s", erro);
  g_e.arquivo[0] = 0;
  g_e.http = http;
  g_e.rodando = 0;
  g_e.em = (long long)time(NULL);
  pthread_mutex_unlock(&g_trava);
}

static int subir(const char *chave, const char *caminho, const char *msg, const void *d, size_t n, int *retentativas) {
  int st = 0;
  for(int t = 1; t <= CD_TENTATIVAS; t++) {
    st = diagnostico_github_arquivo(chave, caminho, msg, d, n);
    if(st == 200 || st == 201 || !diagnostico_vale_repetir(st) || t == CD_TENTATIVAS) break;
    (*retentativas)++;
    sleep((unsigned)t * 2);
  }
  return st;
}

static const char *erro_de(int st) {
  return st == -1 ? "network" : st == 401 ? "unauthorized" : st == 403 ? "forbidden" : st == 404 ? "no-repo" :
         st == -2 ? "read" : "http";
}

static void *envio(void *arg) {
  (void)arg;
  char nome[96], destino[160];
  pthread_mutex_lock(&g_trava);
  snprintf(nome, sizeof nome, "%s", g_e.nome);
  snprintf(destino, sizeof destino, "%s", g_e.destino);
  pthread_mutex_unlock(&g_trava);
  char chave[256];
  if(!diagnostico_chave_ler(chave, sizeof chave)) {
    terminar("failed", "no-key", 0);
    return NULL;
  }
  arq_t *a = calloc(CD_MAX_ARQ, sizeof *a);
  unsigned char *pedaco = malloc(CD_PEDACO);
  buf_t indice = {0};
  int st = 0, retentativas = 0, n = 0;
  unsigned long long total = 0;
  if(!a || !pedaco || (n = ler_pasta(nome, a, CD_MAX_ARQ, &total, NULL)) < 0) {
    st = -2;
    goto fim;
  }
  pthread_mutex_lock(&g_trava);
  g_e.total = total;
  pthread_mutex_unlock(&g_trava);
  char msg[160];
  snprintf(msg, sizeof msg, "coredump %s (glibren %s)", nome, VERSAO);
  buf_fmt(&indice, "# CoreDump %s enviado pelo glibren %s em %s\n# arquivo bytes sha256 partes (partes > 0: <arquivo>.parte001...)\n",
          nome, VERSAO, destino);
  for(int i = 0; i < n && st >= 0; i++) {
    char c[800];
    snprintf(c, sizeof c, "%s/%s/%s", raiz(), nome, a[i].nome);
    int fd = open(c, O_RDONLY);
    if(fd < 0) {
      st = -2;
      break;
    }
    pthread_mutex_lock(&g_trava);
    snprintf(g_e.arquivo, sizeof g_e.arquivo, "%s", a[i].nome);
    pthread_mutex_unlock(&g_trava);
    int partes = a[i].bytes > CD_PEDACO ? (int)((a[i].bytes + CD_PEDACO - 1) / CD_PEDACO) : 0;
    sha256_t h;
    sha256_iniciar(&h);
    unsigned long long lidos = 0;
    for(int parte = 1;; parte++) {
      size_t k = 0;
      while(k < CD_PEDACO) {
        ssize_t r = read(fd, pedaco + k, CD_PEDACO - k);
        if(r < 0 && errno == EINTR) continue;
        if(r <= 0) break;
        k += (size_t)r;
      }
      lidos += k;
      if(!k && parte > 1) break;   /* acabou certinho no fim do pedaco anterior */
      sha256_atualizar(&h, pedaco, k);
      char caminho[400];
      if(partes) snprintf(caminho, sizeof caminho, "%s/%s.parte%03d", destino, a[i].nome, parte);
      else snprintf(caminho, sizeof caminho, "%s/%s", destino, a[i].nome);
      int s = subir(chave, caminho, msg, pedaco, k, &retentativas);
      if(s != 200 && s != 201) {
        st = s > 0 ? s : -1;
        break;
      }
      pthread_mutex_lock(&g_trava);
      g_e.enviados += k;
      pthread_mutex_unlock(&g_trava);
      if(k < CD_PEDACO || !partes) break;
    }
    close(fd);
    if(st < 0 || st > 201) break;
    if(lidos != a[i].bytes) {   /* o arquivo mudou durante o envio (o Dumper ainda copiando?) */
      st = -2;
      break;
    }
    uint8_t r[32];
    char hex[65];
    sha256_final(&h, r);
    sha256_hex(r, hex);
    buf_fmt(&indice, "%s %llu %s %d\n", a[i].nome, a[i].bytes, hex, partes);
  }
  if(st == 0 || st == 200 || st == 201) {
    char caminho[400];
    snprintf(caminho, sizeof caminho, "%s/_glibren.txt", destino);
    int s = subir(chave, caminho, msg, indice.d ? indice.d : "", indice.n, &retentativas);
    st = s == 200 || s == 201 ? 201 : s > 0 ? s : -1;
  }
fim:
  memset(chave, 0, sizeof chave);
  free(a);
  free(pedaco);
  buf_free(&indice);
  if(retentativas) diario("coredump: %d nova(s) tentativa(s) de envio", retentativas);
  if(st == 201) {
    anotar_enviado(nome, destino);
    terminar("done", "", 201);
    diario("coredump: %s enviado (%llu bytes, %d arquivo(s)) para ps5-diagnosticos/%s", nome, total, n, destino);
  } else {
    terminar("failed", erro_de(st), st > 0 ? st : 0);
    diario("coredump: %s falhou (%s, HTTP %d)", nome, erro_de(st), st > 0 ? st : 0);
  }
  return NULL;
}

/* nome= do pedido, conferido; 0 = ok (ja respondeu o erro se nao) */
static int pedir_nome(pedido_t *p, char *nome, size_t tam) {
  nome[0] = 0;
  param(p->corpo, "nome", 0, nome, tam);
  if(!nome_ok(nome)) {
    responder_erro(p, 400, "cd_nome", "nome de pasta invalido", NULL);
    return -1;
  }
  char c[700];
  struct stat st;
  snprintf(c, sizeof c, "%s/%s", raiz(), nome);
  if(lstat(c, &st) || !S_ISDIR(st.st_mode)) {
    responder_erro(p, 404, "cd_nao_achou", "pasta nao encontrada", NULL);
    return -1;
  }
  return 0;
}

void coredump_rota_enviar(pedido_t *p) {
  char nome[96];
  if(pedir_nome(p, nome, sizeof nome)) return;
  char k[256];
  int tem = diagnostico_chave_ler(k, sizeof k);
  memset(k, 0, sizeof k);
  if(!tem) {
    responder_erro(p, 400, "cd_sem_chave", "falta a chave do GitHub (pagina Diagnostico)", NULL);
    return;
  }
  arq_t a[CD_MAX_ARQ];
  unsigned long long total = 0;
  int pronto = 0, n = ler_pasta(nome, a, CD_MAX_ARQ, &total, &pronto);
  if(n == -2) {
    responder_erro(p, 409, "cd_incompleto", "a pasta tem subpastas, links ou nomes estranhos", NULL);
    return;
  }
  if(n <= 0 || !pronto) {
    responder_erro(p, 409, "cd_incompleto", "o CoreDump Dumper ainda nao terminou de copiar (falta o _manifest.txt)", NULL);
    return;
  }
  if(total > CD_MAX_TOTAL) {
    responder_erro(p, 413, "cd_grande", "grande demais para mandar pelo PS5: copie pelo FTP", NULL);
    return;
  }
  time_t agora = time(NULL);
  struct tm t;
  char hora[24] = "sem-data";
  localtime_r(&agora, &t);
  strftime(hora, sizeof hora, "%Y%m%d-%H%M%S", &t);
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_DIAG_PASTA")) snprintf(hora, sizeof hora, "teste");
#endif
  pthread_mutex_lock(&g_trava);
  if(g_e.rodando) {
    pthread_mutex_unlock(&g_trava);
    responder_erro(p, 409, "cd_ocupado", "ja ha um envio em andamento", NULL);
    return;
  }
  g_e.rodando = 1;
  snprintf(g_e.estado, sizeof g_e.estado, "running");
  snprintf(g_e.nome, sizeof g_e.nome, "%s", nome);
  snprintf(g_e.destino, sizeof g_e.destino, "coredump/%s_%s", nome, hora);
  g_e.arquivo[0] = g_e.erro[0] = 0;
  g_e.http = 0;
  g_e.enviados = 0;
  g_e.total = total;
  g_e.em = (long long)agora;
  pthread_mutex_unlock(&g_trava);
  diario("coredump: envio pedido de %s (%llu bytes, %d arquivo(s))", nome, total, n);
  if(criar_thread(envio, NULL, NULL)) {
    terminar("failed", "thread", 0);
    responder_erro(p, 500, "cd_thread", "nao deu para comecar", NULL);
    return;
  }
  coredump_rota_estado(p);
}

void coredump_rota_apagar(pedido_t *p) {
  char nome[96];
  if(pedir_nome(p, nome, sizeof nome)) return;
  pthread_mutex_lock(&g_trava);
  int ocupado = g_e.rodando && !strcmp(g_e.nome, nome);
  pthread_mutex_unlock(&g_trava);
  if(ocupado) {
    responder_erro(p, 409, "cd_ocupado", "essa pasta esta sendo enviada", NULL);
    return;
  }
  arq_t a[CD_MAX_ARQ];
  unsigned long long total = 0;
  if(ler_pasta(nome, a, CD_MAX_ARQ, &total, NULL) == -2) {   /* subpasta, link ou nome estranho: nao apaga nada */
    responder_erro(p, 409, "cd_incompleto", "a pasta tem subpastas, links ou nomes estranhos: apague pelo FTP", NULL);
    return;
  }
  char d[700];
  snprintf(d, sizeof d, "%s/%s", raiz(), nome);
  DIR *dir = opendir(d);
  int erro = 0;
  struct dirent *e;
  while(dir && (e = readdir(dir))) {
    if(!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
    char c[800];
    struct stat st;
    snprintf(c, sizeof c, "%s/%s", d, e->d_name);
    if(lstat(c, &st) || !S_ISREG(st.st_mode) || unlink(c)) erro = errno ? errno : EPERM;
  }
  if(dir) closedir(dir);
  if(!erro && rmdir(d)) erro = errno;
  if(erro) {
    diario("coredump: apagar %s: %s", nome, strerror(erro));
    responder_erro(p, 500, "cd_apagar", strerror(erro), NULL);
    return;
  }
  diario("coredump: %s apagado", nome);
  coredump_rota_estado(p);
}
