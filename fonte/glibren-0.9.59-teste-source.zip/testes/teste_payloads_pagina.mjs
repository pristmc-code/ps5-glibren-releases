// 0.9.33/0.9.34/0.9.35: pagina Payloads - itens acompanhados pelo GitHub (instalada x disponivel, experimental, voltar), "rodando
// agora" e o cartao do ShadowMount+/Procurar atualizacoes, em 360 e 1280 px: sem rolar de lado, botoes da mesma linha
// com a mesma largura, nenhum texto cortado. Roda no Node do Windows com o Playwright do cache do npx, chamado pelo
// testes/teste_payloads_gh.sh com o glibren-pc e os servicos falsos no ar.
//   node teste_payloads_pagina.mjs http://127.0.0.1:8931 <pasta do pacote playwright> [limite]
// 0.9.39: "limite" = glibren no limite proprio de consultas ao GitHub (dump-forge com a resposta boa guardada, kraken-mount
// sem nada guardado): linha "No GitHub" + "Dados de HH:MM; limite..." ou o motivo no lugar do botao.
// 0.9.43: "titan" = TITAN CORE no ar (porta 8097): aviso no cartao de cima; [pasta] = onde salvar a imagem de cada tela.
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const [base, pw, modo, fotos] = process.argv.slice(2);
const { chromium } = await import(pathToFileURL(path.join(pw, 'index.mjs')).href);
let ok = 0, falhas = 0;
const confere = (nome, cond, info = '') => { if (cond) { ok++; console.log('OK   ' + nome); } else { falhas++; console.log('FALHA ' + nome + (info ? ': ' + info : '')); } };

let navegador;
for (const channel of ['msedge', 'chrome']) { try { navegador = await chromium.launch({ channel }); break; } catch { /* outro */ } }
if (!navegador) { console.log('FALHA nenhum navegador abriu'); console.log('=== pagina 0 ok, 1 falhas'); process.exit(1); }

// botoes da mesma linha com a mesma largura, nada cortado (nem reticencias), sem rolar de lado
const medir = pagina => pagina.evaluate(() => {
  const larguras = [...document.querySelectorAll('.botoes')].filter(b => b.offsetParent).map(b =>
    [...b.querySelectorAll('button')].filter(x => x.offsetParent).map(x => Math.round(x.getBoundingClientRect().width)));
  const cortados = [...document.querySelectorAll('button, .versoes, .agora, .linha, h2, a.gh-pag')].filter(e => e.offsetParent &&
    (getComputedStyle(e).textOverflow === 'ellipsis' || e.scrollWidth > e.clientWidth + 1)).map(e => e.className + ':' + e.textContent.slice(0, 30));
  return { larguras, cortados, rola: document.scrollingElement.scrollWidth > innerWidth };
});
const conferirMedidas = (n, medidas) => {
  confere(n('sem rolar de lado'), !medidas.rola);
  confere(n('botoes da mesma linha: mesma largura'), medidas.larguras.every(l => l.every(x => Math.abs(x - l[0]) <= 1)), JSON.stringify(medidas.larguras));
  confere(n('nenhum texto cortado'), medidas.cortados.length === 0, medidas.cortados.join(' | '));
};

for (const tela of [{ w: 360, h: 780, nome: 'celular' }, { w: 1280, h: 800, nome: 'PC' }]) {
  const pagina = await navegador.newPage({ viewport: { width: tela.w, height: tela.h } });
  const n = s => `${s} (${tela.nome})`;
  if (modo === 'titan') {
    await pagina.goto(base + '/payloads');
    await pagina.waitForFunction(() => !document.getElementById('ghTitan').hidden, null, { timeout: 30000 }).catch(() => {});
    const av = await pagina.$eval('#ghTitan', e => e.hidden ? '' : e.textContent).catch(() => '');
    confere(n('titan: aviso visivel'), /^⚠ TITAN CORE rodando agora \(v1\.0\.0\)\. Ele já carrega o kstuff e o ShadowMount\+ dele/.test(av), av);
    confere(n('titan: diz como resolver'), av.includes('tire o TITAN do carregamento automático e reinicie o PS5'), av);
    confere(n('titan: kraken-mount nao rodando'), !/Rodando agora/.test(await pagina.$eval('.item[data-id="kraken-mount"] .agora', e => e.textContent).catch(() => '')));
    const m = await medir(pagina);
    const caixa = await pagina.$eval('#ghTitan', e => { const r = e.getBoundingClientRect(); return { cabe: r.right <= innerWidth && r.left >= 0, corta: e.scrollWidth > e.clientWidth + 1 }; });
    confere(n('titan: aviso cabe na tela'), caixa.cabe && !caixa.corta, JSON.stringify(caixa));
    conferirMedidas(n, m);
    if (fotos) await pagina.screenshot({ path: path.join(fotos, `titan-${tela.w}.png`) });
    await pagina.close();
    continue;
  }
  if (modo === 'limite') {
    await pagina.goto(base + '/payloads');
    const df = '.item[data-id="dump-forge"]', kr = '.item[data-id="kraken-mount"]';
    await pagina.waitForFunction(() => /Dados de/.test(document.querySelector('.item[data-id="dump-forge"] .gh-erro')?.textContent || '') &&
      /Limite/.test(document.querySelector('.item[data-id="kraken-mount"] .b-baixar')?.textContent || ''), null, { timeout: 30000 }).catch(() => {});
    const txt = sel => pagina.$eval(sel, e => e.textContent).catch(() => '');
    const dfe = await txt(df + ' .gh-erro'), kre = await txt(kr + ' .gh-erro'), krb = await txt(kr + ' .b-baixar');
    confere(n('limite: dump-forge com No GitHub'), /No GitHub: v0\.5\.7/.test(await txt(df + ' .versoes')), await txt(df + ' .versoes'));
    confere(n('limite: dump-forge Atualizar (guardado)'), (await txt(df + ' .b-baixar')).includes('Atualizar para v0.5.7') && !(await pagina.isDisabled(df + ' .b-baixar')), await txt(df + ' .b-baixar'));
    confere(n('limite: dump-forge "Dados de HH:MM"'), /^Dados de \d\d:\d\d; limite de consultas ao GitHub, tente de novo em \d+ min\.$/.test(dfe) && await pagina.isVisible(df + ' .gh-erro'), dfe);
    confere(n('limite: kraken sem No GitHub'), !/No GitHub/.test(await txt(kr + ' .versoes')), await txt(kr + ' .versoes'));
    confere(n('limite: kraken motivo no lugar do botao'), /^⏳ Limite do GitHub: \d+ min$/.test(krb) && await pagina.isDisabled(kr + ' .b-baixar'), krb);
    confere(n('limite: kraken nota'), /^Limite de consultas ao GitHub: tente de novo em \d+ min\.$/.test(kre) && await pagina.isVisible(kr + ' .gh-erro'), kre);
    confere(n('limite: sem reticencias'), !/…|\.\.\./.test(dfe + kre + krb));
    conferirMedidas(n, await medir(pagina));
    await pagina.close();
    continue;
  }
  await pagina.goto(base + '/payloads');
  await pagina.waitForFunction(() => document.querySelectorAll('#lista .item').length === 10 &&
    /v0\.5\.7/.test(document.querySelector('.item[data-id="dump-forge"] .versoes')?.textContent || ''), null, { timeout: 30000 });
  const txt = sel => pagina.$eval(sel, e => e.textContent).catch(() => '');
  const df = '.item[data-id="dump-forge"]', kr = '.item[data-id="kraken-mount"]', sk = '.item[data-id="shadowkraken"]';
  confere(n('dump-forge: instalada x GitHub'), /Instalada: v0\.5\.6/.test(await txt(df + ' .versoes')) && /No GitHub: v0\.5\.7/.test(await txt(df + ' .versoes')), await txt(df + ' .versoes'));
  confere(n('dump-forge: botao Atualizar'), (await txt(df + ' .b-baixar')).includes('Atualizar para v0.5.7'), await txt(df + ' .b-baixar'));
  confere(n('dump-forge: voltar para v0.5.7'), (await txt(df + ' .b-voltar')).includes('Voltar para v0.5.7') && await pagina.isVisible(df + ' .b-voltar'));
  confere(n('dump-forge: rodando agora'), (await txt(df + ' .agora')).includes('Rodando agora (v0.5.6)'), await txt(df + ' .agora'));
  confere(n('shadowkraken: experimental'), await pagina.isVisible(sk + ' .exp'));
  // 0.9.46: ShadowKraken primeiro da lista, com borda e selo "Montador de jogos"
  confere(n('shadowkraken: primeiro da lista'), await pagina.$eval('#lista .item', e => e.dataset.id) === 'shadowkraken');
  confere(n('shadowkraken: destaque e selo'), await pagina.$eval(sk, e => e.classList.contains('destaque')) &&
    (await txt(sk + ' .selo-montador')).includes('Montador de jogos'), await txt(sk + ' h2'));
  // 0.9.34: ShadowKraken removido do GitHub (guardado: fica para Ativar/Remover) e kraken-mount com 404
  confere(n('shadowkraken: sem atualizacoes'), (await txt(sk + ' .b-baixar')).includes('Sem atualizações'), await txt(sk + ' .b-baixar'));
  confere(n('shadowkraken: nota removido'), (await txt(sk + ' .gh-erro')).includes('Repositório removido do GitHub em 17/11/2026; sem atualizações.'), await txt(sk + ' .gh-erro'));
  confere(n('shadowkraken: Remover'), await pagina.isVisible(sk + ' .b-remover') && (await txt(sk + ' .b-remover')).includes('Remover do glibren'));
  confere(n('shadowkraken: Ativar'), await pagina.isVisible(sk + ' .b-ativar'));
  confere(n('kraken: repositorio indisponivel'), (await txt(kr + ' .gh-erro')).includes('Repositório indisponível no GitHub'), await txt(kr + ' .gh-erro'));
  confere(n('BlueV: rodando agora'), (await txt('.item[data-id="bluev"] .agora')).includes('Rodando agora'), await txt('.item[data-id="bluev"] .agora'));
  confere(n('kraken: sem Remover'), !(await pagina.isVisible(kr + ' .b-remover')));
  // 0.9.35: ZhiThemes (so pre-release, rodando pela /version com a versao) e atalho para o GitHub em cada item
  const zt = '.item[data-id="zhithemes"]';
  confere(n('ZhiThemes: rodando agora com versao'), (await txt(zt + ' .agora')).includes('Rodando agora (v0.1.0-alpha)'), await txt(zt + ' .agora'));
  confere(n('ZhiThemes: experimental'), await pagina.isVisible(zt + ' .exp'));
  const links = await pagina.$$eval('#lista .item', cs => cs.map(c => { const a = c.querySelector('a.gh-pag');
    return { id: c.dataset.id, href: a ? a.href : '', alvo: a ? a.target : '', rel: a ? a.rel : '', vis: !!(a && a.offsetParent) }; }));
  const semSk = links.filter(l => l.id !== 'shadowkraken' && l.id !== 'kstuff');   // 0.9.41: kstuff (arquivo seu) nao tem repositorio
  confere(n('GitHub: link em cada item'), semSk.length === 8 && semSk.every(l => l.vis && /^https:\/\/github\.com\/[^/]+\/[^/]+$/.test(l.href) && l.alvo === '_blank' && /noopener/.test(l.rel)), JSON.stringify(links));
  confere(n('GitHub: ZhiThemes aponta para o repo'), links.find(l => l.id === 'zhithemes')?.href === 'https://github.com/itsRealZhi/ZhiThemes');
  // 0.9.40: MemDBG rodando agora com a versao e o nivel do protocolo (HELLO)
  const md = '.item[data-id="memdbg"]';
  confere(n('MemDBG: rodando com versao e nivel'), (await txt(md + ' .agora')).includes('Rodando agora (v0.2.0-nightly.321.g6e31144, protocolo nível 4)'), await txt(md + ' .agora'));
  confere(n('MemDBG: aviso das portas'), /9020/.test(await txt(md)) && /744/.test(await txt(md)), (await txt(md)).slice(0, 300));
  confere(n('GitHub: removido sem link'), !links.find(l => l.id === 'shadowkraken')?.href);
  confere(n('kstuff (arquivo seu): sem link'), !links.find(l => l.id === 'kstuff')?.href);
  confere(n('kraken: esperando o SMP'), /Rodando agora \(v0\.2\.1\) \(esperando ShadowMount\+ parar\)/.test(await txt(kr + ' .agora')), await txt(kr + ' .agora'));
  confere(n('kraken: nao carregado some'), !(await txt('.item[data-id="prefbar"] .agora')).includes('Rodando'));
  confere(n('cartao: ShadowMount+ rodando'), (await txt('#ghSmp')).includes('ShadowMount+ rodando agora (v1.7beta12)'), await txt('#ghSmp'));
  // 0.9.51: build de teste do ampr-emu-ng no cartao do ShadowKraken (guardado aqui): o embutido em uso, os 3 botoes
  await pagina.waitForFunction(() => /Em uso/.test(document.querySelector('.item[data-id="shadowkraken"] .ampr-uso')?.textContent || ''), null, { timeout: 15000 }).catch(() => {});
  confere(n('ampr: secao visivel'), await pagina.isVisible(sk + ' .ampr'));
  confere(n('ampr: em uso o embutido'), (await txt(sk + ' .ampr-uso')).includes('Em uso: o embutido no ShadowKraken'), await txt(sk + ' .ampr-uso'));
  confere(n('ampr: sem traces'), (await txt(sk + ' .ampr-traces')).includes('nenhum guardado ainda'), await txt(sk + ' .ampr-traces'));
  confere(n('ampr: botoes'), await pagina.isVisible(sk + ' .b-ampr-enviar') && await pagina.isVisible(sk + ' .b-ampr-escolher') && await pagina.isVisible(sk + ' .b-ampr-voltar'));
  confere(n('ampr: voltar desligado sem teste'), await pagina.$eval(sk + ' .b-ampr-voltar', e => e.disabled));
  confere(n('ampr: kraken sem a secao'), !(await pagina.$(kr + ' .ampr')));
  confere(n('cartao: botao Procurar'), (await txt('#ghProcurar')).includes('Procurar atualizações') || (await txt('#ghProcurar')).includes('Procurando'), await txt('#ghProcurar'));
  conferirMedidas(n, await medir(pagina));
  await pagina.close();
  // 0.9.55: nome do arquivo escolhido em destaque (guardado; ou reconhecido pelo SHA-256; ou desconhecido), detalhe menor
  // embaixo; nomes longos quebram sem cortar. /api/ampr respondido aqui (o glibren-pc deste teste nao tem build de teste).
  const pa = await navegador.newPage({ viewport: { width: tela.w, height: tela.h } });
  const rt = (o) => ({ valido: true, caminho: '/data/shadowmount/emus/ampr-emu-ng/libSceAmpr.sprx', versao: '0.5.0', commit: '', depuracao: false, tamanho: 1048576, desde: 1795000000, sha256: '0696660c6c4eb267615ebe7f78677319fd8decaa768e33d98da75bbd9b84506f', nome: '', origem: '', instalado: 0, conhecido: null, ...o });
  let estadoAmpr = {
    ok: true, pasta_emus: '/data/shadowmount/emus', traces: 0, ultimo_trace: null,
    teste: rt({ nome: 'ampr-emu-ng-pr113+pr115-a44b4d2-debug-com-um-nome-bem-comprido-para-quebrar.sprx', origem: '/mnt/usb0/ampr/builds-de-teste/pr113+pr115/ampr-emu-ng-pr113+pr115-a44b4d2-debug-com-um-nome-bem-comprido-para-quebrar.sprx', instalado: 1795003000, commit: 'a44b4d2', depuracao: true }),
    anterior: rt({ caminho: '/data/shadowmount/emus/ampr-emu-ng/libSceAmpr.sprx.anterior', conhecido: { nome: 'ampr-emu-ng-pr115-f7a31de-release.sprx', corrige: 'hades' } }),
  };
  await pa.route('**/api/ampr', r => r.fulfill({ contentType: 'application/json', body: JSON.stringify(estadoAmpr) }));
  await pa.goto(base + '/payloads');
  await pa.waitForFunction(() => /a44b4d2/.test(document.querySelector('.item[data-id="shadowkraken"] .ampr-uso')?.textContent || ''), null, { timeout: 15000 }).catch(() => {});
  const uso = await pa.$$eval(sk + ' .ampr-uso span', l => l.map(e => e.textContent));
  confere(n('ampr 0.9.55: em uso = nome do arquivo'), uso[0] === 'Em uso: ampr-emu-ng-pr113+pr115-a44b4d2-debug-com-um-nome-bem-comprido-para-quebrar.sprx', JSON.stringify(uso));
  confere(n('ampr 0.9.55: detalhe do em uso'), /^ampr-emu-ng 0\.5\.0 · depuração · commit a44b4d2 · SHA-256 0696660c6c4e · desde .+ · veio de \/mnt\/usb0\//.test(uso[1] || ''), JSON.stringify(uso));
  const ant = await pa.$$eval(sk + ' .ampr-ant span', l => l.map(e => e.textContent));
  confere(n('ampr 0.9.55: anterior reconhecido pelo SHA'), ant[0] === 'Guardado para voltar: provavelmente ampr-emu-ng-pr115-f7a31de-release.sprx (pelo SHA-256)', JSON.stringify(ant));
  confere(n('ampr 0.9.55: o que corrige'), ant[1] === 'Corrige: Hades (#114)', JSON.stringify(ant));
  confere(n('ampr 0.9.55: detalhe menor'), await pa.$eval(sk + ' .ampr-uso .ampr-sub', e => parseFloat(getComputedStyle(e).fontSize)) < await pa.$eval(sk + ' .ampr-uso .ampr-nome', e => parseFloat(getComputedStyle(e).fontSize)));
  conferirMedidas(s => n('ampr 0.9.55: ' + s), await medir(pa));
  if (fotos) await pa.screenshot({ path: path.join(fotos, `ampr-nome-${tela.w}.png`), fullPage: true });
  // sem nome guardado e SHA desconhecido; enviado do celular/PC
  estadoAmpr = { ...estadoAmpr, teste: rt({ sha256: 'ab'.repeat(32) }), anterior: rt({ nome: 'ampr-emu-ng-pr113-5a8cca6-release.sprx', origem: '@celular', instalado: 1795001000, sha256: '0c0ac674522baafd87729ca8096102abccf9457c0d795a911d63a3232f351d28', conhecido: { nome: 'ampr-emu-ng-pr113-5a8cca6-release.sprx', corrige: 'marvel' } }) };
  await pa.reload();
  await pa.waitForFunction(() => /desconhecido/.test(document.querySelector('.item[data-id="shadowkraken"] .ampr-uso')?.textContent || ''), null, { timeout: 15000 }).catch(() => {});
  const uso2 = await pa.$$eval(sk + ' .ampr-uso span', l => l.map(e => e.textContent));
  confere(n('ampr 0.9.55: nome desconhecido'), uso2[0] === 'Em uso: nome desconhecido (instalado antes da 0.9.55 ou por FTP)' && uso2.length === 2 && !/veio de|enviado/.test(uso2[1]), JSON.stringify(uso2));
  const ant2 = await pa.$$eval(sk + ' .ampr-ant span', l => l.map(e => e.textContent));
  confere(n('ampr 0.9.55: anterior enviado do celular'), ant2[0] === 'Guardado para voltar: ampr-emu-ng-pr113-5a8cca6-release.sprx' && ant2[1] === 'Corrige: MARVEL Cosmic Invasion (#111)' && / · enviado do celular\/PC$/.test(ant2[2] || ''), JSON.stringify(ant2));
  conferirMedidas(s => n('ampr 0.9.55 (2): ' + s), await medir(pa));
  // 0.9.57: ampr-emu-ng no fakelib/ dos backports (nomes longos, os 4 estados, aviso do emus)
  const ng = { ng: true, versao: '0.5.0', commit: 'a44b4d2', depuracao: false, sha256: 'ac'.repeat(32), conhecido: 'ampr-emu-ng-pr113+pr115-a44b4d2-release.sprx' };
  const bkps = { ok: true, emus_ampr: true, listas: { ampr_add: ['PPSA13427', 'PPSA00001'], playgo_off: [] }, fonte: { teste: true, ...ng }, backports: [
    { caminho: '/data/homebrew/backports/PPSA13427-Horizon-Zero-Dawn-Remastered-backport-v1.02-com-um-nome-bem-comprido', pasta: 'PPSA13427-Horizon-Zero-Dawn-Remastered-backport-v1.02-com-um-nome-bem-comprido', titulo: 'PPSA13427', fakelib: true, ampr: null, nosso: false, original: false },
    { caminho: '/mnt/ext0/homebrew/backports/PPSA00001', pasta: 'PPSA00001', titulo: 'PPSA00001', fakelib: true, ampr: ng, nosso: true, original: true },
    { caminho: '/data/homebrew/backports/PPSA00002', pasta: 'PPSA00002', titulo: 'PPSA00002', fakelib: true, ampr: { ng: false }, nosso: false, original: false },
    { caminho: '/data/homebrew/backports/PPSA00003', pasta: 'PPSA00003', titulo: 'PPSA00003', fakelib: false, ampr: { ...ng, commit: '' }, nosso: false, original: false } ] };
  await pa.route('**/api/ampr/backports', r => r.fulfill({ contentType: 'application/json', body: JSON.stringify(bkps) }));
  await pa.reload();
  await pa.waitForFunction(() => document.querySelectorAll('.item[data-id="shadowkraken"] .bkp-lista .bkp-item').length === 4, null, { timeout: 15000 }).catch(() => {});
  const ptxt = sel => pa.$eval(sel, e => e.textContent).catch(() => '');
  const itens = await pa.$$eval(sk + ' .bkp-lista .bkp-item', l => l.map(e => [...e.querySelectorAll('span')].map(x => x.textContent).concat(e.querySelector('button')?.textContent || '')));
  confere(n('bkp 0.9.57: 4 backports'), itens.length === 4, JSON.stringify(itens));
  confere(n('bkp 0.9.57: sem ampr'), itens[0]?.[2] === 'Sem ampr-emu-ng: o jogo usa o AMPR do sistema' && itens[0]?.[3] === 'Pôr o ampr-emu-ng', JSON.stringify(itens[0]));
  confere(n('bkp 0.9.57: nosso com original'), itens[1]?.[2] === 'Com o ampr-emu-ng 0.5.0 a44b4d2 posto pelo glibren; o original está guardado' && itens[1]?.[3] === 'Tirar', JSON.stringify(itens[1]));
  confere(n('bkp 0.9.57: outro AMPR'), /não é o ampr-emu-ng/.test(itens[2]?.[2] || ''), JSON.stringify(itens[2]));
  confere(n('bkp 0.9.57: ng do backport'), itens[3]?.[2] === 'Já tem um ampr-emu-ng 0.5.0 (veio com o backport)', JSON.stringify(itens[3]));
  confere(n('bkp 0.9.57: fonte'), (await ptxt(sk + ' .bkp-fonte')) === 'Vai ser copiado: ampr-emu-ng-pr113+pr115-a44b4d2-release.sprx (o de teste, ampr-emu-ng 0.5.0 a44b4d2, release)', await ptxt(sk + ' .bkp-fonte'));
  confere(n('bkp 0.9.57: aviso do emus'), /libSceAmpr\.sprx solto/.test(await ptxt(sk + ' .bkp-emus')), await ptxt(sk + ' .bkp-emus'));
  // 0.9.58: listas por jogo do ShadowKraken
  const lst = await pa.$$eval(sk + ' .lst-bloco', l => l.map(b => [b.dataset.lista, [...b.querySelectorAll('.lst-itens .ampr-nome')].map(x => x.textContent).join(','), b.querySelector('.lst-itens').textContent, b.querySelector('[data-lst-por]')?.textContent || '']));
  confere(n('lst 0.9.58: ampr_add com 2'), lst[0]?.[0] === 'ampr_add' && lst[0]?.[1] === 'PPSA13427,PPSA00001' && lst[0]?.[3] === 'Adicionar', JSON.stringify(lst[0]));
  confere(n('lst 0.9.58: playgo_off vazia'), lst[1]?.[0] === 'playgo_off' && lst[1]?.[2] === 'Nenhum jogo na lista.', JSON.stringify(lst[1]));
  confere(n('lst 0.9.58: botoes Tirar'), (await pa.$$(sk + ' [data-lst-tirar]')).length === 2, '');
  conferirMedidas(s => n('bkp 0.9.57: ' + s), await medir(pa));
  if (fotos) await pa.screenshot({ path: path.join(fotos, `ampr-backports-${tela.w}.png`), fullPage: true });
  // 0.9.59: CoreDumps guardados no cartao do CoreDump Dumper (envio andando: botoes travados)
  const cdm = { ok: true, pasta: '/data/ps5-coredump-dumper', rodando: true, limite: 805306368, dumps: [
    { nome: 'PPSA01552_1794577085', titulo: 'PPSA01552', hora: 1794577085, arquivos: 9, bytes: 123456789, pronto: true, estranho: false, enviado: null },
    { nome: 'PPSA00001_1794500000-com-um-nome-bem-comprido-para-quebrar-a-linha', titulo: 'PPSA00001', hora: 1794500000, arquivos: 2, bytes: 1024, pronto: false, estranho: false, enviado: null },
    { nome: 'PPSA00002_1794400000', titulo: 'PPSA00002', hora: 1794400000, arquivos: 9, bytes: 5000000, pronto: true, estranho: false, enviado: 'coredump/PPSA00002_1794400000_20261122-101500' } ],
    envio: { estado: 'running', nome: 'PPSA01552_1794577085', destino: 'coredump/PPSA01552_1794577085_20261122-101500', arquivo: 'prosperocore-1794577085-0x00000068-eboot.bin.prosperodmp', erro: '', http: 0, enviados: 41943040, total: 123456789, em: 1794577200 } };
  await pa.route('**/api/coredump', r => r.fulfill({ contentType: 'application/json', body: JSON.stringify(cdm) }));
  await pa.reload();
  const cdSel = '.item[data-id="coredump"]';
  await pa.waitForFunction(s => document.querySelectorAll(s + ' .cd-item').length === 3, cdSel, { timeout: 15000 }).catch(() => {});
  const cds = await pa.$$eval(cdSel + ' .cd-item', l => l.map(e => [...e.querySelectorAll('.cd-nome, p')].map(x => x.textContent).concat([...e.querySelectorAll('button')].map(b => b.textContent + (b.disabled ? '#' : '')))));
  confere(n('cd 0.9.59: 3 dumps'), cds.length === 3, JSON.stringify(cds));
  confere(n('cd 0.9.59: linha do dump'), cds[0]?.[0] === 'PPSA01552_1794577085' && /^PPSA01552 · .+ · 9 arquivo\(s\) · 117[,.]7 MB$/.test(cds[0]?.[1] || ''), JSON.stringify(cds[0]));
  confere(n('cd 0.9.59: botoes travados no envio'), cds[0]?.includes('📤 Enviar ao Claude#') && cds[0]?.includes('🗑 Apagar#'), JSON.stringify(cds[0]));
  confere(n('cd 0.9.59: ainda copiando'), /ainda está copiando/.test(cds[1]?.join(' ') || ''), JSON.stringify(cds[1]));
  confere(n('cd 0.9.59: ja enviado'), cds[2]?.includes('Já enviado: ps5-diagnosticos/coredump/PPSA00002_1794400000_20261122-101500'), JSON.stringify(cds[2]));
  confere(n('cd 0.9.59: progresso'), /^Enviando PPSA01552_1794577085: 40 MB de 117[,.]7 MB \(33%\)\. Arquivo agora: prosperocore/.test(await ptxt(cdSel + ' .cd-envio')), await ptxt(cdSel + ' .cd-envio'));
  const larg = await pa.$$eval(cdSel + ' .cd-item:first-child .botoes button', l => l.map(b => Math.round(b.getBoundingClientRect().width)));
  confere(n('cd 0.9.59: botoes da mesma largura'), larg.length === 2 && Math.abs(larg[0] - larg[1]) <= 1, JSON.stringify(larg));
  conferirMedidas(s => n('cd 0.9.59: ' + s), await medir(pa));
  if (fotos) await pa.screenshot({ path: path.join(fotos, `coredump-${tela.w}.png`), fullPage: true });
  // terminou: botoes livres (o de "ainda copiando" continua sem Enviar)
  cdm.envio = { ...cdm.envio, estado: 'done', enviados: cdm.envio.total, arquivo: '' };
  await pa.reload();
  await pa.waitForFunction(s => /Enviado:/.test(document.querySelector(s + ' .cd-envio')?.textContent || ''), cdSel, { timeout: 15000 }).catch(() => {});
  confere(n('cd 0.9.59: enviado'), (await ptxt(cdSel + ' .cd-envio')) === 'Enviado: ps5-diagnosticos/coredump/PPSA01552_1794577085_20261122-101500. Avise o Claude.', await ptxt(cdSel + ' .cd-envio'));
  const liv = await pa.$$eval(cdSel + ' [data-cd-enviar]', l => l.map(b => b.disabled));
  confere(n('cd 0.9.59: enviar livre so nos prontos'), JSON.stringify(liv) === '[false,true,false]', JSON.stringify(liv));
  await pa.close();
}
await navegador.close();
console.log(`=== pagina ${ok} ok, ${falhas} falhas`);
process.exit(falhas ? 1 : 0);
