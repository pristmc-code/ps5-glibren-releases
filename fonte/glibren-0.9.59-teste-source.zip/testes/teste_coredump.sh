#!/bin/bash
# Testa os CoreDumps do CoreDump Dumper (0.9.59) na versao de PC: lista das pastas de /data/ps5-coredump-dumper
# (GLR_TESTE_COREDUMPS), envio ao GitHub falso (GLR_TESTE_GITHUB: guarda cada PUT decodificado), partes de 4 MiB
# remontadas e conferidas pelo SHA-256 do _glibren.txt, recusas (sem chave, pasta ainda copiando, estranha, grande,
# nome invalido, inexistente, uma por vez), erros do GitHub, pareamento e apagar.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_coredump.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8931; PORTA_GH=8932
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R="http://$IP:$PORTA"
T=/root/glr-coredump; DADOS=$T/dados; CD=$T/cd; GH=$T/gh
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$(echo "$2" | head -c 600)] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
codigo() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
lista() { curl -s "$L/api/coredump"; }
espera_fim() { for i in $(seq 1 200); do lista | grep -q '"estado":"running"' || return; sleep 0.25; done; }
rm -rf "$T"; mkdir -p "$DADOS" "$CD" "$GH/recebido" "$T/jobe"
printf 'language = pt-BR\nfolder = %s/\n' "$T" > "$DADOS/config.ini"
KJOBE="github_pat_11JOBE0000000000000000_abcdefghijklmnopqrstuvwxyz0123456789JOBEjobe1234"

# GitHub falso: cada PUT vira $GH/recebido/<caminho do repositorio> (binario decodificado); modo em $GH/modo
cat > "$T/gh.py" <<'EOF'
import base64, http.server, json, os, sys
pasta = sys.argv[2]
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_PUT(self):
        n = int(self.headers.get("Content-Length") or 0)
        corpo = self.rfile.read(n)
        modo = open(pasta + "/modo").read().strip()
        codigo = {"401": 401, "500": 500}.get(modo, 201)
        pre = "/repos/pristmc-code/ps5-diagnosticos/contents/"
        if codigo == 201 and self.path.startswith(pre):
            j = json.loads(corpo)
            destino = os.path.join(pasta, "recebido", self.path[len(pre):])
            os.makedirs(os.path.dirname(destino), exist_ok=True)
            open(destino, "wb").write(base64.b64decode(j["content"]))
            open(pasta + "/ordem", "a").write(self.path[len(pre):] + " " + (self.headers.get("Authorization") or "") + " " + j.get("message", "") + "\n")
        self.send_response(codigo); self.send_header("Content-Type", "application/json"); self.end_headers()
        self.wfile.write(b'{"content":{}}')
http.server.ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1])), H).serve_forever()
EOF
echo ok > "$GH/modo"
python3 -I "$T/gh.py" $PORTA_GH "$GH" > "$T/gh.log" 2>&1 &
PID_GH=$!

inicia() {
  GLR_TESTE_GITHUB="http://127.0.0.1:$PORTA_GH" GLR_TESTE_JOBE_TOKEN="$T/jobe/token" GLR_TESTE_COREDUMPS="$CD" \
  GLR_TESTE_DIAG_PASTA=1 GLR_TESTE_FW=12.00 "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
inicia

echo "--- lista"
confere "sem dumps"                         "$(lista)" '"dumps":\[\]'
confere "pasta e limite"                    "$(lista)" "\"pasta\":\"$CD\",\"rodando\":false,\"limite\":805306368"
D1=PPSA01552_1794577085; D2=PPSA00001_1794600000; D3=PPSA00002_1794500000
mkdir -p "$CD/$D1" "$CD/$D2" "$CD/$D3/sub"
DMP="prosperocore-1794577085-0x00000068-eboot.bin.prosperodmp"
head -c $((9 * 1024 * 1024 + 123)) /dev/urandom > "$CD/$D1/$DMP"          # 3 partes
head -c $((4 * 1024 * 1024)) /dev/urandom > "$CD/$D1/exato-4mib.webm"      # cabe num PUT so
head -c 50000 /dev/urandom > "$CD/$D1/crash-screenshot.jpg"
: > "$CD/$D1/vazio.json"
printf '{"titleId":"PPSA01552"}\n' > "$CD/$D1/coredump_info.json"
printf 'klog\n' > "$CD/$D1/_klog.txt"
printf 'manifest ok\n' > "$CD/$D1/_manifest.txt"
printf 'x' > "$CD/$D2/parcial.prosperodmp"                                   # sem _manifest.txt: ainda copiando
printf 'm\n' > "$CD/$D3/_manifest.txt"                                        # tem subpasta: estranha
printf 'lixo' > "$CD/dumper.log"                                              # arquivo solto na raiz: ignorado
E=$(lista)
confere "3 pastas, a mais nova primeiro"    "$E" "\"dumps\":\[{\"nome\":\"$D2\".*{\"nome\":\"$D1\".*{\"nome\":\"$D3\""
confere "titulo e hora"                     "$E" "\"nome\":\"$D1\",\"titulo\":\"PPSA01552\",\"hora\":1794577085,\"arquivos\":7,\"bytes\":$((9*1024*1024+123 + 4*1024*1024 + 50000 + 24 + 5 + 12)),\"pronto\":true,\"estranho\":false,\"enviado\":null"
confere "ainda copiando"                    "$E" "\"nome\":\"$D2\",.*\"pronto\":false"
confere "estranha"                          "$E" "\"nome\":\"$D3\",.*\"estranho\":true"
nao_tem "arquivo solto nao vira dump"       "$E" "dumper.log"
confere "envio parado"                      "$E" '"envio":{"estado":"idle"'

echo "--- recusas"
confere "sem X-GLR = 403"                   "$(codigo -d nome=$D1 $L/api/coredump/enviar)" "403"
confere "rede sem token = 401"              "$(codigo -H 'X-GLR: 1' -d nome=$D1 $R/api/coredump/enviar)" "401"
confere "apagar pela rede sem token = 401"  "$(codigo -H 'X-GLR: 1' -d nome=$D1 $R/api/coredump/apagar)" "401"
confere "nome invalido"                     "$(post --data-urlencode 'nome=../dados' $L/api/coredump/enviar)" '"chave":"cd_nome"'
confere "inexistente = 404"                 "$(codigo -H 'X-GLR: 1' -d nome=PPSA99999_1 $L/api/coredump/enviar)" "404"
confere "sem chave"                         "$(post -d nome=$D1 $L/api/coredump/enviar)" '"chave":"cd_sem_chave"'
printf '%s\n' "$KJOBE" > "$T/jobe/token"
confere "ainda copiando = 409"              "$(post -d nome=$D2 $L/api/coredump/enviar)" '"chave":"cd_incompleto"'
confere "estranha = 409"                    "$(post -d nome=$D3 $L/api/coredump/enviar)" '"chave":"cd_incompleto"'
confere "nada chegou ao GitHub"             "$(ls $GH/recebido | wc -l)" "^0$"

echo "--- envio"
confere "comecou"                           "$(post -d nome=$D1 $L/api/coredump/enviar)" "\"envio\":{\"estado\":\"running\",\"nome\":\"$D1\",\"destino\":\"coredump/${D1}_teste\""
confere "um por vez = 409"                  "$(post -d nome=$D1 $L/api/coredump/enviar)" '"chave":"cd_ocupado"'
confere "nao apaga durante o envio"         "$(post -d nome=$D1 $L/api/coredump/apagar)" '"chave":"cd_ocupado"'
espera_fim
E=$(lista)
confere "terminou"                          "$E" '"envio":{"estado":"done".*"erro":"","http":201'
confere "enviado = total"                   "$E" "\"enviados\":$((9*1024*1024+123 + 4*1024*1024 + 50000 + 24 + 5 + 12)),\"total\":$((9*1024*1024+123 + 4*1024*1024 + 50000 + 24 + 5 + 12))"
confere "lista marca enviado"               "$E" "\"nome\":\"$D1\",.*\"enviado\":\"coredump/${D1}_teste\""
P="$GH/recebido/coredump/${D1}_teste"
confere "partes do dump grande"             "$(ls $P | tr '\n' ' ')" "$DMP.parte001 $DMP.parte002 $DMP.parte003 "
confere "4 MiB exato num PUT so"            "$(ls $P | tr '\n' ' ')" " exato-4mib.webm "
confere "arquivo vazio tambem"              "$(ls $P | tr '\n' ' ')" " vazio.json "
confere "indice por ultimo"                 "$(tail -n1 $GH/ordem)" "coredump/${D1}_teste/_glibren.txt Bearer $KJOBE coredump $D1 (glibren"
cat "$P/$DMP".parte* > "$T/remontado"
confere "dump remontado igual"              "$(sha256sum < $T/remontado | cut -d' ' -f1)" "^$(sha256sum < $CD/$D1/$DMP | cut -d' ' -f1)$"
confere "indice: dump com 3 partes"         "$(cat $P/_glibren.txt)" "^$DMP $((9*1024*1024+123)) $(sha256sum < $CD/$D1/$DMP | cut -d' ' -f1) 3$"
confere "indice: inteiro com 0 partes"      "$(cat $P/_glibren.txt)" "^exato-4mib.webm 4194304 $(sha256sum < $CD/$D1/exato-4mib.webm | cut -d' ' -f1) 0$"
confere "jpg igual"                         "$(cmp $P/crash-screenshot.jpg $CD/$D1/crash-screenshot.jpg && echo igual)" "igual"
confere "diario"                            "$(cat $DADOS/glibren.log)" "coredump: $D1 enviado (.* bytes, 7 arquivo(s)) para ps5-diagnosticos/coredump/${D1}_teste"
nao_tem "chave fora do diario"              "$(cat $DADOS/glibren.log)" "github_pat"
nao_tem "chave fora do GET"                 "$(lista)" "github_pat"

echo "--- erros do GitHub"
rm -rf "$GH/recebido"/*
echo 401 > "$GH/modo"
post -d nome=$D1 $L/api/coredump/enviar > /dev/null; espera_fim
confere "chave recusada"                    "$(lista)" '"envio":{"estado":"failed".*"erro":"unauthorized","http":401'
echo 500 > "$GH/modo"
post -d nome=$D1 $L/api/coredump/enviar > /dev/null; espera_fim
confere "GitHub fora (3 tentativas)"        "$(lista)" '"erro":"http","http":500'
confere "tentou de novo"                    "$(cat $DADOS/glibren.log)" "coredump: 2 nova(s) tentativa(s)"
kill $PID_GH 2>/dev/null; wait $PID_GH 2>/dev/null
post -d nome=$D1 $L/api/coredump/enviar > /dev/null; espera_fim
confere "sem servidor = network"            "$(lista)" '"erro":"network","http":0'

echo "--- grande demais"
mkdir -p "$CD/PPSA00003_1794000000"; truncate -s 900M "$CD/PPSA00003_1794000000/grande.prosperodmp"; printf 'm\n' > "$CD/PPSA00003_1794000000/_manifest.txt"
confere "grande = 413"                      "$(codigo -H 'X-GLR: 1' -d nome=PPSA00003_1794000000 $L/api/coredump/enviar)" "413"

echo "--- apagar"
confere "apagar estranha = 409"             "$(post -d nome=$D3 $L/api/coredump/apagar)" '"chave":"cd_incompleto"'
confere "estranha intacta"                  "$(ls $CD/$D3)" "_manifest.txt"
confere "apagar"                            "$(post -d nome=$D1 $L/api/coredump/apagar)" '"ok":true'
confere "sumiu"                             "$(ls $CD)" "^$D2$\|^PPSA00002\|^PPSA00003"
nao_tem "sumiu de verdade"                  "$(ls $CD)" "$D1"
confere "diario apagado"                    "$(cat $DADOS/glibren.log)" "coredump: $D1 apagado"
confere "apagar de novo = 404"              "$(codigo -H 'X-GLR: 1' -d nome=$D1 $L/api/coredump/apagar)" "404"

echo "--- item na pagina Payloads"
confere "item coredump no catalogo"         "$(curl -s $L/api/payloads)" '"id":"coredump","nome":"CoreDump Dumper"'
confere "pagina: bloco dos dumps"           "$(curl -s $L/payloads)" 'class="cdump"'
para
rm -rf "$T"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
