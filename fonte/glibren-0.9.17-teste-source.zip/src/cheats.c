/* Game Library Renamer (payload PS5) - cheats do jogo aberto, Fase 0: SO LEITURA (teste, branch "cheats").

O que faz: descobre o jogo aberto e a versao dele, acha no catalogo os arquivos de cheat .json dessa versao exata,
e para cada cheat LE os bytes atuais da memoria do jogo e compara com o "off" (desligada) e o "on" (ligada) do
arquivo. Se os bytes batem com o "off", a versao confere e a leitura funciona. NADA E GRAVADO NA MEMORIA DO JOGO: nao
existe funcao de escrita neste arquivo (nem kernel_proc_copyin, nem mdbg_copyin, nem ptrace) e a unica rota de
memoria e GET. A escrita (ligar/desligar com restauracao dos bytes originais) e a Fase 1.

Catalogo
- HEN-Cheats-Collection (TeeKay87, github.com/TeeKay87/HEN-Cheats-Collection), o mesmo que o onionHEN usa. Baixado
  como zip da branch master em codeload.github.com (POST /api/cheats/catalogo). Do zip so os .json de
  "<topo>/cheats/json/" sao extraidos, para /data/glibren/cheats/json/ (troca atomica da pasta inteira).
- Tambem le /data/OnionHEN/cheats/ (pasta plana do onionHEN) se existir; com o mesmo nome nos dois, vale o do onionHEN
  (pode ter sido editado pelo dono).
- Nome do arquivo: <TITLE_ID>_<VERSAO>[_<PROCESSO>][_<ID 8 hex>].json; a versao tem de ser IGUAL (texto) a do jogo.
  PS5: contentVersion do param.json ("01.000.002"). PS4: maior entre VERSION e APP_VER do param.sfo ("01.07").

Formato .json (conferido em arquivos reais do catalogo, 12/11/2026):
  {"name": jogo, "id": "PPSA04181", "version": "01.000.002", "process": "eboot.bin",
   "mods": [{"name": .., "description": .., "type": "checkbox",
             "memory": [{"offset": "80509753", "on": "9090..", "off": "C680..", "section": 0, "absolute": false}]}],
   "credits": [..]}
  offset = hex sem "0x", relativo a base do modulo "process" (o eboot.bin na maioria); "absolute": true = endereco
  direto. "on"/"off" = bytes em hex. "off" todo zero costuma ser "code cave" (area que o HEN cria ao ligar): antes
  disso a leitura falha ou da zeros - isso NAO quer dizer versao errada.

Como le a memoria do jogo (PS5) - ideia reescrita, sem copiar codigo, a partir de:
  ps5-payload-sdk (John Tornblom, GPL-3: crt/kernel_procio.c), ps5debug-NG (Pharaoh2k), etaHEN e onionHEN
  (aydencharles, GPL-3: source/util/source/cheats). Creditos no README.
  1. jogo: sceSystemServiceGetAppIdOfRunningBigApp (app id) + sceSystemServiceGetAppTitleId;
  2. processo: lista de processos (sysctl KERN_PROC_PROC) + sceKernelGetAppInfo(pid) com o mesmo app id (como a
     amostra "ps" do SDK); prefere o de nome "eboot.bin";
  3. base do modulo: kernel_dynlib_handle(pid, nome) + kernel_dynlib_mapbase_addr (SDK: lista de objetos em
     proc+0x3e8). Endereco = base + offset (ou o offset, se "absolute");
  4. leitura: kernel_proc_copyout(pid, endereco, ...) do SDK: tenta o mdbg (syscall 573, comando de LEITURA 0x12) e,
     se falhar, anda a tabela de paginas do processo (proc+0x200 -> vmspace -> pmap -> 4 niveis) e copia pelo DMAP
     com o kernel R/W que o elfldr entrega.
  Dependem do firmware (todos DENTRO do SDK v0.45, que tem tabela ate 14.xx e cobre o 12.00): offset do pmap no
  vmspace (0x2e8 no fw >= 6), proc+0x200 (vmspace), proc+0x3e8 (lista de modulos) e o numero/formato do mdbg. Neste
  arquivo nao ha offset de kernel nenhum. A confirmar no PS5 (fw 12.00): se o app id bate com o do processo, se a
  mapbase e a mesma base que os HENs usam (sections[0].vaddr), e se a leitura funciona. Tudo isso fica no diario
  (linhas "cheats:").

No PC (teste) o "jogo" e um processo chamado eboot.bin (testes/cheat_alvo.c): acha por /proc/<pid>/comm, base pela
primeira linha do modulo em /proc/<pid>/maps, le por /proc/<pid>/mem (so leitura). Variaveis: GLR_TESTE_ABERTOS (jogo
aberto), GLR_TESTE_APPMETA (pasta no lugar de /user/appmeta), GLR_TESTE_CHEATS (pasta do catalogo),
GLR_TESTE_ONION (pasta do onionHEN), GLR_TESTE_CHEATS_PID (so este processo), GLR_TESTE_CHEATS_URL (zip do catalogo; servidor local via GLR_TESTE_BASE).
*/
#include "cheats.h"

#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#include "config.h"
#include "https.h"
#include "imagem.h"
#include "lancador.h"
#include "plataforma.h"
#include "zip.h"

#ifdef __PROSPERO__
#include <sys/sysctl.h>
#include <sys/user.h>
#include <ps5/kernel.h>
#endif

#define URL_CATALOGO "https://codeload.github.com/TeeKay87/HEN-Cheats-Collection/zip/refs/heads/master"
#define MAX_ZIP (256ull * 1024 * 1024)          /* o zip tinha 13,8 MB (2486 .json) em 12/11/2026 */
#define MAX_TOTAL_ZIP (2ull * 1024 * 1024 * 1024)
#define MAX_JSON (2 * 1024 * 1024)              /* um arquivo de cheat */
#define MAX_ARQUIVOS 8                          /* arquivos da mesma versao (fontes diferentes) */
#define MAX_TRECHO 4096                         /* bytes de um "on"/"off" */
#define MAX_LEITURAS 2000                       /* trechos lidos por pedido */
#define FOLGA_DISCO (300ull * 1024 * 1024)

/* ------------------------------------------------------------------ JSON (arvore pequena, so leitura) */

/* Parser JSON estrito e pequeno so para os arquivos de cheat: monta uma arvore (objetos, listas, textos, numeros,
   true/false/null) com limites de tamanho, de profundidade e de nos. Textos: escapes decodificados (\uXXXX vira
   UTF-8; \u0000 vira espaco). Liberar com jv_liberar. */
typedef enum { JV_NULO, JV_LOGICO, JV_NUMERO, JV_TEXTO, JV_LISTA, JV_OBJETO } jv_tipo_t;

typedef struct jv {
  jv_tipo_t tipo;
  char *chave;          /* dentro de objeto: o nome do campo */
  char *texto;          /* JV_TEXTO (e o numero como escrito, em JV_NUMERO) */
  int logico;
  struct jv *filho, *prox;
} jv_t;

#define JV_MAX_PROF 24
#define JV_MAX_NOS 200000

typedef struct {
  const char *p, *fim;
  int nos;
  const char *erro;
} jv_leitor_t;

static void jv_liberar(jv_t *v) {
  while(v) {
    jv_t *prox = v->prox;
    jv_liberar(v->filho);
    free(v->chave);
    free(v->texto);
    free(v);
    v = prox;
  }
}

static void jv_espacos(jv_leitor_t *l) {
  while(l->p < l->fim && (*l->p == ' ' || *l->p == '\t' || *l->p == '\n' || *l->p == '\r')) l->p++;
}

static int jv_hex4(const char *p, unsigned *v) {
  *v = 0;
  for(int i = 0; i < 4; i++) {
    char c = p[i];
    int d = c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1;
    if(d < 0) return -1;
    *v = *v * 16 + (unsigned)d;
  }
  return 0;
}

static void jv_utf8(buf_t *b, unsigned cp) {
  char s[4];
  size_t k;
  if(!cp) cp = ' ';
  if(cp < 0x80) { s[0] = (char)cp; k = 1; }
  else if(cp < 0x800) { s[0] = (char)(0xC0 | (cp >> 6)); s[1] = (char)(0x80 | (cp & 0x3F)); k = 2; }
  else if(cp < 0x10000) { s[0] = (char)(0xE0 | (cp >> 12)); s[1] = (char)(0x80 | ((cp >> 6) & 0x3F)); s[2] = (char)(0x80 | (cp & 0x3F)); k = 3; }
  else { s[0] = (char)(0xF0 | (cp >> 18)); s[1] = (char)(0x80 | ((cp >> 12) & 0x3F)); s[2] = (char)(0x80 | ((cp >> 6) & 0x3F)); s[3] = (char)(0x80 | (cp & 0x3F)); k = 4; }
  buf_add(b, s, k);
}

/* Le um texto entre aspas (l->p no '"'); devolve malloc ou NULL. */
static char *jv_texto(jv_leitor_t *l) {
  buf_t b = {0};
  l->p++;
  while(l->p < l->fim && *l->p != '"') {
    unsigned char c = (unsigned char)*l->p;
    if(c < 0x20) { l->erro = "caractere de controle dentro de texto"; buf_free(&b); return NULL; }
    if(c != '\\') { buf_add(&b, l->p++, 1); continue; }
    if(l->fim - l->p < 2) break;
    char e = l->p[1];
    l->p += 2;
    switch(e) {
    case '"': buf_add(&b, "\"", 1); break;
    case '\\': buf_add(&b, "\\", 1); break;
    case '/': buf_add(&b, "/", 1); break;
    case 'b': case 'f': case 'n': case 'r': case 't': buf_add(&b, " ", 1); break;
    case 'u': {
      unsigned cp, baixo;
      if(l->fim - l->p < 4 || jv_hex4(l->p, &cp)) { l->erro = "escape \\u invalido"; buf_free(&b); return NULL; }
      l->p += 4;
      if(cp >= 0xD800 && cp <= 0xDBFF && l->fim - l->p >= 6 && l->p[0] == '\\' && l->p[1] == 'u' && !jv_hex4(l->p + 2, &baixo) &&
         baixo >= 0xDC00 && baixo <= 0xDFFF) {
        cp = 0x10000 + ((cp - 0xD800) << 10) + (baixo - 0xDC00);
        l->p += 6;
      } else if(cp >= 0xD800 && cp <= 0xDFFF) cp = 0xFFFD;
      jv_utf8(&b, cp);
      break;
    }
    default: l->erro = "escape invalido"; buf_free(&b); return NULL;
    }
  }
  if(l->p >= l->fim) { l->erro = "texto sem fim"; buf_free(&b); return NULL; }
  l->p++;
  if(!b.d) buf_add(&b, "", 0);
  return b.d;
}

static jv_t *jv_valor(jv_leitor_t *l, int prof);

static jv_t *jv_novo(jv_leitor_t *l, jv_tipo_t tipo) {
  if(++l->nos > JV_MAX_NOS) { l->erro = "JSON grande demais"; return NULL; }
  jv_t *v = calloc(1, sizeof *v);
  if(!v) { l->erro = "sem memoria"; return NULL; }
  v->tipo = tipo;
  return v;
}

static jv_t *jv_composto(jv_leitor_t *l, int prof, int objeto) {
  jv_t *v = jv_novo(l, objeto ? JV_OBJETO : JV_LISTA), **ultimo;
  if(!v) return NULL;
  ultimo = &v->filho;
  l->p++;
  jv_espacos(l);
  if(l->p < l->fim && *l->p == (objeto ? '}' : ']')) { l->p++; return v; }
  for(;;) {
    char *chave = NULL;
    jv_espacos(l);
    if(objeto) {
      if(l->p >= l->fim || *l->p != '"') { l->erro = "esperava o nome de um campo"; goto falha; }
      if(!(chave = jv_texto(l))) goto falha;
      jv_espacos(l);
      if(l->p >= l->fim || *l->p != ':') { free(chave); l->erro = "esperava ':'"; goto falha; }
      l->p++;
    }
    jv_t *f = jv_valor(l, prof + 1);
    if(!f) { free(chave); goto falha; }
    f->chave = chave;
    *ultimo = f;
    ultimo = &f->prox;
    jv_espacos(l);
    if(l->p < l->fim && *l->p == ',') { l->p++; continue; }
    if(l->p < l->fim && *l->p == (objeto ? '}' : ']')) { l->p++; return v; }
    l->erro = objeto ? "esperava ',' ou '}'" : "esperava ',' ou ']'";
    goto falha;
  }
falha:
  jv_liberar(v);
  return NULL;
}

static jv_t *jv_valor(jv_leitor_t *l, int prof) {
  if(prof > JV_MAX_PROF) { l->erro = "JSON fundo demais"; return NULL; }
  jv_espacos(l);
  if(l->p >= l->fim) { l->erro = "fim inesperado"; return NULL; }
  char c = *l->p;
  if(c == '{' || c == '[') return jv_composto(l, prof, c == '{');
  if(c == '"') {
    char *s = jv_texto(l);
    if(!s) return NULL;
    jv_t *v = jv_novo(l, JV_TEXTO);
    if(!v) { free(s); return NULL; }
    v->texto = s;
    return v;
  }
  static const struct { const char *s; jv_tipo_t t; int b; } PAL[] = {{"true", JV_LOGICO, 1}, {"false", JV_LOGICO, 0}, {"null", JV_NULO, 0}};
  for(size_t i = 0; i < sizeof PAL / sizeof PAL[0]; i++) {
    size_t n = strlen(PAL[i].s);
    if((size_t)(l->fim - l->p) >= n && !memcmp(l->p, PAL[i].s, n)) {
      l->p += n;
      jv_t *v = jv_novo(l, PAL[i].t);
      if(v) v->logico = PAL[i].b;
      return v;
    }
  }
  if(c == '-' || (c >= '0' && c <= '9')) {
    const char *ini = l->p;
    if(*l->p == '-') l->p++;
    while(l->p < l->fim && strchr("0123456789.eE+-", *l->p)) l->p++;
    jv_t *v = jv_novo(l, JV_NUMERO);
    if(!v) return NULL;
    v->texto = strndup(ini, (size_t)(l->p - ini));
    if(!v->texto) { free(v); l->erro = "sem memoria"; return NULL; }
    return v;
  }
  l->erro = "valor invalido";
  return NULL;
}

/* Documento inteiro (com BOM UTF-8 opcional). NULL se invalido (erro recebe o motivo). */
static jv_t *jv_ler(const char *dados, size_t n, const char **erro) {
  jv_leitor_t l = {dados, dados + n, 0, NULL};
  if(n >= 3 && !memcmp(dados, "\xEF\xBB\xBF", 3)) l.p += 3;
  jv_t *v = jv_valor(&l, 0);
  if(v) {
    jv_espacos(&l);
    if(l.p != l.fim) { jv_liberar(v); v = NULL; l.erro = "sobra depois do JSON"; }
  }
  if(erro) *erro = l.erro ? l.erro : "";
  return v;
}

/* Campo de um objeto (nome sem diferenciar maiusculas: os arquivos da comunidade variam "Offset"/"offset"). */
static const jv_t *jv_campo(const jv_t *o, const char *nome) {
  if(!o || o->tipo != JV_OBJETO) return NULL;
  for(const jv_t *f = o->filho; f; f = f->prox)
    if(f->chave && !strcasecmp(f->chave, nome)) return f;
  return NULL;
}

/* Texto de um campo (numero tambem vale, como escrito); "" se nao tiver. */
static const char *jv_txt(const jv_t *o, const char *nome) {
  const jv_t *f = jv_campo(o, nome);
  return f && (f->tipo == JV_TEXTO || f->tipo == JV_NUMERO) ? f->texto : "";
}

/* ------------------------------------------------------------------ pastas */

static void pasta_catalogo(char *s, size_t tam) {
#ifdef __PROSPERO__
  snprintf(s, tam, "/data/glibren/cheats");
#else
  const char *e = getenv("GLR_TESTE_CHEATS");
  if(e && *e) snprintf(s, tam, "%s", e);
  else snprintf(s, tam, "%s/cheats", g_pasta_dados);
#endif
}

static const char *pasta_onion(void) {
#ifdef __PROSPERO__
  return "/data/OnionHEN/cheats";
#else
  const char *e = getenv("GLR_TESTE_ONION");
  return e && *e ? e : "/nao-existe";
#endif
}

static int ler_arquivo(const char *caminho, buf_t *b, size_t max) {
  FILE *f = fopen(caminho, "rb");
  if(!f) return -1;
  char bloco[16384];
  size_t n;
  int r = 0;
  while((n = fread(bloco, 1, sizeof bloco, f)) > 0) {
    if(b->n + n > max) { r = -1; break; }
    buf_add(b, bloco, n);
  }
  fclose(f);
  if(!r && !b->d) buf_add(b, "", 0);
  return r;
}

/* ------------------------------------------------------------------ jogo aberto e versao */

#ifdef __PROSPERO__
int sceSystemServiceGetAppIdOfRunningBigApp(void) __attribute__((weak));
int sceSystemServiceGetAppTitleId(int app_id, char *title_id) __attribute__((weak));
#endif

typedef struct {
  char tid[16];
  int app_id;          /* -1 = nao sabe (PC ou funcao ausente) */
  char tipo[16];       /* ps5, ps4, menu, desconhecido */
  char nome[256];
  char versao[32];     /* contentVersion (PS5) ou VERSION/APP_VER (PS4) */
  char versao_de[24];  /* de onde veio (campo) */
  char mestre[32];     /* masterVersion (so informativo) */
} jogo_t;

static void jogo_aberto(jogo_t *j) {
  memset(j, 0, sizeof *j);
  j->app_id = -1;
  int sabe = 0;
#ifdef __PROSPERO__
  if(sceSystemServiceGetAppIdOfRunningBigApp && sceSystemServiceGetAppTitleId) {
    int id = sceSystemServiceGetAppIdOfRunningBigApp();
    sabe = 1;
    if(id >= 0) {
      char t[32];
      memset(t, 0, sizeof t);
      if(!sceSystemServiceGetAppTitleId(id, t)) {
        t[sizeof t - 1] = 0;
        snprintf(j->tid, sizeof j->tid, "%s", t);
        j->app_id = id;
      } else sabe = 0;
    }
  }
#endif
  if(!sabe) sabe = app_de_jogo_aberto(j->tid, sizeof j->tid) >= 0;
  const char *t = j->tid;
  if(!sabe) snprintf(j->tipo, sizeof j->tipo, "desconhecido");
  else if(!t[0] || !titulo_valido(t) || !strncmp(t, "NPXS", 4) || !strcmp(t, GLIBREN_TITLE_ID)) snprintf(j->tipo, sizeof j->tipo, "menu");
  else if(!strncmp(t, "CUSA", 4)) snprintf(j->tipo, sizeof j->tipo, "ps4");
  else snprintf(j->tipo, sizeof j->tipo, "ps5");
}

static const char *pasta_appmeta(void) {
#ifdef __PROSPERO__
  return "/user/appmeta";
#else
  const char *e = getenv("GLR_TESTE_APPMETA");
  return e && *e ? e : "/nao-existe";
#endif
}

/* Versao de jogo: so digitos e pontos (vai para nome de arquivo e para a tela). */
static int versao_valida(const char *v) {
  if(!*v || strlen(v) > 20) return 0;
  for(; *v; v++)
    if(!isdigit((unsigned char)*v) && *v != '.') return 0;
  return 1;
}

static uint32_t le32(const unsigned char *p) {
  return p[0] | p[1] << 8 | p[2] << 16 | (uint32_t)p[3] << 24;
}

/* PS4: VERSION e APP_VER do param.sfo (formato em fmt_param.c). Fica com o maior (como o onionHEN). */
static int sfo_versao(const unsigned char *d, size_t n, char *saida, size_t tam, char *campo, size_t tam_campo) {
  if(n >= 0x800 + 0x14 && !memcmp(d, "SCEC", 4)) { d += 0x800; n -= 0x800; }
  if(n < 0x14 || memcmp(d, "\0PSF", 4)) return -1;
  uint32_t chaves = le32(d + 8), dados = le32(d + 12), qtd = le32(d + 16);
  if(qtd > 1000 || 0x14 + (size_t)qtd * 16 > n || chaves >= n || dados >= n) return -1;
  saida[0] = campo[0] = 0;
  for(uint32_t i = 0; i < qtd; i++) {
    const unsigned char *it = d + 0x14 + i * 16;
    uint32_t k = it[0] | it[1] << 8, fmt = it[2] | it[3] << 8, len = le32(it + 4), off = le32(it + 12);
    if((size_t)chaves + k >= n || (fmt & 0xff) != 4 || (size_t)dados + off + len > n || len == 0 || len > 31) continue;
    const char *nome = (const char *)d + chaves + k;
    if(strnlen(nome, n - chaves - k) == n - chaves - k) continue;
    if(strcmp(nome, "VERSION") && strcmp(nome, "APP_VER")) continue;
    char v[32];
    memcpy(v, d + dados + off, len);
    v[len] = 0;
    if(!versao_valida(v)) continue;
    if(!saida[0] || strcmp(v, saida) > 0) {
      snprintf(saida, tam, "%s", v);
      snprintf(campo, tam_campo, "%s", nome);
    }
  }
  return saida[0] ? 0 : -1;
}

/* Nome e versao pelo param.json (PS5) ou param.sfo (PS4) do jogo instalado. Caminhos na ordem do onionHEN/etaHEN. */
static void jogo_versao(jogo_t *j) {
  if(strcmp(j->tipo, "ps5") && strcmp(j->tipo, "ps4")) return;
  static char pastas[MAX_PASTAS][1024];
  static pthread_mutex_t trava = PTHREAD_MUTEX_INITIALIZER;
  char caminhos[6][320], idioma[16] = "pt-BR";
  pthread_mutex_lock(&trava);
  config_ler(pastas, idioma);
  pthread_mutex_unlock(&trava);
  int ps4 = !strcmp(j->tipo, "ps4");
  const char *arq = ps4 ? "param.sfo" : "param.json";
  int n = 0;
  snprintf(caminhos[n++], sizeof caminhos[0], "%s/%s/%s", pasta_appmeta(), j->tid, arq);
#ifdef __PROSPERO__
  snprintf(caminhos[n++], sizeof caminhos[0], "/system_data/priv/appmeta/%s/%s", j->tid, arq);
  snprintf(caminhos[n++], sizeof caminhos[0], "/system_data/priv/appmeta/external/%s/%s", j->tid, arq);
  snprintf(caminhos[n++], sizeof caminhos[0], "/system_ex/app/%s/sce_sys/%s", j->tid, arq);
  snprintf(caminhos[n++], sizeof caminhos[0], "/user/app/%s/sce_sys/%s", j->tid, arq);
#endif
  for(int i = 0; i < n && !j->versao[0]; i++) {
    buf_t b = {0};
    if(ler_arquivo(caminhos[i], &b, 1024 * 1024)) { buf_free(&b); continue; }
    info_jogo_t info;
    memset(&info, 0, sizeof info);
    if(ps4) {
      if(!param_sfo_ler(b.d, b.n, idioma, &info) && !j->nome[0]) snprintf(j->nome, sizeof j->nome, "%s", info.nome);
      sfo_versao((const unsigned char *)b.d, b.n, j->versao, sizeof j->versao, j->versao_de, sizeof j->versao_de);
    } else {
      if(!param_json_ler(b.d, b.n, idioma, &info) && !j->nome[0]) snprintf(j->nome, sizeof j->nome, "%s", info.nome);
      jv_t *r = jv_ler(b.d, b.n, NULL);
      static const char *CAMPOS[] = {"contentVersion", "content_version", "titleVersion", "version", "APP_VER", NULL};
      for(int c = 0; r && CAMPOS[c] && !j->versao[0]; c++) {
        const char *v = jv_txt(r, CAMPOS[c]);
        if(versao_valida(v)) {
          snprintf(j->versao, sizeof j->versao, "%s", v);
          snprintf(j->versao_de, sizeof j->versao_de, "%s", CAMPOS[c]);
        }
      }
      if(r && versao_valida(jv_txt(r, "masterVersion"))) snprintf(j->mestre, sizeof j->mestre, "%s", jv_txt(r, "masterVersion"));
      jv_liberar(r);
    }
    buf_free(&b);
  }
  for(char *c = j->nome; *c; c++) if((unsigned char)*c < ' ') *c = ' ';
}

/* ------------------------------------------------------------------ catalogo (download) */

static pthread_mutex_t g_trava_cat = PTHREAD_MUTEX_INITIALIZER;
static char g_cat_estado[16] = "parado";   /* parado, baixando, extraindo, pronto, erro */
static char g_cat_erro[200];
static unsigned long long g_cat_bytes;

static void cat_estado(const char *estado, const char *erro) {
  pthread_mutex_lock(&g_trava_cat);
  snprintf(g_cat_estado, sizeof g_cat_estado, "%s", estado);
  snprintf(g_cat_erro, sizeof g_cat_erro, "%s", erro ? erro : "");
  pthread_mutex_unlock(&g_trava_cat);
}

/* Apaga uma pasta so com arquivos (a pasta json/ do catalogo). Ignora o que nao existe. */
static void apagar_pasta_plana(const char *pasta) {
  DIR *d = opendir(pasta);
  if(d) {
    struct dirent *e;
    char c[1024];
    while((e = readdir(d))) {
      if(!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
      snprintf(c, sizeof c, "%s/%s", pasta, e->d_name);
      unlink(c);
    }
    closedir(d);
  }
  rmdir(pasta);
}

typedef struct {
  int fd;
  unsigned long long n;
  int excedeu, erro;
} baixando_t;

static int recebeu_zip(const void *dados, size_t n, void *ctx) {
  baixando_t *b = ctx;
  if(b->n + n > MAX_ZIP) { b->excedeu = 1; return 1; }
  const char *p = dados;
  size_t feito = 0;
  while(feito < n) {
    ssize_t w = write(b->fd, p + feito, n - feito);
    if(w <= 0) { b->erro = 1; return 1; }
    feito += (size_t)w;
  }
  b->n += n;
  pthread_mutex_lock(&g_trava_cat);
  g_cat_bytes = b->n;
  pthread_mutex_unlock(&g_trava_cat);
  return 0;
}

/* "<topo>/cheats/json/<arquivo>.json" (ou sem a pasta de topo): devolve o nome do arquivo, senao NULL. */
static const char *json_do_catalogo(const char *nome) {
  const char *m = strstr(nome, "cheats/json/");
  if(!m) return NULL;
  if(m != nome) {   /* antes: uma unica pasta de topo */
    const char *barra = strchr(nome, '/');
    if(!barra || barra + 1 != m) return NULL;
  }
  const char *arq = m + 12;
  size_t n = strlen(arq);
  if(n < 6 || n > 200 || strchr(arq, '/') || strcasecmp(arq + n - 5, ".json") || !nome_valido(arq) || arq[0] == '.') return NULL;
  return arq;
}

static void *baixar_catalogo(void *arg) {
  (void)arg;
  char pasta[512], parcial[600], novo[600], atual[600], antigo[600], info[600], erro[200] = "";
  pasta_catalogo(pasta, sizeof pasta);
  snprintf(parcial, sizeof parcial, "%s/.catalogo.zip.parcial", pasta);
  snprintf(novo, sizeof novo, "%s/json.novo", pasta);
  snprintf(atual, sizeof atual, "%s/json", pasta);
  snprintf(antigo, sizeof antigo, "%s/json.antigo", pasta);
  snprintf(info, sizeof info, "%s/catalogo.txt", pasta);
  const char *url = URL_CATALOGO;
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_CHEATS_URL")) url = getenv("GLR_TESTE_CHEATS_URL");
#endif
  zip_t z;
  memset(&z, 0, sizeof z);
  z.fd = -1;
  int abriu_zip = 0, qtd = 0;
  baixando_t b = {-1, 0, 0, 0};
  struct statvfs sv;
  if(mkdir_p(pasta)) { snprintf(erro, sizeof erro, "nao criou %s (errno %d)", pasta, errno); goto fim; }
  if(!statvfs(pasta, &sv) && (unsigned long long)sv.f_bavail * sv.f_frsize < FOLGA_DISCO) {
    snprintf(erro, sizeof erro, "pouco espaco livre no PS5 (%llu MB)", (unsigned long long)sv.f_bavail * sv.f_frsize / (1024 * 1024));
    goto fim;
  }
  diario("cheats: baixando o catalogo (%s)", url);
  unlink(parcial);
  if((b.fd = open(parcial, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644)) < 0) {
    snprintf(erro, sizeof erro, "nao criou o arquivo do download (errno %d)", errno);
    goto fim;
  }
  int status = https_baixar(url, recebeu_zip, &b);
  int fechou = close(b.fd);
  diario("cheats: catalogo: status %d, %llu bytes", status, b.n);
  if(status != 200 || b.excedeu || b.erro || fechou) {
    if(status != 200) snprintf(erro, sizeof erro, "nao baixou o catalogo (HTTP %d)", status);
    else if(b.excedeu) snprintf(erro, sizeof erro, "catalogo maior que o limite");
    else snprintf(erro, sizeof erro, "erro ao gravar o download");
    goto fim;
  }
  cat_estado("extraindo", NULL);
  char ezip[160] = "";
  if(zip_abrir(&z, parcial, MAX_TOTAL_ZIP, ezip, sizeof ezip)) {
    snprintf(erro, sizeof erro, "zip recusado: %s", ezip);
    goto fim;
  }
  abriu_zip = 1;
  apagar_pasta_plana(novo);
  if(mkdir(novo, 0777)) { snprintf(erro, sizeof erro, "nao criou %s (errno %d)", novo, errno); goto fim; }
  for(uint32_t i = 0; i < z.n; i++) {
    const zip_entrada_t *e = &z.e[i];
    const char *arq = e->pasta ? NULL : json_do_catalogo(e->nome);
    if(!arq || e->tam > MAX_JSON) continue;
    buf_t j = {0};
    char e2[160], destino[1024];
    if(zip_ler(&z, e, &j, MAX_JSON, e2, sizeof e2)) {
      diario("cheats: catalogo: %s pulado (%s)", arq, e2);
      buf_free(&j);
      continue;
    }
    snprintf(destino, sizeof destino, "%s/%s", novo, arq);
    int fd = open(destino, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644);
    int ok = fd >= 0 && write(fd, j.d ? j.d : "", j.n) == (ssize_t)j.n;
    if(fd >= 0 && close(fd)) ok = 0;
    buf_free(&j);
    if(!ok) { snprintf(erro, sizeof erro, "erro ao gravar %.100s (errno %d)", arq, errno); goto fim; }
    qtd++;
  }
  if(!qtd) { snprintf(erro, sizeof erro, "o zip nao tem cheats/json/*.json"); goto fim; }
  /* troca a pasta inteira: json -> json.antigo, json.novo -> json */
  apagar_pasta_plana(antigo);
  if(rename(atual, antigo) && errno != ENOENT) { snprintf(erro, sizeof erro, "nao trocou a pasta (errno %d)", errno); goto fim; }
  if(rename(novo, atual)) {
    snprintf(erro, sizeof erro, "nao trocou a pasta (errno %d)", errno);
    rename(antigo, atual);
    goto fim;
  }
  apagar_pasta_plana(antigo);
  FILE *f = fopen(info, "w");
  if(f) {
    fprintf(f, "quando=%lld\narquivos=%d\nbytes=%llu\n", (long long)time(NULL), qtd, b.n);
    fclose(f);
  }
fim:
  if(abriu_zip) zip_fechar(&z);
  unlink(parcial);
  if(erro[0]) {
    apagar_pasta_plana(novo);
    diario("cheats: catalogo: %s", erro);
    cat_estado("erro", erro);
  } else {
    diario("cheats: catalogo pronto: %d arquivos .json", qtd);
    cat_estado("pronto", NULL);
  }
  return NULL;
}

int cheats_catalogo_baixar(char *msg, size_t tam) {
  pthread_mutex_lock(&g_trava_cat);
  int ocupado = !strcmp(g_cat_estado, "baixando") || !strcmp(g_cat_estado, "extraindo");
  if(!ocupado) {
    snprintf(g_cat_estado, sizeof g_cat_estado, "baixando");
    g_cat_erro[0] = 0;
    g_cat_bytes = 0;
  }
  pthread_mutex_unlock(&g_trava_cat);
  if(ocupado) { snprintf(msg, tam, "o catalogo ja esta sendo baixado"); return -1; }
  if(criar_thread(baixar_catalogo, NULL, NULL)) {
    cat_estado("erro", "nao criou a thread do download");
    snprintf(msg, tam, "nao criou a thread do download");
    return -1;
  }
  msg[0] = 0;
  return 0;
}

static void catalogo_json(buf_t *b) {
  char pasta[512], info[600], linha[128];
  pasta_catalogo(pasta, sizeof pasta);
  snprintf(info, sizeof info, "%s/catalogo.txt", pasta);
  long long quando = 0;
  int arquivos = 0;
  FILE *f = fopen(info, "r");
  while(f && fgets(linha, sizeof linha, f)) {
    if(!strncmp(linha, "quando=", 7)) quando = atoll(linha + 7);
    else if(!strncmp(linha, "arquivos=", 9)) arquivos = atoi(linha + 9);
  }
  if(f) fclose(f);
  struct stat st;
  int onion = !stat(pasta_onion(), &st) && S_ISDIR(st.st_mode);
  pthread_mutex_lock(&g_trava_cat);
  buf_str(b, "\"catalogo\":{\"estado\":");
  buf_json(b, g_cat_estado);
  buf_str(b, ",\"erro\":");
  buf_json(b, g_cat_erro);
  buf_fmt(b, ",\"bytes\":%llu,\"quando\":%lld,\"arquivos\":%d,\"onion\":%s}", g_cat_bytes, quando, arquivos, onion ? "true" : "false");
  pthread_mutex_unlock(&g_trava_cat);
}

/* ------------------------------------------------------------------ escolha dos arquivos */

typedef struct {
  char caminho[700];
  char nome[256];
  const char *origem;   /* "onionhen" ou "catalogo" */
} arquivo_t;

/* Nome "<TID>_<VERSAO>" seguido de "_" ou de ".json" (sem diferenciar maiusculas no Title ID e na extensao). */
static int nome_combina(const char *nome, const char *tid, const char *versao) {
  size_t nt = strlen(tid), nv = strlen(versao), n = strlen(nome);
  if(!nt || !nv || n < 6 || strcasecmp(nome + n - 5, ".json")) return 0;
  if(strncasecmp(nome, tid, nt) || nome[nt] != '_' || strncmp(nome + nt + 1, versao, nv)) return 0;
  const char *depois = nome + nt + 1 + nv;
  return *depois == '_' || depois == nome + n - 5;
}

static int cmp_arquivo(const void *a, const void *b) {
  return strcmp(((const arquivo_t *)a)->nome, ((const arquivo_t *)b)->nome);
}

static int achar_arquivos(const jogo_t *j, arquivo_t *lista, int max) {
  int n = 0;
  char cat[512], pj[600];
  pasta_catalogo(cat, sizeof cat);
  snprintf(pj, sizeof pj, "%s/json", cat);
  const char *pastas[2] = {pasta_onion(), pj};
  const char *origens[2] = {"onionhen", "catalogo"};
  for(int p = 0; p < 2; p++) {
    DIR *d = opendir(pastas[p]);
    if(!d) continue;
    struct dirent *e;
    int inicio = n;
    while((e = readdir(d)) && n < max) {
      if(!nome_combina(e->d_name, j->tid, j->versao) || strlen(e->d_name) >= sizeof lista[0].nome) continue;
      int repetido = 0;
      for(int i = 0; i < inicio && !repetido; i++) repetido = !strcasecmp(lista[i].nome, e->d_name);
      if(repetido) continue;
      snprintf(lista[n].caminho, sizeof lista[n].caminho, "%s/%s", pastas[p], e->d_name);
      snprintf(lista[n].nome, sizeof lista[n].nome, "%s", e->d_name);
      lista[n].origem = origens[p];
      n++;
    }
    closedir(d);
    qsort(lista + inicio, (size_t)(n - inicio), sizeof lista[0], cmp_arquivo);
  }
  return n;
}

/* ------------------------------------------------------------------ memoria do jogo (SO LEITURA) */

static int digito_hex(int c) {
  return c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1;
}

/* "C6 80 cc 00" -> bytes. -1 se nao for hex par ou passar de max. */
static int hex_bytes(const char *s, unsigned char *saida, size_t max) {
  size_t n = 0;
  int alto = -1;
  for(; *s; s++) {
    if(*s == ' ' || *s == '\t') continue;
    int d = digito_hex(*s);
    if(d < 0) return -1;
    if(alto < 0) { alto = d; continue; }
    if(n == max) return -1;
    saida[n++] = (unsigned char)(alto << 4 | d);
    alto = -1;
  }
  return alto >= 0 ? -1 : (int)n;
}

/* Offset em hex (com ou sem 0x). -1 se invalido. */
static int hex_offset(const char *s, uint64_t *v) {
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) s += 2;
  if(!*s || strlen(s) > 16) return -1;
  *v = 0;
  for(; *s; s++) {
    int d = digito_hex(*s);
    if(d < 0) return -1;
    *v = *v << 4 | (uint64_t)d;
  }
  return 0;
}

static const char *base_nome(const char *caminho) {
  const char *b = strrchr(caminho, '/');
  return b ? b + 1 : caminho;
}

#define MAX_PIDS 8

typedef struct {
  int pids[MAX_PIDS];
  int n;
  char comm[MAX_PIDS][24];
} processos_t;

#ifdef __PROSPERO__
/* Mesmo layout da amostra "ps" do ps5-payload-sdk (sceKernelGetAppInfo). */
typedef struct {
  uint32_t app_id;
  uint64_t desconhecido1;
  uint32_t app_type;
  char title_id[10];
  char desconhecido2[0x3c];
} app_info_t;
int sceKernelGetAppInfo(pid_t pid, app_info_t *info) __attribute__((weak));

/* Processos do jogo aberto: mesmo app id (ou, sem app id, mesmo Title ID). O "eboot.bin" fica primeiro. */
static void processos_do_jogo(const jogo_t *j, processos_t *pr) {
  pr->n = 0;
  if(!sceKernelGetAppInfo) return;
  int mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_PROC, 0};
  size_t tam = 0;
  if(sysctl(mib, 4, NULL, &tam, NULL, 0) || !tam) return;
  tam += 16 * sizeof(struct kinfo_proc);
  char *lista = malloc(tam);
  if(!lista) return;
  if(sysctl(mib, 4, lista, &tam, NULL, 0)) { free(lista); return; }
  for(char *p = lista; p + sizeof(int) <= lista + tam;) {
    struct kinfo_proc *ki = (struct kinfo_proc *)p;
    if(ki->ki_structsize <= 0) break;
    p += ki->ki_structsize;
    app_info_t ai;
    memset(&ai, 0, sizeof ai);
    if(sceKernelGetAppInfo(ki->ki_pid, &ai)) continue;
    ai.title_id[sizeof ai.title_id - 1] = 0;
    int mesmo = j->app_id >= 0 ? (int)ai.app_id == j->app_id : !strncmp(ai.title_id, j->tid, 9);
    if(!mesmo || pr->n == MAX_PIDS) continue;
    int i = pr->n++;
    if(!strcmp(ki->ki_comm, "eboot.bin") && i) {   /* eboot primeiro */
      pr->pids[i] = pr->pids[0];
      memcpy(pr->comm[i], pr->comm[0], sizeof pr->comm[0]);
      i = 0;
    }
    pr->pids[i] = ki->ki_pid;
    snprintf(pr->comm[i], sizeof pr->comm[i], "%s", ki->ki_comm);
  }
  free(lista);
}

/* Base do modulo (ex.: "eboot.bin") no processo. 0 = achou. */
static int base_do_modulo(int pid, const char *modulo, uint64_t *base) {
  uint32_t h = 0;
  if(kernel_dynlib_handle(pid, modulo, &h)) return -1;
  intptr_t b = kernel_dynlib_mapbase_addr(pid, h);
  if(!b || b == -1) return -1;
  *base = (uint64_t)b;
  return 0;
}

/* SO LEITURA: kernel_proc_copyout (mdbg de leitura e, se falhar, tabela de paginas + DMAP; ver o topo). */
static int ler_memoria(int pid, uint64_t endereco, void *saida, size_t n) {
  return kernel_proc_copyout(pid, (intptr_t)endereco, saida, n) ? -1 : 0;
}
#else
/* PC: processos chamados "eboot.bin" (o alvo de teste, testes/cheat_alvo.c). */
static void processos_do_jogo(const jogo_t *j, processos_t *pr) {
  (void)j;
  pr->n = 0;
  DIR *d = opendir("/proc");
  if(!d) return;
  struct dirent *e;
  while((e = readdir(d)) && pr->n < MAX_PIDS) {
    if(!isdigit((unsigned char)e->d_name[0])) continue;
    char c[300], comm[32] = "";
    snprintf(c, sizeof c, "/proc/%s/comm", e->d_name);
    FILE *f = fopen(c, "r");
    if(!f) continue;
    if(!fgets(comm, sizeof comm, f)) comm[0] = 0;
    fclose(f);
    comm[strcspn(comm, "\n")] = 0;
    if(strcmp(comm, "eboot.bin")) continue;
    const char *so = getenv("GLR_TESTE_CHEATS_PID");   /* teste: so este pid (a demo pode ter outro eboot.bin) */
    if(so && *so && atoi(so) != atoi(e->d_name)) continue;
    pr->pids[pr->n] = atoi(e->d_name);
    snprintf(pr->comm[pr->n], sizeof pr->comm[0], "%s", comm);
    pr->n++;
  }
  closedir(d);
}

static int base_do_modulo(int pid, const char *modulo, uint64_t *base) {
  char c[64], linha[1200];
  snprintf(c, sizeof c, "/proc/%d/maps", pid);
  FILE *f = fopen(c, "r");
  if(!f) return -1;
  int r = -1;
  while(r && fgets(linha, sizeof linha, f)) {
    unsigned long long ini;
    char caminho[1024] = "";
    linha[strcspn(linha, "\n")] = 0;
    if(sscanf(linha, "%llx-%*x %*s %*s %*s %*s %1023s", &ini, caminho) == 2 && !strcmp(base_nome(caminho), modulo)) {
      *base = ini;
      r = 0;
    }
  }
  fclose(f);
  return r;
}

/* SO LEITURA: /proc/<pid>/mem aberto em O_RDONLY. */
static int ler_memoria(int pid, uint64_t endereco, void *saida, size_t n) {
  char c[64];
  snprintf(c, sizeof c, "/proc/%d/mem", pid);
  int fd = open(c, O_RDONLY);
  if(fd < 0) return -1;
  ssize_t r = pread(fd, saida, n, (off_t)endereco);
  close(fd);
  return r == (ssize_t)n ? 0 : -1;
}
#endif

/* ------------------------------------------------------------------ JSON de saida */

static int tudo_zero(const unsigned char *b, int n) {
  for(int i = 0; i < n; i++)
    if(b[i]) return 0;
  return n > 0;
}

/* Bytes em hex (ate 24; mais que isso termina em ".."). */
static void hex_curto(buf_t *b, const unsigned char *d, int n) {
  char s[2 * 24 + 4];
  int k = n > 24 ? 24 : n, p = 0;
  for(int i = 0; i < k; i++) p += snprintf(s + p, sizeof s - (size_t)p, "%02X", d[i]);
  if(n > k) snprintf(s + p, sizeof s - (size_t)p, "..");
  s[sizeof s - 1] = 0;
  buf_json(b, s);
}

typedef struct {
  int lidos, desligados, ligados, diferentes, erros, caves;
} contagem_t;

/* Um trecho de "memory": le e compara. Estados: desligado, ligado, diferente, cave (code cave ainda nao criada),
   erro (leitura falhou), invalido (arquivo), secao (section != 0, Fase 1), sem_base (modulo nao achado), limite. */
static void trecho(buf_t *b, const jv_t *m, int pid, int tem_base, uint64_t base, int *leituras, contagem_t *c) {
  static unsigned char on[MAX_TRECHO], off[MAX_TRECHO], atual[MAX_TRECHO];   /* so com g_trava_leitura */
  uint64_t offset;
  int non = hex_bytes(jv_txt(m, "on"), on, sizeof on), noff = hex_bytes(jv_txt(m, "off"), off, sizeof off);
  const jv_t *abs = jv_campo(m, "absolute"), *sec = jv_campo(m, "section");
  int absoluto = abs && abs->tipo == JV_LOGICO && abs->logico;
  int secao = sec && sec->tipo == JV_NUMERO ? atoi(sec->texto) : 0;
  const char *estado;
  buf_str(b, "{\"offset\":");
  buf_json(b, jv_txt(m, "offset"));
  if(hex_offset(jv_txt(m, "offset"), &offset) || non <= 0 || noff < 0 || (noff && noff != non)) {
    estado = "invalido";
    c->erros++;
  } else if(secao) {
    estado = "secao";
    c->erros++;
  } else if(!tem_base && !absoluto) {
    estado = "sem_base";
    c->erros++;
  } else if(*leituras >= MAX_LEITURAS) {
    estado = "limite";
    c->erros++;
  } else {
    uint64_t end = absoluto ? offset : base + offset;
    int cave = noff && tudo_zero(off, noff);
    (*leituras)++;
    buf_fmt(b, ",\"endereco\":\"0x%llx\"", (unsigned long long)end);
    if(ler_memoria(pid, end, atual, (size_t)non)) {
      estado = cave ? "cave" : "erro";
      if(cave) c->caves++;
      else c->erros++;
    } else {
      c->lidos++;
      buf_str(b, ",\"lido\":");
      hex_curto(b, atual, non);
      if(noff && !memcmp(atual, off, (size_t)noff)) {
        estado = cave ? "cave" : "desligado";
        if(cave) c->caves++;
        else c->desligados++;
      } else if(!memcmp(atual, on, (size_t)non)) {
        estado = "ligado";
        c->ligados++;
      } else {
        estado = "diferente";
        c->diferentes++;
      }
    }
  }
  buf_str(b, ",\"estado\":");
  buf_json(b, estado);
  buf_fmt(b, ",\"bytes\":%d}", non > 0 ? non : 0);
}

/* As cheats de um arquivo, com a leitura de cada trecho. */
static void arquivo_cheats(buf_t *b, const arquivo_t *a, const jogo_t *j, const processos_t *pr, int *leituras, int *primeiro,
                           contagem_t *total) {
  buf_t dados = {0};
  const char *erro = "";
  jv_t *r = NULL;
  if(ler_arquivo(a->caminho, &dados, MAX_JSON)) erro = "arquivo grande demais ou ilegivel";
  else r = jv_ler(dados.d, dados.n, &erro);
  buf_free(&dados);
  buf_fmt(b, "%s{\"arquivo\":", *primeiro ? "" : ",");
  *primeiro = 0;
  buf_json(b, a->nome);
  buf_str(b, ",\"origem\":");
  buf_json(b, a->origem);
  if(!r || r->tipo != JV_OBJETO) {
    if(r) erro = "o arquivo nao e um objeto JSON";
    buf_str(b, ",\"erro\":");
    buf_json(b, erro);
    buf_str(b, ",\"mods\":[]}");
    jv_liberar(r);
    return;
  }
  const char *processo = jv_txt(r, "process");
  if(!*processo) processo = "eboot.bin";
  const char *modulo = base_nome(processo);
  /* base do modulo: o primeiro processo do jogo que tiver o modulo */
  int pid = -1, tem_base = 0;
  uint64_t base = 0;
  for(int i = 0; i < pr->n && !tem_base; i++)
    if(!base_do_modulo(pr->pids[i], modulo, &base)) { tem_base = 1; pid = pr->pids[i]; }
  if(!tem_base && pr->n) pid = pr->pids[0];
  buf_str(b, ",\"jogo\":");
  buf_json(b, jv_txt(r, "name"));
  buf_str(b, ",\"processo\":");
  buf_json(b, processo);
  buf_fmt(b, ",\"versao_confere\":%s,\"pid\":%d", !strcmp(jv_txt(r, "version"), j->versao) ? "true" : "false", pid);
  if(tem_base) buf_fmt(b, ",\"base\":\"0x%llx\"", (unsigned long long)base);
  buf_str(b, ",\"creditos\":[");
  const jv_t *cr = jv_campo(r, "credits");
  if(!cr) cr = jv_campo(r, "authors");
  int k = 0;
  for(const jv_t *x = cr && cr->tipo == JV_LISTA ? cr->filho : NULL; x && k < 10; x = x->prox) {
    if(x->tipo != JV_TEXTO) continue;
    if(k++) buf_str(b, ",");
    buf_json(b, x->texto);
  }
  buf_str(b, "],\"mods\":[");
  const jv_t *mods = jv_campo(r, "mods");
  int nm = 0;
  for(const jv_t *mo = mods && mods->tipo == JV_LISTA ? mods->filho : NULL; mo && nm < 300; mo = mo->prox) {
    if(mo->tipo != JV_OBJETO) continue;
    buf_str(b, nm++ ? ",{\"nome\":" : "{\"nome\":");
    buf_json(b, jv_txt(mo, "name"));
    buf_str(b, ",\"descricao\":");
    buf_json(b, jv_txt(mo, "description"));
    buf_str(b, ",\"tipo\":");
    buf_json(b, jv_txt(mo, "type"));
    buf_str(b, ",\"trechos\":[");
    contagem_t c = {0};
    const jv_t *mem = jv_campo(mo, "memory");
    int nt = 0;
    for(const jv_t *m = mem && mem->tipo == JV_LISTA ? mem->filho : NULL; m && nt < 200; m = m->prox) {
      if(m->tipo != JV_OBJETO) continue;
      if(nt++) buf_str(b, ",");
      trecho(b, m, pid, tem_base, base, leituras, &c);
    }
    /* resumo da cheat: diferente > erro > misto > ligado > desligado > cave */
    const char *estado = c.diferentes ? "diferente"
                         : c.erros ? "erro"
                         : !nt ? "vazio"
                         : c.ligados && (c.desligados || c.caves) ? "misto"
                         : c.ligados ? "ligado"
                         : c.desligados ? "desligado"
                         : "cave";
    buf_str(b, "],\"estado\":");
    buf_json(b, estado);
    buf_str(b, "}");
    total->lidos += c.lidos;
    total->desligados += c.desligados;
    total->ligados += c.ligados;
    total->diferentes += c.diferentes;
    total->erros += c.erros;
    total->caves += c.caves;
  }
  buf_str(b, "]}");
  jv_liberar(r);
}

static pthread_mutex_t g_trava_leitura = PTHREAD_MUTEX_INITIALIZER;
static char g_ultimo_resumo[400];

void cheats_json(buf_t *b) {
  jogo_t j;
  jogo_aberto(&j);
  jogo_versao(&j);
#ifdef __PROSPERO__
  const char *simulado = "false";
#else
  const char *simulado = "true";
#endif
  buf_fmt(b, "{\"ok\":true,\"teste\":true,\"somente_leitura\":true,\"simulado\":%s,\"jogo\":{\"tid\":", simulado);
  buf_json(b, j.tid);
  buf_str(b, ",\"tipo\":");
  buf_json(b, j.tipo);
  buf_str(b, ",\"nome\":");
  buf_json(b, j.nome);
  buf_str(b, ",\"versao\":");
  buf_json(b, j.versao);
  buf_str(b, ",\"versao_de\":");
  buf_json(b, j.versao_de);
  buf_str(b, ",\"mestre\":");
  buf_json(b, j.mestre);
  buf_fmt(b, ",\"app_id\":%d},", j.app_id);
  catalogo_json(b);

  arquivo_t *lista = calloc(MAX_ARQUIVOS, sizeof *lista);
  int n = lista && j.versao[0] && j.tid[0] ? achar_arquivos(&j, lista, MAX_ARQUIVOS) : 0;
  processos_t pr;
  memset(&pr, 0, sizeof pr);
  pthread_mutex_lock(&g_trava_leitura);
  if(n) processos_do_jogo(&j, &pr);
  buf_str(b, ",\"processos\":[");
  for(int i = 0; i < pr.n; i++) {
    buf_fmt(b, "%s{\"pid\":%d,\"nome\":", i ? "," : "", pr.pids[i]);
    buf_json(b, pr.comm[i]);
    buf_str(b, "}");
  }
  buf_str(b, "],\"arquivos\":[");
  int leituras = 0, primeiro = 1;
  contagem_t total = {0};
  for(int i = 0; i < n; i++) arquivo_cheats(b, &lista[i], &j, &pr, &leituras, &primeiro, &total);
  buf_fmt(b, "],\"resumo\":{\"lidos\":%d,\"desligados\":%d,\"ligados\":%d,\"diferentes\":%d,\"erros\":%d,\"caves\":%d}}",
          total.lidos, total.desligados, total.ligados, total.diferentes, total.erros, total.caves);
  /* diario: uma linha quando o resultado muda (nao a cada consulta da pagina) */
  char resumo[400];
  snprintf(resumo, sizeof resumo,
           "%s %s v%s (%s): %d arquivo(s), %d processo(s)%s%s; lidos %d (desligados %d, ligados %d, diferentes %d, cave %d, erros %d)",
           j.tipo, j.tid[0] ? j.tid : "-", j.versao[0] ? j.versao : "?", j.versao_de[0] ? j.versao_de : "-", n, pr.n,
           pr.n ? " primeiro " : "", pr.n ? pr.comm[0] : "", total.lidos, total.desligados, total.ligados, total.diferentes,
           total.caves, total.erros);
  if(strcmp(resumo, g_ultimo_resumo)) {
    snprintf(g_ultimo_resumo, sizeof g_ultimo_resumo, "%s", resumo);
    diario("cheats: %s", resumo);
  }
  pthread_mutex_unlock(&g_trava_leitura);
  free(lista);
}
