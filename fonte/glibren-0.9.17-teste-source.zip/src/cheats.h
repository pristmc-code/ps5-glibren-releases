/* Game Library Renamer (payload PS5) - cheats do jogo aberto (Fase 0: SO LEITURA).

Mostra no celular/PC as cheats do catalogo (formato .json) para o jogo e a versao abertos e le os bytes atuais da
memoria do jogo para dizer se batem com o valor "desligado" ou "ligado" do arquivo. Nada e gravado na memoria do jogo
nesta fase. Ver src/cheats.c e ps5/ESTUDO-cheats-onionhen.md. */
#pragma once

#include "util.h"

/* GET /api/cheats: {"ok":true,"jogo":{...},"catalogo":{...},"arquivos":[...],"cheats":[...]} com a leitura atual. */
void cheats_json(buf_t *b);
/* POST /api/cheats/catalogo: comeca a baixar o HEN-Cheats-Collection (em segundo plano). 0 = comecou; senao msg. */
int cheats_catalogo_baixar(char *msg, size_t tam);
