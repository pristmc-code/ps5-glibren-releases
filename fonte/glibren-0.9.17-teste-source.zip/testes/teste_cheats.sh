#!/bin/bash
# Testa as cheats (Fase 0, SO LEITURA) na versao de PC. O "jogo" e o testes/cheat_alvo.c compilado como eboot.bin;
# o glibren-pc acha o processo pelo nome, a base pelo /proc/<pid>/maps e le por /proc/<pid>/mem (so leitura).
# Confere: parser .json (campos em qualquer caixa, hex com espacos e 0x, arquivo invalido), escolha do arquivo pela
# versao exata (contentVersion; PS4 pelo param.sfo), pastas do catalogo e do onionHEN, leitura (desligada, ligada,
# nao bate, code cave), pagina e API recusadas no navegador do PS5, Host estranho, download do catalogo (zip local),
# nenhuma rota de escrita e a memoria do alvo intacta depois das leituras.
#   wsl -d Ubuntu-24.04 -u root -- flock /tmp/ps5-testes.lock bash testes/teste_cheats.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8791; PORTA_ZIP=8792
U="http://127.0.0.1:$PORTA"
T=/root/glr-cheats-teste; DADOS=$T/dados
UA_PS5='Mozilla/5.0 (PlayStation; PlayStation 5/12.00) AppleWebKit/605.1.15 (KHTML, like Gecko)'
UA_CEL='Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Mobile Safari/537.36'
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [${2:0:400}] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: tem [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
# valor de um caminho no JSON (python): jq "$R" 'd["arquivos"][0]["mods"][0]["estado"]'
jq() { echo "$1" | python3 -I -c "import json,sys; d=json.load(sys.stdin); print($2)" 2>&1; }
codigo() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
api() { curl -s -A "$UA_CEL" "$U/api/cheats"; }
# estado de uma cheat pelo nome: estado "Vida infinita"
estado() { jq "$R" "[m['estado'] for a in d['arquivos'] for m in a['mods'] if m['nome']=='$1'][0]"; }

rm -rf "$T"; mkdir -p "$DADOS" "$T/appmeta/PPSA01234" "$T/appmeta/CUSA00001" "$T/catalogo/json" "$T/onion" "$T/zip"
printf 'language = pt-BR\n' > "$DADOS/config.ini"

echo "--- alvo de teste (o 'jogo')"
clang-18 -O0 -o "$T/eboot.bin" "$ORIGEM/testes/cheat_alvo.c" || { echo "FALHA nao compilou o alvo"; exit 1; }
"$T/eboot.bin" "$T/alvo.info" & ALVO=$!
for i in 1 2 3 4 5 6 7 8 9 10; do [ -s "$T/alvo.info" ] && break; sleep 0.2; done
read -r PID_ALVO OFF < "$T/alvo.info"
confere "alvo rodando"                 "$PID_ALVO" "$ALVO"
h() { printf '%X' $((16#$OFF + $1)); }   # offset da area + n, em hex

echo "--- jogo instalado (param.json / param.sfo)"
cat > "$T/appmeta/PPSA01234/param.json" <<JSON
{"titleId":"PPSA01234","contentVersion":"01.000.002","masterVersion":"01.00",
 "localizedParameters":{"defaultLanguage":"en-US","en-US":{"titleName":"Jogo de Teste"},"pt-BR":{"titleName":"Jogo de Teste BR"}}}
JSON
python3 -I - "$T/appmeta/CUSA00001/param.sfo" <<'PY'
import struct, sys
itens = [("APP_VER", "01.07"), ("TITLE", "Jogo PS4"), ("TITLE_ID", "CUSA00001"), ("VERSION", "01.00")]
chaves = b""; dados = b""; tabela = b""
for k, v in itens:
    vb = v.encode() + b"\0"
    tabela += struct.pack("<HHIII", len(chaves), 0x0204, len(vb), len(vb), len(dados))
    chaves += k.encode() + b"\0"; dados += vb
ini_chaves = 0x14 + len(tabela)
while len(chaves) % 4: chaves += b"\0"
cab = b"\0PSF" + struct.pack("<IIII", 0x101, ini_chaves, ini_chaves + len(chaves), len(itens))
open(sys.argv[1], "wb").write(cab + tabela + chaves + dados)
PY

echo "--- arquivos de cheat"
# catalogo (HEN-Cheats-Collection): o certo (3 cheats), versao errada e um JSON quebrado
cat > "$T/catalogo/json/PPSA01234_01.000.002_aaaaaaaa.json" <<JSON
{
  "name": "Jogo de Teste", "id": "PPSA01234", "version": "01.000.002", "process": "eboot.bin",
  "mods": [
    {"name": "Vida infinita", "description": "nao perde vida", "type": "checkbox",
     "memory": [{"offset": "$(h 0)", "on": "90909090909090", "off": "C680CC00000000"}]},
    {"name": "Dinheiro", "description": "", "type": "checkbox",
     "memory": [{"offset": "7FFFFFFF000", "on": "F048014708C74708", "off": "0000000000000000"},
                {"offset": "$(h 16)", "on": "E98E26A57C", "off": "F048014708"}]},
    {"name": "Nao bate", "description": "", "type": "checkbox",
     "memory": [{"offset": "$(h 32)", "on": "9090909090", "off": "1122334455"}]},
    {"name": "Secao 1", "type": "checkbox", "memory": [{"offset": "10", "on": "90", "off": "00", "section": 1}]},
    {"name": "Hex ruim", "type": "checkbox", "memory": [{"offset": "zz", "on": "9", "off": "00"}]}
  ],
  "credits": ["Autor A", "Autor B"]
}
JSON
echo '{"name":"versao errada","version":"01.000.001","process":"eboot.bin","mods":[{"name":"Nao deve aparecer","memory":[]}]}' \
  > "$T/catalogo/json/PPSA01234_01.000.001_bbbbbbbb.json"
echo '{"name": "quebrado", "mods": [ {"name": "x", }' > "$T/catalogo/json/PPSA01234_01.000.002_dddddddd.json"
echo '{"name":"prefixo parecido","mods":[{"name":"Nao deve aparecer 2","memory":[]}]}' > "$T/catalogo/json/PPSA01234_01.000.0021.json"
# onionHEN: nomes em outra caixa, offset com 0x, hex com espacos; e um .shn (fora desta fase)
cat > "$T/onion/PPSA01234_01.000.002.json" <<JSON
{"Name": "Jogo de Teste (onion)", "Version": "01.000.002", "Process": "eboot.bin",
 "Mods": [{"Name": "Hex com espacos", "Type": "checkbox", "Memory": [{"Offset": "0x$(h 48)", "On": "AA BB", "Off": "de ad"}]}],
 "Authors": ["Autor C"]}
JSON
echo 'shn' > "$T/onion/PPSA01234_01.000.002.shn"
# PS4
cat > "$T/catalogo/json/CUSA00001_01.07_eeeeeeee.json" <<JSON
{"name":"Jogo PS4","id":"CUSA00001","version":"01.07","process":"eboot.bin",
 "mods":[{"name":"Municao","type":"checkbox","memory":[{"offset":"$(h 0)","on":"90909090909090","off":"C680CC00000000"}]}]}
JSON
echo '{"name":"PS4 versao base","mods":[{"name":"Nao deve aparecer 3","memory":[]}]}' > "$T/catalogo/json/CUSA00001_01.00_ffffffff.json"

: > "$T/abertos"
inicia() { env GLR_TESTE_ABERTOS="$T/abertos" GLR_TESTE_APPMETA="$T/appmeta" GLR_TESTE_CHEATS="$T/catalogo" GLR_TESTE_ONION="$T/onion" GLR_TESTE_CHEATS_PID="$PID_ALVO" \
  GLR_TESTE_BASE="http://127.0.0.1:$PORTA_ZIP/" GLR_TESTE_CHEATS_URL="http://127.0.0.1:$PORTA_ZIP/catalogo.zip" "$@" \
  "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
inicia

echo "--- recusa no navegador do PS5 e Host estranho"
confere "PS5: pagina recusada"         "$(codigo -A "$UA_PS5" $U/cheats)" "403"
confere "PS5: api recusada"            "$(codigo -A "$UA_PS5" $U/api/cheats)" "403"
confere "PS5 (caixa baixa): recusada"  "$(codigo -A 'mozilla playstation 5' $U/api/cheats)" "403"
confere "PS5: mensagem"                "$(curl -s -A "$UA_PS5" $U/cheats)" "so para o celular ou o PC"
confere "PS5: catalogo recusado"       "$(codigo -A "$UA_PS5" -X POST -H 'X-GLR: 1' $U/api/cheats/catalogo)" "403"
confere "Host estranho recusado"       "$(codigo -A "$UA_CEL" -H 'Host: ataque.example.com' $U/api/cheats)" "403"
confere "celular: pagina"              "$(curl -s -A "$UA_CEL" $U/cheats)" "Cheats do jogo"
confere "pagina: aviso de banimento"   "$(curl -s -A "$UA_CEL" $U/cheats)" "banir a conta na PSN"
confere "pagina: JOGOS primeiro"       "$(curl -s -A "$UA_CEL" $U/cheats | grep -o '<nav class="atalhos"><a href="/" id="tVoltar">')" 'tVoltar'

echo "--- sem rota de escrita"
confere "POST /api/cheats = 404"       "$(codigo -A "$UA_CEL" -X POST -H 'X-GLR: 1' $U/api/cheats)" "404"
confere "PUT /api/cheats = 405"        "$(codigo -A "$UA_CEL" -X PUT -H 'X-GLR: 1' $U/api/cheats)" "405"
for r in ligar desligar escrever aplicar gravar; do
  confere "POST /api/cheats/$r = 404"  "$(codigo -A "$UA_CEL" -X POST -H 'X-GLR: 1' $U/api/cheats/$r)" "404"
done
confere "catalogo sem X-GLR = 403"     "$(codigo -A "$UA_CEL" -X POST $U/api/cheats/catalogo)" "403"
# no codigo: nenhuma chamada de escrita na memoria (fora dos comentarios) e /proc/<pid>/mem so em O_RDONLY
SEM_COMENT=$(sed -e 's://.*$::' "$ORIGEM/src/cheats.c" | perl -0pe 's:/\*.*?\*/::gs')
nao_tem "cheats.c sem copyin"          "$SEM_COMENT" "copyin"
nao_tem "cheats.c sem ptrace/mdbg"     "$SEM_COMENT" "ptrace\|mdbg_\|pt_attach"
nao_tem "cheats.c sem /mem em escrita" "$(echo "$SEM_COMENT" | grep -A3 '/proc/%d/mem')" "O_RDWR\|O_WRONLY"
if [ -x /opt/ps5-payload-sdk/bin/prospero-clang ]; then
  (cd "$ORIGEM" && /opt/ps5-payload-sdk/bin/prospero-clang -Wall -Werror -O2 -Isrc -Ibuild -c src/cheats.c -o "$T/cheats.o" 2>&1)
  IMPORTA=$(/opt/ps5-payload-sdk/bin/llvm-nm -u "$T/cheats.o" 2>/dev/null)
  confere "PS5: cheats.o importa a leitura" "$IMPORTA" "kernel_proc_copyout"
  nao_tem "PS5: cheats.o sem escrita"  "$IMPORTA" "copyin\|mdbg\|ptrace\|setlong\|setint\|setchar\|setshort\|mprotect"
else
  echo "PULADO sem o SDK do PS5 (conferencia do cheats.o)"
fi

echo "--- nenhum jogo aberto"
R=$(api)
confere "menu: tipo"                   "$R" '"tipo":"menu"'
confere "menu: nenhum arquivo"         "$R" '"arquivos":\[\]'
confere "somente leitura"              "$R" '"somente_leitura":true'

echo "--- jogo de PS5: escolha do arquivo e leitura"
echo PPSA01234 > "$T/abertos"
R=$(api)
confere "versao do param.json"         "$(jq "$R" "d['jogo']['versao'], d['jogo']['versao_de'], d['jogo']['mestre']")" "01.000.002 contentVersion 01.00"
confere "nome do jogo"                 "$R" '"nome":"Jogo de Teste BR"'
confere "arquivos escolhidos"          "$(jq "$R" "[a['arquivo'] for a in d['arquivos']]")" "\['PPSA01234_01.000.002.json', 'PPSA01234_01.000.002_aaaaaaaa.json', 'PPSA01234_01.000.002_dddddddd.json'\]"
confere "origens"                      "$(jq "$R" "[a['origem'] for a in d['arquivos']]")" "\['onionhen', 'catalogo', 'catalogo'\]"
nao_tem "versao errada fora"           "$R" "Nao deve aparecer"
confere "JSON quebrado: erro"          "$(jq "$R" "d['arquivos'][2].get('erro','')")" "esperava"
confere "processo achado"              "$(jq "$R" "d['processos'][0]")" "'pid': $PID_ALVO, 'nome': 'eboot.bin'"
confere "versao confere no arquivo"    "$(jq "$R" "d['arquivos'][1]['versao_confere']")" "True"
confere "creditos"                     "$(jq "$R" "d['arquivos'][1]['creditos']")" "Autor A"
confere "creditos (Authors)"           "$(jq "$R" "d['arquivos'][0]['creditos']")" "Autor C"
confere "Vida infinita: desligada"     "$(estado 'Vida infinita')" "^desligado$"
confere "Vida infinita: bytes lidos"   "$(jq "$R" "d['arquivos'][1]['mods'][0]['trechos'][0]['lido']")" "^C680CC00000000$"
confere "Dinheiro: cave + desligado"   "$(estado 'Dinheiro')" "^desligado$"
confere "Dinheiro: trecho cave"        "$(jq "$R" "d['arquivos'][1]['mods'][1]['trechos'][0]['estado']")" "^cave$"
confere "Nao bate: diferente"          "$(estado 'Nao bate')" "^diferente$"
confere "Nao bate: lido"               "$(jq "$R" "d['arquivos'][1]['mods'][2]['trechos'][0]['lido']")" "^9999999999$"
confere "secao != 0: fase 1"           "$(jq "$R" "d['arquivos'][1]['mods'][3]['trechos'][0]['estado']")" "^secao$"
confere "hex invalido"                 "$(jq "$R" "d['arquivos'][1]['mods'][4]['trechos'][0]['estado']")" "^invalido$"
confere "onion: chaves em outra caixa" "$(estado 'Hex com espacos')" "^desligado$"
confere "resumo"                       "$(jq "$R" "d['resumo']")" "'lidos': 4, 'desligados': 3, 'ligados': 0, 'diferentes': 1"
confere "base do eboot"                "$(jq "$R" "d['arquivos'][1]['base']")" "^0x"
confere "diario: resumo"               "$(cat $DADOS/glibren.log)" "cheats: ps5 PPSA01234 v01.000.002 (contentVersion): 3 arquivo(s), 1 processo(s)"

echo "--- outra ferramenta liga a cheat (o proprio alvo grava): a leitura mostra ligada"
kill -USR2 $ALVO; sleep 0.3; SOMA1=$(cat "$T/alvo.info.soma")
for i in 1 2 3 4 5; do api > /dev/null; done
kill -USR2 $ALVO; sleep 0.3; SOMA2=$(cat "$T/alvo.info.soma")
confere "memoria intacta apos 6 leituras" "$SOMA2" "^$SOMA1$"
kill -USR1 $ALVO; sleep 0.3
R=$(api)
confere "Vida infinita: ligada"        "$(estado 'Vida infinita')" "^ligado$"
confere "resumo: 1 ligada"             "$(jq "$R" "d['resumo']['ligados']")" "^1$"

echo "--- modulo que nao existe"
sed -i 's/"process": "eboot.bin"/"process": "mgs4\/mgs4.elf"/' "$T/catalogo/json/PPSA01234_01.000.002_aaaaaaaa.json"
R=$(api)
confere "sem base: processo"           "$(jq "$R" "d['arquivos'][1]['processo']")" "mgs4/mgs4.elf"
confere "sem base: estado"             "$(estado 'Vida infinita')" "^erro$"
confere "sem base: trecho"             "$(jq "$R" "d['arquivos'][1]['mods'][0]['trechos'][0]['estado']")" "^sem_base$"

echo "--- jogo de PS4 (param.sfo: maior entre VERSION e APP_VER)"
echo CUSA00001 > "$T/abertos"
R=$(api)
confere "PS4: tipo"                    "$R" '"tipo":"ps4"'
confere "PS4: versao"                  "$(jq "$R" "d['jogo']['versao'], d['jogo']['versao_de']")" "01.07 APP_VER"
confere "PS4: nome"                    "$R" '"nome":"Jogo PS4"'
confere "PS4: arquivo"                 "$(jq "$R" "[a['arquivo'] for a in d['arquivos']]")" "\['CUSA00001_01.07_eeeeeeee.json'\]"
confere "PS4: leitura (ligada pelo alvo)" "$(estado 'Municao')" "^ligado$"

echo "--- jogo sem cheats / sem versao"
echo PPSA09999 > "$T/abertos"
R=$(api)
confere "sem versao"                   "$(jq "$R" "d['jogo']['versao']")" "^$"
confere "sem arquivo"                  "$R" '"arquivos":\[\]'
para

echo "--- download do catalogo (zip local no lugar do GitHub)"
python3 -I - "$T/zip/catalogo.zip" <<'PY'
import sys, zipfile
with zipfile.ZipFile(sys.argv[1], "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("HEN-Cheats-Collection-master/", "")
    z.writestr("HEN-Cheats-Collection-master/cheats/json/PPSA01234_01.000.002_12345678.json",
               '{"name":"Do zip","version":"01.000.002","process":"eboot.bin","mods":[{"name":"Do zip","memory":[]}]}')
    z.writestr("HEN-Cheats-Collection-master/cheats/json/PPSA05344_04.001.000_de306fb7.json", '{"name":"Park Beyond","mods":[]}')
    z.writestr("HEN-Cheats-Collection-master/cheats/shn/PPSA01234_01.000.002.shn", "shn")
    z.writestr("HEN-Cheats-Collection-master/cheats/json.txt", "x")
    z.writestr("HEN-Cheats-Collection-master/README.md", "readme")
PY
(cd "$T/zip" && exec python3 -I -m http.server $PORTA_ZIP --bind 127.0.0.1 > /dev/null 2>&1) & SRV=$!
for i in $(seq 1 50); do [ "$(codigo http://127.0.0.1:$PORTA_ZIP/catalogo.zip)" = 200 ] && break; sleep 0.2; done
echo PPSA01234 > "$T/abertos"
inicia
R=$(curl -s -A "$UA_CEL" -X POST -H 'X-GLR: 1' $U/api/cheats/catalogo)
confere "catalogo: comecou"            "$R" '"ok":true'
for i in $(seq 1 100); do R=$(api); echo "$R" | grep -q '"estado":"pronto"\|"estado":"erro"' && break; sleep 0.3; done
confere "catalogo: pronto"             "$(jq "$R" "d['catalogo']['estado'], d['catalogo']['arquivos']")" "pronto 2"
confere "catalogo: so os .json"        "$(ls "$T/catalogo/json" | tr '\n' ' ')" "^PPSA01234_01.000.002_12345678.json PPSA05344_04.001.000_de306fb7.json $"
confere "catalogo: substituiu a pasta" "$(jq "$R" "[a['arquivo'] for a in d['arquivos']]")" "PPSA01234_01.000.002_12345678.json"
nao_tem "catalogo: sem sobra"          "$(ls -a "$T/catalogo")" "json.novo\|json.antigo\|parcial"
confere "catalogo: diario"             "$(cat $DADOS/glibren.log)" "cheats: catalogo pronto: 2 arquivos .json"
# zip sem cheats: erro e a pasta antiga fica
python3 -I -c "import zipfile; zipfile.ZipFile('$T/zip/catalogo.zip','w').writestr('x/README.md','x')"
curl -s -A "$UA_CEL" -X POST -H 'X-GLR: 1' $U/api/cheats/catalogo > /dev/null
for i in $(seq 1 100); do R=$(api); echo "$R" | grep -q '"estado":"pronto"\|"estado":"erro"' && break; sleep 0.3; done
confere "zip sem cheats: erro"         "$(jq "$R" "d['catalogo']['erro']")" "o zip nao tem cheats/json"
confere "zip sem cheats: antiga fica"  "$(ls "$T/catalogo/json" | wc -l)" "^2$"
rm -f "$T/zip/catalogo.zip"
curl -s -A "$UA_CEL" -X POST -H 'X-GLR: 1' $U/api/cheats/catalogo > /dev/null
for i in $(seq 1 100); do R=$(api); echo "$R" | grep -q '"estado":"pronto"\|"estado":"erro"' && break; sleep 0.3; done
confere "sem o zip: HTTP 404"          "$(jq "$R" "d['catalogo']['erro']")" "HTTP 404"
para
kill $SRV 2>/dev/null

kill $ALVO 2>/dev/null; wait $ALVO 2>/dev/null
rm -rf "$T"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
