#!/bin/bash
# 0.9.49: pasta de backup em minusculo (<disco>/backup), originais soltos nela, arrumacao ao iniciar e lista um nivel
# abaixo (src/backup.c backup_arrumar, src/arquivos.c, src/config.c), na versao de PC. Discos de mentira por
# GLR_TESTE_RAIZES; ShadowMount+ falso (testes/smp_falso.py). Casos:
#   D1 so BACKUP (antigo): a pasta vira "backup"; subpasta do glibren (marcador "source":"glibren") sobe os originais
#      (arquivo e pasta de jogo) e some; subpasta da Jobe, sem marcador ou com outra coisa dentro ficam e aparecem na
#      lista um nivel abaixo (com "raiz" e "backup":true); config.ini acompanha; contagem da pasta;
#      mover de volta para a pasta de jogos e excluir (a subpasta vazia e o marcador saem), renomear, caminhos recusados;
#   D2 as duas pastas com conflito: o que nao conflita muda, o xara fica na antiga (registrado), a antiga continua;
#   D3 so "backup" com subpasta do glibren: sobe;
#   D4 BACKUP com arquivo gravado agora: fica para depois; "folder = .../backup/" na lista com BACKUP no disco: a lista
#      passa a usar a grafia que existe (config_corrigir_caixa);
#   D5 jogo montado pelo ShadowMount+ a partir do BACKUP: fica para depois.
#   D6 download pela metade (.part) parado ha horas em BACKUP/<jogo>/: fica para depois.
# Disco que nao diferencia caixa (exFAT): nao simulado aqui (o codigo renomeia por um nome intermediario e confere pela
# listagem).
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_backup_lista.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8941; PORTA_SMP=8942
L="http://127.0.0.1:$PORTA"
T=/root/glr-bklista; DADOS=$T/dados; D1=$T/d1; D2=$T/d2; D3=$T/d3; D4=$T/d4; D5=$T/d5
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
existe() { if [ -e "$2" ]; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: nao existe $2"; fi; }
sumiu() { if [ -e "$2" ]; then falhas=$((falhas+1)); echo "FALHA $1: ainda existe $2"; else ok=$((ok+1)); echo "OK   $1"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
espera() { for _ in $(seq 1 80); do curl -s $L/api/tarefas | grep -q '"estado":"\(fila\|rodando\)"' || return; sleep 0.25; done; }
ultima() { curl -s $L/api/tarefas | python3 -I -c 'import json,sys; t=json.load(sys.stdin)["tarefas"]; print(json.dumps(max(t, key=lambda x: x["id"]), ensure_ascii=False))'; }
tarefa() { post --data-urlencode "tipo=$1" --data-urlencode "pasta=$2" --data-urlencode "de=$3" --data-urlencode "destino=${4:-}" $L/api/tarefas; }
itens() { curl -s $L/api/escanear | python3 -I -c '
import json, sys
for i in json.load(sys.stdin)["itens"]:
    print(json.dumps(i, ensure_ascii=False, sort_keys=True))'; }
marca() { printf '{"titleId":"%s","platform":"ps5","format":"exfat","source":"%s"}' "$2" "$3" > "$1/.jobe-backup.json"; }
jogo() { mkdir -p "$1/sce_sys"; echo elf > "$1/eboot.bin"; printf '{"titleId":"%s"}' "$2" > "$1/sce_sys/param.json"; }

pkill -f "smp_falso.py $PORTA_SMP" 2>/dev/null
rm -rf "$T"; mkdir -p "$DADOS" "$T/smp" $D1/homebrew $D2/homebrew $D3/homebrew $D4/homebrew $D5/homebrew
# D1: so BACKUP
mkdir -p "$D1/BACKUP/Hades" "$D1/BACKUP/DaJobe" "$D1/BACKUP/SemMarca" "$D1/BACKUP/Pasta" "$D1/BACKUP/Misto/notas" "$D1/BACKUP/_temp"
echo hades > "$D1/BACKUP/Hades/Hades-PPSA03355-US-PS5.exfat"; marca "$D1/BACKUP/Hades" PPSA03355 glibren
echo solto > "$D1/BACKUP/Solto-PPSA00001.exfat"
echo jobe > "$D1/BACKUP/DaJobe/x-PPSA00002.pkg"; marca "$D1/BACKUP/DaJobe" PPSA00002 jobe
echo sem > "$D1/BACKUP/SemMarca/y-PPSA00003.exfat"
jogo "$D1/BACKUP/Pasta/PastaJogo-PPSA05555" PPSA05555; marca "$D1/BACKUP/Pasta" PPSA05555 glibren
echo misto > "$D1/BACKUP/Misto/z-PPSA00004.exfat"; echo nota > "$D1/BACKUP/Misto/notas/leia.txt"; marca "$D1/BACKUP/Misto" PPSA00004 glibren
# D2: as duas, com conflito
mkdir -p "$D2/BACKUP" "$D2/backup"
echo antigo-a > "$D2/BACKUP/a-PPSA00010.exfat"; echo antigo-b > "$D2/BACKUP/b-PPSA00011.exfat"; echo novo-a > "$D2/backup/a-PPSA00010.exfat"
# D3: so backup, com subpasta do glibren
mkdir -p "$D3/backup/Jogo"; echo tres > "$D3/backup/Jogo/c-PPSA00020.exfat"; marca "$D3/backup/Jogo" PPSA00020 glibren
# D5: jogo montado a partir do BACKUP
mkdir -p "$D5/BACKUP"; echo montado > "$D5/BACKUP/m-PPSA00040.exfat"
# D6: download da Jobe parado ha horas em BACKUP/<jogo>/ (.part): fica para depois
mkdir -p "$T/d6/homebrew" "$T/d6/BACKUP/Baixando"; echo meio > "$T/d6/BACKUP/Baixando/jogo-PPSA00050.pkg.part"
# tudo "antigo" (a arrumacao nao mexe no que foi gravado ha menos de 15 minutos)...
find "$T" -exec touch -d '3 hours ago' {} +
# ...menos o D4: BACKUP com um arquivo de agora
mkdir -p "$D4/BACKUP"; echo agora > "$D4/BACKUP/n-PPSA00030.exfat"
printf 'language = pt-BR\nfolder = %s/\nfolder = %s/\nfolder = %s/\nfolder = %s/\nfolder = %s/\nfolder = %s/\nfolder = %s/\n' \
  "$D1/homebrew" "$D1/BACKUP" "$D2/BACKUP" "$D3/backup" "$D4/backup" "$D5/BACKUP" "$D2/homebrew" > "$DADOS/config.ini"
printf 'folder = %s/
' "$T/d6/homebrew" >> "$DADOS/config.ini"
python3 -I -c 'import json,sys; json.dump({"games":[{"path":sys.argv[1],"title_id":"PPSA00040","mounted":True}],"images":[]}, open(sys.argv[2],"w"))' \
  "$D5/BACKUP/m-PPSA00040.exfat" "$T/smp/estado.json"
(exec python3 -I "$ORIGEM/testes/smp_falso.py" $PORTA_SMP "$T/smp") >> "$T/smp.log" 2>&1 &
sleep 0.5
GLR_TESTE_SONDA_S=0 GLR_TESTE_SMP_PORTA=$PORTA_SMP GLR_TESTE_PROCESSOS="shadowmountplus.elf" GLR_TESTE_CONV_VIGIA_S=0 \
  GLR_TESTE_RAIZES="$D1:$D2:$D3:$D4:$D5:$T/d6" "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!
for _ in $(seq 1 40); do grep -q 'c-PPSA00020.exfat ->' "$DADOS/glibren.log" 2>/dev/null && break; sleep 0.25; done
sleep 0.5
LOG=$(cat "$DADOS/glibren.log")

echo "--- D1: so BACKUP -> backup, subpastas do glibren sobem"
confere "D1: pasta em minusculo"            "$(ls "$D1" | tr '\n' ' ')" '^backup homebrew $'
existe "D1: Hades solto"                    "$D1/backup/Hades-PPSA03355-US-PS5.exfat"
sumiu  "D1: subpasta Hades saiu"            "$D1/backup/Hades"
existe "D1: pasta de jogo subiu"            "$D1/backup/PastaJogo-PPSA05555/eboot.bin"
sumiu  "D1: subpasta Pasta saiu"            "$D1/backup/Pasta"
existe "D1: da Jobe fica"                   "$D1/backup/DaJobe/x-PPSA00002.pkg"
existe "D1: marcador da Jobe fica"          "$D1/backup/DaJobe/.jobe-backup.json"
existe "D1: sem marcador fica"              "$D1/backup/SemMarca/y-PPSA00003.exfat"
existe "D1: com outra coisa dentro fica"    "$D1/backup/Misto/z-PPSA00004.exfat"
existe "D1: _temp intacta"                  "$D1/backup/_temp"
confere "D1: diario da pasta"               "$LOG" "arrumacao: pasta $D1/BACKUP renomeada para $D1/backup"
confere "D1: diario item a item"            "$LOG" "arrumacao: $D1/backup/Hades/Hades-PPSA03355-US-PS5.exfat -> $D1/backup/Hades-PPSA03355-US-PS5.exfat"
confere "D1: diario da duvida"              "$LOG" "arrumacao: $D1/backup/Misto fica como esta"
confere "D1: config.ini acompanha"          "$(cat $DADOS/config.ini)" "^folder = $D1/backup/\$"
nao_tem "D1: config.ini sem o nome antigo"  "$(cat $DADOS/config.ini)" "^folder = $D1/BACKUP/"

echo "--- D1: lista (solto + um nivel abaixo)"
I=$(itens)
confere "lista: solto"                      "$I" "\"backup\": true, \"nome\": \"Solto-PPSA00001.exfat\", \"pasta\": \"$D1/backup/\""
confere "lista: o que subiu"                "$I" "\"nome\": \"Hades-PPSA03355-US-PS5.exfat\", \"pasta\": \"$D1/backup/\""
confere "lista: pasta de jogo"              "$I" "\"nome\": \"PastaJogo-PPSA05555\", \"pasta\": \"$D1/backup/\", \"tipo\": \"pasta\""
confere "lista: um nivel abaixo (Jobe)"     "$I" "\"backup\": true, \"nome\": \"x-PPSA00002.pkg\", \"pasta\": \"$D1/backup/DaJobe/\", \"raiz\": \"$D1/backup/\""
confere "lista: um nivel abaixo (sem marca)" "$I" "\"nome\": \"y-PPSA00003.exfat\", \"pasta\": \"$D1/backup/SemMarca/\", \"raiz\": \"$D1/backup/\""
confere "lista: um nivel abaixo (misto)"    "$I" "\"nome\": \"z-PPSA00004.exfat\", \"pasta\": \"$D1/backup/Misto/\""
nao_tem "lista: marcador nao e item"        "$I" 'jobe-backup'
nao_tem "lista: dois niveis abaixo nao"     "$I" 'leia.txt'
confere "contagem da pasta"                 "$(curl -s $L/api/escanear)" "{\"pasta\":\"$D1/backup/\",\"existe\":true,\"qtd\":6,"

echo "--- D1: mover de volta, excluir, renomear, recusas"
confere "mover de volta: na fila"           "$(tarefa mover "$D1/backup/DaJobe/" x-PPSA00002.pkg "$D1/homebrew")" '"criadas":1'
espera
confere "mover de volta: feita"             "$(ultima)" '"tipo": "mover", "estado": "feita"'
existe "mover de volta: chegou"             "$D1/homebrew/x-PPSA00002.pkg"
sumiu  "mover de volta: subpasta e marcador sairam" "$D1/backup/DaJobe"
tarefa excluir "$D1/backup/SemMarca/" y-PPSA00003.exfat > /dev/null; espera
confere "excluir: feita"                    "$(ultima)" '"tipo": "excluir", "estado": "feita"'
sumiu  "excluir: subpasta vazia saiu"       "$D1/backup/SemMarca"
confere "renomear na subpasta"              "$(post --data-urlencode "pasta=$D1/backup/Misto/" -d de=z-PPSA00004.exfat -d para=Zeta-PPSA00004.exfat $L/api/renomear)" '"ok":true'
existe "renomear: nome novo"                "$D1/backup/Misto/Zeta-PPSA00004.exfat"
tarefa excluir "$D1/backup/Misto/" Zeta-PPSA00004.exfat > /dev/null; espera
existe "subpasta com outra coisa fica"      "$D1/backup/Misto/notas/leia.txt"
confere "dois niveis abaixo: recusado"      "$(tarefa excluir "$D1/backup/Misto/notas/" leia.txt)" '"criadas":0.*"fora_das_pastas":1'
confere "subpasta fora do backup: recusada" "$(tarefa excluir "$D1/homebrew/sub/" x)" '"criadas":0.*"fora_das_pastas":1'
confere "caminho com ..: recusado"          "$(tarefa excluir "$D1/backup/Misto/../../homebrew" x-PPSA00002.pkg)" '"criadas":0'
confere "pasta de jogo nao e subpasta"      "$(tarefa excluir "$D1/backup/PastaJogo-PPSA05555/" eboot.bin)" '"criadas":0.*"fora_das_pastas":1'
existe "pasta de jogo intacta"              "$D1/backup/PastaJogo-PPSA05555/eboot.bin"
confere "destino continua so pasta da lista" "$(tarefa mover "$D1/homebrew" x-PPSA00002.pkg "$D1/backup/Misto/")" '"criadas":0'

echo "--- D2: as duas pastas, com conflito"
confere "D2: o que nao conflita mudou"      "$(cat "$D2/backup/b-PPSA00011.exfat" 2>&1)" '^antigo-b$'
confere "D2: o xara ficou na antiga"        "$(cat "$D2/BACKUP/a-PPSA00010.exfat" 2>&1)" '^antigo-a$'
confere "D2: o da nova nao foi sobrescrito" "$(cat "$D2/backup/a-PPSA00010.exfat" 2>&1)" '^novo-a$'
confere "D2: conflito no diario"            "$LOG" "arrumacao: $D2/BACKUP/a-PPSA00010.exfat fica onde esta (ja existe $D2/backup/a-PPSA00010.exfat)"
confere "D2: config.ini aponta a nova"      "$(cat $DADOS/config.ini)" "^folder = $D2/backup/\$"

echo "--- D3: so backup, subpasta do glibren sobe"
existe "D3: subiu"                          "$D3/backup/c-PPSA00020.exfat"
sumiu  "D3: subpasta saiu"                  "$D3/backup/Jogo"

echo "--- D4: gravado agora = fica para depois; lista usa a grafia que existe"
existe "D4: BACKUP intacto"                 "$D4/BACKUP/n-PPSA00030.exfat"
confere "D4: so BACKUP no disco"            "$(ls "$D4" | tr '\n' ' ')" '^BACKUP homebrew $'
confere "D4: diario"                        "$LOG" "arrumacao: $D4/BACKUP fica para depois (algo foi gravado ali ha menos de 15 minutos"
confere "D4: a lista mostra o arquivo"      "$I" "\"nome\": \"n-PPSA00030.exfat\", \"pasta\": \"$D4/BACKUP/\""
confere "D4: config.ini com a grafia real"  "$(cat $DADOS/config.ini)" "^folder = $D4/BACKUP/\$"
confere "D4: diario da grafia"              "$(cat $DADOS/glibren.log)" "config: pasta da lista $D4/backup/ nao existe; usando $D4/BACKUP/"

echo "--- D5: jogo montado a partir do BACKUP = fica para depois"
existe "D5: BACKUP intacto"                 "$D5/BACKUP/m-PPSA00040.exfat"
confere "D5: diario"                        "$LOG" "arrumacao: $D5/BACKUP fica para depois (ha jogo montado a partir dali"

echo "--- D6: download pela metade (.part antigo) = fica para depois"
existe "D6: BACKUP intacto"                 "$T/d6/BACKUP/Baixando/jogo-PPSA00050.pkg.part"
confere "D6: so BACKUP no disco"            "$(ls "$T/d6" | tr '
' ' ')" '^BACKUP homebrew $'
confere "D6: diario"                        "$LOG" "arrumacao: $T/d6/BACKUP fica para depois"

kill $PID 2>/dev/null; wait $PID 2>/dev/null
pkill -f "smp_falso.py $PORTA_SMP" 2>/dev/null
echo "=== $ok ok, $falhas falhas"
[ $falhas -eq 0 ]
