#!/bin/bash
# 0.9.41: "Carregar ao iniciar o glibren" (pagina Payloads), "Instalar de arquivo" (ShadowKraken do dono e kstuff) e as
# regras de seguranca do kstuff, na versao de PC, com elfldr falso (testes/elfldr_falso.py), Dump Forge falso (rodando
# agora), ShadowMount+/ShadowKraken falso (testes/github_falso.py smp) e a sonda do kstuff lida de um arquivo
# (GLR_TESTE_KSTUFF). Casos: quem pode ter a chave (proibidos: tela cheia, PrefBar, ZhiThemes), pareamento, config.ini;
# instalar de arquivo (todos os .elf, sugeridos primeiro, pasta do payload manager primeiro, versao pelo marcador do ELF,
# "mais nova", nome fixo -PristMC, .anterior + Voltar, origem intacta, fora dos discos/link/nao-ELF recusados); ligado e
# nao rodando -> envia; ligado e rodando -> nao envia; desligado -> nada; elfldr atrasado; elfldr ausente; montadores
# exclusivos; kraken-mount com o ShadowMount+ rodando -> nao carrega; ShadowKraken com o SMP -> carrega; ShadowKraken ja
# rodando -> nao; kstuff: "nao carregado" -> envia uma vez e confirma; marcador do boot impede repetir; "carregado" e
# "desconhecido" -> nao envia; kstuff antes dos outros; kstuff que nao confirma -> os outros seguem. No fim a pagina
# Payloads (testes/teste_autoload_pagina.mjs) em 360 e 1280, se houver Node + Playwright no Windows.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_autoload.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8971; PEL=8972; PDF=8973; PSMP=8974
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R="http://$IP:$PORTA"
T=/root/glr-autoload; DADOS=$T/dados; PAY=$DADOS/payloads; GH=$T/gh
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$(echo "$2" | head -c 700)] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
codigo() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
estado() { curl -s "$L/api/payloads"; }
campo() { estado | python3 -c "import json,sys; d=json.load(sys.stdin); i=[x for x in d['itens'] if x['id']=='$1'][0]; v=eval('i'+sys.argv[1]); print(json.dumps(v) if not isinstance(v,str) else v)" "$2"; }
recebidos() { [ -f $T/el/recebidos ] && wc -l < $T/el/recebidos || echo 0; }
ks_recebidos() { grep -c kstuff $T/el/recebidos 2>/dev/null || echo 0; }
# espera o "carregar ao iniciar" do item terminar (carregado, ja_rodando, erro ou boot)
espera_res() { local v=""; for _ in $(seq 1 ${2:-150}); do v=$(campo "$1" "['autoload_res']" 2>/dev/null); case "$v" in carregado|ja_rodando|erro|boot) break;; esac; sleep 0.2; done; echo "$v"; }
espera_livre() { for _ in $(seq 1 100); do estado | grep -q '"ocupado":false' && return; sleep 0.1; done; }
espera_http() { for _ in $(seq 1 150); do curl -s -o /dev/null -m 2 "$1" && return 0; sleep 0.1; done; echo "AVISO: $1 nao respondeu"; }
liga_el() { mkdir -p $T/el; rm -f $T/el/elfldr.pronto; (exec python3 -I "$ORIGEM/testes/elfldr_falso.py" $PEL $T/el) >> $T/el.log 2>&1 & PID_EL=$!; for _ in $(seq 1 50); do [ -e $T/el/elfldr.pronto ] && break; sleep 0.1; done; }
para_el() { kill $PID_EL 2>/dev/null; wait $PID_EL 2>/dev/null; }
liga_df() { mkdir -p $T/df; (exec python3 -I "$ORIGEM/testes/dumpforge_falso.py" $PDF $T/df) >> $T/df.log 2>&1 & PID_DF=$!; espera_http "http://127.0.0.1:$PDF/api/session"; }
para_df() { kill $PID_DF 2>/dev/null; wait $PID_DF 2>/dev/null; }
config() { printf 'language = pt-BR\nfolder = %s/\n%s' "$T/lista" "${1:+payload_autoload = $1
}" > "$DADOS/config.ini"; }
inicia() {
  GLR_TESTE_ELFLDR=$PEL GLR_TESTE_SONDA_S=0 GLR_TESTE_DUMPFORGE_PORTA=$PDF GLR_TESTE_SMP_PORTA=$PSMP GLR_TESTE_KRAKEN_PORTA=8979 \
  GLR_TESTE_BLUEV_PORTA=8978 GLR_TESTE_ZHITHEMES_PORTA=8977 GLR_TESTE_MEMDBG_PORTA=8976 GLR_TESTE_MEMDBG_CACHE_S=0 GLR_TESTE_GH=http://127.0.0.1:8975 \
  GLR_TESTE_PROCESSOS="$(cat $T/processos 2>/dev/null)" GLR_TESTE_KSTUFF=$T/el/kstuff_estado GLR_TESTE_BOOT=${BOOT:-1700000000} GLR_TESTE_UPTIME=${UPT:-100} GLR_TESTE_BOOT_ID=${BOOTID:-} \
  GLR_TESTE_AUTOLOAD_ESPERA_S=${ESPERA:-20} GLR_TESTE_KSTUFF_ESPERA_S=${KSESP:-5} GLR_TESTE_PLDMGR=$T/pldmgr GLR_TESTE_ARQ_RAIZES=$T/usb0:$T/data \
  GLR_TESTE_FW=12.00 "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; espera_http "$L/nada"; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
parear() {
  local n0=$(grep -c 'pareamento [0-9]\{6\}' "$T/glr.log") C=""
  post -X POST $R/api/parear/pedir > /dev/null
  for _ in $(seq 1 100); do [ "$(grep -c 'pareamento [0-9]\{6\}' "$T/glr.log")" -gt "$n0" ] && break; sleep 0.1; done
  C=$(grep -o 'pareamento [0-9]\{6\}' "$T/glr.log" | tail -1 | awk '{print $2}')
  TOKEN=$(post -d codigo=$C -d nome=teste $R/api/parear | grep -o '"token":"[0-9a-f]*"' | cut -d'"' -f4)
}
P() { post -H "X-GLR-Token: $TOKEN" "$@"; }
# .elf falso: magia ELF + texto (marcador) + enchimento
elf() { python3 - "$@" <<'EOF'
import sys
caminho, texto, tam = sys.argv[1], sys.argv[2].encode(), int(sys.argv[3])
d = b"\x7fELF" + b"\0" * 60 + texto + b"\0"
d += bytes((i * 7) % 251 for i in range(max(0, tam - len(d))))
open(caminho, "wb").write(d)
EOF
}
# guarda um payload do GitHub ja instalado (o .elf + o .info com o SHA-256 dele)
instala_gh() { elf "$PAY/$1.elf" "$2" 3000; printf 'versao=%s\nsha256=%s\ntamanho=%s\nasset=%s.elf\n' "$3" "$(sha256sum $PAY/$1.elf | cut -d' ' -f1)" "$(stat -c %s $PAY/$1.elf)" "$1" > "$PAY/$1.info"; }

rm -rf "$T"; mkdir -p "$DADOS" "$PAY" "$GH" "$T/lista" "$T/pldmgr/payloads" "$T/usb0/sub" "$T/data" "$T/el"
instala_gh dump-forge "DUMP-FORGE-FALSO" v0.5.6
instala_gh kraken-mount "KRAKEN-FALSO" v0.2.1
elf "$T/pldmgr/payloads/Kstuff-NG_v1.00.elf" "KSTUFF-FALSO Kstuff-NG v1.00" 4096
printf 'kstuff-NG_v1.00.elf\nshadowmountplus.elf\n' > "$T/pldmgr/autoload.txt"
elf "$T/pldmgr/payloads/outro-payload.elf" "OUTRO" 2048
elf "$T/usb0/sub/shadowkraken-1.00-Dev.7-pristmc.elf" "ShadowKraken 1.00-Dev.7-pristmc" 5000
elf "$T/usb0/sub/shadowkraken-1.00-Dev.8-pristmc.elf" "ShadowKraken 1.00-Dev.8-pristmc" 5100
elf "$T/usb0/kstuff-v1.01.elf" "KSTUFF-FALSO kstuff v1.01" 4200
head -c 2048 /dev/zero | tr '\0' 'x' > "$T/data/kstuff-texto.elf"
ln -s "$T/pldmgr/payloads/Kstuff-NG_v1.00.elf" "$T/usb0/kstuff-link.elf"
SHA_PM=$(sha256sum "$T/pldmgr/payloads/Kstuff-NG_v1.00.elf" "$T/pldmgr/autoload.txt")
config ""
liga_el
inicia; parear

echo "--- quem pode ter a chave"
E=$(estado)
for id in dump-forge memdbg bluev kraken-mount shadowkraken kstuff; do confere "$id: chave" "$(campo $id "['autoload_pode']")" "^true$"; done
for id in prefbar zhithemes web-browser-fullscreen; do confere "$id: sem chave" "$(campo $id "['autoload_pode']")" "^false$"; done
confere "proibido: 400"                    "$(P -d id=prefbar -d ligado=1 $R/api/payloads/autoload)" "payload_autoload_proibido"
confere "sem pareamento: 401"              "$(post -d id=dump-forge -d ligado=1 $R/api/payloads/autoload)" "parear_necessario"
confere "local: so celular/PC"             "$(post -d id=dump-forge -d ligado=1 $L/api/payloads/autoload)" "payload_so_celular"
confere "padrao desligado"                 "$(campo dump-forge "['autoload']")" "^false$"
confere "ligar"                            "$(P -d id=dump-forge -d ligado=1 $R/api/payloads/autoload)" '"ok":true,"autoload":true'
confere "config.ini"                       "$(cat $DADOS/config.ini)" "^payload_autoload = dump-forge$"
confere "desligar"                         "$(P -d id=dump-forge -d ligado=0 $R/api/payloads/autoload)" '"autoload":false'
nao_tem "config.ini sem a linha"           "$(cat $DADOS/config.ini)" "payload_autoload"

echo "--- montadores exclusivos"
P -d id=kraken-mount -d ligado=1 $R/api/payloads/autoload > /dev/null
confere "ligar SK desliga o kraken"        "$(P -d id=shadowkraken -d ligado=1 $R/api/payloads/autoload)" '"desligou":"Kraken Mount"'
confere "config: so o SK"                  "$(grep payload_autoload $DADOS/config.ini)" "^payload_autoload = shadowkraken$"
confere "ligar kraken desliga o SK"        "$(P -d id=kraken-mount -d ligado=1 $R/api/payloads/autoload)" '"desligou":"ShadowKraken"'
confere "config: so o kraken"              "$(grep payload_autoload $DADOS/config.ini)" "^payload_autoload = kraken-mount$"
confere "outro item nao desliga montador"  "$(P -d id=dump-forge -d ligado=1 $R/api/payloads/autoload)" '"desligou":""'
P -d id=dump-forge -d ligado=0 $R/api/payloads/autoload > /dev/null; P -d id=kraken-mount -d ligado=0 $R/api/payloads/autoload > /dev/null

echo "--- instalar de arquivo: lista"
confere "lista: rede sem pareamento 401"  "$(codigo "$R/api/payloads/arquivos?id=kstuff")" "401"
A=$(curl -s "$L/api/payloads/arquivos?id=kstuff")
confere "1o: o do payload manager"         "$(echo "$A" | python3 -c "import json,sys; a=json.load(sys.stdin)['arquivos'][0]; print(a['caminho'], a['fonte'], a['sugerido'], a['versao'], a['estado'])")" "^$T/pldmgr/payloads/Kstuff-NG_v1.00.elf pldmgr True 1.00 nao_instalado$"
confere "todos os .elf (outro tambem)"     "$A" '"caminho":"'$T'/pldmgr/payloads/outro-payload.elf".*"sugerido":false'
confere "sugeridos antes dos outros"       "$(echo "$A" | python3 -c "import json,sys; s=[a['sugerido'] for a in json.load(sys.stdin)['arquivos']]; print(s == sorted(s, reverse=True))")" "^True$"
confere "nao-ELF: invalido"                "$A" 'kstuff-texto.elf","tamanho":2048,"fonte":"disco","sugerido":true,"versao":"","sha256":"","estado":"invalido"'
nao_tem "link nao aparece"                 "$A" 'kstuff-link.elf'
nao_tem "nossa pasta nao aparece"          "$A" "$PAY"
confere "item sem arquivo: 404"            "$(codigo "$L/api/payloads/arquivos?id=dump-forge")" "404"

echo "--- instalar de arquivo: kstuff"
confere "fora dos discos: recusado"        "$(P -d id=kstuff -d caminho=/etc/hostname $R/api/payloads/arquivo)" "payload_arquivo_fora"
confere "link: recusado"                   "$(P -d id=kstuff -d caminho=$T/usb0/kstuff-link.elf $R/api/payloads/arquivo)" "payload_arquivo_fora"
confere "nao-ELF: recusado"                "$(P -d id=kstuff -d caminho=$T/data/kstuff-texto.elf $R/api/payloads/arquivo)" "nao e um ELF"
confere "local: so celular/PC"             "$(post -d id=kstuff -d caminho=$T/pldmgr/payloads/Kstuff-NG_v1.00.elf $L/api/payloads/arquivo)" "payload_so_celular"
R1=$(P -d id=kstuff -d caminho=$T/pldmgr/payloads/Kstuff-NG_v1.00.elf $R/api/payloads/arquivo)
confere "instalado (versao do marcador)"   "$R1" '"ok":true,"versao":"1.00","nome":"Kstuff-NG_v1.00.elf","fonte":"pldmgr"'
confere "copia com nome fixo"              "$(cmp $PAY/kstuff-PristMC.elf $T/pldmgr/payloads/Kstuff-NG_v1.00.elf && echo igual)" "igual"
confere "origem e autoload.txt intactos"   "$(sha256sum "$T/pldmgr/payloads/Kstuff-NG_v1.00.elf" "$T/pldmgr/autoload.txt")" "^$(echo "$SHA_PM" | head -1)"
confere "autoload.txt do pldmgr igual"     "$(sha256sum "$T/pldmgr/autoload.txt" | cut -d' ' -f1)" "$(echo "$SHA_PM" | tail -1 | cut -d' ' -f1)"
confere "pagina: arquivo seu"              "$(campo kstuff "['arquivo_seu']['nome']")" "^Kstuff-NG_v1.00.elf$"
confere "pagina: de onde veio"             "$(campo kstuff "['arquivo_seu']['origem']")" "^$T/pldmgr/payloads/Kstuff-NG_v1.00.elf$"
confere "pagina: instalado como"           "$(campo kstuff "['arquivo_fixo']")" "^kstuff-PristMC.elf$"
confere "lista: agora igual"               "$(curl -s "$L/api/payloads/arquivos?id=kstuff")" 'Kstuff-NG_v1.00.elf","tamanho":4096,"fonte":"pldmgr","sugerido":true,"versao":"1.00","sha256":"[0-9a-f]*","estado":"igual"'
confere "lista: v1.01 mais nova"           "$(curl -s "$L/api/payloads/arquivos?id=kstuff")" 'kstuff-v1.01.elf",.*"versao":"1.01","sha256":"[0-9a-f]*","estado":"mais_nova"'
P -d id=kstuff -d caminho=$T/usb0/kstuff-v1.01.elf $R/api/payloads/arquivo > /dev/null
confere "atualizado para 1.01"             "$(campo kstuff "['arquivo_seu']['versao']")" "^1.01$"
confere "anterior guardada (.anterior)"    "$(ls $PAY)" "kstuff-PristMC.elf.anterior"
confere "anterior: 1.00"                   "$(campo kstuff "['arquivo_anterior']['versao']")" "^1.00$"
P -d id=kstuff $R/api/payloads/voltar > /dev/null; espera_livre
confere "Voltar: 1.00 de novo"             "$(campo kstuff "['arquivo_seu']['versao']")" "^1.00$"
confere "Voltar: arquivo certo"            "$(cmp $PAY/kstuff-PristMC.elf $T/pldmgr/payloads/Kstuff-NG_v1.00.elf && echo igual)" "igual"
confere "sem baixar do GitHub (kstuff)"    "$(campo kstuff "['gh']")" "^null$"

echo "--- instalar de arquivo: ShadowKraken (build do dono)"
R1=$(P -d id=shadowkraken -d caminho=$T/usb0/sub/shadowkraken-1.00-Dev.7-pristmc.elf $R/api/payloads/arquivo)
confere "Dev.7 pelo marcador"              "$R1" '"versao":"1.00-Dev.7-pristmc"'
confere "instalada (gh) = Dev.7"           "$(campo shadowkraken "['gh']['instalada']['versao']")" "^1.00-Dev.7-pristmc$"
confere "nome fixo shadowkraken-PristMC"   "$(ls $PAY)" "^shadowkraken-PristMC.elf$"
confere "lista: Dev.8 mais nova"           "$(curl -s "$L/api/payloads/arquivos?id=shadowkraken")" 'Dev.8-pristmc.elf",.*"versao":"1.00-Dev.8-pristmc","sha256":"[0-9a-f]*","estado":"mais_nova"'
P -d id=shadowkraken -d caminho=$T/usb0/sub/shadowkraken-1.00-Dev.8-pristmc.elf $R/api/payloads/arquivo > /dev/null
confere "Dev.8; anterior Dev.7"            "$(campo shadowkraken "['gh']['anterior']['versao']")" "^1.00-Dev.7-pristmc$"
confere "anterior .anterior"               "$(ls $PAY)" "shadowkraken-PristMC.elf.anterior"
confere "lista: Dev.7 mais velha"          "$(curl -s "$L/api/payloads/arquivos?id=shadowkraken")" 'Dev.7-pristmc.elf",.*"estado":"mais_velha"'
P -d id=shadowkraken $R/api/payloads/voltar > /dev/null; espera_livre
confere "Voltar: Dev.7"                    "$(campo shadowkraken "['gh']['instalada']['versao']")" "^1.00-Dev.7-pristmc$"
confere "origens intactas"                 "$(ls $T/usb0/sub | tr '\n' ' ')" "shadowkraken-1.00-Dev.7-pristmc.elf shadowkraken-1.00-Dev.8-pristmc.elf"
para

echo "--- ligado e nao rodando: envia (Dump Forge)"
config "dump-forge"; inicia
confere "carregado"                        "$(espera_res dump-forge)" "^carregado$"
confere "elfldr recebeu 1"                 "$(recebidos)" "^1$"
confere "o arquivo instalado"              "$(cmp $T/el/recebido-1.elf $PAY/dump-forge.elf && echo igual)" "igual"
confere "diario"                           "$(cat $DADOS/glibren.log)" "dump-forge: carregado ao iniciar o glibren"
para

echo "--- ligado e ja rodando: nao envia"
liga_df; inicia
confere "ja rodando"                       "$(espera_res dump-forge)" "^ja_rodando$"
confere "elfldr: nada novo"                "$(recebidos)" "^1$"
para; para_df

echo "--- desligado: nada"
config ""; inicia; sleep 2
confere "sem resultado"                    "$(campo dump-forge "['autoload_res']")" "^$"
confere "elfldr: nada novo"                "$(recebidos)" "^1$"
para

echo "--- elfldr atrasado e elfldr ausente"
para_el; config "dump-forge"; ESPERA=20 inicia
sleep 3; liga_el
confere "atrasado: carregado"              "$(espera_res dump-forge)" "^carregado$"
confere "atrasado: elfldr recebeu"         "$(recebidos)" "^2$"
para; para_el
ESPERA=2 inicia
confere "ausente: erro"                    "$(espera_res dump-forge)" "^erro$"
confere "ausente: motivo"                  "$(campo dump-forge "['autoload_erro']")" "o elfldr (porta 9021) nao respondeu em 2 s"
confere "ausente: no diagnostico/diario"   "$(cat $DADOS/glibren.log)" "dump-forge: nao carregou ao iniciar: o elfldr"
para; liga_el

echo "--- montadores ao iniciar"
(exec python3 -I "$ORIGEM/testes/github_falso.py" smp $PSMP $GH) > $T/smp.log 2>&1 & PID_SMP=$!; espera_http "http://127.0.0.1:$PSMP/"
echo "1.7beta12" > $GH/smp_versao; echo "shadowmountplus.elf" > $T/processos
N0=$(recebidos)
config "kraken-mount"; inicia
confere "kraken + SMP: nao carrega"        "$(espera_res kraken-mount)" "^erro$"
confere "kraken + SMP: motivo"             "$(campo kraken-mount "['autoload_erro']")" "ShadowMount+ ja esta rodando: o kraken-mount ficaria esperando"
confere "kraken + SMP: nada enviado"       "$(recebidos)" "^$N0$"
para
config "shadowkraken"; inicia
confere "SK + SMP: carrega (substitui)"    "$(espera_res shadowkraken)" "^carregado$"
confere "SK: o arquivo instalado"          "$(cmp $T/el/recebido-$(recebidos).elf $PAY/shadowkraken-PristMC.elf && echo igual)" "igual"
para
echo "1.00-Dev.7-pristmc" > $GH/smp_versao; N0=$(recebidos)
inicia
confere "SK ja rodando: nao carrega"       "$(espera_res shadowkraken)" "^ja_rodando$"
confere "SK ja rodando: nada enviado"      "$(recebidos)" "^$N0$"
para
config "kraken-mount"; inicia
confere "kraken + SK rodando: nao carrega" "$(campo kraken-mount "['autoload_erro']" ; espera_res kraken-mount > /dev/null; campo kraken-mount "['autoload_erro']")" "ShadowKraken ja esta rodando"
para
rm -f $GH/smp_versao $T/processos; kill $PID_SMP 2>/dev/null; wait $PID_SMP 2>/dev/null

echo "--- kstuff: nao carregado -> envia uma vez, antes dos outros"
echo nao > $T/el/kstuff_estado; touch $T/el/ks_vira
N0=$(recebidos)
config "dump-forge kstuff"; inicia
confere "kstuff carregado"                 "$(espera_res kstuff)" "^carregado$"
confere "Dump Forge tambem"                "$(espera_res dump-forge)" "^carregado$"
confere "kstuff primeiro"                  "$(sed -n "$((N0+1))p" $T/el/recebidos)" "kstuff$"
confere "depois o Dump Forge"              "$(sed -n "$((N0+2))p" $T/el/recebidos)" "[0-9a-f]$"
confere "uma vez"                          "$(ks_recebidos)" "^1$"
confere "marcador do boot"                 "$(cat $PAY/kstuff.boot)" "^v2 0 1700000000 100$"
confere "esta carregado: sim"              "$(campo kstuff "['carregado']")" "^sim$"
para

echo "--- kstuff: o marcador do boot impede repetir"
echo nao > $T/el/kstuff_estado
inicia
confere "mesmo boot: nao repete"           "$(espera_res kstuff)" "^boot$"
confere "mesmo boot: nada enviado"         "$(ks_recebidos)" "^1$"
confere "esta carregado: nao"              "$(campo kstuff "['carregado']")" "^nao$"
confere "marcador na pagina"               "$(campo kstuff "['marcador_boot']")" "^true$"
para

echo "--- kstuff: ja ativo / desconhecido -> nao envia"
echo ativo > $T/el/kstuff_estado
BOOT=1700005000 inicia
confere "ativo: nao envia"                 "$(espera_res kstuff)" "^ja_rodando$"
confere "ativo: nada enviado"              "$(ks_recebidos)" "^1$"
para
echo talvez > $T/el/kstuff_estado
BOOT=1700006000 inicia
confere "desconhecido: nao envia"          "$(espera_res kstuff)" "^erro$"
confere "desconhecido: motivo"             "$(campo kstuff "['autoload_erro']")" "nao deu para saber se o kstuff ja esta ativo; carregue manualmente"
confere "desconhecido na pagina"           "$(campo kstuff "['carregado']")" "^desconhecido$"
confere "desconhecido: nada enviado"       "$(ks_recebidos)" "^1$"
confere "os outros seguem"                 "$(espera_res dump-forge)" "^carregado$"
para

echo "--- kstuff que nao confirma: os outros seguem"
echo nao > $T/el/kstuff_estado; rm -f $T/el/ks_vira
BOOT=1700007000 KSESP=2 inicia
confere "nao confirmou"                    "$(espera_res kstuff)" "^erro$"
confere "motivo"                           "$(campo kstuff "['autoload_erro']")" "nao confirmou que ficou ativo em 2 s"
confere "enviado uma vez (marcador)"       "$(ks_recebidos)" "^2$"
confere "marcador do novo boot"            "$(cat $PAY/kstuff.boot)" "^v2 0 1700007000 100$"
confere "Dump Forge depois"                "$(espera_res dump-forge)" "^carregado$"

# Pagina Payloads (chave, avisos, instalar de arquivo) no Chromium/Edge do Windows, se houver
NODE_WIN="/mnt/c/Program Files/nodejs/node.exe"
LAD=$(cmd.exe /c 'echo %LOCALAPPDATA%' 2>/dev/null | tr -d '\r')
PW=""; [ -n "$LAD" ] && PW=$(ls -d "$(wslpath "$LAD")"/npm-cache/_npx/*/node_modules/playwright 2>/dev/null | head -1)
if [ -x "$NODE_WIN" ] && [ -n "$PW" ]; then
  SAIDA=$("$NODE_WIN" "$(wslpath -w "$ORIGEM/testes/teste_autoload_pagina.mjs")" "http://127.0.0.1:$PORTA" "$(wslpath -w "$PW")" ${GLR_FOTOS:-} 2>&1)
  echo "$SAIDA"
  ok=$((ok + $(echo "$SAIDA" | grep -c '^OK '))); falhas=$((falhas + $(echo "$SAIDA" | grep -c '^FALHA')))
  echo "$SAIDA" | grep -q '^=== pagina' || { falhas=$((falhas+1)); echo "FALHA pagina: o script nao terminou"; }
  sleep 1
  confere "pagina: pergunta do kstuff, nada chegou ao elfldr" "$(ks_recebidos)" "^2$"
else
  echo "PULADO: teste da pagina (sem node.exe ou Playwright no Windows)"
fi
para; para_el
echo "=== $ok ok, $falhas falhas"
[ $falhas -eq 0 ]
