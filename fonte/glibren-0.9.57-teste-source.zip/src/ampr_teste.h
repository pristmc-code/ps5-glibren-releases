/* Game Library Renamer (payload PS5) - 0.9.51: build de teste do ampr-emu-ng no ShadowKraken, sem FTP.

O ShadowKraken (1.00-Dev.16+) usa <emulators_path>/ampr-emu-ng/libSceAmpr.sprx no lugar do runtime embutido quando o
arquivo existe e e um ampr-emu-ng (sm_ampr_resolve_ng_runtime, sem comparar versao; emulators_path padrao
/data/shadowmount/emus, ou o [emulators] path do /data/shadowmount/config.ini). A assinatura do cache de fakelib do
jogo inclui esse arquivo (tamanho/data), entao a troca vale na proxima abertura de cada jogo, sem reiniciar o
ShadowKraken. Aqui: enviar/escolher um .sprx de teste (conferido: SELF/ELF e "ampr-emu-ng X.Y.Z" dentro), voltar ao
embutido e guardar as ultimas 5 copias de /data/ampr_emu_trace.txt (o build de depuracao regrava esse arquivo a cada
inicio de jogo), que vao no diagnostico. */
#pragma once

#include "http.h"
#include "util.h"

#define AMPR_TRACES_MAX 5

/* Liga o vigia do /data/ampr_emu_trace.txt (thread). */
void ampr_teste_iniciar(void);

/* GET /api/ampr: o que esta em uso, o anterior guardado e as copias do trace. */
void ampr_teste_rota_estado(pedido_t *p);
/* POST /api/ampr/enviar?nome=: .sprx no corpo (celular/PC pareado). */
void ampr_teste_rota_enviar(pedido_t *p);
/* POST /api/ampr/arquivo (caminho=): .sprx de um disco do PS5. */
void ampr_teste_rota_arquivo(pedido_t *p);
/* POST /api/ampr/embutido: tira o arquivo de teste (guarda como .anterior). */
void ampr_teste_rota_embutido(pedido_t *p);

/* Para o diagnostico: as copias do trace, da mais nova para a mais velha. Devolve quantas. */
int ampr_teste_traces(char nomes[][96], char caminhos[][600], int max);
/* Para o diagnostico: o estado (mesmo JSON do GET /api/ampr). */
void ampr_teste_json(buf_t *b);

/* 0.9.57: ampr-emu-ng no fakelib/ de um backport (<raiz>/backports/<TITULO...>/fakelib/libSceAmpr.sprx).
   GET /api/ampr/backports: os backports achados e o runtime que seria copiado. */
void ampr_backports_rota_estado(pedido_t *p);
/* POST /api/ampr/backport (caminho=, acao=por|tirar): poe o runtime do ShadowKraken ou devolve o que estava la. */
void ampr_backport_rota(pedido_t *p);
/* Para o diagnostico: o mesmo JSON do GET /api/ampr/backports. */
void ampr_backports_json(buf_t *j);
