/* Game Library Renamer (payload PS5) - payloads de terceiros para teste (0.9.20). Ver payloads.h.

Regras:
  - so os itens do catalogo abaixo (id fora da lista = recusado); URL, tamanho e SHA-256 fixados aqui;
  - o arquivo baixado E o arquivo guardado sao conferidos pelo SHA-256 antes de enviar ao elfldr (adulterado = recusado
    e apagado);
  - 0.9.22: os itens marcados "shellui" (tela cheia e PrefBar) mexem na mesma interface: um ativo nesta sessao do PS5
    bloqueia os outros; "uma_vez" (PrefBar fica rodando) nao ativa duas vezes. .ativado = "hora pid_da_SceShellUI";
    vale depois do kern.boottime e com a mesma ShellUI;
  - um trabalho por vez; nada com jogo/app aberto (se a interface do PS5 reiniciar, o jogo fecharia sem salvar);
  - rota POST com X-GLR e pareamento (api.c). O navegador do PS5 (e outros programas do proprio PS5, que o pareamento
    deixa passar) so pode acionar o item marcado "navegador" (tela cheia): e o unico que faz sentido ali, e e o mesmo
    gesto de quem esta com o controle na mao diante da TV;
  - item "navegador" (modelo do PS5 Web File Manager, botao de tela cheia): responde, 250 ms, volta a tela inicial
    (sceShellUIUtilLaunchByUri "pshomeui:navigateToHome"), 1 s, envia ao elfldr, espera o resultado e reabre o navegador
    na pagina pedida (sceSystemServiceLaunchWebBrowser), mesmo se falhar, para ninguem ficar perdido na tela inicial.
O resultado vem da saida do proprio payload: o elfldr (ps5-payload-dev) liga stdin/stdout/stderr do payload a conexao
que o enviou. O ps5-web-browser-fullscreen escreve "Result=N; ..." (0 = ok, 2 = ok mas o INI nao gravou, 1 = falhou) e
"Notification: <texto>".
0.9.24: POST /api/navegador/abrir reaproveita a tela inicial + abrir_navegador para o celular abrir o navegador do PS5
numa pagina da lista fixa DESTINOS (o PS5 nao tem o app de navegador na tela: so abre pelo icone do glibren).
0.9.35: ZhiThemes (itsRealZhi/ZhiThemes, so pre-release) tambem e "shellui": injeta na SceShellUI; rodando agora por
GET 127.0.0.1:4444/version (GLR_TESTE_ZHITHEMES_PORTA no PC).
Testes no PC: GLR_TESTE_ELFLDR (porta do elfldr falso), GLR_TESTE_PAYLOADS_URL (base no lugar do GitHub, servidor local
de GLR_TESTE_BASE), GLR_TESTE_PAYLOAD_SHA/GLR_TESTE_PAYLOAD_TAM (outro arquivo no lugar do .elf real), GLR_TESTE_FW. */
#include "payloads.h"

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#include "api.h"
#include "config.h"
#include "fps.h"
#include "https.h"
#include "lancador.h"
#include "plataforma.h"
#include "prefbar.h"
#include "sha256.h"
#include "conversao.h"
#include "apps.h"
#include "github_rel.h"

#ifdef __PROSPERO__
#include <ps5/kernel.h>
#include <sys/sysctl.h>
#include <sys/user.h>
int sceKernelLoadStartModule(const char *, size_t, const void *, uint32_t, void *, int *) __attribute__((weak));
int sceSystemServiceLaunchWebBrowser(const char *, void *) __attribute__((weak));
int sceUserServiceGetForegroundUser(uint32_t *) __attribute__((weak));
#endif

#define PORTA_ELFLDR 9021
#define MAX_SAIDA (16 * 1024)
#ifdef MSG_NOSIGNAL
#define SEM_SINAL MSG_NOSIGNAL   /* elfldr fechou no meio: erro, nao queda */
#else
#define SEM_SINAL 0
#endif

typedef struct {
  const char *id, *nome, *autor, *licenca, *repo, *tag, *url, *arquivo, *sha256;
  unsigned long long tamanho;
  const char *firmwares;              /* testados em console (autor e comunidade), separados por espaco */
  const char *descricao[3];           /* pt-BR, en, es */
  const char *desfazer[3];
  const char *aviso[3];
  int espera_s;                       /* quanto esperar a saida do payload (ele termina sozinho) */
  int navegador;                      /* 1 = tela cheia do navegador: volta a home, aplica e reabre */
  int shellui;                        /* 0.9.22: 1 = mexe na interface do PS5 (SceShellUI): so um destes por sessao */
  int uma_vez;                        /* 0.9.22: 1 = fica rodando; ativar de novo na mesma sessao = duas copias (recusado) */
  const char *confirmados;            /* 0.9.23: firmwares que NOS testamos no PS5 real (separados por espaco) */
  const char *confirmado_em;          /* 0.9.23: em que console e data */
  int sonda;                          /* 0.9.33: como saber se esta rodando agora (SONDA_*) */
  /* 0.9.33: acompanhado pelo GitHub (gh_repo != NULL): versao, URL, tamanho e SHA-256 vem da ultima release (API do
     GitHub, digest do asset); arquivo = "<id>.elf"; tag/url/sha256/tamanho acima ficam vazios */
  const char *gh_repo, *gh_padrao;
  int gh_pre;                         /* 1 = a mais nova inclusive pre-release ("experimental") */
  unsigned long long gh_max;          /* tamanho maximo aceito */
  int aviso_smp;                      /* 1 = nao roda junto com o ShadowMount+: ativar pede confirmo=1 */
  const char *removido_em;            /* 0.9.34: repositorio removido do GitHub (DD/MM/AAAA): nao consulta nem instala;
                                         sem arquivo guardado o item nem aparece; guardado continua para Ativar/Remover/Voltar */
} item_t;

enum { SONDA_NENHUMA = 0, SONDA_DUMPFORGE, SONDA_KRAKEN, SONDA_SHADOWKRAKEN, SONDA_BLUEV, SONDA_ZHITHEMES };
#define PORTA_BLUEV 7733
#define PORTA_ZHITHEMES 4444
#define PORTA_KRAKEN 8097
#define PROCESSO_SMP "shadowmountplus.elf"   /* nome que o ShadowMount+ E o ShadowKraken dao a si mesmos */
/* 0.9.30 guardava o Dump Forge fixo com o nome do asset: adotado como versao instalada se o SHA-256 bater */
#define DF_LEGADO_ARQ "ps5-dump-forge-0.5.6-ps5.elf"
#define DF_LEGADO_SHA "f0415aab6ded1cdf875418b6683ab56aeae3721492af99fba71b08c2c351f82f"
#define DF_LEGADO_TAM 18549840ULL

static const item_t ITENS[] = {
  {"web-browser-fullscreen", "PS5 Web Browser Fullscreen", "owendswang", "GPL-3.0-or-later",
   /* 0.9.33: acompanhado pelo GitHub (antes: v0.1b fixa, sha256 520977607a22ecdf..., 463.848 B) */
   "https://github.com/owendswang/ps5-web-browser-fullscreen", "", "", "web-browser-fullscreen.elf", "", 0ULL,
   "4.03 6.50 7.00 7.61 10.01 10.20 11.20 12.02 12.20 13.00 13.60",
   {"Deixa o navegador do PS5 em tela cheia (1920x1080, sem a moldura). Corrige a interface do PS5 (ShellUI) só na memória: nenhum arquivo do sistema é alterado.",
    "Makes the PS5 web browser fullscreen (1920x1080, without the frame). Patches the PS5 interface (ShellUI) in memory only: no system file is changed.",
    "Pone el navegador de la PS5 en pantalla completa (1920x1080, sin el marco). Corrige la interfaz de la PS5 (ShellUI) solo en la memoria: ningún archivo del sistema se modifica."},
   {"Reinicie o PS5 (trocar o idioma do sistema também desfaz). O glibren não usa o \"restore\" do autor: no 11.60 ele derrubou a interface.",
    "Restart the PS5 (changing the system language also undoes it). glibren does not use the author's \"restore\": on 11.60 it crashed the interface.",
    "Reinicie la PS5 (cambiar el idioma del sistema también lo deshace). glibren no usa el \"restore\" del autor: en 11.60 tumbó la interfaz."},
   {"O PS5 volta à tela inicial, aplica e reabre o navegador. Outros cartões do sistema podem mudar de tamanho enquanto valer.",
    "The PS5 goes back to the home screen, applies it and reopens the browser. Other system cards may change size while it lasts.",
    "La PS5 vuelve a la pantalla de inicio, lo aplica y reabre el navegador. Otras tarjetas del sistema pueden cambiar de tamaño mientras dure."},
   30, 1, 1, 0,
   /* 0.9.23: o usuario testou a v0.1b no PS5 Pro 12.00 em 13/11/2026: "funcionou perfeito e desativou quando reiniciei" */
   "12.00", "PS5 Pro, 13/11/2026", SONDA_NENHUMA,
   /* so a ultima release normal (a "test" e pre-release); o "restore" do autor fica de fora pelo padrao */
   "owendswang/ps5-web-browser-fullscreen", "web-browser-fullscreen-*.elf", 0, 8ULL * 1024 * 1024, 0},
  /* 0.9.22: PrefBar (numeros por cima do jogo). Fica rodando: espera um jogo abrir e a interface do PS5 ficar estavel e
     so entao se injeta na SceShellUI (o README manda carregar e DEPOIS abrir o jogo). Nao escreve nada na saida quando
     da certo: o glibren espera 4 s por um erro do elfldr e solta a conexao. */
  {"prefbar", "PrefBar", "X1NONs", "GPL-3.0",
   /* 0.9.33: acompanhado pelo GitHub (antes: v0.3.0 fixa, sha256 e4379590115ef87b..., 964.272 B) */
   "https://github.com/X1NONs/PrefBar", "", "", "prefbar.elf", "", 0ULL,
   "7.xx 8.xx 9.xx 10.xx 11.xx 12.xx 13.xx",
   {"Mostra FPS, 1% low, CPU e GPU (uso, temperatura, MHz), ventoinha, RAM, VRAM e consumo numa barra por cima do jogo. Ative fora do jogo e depois abra o jogo: a barra aparece alguns segundos depois. Três toques no touchpad mostram ou escondem.",
    "Shows FPS, 1% low, CPU and GPU (usage, temperature, MHz), fan, RAM, VRAM and power in a bar over the game. Activate it outside the game, then open the game: the bar shows up a few seconds later. Triple-tap the touchpad to show or hide it.",
    "Muestra FPS, 1% low, CPU y GPU (uso, temperatura, MHz), ventilador, RAM, VRAM y consumo en una barra sobre el juego. Actívelo fuera del juego y luego abra el juego: la barra aparece unos segundos después. Tres toques en el touchpad la muestran u ocultan."},
   {"Reinicie o PS5 (nada fica instalado; para limpar tudo, apague a pasta /data/prefbar).",
    "Restart the PS5 (nothing stays installed; to clean everything, delete the /data/prefbar folder).",
    "Reinicie la PS5 (nada queda instalado; para limpiar todo, borre la carpeta /data/prefbar)."},
   {"Espere ~2 min depois de ligar o PS5. Não use junto com a tela cheia do navegador: os dois mexem na interface do PS5 (ShellUI). Não testado no PS5 Pro 12.00.",
    "Wait ~2 min after turning the PS5 on. Do not use it together with the browser fullscreen: both change the PS5 interface (ShellUI). Not tested on the PS5 Pro 12.00.",
    "Espere ~2 min después de encender la PS5. No lo use junto con la pantalla completa del navegador: los dos modifican la interfaz de la PS5 (ShellUI). No probado en la PS5 Pro 12.00."},
   4, 0, 1, 1, NULL, NULL, SONDA_NENHUMA,
   /* o nome do .elf muda a cada versao (perfbar-complete.elf, PrefBar-complete_V0.2.1.elf, Prefbar_V0.3.0.elf): cada
      release tem um .elf so, e ele tem de ser unico */
   "X1NONs/PrefBar", "*.elf", 0, 8ULL * 1024 * 1024, 0},
  /* 0.9.30: ps5-dump-forge (motor da conversao de formato do glibren, src/conversao.c). Fica rodando, com a API em
     127.0.0.1:8095 e a pagina dele em http://<ip do PS5>:8095. 0.9.33: acompanhado pelo GitHub (antes: v0.5.6 fixa). */
  {"dump-forge", "PS5 Dump Forge", "quer3q", "GPL-3.0",
   "https://github.com/quer3q/ps5-dump-forge", "", "", "dump-forge.elf", "", 0ULL,
   "",
   {"Converte jogos entre pasta, .exfat, .ffpkg, .ffpfs, .ffpfsc, .pkg (FPKG) e pastas compactadas (zstd e LZ4, com o ampr-emu-ng). É o motor do botão Converter da lista de jogos do glibren e da conversão da Jobe; também tem a própria página em http://IP-do-PS5:8095.",
    "Converts games between folder, .exfat, .ffpkg, .ffpfs, .ffpfsc, .pkg (FPKG) and packed folders (zstd and LZ4, with ampr-emu-ng). It is the engine behind the Convert button in glibren's game list and Jobe's conversion; it also has its own page at http://PS5-IP:8095.",
    "Convierte juegos entre carpeta, .exfat, .ffpkg, .ffpfs, .ffpfsc, .pkg (FPKG) y carpetas comprimidas (zstd y LZ4, con ampr-emu-ng). Es el motor del botón Convertir de la lista de juegos de glibren y de la conversión de Jobe; también tiene su propia página en http://IP-de-la-PS5:8095."},
   {"Feche pela página dele (http://IP-do-PS5:8095) ou reinicie o PS5. Nada fica instalado no sistema.",
    "Close it from its page (http://PS5-IP:8095) or restart the PS5. Nothing is installed in the system.",
    "Ciérrelo desde su página (http://IP-de-la-PS5:8095) o reinicie la PS5. Nada queda instalado en el sistema."},
   {"Usa a porta 8095: a conversão do glibren e da Jobe fala com ele por ela (não ligue outro programa nessa porta). Arquivo grande (~18 MB). Fica rodando até reiniciar o PS5; uma versão nova só vale depois de fechar a que está rodando. Não testado por nós no PS5 Pro 12.00.",
    "Uses port 8095: glibren's and Jobe's conversion talk to it there (do not run another program on that port). Large file (~18 MB). It keeps running until the PS5 restarts; a new version only takes effect after closing the running one. Not tested by us on the PS5 Pro 12.00.",
    "Usa el puerto 8095: la conversión de glibren y de Jobe habla con él por ahí (no use otro programa en ese puerto). Archivo grande (~18 MB). Sigue ejecutándose hasta reiniciar la PS5; una versión nueva solo vale después de cerrar la que está en ejecución. No probado por nosotros en la PS5 Pro 12.00."},
   4, 0, 0, 1, NULL, NULL, SONDA_DUMPFORGE,
   "quer3q/ps5-dump-forge", "ps5-dump-forge-*-ps5.elf", 0, 64ULL * 1024 * 1024, 0},
  /* 0.9.33: kraken-mount (monta jogos em pasta e FPKG direto, com o ampr-emu-ng). Interface em :8097 (GET /api/state traz
     "version" e "waiting"). Espera o ShadowMount+ PARAR antes de montar qualquer coisa (README/DESIGN do autor). */
  {"kraken-mount", "Kraken Mount", "quer3q", "GPL-3.0",
   "https://github.com/quer3q/kraken-mount", "", "", "kraken-mount.elf", "", 0ULL,
   "",
   {"Monta jogos em pasta (normal, zstd e LZ4) e .pkg FPKG direto, sem instalar, com o ampr-emu-ng embutido. Tem a própria página em http://IP-do-PS5:8097.",
    "Mounts games as folders (plain, zstd and LZ4) and FPKG .pkg directly, without installing, with ampr-emu-ng built in. It has its own page at http://PS5-IP:8097.",
    "Monta juegos en carpeta (normal, zstd y LZ4) y .pkg FPKG directo, sin instalar, con ampr-emu-ng incluido. Tiene su propia página en http://IP-de-la-PS5:8097."},
   {"Feche pela página dele (http://IP-do-PS5:8097) ou reinicie o PS5.",
    "Close it from its page (http://PS5-IP:8097) or restart the PS5.",
    "Ciérrelo desde su página (http://IP-de-la-PS5:8097) o reinicie la PS5."},
   {"Não roda junto com o ShadowMount+ (nem com o ShadowKraken): enquanto um deles estiver rodando, o kraken-mount fica esperando e não monta nada. O glibren nunca fecha o ShadowMount+: tire-o do autoload e reinicie o PS5 antes, ou use o ShadowKraken. Não testado por nós no PS5 Pro 12.00.",
    "Does not run together with ShadowMount+ (nor with ShadowKraken): while one of them is running, kraken-mount waits and mounts nothing. glibren never closes ShadowMount+: remove it from autoload and restart the PS5 first, or use ShadowKraken. Not tested by us on the PS5 Pro 12.00.",
    "No funciona junto con ShadowMount+ (ni con ShadowKraken): mientras uno de ellos esté en ejecución, kraken-mount espera y no monta nada. glibren nunca cierra ShadowMount+: quítelo del autoload y reinicie la PS5 antes, o use ShadowKraken. No probado por nosotros en la PS5 Pro 12.00."},
   4, 0, 0, 1, NULL, NULL, SONDA_KRAKEN,
   "quer3q/kraken-mount", "kraken-mount.elf", 0, 32ULL * 1024 * 1024, 1},
  /* 0.9.33: ShadowKraken (fork do ShadowMount+ com o backend FPKG do kraken). So pre-releases "Dev". Usa o MESMO nome de
     processo do SMP (shadowmountplus.elf) e, ao subir, pede para a copia que esta rodando (SMP ou ele) sair (SIGTERM) e
     fica no lugar (main.c dele). API igual a do SMP (POST /api/v1/version, porta 10101 por padrao). */
  {"shadowkraken", "ShadowKraken", "MNeroba", "GPL-3.0",
   "https://github.com/MNeroba/ShadowKraken", "", "", "shadowkraken.elf", "", 0ULL,
   "",
   {"ShadowMount+ com o suporte a FPKG do kraken-mount num payload só: monta pastas, imagens (.exfat/.ffpkg/.ffpfs/.ffpfsc) e .pkg FPKG (experimental). Usa no lugar do ShadowMount+. Página em http://IP-do-PS5:10101.",
    "ShadowMount+ with kraken-mount's FPKG support in a single payload: mounts folders, images (.exfat/.ffpkg/.ffpfs/.ffpfsc) and FPKG .pkg (experimental). Used instead of ShadowMount+. Page at http://PS5-IP:10101.",
    "ShadowMount+ con el soporte FPKG de kraken-mount en un solo payload: monta carpetas, imágenes (.exfat/.ffpkg/.ffpfs/.ffpfsc) y .pkg FPKG (experimental). Se usa en lugar de ShadowMount+. Página en http://IP-de-la-PS5:10101."},
   {"Reinicie o PS5 (o ShadowMount+ do autoload volta). Para não voltar, tire o ShadowKraken de onde você o liga.",
    "Restart the PS5 (ShadowMount+ from autoload comes back). To keep it from coming back, remove ShadowKraken from where you start it.",
    "Reinicie la PS5 (vuelve el ShadowMount+ del autoload). Para que no vuelva, quite ShadowKraken de donde lo inicia."},
   {"Experimental (só versões \"Dev\"). Substitui o ShadowMount+: se ele estiver rodando, o próprio ShadowKraken pede para ele fechar e fica no lugar (o glibren não fecha nada). Não use junto com o kraken-mount. Não testado por nós no PS5 Pro 12.00.",
    "Experimental (\"Dev\" builds only). Replaces ShadowMount+: if it is running, ShadowKraken itself asks it to close and takes its place (glibren closes nothing). Do not use together with kraken-mount. Not tested by us on the PS5 Pro 12.00.",
    "Experimental (solo versiones \"Dev\"). Sustituye a ShadowMount+: si está en ejecución, el propio ShadowKraken le pide que se cierre y ocupa su lugar (glibren no cierra nada). No lo use junto con kraken-mount. No probado por nosotros en la PS5 Pro 12.00."},
   4, 0, 0, 1, NULL, NULL, SONDA_SHADOWKRAKEN,
   "MNeroba/ShadowKraken", "ShadowKraken.elf", 1, 32ULL * 1024 * 1024, 1, "17/11/2026"},   /* 0.9.34: repo 404 desde 17/11/2026 */
  /* 0.9.34: BlueV (som do PS5 em Bluetooth A2DP). Pagina propria em :7733 sem senha; GET /api/status responde enquanto
     roda (sem a versao: docs/program.md e src/service/service.cpp do autor). A release tambem tem bluev.elf.sha256: o
     padrao "bluev.elf" casa so com o .elf. */
  {"bluev", "BlueV", "0xZ3n0x", "GPL-3.0",
   "https://github.com/0xZ3n0x/BlueV", "", "", "bluev.elf", "", 0ULL,
   "",
   {"Som do PS5 em caixas e fones Bluetooth (A2DP). Funciona com adaptador Bluetooth USB (CSR 4.0 testado) ou com o chip do próprio PS5, que é dividido com o controle. Controle pela página na porta 7733 ou pelo atalho BlueV na tela inicial.",
    "PS5 sound on Bluetooth speakers and headphones (A2DP). Works with a USB Bluetooth adapter (CSR 4.0 tested) or with the PS5's own chip, which is shared with the controller. Control it from the page on port 7733 or from the BlueV shortcut on the home screen.",
    "Sonido de la PS5 en altavoces y auriculares Bluetooth (A2DP). Funciona con adaptador Bluetooth USB (CSR 4.0 probado) o con el chip de la propia PS5, que se comparte con el mando. Control desde la página en el puerto 7733 o desde el acceso BlueV en la pantalla de inicio."},
   {"Pare pela página dele (http://IP-do-PS5:7733, \"Stop BlueV\") ou reinicie o PS5.",
    "Stop it from its page (http://PS5-IP:7733, \"Stop BlueV\") or restart the PS5.",
    "Deténgalo desde su página (http://IP-de-la-PS5:7733, \"Stop BlueV\") o reinicie la PS5."},
   {"Usa a porta 7733 sem senha: qualquer aparelho da rede abre a página dele (dá para limitar ao próprio PS5 nela). Fica rodando até parar pela página ou reiniciar o PS5. Não testado por nós no PS5 Pro 12.00.",
    "Uses port 7733 without a password: any device on the network can open its page (it can be limited to the PS5 itself there). It keeps running until stopped from the page or the PS5 restarts. Not tested by us on the PS5 Pro 12.00.",
    "Usa el puerto 7733 sin contraseña: cualquier aparato de la red abre su página (se puede limitar a la propia PS5 en ella). Sigue ejecutándose hasta detenerlo desde la página o reiniciar la PS5. No probado por nosotros en la PS5 Pro 12.00."},
   4, 0, 0, 1, NULL, NULL, SONDA_BLUEV,
   "0xZ3n0x/BlueV", "bluev.elf", 0, 16ULL * 1024 * 1024, 0, NULL},
  /* 0.9.35: ZhiThemes (temas na tela inicial real do PS5). Injeta um modulo na SceShellUI (so na memoria; grava so em
     /data/ZhiThemes/) e fica um processo vigia que reinjeta se a ShellUI reiniciar. Editor em :4444 sem senha (INADDR_ANY,
     src/source/shellui/src/theme_web.cpp do autor); GET /version responde "zhithemes 0.1.0-alpha (build ...) ..." enquanto
     roda. Mandar de novo troca a copia que esta rodando sem reiniciar (POST /quit + vigia novo, main.cpp do autor): nao e
     "uma_vez". So tem pre-release (v0.1.0-alpha); a release tambem traz ZhiThemes-themes.zip (temas, fora do glibren). */
  {"zhithemes", "ZhiThemes", "itsRealZhi", "GPL-3.0",
   "https://github.com/itsRealZhi/ZhiThemes", "", "", "zhithemes.elf", "", 0ULL,
   "9.xx 10.xx 11.xx 12.xx 13.xx",
   {"Temas na tela inicial do PS5: pastas de jogos, capas verticais, papel de parede com imagem ou vídeo, fonte, barra de cima nova, Configurações e Troféus com o tema. Edite pelo PC ou celular em http://IP-do-PS5:4444. Firmware 9.00 a 13.60. Os temas prontos ficam no arquivo ZhiThemes-themes.zip da release (o glibren não instala).",
    "Themes for the PS5 home screen: game folders, vertical covers, picture or video wallpaper, font, a new top bar, themed Settings and Trophies. Edit it from a PC or phone at http://PS5-IP:4444. Firmware 9.00 to 13.60. Ready-made themes are in the release's ZhiThemes-themes.zip file (glibren does not install them).",
    "Temas en la pantalla de inicio de la PS5: carpetas de juegos, portadas verticales, fondo con imagen o vídeo, fuente, barra superior nueva, Ajustes y Trofeos con el tema. Edítelo desde el PC o el móvil en http://IP-de-la-PS5:4444. Firmware 9.00 a 13.60. Los temas listos están en el archivo ZhiThemes-themes.zip de la release (glibren no los instala)."},
   {"Reinicie o PS5 sem mandar o payload de novo: o PS5 volta ao normal. Para desligar só o tema: no editor ou em Opções > ZhiThemes, \"PS5 default\". Para apagar tudo, apague a pasta /data/ZhiThemes.",
    "Restart the PS5 without sending the payload again: the PS5 goes back to normal. To turn only the theme off: in the editor or in Options > ZhiThemes, \"PS5 default\". To delete everything, delete the /data/ZhiThemes folder.",
    "Reinicie la PS5 sin volver a enviar el payload: la PS5 vuelve a la normalidad. Para apagar solo el tema: en el editor o en Opciones > ZhiThemes, \"PS5 default\". Para borrar todo, borre la carpeta /data/ZhiThemes."},
   {"Alpha. Altera a tela inicial de verdade do PS5 (só na memória; grava apenas em /data/ZhiThemes). Ative sem jogo aberto. Não roda junto com etaHEN, OnionHEN ou AniketosHEN (ele mesmo recusa e avisa) nem com outro payload que mexe na interface do PS5. Modo seguro: 2 travamentos da tela inicial em 3 min desligam o tema. Usa a porta 4444 sem senha: qualquer aparelho da rede abre o editor. Não testado por nós no PS5 Pro 12.00.",
    "Alpha. It changes the PS5's real home screen (in memory only; it writes only to /data/ZhiThemes). Activate it with no game open. It does not run together with etaHEN, OnionHEN or AniketosHEN (it refuses by itself and says so) nor with another payload that changes the PS5 interface. Safe mode: 2 home screen crashes within 3 min turn the theme off. Uses port 4444 without a password: any device on the network can open the editor. Not tested by us on the PS5 Pro 12.00.",
    "Alpha. Cambia la pantalla de inicio real de la PS5 (solo en la memoria; escribe solo en /data/ZhiThemes). Actívelo sin juego abierto. No funciona junto con etaHEN, OnionHEN o AniketosHEN (él mismo lo rechaza y avisa) ni con otro payload que modifique la interfaz de la PS5. Modo seguro: 2 caídas de la pantalla de inicio en 3 min apagan el tema. Usa el puerto 4444 sin contraseña: cualquier aparato de la red abre el editor. No probado por nosotros en la PS5 Pro 12.00."},
   4, 0, 1, 0, NULL, NULL, SONDA_ZHITHEMES,
   "itsRealZhi/ZhiThemes", "ZhiThemes.elf", 1, 24ULL * 1024 * 1024, 0, NULL},
};
#define N_ITENS ((int)(sizeof ITENS / sizeof ITENS[0]))

typedef struct {
  char fase[16];        /* "", baixando, conferindo, home, aplicando, reabrindo */
  char erro[300];
  char saida[600];      /* resumo da saida do payload (Result/Notification) */
  time_t ativado_em;
  unsigned long long baixados, total;   /* total: tamanho do download em andamento (0.9.33) */
  /* cache do SHA-256 do arquivo guardado (refeito quando tamanho/data mudam) */
  long long cache_tam, cache_mtime;
  int cache_ok;
  char cache_sha[65];   /* 0.9.33: o SHA-256 esperado quando o cache foi feito (muda ao atualizar/voltar) */
  /* 0.9.33: ultima release no GitHub (itens acompanhados) */
  gh_release_t disp;
  int disp_ok;          /* 1 = disp valida (asset unico com digest) */
  int gh_res, gh_http;  /* resultado da ultima resposta do GitHub (GH_*; 0.9.39: so as que valem o cache) e o HTTP da ultima tentativa */
  int gh_falha;         /* 0.9.39: erro da ultima tentativa que nao trouxe resposta (rede/http/limite/json); 0 = a ultima respondeu */
  time_t consultado;    /* hora da ultima consulta que respondeu (cache de 1 h) */
  time_t tentou;        /* hora da ultima tentativa (botao: no maximo 1 por minuto) */
  int consultando;
  /* 0.9.33: rodando agora? (cache de 8 s) */
  time_t sonda_em;
  int rodando;          /* 1 sim, 0 nao */
  char rodando_versao[64];
  char rodando_obs[32]; /* kraken: "waiting" (ex.: "shadowmount") */
} estado_t;

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static estado_t g_est[N_ITENS];
static int g_ocupado;

/* ------------------------------------------------------------------ catalogo e pastas */

static const char *sha_item(const item_t *it) {
#ifndef __PROSPERO__
  if(!it->gh_repo && getenv("GLR_TESTE_PAYLOAD_SHA")) return getenv("GLR_TESTE_PAYLOAD_SHA");
#endif
  return it->sha256;
}

static unsigned long long tam_item(const item_t *it) {
#ifndef __PROSPERO__
  if(!it->gh_repo && getenv("GLR_TESTE_PAYLOAD_TAM")) return strtoull(getenv("GLR_TESTE_PAYLOAD_TAM"), NULL, 10);
#endif
  return it->tamanho;
}

static void caminho(const item_t *it, const char *ext, char *saida, size_t tam);

/* ------------------------------------------------------------------ 0.9.33: versao instalada (itens do GitHub) */

typedef struct {
  char versao[64], sha256[65], asset[128];
  unsigned long long tamanho;
} info_t;

/* <id>.info ou <id>.anterior.info: "versao=..", "sha256=..", "tamanho=..", "asset=..". 0 = leu e e valido. */
static int info_ler(const item_t *it, int anterior, info_t *in) {
  char arq[600], linha_[256];
  memset(in, 0, sizeof *in);
  caminho(it, anterior ? ".anterior.info" : ".info", arq, sizeof arq);
  FILE *f = fopen(arq, "r");
  if(!f) return -1;
  while(fgets(linha_, sizeof linha_, f)) {
    linha_[strcspn(linha_, "\r\n")] = 0;
    char *ig = strchr(linha_, '=');
    if(!ig) continue;
    *ig++ = 0;
    if(!strcmp(linha_, "versao")) snprintf(in->versao, sizeof in->versao, "%s", ig);
    else if(!strcmp(linha_, "sha256")) snprintf(in->sha256, sizeof in->sha256, "%s", ig);
    else if(!strcmp(linha_, "asset")) snprintf(in->asset, sizeof in->asset, "%s", ig);
    else if(!strcmp(linha_, "tamanho")) in->tamanho = strtoull(ig, NULL, 10);
  }
  fclose(f);
  return gh_nome_ok(in->versao, sizeof in->versao) && strlen(in->sha256) == 64 && strspn(in->sha256, "0123456789abcdef") == 64 &&
                 in->tamanho > 0 && in->tamanho <= it->gh_max
             ? 0
             : -1;
}

/* Grava em <destino>.tmp, fsync e rename (atomico). 0 = ok. */
static int info_gravar(const char *destino, const info_t *in) {
  char tmp[640];
  snprintf(tmp, sizeof tmp, "%s.tmp", destino);
  FILE *f = fopen(tmp, "w");
  if(!f) return -1;
  fprintf(f, "versao=%s\nsha256=%s\ntamanho=%llu\nasset=%s\n", in->versao, in->sha256, in->tamanho, in->asset);
  int ok = !fflush(f) && !fsync(fileno(f));
  if(fclose(f) || !ok || rename(tmp, destino)) {
    unlink(tmp);
    return -1;
  }
  return 0;
}

/* SHA-256 e tamanho esperados do arquivo guardado: fixos no catalogo, ou os da versao instalada (GitHub). 0 = sabe. */
static int esperado(const item_t *it, char *sha, unsigned long long *tam) {
  if(!it->gh_repo) {
    snprintf(sha, 65, "%s", sha_item(it));
    *tam = tam_item(it);
    return 0;
  }
  info_t in;
  if(info_ler(it, 0, &in)) return -1;
  snprintf(sha, 65, "%s", in.sha256);
  *tam = in.tamanho;
  return 0;
}

static void url_item(const item_t *it, char *saida, size_t tam) {
#ifndef __PROSPERO__
  const char *base = getenv("GLR_TESTE_PAYLOADS_URL");
  if(base && *base) {
    snprintf(saida, tam, "%s%s", base, it->arquivo);
    return;
  }
#endif
  snprintf(saida, tam, "%s", it->url);
}

static void pasta(char *saida, size_t tam) {
#ifdef __PROSPERO__
  snprintf(saida, tam, "/data/glibren/payloads");
#else
  snprintf(saida, tam, "%s/payloads", g_pasta_dados);   /* PC: dentro da pasta de dados do teste */
#endif
}

/* ext NULL = o .elf; ".ativado" = hora da ultima ativacao */
static void caminho(const item_t *it, const char *ext, char *saida, size_t tam) {
  char p[512];
  pasta(p, sizeof p);
  if(ext) snprintf(saida, tam, "%s/%s%s", p, it->id, ext);
  else snprintf(saida, tam, "%s/%s", p, it->arquivo);
}

static int achar(const char *id) {
  for(int i = 0; i < N_ITENS; i++)
    if(!strcmp(ITENS[i].id, id)) return i;
  return -1;
}

/* "12.00" (vazio = nao sabe) */
static void firmware(char *saida, size_t tam) {
  saida[0] = 0;
#ifdef __PROSPERO__
  uint32_t v = kernel_get_fw_version();
  if(v) snprintf(saida, tam, "%x.%02x", (unsigned)((v >> 24) & 0xff), (unsigned)((v >> 16) & 0xff));
#else
  if(getenv("GLR_TESTE_FW")) snprintf(saida, tam, "%s", getenv("GLR_TESTE_FW"));
#endif
}

/* "4.03 12.02" contem "12.02"? (palavra inteira). 0.9.22: "12.xx" na lista vale para qualquer 12.yy. */
static int palavra(const char *lista, const char *fw) {
  size_t n = strlen(fw);
  for(const char *p = lista; n && (p = strstr(p, fw)); p++)
    if((p == lista || p[-1] == ' ') && (p[n] == 0 || p[n] == ' ')) return 1;
  return 0;
}

static int na_lista(const char *lista, const char *fw) {
  if(palavra(lista, fw)) return 1;
  char familia[16];
  const char *ponto = strchr(fw, '.');
  if(!ponto || ponto - fw > 3) return 0;
  snprintf(familia, sizeof familia, "%.*s.xx", (int)(ponto - fw), fw);
  return palavra(lista, familia);
}

/* Hora em que o PS5 ligou (os patches da interface valem ate reiniciar). 0.9.22: kern.boottime no PS5 (o mesmo do
   "Ligado ha" da Temperatura); reserva: relogio monotonico. */
static time_t ligou_em(void) {
#ifdef __PROSPERO__
  struct timeval boot;
  size_t tam = sizeof boot;
  if(!sysctlbyname("kern.boottime", &boot, &tam, NULL, 0) && boot.tv_sec > 0) return boot.tv_sec;
#endif
  struct timespec ts;
  if(clock_gettime(CLOCK_MONOTONIC, &ts)) return 0;
  return time(NULL) - ts.tv_sec;
}

/* 0.9.22: pid da SceShellUI (a interface do PS5). Os patches vivem na memoria dela: se ela reiniciar (pid novo), o
   patch acabou. 0 = nao sabe. PC: GLR_TESTE_SHELLUI_PID. */
static int pid_shellui(void) {
#ifdef __PROSPERO__
  int mib[3] = {CTL_KERN, KERN_PROC, KERN_PROC_PROC}, pid = 0;
  size_t tam = 0;
  if(sysctl(mib, 3, NULL, &tam, NULL, 0) || !tam) return 0;
  tam += 64 * 1024;
  uint8_t *b = malloc(tam);
  if(!b) return 0;
  if(!sysctl(mib, 3, b, &tam, NULL, 0)) {
    for(uint8_t *q = b; q + sizeof(int) <= b + tam;) {
      struct kinfo_proc *ki = (struct kinfo_proc *)q;
      if(ki->ki_structsize <= 0) break;
      if(!strcmp(ki->ki_comm, "SceShellUI")) {
        pid = ki->ki_pid;
        break;
      }
      q += ki->ki_structsize;
    }
  }
  free(b);
  return pid;
#else
  const char *v = getenv("GLR_TESTE_SHELLUI_PID");
  return v ? atoi(v) : 0;
#endif
}

/* ------------------------------------------------------------------ arquivo guardado */

/* Le o arquivo e confere tamanho e SHA-256. 1 = ok (b recebe o conteudo, se nao for NULL). */
static int arquivo_confere_em(const char *arq, const char *sha_esp, unsigned long long esperado, buf_t *b) {
  char hex[65];
  int fd = open(arq, O_RDONLY | O_NOFOLLOW);
  if(fd < 0) return 0;
  unsigned long long lidos = 0;
  sha256_t s;
  sha256_iniciar(&s);
  char bloco[64 * 1024];
  ssize_t r;
  int ok = 1;
  while(ok && (r = read(fd, bloco, sizeof bloco)) > 0) {
    lidos += (unsigned long long)r;
    if(lidos > esperado) ok = 0;
    else {
      sha256_atualizar(&s, bloco, (size_t)r);
      if(b) buf_add(b, bloco, (size_t)r);
    }
  }
  if(r < 0) ok = 0;
  close(fd);
  uint8_t resumo[32];
  sha256_final(&s, resumo);
  sha256_hex(resumo, hex);
  return ok && lidos == esperado && !strcmp(hex, sha_esp);
}

static int arquivo_confere(const item_t *it, buf_t *b) {
  char arq[600], sha[65];
  unsigned long long tam;
  if(esperado(it, sha, &tam)) return 0;
  caminho(it, NULL, arq, sizeof arq);
  return arquivo_confere_em(arq, sha, tam, b);
}

/* Pronto (guardado e conferido)? Usa o cache pelo tamanho/data do arquivo. Chamar sem a trava. */
static int pronto(int i) {
  char arq[600];
  struct stat st;
  caminho(&ITENS[i], NULL, arq, sizeof arq);
  if(lstat(arq, &st) || !S_ISREG(st.st_mode)) return 0;
  char sha[65];
  unsigned long long tam;
  if(esperado(&ITENS[i], sha, &tam)) return 0;
  pthread_mutex_lock(&g_trava);
  int sabe = g_est[i].cache_tam == (long long)st.st_size && g_est[i].cache_mtime == (long long)st.st_mtime && !strcmp(g_est[i].cache_sha, sha),
      ok = g_est[i].cache_ok;
  pthread_mutex_unlock(&g_trava);
  if(sabe) return ok;
  ok = arquivo_confere_em(arq, sha, tam, NULL);
  pthread_mutex_lock(&g_trava);
  g_est[i].cache_tam = (long long)st.st_size;
  g_est[i].cache_mtime = (long long)st.st_mtime;
  g_est[i].cache_ok = ok;
  snprintf(g_est[i].cache_sha, sizeof g_est[i].cache_sha, "%s", sha);
  pthread_mutex_unlock(&g_trava);
  return ok;
}

/* ------------------------------------------------------------------ estado */

static void fase(int i, const char *f) {
  pthread_mutex_lock(&g_trava);
  snprintf(g_est[i].fase, sizeof g_est[i].fase, "%s", f);
  pthread_mutex_unlock(&g_trava);
}

static void falhou(int i, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
static void falhou(int i, const char *fmt, ...) {
  char msg[300];
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(msg, sizeof msg, fmt, ap);
  va_end(ap);
  pthread_mutex_lock(&g_trava);
  snprintf(g_est[i].erro, sizeof g_est[i].erro, "%s", msg);
  g_est[i].fase[0] = 0;
  pthread_mutex_unlock(&g_trava);
  diario("payloads: %s: erro: %s", ITENS[i].id, msg);
}

/* Hora da ativacao nesta sessao do PS5, ou 0. O arquivo .ativado guarda "hora pid_da_ShellUI" (0.9.22; antes so a
   hora; o arquivo vale mais que a memoria: e o que sobra depois de reabrir o glibren). Ativado antes de o PS5 ligar,
   ou com outra ShellUI (ela reiniciou), ja foi desfeito. */
static time_t ativado_em(int i) {
  char arq[600];
  long long v = 0;
  int pid = 0;
  pthread_mutex_lock(&g_trava);
  time_t mem = g_est[i].ativado_em;
  pthread_mutex_unlock(&g_trava);
  caminho(&ITENS[i], ".ativado", arq, sizeof arq);
  FILE *f = fopen(arq, "r");
  if(f) {
    int n = fscanf(f, "%lld %d", &v, &pid);
    if(n < 1) v = 0;
    if(n < 2) pid = 0;
    fclose(f);
  } else v = (long long)mem;   /* arquivo nao gravou: vale o da memoria */
  time_t t = (time_t)v;
  if(t <= ligou_em() + 5) return 0;   /* antes de o PS5 ligar: ja foi desfeito */
  int agora = pid ? pid_shellui() : 0;
  if(pid && agora && agora != pid) return 0;   /* a interface do PS5 reiniciou: o patch foi junto */
  return t;
}

/* ------------------------------------------------------------------ 0.9.33: esta rodando agora? */

#define SONDA_CACHE_S 8

/* PC: GLR_TESTE_SONDA_S (0 = sem cache) para os testes nao esperarem */
static int sonda_cache_s(void) {
#ifndef __PROSPERO__
  const char *v = getenv("GLR_TESTE_SONDA_S");
  if(v && *v) return atoi(v);
#endif
  return SONDA_CACHE_S;
}

/* GET em 127.0.0.1:porta (ate max bytes, espera_s). Status HTTP ou -1; corpo (sem cabecalho, terminado em \0) em resp. */
static int http_local(int porta, const char *rota, buf_t *resp, size_t max, int espera_s) {
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if(fd < 0) return -1;
  struct timeval t = {.tv_sec = espera_s};
  setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &t, sizeof t);
  setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &t, sizeof t);
#ifdef SO_NOSIGPIPE
  int sim = 1;
  setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &sim, sizeof sim);
#endif
  struct sockaddr_in end = {.sin_family = AF_INET, .sin_port = htons((uint16_t)porta)};
  end.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  char ped[256];
  int n = snprintf(ped, sizeof ped, "GET %s HTTP/1.1\r\nHost: 127.0.0.1:%d\r\nConnection: close\r\n\r\n", rota, porta);
  buf_t tudo = {0};
  int ok = !connect(fd, (struct sockaddr *)&end, sizeof end) && send(fd, ped, (size_t)n, SEM_SINAL) == n;
  time_t limite = time(NULL) + espera_s + 1;
  char bloco[16384];
  while(ok && time(NULL) <= limite) {
    ssize_t r = recv(fd, bloco, sizeof bloco, 0);
    if(r <= 0) break;
    if(tudo.n + (size_t)r > max) break;
    buf_add(&tudo, bloco, (size_t)r);
  }
  close(fd);
  int st = -1;
  if(ok && tudo.n > 12 && !strncmp(tudo.d, "HTTP/1.", 7)) {
    buf_add(&tudo, "", 1);
    st = atoi(tudo.d + 9);
    const char *c = strstr(tudo.d, "\r\n\r\n");
    if(c) buf_str(resp, c + 4);
    buf_add(resp, "", 1);
  }
  buf_free(&tudo);
  return st;
}

/* valor "x" da ULTIMA ocorrencia de "chave":"x" (so letras, numeros e . - + _) */
static void valor_final(const char *json, const char *chave, char *saida, size_t tam) {
  char padrao[48];
  snprintf(padrao, sizeof padrao, "\"%s\":\"", chave);
  const char *ult = NULL;
  for(const char *p = json; (p = strstr(p, padrao)); p++) ult = p;
  size_t k = 0;
  if(ult)
    for(const char *c = ult + strlen(padrao); *c && *c != '"' && k + 1 < tam; c++)
      if(strchr("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.-+_", *c)) saida[k++] = *c;
  saida[k] = 0;
}

static int porta_bluev(void) {
#ifndef __PROSPERO__
  const char *v = getenv("GLR_TESTE_BLUEV_PORTA");
  if(v && atoi(v) > 0) return atoi(v);
#endif
  return PORTA_BLUEV;
}

static int porta_zhithemes(void) {
#ifndef __PROSPERO__
  const char *v = getenv("GLR_TESTE_ZHITHEMES_PORTA");
  if(v && atoi(v) > 0) return atoi(v);
#endif
  return PORTA_ZHITHEMES;
}

static int porta_kraken(void) {
#ifndef __PROSPERO__
  const char *v = getenv("GLR_TESTE_KRAKEN_PORTA");
  if(v && atoi(v) > 0) return atoi(v);
#endif
  return PORTA_KRAKEN;
}

/* ShadowMount+ / ShadowKraken (mesmo processo, mesma API): cache de SONDA_CACHE_S */
static struct {
  time_t em;
  int api, processo;
  char versao[64];
} g_smp;
static pthread_mutex_t g_trava_smp = PTHREAD_MUTEX_INITIALIZER;

static void smp_estado(int *api, int *processo, char *versao, size_t tam) {
  pthread_mutex_lock(&g_trava_smp);
  time_t agora = time(NULL);
  if(!g_smp.em || agora - g_smp.em >= sonda_cache_s() || agora < g_smp.em) {
    char v[64];
    int a = apps_smp_versao(v, sizeof v);
    g_smp.api = a;
    g_smp.processo = plataforma_processo_rodando(PROCESSO_SMP);
    snprintf(g_smp.versao, sizeof g_smp.versao, "%s", a ? v : "");
    g_smp.em = time(NULL);
  }
  *api = g_smp.api;
  *processo = g_smp.processo;
  snprintf(versao, tam, "%s", g_smp.versao);
  pthread_mutex_unlock(&g_trava_smp);
}

/* As versoes do ShadowKraken sao tags "1.00-Dev.N..." (git describe); as do ShadowMount+ nao tem "Dev". */
static int versao_shadowkraken(const char *v) {
  return strstr(v, "-Dev") != NULL;
}

static time_t ativado_em(int i);

static void sondar(int i) {
  const item_t *it = &ITENS[i];
  pthread_mutex_lock(&g_trava);
  time_t em = g_est[i].sonda_em, agora = time(NULL);
  pthread_mutex_unlock(&g_trava);
  if(em && agora - em < sonda_cache_s() && agora >= em) return;
  int rodando = 0;
  char versao[64] = "", obs[32] = "";
  if(it->sonda == SONDA_DUMPFORGE) rodando = conversao_dumpforge_versao(versao, sizeof versao);
  else if(it->sonda == SONDA_BLUEV) {   /* 0.9.34: /api/status responde = rodando (nao traz a versao) */
    buf_t r = {0};
    int st = http_local(porta_bluev(), "/api/status", &r, 256 * 1024, 2);
    rodando = st == 200 && r.d && strstr(r.d, "\"state\"") != NULL;
    buf_free(&r);
  } else if(it->sonda == SONDA_ZHITHEMES) {
    /* 0.9.35: GET /version (texto, sem efeito colateral) = "zhithemes <versao> (build ...) ...". Um tema do OnionHEN
       responde "onionhen ...": nao conta. */
    buf_t r = {0};
    int st = http_local(porta_zhithemes(), "/version", &r, 4096, 2);
    if(st == 200 && r.d && !strncmp(r.d, "zhithemes ", 10)) {
      rodando = 1;
      size_t k = 0;
      for(const char *c = r.d + 10; *c && *c != ' ' && k + 1 < sizeof versao; c++)
        if(strchr("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.-+_", *c)) versao[k++] = *c;
      versao[k] = 0;
    }
    buf_free(&r);
  } else if(it->sonda == SONDA_KRAKEN) {
    buf_t r = {0};
    int st = http_local(porta_kraken(), "/api/state", &r, 4 * 1024 * 1024, 2);
    if(st == 200 && r.d) {
      rodando = 1;
      valor_final(r.d, "version", versao, sizeof versao);
      valor_final(r.d, "waiting", obs, sizeof obs);
    }
    buf_free(&r);
  } else if(it->sonda == SONDA_SHADOWKRAKEN) {
    int api, proc;
    char v[64];
    smp_estado(&api, &proc, v, sizeof v);
    if(api && versao_shadowkraken(v)) {
      rodando = 1;
      snprintf(versao, sizeof versao, "%s", v);
    } else if(!api && proc && ativado_em(i)) rodando = 1;   /* API desligada: vale o processo + ativado nesta sessao */
  }
  pthread_mutex_lock(&g_trava);
  g_est[i].sonda_em = time(NULL);
  g_est[i].rodando = rodando;
  snprintf(g_est[i].rodando_versao, sizeof g_est[i].rodando_versao, "%s", versao);
  snprintf(g_est[i].rodando_obs, sizeof g_est[i].rodando_obs, "%s", obs);
  pthread_mutex_unlock(&g_trava);
}

/* 1 = a versao rodando nao e a instalada ("v0.5.6" = "0.5.6"; "1.00-Dev.3" casa com "1.00-Dev.3-dirty", nao com "1.00-Dev.30") */
static int versao_diferente(const char *rodando, const char *instalada) {
  if(!rodando[0] || !instalada[0]) return 0;
  if(*rodando == 'v' || *rodando == 'V') rodando++;
  if(*instalada == 'v' || *instalada == 'V') instalada++;
  size_t n = strlen(instalada);
  if(strncmp(rodando, instalada, n)) return 1;
  char c = rodando[n];
  return c && ((c >= '0' && c <= '9') || c == '.');
}

/* 0.9.22: o item esta valendo nesta sessao (ativado pelo glibren ou, no PrefBar, rodando por outro caminho: os
   arquivos de estado dele mudaram depois que o PS5 ligou). 0.9.33: itens com sonda valem pelo que esta rodando. */
static int ativo_na_sessao(int i) {
  if(ITENS[i].sonda) {
    sondar(i);
    pthread_mutex_lock(&g_trava);
    int r = g_est[i].rodando;
    pthread_mutex_unlock(&g_trava);
    return r;
  }
  if(ativado_em(i)) return 1;
  return !strcmp(ITENS[i].id, "prefbar") && prefbar_rodou_desde((long long)ligou_em());
}

/* Outro item que mexe na ShellUI e esta ativo nesta sessao (indice) ou -1. */
static int conflito_com(int i) {
  if(!ITENS[i].shellui) return -1;
  for(int j = 0; j < N_ITENS; j++)
    if(j != i && ITENS[j].shellui && ativo_na_sessao(j)) return j;
  return -1;
}

/* ------------------------------------------------------------------ 0.9.33: GitHub (ultima release) */

#define GH_CACHE_S 3600     /* abrir a pagina: pergunta de novo so depois de 1 h */
#define GH_BOTAO_S 60       /* botao "Procurar atualizacoes": no maximo uma vez por minuto por item */
#define GH_CACHE_SUMIU_S (24 * 3600)   /* 0.9.34: repositorio 404 (removido/privado): abrir a pagina so pergunta 1x por dia */

/* PC: GLR_TESTE_GH_CACHE_S troca o cache de 1 h e o limite do botao (o de 24 h do 404 fica) */
static int gh_cache_s(int botao) {
#ifndef __PROSPERO__
  const char *t = getenv("GLR_TESTE_GH_CACHE_S");
  if(t && *t) return atoi(t);
#endif
  return botao ? GH_BOTAO_S : GH_CACHE_S;
}

/* 0.9.34: repositorio removido do GitHub (no PC, GLR_TESTE_SEM_REMOVIDOS=1 ignora, para os testes instalarem antes) */
static int removido(const item_t *it) {
#ifndef __PROSPERO__
  const char *t = getenv("GLR_TESTE_SEM_REMOVIDOS");
  if(t && *t == '1') return 0;
#endif
  return it->removido_em != NULL;
}

/* Quanto vale a ultima resposta do GitHub (404 vale um dia) */
static int cache_item(const estado_t *e) {
  return e->gh_res == GH_REPO_SUMIU ? GH_CACHE_SUMIU_S : gh_cache_s(0);
}

static int g_procurando;

/* Pergunta ao GitHub (bloqueia; fora da trava). */
static void consultar(int i) {
  const item_t *it = &ITENS[i];
  gh_release_t r;
  int http = -1;
  int res = gh_consultar(it->gh_repo, it->gh_pre, it->gh_padrao, &r, &http);
  time_t agora = time(NULL);
  pthread_mutex_lock(&g_trava);
  estado_t *e = &g_est[i];
  e->gh_http = http;
  e->tentou = agora;
  if(res == GH_OK || res == GH_SEM_ASSET || res == GH_VARIOS_ASSETS || res == GH_SEM_RELEASE || res == GH_REPO_SUMIU) {
    e->gh_res = res;
    e->gh_falha = 0;
    e->consultado = agora;   /* resposta definitiva do GitHub: vale o cache */
    e->disp = r;
    e->disp_ok = res == GH_OK && r.sha256[0] && r.tamanho > 0 && r.tamanho <= it->gh_max;
  } else e->gh_falha = res;   /* 0.9.39: sem resposta (limite, rede...): a ultima resposta boa (disp/gh_res) continua valendo */
  pthread_mutex_unlock(&g_trava);
  if(res == GH_OK)
    diario("payloads: %s: GitHub: %s%s, asset %s, %llu bytes, sha256 %.16s%s", it->id, r.tag, r.pre ? " (pre-release)" : "", r.asset,
           r.tamanho, r.sha256[0] ? r.sha256 : "(sem digest)", r.sha256[0] ? "..." : "");
  else diario("payloads: %s: GitHub: resultado %d (HTTP %d)", it->id, res, http);
}

/* forcar = botao (ignora o cache de 1 h, respeita 1 por minuto). Devolve quantos itens precisam perguntar. */
static int precisa(int i, int forcar, time_t agora) {
  const estado_t *e = &g_est[i];
  if(!ITENS[i].gh_repo || e->consultando || removido(&ITENS[i])) return 0;
  if(e->tentou && agora - e->tentou < gh_cache_s(1) && agora >= e->tentou) return 0;
  if(forcar) return 1;
  return !e->consultado || agora - e->consultado >= cache_item(e) || agora < e->consultado;
}

/* Pergunta pelos itens marcados "consultando" (marcados pela rota, antes da thread: o estado ja sai certo). */
static void *procurar(void *arg) {
  (void)arg;
  for(int i = 0; i < N_ITENS; i++) {
    pthread_mutex_lock(&g_trava);
    int vai = g_est[i].consultando;
    pthread_mutex_unlock(&g_trava);
    if(!vai) continue;
    consultar(i);
    pthread_mutex_lock(&g_trava);
    g_est[i].consultando = 0;
    pthread_mutex_unlock(&g_trava);
  }
  pthread_mutex_lock(&g_trava);
  g_procurando = 0;
  pthread_mutex_unlock(&g_trava);
  return NULL;
}

/* Ate a 0.9.32 os itens eram fixos e o arquivo tinha o nome do asset: se bater com o SHA-256 que era fixo, vira a
   versao instalada (nao baixa de novo). Uma vez por execucao. */
static const struct {
  const char *id, *arquivo, *versao, *sha256;
  unsigned long long tamanho;
} LEGADOS[] = {
  {"web-browser-fullscreen", "web-browser-fullscreen-v0.1b.elf", "v0.1b", "520977607a22ecdf51c8d8b75360486026e0bd8780ded8026c3456fac7997a97", 463848ULL},
  {"prefbar", "Prefbar_V0.3.0.elf", "v0.3.0", "e4379590115ef87b2f0310b502321d7da30783536d939bfb1c4c0e511972af30", 964272ULL},
  {"dump-forge", DF_LEGADO_ARQ, "v0.5.6", DF_LEGADO_SHA, DF_LEGADO_TAM},
};

static void migrar_legado(void) {
  for(size_t k = 0; k < sizeof LEGADOS / sizeof LEGADOS[0]; k++) {
    int i = achar(LEGADOS[k].id);
    if(i < 0 || !ITENS[i].gh_repo) continue;
    const item_t *it = &ITENS[i];
    char p[512], velho[600], novo[600], info[600];
    info_t in;
    pasta(p, sizeof p);
    snprintf(velho, sizeof velho, "%s/%s", p, LEGADOS[k].arquivo);
    caminho(it, NULL, novo, sizeof novo);
    caminho(it, ".info", info, sizeof info);
    struct stat st;
    if(lstat(velho, &st) || !S_ISREG(st.st_mode) || !info_ler(it, 0, &in) || !lstat(novo, &st)) continue;
    if(!arquivo_confere_em(velho, LEGADOS[k].sha256, LEGADOS[k].tamanho, NULL)) {
      diario("payloads: %s nao confere com o SHA-256 de antes: ignorado", LEGADOS[k].arquivo);
      continue;
    }
    memset(&in, 0, sizeof in);
    snprintf(in.versao, sizeof in.versao, "%s", LEGADOS[k].versao);
    snprintf(in.sha256, sizeof in.sha256, "%s", LEGADOS[k].sha256);
    snprintf(in.asset, sizeof in.asset, "%s", LEGADOS[k].arquivo);
    in.tamanho = LEGADOS[k].tamanho;
    if(!rename(velho, novo) && !info_gravar(info, &in)) diario("payloads: %s %s guardado antes adotado como versao instalada", it->id, in.versao);
  }
}

static pthread_once_t g_migrou = PTHREAD_ONCE_INIT;

void payloads_firmware(char *saida, size_t tam) {
  firmware(saida, tam);
}

void payloads_rota_estado(pedido_t *p) {
  buf_t b = {0};
  payloads_json(&b);
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* 0.9.21: o mesmo JSON do GET /api/payloads, tambem para o diagnostico */
void payloads_json(buf_t *saida) {
  static const char *const LING[] = {"pt-BR", "en", "es"};
  static const char *const CAMPOS[] = {"descricao", "desfazer", "aviso"};
  char fw[16], arq[600];
  pthread_once(&g_migrou, migrar_legado);
  firmware(fw, sizeof fw);
  buf_t b = {0};
  buf_str(&b, "{\"ok\":true,\"firmware\":");
  buf_json(&b, fw);
  /* 0.9.33: ShadowMount+ (ou ShadowKraken, que usa o mesmo processo e a mesma API) rodando agora? */
  {
    int api, proc;
    char v[64];
    smp_estado(&api, &proc, v, sizeof v);
    const char *tipo = api ? (versao_shadowkraken(v) ? "shadowkraken" : "smp") : proc ? "desconhecido" : "";
    buf_fmt(&b, ",\"smp\":{\"api\":%s,\"processo\":%s,\"versao\":", api ? "true" : "false", proc ? "true" : "false");
    buf_json(&b, v);
    buf_str(&b, ",\"tipo\":");
    buf_json(&b, tipo);
    buf_fmt(&b, "},\"gh_bloqueado_ate\":%lld,\"gh_livre_em\":%lld", gh_bloqueado_ate(), gh_livre_em());
  }
  pthread_mutex_lock(&g_trava);
  buf_fmt(&b, ",\"ocupado\":%s,\"agora\":%lld,\"itens\":[", g_ocupado ? "true" : "false", (long long)time(NULL));
  pthread_mutex_unlock(&g_trava);
  for(int i = 0, n = 0; i < N_ITENS; i++) {
    const item_t *it = &ITENS[i];
    int rem = it->gh_repo && removido(it);
    if(rem) {   /* 0.9.34: sem nada guardado nao da para instalar: o item some */
      char a1[600], a2[600];
      struct stat s1;
      caminho(it, NULL, a1, sizeof a1);
      caminho(it, ".anterior.elf", a2, sizeof a2);
      if(lstat(a1, &s1) && lstat(a2, &s1)) continue;
    }
    int ok = pronto(i);
    time_t ativ = ativado_em(i);
    if(it->sonda && !ativo_na_sessao(i)) ativ = 0;   /* 0.9.30/0.9.33: saiu (fechado pela pagina dele) */
    info_t inst, ant;
    int tem_inst = it->gh_repo && !info_ler(it, 0, &inst), tem_ant = it->gh_repo && !info_ler(it, 1, &ant);
    struct stat st;
    caminho(it, NULL, arq, sizeof arq);
    int existe = !lstat(arq, &st);
    /* 0.9.22: exclusao mutua dos que mexem na ShellUI (quem esta ativo nesta sessao do PS5 bloqueia os outros);
       "rodando" = PrefBar rodando nesta sessao sem ter sido ativado pelo glibren */
    int outro = conflito_com(i), ativo = ativo_na_sessao(i);
    pthread_mutex_lock(&g_trava);
    estado_t e = g_est[i];
    pthread_mutex_unlock(&g_trava);
    if(rem) {
      e.disp_ok = 0;
      e.consultado = 0;
      e.gh_res = GH_REPO_SUMIU;
      e.gh_falha = 0;
    }
    const char *estado = e.fase[0] ? e.fase : e.erro[0] ? "erro" : ativ ? "ativado" : ativo ? "rodando" : ok ? "pronto" : "nao_baixado";
    buf_str(&b, n++ ? ",{" : "{");
    buf_str(&b, "\"id\":"); buf_json(&b, it->id);
    buf_str(&b, ",\"nome\":"); buf_json(&b, it->nome);
    buf_str(&b, ",\"autor\":"); buf_json(&b, it->autor);
    buf_str(&b, ",\"licenca\":"); buf_json(&b, it->licenca);
    buf_str(&b, ",\"repo\":"); buf_json(&b, it->repo);
    if(it->gh_repo) {
      /* 0.9.33: o que esta instalado; senao, o que o GitHub oferece */
      gh_release_t d = e.disp;
      char url[600] = "";
      if(e.disp_ok) gh_url_asset(it->gh_repo, &d, url, sizeof url);
      buf_str(&b, ",\"tag\":"); buf_json(&b, tem_inst ? inst.versao : e.disp_ok ? d.tag : "");
      buf_str(&b, ",\"url\":"); buf_json(&b, url);
      buf_str(&b, ",\"sha256\":"); buf_json(&b, tem_inst ? inst.sha256 : e.disp_ok ? d.sha256 : "");
      buf_fmt(&b, ",\"tamanho\":%llu", tem_inst ? inst.tamanho : e.disp_ok ? d.tamanho : 0ULL);
      static const char *const ERROS[] = {"", "rede", "http", "limite", "json", "sem_release", "sem_asset", "varios_assets",
                                         "repo_indisponivel"};
      /* 0.9.39: "erro" = o da ultima tentativa (limite, rede...) se ela nao respondeu; senao, o da ultima resposta.
         "disponivel", "atualizar" e "pode_instalar" vem todos da ultima resposta boa ("cache":true = ela e de antes de
         uma tentativa que falhou; a data e o consultado_em). Antes, com o limite, "disponivel" ficava null e o resto
         continuava true (botao "Atualizar para" sem a linha "No GitHub"). */
      int falha = e.gh_falha < 0 && e.gh_falha >= -8 ? -e.gh_falha : 0;
      int ie = falha ? falha : e.gh_res < 0 && e.gh_res >= -8 ? -e.gh_res : 0;
      if(rem) ie = 8;   /* nao consulta: vale o que se sabe */
      int sem_digest = !falha && e.consultado && e.gh_res == GH_OK && !d.sha256[0];
      int grande = !falha && e.consultado && e.gh_res == GH_OK && d.sha256[0] && (d.tamanho == 0 || d.tamanho > it->gh_max);
      int tem_disp = e.consultado && e.gh_res == GH_OK && d.tag[0];
      buf_str(&b, ",\"gh\":{\"repo\":"); buf_json(&b, it->gh_repo);
      buf_str(&b, ",\"padrao\":"); buf_json(&b, it->gh_padrao);
      buf_str(&b, ",\"removido_em\":"); buf_json(&b, rem ? it->removido_em : "");
      buf_fmt(&b, ",\"pre_releases\":%s,\"instalada\":", it->gh_pre ? "true" : "false");
      if(tem_inst) {
        buf_str(&b, "{\"versao\":"); buf_json(&b, inst.versao);
        buf_str(&b, ",\"asset\":"); buf_json(&b, inst.asset);
        buf_str(&b, ",\"sha256\":"); buf_json(&b, inst.sha256);
        buf_fmt(&b, ",\"tamanho\":%llu}", inst.tamanho);
      } else buf_str(&b, "null");
      buf_str(&b, ",\"anterior\":");
      if(tem_ant) {
        buf_str(&b, "{\"versao\":"); buf_json(&b, ant.versao);
        buf_fmt(&b, ",\"tamanho\":%llu}", ant.tamanho);
      } else buf_str(&b, "null");
      buf_str(&b, ",\"disponivel\":");
      if(tem_disp) {
        buf_str(&b, "{\"versao\":"); buf_json(&b, d.tag);
        buf_fmt(&b, ",\"pre\":%s,\"asset\":", d.pre ? "true" : "false"); buf_json(&b, d.asset);
        buf_fmt(&b, ",\"tamanho\":%llu,\"sha256\":", d.tamanho); buf_json(&b, d.sha256);
        buf_str(&b, ",\"publicado\":"); buf_json(&b, d.publicado);
        buf_str(&b, "}");
      } else buf_str(&b, "null");
      buf_str(&b, ",\"erro\":");
      buf_json(&b, sem_digest ? "sem_digest" : grande ? "grande" : ERROS[ie]);
      int pode = e.disp_ok && tem_disp;   /* nunca "pode instalar" sem "disponivel" */
      int atualizar = pode && (!tem_inst || strcmp(inst.sha256, d.sha256));
      buf_fmt(&b, ",\"cache\":%s,\"http\":%d,\"consultado_em\":%lld,\"tentou_em\":%lld,\"consultando\":%s,\"atualizar\":%s,\"pode_instalar\":%s}",
              tem_disp && falha ? "true" : "false", e.gh_http, (long long)e.consultado, (long long)e.tentou, e.consultando ? "true" : "false",
              atualizar ? "true" : "false", pode ? "true" : "false");
    } else {
      buf_str(&b, ",\"tag\":"); buf_json(&b, it->tag);
      buf_str(&b, ",\"url\":"); buf_json(&b, it->url);
      buf_str(&b, ",\"sha256\":"); buf_json(&b, it->sha256);
      buf_fmt(&b, ",\"tamanho\":%llu,\"gh\":null", it->tamanho);
    }
    /* 0.9.33: rodando agora (null = o glibren nao tem como saber) */
    if(it->sonda) {
      buf_fmt(&b, ",\"rodando\":%s,\"rodando_versao\":", e.rodando ? "true" : "false");
      buf_json(&b, e.rodando ? e.rodando_versao : "");
      buf_str(&b, ",\"rodando_obs\":");
      buf_json(&b, e.rodando ? e.rodando_obs : "");
      buf_fmt(&b, ",\"versao_diferente\":%s", e.rodando && tem_inst && versao_diferente(e.rodando_versao, inst.versao) ? "true" : "false");
    } else buf_fmt(&b, ",\"rodando\":%s,\"rodando_versao\":\"\",\"rodando_obs\":\"\",\"versao_diferente\":false", ativo ? "true" : "null");
    buf_fmt(&b, ",\"aviso_smp\":%s,\"total\":%llu", it->aviso_smp ? "true" : "false", e.total);
    buf_str(&b, ",\"firmwares\":"); buf_json(&b, it->firmwares);
    buf_str(&b, ",\"confirmados\":"); buf_json(&b, it->confirmados ? it->confirmados : "");
    buf_str(&b, ",\"confirmado_em\":"); buf_json(&b, it->confirmado_em ? it->confirmado_em : "");
    /* 0.9.22: "12.xx" na lista do autor = so a faixa que ele diz suportar (nao um teste no 12.00): "faixa_do_autor".
       0.9.23: um firmware que nos confirmamos no PS5 real tambem conta como testado ("confirmado_no_seu") */
    int nosso = fw[0] && it->confirmados && palavra(it->confirmados, fw);
    int exato = fw[0] && (nosso || palavra(it->firmwares, fw)), faixa = fw[0] && !exato && na_lista(it->firmwares, fw);
    buf_fmt(&b, ",\"testado_no_seu\":%s,\"faixa_do_autor\":%s,\"confirmado_no_seu\":%s", !fw[0] ? "null" : exato ? "true" : "false",
            faixa ? "true" : "false", nosso ? "true" : "false");
    const char *const *textos[] = {it->descricao, it->desfazer, it->aviso};
    for(int c = 0; c < 3; c++) {
      buf_fmt(&b, ",\"%s\":{", CAMPOS[c]);
      for(int l = 0; l < 3; l++) {
        buf_str(&b, l ? "," : "");
        buf_json(&b, LING[l]);
        buf_str(&b, ":");
        buf_json(&b, textos[c][l]);
      }
      buf_str(&b, "}");
    }
    buf_fmt(&b, ",\"shellui\":%s,\"uma_vez\":%s,\"ativo_sessao\":%s,\"rodando_fora\":%s,\"bloqueado_por\":", it->shellui ? "true" : "false",
            it->uma_vez ? "true" : "false", ativo ? "true" : "false", ativo && !ativ ? "true" : "false");
    buf_json(&b, outro >= 0 ? ITENS[outro].nome : "");
    buf_fmt(&b, ",\"navegador\":%s,\"estado\":", it->navegador ? "true" : "false");
    buf_json(&b, estado);
    buf_fmt(&b, ",\"guardado\":%s,\"conferido\":%s,\"ativado_em\":%lld,\"baixados\":%llu,\"erro\":", existe ? "true" : "false",
            ok ? "true" : "false", (long long)ativ, e.baixados);
    buf_json(&b, e.erro);
    buf_str(&b, ",\"saida\":");
    buf_json(&b, e.saida);
    buf_str(&b, "}");
  }
  buf_str(&b, "]}");
  buf_add(saida, b.d, b.n);
  buf_free(&b);
}

int payloads_ocupado(void) {
  pthread_mutex_lock(&g_trava);
  int o = g_ocupado;
  pthread_mutex_unlock(&g_trava);
  return o;
}

/* ------------------------------------------------------------------ baixar */

typedef struct {
  int fd, excedeu, erro_gravar, i;
  unsigned long long n, limite;
  sha256_t sha;
} download_t;

static int recebeu(const void *dados, size_t n, void *ctx) {
  download_t *d = ctx;
  if(!dados) return 0;
  if(d->n + n > d->limite) {
    d->excedeu = 1;
    return 1;
  }
  for(size_t feitos = 0; feitos < n;) {
    ssize_t r = write(d->fd, (const char *)dados + feitos, n - feitos);
    if(r <= 0) {
      d->erro_gravar = 1;
      return 1;
    }
    feitos += (size_t)r;
  }
  sha256_atualizar(&d->sha, dados, n);
  d->n += n;
  pthread_mutex_lock(&g_trava);
  g_est[d->i].baixados = d->n;
  pthread_mutex_unlock(&g_trava);
  return 0;
}

/* Baixa, confere o SHA-256 e guarda. 0 = ok. */
static int baixar(int i) {
  const item_t *it = &ITENS[i];
  char p[512], arq[600], parcial[620], url[700], hex[65];
  pasta(p, sizeof p);
  caminho(it, NULL, arq, sizeof arq);
  snprintf(parcial, sizeof parcial, "%s.part", arq);
  url_item(it, url, sizeof url);
  fase(i, "baixando");
  if(mkdir_p(p)) {
    falhou(i, "nao criou a pasta %s (%s)", p, strerror(errno));
    return -1;
  }
  download_t d;
  memset(&d, 0, sizeof d);
  d.i = i;
  d.limite = tam_item(it);
  sha256_iniciar(&d.sha);
  unlink(parcial);
  if((d.fd = open(parcial, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644)) < 0) {
    falhou(i, "nao criou %s (%s)", parcial, strerror(errno));
    return -1;
  }
  int status = https_baixar(url, recebeu, &d);
  int erro_fechar = fsync(d.fd);
  erro_fechar |= close(d.fd);
  diario("payloads: %s: download %s status %d, %llu bytes", it->id, url, status, d.n);
  if(status != 200 || d.excedeu || d.erro_gravar || erro_fechar || d.n != d.limite) {
    unlink(parcial);
    if(status != 200) falhou(i, "nao foi possivel baixar (HTTP %d)", status);
    else if(d.excedeu || d.n != d.limite) falhou(i, "tamanho diferente do fixado (%llu de %llu bytes): recusado", d.n, d.limite);
    else falhou(i, "erro ao gravar no PS5");
    return -1;
  }
  fase(i, "conferindo");
  uint8_t resumo[32];
  sha256_final(&d.sha, resumo);
  sha256_hex(resumo, hex);
  if(strcmp(hex, sha_item(it))) {
    unlink(parcial);
    falhou(i, "SHA-256 nao confere: arquivo recusado (veio %.16s..., esperado %.16s...)", hex, sha_item(it));
    return -1;
  }
  if(rename(parcial, arq)) {
    unlink(parcial);
    falhou(i, "nao guardou o arquivo (%s)", strerror(errno));
    return -1;
  }
  diario("payloads: %s: baixado e conferido (sha256 %.16s...) em %s", it->id, hex, arq);
  return 0;
}

/* ------------------------------------------------------------------ 0.9.33: instalar/atualizar e voltar (GitHub) */

/* Baixa a ultima release (consultada antes) para <id>.elf.tmp, confere tamanho e SHA-256 com o digest que a API do
   GitHub informou, guarda a versao atual como anterior e troca (rename). Sem digest = recusado. 0 = ok (ou ja estava). */
static int instalar_gh(int i) {
  const item_t *it = &ITENS[i];
  char p[512], arq[600], tmp[620], info[600], ant[620], ant_info[620], url[700], hex[65];
  if(removido(it)) {
    falhou(i, "repositorio removido do GitHub em %s: nada para instalar ou atualizar", it->removido_em);
    return -1;
  }
  pthread_mutex_lock(&g_trava);
  int velho = !g_est[i].consultado || time(NULL) - g_est[i].consultado >= cache_item(&g_est[i]);
  pthread_mutex_unlock(&g_trava);
  if(velho) {   /* sem consulta recente: pergunta agora (respeita o limite) */
    fase(i, "consultando");
    consultar(i);
  }
  pthread_mutex_lock(&g_trava);
  gh_release_t d = g_est[i].disp;
  int disp_ok = g_est[i].disp_ok, res = g_est[i].gh_falha ? g_est[i].gh_falha : g_est[i].gh_res, consultado = g_est[i].consultado != 0;
  pthread_mutex_unlock(&g_trava);
  if(!disp_ok) {
    if(res == GH_LIMITE) {   /* 0.9.39: limite proprio (30/h) ou pausa depois de 403/429: diz quando volta */
      long long livre = gh_livre_em(), agora = (long long)time(NULL);
      falhou(i, "limite de consultas ao GitHub: tente de novo em %lld min", livre > agora ? (livre - agora + 59) / 60 : 1LL);
    }
    else if(res == GH_REDE) falhou(i, "sem resposta do GitHub (internet do PS5?)");
    else if(res == GH_SEM_ASSET) falhou(i, "a ultima release nao tem o arquivo %s", it->gh_padrao);
    else if(res == GH_VARIOS_ASSETS) falhou(i, "a ultima release tem mais de um arquivo %s: recusado", it->gh_padrao);
    else if(res == GH_SEM_RELEASE) falhou(i, "o repositorio nao tem release publicada");
    else if(res == GH_REPO_SUMIU) falhou(i, "repositorio indisponivel no GitHub (removido ou privado)");
    else if(consultado && res == GH_OK && !d.sha256[0])
      falhou(i, "a API do GitHub nao informou o SHA-256 (digest) de %s: sem conferencia, nao instala", d.asset);
    else if(consultado && res == GH_OK) falhou(i, "tamanho do arquivo fora do limite (%llu bytes): recusado", d.tamanho);
    else falhou(i, "nao deu para consultar o GitHub (resultado %d)", res);
    return -1;
  }
  info_t atual;
  if(!info_ler(it, 0, &atual) && !strcmp(atual.sha256, d.sha256) && pronto(i)) {
    diario("payloads: %s: %s ja instalada", it->id, d.tag);
    return 0;
  }
  pasta(p, sizeof p);
  caminho(it, NULL, arq, sizeof arq);
  caminho(it, ".info", info, sizeof info);
  caminho(it, ".anterior.elf", ant, sizeof ant);
  caminho(it, ".anterior.info", ant_info, sizeof ant_info);
  snprintf(tmp, sizeof tmp, "%s.tmp", arq);
  gh_url_asset(it->gh_repo, &d, url, sizeof url);
  if(mkdir_p(p)) {
    falhou(i, "nao criou a pasta %s (%s)", p, strerror(errno));
    return -1;
  }
  download_t dl;
  memset(&dl, 0, sizeof dl);
  dl.i = i;
  dl.limite = d.tamanho;
  sha256_iniciar(&dl.sha);
  pthread_mutex_lock(&g_trava);
  g_est[i].total = d.tamanho;
  g_est[i].baixados = 0;
  snprintf(g_est[i].fase, sizeof g_est[i].fase, "baixando");
  pthread_mutex_unlock(&g_trava);
  unlink(tmp);
  if((dl.fd = open(tmp, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644)) < 0) {
    falhou(i, "nao criou %s (%s)", tmp, strerror(errno));
    return -1;
  }
  int status = https_baixar(url, recebeu, &dl);
  int erro_fechar = fsync(dl.fd);
  erro_fechar |= close(dl.fd);
  diario("payloads: %s: download %s status %d, %llu bytes", it->id, url, status, dl.n);
  if(status != 200 || dl.excedeu || dl.erro_gravar || erro_fechar || dl.n != dl.limite) {
    unlink(tmp);
    if(status != 200) falhou(i, "nao foi possivel baixar (HTTP %d)", status);
    else if(dl.excedeu || dl.n != dl.limite) falhou(i, "tamanho diferente do informado pelo GitHub (%llu de %llu bytes): recusado", dl.n, dl.limite);
    else falhou(i, "erro ao gravar no PS5");
    return -1;
  }
  fase(i, "conferindo");
  uint8_t resumo[32];
  sha256_final(&dl.sha, resumo);
  sha256_hex(resumo, hex);
  if(strcmp(hex, d.sha256)) {
    unlink(tmp);
    falhou(i, "SHA-256 nao confere com o digest do GitHub: arquivo recusado (veio %.16s..., esperado %.16s...)", hex, d.sha256);
    return -1;
  }
  info_t novo;
  memset(&novo, 0, sizeof novo);
  snprintf(novo.versao, sizeof novo.versao, "%s", d.tag);
  snprintf(novo.sha256, sizeof novo.sha256, "%s", d.sha256);
  snprintf(novo.asset, sizeof novo.asset, "%s", d.asset);
  novo.tamanho = d.tamanho;
  /* a atual (conferida) vira a anterior; uma atual que nao confere e descartada */
  struct stat st;
  if(!lstat(arq, &st)) {
    if(!info_ler(it, 0, &atual) && arquivo_confere(it, NULL) && !rename(arq, ant) && !info_gravar(ant_info, &atual))
      diario("payloads: %s: %s guardada como anterior", it->id, atual.versao);
    else unlink(arq);
  }
  if(rename(tmp, arq) || info_gravar(info, &novo)) {
    unlink(tmp);
    falhou(i, "nao guardou o arquivo (%s)", strerror(errno));
    return -1;
  }
  diario("payloads: %s: %s instalada (sha256 %.16s... conferido com o digest do GitHub)", it->id, d.tag, hex);
  return 0;
}

/* Troca a instalada pela anterior (a anterior e conferida pelo SHA-256 dela antes). A que sai vira a anterior. */
static int voltar(int i) {
  const item_t *it = &ITENS[i];
  char arq[600], info[600], ant[620], ant_info[620], troca[640];
  info_t in_ant, in_atual;
  caminho(it, NULL, arq, sizeof arq);
  caminho(it, ".info", info, sizeof info);
  caminho(it, ".anterior.elf", ant, sizeof ant);
  caminho(it, ".anterior.info", ant_info, sizeof ant_info);
  snprintf(troca, sizeof troca, "%s.troca", arq);
  fase(i, "conferindo");
  if(info_ler(it, 1, &in_ant) || !arquivo_confere_em(ant, in_ant.sha256, in_ant.tamanho, NULL)) {
    falhou(i, "a versao anterior guardada nao confere (ou nao existe): nada trocado");
    return -1;
  }
  int tem_atual = !info_ler(it, 0, &in_atual) && arquivo_confere(it, NULL);
  if(tem_atual ? rename(arq, troca) : 0) {
    falhou(i, "nao trocou (%s)", strerror(errno));
    return -1;
  }
  if(rename(ant, arq)) {
    if(tem_atual) rename(troca, arq);
    falhou(i, "nao trocou (%s)", strerror(errno));
    return -1;
  }
  info_gravar(info, &in_ant);
  if(tem_atual && !rename(troca, ant)) info_gravar(ant_info, &in_atual);
  else {
    unlink(troca);
    unlink(ant_info);
  }
  diario("payloads: %s: voltou para %s (anterior agora: %s)", it->id, in_ant.versao, tem_atual ? in_atual.versao : "nenhuma");
  return 0;
}

/* ------------------------------------------------------------------ PS5: tela inicial e navegador */

static int ir_para_home(void) {
#ifdef __PROSPERO__
  if(!sceKernelLoadStartModule || !sceUserServiceGetForegroundUser) return -1;
  int modulo = sceKernelLoadStartModule("/system_ex/common_ex/lib/libSceShellUIUtil.sprx", 0, NULL, 0, NULL, NULL);
  if(modulo < 0) {
    diario("payloads: libSceShellUIUtil nao carregou (0x%08x)", (unsigned)modulo);
    return modulo;
  }
  int (*iniciar)(void) = (void *)kernel_dynlib_dlsym(-1, (uint32_t)modulo, "sceShellUIUtilInitialize");
  int (*por_uri)(const char *, void *) = (void *)kernel_dynlib_dlsym(-1, (uint32_t)modulo, "sceShellUIUtilLaunchByUri");
  if(!iniciar || !por_uri) {
    diario("payloads: libSceShellUIUtil sem as funcoes esperadas");
    return -1;
  }
  int r = iniciar();
  if(r < 0) diario("payloads: sceShellUIUtilInitialize 0x%08x", (unsigned)r);
  struct {
    uint32_t tamanho, usuario;
  } par = {8, 0};
  sceUserServiceGetForegroundUser(&par.usuario);
  r = por_uri("pshomeui:navigateToHome?bootCondition=psButton", &par);
  diario("payloads: tela inicial 0x%08x", (unsigned)r);
  return r;
#else
  diario("payloads (PC): voltaria para a tela inicial");
  return 0;
#endif
}

static int abrir_navegador(const char *url) {
#ifdef __PROSPERO__
  if(!sceSystemServiceLaunchWebBrowser) return -1;
  int r = sceSystemServiceLaunchWebBrowser(url, NULL);
  diario("payloads: navegador reaberto em %s (0x%08x)", url, (unsigned)r);
  return r;
#else
  diario("payloads (PC): abriria o navegador em %s", url);
  return 0;
#endif
}

/* ------------------------------------------------------------------ elfldr */

/* Envia ao elfldr e le a saida do payload ate ele terminar (ou espera_s). 0 = enviado. */
static int enviar_elfldr(const void *dados, size_t n, int espera_s, buf_t *saida) {
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if(fd < 0) return -1;
  int porta = PORTA_ELFLDR;
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_ELFLDR")) porta = atoi(getenv("GLR_TESTE_ELFLDR"));
#endif
  struct timeval um = {.tv_sec = 1};
  setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &um, sizeof um);
  struct timeval dez = {.tv_sec = 10};
  setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &dez, sizeof dez);
#ifdef SO_NOSIGPIPE
  int sim = 1;
  setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &sim, sizeof sim);
#endif
  struct sockaddr_in end = {.sin_family = AF_INET, .sin_port = htons(porta)};
  end.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  int ok = !connect(fd, (struct sockaddr *)&end, sizeof end);
  for(size_t enviados = 0; ok && enviados < n;) {
    ssize_t r = send(fd, (const char *)dados + enviados, n - enviados, SEM_SINAL);
    if(r <= 0) ok = 0;
    else enviados += (size_t)r;
  }
  if(ok) {
    shutdown(fd, SHUT_WR);   /* fim do .elf; a leitura continua: a saida do payload chega por aqui */
    time_t limite = time(NULL) + espera_s;
    char bloco[2048];
    while(time(NULL) < limite) {
      ssize_t r = recv(fd, bloco, sizeof bloco, 0);
      if(r == 0) break;   /* o payload terminou */
      if(r < 0) {
        if(errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) continue;
        break;
      }
      if(saida->n + (size_t)r <= MAX_SAIDA) buf_add(saida, bloco, (size_t)r);
    }
  }
  close(fd);
  buf_add(saida, "", 1);
  return ok ? 0 : -1;
}

/* Linha que comeca com "prefixo" (sem o prefixo e o fim de linha; so ASCII visivel). 1 = achou. */
static int linha(const char *texto, const char *prefixo, char *saida, size_t tam) {
  saida[0] = 0;
  size_t np = strlen(prefixo);
  for(const char *p = texto; p && *p;) {
    if(!strncmp(p, prefixo, np)) {
      size_t k = 0;
      for(const char *c = p + np; *c && *c != '\n' && *c != '\r' && k + 1 < tam; c++) saida[k++] = (*c >= ' ' && *c <= '~') ? *c : '?';
      saida[k] = 0;
      return 1;
    }
    p = strchr(p, '\n');
    if(p) p++;
  }
  return 0;
}

/* ------------------------------------------------------------------ trabalho */

typedef struct {
  int i, ativar, voltar;
  char reabrir[300];   /* URL completa para reabrir o navegador ("" = nao reabre) */
} trabalho_t;

static void gravar_ativado(const item_t *it, time_t quando) {
  char arq[600], tmp[620];
  caminho(it, ".ativado", arq, sizeof arq);
  snprintf(tmp, sizeof tmp, "%s.tmp", arq);
  FILE *f = fopen(tmp, "w");
  if(!f) return;
  int pid = it->shellui ? pid_shellui() : 0;   /* 0.9.33: so os patches da ShellUI morrem com ela */
  fprintf(f, "%lld %d\n", (long long)quando, pid);   /* quem foi ativado (o arquivo) e quando, nesta ShellUI */
  int ok = !fflush(f) && !fsync(fileno(f));
  if(fclose(f) || !ok || rename(tmp, arq)) unlink(tmp);
  else diario("payloads: %s: ativacao gravada (hora %lld, ShellUI pid %d, PS5 ligado desde %lld)", it->id, (long long)quando, pid,
              (long long)ligou_em());
}

/* Envia ao elfldr e interpreta a saida. 0 = ativado. */
static int aplicar(int i, const buf_t *elf) {
  const item_t *it = &ITENS[i];
  buf_t saida = {0};
  int r = -1;
  char res[200] = "", aviso[400] = "", resumo[600] = "";
  fase(i, "aplicando");
  diario("payloads: %s: enviando ao elfldr (%zu bytes)", it->id, elf->n);
  if(enviar_elfldr(elf->d, elf->n, it->espera_s, &saida)) {
    falhou(i, "o elfldr (porta 9021) nao respondeu");
    goto fim;
  }
  int tem_res = linha(saida.d, "Result=", res, sizeof res);
  if(!linha(saida.d, "Notification: ", aviso, sizeof aviso)) linha(saida.d, "[elfldr.elf] ", aviso, sizeof aviso);
  snprintf(resumo, sizeof resumo, "%s%s%s%s", tem_res ? "Result=" : "", res, tem_res && aviso[0] ? " | " : "", aviso);
  diario("payloads: %s: saida do payload: %s", it->id, resumo[0] ? resumo : "(nada)");
  pthread_mutex_lock(&g_trava);
  snprintf(g_est[i].saida, sizeof g_est[i].saida, "%s", resumo);
  pthread_mutex_unlock(&g_trava);
  int codigo = tem_res ? atoi(res) : -1;
  if(tem_res && codigo != 0 && codigo != 2) {
    falhou(i, "o payload informou falha: %s", aviso[0] ? aviso : res);
    goto fim;
  }
  if(!tem_res && strstr(saida.d, "[elfldr.elf]")) {
    falhou(i, "o elfldr recusou: %s", aviso);
    goto fim;
  }
  time_t agora = time(NULL);
  gravar_ativado(it, agora);
  pthread_mutex_lock(&g_trava);
  g_est[i].ativado_em = agora;
  g_est[i].erro[0] = 0;
  pthread_mutex_unlock(&g_trava);
  diario("payloads: %s: ativado%s", it->id, tem_res ? "" : " (o payload nao confirmou; veja a notificacao do PS5)");
  r = 0;
fim:
  buf_free(&saida);
  return r;
}

static void *trabalhar(void *arg) {
  trabalho_t t = *(trabalho_t *)arg;
  free(arg);
  const item_t *it = &ITENS[t.i];
  buf_t elf = {0};
  int home = 0;
  if(t.voltar) {
    voltar(t.i);
    goto fim;
  }
  if(it->gh_repo) {
    /* 0.9.33: Baixar = instalar/atualizar para a ultima; Ativar sem nada instalado instala a ultima antes */
    if((!t.ativar || !pronto(t.i)) && instalar_gh(t.i)) goto fim;
  } else if(!pronto(t.i) && baixar(t.i)) goto fim;
  if(!t.ativar) goto fim;
  /* confere de novo o arquivo guardado (pode ter sido trocado no disco depois do download) */
  fase(t.i, "conferindo");
  if(!arquivo_confere(it, &elf)) {
    char arq[600];
    caminho(it, NULL, arq, sizeof arq);
    unlink(arq);
    falhou(t.i, "o arquivo guardado nao confere com o SHA-256 %s: apagado (baixe de novo)", it->gh_repo ? "da versao instalada" : "fixado");
    goto fim;
  }
  if(it->navegador) {
    fase(t.i, "home");
    usleep(250000);   /* a resposta chega ao navegador antes de sair dele */
    home = !ir_para_home();
    if(home) usleep(1000000);
  }
  aplicar(t.i, &elf);
  if(it->navegador && t.reabrir[0]) {
    fase(t.i, "reabrindo");
    if(!home) usleep(250000);
    abrir_navegador(t.reabrir);   /* mesmo se falhou: ninguem fica perdido na tela inicial */
  }
fim:
  buf_free(&elf);
  pthread_mutex_lock(&g_trava);
  g_est[t.i].fase[0] = 0;
  g_ocupado = 0;
  pthread_mutex_unlock(&g_trava);
  return NULL;
}

/* Pagina para reabrir: "/" + letras, numeros e - _ . / ? = & (sem "//" nem ".."). */
static int caminho_reabrir_ok(const char *c) {
  if(c[0] != '/' || c[1] == '/' || strstr(c, "..") || strlen(c) > 200) return 0;
  for(const char *p = c; *p; p++)
    if(!((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') || (*p >= '0' && *p <= '9') || strchr("-_./?=&", *p))) return 0;
  return 1;
}

static void rota_acao(pedido_t *p, int ativar, int volta);

void payloads_rota_acao(pedido_t *p, int ativar) {
  rota_acao(p, ativar, 0);
}

void payloads_rota_voltar(pedido_t *p) {
  rota_acao(p, 0, 1);
}

/* 0.9.34: POST /api/payloads/remover (id): apaga o que o glibren guardou de um item acompanhado pelo GitHub (o .elf, a
   anterior, os .info e o .ativado). Nao fecha o que ja esta rodando. Mesmas regras do voltar (pareamento + X-GLR, so celular/PC). */
void payloads_rota_remover(pedido_t *p) {
  char id[64] = "";
  param(p->corpo, "id", 0, id, sizeof id);
  int i = achar(id);
  if(i < 0 || !ITENS[i].gh_repo) {
    responder_erro(p, 404, "payload_fora_da_lista", "este payload nao esta na lista do glibren", NULL);
    return;
  }
  if(fps_agente_ps5(p->agente) || p->local) {
    responder_erro(p, 403, "payload_so_celular", "payloads de teste so pelo celular ou PC pareado", NULL);
    return;
  }
  const item_t *it = &ITENS[i];
  pthread_mutex_lock(&g_trava);
  if(g_ocupado) {
    pthread_mutex_unlock(&g_trava);
    responder_erro(p, 409, "payload_ocupado", "outro payload esta sendo baixado ou ativado: espere", NULL);
    return;
  }
  static const char *const EXT[] = {NULL, ".info", ".anterior.elf", ".anterior.info", ".ativado"};
  int apagados = 0;
  for(int k = 0; k < 5; k++) {
    char arq[620];
    caminho(it, EXT[k], arq, sizeof arq);
    if(!unlink(arq)) apagados++;
  }
  g_est[i].cache_tam = -1;
  g_est[i].ativado_em = 0;
  g_est[i].erro[0] = 0;
  g_est[i].saida[0] = 0;
  pthread_mutex_unlock(&g_trava);
  diario("payloads: %s: removido do glibren pelo aparelho pareado (%d arquivos)", it->id, apagados);
  responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
}

/* POST /api/payloads/procurar (forcar=1 = botao): pergunta ao GitHub numa thread (cache de 1 h; botao 1x/min). */
void payloads_rota_procurar(pedido_t *p) {
  char forcar[4] = "";
  param(p->corpo, "forcar", 0, forcar, sizeof forcar);
  int f = !strcmp(forcar, "1"), vai = 0, n = 0;
  pthread_once(&g_migrou, migrar_legado);
  time_t agora = time(NULL);
  long long bloq = gh_bloqueado_ate();
  pthread_mutex_lock(&g_trava);
  if(!g_procurando && !bloq)
    for(int i = 0; i < N_ITENS; i++)
      if(precisa(i, f, agora)) {
        g_est[i].consultando = 1;
        n++;
      }
  if(n) {
    g_procurando = 1;
    vai = 1;
  }
  pthread_mutex_unlock(&g_trava);
  if(vai && criar_thread(procurar, NULL, NULL)) {
    pthread_mutex_lock(&g_trava);
    g_procurando = 0;
    for(int i = 0; i < N_ITENS; i++) g_est[i].consultando = 0;
    pthread_mutex_unlock(&g_trava);
    vai = 0;
  }
  char r[128];
  int k = snprintf(r, sizeof r, "{\"ok\":true,\"iniciado\":%s,\"itens\":%d,\"bloqueado_ate\":%lld}", vai ? "true" : "false", vai ? n : 0, bloq);
  responder(p, 200, "application/json", r, (size_t)k, NULL);
}

static void rota_acao(pedido_t *p, int ativar, int volta) {
  char id[64] = "", reabrir[256] = "", tid[16] = "", confirmo[4] = "";
  param(p->corpo, "id", 0, id, sizeof id);
  param(p->corpo, "confirmo", 0, confirmo, sizeof confirmo);
  param(p->corpo, "reabrir", 0, reabrir, sizeof reabrir);
  int i = achar(id);
  if(i < 0) {
    for(char *c = id; *c; c++) if(*c < ' ' || *c > '~') *c = '?';
    diario("payloads: pedido recusado: \"%.60s\" nao esta na lista", id);
    responder_erro(p, 404, "payload_fora_da_lista", "este payload nao esta na lista do glibren", NULL);
    return;
  }
  const item_t *it = &ITENS[i];
  int ps5 = fps_agente_ps5(p->agente);
  if((ps5 || p->local) && !(it->navegador && ps5)) {
    responder_erro(p, 403, "payload_so_celular", "payloads de teste so pelo celular ou PC pareado", NULL);
    return;
  }
  if(volta) {
    info_t in;
    if(!it->gh_repo || info_ler(it, 1, &in)) {
      responder_erro(p, 409, "payload_sem_anterior", "nao ha versao anterior guardada deste payload", NULL);
      return;
    }
  }
  if(reabrir[0] && !caminho_reabrir_ok(reabrir)) {
    responder_erro(p, 400, "payload_reabrir", "pagina para reabrir invalida", NULL);
    return;
  }
  if(ativar) {
    int r = app_de_jogo_aberto(tid, sizeof tid);
    if(r == 1) {
      responder_erro(p, 409, "payload_jogo_aberto", "feche o jogo ou app antes: se a interface do PS5 reiniciar, ele fecha sem salvar", tid);
      return;
    }
    if(r < 0) diario("payloads: nao deu para saber se ha jogo aberto; seguindo");
    /* 0.9.22: so um patch da ShellUI por sessao do PS5 (o PrefBar e a tela cheia mexem na mesma interface) */
    int outro = conflito_com(i);
    if(outro >= 0) {
      diario("payloads: %s recusado: %s ja esta ativo nesta sessao do PS5 (os dois mexem na ShellUI)", it->id, ITENS[outro].id);
      responder_erro(p, 409, "payload_conflito", "outro payload que mexe na interface do PS5 ja esta ativo: reinicie o PS5 antes", ITENS[outro].nome);
      return;
    }
    /* 0.9.33: kraken-mount e ShadowKraken nao rodam junto com o ShadowMount+: so com a confirmacao explicita da pagina
       (o glibren nunca fecha o ShadowMount+) */
    if(it->aviso_smp && strcmp(confirmo, "1")) {
      int api, proc;
      char v[64];
      smp_estado(&api, &proc, v, sizeof v);
      responder_erro(p, 409, "payload_confirmar_smp", "confirme: este payload nao roda junto com o ShadowMount+", api || proc ? "rodando" : "parado");
      return;
    }
    if(it->uma_vez && ativo_na_sessao(i)) {
      diario("payloads: %s recusado: ja esta rodando nesta sessao do PS5", it->id);
      responder_erro(p, 409, "payload_ja_ativo", "ja esta ativo nesta sessao do PS5 (ativar de novo criaria uma segunda copia)", it->nome);
      return;
    }
  }
  trabalho_t *t = calloc(1, sizeof *t);
  if(!t) {
    responder_erro(p, 500, "payload_erro", "sem memoria", NULL);
    return;
  }
  t->i = i;
  t->ativar = ativar;
  t->voltar = volta;
  if(reabrir[0]) snprintf(t->reabrir, sizeof t->reabrir, "http://127.0.0.1:%d%s", g_porta, reabrir);
  pthread_mutex_lock(&g_trava);
  if(g_ocupado) {
    pthread_mutex_unlock(&g_trava);
    free(t);
    responder_erro(p, 409, "payload_ocupado", "outro payload esta sendo baixado ou ativado: espere", NULL);
    return;
  }
  g_ocupado = 1;
  g_est[i].erro[0] = 0;
  g_est[i].saida[0] = 0;
  g_est[i].baixados = 0;
  g_est[i].total = 0;
  snprintf(g_est[i].fase, sizeof g_est[i].fase, "%s", "conferindo");
  pthread_mutex_unlock(&g_trava);
  diario("payloads: %s: %s pedido pelo %s%s", it->id, volta ? "voltar a versao anterior" : ativar ? "ativar" : "baixar", ps5 ? "navegador do PS5" : "aparelho pareado",
         t->reabrir[0] ? " (reabre o navegador depois)" : "");
  if(criar_thread(trabalhar, t, NULL)) {
    free(t);
    pthread_mutex_lock(&g_trava);
    g_ocupado = 0;
    g_est[i].fase[0] = 0;
    pthread_mutex_unlock(&g_trava);
    responder_erro(p, 500, "payload_erro", "nao iniciou", NULL);
    return;
  }
  responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
}

/* ------------------------------------------------------------------ 0.9.24: abrir o navegador do PS5 pelo celular */

#define PORTA_JOBE_WEB 34201   /* servidor web da Jobe no PS5 (/app e /teste) */

/* Lista FIXA: nada de URL vinda do pedido. porta 0 = a do glibren; porta -1 = caminho e o endereco inteiro
   (0.9.29: "internet" abre o Google para navegar, ja que o navegador do PS5 nao tem barra de endereco). */
static const struct {
  const char *id;
  int porta;
  const char *caminho;
} DESTINOS[] = {
  {"jobe", PORTA_JOBE_WEB, "/app"},
  {"jobe_teste", PORTA_JOBE_WEB, "/teste"},
  {"glibren", 0, "/"},
  {"glibren_payloads", 0, "/payloads"},
  {"internet", -1, "https://www.google.com/"},
  {NULL, 0, NULL},
};

static void *abrir_destino(void *arg) {
  char *url = arg;
  usleep(250000);
  int home = !ir_para_home();   /* como no item de tela cheia: da tela inicial o navegador abre limpo */
  usleep(home ? 1000000 : 250000);
  abrir_navegador(url);
  free(url);
  pthread_mutex_lock(&g_trava);
  g_ocupado = 0;
  pthread_mutex_unlock(&g_trava);
  return NULL;
}

void payloads_rota_navegador(pedido_t *p) {
  char destino[32] = "", tid[16] = "";
  param(p->corpo, "destino", 0, destino, sizeof destino);
  int d = 0;
  while(DESTINOS[d].id && strcmp(DESTINOS[d].id, destino)) d++;
  if(!DESTINOS[d].id) {
    for(char *c = destino; *c; c++) if(*c < ' ' || *c > '~') *c = '?';
    diario("navegador: pedido recusado: \"%.30s\" nao esta na lista", destino);
    responder_erro(p, 404, "navegador_destino", "esta pagina nao esta na lista do glibren", NULL);
    return;
  }
  if(fps_agente_ps5(p->agente) || p->local) {
    responder_erro(p, 403, "navegador_so_celular", "abrir o navegador do PS5 so pelo celular ou PC pareado", NULL);
    return;
  }
  int r = app_de_jogo_aberto(tid, sizeof tid);
  if(r == 1) {
    responder_erro(p, 409, "navegador_jogo_aberto", "feche o jogo ou app aberto antes: abrir o navegador por cima de outro app pode travar o PS5", tid);
    return;
  }
  if(r < 0) diario("navegador: nao deu para saber se ha jogo aberto; seguindo");
  char *url = malloc(96);
  if(!url) {
    responder_erro(p, 500, "navegador_erro", "sem memoria", NULL);
    return;
  }
  if(DESTINOS[d].porta < 0) snprintf(url, 96, "%s", DESTINOS[d].caminho);
  else snprintf(url, 96, "http://127.0.0.1:%d%s", DESTINOS[d].porta ? DESTINOS[d].porta : g_porta, DESTINOS[d].caminho);
  pthread_mutex_lock(&g_trava);
  if(g_ocupado) {
    pthread_mutex_unlock(&g_trava);
    free(url);
    responder_erro(p, 409, "payload_ocupado", "outro payload esta sendo baixado ou ativado: espere", NULL);
    return;
  }
  g_ocupado = 1;
  pthread_mutex_unlock(&g_trava);
  diario("navegador: abrir %s pedido pelo aparelho pareado", url);
  if(criar_thread(abrir_destino, url, NULL)) {
    free(url);
    pthread_mutex_lock(&g_trava);
    g_ocupado = 0;
    pthread_mutex_unlock(&g_trava);
    responder_erro(p, 500, "navegador_erro", "nao iniciou", NULL);
    return;
  }
  responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
}
