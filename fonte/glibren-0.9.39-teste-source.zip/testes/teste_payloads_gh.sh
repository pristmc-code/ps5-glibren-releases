#!/bin/bash
# 0.9.33: payloads acompanhados pelo GitHub (Dump Forge, kraken-mount, ShadowKraken) e "rodando agora", na versao de PC,
# com um GitHub FALSO (testes/github_falso.py: API + downloads), Dump Forge falso (8095), kraken-mount falso (/api/state),
# ShadowMount+/ShadowKraken falso (/api/v1/version) e elfldr falso. Casos: consulta e cache de 1 h, botao (1x/min),
# release ok -> instalar (sha256 = digest), digest errado = recusa, sem digest = recusa, sem asset, varios assets,
# pre-release (ShadowKraken, pula rascunho), atualizacao (anterior guardada), voltar versao, limite 403/429 (pausa),
# confirmacao do ShadowMount+, rodando/versao diferente, adocao do Dump Forge da 0.9.30, notificacao com a versao.
# 0.9.39: limite proprio do glibren (30 pedidos por hora): JSON coerente (resposta boa guardada ou nada a instalar) e pagina.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_payloads_gh.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8931; PGH=8932; PEL=8933; PDF=8934; PKR=8935; PSMP=8936; PBV=8937; PZT=8938
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R="http://$IP:$PORTA"
T=/root/glr-paygh; DADOS=$T/dados; GH=$T/gh; A=$T/lista
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$(echo "$2" | head -c 600)] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
estado() { curl -s "$L/api/payloads"; }
# so o item pedido (o JSON de um item vai de {"id":"x" ate o proximo {"id")
item() { estado | python3 -c "import json,sys; d=json.load(sys.stdin); print(json.dumps([i for i in d['itens'] if i['id']=='$1'][0]))"; }
campo() { item "$1" | python3 -c "import json,sys; d=json.load(sys.stdin); v=eval('d'+sys.argv[1]); print(json.dumps(v) if not isinstance(v,str) else v)" "$2"; }
espera_livre() { for i in $(seq 1 120); do estado | grep -q '"ocupado":false' && ! estado | grep -q '"consultando":true' && return; sleep 0.25; done; }
hits() { [ -f $GH/hits ] && wc -l < $GH/hits || echo 0; }
# esperar por condicao, nao por tempo (sob carga, sleep fixo nao basta): qualquer resposta HTTP serve
espera_http() { for i in $(seq 1 150); do curl -s -o /dev/null -m 2 "$1" && return 0; sleep 0.1; done; echo "AVISO: $1 nao respondeu"; }
espera_arq() { for i in $(seq 1 150); do [ -e "$1" ] && return 0; sleep 0.1; done; echo "AVISO: $1 nao apareceu"; }
rm -rf "$T"; mkdir -p "$DADOS" "$GH/arquivos" "$A" "$T/df"
printf 'language = pt-BR\nfolder = %s/\n' "$A" > "$DADOS/config.ini"

# --- arquivos das releases falsas
novo_elf() { mkdir -p "$GH/arquivos/$1"; head -c $3 /dev/urandom > "$GH/arquivos/$1/$2"; }
sha() { sha256sum "$GH/arquivos/$1/$2" | cut -d' ' -f1; }
tam() { stat -c %s "$GH/arquivos/$1/$2"; }
novo_elf v0.5.6 ps5-dump-forge-0.5.6-ps5.elf 200000
novo_elf v0.5.7 ps5-dump-forge-0.5.7-ps5.elf 210000
novo_elf v0.2.1 kraken-mount.elf 120000
novo_elf 1.00-Dev.3-Fix.2 ShadowKraken.elf 130000
novo_elf 1.00-Dev.3-Fix.1 ShadowKraken.elf 125000
novo_elf v0.5.0 bluev.elf 150000
novo_elf v0.1.0-alpha ZhiThemes.elf 160000
novo_elf v0.1.0-alpha ZhiThemes-themes.zip 1000
rel() {   # tag pre draft "asset:sha|asset:sha" (sha "-" = sem digest; tamanho real do arquivo, ou 999 se nao existe)
  python3 - "$GH" "$@" <<'EOF'
import json, os, sys
gh, tag, pre, draft, assets = sys.argv[1], sys.argv[2], sys.argv[3] == "1", sys.argv[4] == "1", sys.argv[5]
lista = []
for a in filter(None, assets.split("|")):
    nome, dig = a.split(":")
    arq = os.path.join(gh, "arquivos", tag, nome)
    tam = os.path.getsize(arq) if os.path.isfile(arq) else 999
    item = {"name": nome, "size": tam, "url": "x", "browser_download_url": "x", "content_type": "application/octet-stream"}
    item["digest"] = None if dig == "-" else "sha256:" + dig
    lista.append(item)
print(json.dumps({"tag_name": tag, "prerelease": pre, "draft": draft, "published_at": "2026-11-16T10:00:00Z",
                  "body": "notas com \"aspas\", \\u00e9 e uma chave_muito_grande_que_passa_de_32_caracteres", "assets": lista}))
EOF
}
SUMS=SHA256SUMS:$(printf 0%.0s $(seq 64))
cenario() {   # $1 = versao do dump-forge (v0.5.6|v0.5.7|errado|semdigest|semasset|varios)
  local DF
  case $1 in
    v0.5.6) DF=$(rel v0.5.6 0 0 "ps5-dump-forge-0.5.6-ps5.elf:$(sha v0.5.6 ps5-dump-forge-0.5.6-ps5.elf)|$SUMS|ps5-dump-forge-0.5.6-linux-x86-64.tar.gz:$(printf a%.0s $(seq 64))") ;;
    v0.5.7) DF=$(rel v0.5.7 0 0 "ps5-dump-forge-0.5.7-ps5.elf:$(sha v0.5.7 ps5-dump-forge-0.5.7-ps5.elf)|$SUMS"),$(rel v0.5.6 0 0 "ps5-dump-forge-0.5.6-ps5.elf:$(sha v0.5.6 ps5-dump-forge-0.5.6-ps5.elf)") ;;
    errado) DF=$(rel v0.5.7 0 0 "ps5-dump-forge-0.5.7-ps5.elf:$(printf b%.0s $(seq 64))") ;;
    semdigest) DF=$(rel v0.5.7 0 0 "ps5-dump-forge-0.5.7-ps5.elf:-") ;;
    semasset) DF=$(rel v0.5.7 0 0 "$SUMS") ;;
    varios) DF=$(rel v0.5.7 0 0 "ps5-dump-forge-0.5.7-ps5.elf:$(sha v0.5.7 ps5-dump-forge-0.5.7-ps5.elf)|ps5-dump-forge-x-ps5.elf:$(printf c%.0s $(seq 64))") ;;
  esac
  local KR=$(rel v0.2.1 0 0 "kraken-mount.elf:$(sha v0.2.1 kraken-mount.elf)|$SUMS")
  local SK1=$(rel 1.00-Dev.4 1 1 "ShadowKraken.elf:$(printf d%.0s $(seq 64))")   # rascunho: pulado
  local SK2=$(rel 1.00-Dev.3-Fix.2 1 0 "ShadowKraken.elf:$(sha 1.00-Dev.3-Fix.2 ShadowKraken.elf)|ShadowKraken_1.00-Dev.3-Fix.2.zip:$(printf e%.0s $(seq 64))|$SUMS")
  local SK3=$(rel 1.00-Dev.3-Fix.1 1 0 "ShadowKraken.elf:$(sha 1.00-Dev.3-Fix.1 ShadowKraken.elf)")
  local BV=$(rel v0.5.0 0 0 "bluev.elf:$(sha v0.5.0 bluev.elf)|bluev.elf.sha256:$(printf f%.0s $(seq 64))")   # 0.9.34: o .sha256 nao casa
  # 0.9.35: ZhiThemes so tem pre-release (v0.1.0-alpha) com o .elf e o .zip dos temas
  local ZT=$(rel v0.1.0-alpha 1 0 "ZhiThemes.elf:$(sha v0.1.0-alpha ZhiThemes.elf)|ZhiThemes-themes.zip:$(sha v0.1.0-alpha ZhiThemes-themes.zip)")
  printf '{"quer3q/ps5-dump-forge":[%s],"quer3q/kraken-mount":[%s],"MNeroba/ShadowKraken":[%s,%s,%s],"0xZ3n0x/BlueV":[%s],"itsRealZhi/ZhiThemes":[%s]}' "$DF" "$KR" "$SK1" "$SK2" "$SK3" "$BV" "$ZT" > $GH/releases.json
}
cenario v0.5.6
echo ok > $GH/modo_api

# --- servicos falsos
(exec python3 -I "$ORIGEM/testes/github_falso.py" gh $PGH $GH) > $T/gh.log 2>&1 &
PID_GH=$!
(exec python3 -I "$ORIGEM/testes/github_falso.py" kraken $PKR $GH) > $T/kr.log 2>&1 &
PID_KR=$!
(exec python3 -I "$ORIGEM/testes/github_falso.py" smp $PSMP $GH) > $T/smp.log 2>&1 &
PID_SMP=$!
(exec python3 -I "$ORIGEM/testes/github_falso.py" bluev $PBV $GH) > $T/bv.log 2>&1 &
PID_BV=$!
(exec python3 -I "$ORIGEM/testes/github_falso.py" zhithemes $PZT $GH) > $T/zt.log 2>&1 &
PID_ZT=$!
cat > "$T/elfldr.py" <<'EOF'
import socket, sys
porta, pasta = int(sys.argv[1]), sys.argv[2]
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); s.bind(("127.0.0.1", porta)); s.listen(4)
open(pasta + "/elfldr.pronto", "w").close()   # no ar (sem conexao de teste: ela contaria como envio)
n = 0
while True:
    c, _ = s.accept(); dados = b""
    while True:
        d = c.recv(65536)
        if not d: break
        dados += d
    n += 1
    open(pasta + "/recebido.elf", "wb").write(dados)
    c.close()
    open(pasta + "/conexoes", "w").write(str(n))
EOF
python3 -I "$T/elfldr.py" $PEL "$T" > "$T/elfldr.log" 2>&1 &
PID_EL=$!
liga_df() { (exec python3 -I "$ORIGEM/testes/dumpforge_falso.py" $PDF "$T/df") >> "$T/df.log" 2>&1 & PID_DF=$!; espera_http "http://127.0.0.1:$PDF/api/session"; }
# /dl/ do GitHub falso nao conta em hits
espera_http "http://127.0.0.1:$PGH/dl/"; espera_http "http://127.0.0.1:$PKR/"; espera_http "http://127.0.0.1:$PSMP/"
espera_http "http://127.0.0.1:$PBV/"; espera_http "http://127.0.0.1:$PZT/"; espera_arq "$T/elfldr.pronto"

inicia() {
  GLR_TESTE_BASE="http://127.0.0.1:$PGH/" GLR_TESTE_GH="http://127.0.0.1:$PGH" GLR_TESTE_ELFLDR=$PEL GLR_TESTE_FW=12.00 \
  GLR_TESTE_ABERTOS="$T/abertos" GLR_TESTE_SONDA_S=0 GLR_TESTE_DUMPFORGE_PORTA=$PDF GLR_TESTE_KRAKEN_PORTA=$PKR GLR_TESTE_SMP_PORTA=$PSMP GLR_TESTE_BLUEV_PORTA=$PBV GLR_TESTE_ZHITHEMES_PORTA=$PZT \
  GLR_TESTE_PROCESSOS="$(cat $T/processos 2>/dev/null)" GLR_TESTE_SEM_REMOVIDOS=${SEM_REM:-1} GLR_TESTE_GH_CACHE_S=${GH_CACHE:-} "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; espera_http "$L/nada"; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
parear() {
  local n0=$(grep -c 'pareamento [0-9]\{6\}' "$T/glr.log") C=""
  post -X POST $R/api/parear/pedir > /dev/null
  for i in $(seq 1 100); do [ "$(grep -c 'pareamento [0-9]\{6\}' "$T/glr.log")" -gt "$n0" ] && break; sleep 0.1; done
  C=$(grep -o 'pareamento [0-9]\{6\}' "$T/glr.log" | tail -1 | awk '{print $2}')
  TOKEN=$(post -d codigo=$C -d nome=teste $R/api/parear | grep -o '"token":"[0-9a-f]*"' | cut -d'"' -f4)
}
P() { post -H "X-GLR-Token: $TOKEN" "$@"; }

# --- 0.9.30 -> 0.9.33: o Dump Forge guardado com o nome antigo e adotado se bater com o SHA-256 fixo de antes.
#     (no PC o arquivo de teste nao bate: tem de ser ignorado, sem apagar nada)
mkdir -p $DADOS/payloads; head -c 1000 /dev/urandom > $DADOS/payloads/ps5-dump-forge-0.5.6-ps5.elf
inicia
echo "--- notificacao com a versao"
confere "notificacao: nome e versao"      "$(head -5 $T/glr.log)" "Game Library Renamer $(grep -o '"[0-9.]*-teste"' $ORIGEM/src/api.h | tr -d '"')"
confere "notificacao: endereco"           "$(head -5 $T/glr.log)" "abra http://.*:$PORTA"
echo "--- estado inicial"
E=$(estado)
confere "7 itens acompanhados"            "$(echo "$E" | grep -o '"gh":{"repo"' | wc -l)" "^7$"
confere "smp parado"                      "$E" '"smp":{"api":false,"processo":false,"versao":"","tipo":""}'
confere "legado que nao confere: mantido" "$(ls $DADOS/payloads)" "ps5-dump-forge-0.5.6-ps5.elf"
nao_tem "legado nao vira instalado"       "$(ls $DADOS/payloads)" "dump-forge.info"
confere "nada consultado ainda"           "$(hits)" "^0$"
confere "rodando: nao (dump forge)"       "$(campo dump-forge "['rodando']")" "^false$"
confere "web-browser: rodando null"       "$(campo web-browser-fullscreen "['rodando']")" "^null$"

echo "--- procurar (abrir a pagina) e cache"
parear
confere "procurar sem par: 401"           "$(post -d forcar=0 $R/api/payloads/procurar)" "parear_necessario"
confere "procurar (PS5/local) iniciou"    "$(post -d forcar=0 $L/api/payloads/procurar)" '"iniciado":true,"itens":7'
espera_livre
# 9 = 7 itens + /repos/<r> dos 2 sem release no GitHub falso (0.9.34: /latest 404 confere se o repositorio existe)
confere "9 consultas"                     "$(hits)" "^9$"
confere "sem release: confere o repo"     "$(cat $GH/hits)" "^/repos/X1NONs/[^/]*$"
confere "latest no dump-forge"            "$(cat $GH/hits)" "/repos/quer3q/ps5-dump-forge/releases/latest"
confere "lista no ShadowKraken"           "$(cat $GH/hits)" "/repos/MNeroba/ShadowKraken/releases?per_page=5"
confere "dump-forge disponivel"           "$(campo dump-forge "['gh']['disponivel']['versao']")" "^v0.5.6$"
confere "asset certo (padrao)"            "$(campo dump-forge "['gh']['disponivel']['asset']")" "^ps5-dump-forge-0.5.6-ps5.elf$"
confere "digest lido"                     "$(campo dump-forge "['gh']['disponivel']['sha256']")" "^$(sha v0.5.6 ps5-dump-forge-0.5.6-ps5.elf)$"
confere "pode instalar"                   "$(campo dump-forge "['gh']['pode_instalar']")" "^true$"
confere "ShadowKraken: pula rascunho"     "$(campo shadowkraken "['gh']['disponivel']['versao']")" "^1.00-Dev.3-Fix.2$"
confere "ShadowKraken: experimental"      "$(campo shadowkraken "['gh']['disponivel']['pre']")" "^true$"
confere "BlueV disponivel v0.5.0"         "$(campo bluev "['gh']['disponivel']['versao']")" "^v0.5.0$"
confere "BlueV: so o .elf (sem .sha256)"  "$(campo bluev "['gh']['disponivel']['asset']")" "^bluev.elf$"
confere "BlueV: pode instalar"            "$(campo bluev "['gh']['pode_instalar']")" "^true$"
confere "lista no ZhiThemes (pre)"        "$(cat $GH/hits)" "/repos/itsRealZhi/ZhiThemes/releases?per_page=5"
confere "ZhiThemes: so pre-release"       "$(campo zhithemes "['gh']['disponivel']['versao']")" "^v0.1.0-alpha$"
confere "ZhiThemes: experimental"         "$(campo zhithemes "['gh']['disponivel']['pre']")" "^true$"
confere "ZhiThemes: so o .elf (sem .zip)" "$(campo zhithemes "['gh']['disponivel']['asset']")" "^ZhiThemes.elf$"
confere "ZhiThemes: pode instalar"        "$(campo zhithemes "['gh']['pode_instalar']")" "^true$"
confere "ZhiThemes: mexe na ShellUI"      "$(campo zhithemes "['shellui']")" "^true$"
confere "kraken disponivel"               "$(campo kraken-mount "['gh']['disponivel']['versao']")" "^v0.2.1$"
confere "abrir de novo: cache (nada)"     "$(post -d forcar=0 $L/api/payloads/procurar)" '"iniciado":false'
confere "botao logo depois: nada (1/min)" "$(P -d forcar=1 $R/api/payloads/procurar)" '"iniciado":false'
sleep 0.5; confere "cache: ainda 9 consultas"  "$(hits)" "^9$"

echo "--- instalar (digest confere) e ativar"
confere "instalar pelo PS5: recusado"     "$(post -A 'Mozilla/5.0 (PlayStation; PlayStation 5/12.00)' -d id=dump-forge $L/api/payloads/baixar)" "payload_so_celular"
confere "instalar iniciou"                "$(P -d id=dump-forge $R/api/payloads/baixar)" '"ok":true'
espera_livre
confere "instalada v0.5.6"                "$(campo dump-forge "['gh']['instalada']['versao']")" "^v0.5.6$"
confere "arquivo = asset"                 "$(cmp $DADOS/payloads/dump-forge.elf $GH/arquivos/v0.5.6/ps5-dump-forge-0.5.6-ps5.elf && echo igual)" "igual"
confere "info gravada"                    "$(cat $DADOS/payloads/dump-forge.info)" "sha256=$(sha v0.5.6 ps5-dump-forge-0.5.6-ps5.elf)"
nao_tem "sem .tmp sobrando"               "$(ls $DADOS/payloads)" "\.tmp"
confere "estado pronto"                   "$(campo dump-forge "['estado']")" "^pronto$"
confere "atualizado (nada a fazer)"       "$(campo dump-forge "['gh']['atualizar']")" "^false$"
confere "sem anterior"                    "$(campo dump-forge "['gh']['anterior']")" "^null$"
confere "ativar iniciou"                  "$(P -d id=dump-forge $R/api/payloads/ativar)" '"ok":true'
espera_livre
confere "elfldr recebeu a instalada"      "$(cmp $T/recebido.elf $GH/arquivos/v0.5.6/ps5-dump-forge-0.5.6-ps5.elf && echo igual)" "igual"

echo "--- rodando agora (Dump Forge falso responde 0.5.6)"
liga_df
confere "rodando: sim"                    "$(campo dump-forge "['rodando']")" "^true$"
confere "rodando: versao"                 "$(campo dump-forge "['rodando_versao']")" "^0.5.6$"
confere "mesma versao: nao diferente"     "$(campo dump-forge "['versao_diferente']")" "^false$"
confere "estado: ativado/rodando"         "$(campo dump-forge "['estado']")" "ativado\|rodando"
confere "ativar de novo: ja ativo"        "$(P -d id=dump-forge $R/api/payloads/ativar)" "payload_ja_ativo"

echo "--- atualizacao (v0.5.7) e versao diferente da rodando"
cenario v0.5.7
para; inicia; parear   # glibren novo = cache vazio
post -d forcar=0 $L/api/payloads/procurar > /dev/null; espera_livre
confere "atualizar: true"                 "$(campo dump-forge "['gh']['atualizar']")" "^true$"
confere "disponivel v0.5.7"               "$(campo dump-forge "['gh']['disponivel']['versao']")" "^v0.5.7$"
P -d id=dump-forge $R/api/payloads/baixar > /dev/null; espera_livre
confere "instalada v0.5.7"                "$(campo dump-forge "['gh']['instalada']['versao']")" "^v0.5.7$"
confere "anterior v0.5.6 guardada"        "$(campo dump-forge "['gh']['anterior']['versao']")" "^v0.5.6$"
confere "anterior: arquivo"               "$(cmp $DADOS/payloads/dump-forge.anterior.elf $GH/arquivos/v0.5.6/ps5-dump-forge-0.5.6-ps5.elf && echo igual)" "igual"
confere "rodando 0.5.6 x instalada 0.5.7" "$(campo dump-forge "['versao_diferente']")" "^true$"
kill $PID_DF 2>/dev/null; wait $PID_DF 2>/dev/null
confere "Dump Forge fechou: nao rodando"  "$(campo dump-forge "['rodando']")" "^false$"

echo "--- voltar a versao anterior"
confere "voltar pelo local: recusado"     "$(post -d id=dump-forge $L/api/payloads/voltar)" "payload_so_celular"
confere "voltar iniciou"                  "$(P -d id=dump-forge $R/api/payloads/voltar)" '"ok":true'
espera_livre
confere "instalada voltou a v0.5.6"       "$(campo dump-forge "['gh']['instalada']['versao']")" "^v0.5.6$"
confere "anterior agora v0.5.7"           "$(campo dump-forge "['gh']['anterior']['versao']")" "^v0.5.7$"
confere "arquivo trocado"                 "$(cmp $DADOS/payloads/dump-forge.elf $GH/arquivos/v0.5.6/ps5-dump-forge-0.5.6-ps5.elf && echo igual)" "igual"
confere "conferido depois de voltar"      "$(campo dump-forge "['conferido']")" "^true$"
confere "atualizar de novo oferecido"     "$(campo dump-forge "['gh']['atualizar']")" "^true$"
confere "kraken sem anterior: recusado"   "$(P -d id=kraken-mount $R/api/payloads/voltar)" "payload_sem_anterior"
cp $DADOS/payloads/dump-forge.anterior.elf $T/ant.bak; printf 'x' >> $DADOS/payloads/dump-forge.anterior.elf
P -d id=dump-forge $R/api/payloads/voltar > /dev/null; espera_livre
confere "anterior adulterada: recusada"   "$(campo dump-forge "['erro']")" "versao anterior guardada nao confere"
confere "adulterada: nada trocado"        "$(campo dump-forge "['gh']['instalada']['versao']")" "^v0.5.6$"
cp $T/ant.bak $DADOS/payloads/dump-forge.anterior.elf

echo "--- digest errado, sem digest, sem asset, varios assets"
for c in errado semdigest semasset varios; do
  cenario $c; para; inicia; parear
  post -d forcar=0 $L/api/payloads/procurar > /dev/null; espera_livre
  P -d id=dump-forge $R/api/payloads/baixar > /dev/null; espera_livre
  E=$(item dump-forge)
  case $c in
    errado) confere "digest errado: recusado"      "$E" "SHA-256 nao confere com o digest do GitHub: arquivo recusado" ;;
    semdigest) confere "sem digest: erro sem_digest" "$(campo dump-forge "['gh']['erro']")" "^sem_digest$"
               confere "sem digest: recusado"        "$E" "nao informou o SHA-256 (digest)" ;;
    semasset) confere "sem asset: erro"             "$(campo dump-forge "['gh']['erro']")" "^sem_asset$" ;;
    varios) confere "varios assets: erro"          "$(campo dump-forge "['gh']['erro']")" "^varios_assets$" ;;
  esac
  confere "$c: instalada continua v0.5.6"  "$(campo dump-forge "['gh']['instalada']['versao']")" "^v0.5.6$"
  confere "$c: arquivo intacto"            "$(cmp $DADOS/payloads/dump-forge.elf $GH/arquivos/v0.5.6/ps5-dump-forge-0.5.6-ps5.elf && echo igual)" "igual"
  nao_tem "$c: sem .tmp"                   "$(ls $DADOS/payloads)" "\.tmp"
done

echo "--- kraken-mount / ShadowKraken: confirmacao do ShadowMount+ e deteccao"
cenario v0.5.7; para
echo "1.7beta12" > $GH/smp_versao; echo "shadowmountplus.elf" > $T/processos
inicia; parear
E=$(estado)
confere "SMP rodando (API)"               "$E" '"smp":{"api":true,"processo":true,"versao":"1.7beta12","tipo":"smp"}'
confere "ShadowKraken nao rodando com SMP" "$(campo shadowkraken "['rodando']")" "^false$"
confere "kraken sem confirmo: 409"        "$(P -d id=kraken-mount $R/api/payloads/ativar)" '"chave":"payload_confirmar_smp".*"nome":"rodando"'
confere "jogo aberto: recusado"           "$(echo PPSA01234 > $T/abertos; P -d id=kraken-mount -d confirmo=1 $R/api/payloads/ativar)" "payload_jogo_aberto"
: > $T/abertos
N0=$(cat $T/conexoes)
confere "kraken com confirmo: iniciou"    "$(P -d id=kraken-mount -d confirmo=1 $R/api/payloads/ativar)" '"ok":true'
espera_livre
confere "kraken instalado ao ativar"      "$(campo kraken-mount "['gh']['instalada']['versao']")" "^v0.2.1$"
confere "kraken enviado ao elfldr"        "$(cmp $T/recebido.elf $GH/arquivos/v0.2.1/kraken-mount.elf && echo igual)" "igual"
echo '{"busy":false,"games":[{"title":"x","version":"01.002"}],"log":["\"version\":\"9.9.9\""],"paused":false,"running":[],"version":"0.2.1","waiting":"shadowmount"}' > $GH/kraken.json
confere "kraken rodando"                  "$(campo kraken-mount "['rodando']")" "^true$"
confere "kraken versao (a de cima)"       "$(campo kraken-mount "['rodando_versao']")" "^0.2.1$"
confere "kraken esperando o SMP"          "$(campo kraken-mount "['rodando_obs']")" "^shadowmount$"
confere "kraken mesma versao"             "$(campo kraken-mount "['versao_diferente']")" "^false$"
rm -f $GH/kraken.json
echo "1.00-Dev.3-Fix.2" > $GH/smp_versao
confere "ShadowKraken detectado"          "$(estado)" '"tipo":"shadowkraken"'
confere "ShadowKraken: rodando"           "$(campo shadowkraken "['rodando']")" "^true$"
confere "ShadowKraken: ja ativo"          "$(P -d id=shadowkraken -d confirmo=1 $R/api/payloads/ativar)" "payload_ja_ativo"
rm -f $GH/smp_versao
confere "so o processo: desconhecido"     "$(estado)" '"tipo":"desconhecido"'
confere "SK instalar (pre-release)"       "$(P -d id=shadowkraken $R/api/payloads/baixar)" '"ok":true'
espera_livre
confere "SK instalada Dev.3-Fix.2"        "$(campo shadowkraken "['gh']['instalada']['versao']")" "^1.00-Dev.3-Fix.2$"
confere "SK arquivo"                      "$(cmp $DADOS/payloads/shadowkraken.elf $GH/arquivos/1.00-Dev.3-Fix.2/ShadowKraken.elf && echo igual)" "igual"

echo "--- 0.9.34: repositorio que sumiu (404) e ShadowKraken removido do GitHub"
para; SEM_REM=0; GH_CACHE=1; echo "quer3q/kraken-mount" > $GH/sumidos
inicia; parear; H0=$(hits)
confere "SK guardado: continua na lista"  "$(estado)" '"id":"shadowkraken"'
confere "procurar: 4 (SK nao pergunta)"   "$(post -d forcar=0 $L/api/payloads/procurar)" '"iniciado":true,"itens":6'
espera_livre
NOVOS=$(tail -n +$((H0+1)) $GH/hits)
nao_tem "SK: nada perguntado ao GitHub"   "$NOVOS" "ShadowKraken"
confere "404: confere o repositorio"      "$NOVOS" "^/repos/quer3q/kraken-mount$"
confere "404: repo_indisponivel"          "$(campo kraken-mount "['gh']['erro']")" "^repo_indisponivel$"
confere "404: sem disponivel"             "$(campo kraken-mount "['gh']['disponivel']")" "^null$"
confere "404: instalada mantida"          "$(campo kraken-mount "['gh']['instalada']['versao']")" "^v0.2.1$"
confere "404: estado sem erro"            "$(campo kraken-mount "['estado']")" "^pronto$\|^ativado$"
confere "404: os outros seguem"           "$(campo dump-forge "['gh']['disponivel']['versao']")" "^v0.5.7$"
# Antes era "sleep 1.3". O cache de teste e de 1 s, contado pelo relogio do glibren (time()); o relogio do WSL leva
# passos para TRAS (systemd-timesyncd/Hyper-V, "Time jumped backwards" no journal, mais sob carga) e o glibren, de
# proposito, pergunta de novo quando o relogio volta para antes da consulta (agora < consultado). Entao: espera o
# "agora" do glibren passar 1 s da ultima consulta e, se o kraken-mount foi perguntado de novo com o relogio
# voltando (tentou_em novo < consultado_em de antes), repete a rodada: isso nao e o cache de 24 h falhando.
cache_vencido() { estado | python3 -c "import json,sys; d=json.load(sys.stdin); c=[i['gh']['consultado_em'] for i in d['itens'] if i.get('gh') and i['gh']['consultado_em']]; sys.exit(0 if c and d['agora'] >= max(c) + 1 else 1)"; }
for rodada in 1 2 3; do
  for i in $(seq 1 100); do cache_vencido && break; sleep 0.1; done
  K0=$(campo kraken-mount "['gh']['consultado_em']"); H1=$(hits)
  post -d forcar=0 $L/api/payloads/procurar > /dev/null; espera_livre
  K1=$(campo kraken-mount "['gh']['tentou_em']")
  [ "$K1" -ge "$K0" ] && break
  echo "AVISO: o relogio voltou ($K0 -> $K1) e o kraken-mount foi perguntado de novo (esperado); rodada de novo"
done
NOVOS=$(tail -n +$((H1+1)) $GH/hits)
confere "cache vencido: outros de novo"   "$NOVOS" "ps5-dump-forge"
nao_tem "404: cache de 24 h"              "$NOVOS" "kraken-mount"
P -d id=kraken-mount $R/api/payloads/baixar > /dev/null; espera_livre
confere "404: instalar recusado"          "$(campo kraken-mount "['erro']")" "repositorio indisponivel no GitHub"
confere "404: arquivo intacto"            "$(cmp $DADOS/payloads/kraken-mount.elf $GH/arquivos/v0.2.1/kraken-mount.elf && echo igual)" "igual"
confere "SK: removido_em"                 "$(campo shadowkraken "['gh']['removido_em']")" "^17/11/2026$"
confere "SK: repo_indisponivel"           "$(campo shadowkraken "['gh']['erro']")" "^repo_indisponivel$"
confere "SK: nao instala"                 "$(campo shadowkraken "['gh']['pode_instalar']")" "^false$"
P -d id=shadowkraken $R/api/payloads/baixar > /dev/null; espera_livre
confere "SK: atualizar recusado"          "$(campo shadowkraken "['erro']")" "repositorio removido do GitHub em 17/11/2026"
confere "SK: ativar (guardado)"           "$(P -d id=shadowkraken -d confirmo=1 $R/api/payloads/ativar)" '"ok":true'
espera_livre
confere "SK: enviado ao elfldr"           "$(cmp $T/recebido.elf $GH/arquivos/1.00-Dev.3-Fix.2/ShadowKraken.elf && echo igual)" "igual"
echo "1.00-Dev.3-Fix.2" > $GH/smp_versao
confere "SK: rodando agora"               "$(campo shadowkraken "['rodando']")" "^true$"
rm -f $GH/smp_versao

echo "--- 0.9.34: BlueV (instalar, rodando agora pela /api/status)"
confere "BlueV: nao rodando"              "$(campo bluev "['rodando']")" "^false$"
confere "BlueV: instalar"                 "$(P -d id=bluev $R/api/payloads/baixar)" '"ok":true'
espera_livre
confere "BlueV: instalada v0.5.0"         "$(campo bluev "['gh']['instalada']['versao']")" "^v0.5.0$"
confere "BlueV: arquivo = asset"          "$(cmp $DADOS/payloads/bluev.elf $GH/arquivos/v0.5.0/bluev.elf && echo igual)" "igual"
confere "BlueV: ativar"                   "$(P -d id=bluev $R/api/payloads/ativar)" '"ok":true'
espera_livre
confere "BlueV: enviado ao elfldr"        "$(cmp $T/recebido.elf $GH/arquivos/v0.5.0/bluev.elf && echo igual)" "igual"
echo '{"state":"idle","message":"","peer":null,"volume":-1,"quality":0,"network":"lan"}' > $GH/bluev.json
confere "BlueV: rodando"                  "$(campo bluev "['rodando']")" "^true$"
confere "BlueV: sem versao na API"        "$(campo bluev "['rodando_versao']")" "^$"
confere "BlueV: ativar de novo recusado"  "$(P -d id=bluev $R/api/payloads/ativar)" "payload_ja_ativo"

echo "--- 0.9.35: ZhiThemes (so pre-release, instalar, ativar, rodando agora pela /version)"
confere "ZhiThemes: nao rodando"          "$(campo zhithemes "['rodando']")" "^false$"
echo "onionhen 1.0 (build 1) Nov 17 2026 | started 10:00:00 UTC" > $GH/zhithemes_versao
confere "tema do OnionHEN nao conta"      "$(campo zhithemes "['rodando']")" "^false$"
rm -f $GH/zhithemes_versao
confere "ZhiThemes: instalar"             "$(P -d id=zhithemes $R/api/payloads/baixar)" '"ok":true'
espera_livre
confere "ZhiThemes: instalada alpha"      "$(campo zhithemes "['gh']['instalada']['versao']")" "^v0.1.0-alpha$"
confere "ZhiThemes: arquivo = asset .elf" "$(cmp $DADOS/payloads/zhithemes.elf $GH/arquivos/v0.1.0-alpha/ZhiThemes.elf && echo igual)" "igual"
nao_tem "ZhiThemes: .zip nao baixado"     "$(ls $DADOS/payloads)" "themes.zip"
confere "ZhiThemes: ativar"               "$(P -d id=zhithemes $R/api/payloads/ativar)" '"ok":true'
espera_livre
confere "ZhiThemes: enviado ao elfldr"    "$(cmp $T/recebido.elf $GH/arquivos/v0.1.0-alpha/ZhiThemes.elf && echo igual)" "igual"
echo "zhithemes 0.1.0-alpha (build 7fe5597) Nov 18 2026 00:46:08 | started 10:00:00 UTC, 0 min 5 s ago | hooks=12 doubles=0" > $GH/zhithemes_versao
confere "ZhiThemes: rodando"              "$(campo zhithemes "['rodando']")" "^true$"
confere "ZhiThemes: versao rodando"       "$(campo zhithemes "['rodando_versao']")" "^0.1.0-alpha$"
confere "ZhiThemes: mesma da instalada"   "$(campo zhithemes "['versao_diferente']")" "^false$"
confere "ZhiThemes bloqueia o PrefBar"    "$(campo prefbar "['bloqueado_por']")" "ZhiThemes"
confere "ZhiThemes: ativar de novo (troca)" "$(P -d id=zhithemes $R/api/payloads/ativar)" '"ok":true'
espera_livre

echo "--- pagina no Edge/Chrome do Windows (360 e 1280 px), se houver"
NODE_WIN="/mnt/c/Program Files/nodejs/node.exe"
LAD=$(cmd.exe /c 'echo %LOCALAPPDATA%' 2>/dev/null | tr -d '\r')
PW=""; [ -n "$LAD" ] && PW=$(ls -d "$(wslpath "$LAD")"/npm-cache/_npx/*/node_modules/playwright 2>/dev/null | head -1)
if [ -x "$NODE_WIN" ] && [ -n "$PW" ]; then
  # glibren novo para a pagina: com o cache de 1 s este processo ja fez ~30 pedidos ao GitHub falso (o limite do
  # glibren e 30 por hora, GH_MAX_POR_HORA) e a consulta que a pagina dispara ao abrir passava do limite (dump-forge
  # sem "No GitHub" no PC) quando algo pedia 1 a mais. Cache normal (1 h) e consulta terminada antes de abrir.
  para; GH_CACHE=; inicia; parear
  post -d forcar=0 $L/api/payloads/procurar > /dev/null; espera_livre
  echo "1.7beta12" > $GH/smp_versao
  echo '{"busy":false,"games":[],"log":[],"paused":false,"running":[],"version":"0.2.1","waiting":"shadowmount"}' > $GH/kraken.json
  liga_df
  SAIDA=$("$NODE_WIN" "$(wslpath -w "$ORIGEM/testes/teste_payloads_pagina.mjs")" "http://127.0.0.1:$PORTA" "$(wslpath -w "$PW")" 2>&1)
  echo "$SAIDA"
  ok=$((ok + $(echo "$SAIDA" | grep -c '^OK '))); falhas=$((falhas + $(echo "$SAIDA" | grep -c '^FALHA')))
  echo "$SAIDA" | grep -q '^=== pagina' || { falhas=$((falhas+1)); echo "FALHA pagina: o script nao terminou"; }
  rm -f $GH/smp_versao $GH/kraken.json
else
  echo "PULADO: teste da pagina (sem node.exe ou Playwright no Windows)"
fi

echo "--- 0.9.34: remover o ShadowKraken guardado (o item some)"
confere "remover pelo local: recusado"    "$(post -d id=shadowkraken $L/api/payloads/remover)" "payload_so_celular"
confere "remover sem par: 401"            "$(post -d id=shadowkraken $R/api/payloads/remover)" "parear_necessario"
confere "remover"                         "$(P -d id=shadowkraken $R/api/payloads/remover)" '"ok":true'
nao_tem "arquivos do SK apagados"         "$(ls $DADOS/payloads)" "shadowkraken"
nao_tem "SK nao instalado: some"          "$(estado)" '"id":"shadowkraken"'
confere "SK some: 6 itens"                "$(estado | grep -o '"gh":{"repo"' | wc -l)" "^6$"
confere "SK nao instalado: nao instala"   "$(P -d id=shadowkraken $R/api/payloads/baixar)" '"ok":true'
espera_livre
nao_tem "SK: nada baixado"                "$(ls $DADOS/payloads)" "shadowkraken"
rm -f $GH/sumidos; GH_CACHE=

echo "--- limite da API (403 e 429)"
for cod in 403 429; do
  para; rm -f $T/processos; inicia; parear
  echo $cod > $GH/modo_api; H0=$(hits)
  post -d forcar=0 $L/api/payloads/procurar > /dev/null; espera_livre
  confere "$cod: uma consulta so (pausa)" "$(( $(hits) - H0 ))" "^1$"
  E=$(estado)
  confere "$cod: bloqueado_ate"           "$E" '"gh_bloqueado_ate":[1-9]'
  confere "$cod: erro limite"             "$(campo dump-forge "['gh']['erro']")" "^limite$"
  confere "$cod: botao recusado"          "$(P -d forcar=1 $R/api/payloads/procurar)" '"iniciado":false,"itens":0,"bloqueado_ate":[1-9]'
  sleep 0.5; confere "$cod: nada perguntado" "$(( $(hits) - H0 ))" "^1$"
  echo ok > $GH/modo_api
done

echo "--- 0.9.39: limite proprio do glibren (GH_MAX_POR_HORA = 30 pedidos por hora)"
# Cache de 1 s e o kraken-mount respondendo 500 (nunca uma resposta boa); as rodadas gastam os 30 pedidos da hora.
# Depois: dump-forge com a resposta boa guardada (v0.5.7, "cache") e kraken-mount sem nada (nao instala, motivo na pagina).
para; GH_CACHE=1; echo "quer3q/kraken-mount" > $GH/falhando
inicia; parear; H0=$(hits)
ultima_vencida() { estado | python3 -c "import json,sys; d=json.load(sys.stdin); c=[i['gh']['tentou_em'] for i in d['itens'] if i.get('gh') and i['gh']['tentou_em']]; sys.exit(0 if not c or d['agora'] >= max(c) + 1 else 1)"; }
no_limite() { estado | python3 -c "import json,sys; d=json.load(sys.stdin); g={i['id']:i['gh'] for i in d['itens'] if i.get('gh')}; sys.exit(0 if g['dump-forge']['erro'] == 'limite' and g['kraken-mount']['erro'] == 'limite' else 1)"; }
for rodada in $(seq 1 12); do
  no_limite && break
  for i in $(seq 1 100); do ultima_vencida && break; sleep 0.1; done
  post -d forcar=0 $L/api/payloads/procurar > /dev/null; espera_livre
done
confere "limite: 30 pedidos e para"       "$(( $(hits) - H0 ))" "^30$"
E=$(estado)
confere "limite: gh_livre_em no futuro"   "$(echo "$E" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d['gh_livre_em'] > d['agora'])")" "^True$"
confere "cache: erro limite"              "$(campo dump-forge "['gh']['erro']")" "^limite$"
confere "cache: disponivel v0.5.7"        "$(campo dump-forge "['gh']['disponivel']['versao']")" "^v0.5.7$"
confere "cache: marcado"                  "$(campo dump-forge "['gh']['cache']")" "^true$"
confere "cache: data da resposta boa"     "$(campo dump-forge "['gh']['consultado_em']")" "^[1-9]"
confere "cache: atualizar true"           "$(campo dump-forge "['gh']['atualizar']")" "^true$"
confere "cache: pode instalar"            "$(campo dump-forge "['gh']['pode_instalar']")" "^true$"
confere "sem cache: erro limite"          "$(campo kraken-mount "['gh']['erro']")" "^limite$"
confere "sem cache: disponivel null"      "$(campo kraken-mount "['gh']['disponivel']")" "^null$"
confere "sem cache: nao marcado"          "$(campo kraken-mount "['gh']['cache']")" "^false$"
confere "sem cache: atualizar false"      "$(campo kraken-mount "['gh']['atualizar']")" "^false$"
confere "sem cache: pode_instalar false"  "$(campo kraken-mount "['gh']['pode_instalar']")" "^false$"
# coerencia em todos: atualizar/pode_instalar so com "disponivel"
confere "nenhum botao sem No GitHub"      "$(echo "$E" | python3 -c "import json,sys; d=json.load(sys.stdin); print([i['id'] for i in d['itens'] if i.get('gh') and (i['gh']['atualizar'] or i['gh']['pode_instalar']) and not i['gh']['disponivel']])")" '^\[\]$'
if [ -x "$NODE_WIN" ] && [ -n "$PW" ]; then
  SAIDA=$("$NODE_WIN" "$(wslpath -w "$ORIGEM/testes/teste_payloads_pagina.mjs")" "http://127.0.0.1:$PORTA" "$(wslpath -w "$PW")" limite 2>&1)
  echo "$SAIDA"
  ok=$((ok + $(echo "$SAIDA" | grep -c '^OK '))); falhas=$((falhas + $(echo "$SAIDA" | grep -c '^FALHA')))
  echo "$SAIDA" | grep -q '^=== pagina' || { falhas=$((falhas+1)); echo "FALHA pagina (limite): o script nao terminou"; }
else
  echo "PULADO: pagina com o limite (sem node.exe ou Playwright no Windows)"
fi
H1=$(hits)
P -d id=kraken-mount $R/api/payloads/baixar > /dev/null; espera_livre
confere "sem cache: instalar recusado"    "$(campo kraken-mount "['erro']")" "limite de consultas ao GitHub: tente de novo em [0-9]* min"
P -d id=dump-forge $R/api/payloads/baixar > /dev/null; espera_livre
confere "cache: instala a v0.5.7 guardada" "$(campo dump-forge "['gh']['instalada']['versao']")" "^v0.5.7$"
confere "cache: arquivo = asset"          "$(cmp $DADOS/payloads/dump-forge.elf $GH/arquivos/v0.5.7/ps5-dump-forge-0.5.7-ps5.elf && echo igual)" "igual"
confere "limite: nada perguntado"         "$(( $(hits) - H1 ))" "^0$"
rm -f $GH/falhando; GH_CACHE=

echo "--- pagina: textos nos 3 idiomas"
H=$(curl -s $L/payloads)
for k in g_procurar ag_nao e_sem_digest conf_smp voltar_b e_repo_indisponivel e_removido sem_atualiz remover_b gh_pag e_limite_cache e_dados b_limite; do confere "texto $k x3" "$(echo "$H" | grep -o "$k:" | wc -l)" "^3$"; done

para
kill $PID_GH $PID_KR $PID_SMP $PID_BV $PID_ZT $PID_EL $PID_DF 2>/dev/null; wait 2>/dev/null
rm -rf "$T"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
