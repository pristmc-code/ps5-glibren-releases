#!/bin/bash
# Testa o primeiro plano pelo kern.msgbuf (0.9.16) na versao de PC: GLR_TESTE_MSGBUF = arquivo no lugar do msgbuf,
# GLR_TESTE_APPIDS = appId -> title ID, GLR_TESTE_SEGUNDO_MS encurta as esperas do /launch (1 "segundo" = 100 ms).
# Confere: /api/primeiro-plano sem msgbuf (sem sinal) e com as linhas SetControllerFocus/VideoOut; foco na tela do
# sistema (0x7); a pagina de FPS usa o titulo do foco (fonte primeiro_plano); /launch com "from": com sinal espera o
# foco sair do app antigo (+3 s de margem) em vez dos 15 s; sem sinal, espera fixa de 15 s; foco preso no app antigo =
# segue no limite de 15 s; nunca abre com outro app aberto.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_primeiro_plano.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8873
U="http://127.0.0.1:$PORTA"
T=/root/glr-pp; DADOS=$T/dados; MB=$T/msgbuf
UA_CEL='Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Mobile Safari/537.36'
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
rm -rf "$T"; mkdir -p "$DADOS" "$T/appmeta/PPSA01234"
printf 'language = pt-BR\n' > "$DADOS/config.ini"
cat > "$T/appmeta/PPSA01234/param.json" <<'JSON'
{"titleId":"PPSA01234","localizedParameters":{"defaultLanguage":"en-US","en-US":{"titleName":"Jogo em Foco"}}}
JSON
: > "$T/abertos"
inicia() { env GLR_TESTE_ABERTOS="$T/abertos" GLR_TESTE_APPMETA="$T/appmeta" GLR_TESTE_SEGUNDO_MS=100 GLR_TESTE_FPS=60 \
  GLR_TESTE_APPIDS="0x60000010=PPSA99991,0x60000020=PPSA01234" "$@" "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
launch() { curl -s -H 'Content-Type: application/json' -d "$1" $U/launch; }

echo "--- sem msgbuf"
inicia
confere "sem msgbuf: nao leu"            "$(curl -s $U/api/primeiro-plano)" '"lido":false,"errno":2,"bytes":0,"sinal":false'
para

echo "--- com msgbuf"
printf '[123] boot\n<6>VideoOut: shared (pid=0x5f, appId=0x60000020)\nfoo SetControllerFocus(0x60000020) bar\n' > "$MB"
inicia GLR_TESTE_MSGBUF="$MB"
J=$(curl -s $U/api/primeiro-plano)
confere "sinal e foco"                   "$J" '"lido":true,"errno":0,"bytes":[0-9]*,"sinal":true,"focos":1,"foco":"0x60000020","foco_sistema":false,"foco_tid":"PPSA01234"'
confere "VideoOut"                       "$J" '"video":true,"video_pid":95,"video_appid":"0x60000020","video_tid":"PPSA01234"'
confere "linha do foco"                  "$J" '"linha_foco":"foo SetControllerFocus(0x60000020) bar"'
curl -s -A "$UA_CEL" "$U/api/fps" > /dev/null; sleep 1.5
F=$(curl -s -A "$UA_CEL" "$U/api/fps")
confere "FPS: jogo pelo primeiro plano"  "$F" '"tid":"PPSA01234","nome":"Jogo em Foco","tipo":"ps5","fonte":"primeiro_plano"'
printf 'SetControllerFocus(0x7)\n' >> "$MB"
confere "foco na tela do sistema"        "$(curl -s $U/api/primeiro-plano)" '"focos":2,"foco":"0x00000007","foco_sistema":true,"foco_tid":""'
sleep 2.5
confere "FPS: foco no sistema = sistema" "$(curl -s -A "$UA_CEL" "$U/api/fps")" '"fonte":"sistema"'
printf 'SetControllerFocus(-1)\n' >> "$MB"
confere "foco negativo ignorado"         "$(curl -s $U/api/primeiro-plano)" '"focos":2,'

echo "--- /launch: foco sai do app antigo"
echo "PPSA99991" > "$T/abertos"
printf 'SetControllerFocus(0x60000010)\n' > "$MB"
confere "pedido aceito"                  "$(launch '{"title":"PMGL00001","from":"PPSA99991"}')" '"pending":true'
sleep 0.5
: > "$T/abertos"                                   # o app antigo fecha...
sleep 0.4
printf 'SetControllerFocus(0x7)\n' >> "$MB"         # ...e o foco vai para a tela do sistema
sleep 1.2
confere "diario: foco saiu"              "$(cat $DADOS/glibren.log)" "launch: foco saiu do app antigo (0x60000010 -> 0x00000007)"
sleep 0.6
confere "abriu antes dos 15 s"           "$(curl -s $U/api/launch)" '"estado":"aberto"'
confere "abriu o glibren"                "$(cat $DADOS/glibren.log)" "abrir app (PC): abriria o app PMGL00001"
para

echo "--- /launch: foco preso no app antigo = limite de 15 s"
: > "$DADOS/glibren.log"
echo "PPSA99991" > "$T/abertos"
printf 'SetControllerFocus(0x60000010)\n' > "$MB"
inicia GLR_TESTE_MSGBUF="$MB"
launch '{"title":"PMGL00001","from":"PPSA99991"}' > /dev/null
sleep 0.3; : > "$T/abertos"; sleep 1
confere "ainda esperando"                "$(curl -s $U/api/launch)" '"estado":"aguardando"'
sleep 1.2
confere "segue no limite"                "$(cat $DADOS/glibren.log)" "o foco continuou no app antigo por 15 s - segue (limite)"
confere "abriu"                          "$(curl -s $U/api/launch)" '"estado":"aberto"'
para

echo "--- /launch: foco de outro app no pedido = sinal ignorado"
: > "$DADOS/glibren.log"
echo "PPSA99991" > "$T/abertos"
printf 'SetControllerFocus(0x7)
' > "$MB"
inicia GLR_TESTE_MSGBUF="$MB"
launch '{"title":"PMGL00001","from":"PPSA99991"}' > /dev/null
sleep 0.3; : > "$T/abertos"; sleep 0.6
confere "diario: sinal ignorado"         "$(cat $DADOS/glibren.log)" "no pedido o foco era 0x00000007, nao o de PPSA99991 - sinal ignorado"
confere "espera fixa"                    "$(cat $DADOS/glibren.log)" "espera fixa de 15 s"
sleep 1.4
confere "abriu"                          "$(curl -s $U/api/launch)" '"estado":"aberto"'
para

echo "--- /launch sem sinal: espera fixa"
: > "$DADOS/glibren.log"
echo "PPSA99991" > "$T/abertos"
inicia
launch '{"title":"PMGL00001","from":"PPSA99991"}' > /dev/null
sleep 0.3; : > "$T/abertos"; sleep 0.5
confere "diario: espera fixa"            "$(cat $DADOS/glibren.log)" "sem sinal de primeiro plano (msgbuf) - espera fixa de 15 s"
confere "aguardando"                     "$(curl -s $U/api/launch)" '"estado":"aguardando"'
sleep 1.5
confere "abriu depois dos 15 s"          "$(curl -s $U/api/launch)" '"estado":"aberto"'

echo "--- regra: nunca por cima de outro app"
: > "$DADOS/glibren.log"
echo "PPSA99991" > "$T/abertos"
confere "sem from com app aberto: 409"   "$(launch '{"title":"PMGL00001"}')" "app_aberto"
nao_tem "nada aberto"                    "$(cat $DADOS/glibren.log)" "abriria o app"
para

rm -rf "$T"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
