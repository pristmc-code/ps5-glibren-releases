#!/usr/bin/env python3
"""Servidores DNS de mentira para o teste_dns.sh (so 127.0.0.1): UDP, TCP e DoH (HTTPS, RFC 8484 por POST).
Cada pergunta respondida vai para o arquivo --log ("udp host", "tcp host", "doh host").
Modos: ok (responde --ip), tc (UDP truncado, sem respostas), sink (responde 10.0.0.1), nx (NXDOMAIN)."""
import argparse, http.server, socket, socketserver, ssl, struct, threading

a = argparse.ArgumentParser()
a.add_argument("--udp", type=int); a.add_argument("--udp-modo", default="ok")
a.add_argument("--tcp", type=int); a.add_argument("--tcp-modo", default="ok")
a.add_argument("--doh", type=int); a.add_argument("--cert"); a.add_argument("--key")
a.add_argument("--ip", default="140.82.112.3"); a.add_argument("--log", required=True)
op = a.parse_args()
trava = threading.Lock()

def registra(onde, host):
    with trava, open(op.log, "a") as f:
        f.write("%s %s\n" % (onde, host))

def nome(q):
    p, partes = 12, []
    while q[p]:
        partes.append(q[p + 1:p + 1 + q[p]].decode()); p += q[p] + 1
    return ".".join(partes), p + 5

def resposta(q, modo):
    host, fim = nome(q)
    ident, = struct.unpack(">H", q[:2])
    pergunta = q[12:fim]
    if modo == "tc":
        return struct.pack(">HHHHHH", ident, 0x8380, 1, 0, 0, 0) + pergunta, host
    if modo == "nx":
        return struct.pack(">HHHHHH", ident, 0x8183, 1, 0, 0, 0) + pergunta, host
    ip = "10.0.0.1" if modo == "sink" else op.ip
    rr = b"\xc0\x0c" + struct.pack(">HHIH", 1, 1, 60, 4) + socket.inet_aton(ip)
    return struct.pack(">HHHHHH", ident, 0x8180, 1, 1, 0, 0) + pergunta + rr, host

class Udp(socketserver.BaseRequestHandler):
    def handle(self):
        dados, s = self.request
        r, host = resposta(dados, op.udp_modo)
        registra("udp", host)
        s.sendto(r, self.client_address)

class Tcp(socketserver.BaseRequestHandler):
    def handle(self):
        n, = struct.unpack(">H", self.request.recv(2))
        q = b""
        while len(q) < n:
            q += self.request.recv(n - len(q))
        r, host = resposta(q, op.tcp_modo)
        registra("tcp", host)
        self.request.sendall(struct.pack(">H", len(r)) + r)

class Doh(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        q = self.rfile.read(int(self.headers["Content-Length"]))
        ok = self.path == "/dns-query" and self.headers.get("Content-Type") == "application/dns-message"
        r, host = resposta(q, "ok") if ok else (b"", "")
        registra("doh", host)
        self.send_response(200 if ok else 400)
        self.send_header("Content-Type", "application/dns-message")
        self.send_header("Content-Length", str(len(r)))
        self.end_headers()
        self.wfile.write(r)
    def log_message(self, *x):
        pass

class UdpS(socketserver.ThreadingMixIn, socketserver.UDPServer): allow_reuse_address = True
class TcpS(socketserver.ThreadingMixIn, socketserver.TCPServer): allow_reuse_address = True
class HttpS(socketserver.ThreadingMixIn, http.server.HTTPServer): allow_reuse_address = True

servidores = []
if op.udp: servidores.append(UdpS(("127.0.0.1", op.udp), Udp))
if op.tcp: servidores.append(TcpS(("127.0.0.1", op.tcp), Tcp))
if op.doh:
    h = HttpS(("127.0.0.1", op.doh), Doh)
    c = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); c.load_cert_chain(op.cert, op.key)
    h.socket = c.wrap_socket(h.socket, server_side=True)
    servidores.append(h)
for s in servidores[1:]:
    threading.Thread(target=s.serve_forever, daemon=True).start()
servidores[0].serve_forever()
