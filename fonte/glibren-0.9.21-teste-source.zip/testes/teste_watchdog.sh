#!/bin/bash
# Testa o watchdog das chamadas do sistema e o consumo do chip (0.9.16) na versao de PC.
# GLR_TESTE_SCE_TRAVA faz a chamada com aquele nome "travar" (a thread dorme); GLR_TESTE_SEM_POTENCIA simula firmware
# sem sceKernelGetSocPowerConsumption.
# Confere: potencia em W e trilhos; sem a funcao = -1 (a pagina esconde); ventoinha presa nao congela a pagina
# (responde rapido, ventoinha -1, CPU continua), entra na lista de mortas e no diario; volta a valer quando a chamada
# presa volta; na 3a vez fica fora de vez; LncUtil preso = "nao deu para saber" (nada e lancado).
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_watchdog.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8872
U="http://127.0.0.1:$PORTA"
T=/root/glr-wdg; DADOS=$T/dados
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
campo() { echo "$1" | python3 -c "import json,sys; d=json.load(sys.stdin); print(eval('d'+sys.argv[1]))" "$2" 2>/dev/null; }
faixa() { if python3 -c "import sys; v=float('$2'); sys.exit(0 if $3 <= v <= $4 else 1)" 2>/dev/null; then ok=$((ok+1)); echo "OK   $1 ($2)"; else falhas=$((falhas+1)); echo "FALHA $1: $2 (esperado $3..$4)"; fi; }
rm -rf "$T"; mkdir -p "$DADOS"
printf 'language = pt-BR\n' > "$DADOS/config.ini"
: > "$T/abertos"
inicia() { env GLR_TESTE_ABERTOS="$T/abertos" "$@" "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 3; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }

echo "--- consumo do chip"
inicia
J=$(curl -s $U/api/termico)
faixa "potencia em W"                    "$(campo "$J" "['potencia_w']")" 55 120
confere "trilhos crus no JSON"           "$J" '"potencia_trilhos_mw":\[[0-9]*,[0-9]*,0,0,0,0,0,0\]'
confere "watchdog sem mortas"            "$J" '"watchdog":{"chamadas":[0-9]*,"estouros":0,"mortas":\[\]}'
confere "diario: trilhos da 1a leitura"  "$(cat $DADOS/glibren.log)" "potencia: trilhos mW"
para
inicia GLR_TESTE_SEM_POTENCIA=1
confere "sem a funcao: -1 (linha some)"  "$(curl -s $U/api/termico)" '"potencia_w":-1'
para

echo "--- ventoinha presa (dorme 7 s)"
inicia GLR_TESTE_SCE_TRAVA=sceKernelGetCurrentFanDuty GLR_TESTE_SCE_TRAVA_S=7
INI=$(date +%s%N)
J=$(curl -s --max-time 3 $U/api/termico)
FIM=$(date +%s%N)
faixa "/api/termico responde rapido (ms)" "$(( (FIM - INI) / 1000000 ))" 0 500
confere "ventoinha sem leitura"          "$J" '"ventoinha":-1'
faixa "CPU continua lida"                "$(campo "$J" "['cpu']")" 40 90
confere "lista de mortas"                "$J" '"mortas":\["sceKernelGetCurrentFanDuty"\]'
confere "diario: nao respondeu"          "$(cat $DADOS/glibren.log)" "watchdog: sceKernelGetCurrentFanDuty nao respondeu em 800 ms - fica fora ate voltar (1 de 3)"
sleep 2
confere "nao chamada de novo (1 estouro)" "$(curl -s $U/api/termico)" '"estouros":1,'
sleep 6
confere "diario: voltou"                 "$(cat $DADOS/glibren.log)" "watchdog: sceKernelGetCurrentFanDuty voltou depois de"
sleep 1
confere "chamada de novo depois de voltar" "$(curl -s $U/api/termico)" '"estouros":2,'
sleep 17
confere "3a vez: fora de vez"            "$(cat $DADOS/glibren.log)" "(3 de 3)"
sleep 8
confere "continua fora depois de voltar" "$(cat $DADOS/glibren.log)" "continua fora: estourou 3 vezes"
confere "mortas depois de 3"             "$(curl -s $U/api/termico)" '"mortas":\["sceKernelGetCurrentFanDuty"\]'
para

echo "--- LncUtil preso: nada e lancado"
inicia GLR_TESTE_SCE_TRAVA=sceLncUtilGetAppId GLR_TESTE_SCE_TRAVA_S=30
INI=$(date +%s%N)
R=$(curl -s --max-time 6 -H 'Content-Type: application/json' -d '{"title":"PPSA99991"}' $U/launch)
FIM=$(date +%s%N)
confere "launch: nao deu para saber"     "$R" "app_desconhecido"
faixa "launch responde em ate 3 s (ms)"  "$(( (FIM - INI) / 1000000 ))" 0 3000
confere "diario: LncUtil fora"           "$(cat $DADOS/glibren.log)" "watchdog: sceLncUtilGetAppId nao respondeu"
confere "nenhum app aberto"              "$(grep -c 'abrir app (PC)' $DADOS/glibren.log)" "^0$"
confere "2a vez nem chama (morta)"       "$(curl -s -H 'Content-Type: application/json' -d '{"title":"PPSA99991"}' $U/launch)" "app_desconhecido"
para

rm -rf "$T"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
