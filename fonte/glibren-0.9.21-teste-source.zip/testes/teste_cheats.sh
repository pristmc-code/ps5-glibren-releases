#!/bin/bash
# Testa as cheats na versao de PC: Fase 0 (leitura) e Fase 1 (ligar/desligar). O "jogo" e o testes/cheat_alvo.c
# compilado como eboot.bin; o glibren-pc acha o processo pelo nome, a base pelo /proc/<pid>/maps, le por
# /proc/<pid>/mem em O_RDONLY e, so no modo de teste, grava por /proc/<pid>/mem em O_RDWR.
# Confere: parser .json, escolha do arquivo pela versao exata (PS5 e PS4), pastas do catalogo e do onionHEN, leitura
# (desligada, ligada, nao bate, area extra), resumo por tipo de trecho (a 0.9.17 contava a area extra duas vezes:
# "5 de 9"), pagina e API recusadas no navegador do PS5, Host estranho, download do catalogo, simbolos do cheats.o
# do PS5 (kernel_proc_copyin/copyout; nada de ptrace/mprotect/mdbg), e a escrita: ligar e desligar com a memoria
# voltando identica, recusa quando os bytes nao batem, nao suportadas, desfazer parcial, cheat sobreposta, pid
# mudou (perdidas, nada gravado), restaurar ao sair (SIGTERM e /api/sair), retomar depois de SIGKILL, rota sem token
# (401), sem X-GLR (403), de 127.0.0.1 (403) e do navegador do PS5 (403).
#   wsl -d Ubuntu-24.04 -u root -- flock /tmp/ps5-testes.lock bash testes/teste_cheats.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8791; PORTA_ZIP=8792
IP=$(hostname -I | awk '{print $1}')
U="http://127.0.0.1:$PORTA"; RD="http://$IP:$PORTA"
T=/root/glr-cheats-teste; DADOS=$T/dados
UA_PS5='Mozilla/5.0 (PlayStation; PlayStation 5/12.00) AppleWebKit/605.1.15 (KHTML, like Gecko)'
UA_CEL='Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Mobile Safari/537.36'
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [${2:0:400}] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: tem [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
# valor de um caminho no JSON (python): jq "$R" 'd["arquivos"][0]["mods"][0]["estado"]'
jq() { echo "$1" | python3 -I -c "import json,sys; d=json.load(sys.stdin); print($2)" 2>&1; }
codigo() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
api() { curl -s -A "$UA_CEL" "$U/api/cheats"; }
# estado de uma cheat pelo nome: estado "Vida infinita"
estado() { jq "$R" "[m['estado'] for a in d['arquivos'] for m in a['mods'] if m['nome']=='$1'][0]"; }
campo() { jq "$R" "[m['$2'] for a in d['arquivos'] for m in a['mods'] if m['nome']=='$1'][0]"; }
# bytes da area de teste do alvo (128), lidos direto do /proc/<pid>/mem: area PID OFF
area() { python3 -I - "$1" "$2" <<'PY'
import sys
pid, off = int(sys.argv[1]), int(sys.argv[2], 16)
base = None
for l in open(f"/proc/{pid}/maps"):
    if l.rstrip().endswith("/eboot.bin"):
        base = int(l.split("-")[0], 16); break
with open(f"/proc/{pid}/mem", "rb") as f:
    f.seek(base + off); print(f.read(128).hex().upper())
PY
}

rm -rf "$T"; mkdir -p "$DADOS" "$T/appmeta/PPSA01234" "$T/appmeta/CUSA00001" "$T/catalogo/json" "$T/onion" "$T/zip"
printf 'language = pt-BR\n' > "$DADOS/config.ini"

echo "--- alvo de teste (o 'jogo')"
clang-18 -O0 -o "$T/eboot.bin" "$ORIGEM/testes/cheat_alvo.c" || { echo "FALHA nao compilou o alvo"; exit 1; }
"$T/eboot.bin" "$T/alvo.info" & ALVO=$!
for i in 1 2 3 4 5 6 7 8 9 10; do [ -s "$T/alvo.info" ] && break; sleep 0.2; done
read -r PID_ALVO OFF < "$T/alvo.info"
confere "alvo rodando"                 "$PID_ALVO" "$ALVO"
echo "$PID_ALVO" > "$T/pid"
h() { printf '%X' $((16#$OFF + $1)); }   # offset da area + n, em hex
AREA0=$(area $PID_ALVO $OFF)
confere "area inicial"                 "$AREA0" "^C680CC00000000"

echo "--- jogo instalado (param.json / param.sfo)"
cat > "$T/appmeta/PPSA01234/param.json" <<JSON
{"titleId":"PPSA01234","contentVersion":"01.000.002","masterVersion":"01.00",
 "localizedParameters":{"defaultLanguage":"en-US","en-US":{"titleName":"Jogo de Teste"},"pt-BR":{"titleName":"Jogo de Teste BR"}}}
JSON
python3 -I - "$T/appmeta/CUSA00001/param.sfo" <<'PY'
import struct, sys
itens = [("APP_VER", "01.07"), ("TITLE", "Jogo PS4"), ("TITLE_ID", "CUSA00001"), ("VERSION", "01.00")]
chaves = b""; dados = b""; tabela = b""
for k, v in itens:
    vb = v.encode() + b"\0"
    tabela += struct.pack("<HHIII", len(chaves), 0x0204, len(vb), len(vb), len(dados))
    chaves += k.encode() + b"\0"; dados += vb
ini_chaves = 0x14 + len(tabela)
while len(chaves) % 4: chaves += b"\0"
cab = b"\0PSF" + struct.pack("<IIII", 0x101, ini_chaves, ini_chaves + len(chaves), len(itens))
open(sys.argv[1], "wb").write(cab + tabela + chaves + dados)
PY

echo "--- arquivos de cheat"
# catalogo (HEN-Cheats-Collection): o certo, versao errada e um JSON quebrado
ARQ=PPSA01234_01.000.002_aaaaaaaa.json
cat > "$T/catalogo/json/$ARQ" <<JSON
{
  "name": "Jogo de Teste", "id": "PPSA01234", "version": "01.000.002", "process": "eboot.bin",
  "mods": [
    {"name": "Vida infinita", "description": "nao perde vida", "type": "checkbox",
     "memory": [{"offset": "$(h 0)", "on": "90909090909090", "off": "C680CC00000000"}]},
    {"name": "Dinheiro", "description": "", "type": "checkbox",
     "memory": [{"offset": "7FFFFFFF000", "on": "F048014708C74708", "off": "0000000000000000"},
                {"offset": "$(h 16)", "on": "E98E26A57C", "off": "F048014708"}]},
    {"name": "Nao bate", "description": "", "type": "checkbox",
     "memory": [{"offset": "$(h 32)", "on": "9090909090", "off": "1122334455"}]},
    {"name": "Secao 1", "type": "checkbox", "memory": [{"offset": "10", "on": "90", "off": "00", "section": 1}]},
    {"name": "Hex ruim", "type": "checkbox", "memory": [{"offset": "zz", "on": "9", "off": "00"}]},
    {"name": "Cave legivel", "type": "checkbox",
     "memory": [{"offset": "$(h 56)", "on": "41BE0F2700004401", "off": "0000000000000000"}]},
    {"name": "Tres trechos", "type": "checkbox",
     "memory": [{"offset": "$(h 64)", "on": "A1A2A3A4", "off": "11223344"},
                {"offset": "$(h 72)", "on": "B1B2B3B4", "off": "55667788"},
                {"offset": "$(h 80)", "on": "C1C2C3", "off": "AABBCC"}]},
    {"name": "Meio errado", "type": "checkbox",
     "memory": [{"offset": "$(h 88)", "on": "909090", "off": "0F1E2D"},
                {"offset": "$(h 32)", "on": "9090909090", "off": "1122334455"}]},
    {"name": "Sobreposta", "type": "checkbox", "memory": [{"offset": "$(h 2)", "on": "EEEE", "off": "CC00"}]},
    {"name": "Absoluto", "type": "checkbox", "memory": [{"offset": "10", "on": "90", "off": "01", "absolute": true}]},
    {"name": "Sem off", "type": "checkbox", "memory": [{"offset": "$(h 96)", "on": "90"}]}
  ],
  "credits": ["Autor A", "Autor B"]
}
JSON
echo '{"name":"versao errada","version":"01.000.001","process":"eboot.bin","mods":[{"name":"Nao deve aparecer","memory":[]}]}' \
  > "$T/catalogo/json/PPSA01234_01.000.001_bbbbbbbb.json"
echo '{"name": "quebrado", "mods": [ {"name": "x", }' > "$T/catalogo/json/PPSA01234_01.000.002_dddddddd.json"
echo '{"name":"prefixo parecido","mods":[{"name":"Nao deve aparecer 2","memory":[]}]}' > "$T/catalogo/json/PPSA01234_01.000.0021.json"
# onionHEN: nomes em outra caixa, offset com 0x, hex com espacos; e um .shn (fora desta fase)
cat > "$T/onion/PPSA01234_01.000.002.json" <<JSON
{"Name": "Jogo de Teste (onion)", "Version": "01.000.002", "Process": "eboot.bin",
 "Mods": [{"Name": "Hex com espacos", "Type": "checkbox", "Memory": [{"Offset": "0x$(h 48)", "On": "AA BB", "Off": "de ad"}]}],
 "Authors": ["Autor C"]}
JSON
echo 'shn' > "$T/onion/PPSA01234_01.000.002.shn"
# PS4
cat > "$T/catalogo/json/CUSA00001_01.07_eeeeeeee.json" <<JSON
{"name":"Jogo PS4","id":"CUSA00001","version":"01.07","process":"eboot.bin",
 "mods":[{"name":"Municao","type":"checkbox","memory":[{"offset":"$(h 0)","on":"90909090909090","off":"C680CC00000000"}]}]}
JSON
echo '{"name":"PS4 versao base","mods":[{"name":"Nao deve aparecer 3","memory":[]}]}' > "$T/catalogo/json/CUSA00001_01.00_ffffffff.json"

: > "$T/abertos"
inicia() { env GLR_TESTE_ABERTOS="$T/abertos" GLR_TESTE_APPMETA="$T/appmeta" GLR_TESTE_CHEATS="$T/catalogo" GLR_TESTE_ONION="$T/onion" GLR_TESTE_CHEATS_PID="$T/pid" \
  GLR_TESTE_BASE="http://127.0.0.1:$PORTA_ZIP/" GLR_TESTE_CHEATS_URL="http://127.0.0.1:$PORTA_ZIP/catalogo.zip" "$@" \
  "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
inicia

echo "--- recusa no navegador do PS5 e Host estranho"
confere "PS5: pagina recusada"         "$(codigo -A "$UA_PS5" $U/cheats)" "403"
confere "PS5: api recusada"            "$(codigo -A "$UA_PS5" $U/api/cheats)" "403"
confere "PS5 (caixa baixa): recusada"  "$(codigo -A 'mozilla playstation 5' $U/api/cheats)" "403"
confere "PS5: mensagem"                "$(curl -s -A "$UA_PS5" $U/cheats)" "so para o celular ou o PC"
confere "PS5: catalogo recusado"       "$(codigo -A "$UA_PS5" -X POST -H 'X-GLR: 1' $U/api/cheats/catalogo)" "403"
confere "Host estranho recusado"       "$(codigo -A "$UA_CEL" -H 'Host: ataque.example.com' $U/api/cheats)" "403"
confere "celular: pagina"              "$(curl -s -A "$UA_CEL" $U/cheats)" "Cheats do jogo"
PAGINA=$(curl -s -A "$UA_CEL" $U/cheats)
confere "pagina: aviso de banimento"   "$PAGINA" "banir a conta na PSN"
confere "pagina: salve o jogo antes"   "$PAGINA" "Salve o jogo antes"
confere "pagina: interruptor"          "$PAGINA" 'role="switch"'
nao_tem "pagina: sem o selo so leitura" "$PAGINA" "só leitura\|legenda-somente"
confere "pagina: JOGOS primeiro"       "$(echo "$PAGINA" | grep -o '<nav class="atalhos"><a href="/" id="tVoltar">')" 'tVoltar'

echo "--- rotas de escrita: X-GLR, pareamento, 127.0.0.1 e navegador do PS5"
CORPO0="{\"tid\":\"PPSA01234\",\"versao\":\"01.000.002\",\"arquivo\":\"$ARQ\",\"indice\":0}"
confere "POST /api/cheats = 404"       "$(codigo -A "$UA_CEL" -X POST -H 'X-GLR: 1' $U/api/cheats)" "404"
confere "PUT /api/cheats = 405"        "$(codigo -A "$UA_CEL" -X PUT -H 'X-GLR: 1' $U/api/cheats)" "405"
for r in escrever aplicar gravar; do
  confere "POST /api/cheats/$r = 404"  "$(codigo -A "$UA_CEL" -X POST -H 'X-GLR: 1' $U/api/cheats/$r)" "404"
done
confere "catalogo sem X-GLR = 403"     "$(codigo -A "$UA_CEL" -X POST $U/api/cheats/catalogo)" "403"
confere "ligar sem X-GLR = 403"        "$(codigo -A "$UA_CEL" -d "$CORPO0" $RD/api/cheats/ligar)" "403"
confere "ligar sem token = 401"        "$(codigo -A "$UA_CEL" -H 'X-GLR: 1' -d "$CORPO0" $RD/api/cheats/ligar)" "401"
confere "ligar sem token: pareamento"  "$(curl -s -A "$UA_CEL" -H 'X-GLR: 1' -d "$CORPO0" $RD/api/cheats/ligar)" "parear_necessario"
confere "desligar sem token = 401"     "$(codigo -A "$UA_CEL" -H 'X-GLR: 1' -d "$CORPO0" $RD/api/cheats/desligar)" "401"
confere "token errado = 401"           "$(codigo -A "$UA_CEL" -H 'X-GLR: 1' -H "X-GLR-Token: $(printf '0%.0s' $(seq 64))" -d "$CORPO0" $RD/api/cheats/ligar)" "401"
confere "PS5 (127.0.0.1) ligar = 403"  "$(codigo -A "$UA_PS5" -H 'X-GLR: 1' -d "$CORPO0" $U/api/cheats/ligar)" "403"
confere "127.0.0.1 ligar = 403"        "$(codigo -A "$UA_CEL" -H 'X-GLR: 1' -d "$CORPO0" $U/api/cheats/ligar)" "403"
confere "127.0.0.1 desligar = 403"     "$(codigo -A "$UA_CEL" -H 'X-GLR: 1' -d "$CORPO0" $U/api/cheats/desligar)" "403"
confere "nada gravado ate aqui"        "$(area $PID_ALVO $OFF)" "^$AREA0$"
# pareamento pela rede (o codigo vai para a "notificacao", que no PC sai no log)
curl -s -H 'X-GLR: 1' -X POST $RD/api/parear/pedir > /dev/null
C=$(grep -o 'pareamento [0-9]\{6\}' "$T/glr.log" | tail -1 | awk '{print $2}')
TOKEN=$(curl -s -H 'X-GLR: 1' -d codigo=$C -d nome=teste $RD/api/parear | python3 -I -c 'import json,sys; print(json.load(sys.stdin).get("token",""))')
confere "pareado"                      "$TOKEN" "^[0-9a-f]\{64\}$"
confere "PS5 pela rede com token = 403" "$(codigo -A "$UA_PS5" -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" -d "$CORPO0" $RD/api/cheats/ligar)" "403"
acao() { curl -s -A "$UA_CEL" -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" -d "$2" "$RD/api/cheats/$1"; }
corpo() { echo "{\"tid\":\"${3:-PPSA01234}\",\"versao\":\"01.000.002\",\"arquivo\":\"${2:-$ARQ}\",\"indice\":$1}"; }
lig() { acao ligar "$(corpo "$@")"; }
des() { acao desligar "$(corpo "$@")"; }

echo "--- simbolos: escrita so por kernel_proc_copyin (PS5) e /proc/<pid>/mem so no PC"
SEM_COMENT=$(sed -e 's://.*$::' "$ORIGEM/src/cheats.c" | perl -0pe 's:/\*.*?\*/::gs')
nao_tem "cheats.c sem ptrace/mdbg"     "$SEM_COMENT" "ptrace\|mdbg_\|pt_attach\|mprotect"
confere "cheats.c escreve por copyin"  "$SEM_COMENT" "kernel_proc_copyin(pid"
# O_RDWR so dentro do bloco de PC (#else ... #endif)
RDWR_PS5=$(echo "$SEM_COMENT" | awk '/^#ifdef __PROSPERO__/{d=1} /^#else/{d=0} /^#endif/{d=0} d' | grep -c 'O_RDWR')
confere "O_RDWR fora do codigo do PS5" "$RDWR_PS5" "^0$"
if [ -x /opt/ps5-payload-sdk/bin/prospero-clang ]; then
  (cd "$ORIGEM" && /opt/ps5-payload-sdk/bin/prospero-clang -Wall -Werror -O2 -Isrc -Ibuild -c src/cheats.c -o "$T/cheats.o" 2>&1)
  IMPORTA=$(/opt/ps5-payload-sdk/bin/llvm-nm -u "$T/cheats.o" 2>/dev/null)
  confere "PS5: cheats.o importa a leitura" "$IMPORTA" "kernel_proc_copyout"
  confere "PS5: cheats.o importa a escrita" "$IMPORTA" "kernel_proc_copyin"
  nao_tem "PS5: sem ptrace/mprotect/mdbg"   "$IMPORTA" "mdbg\|ptrace\|setlong\|setint\|setchar\|setshort\|mprotect"
else
  echo "PULADO sem o SDK do PS5 (conferencia do cheats.o)"
fi

echo "--- nenhum jogo aberto"
R=$(api)
confere "menu: tipo"                   "$R" '"tipo":"menu"'
confere "menu: nenhum arquivo"         "$R" '"arquivos":\[\]'
confere "escrita na fase 1"            "$R" '"somente_leitura":false,"escrita":true'
confere "ligar sem jogo: recusa"       "$(lig 0)" "cheats_jogo_mudou"

echo "--- jogo de PS5: escolha do arquivo e leitura"
echo PPSA01234 > "$T/abertos"
R=$(api)
confere "versao do param.json"         "$(jq "$R" "d['jogo']['versao'], d['jogo']['versao_de'], d['jogo']['mestre']")" "01.000.002 contentVersion 01.00"
confere "nome do jogo"                 "$R" '"nome":"Jogo de Teste BR"'
confere "arquivos escolhidos"          "$(jq "$R" "[a['arquivo'] for a in d['arquivos']]")" "\['PPSA01234_01.000.002.json', 'PPSA01234_01.000.002_aaaaaaaa.json', 'PPSA01234_01.000.002_dddddddd.json'\]"
confere "origens"                      "$(jq "$R" "[a['origem'] for a in d['arquivos']]")" "\['onionhen', 'catalogo', 'catalogo'\]"
nao_tem "versao errada fora"           "$R" "Nao deve aparecer"
confere "JSON quebrado: erro"          "$(jq "$R" "d['arquivos'][2].get('erro','')")" "esperava"
confere "processo achado"              "$(jq "$R" "d['processos'][0]")" "'pid': $PID_ALVO, 'nome': 'eboot.bin'"
confere "versao confere no arquivo"    "$(jq "$R" "d['arquivos'][1]['versao_confere']")" "True"
confere "creditos"                     "$(jq "$R" "d['arquivos'][1]['creditos']")" "Autor A"
confere "creditos (Authors)"           "$(jq "$R" "d['arquivos'][0]['creditos']")" "Autor C"
confere "Vida infinita: desligada"     "$(estado 'Vida infinita')" "^desligado$"
confere "Vida infinita: suportada"     "$(campo 'Vida infinita' suporte)" "^$"
confere "Vida infinita: indice"        "$(campo 'Vida infinita' indice)" "^0$"
confere "Vida infinita: bytes lidos"   "$(jq "$R" "d['arquivos'][1]['mods'][0]['trechos'][0]['lido']")" "^C680CC00000000$"
confere "Dinheiro: nao suportada"      "$(estado 'Dinheiro'), $(campo 'Dinheiro' suporte)" "^nao_suportada, area_extra$"
confere "Dinheiro: trecho cave"        "$(jq "$R" "d['arquivos'][1]['mods'][1]['trechos'][0]['estado'], d['arquivos'][1]['mods'][1]['trechos'][0]['tipo']")" "^cave area_extra$"
confere "Dinheiro: 2o trecho"          "$(jq "$R" "d['arquivos'][1]['mods'][1]['trechos'][1]['estado']")" "^desligado$"
confere "Nao bate: diferente"          "$(estado 'Nao bate')" "^diferente$"
confere "Nao bate: lido"               "$(jq "$R" "d['arquivos'][1]['mods'][2]['trechos'][0]['lido']")" "^9999999999$"
confere "secao != 0"                   "$(jq "$R" "d['arquivos'][1]['mods'][3]['trechos'][0]['estado']"), $(campo 'Secao 1' suporte)" "^secao, secao$"
confere "hex invalido"                 "$(jq "$R" "d['arquivos'][1]['mods'][4]['trechos'][0]['estado']"), $(campo 'Hex ruim' suporte)" "^invalido, invalido$"
confere "cave legivel (zeros)"         "$(jq "$R" "d['arquivos'][1]['mods'][5]['trechos'][0]['estado']"), $(campo 'Cave legivel' suporte)" "^cave, area_extra$"
confere "Tres trechos: desligada"      "$(estado 'Tres trechos')" "^desligado$"
confere "Meio errado: diferente"       "$(estado 'Meio errado')" "^diferente$"
confere "Absoluto: nao suportada"      "$(campo 'Absoluto' suporte)" "^absoluto$"
confere "Sem off: nao suportada"       "$(campo 'Sem off' suporte), $(jq "$R" "d['arquivos'][1]['mods'][10]['trechos'][0]['estado']")" "^sem_off, sem_off$"
confere "onion: chaves em outra caixa" "$(estado 'Hex com espacos')" "^desligado$"
# resumo por tipo: 18 trechos; as 2 areas extras (uma legivel, como no Terminator 2D) NAO entram nos conferiveis
confere "resumo: tipos"                "$(jq "$R" "[d['resumo'][k] for k in ('trechos','normais','caves','secao','absolutos','sem_off','invalidos')]")" "^\[16, 10, 2, 1, 1, 1, 1\]$"
confere "resumo: conferiveis/lidos"    "$(jq "$R" "[d['resumo'][k] for k in ('conferiveis','lidos','desligados','ligados','diferentes','erros')]")" "^\[12, 11, 8, 0, 2, 1\]$"
confere "resumo: cheats"               "$(jq "$R" "d['resumo']['suportadas'], d['resumo']['nao_suportadas']")" "^6 6$"
confere "base do eboot"                "$(jq "$R" "d['arquivos'][1]['base']")" "^0x"
confere "diario: resumo"               "$(cat $DADOS/glibren.log)" "cheats: ps5 PPSA01234 v01.000.002 (contentVersion): 3 arquivo(s), 1 processo(s) primeiro eboot.bin; 16 trecho(s): 12 conferiveis"
confere "leitura nao mudou nada"       "$(area $PID_ALVO $OFF)" "^$AREA0$"

echo "--- ligar e desligar: a memoria volta identica"
RESP=$(lig 0)
confere "ligar Vida infinita"          "$RESP" '"ok":true,"estado":"ligado","nome":"Vida infinita","trechos":1'
confere "memoria: on gravado"          "$(area $PID_ALVO $OFF)" "^90909090909090"
R=$(api)
confere "estado: ligada pelo glibren"  "$(estado 'Vida infinita'), $(campo 'Vida infinita' aplicada)" "^ligado, True$"
confere "lista de aplicadas"           "$(jq "$R" "d['aplicadas']")" "'nome': 'Vida infinita'"
confere "resumo: 1 aplicada"           "$(jq "$R" "d['resumo']['aplicadas']")" "^1$"
AP=$(cat "$T/catalogo/aplicadas.json")
confere "aplicadas.json: jogo"         "$(jq "$AP" "d['pid'], d['app_id'], d['tid'], d['versao']")" "^$PID_ALVO -1 PPSA01234 01.000.002$"
confere "aplicadas.json: original"     "$(jq "$AP" "d['cheats'][0]['trechos'][0]['original'], d['cheats'][0]['trechos'][0]['on']")" "^C680CC00000000 90909090909090$"
confere "aplicadas.json: endereco"     "$(jq "$AP" "d['cheats'][0]['trechos'][0]['endereco']")" "^0x"
confere "ligar de novo: ja ligada"     "$(lig 0)" "cheats_ja_ligada"
confere "diario: ligou"                "$(cat $DADOS/glibren.log)" "cheats: ligou Vida infinita em PPSA01234 (pid $PID_ALVO, 1 trecho(s); leitura de volta OK)"
confere "diario: trecho"               "$(cat $DADOS/glibren.log)" "trecho 1 0x[0-9a-f]*: C680CC00000000 -> 90909090909090: lido de volta ok"
RESP=$(des 0)
confere "desligar Vida infinita"       "$RESP" '"ok":true,"estado":"desligado"'
confere "memoria identica"             "$(area $PID_ALVO $OFF)" "^$AREA0$"
confere "aplicadas.json vazio"         "$(jq "$(cat "$T/catalogo/aplicadas.json")" "d['cheats']")" "^\[\]$"
confere "diario: desligou"             "$(cat $DADOS/glibren.log)" "cheats: desligou Vida infinita em PPSA01234 (pid $PID_ALVO, 1 trecho(s); leitura de volta OK)"
confere "desligar de novo: nao ligada" "$(des 0)" "cheats_nao_ligada"
# 3 trechos + pedido por formulario
RESP=$(acao ligar "tid=PPSA01234&versao=01.000.002&arquivo=$ARQ&indice=6")
confere "ligar Tres trechos (form)"    "$RESP" '"ok":true,"estado":"ligado","nome":"Tres trechos","trechos":3'
confere "Tres trechos: on"             "$(area $PID_ALVO $OFF | cut -c129-176)" "^A1A2A3A400000000B1B2B3B400000000C1C2C3"
confere "desligar Tres trechos"        "$(des 6)" '"ok":true'
confere "memoria identica (3 trechos)" "$(area $PID_ALVO $OFF)" "^$AREA0$"

echo "--- recusas: bytes nao batem, nao suportadas, sobreposta, pedido invalido"
RESP=$(lig 2)
confere "Nao bate: recusa"             "$RESP" '"chave":"cheats_nao_bate"'
confere "Nao bate: motivo"             "$(jq "$RESP" "d['params']['trecho'], d['params']['lido'], d['params']['esperado']")" "^1 9999999999 1122334455$"
RESP=$(lig 7)
confere "Meio errado: recusa trecho 2" "$(jq "$RESP" "d['chave'], d['params']['trecho']")" "^cheats_nao_bate 2$"
confere "Meio errado: nada gravado"    "$(area $PID_ALVO $OFF)" "^$AREA0$"
for par in "1 area_extra" "3 secao" "4 invalido" "5 area_extra" "9 absoluto" "10 sem_off"; do
  set -- $par
  confere "nao suportada: indice $1 ($2)" "$(jq "$(lig $1)" "d['chave'], d['params']['motivo']")" "^cheats_nao_suportada $2$"
done
confere "nao suportadas: nada gravado" "$(area $PID_ALVO $OFF)" "^$AREA0$"
confere "diario: recusa com motivo"    "$(cat $DADOS/glibren.log)" "cheats: ligar Nao bate em PPSA01234 recusado: trecho 1 (0x[0-9a-f]*) tem 9999999999, o desligado do arquivo e 1122334455"
lig 0 > /dev/null
confere "sobreposta: recusa"           "$(lig 8)" '"chave":"cheats_sobreposta","erro":"mexe nos mesmos bytes de outra cheat ligada","params":{"nome":"Vida infinita"}'
des 0 > /dev/null
confere "sobreposta: memoria identica" "$(area $PID_ALVO $OFF)" "^$AREA0$"
confere "indice inexistente"           "$(lig 50)" "cheats_indice"
confere "arquivo com ..: 400"          "$(codigo -A "$UA_CEL" -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" -d "$(corpo 0 '../aplicadas.json')" $RD/api/cheats/ligar)" "400"
confere "arquivo de outro jogo"        "$(lig 0 CUSA00001_01.07_eeeeeeee.json)" "cheats_arquivo"
confere "tid diferente do aberto"      "$(lig 0 $ARQ PPSA09999)" "cheats_jogo_mudou"
confere "indice invalido: 400"         "$(codigo -A "$UA_CEL" -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" -d 'tid=PPSA01234&versao=01.000.002&arquivo=x.json&indice=-1' $RD/api/cheats/ligar)" "400"

echo "--- desfazer parcial (o 2o de 3 trechos falha)"
END2=$(jq "$(api)" "d['arquivos'][1]['mods'][6]['trechos'][1]['endereco']")
para
inicia GLR_TESTE_CHEATS_FALHAR="$END2"
RESP=$(lig 6)
confere "falha no trecho 2"            "$(jq "$RESP" "d['chave'], d['params']['trecho'], d['params']['desfeito']")" "^cheats_escrita 2 True$"
confere "desfeito: memoria identica"   "$(area $PID_ALVO $OFF)" "^$AREA0$"
confere "desfeito: nada registrado"    "$(jq "$(cat "$T/catalogo/aplicadas.json")" "d['cheats']")" "^\[\]$"
confere "desfeito: diario"             "$(cat $DADOS/glibren.log)" "cheats: ligar Tres trechos em PPSA01234 falhou no trecho 2 (0x[0-9a-f]*); desfeito: OK (jogo como antes)"
confere "desfeito: trecho 1 voltou"    "$(cat $DADOS/glibren.log)" "desfazer trecho 1 0x[0-9a-f]* -> 11223344: ok"
confere "estado depois do desfazer"    "$(R=$(api); estado 'Tres trechos')" "^desligado$"
para

echo "--- restaurar ao fechar: SIGTERM"
inicia
lig 0 > /dev/null; lig 6 > /dev/null
confere "duas ligadas"                 "$(jq "$(api)" "d['resumo']['aplicadas']")" "^2$"
nao_tem "memoria mudou"                "$(area $PID_ALVO $OFF)" "^$AREA0$"
kill -TERM $PID; wait $PID 2>/dev/null
confere "SIGTERM: memoria identica"    "$(area $PID_ALVO $OFF)" "^$AREA0$"
confere "SIGTERM: diario"              "$(cat $DADOS/glibren.log)" "cheats: desligou Vida infinita em PPSA01234 (pid $PID_ALVO, 1 trecho(s); leitura de volta OK) ao fechar o glibren"
confere "SIGTERM: encerrando"          "$(cat $DADOS/glibren.log)" "encerrando (SIGTERM)"
confere "SIGTERM: registro vazio"      "$(jq "$(cat "$T/catalogo/aplicadas.json")" "d['cheats']")" "^\[\]$"

echo "--- restaurar ao fechar: /api/sair (com o token)"
inicia
lig 0 > /dev/null
confere "ligada antes do sair"         "$(area $PID_ALVO $OFF)" "^90909090909090"
confere "sair"                         "$(curl -s -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" -X POST $RD/api/sair)" '"ok":true'
for i in $(seq 1 50); do kill -0 $PID 2>/dev/null || break; sleep 0.1; done
wait $PID 2>/dev/null
confere "sair: memoria identica"       "$(area $PID_ALVO $OFF)" "^$AREA0$"

echo "--- glibren morto com SIGKILL: a nova copia retoma as ligadas (mesmo pid) e desliga"
inicia
lig 0 > /dev/null
kill -KILL $PID; wait $PID 2>/dev/null
confere "SIGKILL: continua ligada"     "$(area $PID_ALVO $OFF)" "^90909090909090"
inicia
R=$(api)
confere "retomou a ligada"             "$(campo 'Vida infinita' aplicada)" "^True$"
confere "retomou: diario"              "$(cat $DADOS/glibren.log)" "1 cheat(s) ligada(s) de antes (PPSA01234 pid $PID_ALVO"
confere "desligar depois de retomar"   "$(des 0)" '"ok":true'
confere "retomou: memoria identica"    "$(area $PID_ALVO $OFF)" "^$AREA0$"

echo "--- outra ferramenta liga a cheat (o proprio alvo grava)"
kill -USR1 $ALVO; sleep 0.3
R=$(api)
confere "Vida infinita: ligada (fora)" "$(estado 'Vida infinita'), $(campo 'Vida infinita' aplicada)" "^ligado, False$"
confere "resumo: 1 ligado"             "$(jq "$R" "d['resumo']['ligados']")" "^1$"
confere "ligar: ja ligada por fora"    "$(lig 0)" "cheats_ligada_fora"
confere "desligar: nao foi o glibren"  "$(des 0)" "cheats_nao_ligada"
confere "nada mudou (continua on)"     "$(area $PID_ALVO $OFF)" "^90909090909090"
para

echo "--- o jogo mudou (outro pid): as ligadas viram perdidas e nada e gravado"
"$T/eboot.bin" "$T/alvo2.info" & ALVO2=$!
for i in 1 2 3 4 5 6 7 8 9 10; do [ -s "$T/alvo2.info" ] && break; sleep 0.2; done
read -r PID2 OFF2 < "$T/alvo2.info"
echo "$PID2" > "$T/pid"
inicia
AREA2=$(area $PID2 $OFF2)
confere "ligar no jogo 2"              "$(lig 0)" '"ok":true'
AREA2_ON=$(area $PID2 $OFF2)
confere "jogo 2: on"                   "$AREA2_ON" "^90909090909090"
echo "$PID_ALVO" > "$T/pid"            # "outro jogo" (outro pid) aberto
confere "desligar com o pid mudado"    "$(des 0)" "cheats_perdida"
confere "jogo 2: nada gravado"         "$(area $PID2 $OFF2)" "^$AREA2_ON$"
confere "perdidas: diario"             "$(cat $DADOS/glibren.log)" "cheats: o jogo mudou (PPSA01234 pid $PID2 app -1 -> PPSA01234 pid $PID_ALVO app -1): 1 cheat(s) ligada(s) perdida(s), nada foi gravado: Vida infinita"
R=$(api)
confere "perdidas na API"              "$(jq "$R" "d['perdidas']['nomes'], d['resumo']['aplicadas']")" "^Vida infinita 0$"
confere "perdidas: registro vazio"     "$(jq "$(cat "$T/catalogo/aplicadas.json")" "d['cheats']")" "^\[\]$"
echo "$PID2" > "$T/pid"; lig 0 > /dev/null 2>&1   # ja esta on no jogo 2: recusa (por fora)
para
confere "sair: jogo 2 intacto"         "$(area $PID2 $OFF2)" "^$AREA2_ON$"
# jogo fechou (nenhum aberto): tambem vira perdida
kill $ALVO2 2>/dev/null; wait $ALVO2 2>/dev/null
echo "$PID_ALVO" > "$T/pid"
kill -KILL $ALVO 2>/dev/null; wait $ALVO 2>/dev/null
rm -f "$T/alvo.info"
"$T/eboot.bin" "$T/alvo.info" & ALVO=$!
for i in 1 2 3 4 5 6 7 8 9 10; do [ -s "$T/alvo.info" ] && break; sleep 0.2; done
read -r PID_ALVO OFF < "$T/alvo.info"
echo "$PID_ALVO" > "$T/pid"
inicia
lig 0 > /dev/null
: > "$T/abertos"
R=$(api)
confere "jogo fechou: perdida"         "$(jq "$R" "d['perdidas']['nomes']")" "^Vida infinita$"
para
confere "jogo fechou: nada restaurado" "$(area $PID_ALVO $OFF)" "^90909090909090"
echo PPSA01234 > "$T/abertos"
kill -KILL $ALVO 2>/dev/null; wait $ALVO 2>/dev/null
rm -f "$T/alvo.info"
"$T/eboot.bin" "$T/alvo.info" & ALVO=$!
for i in 1 2 3 4 5 6 7 8 9 10; do [ -s "$T/alvo.info" ] && break; sleep 0.2; done
read -r PID_ALVO OFF < "$T/alvo.info"
echo "$PID_ALVO" > "$T/pid"
kill -USR1 $ALVO; sleep 0.3
inicia

echo "--- modulo que nao existe"
sed -i 's/"process": "eboot.bin"/"process": "mgs4\/mgs4.elf"/' "$T/catalogo/json/$ARQ"
R=$(api)
confere "sem base: processo"           "$(jq "$R" "d['arquivos'][1]['processo']")" "mgs4/mgs4.elf"
confere "outro processo: nao suportada" "$(estado 'Vida infinita'), $(campo 'Vida infinita' suporte)" "^nao_suportada, outro_processo$"
confere "sem base: trecho"             "$(jq "$R" "d['arquivos'][1]['mods'][0]['trechos'][0]['estado'], d['arquivos'][1]['mods'][0]['trechos'][0]['tipo']")" "^sem_base outro_processo$"
confere "outro processo: recusa"       "$(jq "$(lig 0)" "d['params']['motivo']")" "^outro_processo$"

echo "--- jogo de PS4 (param.sfo: maior entre VERSION e APP_VER)"
echo CUSA00001 > "$T/abertos"
R=$(api)
confere "PS4: tipo"                    "$R" '"tipo":"ps4"'
confere "PS4: versao"                  "$(jq "$R" "d['jogo']['versao'], d['jogo']['versao_de']")" "01.07 APP_VER"
confere "PS4: nome"                    "$R" '"nome":"Jogo PS4"'
confere "PS4: arquivo"                 "$(jq "$R" "[a['arquivo'] for a in d['arquivos']]")" "\['CUSA00001_01.07_eeeeeeee.json'\]"
confere "PS4: leitura (ligada pelo alvo)" "$(estado 'Municao')" "^ligado$"

echo "--- jogo sem cheats / sem versao"
echo PPSA09999 > "$T/abertos"
R=$(api)
confere "sem versao"                   "$(jq "$R" "d['jogo']['versao']")" "^$"
confere "sem arquivo"                  "$R" '"arquivos":\[\]'
para

echo "--- download do catalogo (zip local no lugar do GitHub)"
python3 -I - "$T/zip/catalogo.zip" <<'PY'
import sys, zipfile
with zipfile.ZipFile(sys.argv[1], "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("HEN-Cheats-Collection-master/", "")
    z.writestr("HEN-Cheats-Collection-master/cheats/json/PPSA01234_01.000.002_12345678.json",
               '{"name":"Do zip","version":"01.000.002","process":"eboot.bin","mods":[{"name":"Do zip","memory":[]}]}')
    z.writestr("HEN-Cheats-Collection-master/cheats/json/PPSA05344_04.001.000_de306fb7.json", '{"name":"Park Beyond","mods":[]}')
    z.writestr("HEN-Cheats-Collection-master/cheats/shn/PPSA01234_01.000.002.shn", "shn")
    z.writestr("HEN-Cheats-Collection-master/cheats/json.txt", "x")
    z.writestr("HEN-Cheats-Collection-master/README.md", "readme")
PY
(cd "$T/zip" && exec python3 -I -m http.server $PORTA_ZIP --bind 127.0.0.1 > /dev/null 2>&1) & SRV=$!
for i in $(seq 1 50); do [ "$(codigo http://127.0.0.1:$PORTA_ZIP/catalogo.zip)" = 200 ] && break; sleep 0.2; done
echo PPSA01234 > "$T/abertos"
inicia
R=$(curl -s -A "$UA_CEL" -X POST -H 'X-GLR: 1' $U/api/cheats/catalogo)
confere "catalogo: comecou"            "$R" '"ok":true'
for i in $(seq 1 100); do R=$(api); echo "$R" | grep -q '"estado":"pronto"\|"estado":"erro"' && break; sleep 0.3; done
confere "catalogo: pronto"             "$(jq "$R" "d['catalogo']['estado'], d['catalogo']['arquivos']")" "pronto 2"
confere "catalogo: so os .json"        "$(ls "$T/catalogo/json" | tr '\n' ' ')" "^PPSA01234_01.000.002_12345678.json PPSA05344_04.001.000_de306fb7.json $"
confere "catalogo: substituiu a pasta" "$(jq "$R" "[a['arquivo'] for a in d['arquivos']]")" "PPSA01234_01.000.002_12345678.json"
nao_tem "catalogo: sem sobra"          "$(ls -a "$T/catalogo")" "json.novo\|json.antigo\|parcial"
confere "catalogo: aplicadas.json fica" "$(ls "$T/catalogo")" "aplicadas.json"
confere "catalogo: diario"             "$(cat $DADOS/glibren.log)" "cheats: catalogo pronto: 2 arquivos .json"
# zip sem cheats: erro e a pasta antiga fica
python3 -I -c "import zipfile; zipfile.ZipFile('$T/zip/catalogo.zip','w').writestr('x/README.md','x')"
curl -s -A "$UA_CEL" -X POST -H 'X-GLR: 1' $U/api/cheats/catalogo > /dev/null
for i in $(seq 1 100); do R=$(api); echo "$R" | grep -q '"estado":"pronto"\|"estado":"erro"' && break; sleep 0.3; done
confere "zip sem cheats: erro"         "$(jq "$R" "d['catalogo']['erro']")" "o zip nao tem cheats/json"
confere "zip sem cheats: antiga fica"  "$(ls "$T/catalogo/json" | wc -l)" "^2$"
rm -f "$T/zip/catalogo.zip"
curl -s -A "$UA_CEL" -X POST -H 'X-GLR: 1' $U/api/cheats/catalogo > /dev/null
for i in $(seq 1 100); do R=$(api); echo "$R" | grep -q '"estado":"pronto"\|"estado":"erro"' && break; sleep 0.3; done
confere "sem o zip: HTTP 404"          "$(jq "$R" "d['catalogo']['erro']")" "HTTP 404"
para
kill $SRV 2>/dev/null

kill $ALVO 2>/dev/null; wait $ALVO 2>/dev/null
rm -rf "$T"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
