/* Alvo de teste das cheats (so PC): faz o papel do jogo. Compilar com o nome "eboot.bin" (o glibren-pc procura o
   processo por esse nome, como no PS5).
     clang -O0 -o eboot.bin testes/cheat_alvo.c
     ./eboot.bin ARQUIVO_INFO
   Grava em ARQUIVO_INFO: "<pid> <offset da area de teste em relacao a base do executavel, em hex>".
   A area de teste comeca com bytes conhecidos (ver AREA). Sinais:
     SIGUSR1 -> o proprio alvo grava os bytes "ligado" da 1a cheat (simula outra ferramenta ligando a cheat);
     SIGUSR2 -> grava em ARQUIVO_INFO.soma a soma dos bytes da area (para conferir que o glibren nao mudou nada). */
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

/* 0: C6 80 CC 00 00 00 00 (off da "Vida infinita"); 16: F0 48 01 47 08 (off do "Dinheiro");
   32: 99 99 99 99 99 (nao bate com o arquivo); 48: DE AD (off com espacos/0x no arquivo do onionHEN);
   56: 8 zeros (area extra que da para ler, como no Terminator 2D); 64/72/80: os 3 trechos da "Tres trechos";
   88: 0F 1E 2D (1o trecho da "Meio errado"; o 2o e o 32, que nao bate) */
static volatile unsigned char AREA[128] __attribute__((aligned(64))) = {
  0xC6, 0x80, 0xCC, 0x00, 0x00, 0x00, 0x00, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0xF0, 0x48, 0x01, 0x47, 0x08, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0x99, 0x99, 0x99, 0x99, 0x99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0xDE, 0xAD, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0x11, 0x22, 0x33, 0x44, 0, 0, 0, 0, 0x55, 0x66, 0x77, 0x88, 0, 0, 0, 0,
  0xAA, 0xBB, 0xCC, 0, 0, 0, 0, 0, 0x0F, 0x1E, 0x2D, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static volatile sig_atomic_t g_ligar, g_somar;
static void sinal(int s) {
  if(s == SIGUSR1) g_ligar = 1;
  else g_somar = 1;
}

/* Base do executavel: primeira linha de /proc/self/maps com o caminho dele. */
static unsigned long base_propria(void) {
  char exe[1024], linha[1400];
  ssize_t n = readlink("/proc/self/exe", exe, sizeof exe - 1);
  if(n <= 0) return 0;
  exe[n] = 0;
  FILE *f = fopen("/proc/self/maps", "r");
  unsigned long base = 0;
  while(f && fgets(linha, sizeof linha, f)) {
    if(strstr(linha, exe)) {
      base = strtoul(linha, NULL, 16);
      break;
    }
  }
  if(f) fclose(f);
  return base;
}

int main(int argc, char **argv) {
  if(argc < 2) return 2;
  signal(SIGUSR1, sinal);
  signal(SIGUSR2, sinal);
  unsigned long base = base_propria();
  char tmp[1100];
  snprintf(tmp, sizeof tmp, "%s.tmp", argv[1]);
  FILE *f = fopen(tmp, "w");
  if(!f || !base) return 1;
  fprintf(f, "%d %lx\n", (int)getpid(), (unsigned long)((unsigned long)AREA - base));
  fclose(f);
  rename(tmp, argv[1]);
  for(;;) {
    pause();
    if(g_ligar) {
      g_ligar = 0;
      static const unsigned char on[] = {0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90};
      for(size_t i = 0; i < sizeof on; i++) AREA[i] = on[i];
    }
    if(g_somar) {
      g_somar = 0;
      unsigned soma = 0;
      for(size_t i = 0; i < sizeof AREA; i++) soma = soma * 31 + AREA[i];
      snprintf(tmp, sizeof tmp, "%s.soma", argv[1]);
      f = fopen(tmp, "w");
      if(f) {
        fprintf(f, "%08x\n", soma);
        fclose(f);
      }
    }
  }
}
