#!/bin/bash
# Testa "Ejetar USB com seguranca" (0.9.16) na versao de PC, como root no WSL: um tmpfs em /mnt/usb7 faz o papel do
# pendrive e uma montagem bind de uma pasta dele faz o papel da vista nullfs de um app.
# Confere: pontos protegidos e fora da lista recusados; disco nao montado; teste de velocidade rodando = recusa;
# ocupado (EBUSY) mostra quem usa e NAO encerra nada; vista desmontada antes; forcar (so com forcar=1) desmonta;
# disco livre desmonta; pedido da rede sem token = 401.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_ejetar.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8874
U="http://127.0.0.1:$PORTA"
IP=$(hostname -I | awk '{print $1}')
T=/root/glr-ej; DADOS=$T/dados; USB=/mnt/usb7; VISTA=$T/vista
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
ejetar() { post -d "caminho=$1" ${2:+-d forcar=$2} $U/api/discos/ejetar; }
limpar() { [ -n "$SONO" ] && kill $SONO 2>/dev/null; umount -l "$VISTA" 2>/dev/null; umount -l "$USB" 2>/dev/null; rmdir "$USB" 2>/dev/null; }
monta() { mkdir -p "$USB" "$VISTA"; mount -t tmpfs -o size=2g tmpfs "$USB"; mkdir -p "$USB/jogos"; echo x > "$USB/jogos/arq.txt"; mount --bind "$USB/jogos" "$VISTA"; }
montado() { if grep -q " $1 " /proc/mounts; then echo sim; else echo nao; fi; }
SONO=; PID=
trap 'limpar; [ -n "$PID" ] && kill $PID 2>/dev/null' EXIT
rm -rf "$T"; mkdir -p "$DADOS"
printf 'language = pt-BR\n' > "$DADOS/config.ini"
"$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1

echo "--- protegidos e invalidos"
confere "/data recusado"              "$(ejetar /data)" "ejetar_protegido"
confere "/mnt/ext1 recusado"          "$(ejetar /mnt/ext1)" "ejetar_protegido"
confere "/mnt/ext0 recusado"          "$(ejetar /mnt/ext0)" "ejetar_protegido"
confere "/user recusado"              "$(ejetar /user)" "ejetar_protegido"
confere "/system recusado"            "$(ejetar /system)" "ejetar_protegido"
confere "/ recusado"                  "$(ejetar /)" "ejetar_protegido"
confere "/mnt/usb7/.. recusado"       "$(ejetar /mnt/usb7/..)" "ejetar_protegido"
confere "/mnt/usb123 recusado"        "$(ejetar /mnt/usb123)" "ejetar_protegido"
confere "/mnt/usb7x recusado"         "$(ejetar /mnt/usb7x)" "ejetar_protegido"
confere "nao montado"                 "$(ejetar /mnt/usb7)" "ejetar_nao_montado"
confere "rede sem token: 401"         "$(curl -s -o /dev/null -w '%{http_code}' -H 'X-GLR: 1' -d caminho=$USB http://$IP:$PORTA/api/discos/ejetar)" "401"

echo "--- teste de velocidade rodando"
monta
confere "disco aparece na lista"      "$(curl -s $U/api/discos)" '"caminho":"/mnt/usb7","tipo":"usb"'
kill $PID; wait $PID 2>/dev/null
GLR_DEMO_MBPS=5 "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1
post -d caminho=$USB -d mb=1024 $U/api/velocidade > /dev/null; sleep 0.5
confere "recusa com teste rodando"    "$(ejetar $USB)" "ejetar_teste"
post -X POST $U/api/velocidade/cancelar > /dev/null; sleep 1.5

echo "--- ocupado: mostra quem e nao encerra"
sleep 300 < "$USB/jogos/arq.txt" & SONO=$!
sleep 0.3
R=$(ejetar $USB)
confere "ocupado"                     "$R" '"chave":"ejetar_ocupado"'
confere "pode forcar"                 "$R" '"forcado":false,"pode_forcar":true'
confere "quem ocupa: sleep"           "$R" '"nome":"sleep","arquivo":"/mnt/usb7/jogos/arq.txt"'
confere "vista desmontada antes"      "$R" "\"vistas\":\[{\"ponto\":\"$VISTA\",\"ok\":true"
confere "sleep continua vivo"         "$(kill -0 $SONO 2>/dev/null && echo vivo)" "vivo"
confere "disco continua montado"      "$(montado $USB)" "sim"
confere "diario: nada encerrado"      "$(cat $DADOS/glibren.log)" "ejetar: /mnt/usb7 ocupado (EBUSY) - nada foi encerrado"
R=$(ejetar $USB 1)
confere "forcado: desmontou"          "$R" '"ok":true,"ejetado":true,"caminho":"/mnt/usb7","forcado":true'
confere "diario: forcado"             "$(cat $DADOS/glibren.log)" "FORCADO, confirmado na tela"
confere "sleep ainda vivo (nao matou)" "$(kill -0 $SONO 2>/dev/null && echo vivo)" "vivo"
confere "nao esta mais montado"       "$(montado $USB)" "nao"
kill $SONO 2>/dev/null; wait $SONO 2>/dev/null; SONO=

echo "--- livre"
sleep 0.5; monta
R=$(ejetar $USB)
confere "ejetado"                     "$R" '"ok":true,"ejetado":true,"caminho":"/mnt/usb7","forcado":false'
confere "vista desmontada"            "$(montado $VISTA)" "nao"
confere "disco desmontado"            "$(montado $USB)" "nao"
confere "diario: pode tirar"          "$(cat $DADOS/glibren.log)" "ejetar: /mnt/usb7 desmontado - pode tirar o disco"

kill $PID; wait $PID 2>/dev/null
rm -rf "$T"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
