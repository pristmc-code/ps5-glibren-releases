/* Game Library Renamer (payload PS5) - FPS do jogo aberto (teste, 0.9.14).

Como mede (Fase A do estudo ps5/ESTUDO-fps-monitor-panel.md): o driver de video do PS5 (/dev/dce) tem um contador
de quadros enviados a tela ("flip"/scanout). Uma chamada ioctl so de leitura devolve esse contador; FPS = quantos
quadros andaram dividido pelo tempo. Nao toca no jogo, nao le memoria de ninguem, nao desenha nada na tela do PS5 e
nao depende de endereco por firmware - so do numero do ioctl.
- open("/dev/dce", O_RDWR); ioctl(fd, 0x80308217, &arg), arg de 0x30 bytes = {0x10000000A, 0x8000000000,
  ponteiro da saida, 0, 0, 0}; saida de 0x60 bytes, contador (uint64) em saida+8. Alguns caminhos do PS5 recusam o
  numero com zeros a esquerda (EINVAL): tenta entao 0xFFFFFFFF80308217 (sinal estendido) e lembra o que funcionou.
- Origem da tecnica: PHU Games Tools (ArkSama), usada no onionHEN/HyperHEN (LightningMods) e no fps-monitor-panel
  (rawalakshay, GPL-3.0, source/libonion_fps/source/fps_dce.cpp). So os fatos acima vieram de la; este codigo e
  proprio (C, estilo do glibren).
- Limite: e o ritmo da TELA, nao do processo do jogo (com teto no refresh da TV). A confirmar no PS5 se um jogo
  travado em 30 mostra 30 (e nao 60). Jogos de PS4 (CUSA) ficam sem medicao: o scanout nao e confiavel neles e a
  outra tecnica (gancho no jogo) altera o jogo - fora da regra do dono.

Sob demanda: nao ha thread o tempo todo. O primeiro GET /api/fps cria uma thread que le o contador a cada 250 ms;
cada pedido renova o prazo; sem pedidos por PARAR_S (10 s) ela fecha o /dev/dce, registra o resumo no diario e sai.
Qual jogo: sceSystemServiceGetAppIdOfRunningBigApp + sceSystemServiceGetAppTitleId (prototipos weak); se faltarem,
app_de_jogo_aberto() do lancador.c. Nome: param.json do jogo instalado.

No PC (teste) o contador e simulado: GLR_TESTE_FPS = quadros por segundo (padrao 60), GLR_TESTE_FPS_ERRO = errno do
open (ex.: 13), GLR_TESTE_FPS_PARAR_S = prazo sem pedidos, GLR_TESTE_ABERTOS = jogos "abertos" (como no lancador.c),
GLR_TESTE_APPMETA = pasta no lugar de /user/appmeta (para o nome).
*/
#include "fps.h"

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <time.h>
#include <unistd.h>

#include "config.h"
#include "imagem.h"
#include "lancador.h"
#include "plataforma.h"
#include "primeiro_plano.h"
#include "sce_prazo.h"

#define AMOSTRA_MS 250          /* uma leitura do contador a cada 250 ms (4 ioctls por segundo) */
#define JANELA_AMOSTRAS 8       /* FPS "agora" = ritmo dos ultimos 2 s */
#define PARAR_S 10              /* sem pedidos por 10 s: para de ler */
#define JOGO_S 2                /* confere qual jogo esta aberto a cada 2 s */
#define HISTORICO 300           /* 5 min com um ponto por segundo */
#define FPS_MAX 240

#define DCE "/dev/dce"
#define DCE_IOCTL 0x80308217ul
#define DCE_IOCTL_EXT 0xFFFFFFFF80308217ul
#define DCE_SAIDA 0x60
#define DCE_CONTADOR 8

typedef struct {
  uint64_t seletor, mascara, saida, reservado[3];
} dce_arg_t;
_Static_assert(sizeof(dce_arg_t) == 0x30, "argumento do ioctl do /dev/dce tem 0x30 bytes");

typedef struct {
  uint64_t contador;
  long long ms;
} amostra_t;

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static int g_lendo;                 /* 1 = a thread esta lendo */
static long long g_ultimo_pedido;   /* ms (CLOCK_MONOTONIC) */
static unsigned g_leituras;         /* quantas vezes a leitura foi ligada (diagnostico e testes) */
/* estado publicado (com g_trava) */
static char g_situacao[16] = "parado";   /* parado, iniciando, medindo, erro, ps4 */
static char g_erro[200];
static int g_errno;
static const char *g_variante = "";      /* "normal" ou "estendido" (qual numero do ioctl o PS5 aceitou) */
static char g_tid[16], g_nome[160], g_tipo[16];   /* tipo: ps5, ps4, menu, desconhecido */
static double g_fps = -1;
static double g_soma;               /* sessao do jogo (so tipo ps5): soma e quantidade dos pontos de 1 s */
static int g_qtd_sessao;
static double g_min = -1, g_max = -1;
static short g_hist[HISTORICO];     /* FPS x 10 de cada segundo; -1 = sem leitura */
static int g_hist_inicio, g_hist_qtd;

static long long agora_ms(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (long long)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

static int prazo_parar_s(void) {
#ifndef __PROSPERO__
  const char *v = getenv("GLR_TESTE_FPS_PARAR_S");
  if(v && atoi(v) > 0) return atoi(v);
#endif
  return PARAR_S;
}

int fps_agente_ps5(const char *agente) {
  static const char alvo[] = "playstation";
  const size_t n = sizeof alvo - 1;
  for(const char *p = agente ? agente : ""; *p; p++) {
    size_t i = 0;
    while(i < n && p[i] && tolower((unsigned char)p[i]) == alvo[i]) i++;
    if(i == n) return 1;
  }
  return 0;
}

/* ------------------------------------------------------------------ contador da tela */

#ifdef __PROSPERO__
static int dce_abrir(void) {
  return open(DCE, O_RDWR);
}

static void dce_fechar(int fd) {
  if(fd >= 0) close(fd);
}

/* 0 = leu (contador preenchido); senao -1 com errno. *variante: 0 = ainda nao sabe, 1 = normal, 2 = estendido. */
static int dce_ler(int fd, int *variante, uint64_t *contador) {
  unsigned char saida[DCE_SAIDA];
  for(int tentativa = 0; tentativa < 2; tentativa++) {
    int v = *variante ? *variante : tentativa + 1;
    dce_arg_t arg = {0x10000000Aull, 0x8000000000ull, (uint64_t)(uintptr_t)saida, {0, 0, 0}};
    memset(saida, 0, sizeof saida);
    if(ioctl(fd, v == 2 ? DCE_IOCTL_EXT : DCE_IOCTL, &arg) == 0) {
      *variante = v;
      memcpy(contador, saida + DCE_CONTADOR, sizeof *contador);
      return 0;
    }
    if(*variante || errno != EINVAL) return -1;   /* so troca de numero quando o primeiro deu EINVAL */
  }
  return -1;
}
#else
/* PC: contador que anda GLR_TESTE_FPS quadros por segundo desde a primeira abertura. */
static long long g_sim_inicio;

static int dce_abrir(void) {
  const char *e = getenv("GLR_TESTE_FPS_ERRO");
  if(e && atoi(e) > 0) {
    errno = atoi(e);
    return -1;
  }
  if(!g_sim_inicio) g_sim_inicio = agora_ms();
  return 1;   /* "fd" ficticio: nada e aberto no PC */
}

static void dce_fechar(int fd) {
  (void)fd;
}

static int dce_ler(int fd, int *variante, uint64_t *contador) {
  (void)fd;
  const char *f = getenv("GLR_TESTE_FPS");
  double fps = f && *f ? atof(f) : 60;
  *variante = 1;
  *contador = (uint64_t)((agora_ms() - g_sim_inicio) * fps / 1000.0);
  return 0;
}
#endif

/* ------------------------------------------------------------------ jogo aberto */

#ifdef __PROSPERO__
int sceSystemServiceGetAppIdOfRunningBigApp(void) __attribute__((weak));
int sceSystemServiceGetAppTitleId(int app_id, char *title_id) __attribute__((weak));
#endif

#ifdef __PROSPERO__
/* Pelo watchdog (0.9.16): saida = title ID (32 bytes); 1 = nenhum app grande aberto. */
static int fn_jogo(const void *e, void *s) {
  (void)e;
  int id = sceSystemServiceGetAppIdOfRunningBigApp();
  if(id < 0) return 1;
  return sceSystemServiceGetAppTitleId(id, (char *)s) ? -1 : 0;
}
#endif

static const char *g_fonte = "";   /* de onde veio o jogo: "primeiro_plano" ou "sistema" (so a thread de leitura escreve) */

/* Title ID do app "grande" aberto (jogo) em tid, ou "" se nenhum. 0 = sabe; -1 = nao deu para saber.
   0.9.16: com sinal de primeiro plano (kern.msgbuf) e o foco num titulo, vale o titulo com o foco. */
static int jogo_aberto(char *tid, size_t tam) {
  tid[0] = 0;
  uint32_t foco;
  char t[32];
  if(primeiro_plano_foco(&foco) && foco != FOCO_SISTEMA && !primeiro_plano_titulo(foco, t, sizeof t)) {
    snprintf(tid, tam, "%s", t);
    g_fonte = "primeiro_plano";
    return 0;
  }
  g_fonte = "sistema";
#ifdef __PROSPERO__
  if(sceSystemServiceGetAppIdOfRunningBigApp && sceSystemServiceGetAppTitleId) {
    int r = -1;
    memset(t, 0, sizeof t);
    if(sce_com_prazo("sceSystemServiceGetAppIdOfRunningBigApp", fn_jogo, NULL, 0, t, sizeof t, 1000, &r) != SCE_OK || r < 0) return -1;
    if(r == 1) return 0;   /* nenhum app grande aberto */
    t[sizeof t - 1] = 0;
    snprintf(tid, tam, "%s", t);
    return 0;
  }
#endif
  return app_de_jogo_aberto(tid, tam) < 0 ? -1 : 0;
}

/* ps5, ps4, menu (nenhum jogo; app do sistema ou a pagina do glibren) ou desconhecido. */
static const char *tipo_do_titulo(const char *tid, int sabe) {
  if(!sabe) return "desconhecido";
  if(!tid[0] || !titulo_valido(tid) || !strncmp(tid, "NPXS", 4) || !strcmp(tid, GLIBREN_TITLE_ID)) return "menu";
  if(!strncmp(tid, "CUSA", 4)) return "ps4";
  return "ps5";
}

/* Nome do jogo pelo param.json instalado (no idioma da pagina). "" se nao achar. So a thread de leitura chama. */
static void nome_do_jogo(const char *tid, char *nome, size_t tam) {
  static char pastas[MAX_PASTAS][1024], dados[256 * 1024];
  char caminhos[3][320], idioma[16] = "pt-BR";
  const char *appmeta = "/user/appmeta";
#ifndef __PROSPERO__
  appmeta = getenv("GLR_TESTE_APPMETA") ? getenv("GLR_TESTE_APPMETA") : "/nao-existe";
#endif
  nome[0] = 0;
  config_ler(pastas, idioma);
  snprintf(caminhos[0], sizeof caminhos[0], "%s/%s/param.json", appmeta, tid);
  snprintf(caminhos[1], sizeof caminhos[1], "/user/app/%s/sce_sys/param.json", tid);
  snprintf(caminhos[2], sizeof caminhos[2], "/system_ex/app/%s/sce_sys/param.json", tid);
  for(int i = 0; i < 3 && !nome[0]; i++) {
    FILE *f = fopen(caminhos[i], "rb");
    if(!f) continue;
    size_t n = fread(dados, 1, sizeof dados, f);
    fclose(f);
    info_jogo_t info;
    memset(&info, 0, sizeof info);
    if(n && n < sizeof dados && !param_json_ler(dados, n, idioma, &info)) snprintf(nome, tam, "%s", info.nome);
  }
  for(char *c = nome; *c; c++) if((unsigned char)*c < ' ') *c = ' ';
}

/* ------------------------------------------------------------------ thread de leitura */

/* Zera a sessao e o historico (jogo novo ou leitura nova). Chamar com g_trava. */
static void zerar_sessao(void) {
  g_soma = 0;
  g_qtd_sessao = 0;
  g_min = g_max = -1;
  g_hist_inicio = g_hist_qtd = 0;
  g_fps = -1;
}

static void hist_por(short v) {
  g_hist[(g_hist_inicio + g_hist_qtd) % HISTORICO] = v;
  if(g_hist_qtd < HISTORICO) g_hist_qtd++;
  else g_hist_inicio = (g_hist_inicio + 1) % HISTORICO;
}

/* Erro na tela: chave = "abrir" ou "ioctl" (a pagina traduz), texto = mensagem com o errno. */
static void publicar_erro(int err, const char *texto) {
  pthread_mutex_lock(&g_trava);
  snprintf(g_situacao, sizeof g_situacao, "erro");
  g_errno = err;
  snprintf(g_erro, sizeof g_erro, "%s", texto);
  g_fps = -1;
  pthread_mutex_unlock(&g_trava);
}

static void *medir(void *arg) {
  (void)arg;
  int fd = -1, variante = 0, falha_registrada = 0, sem_dce = 0;
  amostra_t janela[JANELA_AMOSTRAS + 1];
  int n_janela = 0;
  uint64_t cont_seg = 0;
  long long ms_seg = 0, ultimo_jogo = 0, inicio = agora_ms();
  int primeira = 1;
  char tid[16] = "";
  const char *tipo = "";
  diario("fps: leitura ligada (pedido da pagina; para sozinha sem pedidos por %d s)", prazo_parar_s());

  for(;;) {
    long long agora = agora_ms();
    pthread_mutex_lock(&g_trava);
    if(agora - g_ultimo_pedido > prazo_parar_s() * 1000LL) {
      /* ninguem pediu no prazo: para (com o resumo da sessao no diario) */
      g_lendo = 0;
      snprintf(g_situacao, sizeof g_situacao, "parado");
      char resumo[200] = "";
      if(g_qtd_sessao)
        snprintf(resumo, sizeof resumo, "; %s media %.1f min %.1f max %.1f em %d s", g_tid, g_soma / g_qtd_sessao, g_min, g_max,
                 g_qtd_sessao);
      pthread_mutex_unlock(&g_trava);
      dce_fechar(fd);
      diario("fps: leitura parada (sem pedidos ha %d s, ficou ligada %lld s)%s", prazo_parar_s(), (agora - inicio) / 1000, resumo);
      return NULL;
    }
    pthread_mutex_unlock(&g_trava);

    /* qual jogo esta aberto (a cada 2 s) */
    if(primeira || agora - ultimo_jogo >= JOGO_S * 1000LL) {
      ultimo_jogo = agora;
      char novo[16];
      int sabe = jogo_aberto(novo, sizeof novo) == 0;
      const char *novo_tipo = tipo_do_titulo(novo, sabe);
      if(primeira || strcmp(novo, tid) || strcmp(novo_tipo, tipo)) {
        primeira = 0;
        char nome[160] = "";
        if(!strcmp(novo_tipo, "ps5") || !strcmp(novo_tipo, "ps4")) nome_do_jogo(novo, nome, sizeof nome);
        diario("fps: aberto agora: %s (%s)%s%s", novo[0] ? novo : "nenhum jogo", novo_tipo, nome[0] ? " - " : "", nome);
        snprintf(tid, sizeof tid, "%s", novo);
        tipo = novo_tipo;
        pthread_mutex_lock(&g_trava);
        snprintf(g_tid, sizeof g_tid, "%s", novo);
        snprintf(g_nome, sizeof g_nome, "%s", nome);
        snprintf(g_tipo, sizeof g_tipo, "%s", novo_tipo);
        zerar_sessao();
        pthread_mutex_unlock(&g_trava);
        n_janela = 0;
        ms_seg = 0;
      }
    }

    if(!strcmp(tipo, "ps4")) {
      /* jogo de PS4: sem medicao (o contador da tela nao e confiavel nesses jogos) - nem abre o /dev/dce */
      dce_fechar(fd);
      fd = -1;
      pthread_mutex_lock(&g_trava);
      snprintf(g_situacao, sizeof g_situacao, "ps4");
      g_erro[0] = 0;
      g_fps = -1;
      pthread_mutex_unlock(&g_trava);
      usleep(AMOSTRA_MS * 1000);
      continue;
    }

    if(fd < 0) {
      if(sem_dce) {   /* sem permissao / sem o aparelho: nao insiste nesta leitura */
        usleep(1000 * 1000);
        continue;
      }
      fd = dce_abrir();
      if(fd < 0) {
        int e = errno;
        if(e == EPERM || e == EACCES || e == ENOENT || e == ENXIO || e == ENODEV) sem_dce = 1;
        if(!falha_registrada) {
          falha_registrada = 1;
          diario("fps: nao abriu %s: %s (errno %d)", DCE, strerror(e), e);
        }
        char msg[200];
        snprintf(msg, sizeof msg, "nao abriu /dev/dce: %s (errno %d)", strerror(e), e);
        publicar_erro(e, msg);
        usleep(1000 * 1000);
        continue;
      }
    }

    uint64_t contador;
    int antes = variante;
    if(dce_ler(fd, &variante, &contador)) {
      int e = errno;
      if(!falha_registrada) {
        falha_registrada = 1;
        diario("fps: ioctl 0x%lx do %s falhou: %s (errno %d)", DCE_IOCTL, DCE, strerror(e), e);
      }
      char msg[200];
      snprintf(msg, sizeof msg, "o /dev/dce nao deu o contador: %s (errno %d)", strerror(e), e);
      publicar_erro(e, msg);
      if(e == EBADF) {   /* aparelho fechado (volta do repouso): reabre */
        dce_fechar(fd);
        fd = -1;
      }
      n_janela = 0;
      ms_seg = 0;
      usleep(AMOSTRA_MS * 1000);
      continue;
    }
    if(!antes && variante)
      diario("fps: %s aberto; ioctl %s respondeu; contador=%llu", DCE, variante == 2 ? "com sinal estendido" : "normal",
             (unsigned long long)contador);
    agora = agora_ms();

    /* janela dos ultimos 2 s para o numero "agora" */
    if(n_janela && contador < janela[n_janela - 1].contador) n_janela = 0;   /* contador voltou: recomeca */
    if(n_janela == JANELA_AMOSTRAS + 1) {
      memmove(janela, janela + 1, sizeof janela[0] * JANELA_AMOSTRAS);
      n_janela--;
    }
    janela[n_janela++] = (amostra_t){contador, agora};
    double fps = -1;
    if(n_janela >= 3) {
      long long dt = agora - janela[0].ms;
      double v = dt > 0 ? (double)(contador - janela[0].contador) * 1000.0 / dt : -1;
      if(v >= 0 && v <= FPS_MAX) fps = v;
    }

    /* um ponto por segundo no historico e na sessao */
    double ponto = -2;
    if(!ms_seg) {
      ms_seg = agora;
      cont_seg = contador;
    } else if(agora - ms_seg >= 1000) {
      double v = contador >= cont_seg ? (double)(contador - cont_seg) * 1000.0 / (agora - ms_seg) : -1;
      ponto = v >= 0 && v <= FPS_MAX ? v : -1;
      ms_seg = agora;
      cont_seg = contador;
    }

    pthread_mutex_lock(&g_trava);
    snprintf(g_situacao, sizeof g_situacao, fps >= 0 ? "medindo" : "iniciando");
    g_erro[0] = 0;
    g_errno = 0;
    g_variante = variante == 2 ? "estendido" : "normal";
    g_fps = fps;
    if(ponto > -2) {
      hist_por(ponto >= 0 ? (short)(ponto * 10 + 0.5) : -1);
      if(ponto >= 0 && !strcmp(tipo, "ps5")) {   /* media/min/max so de jogo de PS5 (o menu nao conta) */
        g_soma += ponto;
        g_qtd_sessao++;
        if(g_min < 0 || ponto < g_min) g_min = ponto;
        if(ponto > g_max) g_max = ponto;
      }
    }
    pthread_mutex_unlock(&g_trava);
    falha_registrada = 0;
    usleep(AMOSTRA_MS * 1000);
  }
}

/* ------------------------------------------------------------------ JSON */

static void num(buf_t *b, const char *nome, double v) {
  if(v < 0) buf_fmt(b, ",\"%s\":-1", nome);
  else buf_fmt(b, ",\"%s\":%.1f", nome, v);
}

void fps_json(buf_t *b, int com_historico) {
#ifdef __PROSPERO__
  const char *simulado = "false";
#else
  const char *simulado = "true";
#endif
  pthread_mutex_lock(&g_trava);
  g_ultimo_pedido = agora_ms();
  if(!g_lendo) {
    g_lendo = 1;
    g_leituras++;
    snprintf(g_situacao, sizeof g_situacao, "iniciando");
    g_erro[0] = 0;
    g_errno = 0;
    g_variante = "";
    g_tid[0] = g_nome[0] = g_tipo[0] = 0;
    zerar_sessao();
    if(criar_thread(medir, NULL, NULL)) {
      g_lendo = 0;
      snprintf(g_situacao, sizeof g_situacao, "erro");
      snprintf(g_erro, sizeof g_erro, "nao criou a thread de leitura");
    }
  }
  buf_fmt(b, "{\"ok\":true,\"teste\":true,\"lendo\":%s,\"leituras\":%u,\"parar_s\":%d,\"intervalo_hist\":1,\"simulado\":%s,\"situacao\":",
          g_lendo ? "true" : "false", g_leituras, prazo_parar_s(), simulado);
  buf_json(b, g_situacao);
  buf_str(b, ",\"erro\":");
  buf_json(b, g_erro);
  buf_fmt(b, ",\"errno\":%d,\"variante\":", g_errno);
  buf_json(b, g_variante);
  buf_str(b, ",\"tid\":");
  buf_json(b, g_tid);
  buf_str(b, ",\"nome\":");
  buf_json(b, g_nome);
  buf_str(b, ",\"tipo\":");
  buf_json(b, g_tipo);
  buf_str(b, ",\"fonte\":");
  buf_json(b, g_fonte);
  num(b, "fps", g_fps);
  num(b, "media", g_qtd_sessao ? g_soma / g_qtd_sessao : -1);
  num(b, "minimo", g_min);
  num(b, "maximo", g_max);
  buf_fmt(b, ",\"segundos\":%d", g_qtd_sessao);
  if(com_historico) {
    /* FPS x 10 de cada segundo, do mais antigo ao mais novo (-1 = sem leitura) */
    buf_str(b, ",\"historico\":[");
    for(int i = 0; i < g_hist_qtd; i++) buf_fmt(b, "%s%d", i ? "," : "", g_hist[(g_hist_inicio + i) % HISTORICO]);
    buf_str(b, "]");
  }
  buf_str(b, "}");
  pthread_mutex_unlock(&g_trava);
}
