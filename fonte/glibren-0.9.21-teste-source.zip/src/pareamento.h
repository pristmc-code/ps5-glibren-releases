/* Game Library Renamer (payload PS5) - pareamento por codigo mostrado na TV (0.9.16).

A leitura continua livre. As acoes que apagam, movem, renomeiam, atualizam, ejetam, ativam ou trocam de app (e
desligar/parar o payload) exigem um aparelho pareado: a pagina pede um codigo, o PS5 mostra o codigo numa
notificacao, a pagina manda o codigo e recebe um token, guardado no localStorage do navegador. O payload guarda so o
SHA-256 do token (config.ini, "paired"). Pedidos de 127.0.0.1 (navegador do PS5, Jobe, apps) ficam isentos.
"pairing = off" no config.ini desliga o pareamento. Modelo: ps5-hass-payload (Phynix88, GPL-3.0); codigo proprio. */
#pragma once

#include "http.h"

/* 1 = o pedido pode fazer uma acao protegida (local, pareamento desligado ou token valido). */
int pareamento_permitido(const pedido_t *p);
/* Responde 401 {"ok":false,"chave":"parear_necessario",...} */
void pareamento_recusar(pedido_t *p);
/* GET /api/pareamento: {"ok":true,"ligado":..,"local":..,"pareado":..,"aparelhos":N} */
void pareamento_rota_estado(pedido_t *p);
/* POST /api/parear/pedir: cria um codigo de 6 digitos (2 min) e mostra na TV */
void pareamento_rota_pedir(pedido_t *p);
/* POST /api/parear (codigo, nome): confere o codigo e devolve o token */
void pareamento_rota_conferir(pedido_t *p);
/* POST /api/parear/esquecer: (com token valido ou local) apaga todos os aparelhos pareados */
void pareamento_rota_esquecer(pedido_t *p);
