/* Game Library Renamer (payload PS5) - pareamento por codigo mostrado na TV (ver pareamento.h).

Limites:
- codigo de 6 digitos, vale 2 min, 5 tentativas erradas e ele e descartado;
- falhas seguidas bloqueiam novos codigos e tentativas por 30 s, 1, 2, 4... ate 15 min;
- um codigo novo no maximo a cada 10 s (nao enche a TV de notificacoes);
- codigo e token comparados em tempo constante; o codigo nunca vai para o diario (o /diario e de leitura livre). */
#include "pareamento.h"

#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "config.h"
#include "plataforma.h"
#include "sha256.h"
#include "util.h"

#define VALIDADE_CODIGO_S 120
#define TENTATIVAS_CODIGO 5
#define INTERVALO_PEDIDOS_S 10
#define BLOQUEIO_MIN_S 30
#define BLOQUEIO_MAX_S 900
#define TAM_TOKEN 64   /* 32 bytes em hexa */

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static char g_codigo[7];         /* "" = nenhum ativo */
static time_t g_codigo_ate, g_ultimo_pedido, g_bloqueado_ate;
static int g_erros_codigo, g_nivel_bloqueio;

/* Iguais em tempo constante (mesmo tamanho n). */
static int iguais(const char *a, const char *b, size_t n) {
  unsigned char d = 0;
  for(size_t i = 0; i < n; i++) d |= (unsigned char)a[i] ^ (unsigned char)b[i];
  return d == 0;
}

static void aleatorio(void *saida, size_t n) {
  arc4random_buf(saida, n);
}

static int token_formato(const char *t) {
  if(strlen(t) != TAM_TOKEN) return 0;
  for(const char *c = t; *c; c++)
    if(!((*c >= '0' && *c <= '9') || (*c >= 'a' && *c <= 'f'))) return 0;
  return 1;
}

static void hash_token(const char *token, char hex[65]) {
  sha256_t s;
  uint8_t r[32];
  sha256_iniciar(&s);
  sha256_atualizar(&s, token, strlen(token));
  sha256_final(&s, r);
  sha256_hex(r, hex);
}

/* Token valido (algum aparelho pareado)? Percorre todos (tempo nao depende de qual bateu). */
static int token_valido(const char *token) {
  if(!token_formato(token)) return 0;
  char hex[65], linhas[MAX_PAREADOS][TAM_PAREADO];
  hash_token(token, hex);
  int qtd = config_pareados(linhas, MAX_PAREADOS), ok = 0;
  for(int i = 0; i < qtd; i++)
    if(strlen(linhas[i]) >= 64) ok |= iguais(linhas[i], hex, 64);
  return ok;
}

int pareamento_permitido(const pedido_t *p) {
  if(p->local || !config_pareamento()) return 1;
  return token_valido(p->token);
}

void pareamento_recusar(pedido_t *p) {
  static const char msg[] = "{\"ok\":false,\"chave\":\"parear_necessario\",\"erro\":\"pareie este aparelho: o PS5 mostra um codigo na TV\",\"params\":{}}";
  responder(p, 401, "application/json; charset=utf-8", msg, sizeof msg - 1, NULL);
}

void pareamento_rota_estado(pedido_t *p) {
  char linhas[MAX_PAREADOS][TAM_PAREADO];
  int qtd = config_pareados(linhas, MAX_PAREADOS);
  buf_t b = {0};
  buf_fmt(&b, "{\"ok\":true,\"ligado\":%s,\"local\":%s,\"pareado\":%s,\"aparelhos\":%d}", config_pareamento() ? "true" : "false",
          p->local ? "true" : "false", token_valido(p->token) ? "true" : "false", qtd);
  responder_json(p, 200, &b);
  buf_free(&b);
}

static void responder_falha(pedido_t *p, const char *chave, const char *msg, const char *extra) {
  buf_t b = {0};
  buf_str(&b, "{\"ok\":false,\"chave\":");
  buf_json(&b, chave);
  buf_str(&b, ",\"erro\":");
  buf_json(&b, msg);
  buf_fmt(&b, ",\"params\":{%s}}", extra ? extra : "");
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* Bloqueado agora? (chamar com g_trava) segundos restantes ou 0. */
static long bloqueio_restante(time_t agora) {
  return g_bloqueado_ate > agora ? (long)(g_bloqueado_ate - agora) : 0;
}

/* Mais uma falha seguida: codigo descartado e bloqueio crescente. Chamar com g_trava. */
static void bloquear(time_t agora) {
  long s = BLOQUEIO_MIN_S;
  for(int i = 0; i < g_nivel_bloqueio && s < BLOQUEIO_MAX_S; i++) s *= 2;
  if(s > BLOQUEIO_MAX_S) s = BLOQUEIO_MAX_S;
  g_bloqueado_ate = agora + s;
  g_nivel_bloqueio++;
  g_codigo[0] = 0;
  g_erros_codigo = 0;
  diario("pareamento: %d tentativas erradas - bloqueado por %ld s", TENTATIVAS_CODIGO, s);
}

void pareamento_rota_pedir(pedido_t *p) {
  char extra[64];
  time_t agora = time(NULL);
  if(!config_pareamento()) {
    responder_falha(p, "parear_desligado", "o pareamento esta desligado no config.ini", NULL);
    return;
  }
  pthread_mutex_lock(&g_trava);
  long espera = bloqueio_restante(agora);
  if(!espera && g_ultimo_pedido && agora - g_ultimo_pedido < INTERVALO_PEDIDOS_S && g_codigo[0])
    espera = INTERVALO_PEDIDOS_S - (long)(agora - g_ultimo_pedido);
  if(espera) {
    pthread_mutex_unlock(&g_trava);
    snprintf(extra, sizeof extra, "\"espera\":%ld", espera);
    responder_falha(p, "parear_espere", "espere antes de pedir outro codigo", extra);
    return;
  }
  uint32_t n;
  aleatorio(&n, sizeof n);
  snprintf(g_codigo, sizeof g_codigo, "%06u", (unsigned)(n % 1000000u));
  g_codigo_ate = agora + VALIDADE_CODIGO_S;
  g_ultimo_pedido = agora;
  g_erros_codigo = 0;
  char codigo[7];
  memcpy(codigo, g_codigo, sizeof codigo);
  pthread_mutex_unlock(&g_trava);
  /* so na tela do PS5 (nunca no diario nem na resposta) */
  notificar("Game Library Renamer: codigo de pareamento %s (vale 2 min)", codigo);
  diario("pareamento: codigo pedido por um aparelho da rede (mostrado na TV)");
  buf_t b = {0};
  buf_fmt(&b, "{\"ok\":true,\"validade\":%d}", VALIDADE_CODIGO_S);
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* Nome do aparelho so com letras, numeros, espaco, ponto, hifen e sublinhado (ate 32). */
static void limpar_nome(const char *in, char *out, size_t tam) {
  size_t k = 0;
  for(const char *c = in; *c && k + 1 < tam && k < 32; c++) {
    char x = *c;
    if((x >= 'a' && x <= 'z') || (x >= 'A' && x <= 'Z') || (x >= '0' && x <= '9') || x == ' ' || x == '.' || x == '-' || x == '_')
      out[k++] = x;
  }
  out[k] = 0;
  if(!k) snprintf(out, tam, "aparelho");
}

void pareamento_rota_conferir(pedido_t *p) {
  char codigo[16] = "", nome_in[64] = "", nome[40], extra[64];
  param(p->corpo, "codigo", 0, codigo, sizeof codigo);
  param(p->corpo, "nome", 0, nome_in, sizeof nome_in);
  time_t agora = time(NULL);
  if(!config_pareamento()) {
    responder_falha(p, "parear_desligado", "o pareamento esta desligado no config.ini", NULL);
    return;
  }
  pthread_mutex_lock(&g_trava);
  long espera = bloqueio_restante(agora);
  if(espera) {
    pthread_mutex_unlock(&g_trava);
    snprintf(extra, sizeof extra, "\"espera\":%ld", espera);
    responder_falha(p, "parear_bloqueado", "muitas tentativas erradas: espere", extra);
    return;
  }
  if(!g_codigo[0]) {
    pthread_mutex_unlock(&g_trava);
    responder_falha(p, "parear_sem_codigo", "peca um codigo novo", NULL);
    return;
  }
  if(agora > g_codigo_ate) {
    g_codigo[0] = 0;
    pthread_mutex_unlock(&g_trava);
    responder_falha(p, "parear_expirou", "o codigo expirou: peca outro", NULL);
    return;
  }
  /* compara sempre 6 posicoes (um codigo de tamanho errado tambem conta como erro) */
  char tentativa[7] = "______";
  if(strlen(codigo) == 6) memcpy(tentativa, codigo, 6);
  if(!iguais(tentativa, g_codigo, 6)) {
    int restam = TENTATIVAS_CODIGO - ++g_erros_codigo;
    if(restam <= 0) {
      bloquear(agora);
      espera = bloqueio_restante(agora);
      pthread_mutex_unlock(&g_trava);
      snprintf(extra, sizeof extra, "\"espera\":%ld", espera);
      responder_falha(p, "parear_bloqueado", "muitas tentativas erradas: espere", extra);
      return;
    }
    pthread_mutex_unlock(&g_trava);
    snprintf(extra, sizeof extra, "\"restam\":%d", restam);
    responder_falha(p, "parear_codigo_errado", "codigo errado", extra);
    return;
  }
  g_codigo[0] = 0;   /* um codigo, um aparelho */
  g_erros_codigo = 0;
  g_nivel_bloqueio = 0;
  pthread_mutex_unlock(&g_trava);

  uint8_t bruto[32];
  char token[TAM_TOKEN + 1], hex[65];
  aleatorio(bruto, sizeof bruto);
  for(int i = 0; i < 32; i++) snprintf(token + i * 2, 3, "%02x", bruto[i]);
  hash_token(token, hex);
  limpar_nome(nome_in, nome, sizeof nome);
  char linhas[MAX_PAREADOS][TAM_PAREADO];
  int qtd = config_pareados(linhas, MAX_PAREADOS);
  if(qtd == MAX_PAREADOS) {   /* cheio: sai o mais antigo */
    memmove(linhas[0], linhas[1], sizeof linhas[0] * (MAX_PAREADOS - 1));
    qtd--;
  }
  snprintf(linhas[qtd++], TAM_PAREADO, "%s %lld %s", hex, (long long)agora, nome);
  if(config_gravar_pareados(linhas, qtd)) {
    responder_falha(p, "parear_gravar", "nao foi possivel gravar o pareamento", NULL);
    return;
  }
  diario("pareamento: aparelho \"%s\" pareado (%d no total)", nome, qtd);
  notificar("Game Library Renamer: aparelho \"%s\" pareado", nome);
  buf_t b = {0};
  buf_str(&b, "{\"ok\":true,\"token\":");
  buf_json(&b, token);
  buf_str(&b, "}");
  responder_json(p, 200, &b);
  buf_free(&b);
}

void pareamento_rota_esquecer(pedido_t *p) {
  if(!p->local && !token_valido(p->token)) {
    pareamento_recusar(p);
    return;
  }
  if(config_gravar_pareados(NULL, 0)) {
    responder_falha(p, "parear_gravar", "nao foi possivel gravar", NULL);
    return;
  }
  diario("pareamento: todos os aparelhos foram esquecidos");
  responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
}
