/* Game Library Renamer (payload PS5) - downloads HTTPS (sceHttp no PS5, curl no PC). */
#include "https.h"

#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>

#include "dns_ca.h"
#include "dns_resolver.h"
#include "plataforma.h"

#define USER_AGENT "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Safari/537.36"

static const char *HOSTS[] = {
  "raw.githubusercontent.com",                    /* base de titulos (andshrew/PlayStation-Titles) */
  "prosperopatches.com", "cdn.prosperopatches.com", /* PS5: nome do publisher e icone */
  "orbispatches.com", "cdn.orbispatches.com",       /* PS4 */
  "speed.cloudflare.com",                           /* teste de velocidade da internet */
  "www.speedtest.net",                              /* lista de servidores de teste perto do PS5 */
  "github.com",                                     /* apps homebrew: assets das releases (1o salto, redireciona) */
  "release-assets.githubusercontent.com",           /* destino atual dos assets das releases (conferido 04/11/2026) */
  "objects.githubusercontent.com",                  /* destino antigo dos assets das releases */
  "codeload.github.com",                            /* catalogo de cheats (zip da branch do HEN-Cheats-Collection) */
  NULL};

/* Servidores de teste de internet vindos da lista do speedtest.net (mudam conforme a regiao do PS5). R8 (0.9.12):
   lista propria, so vale para o teste de velocidade (https_fluxo), nunca para /api/web, /icone ou downloads; nome de
   host com pelo menos uma letra (IP literal recusado). */
#define MAX_EXTRAS 16
static char g_extras[MAX_EXTRAS][128];
static int g_n_extras;
static pthread_mutex_t g_trava_hosts = PTHREAD_MUTEX_INITIALIZER;

void https_permitir_host(const char *host) {
  size_t n = strcspn(host, ":");
  if(!n || n >= sizeof g_extras[0]) return;
  int letra = 0;
  for(size_t i = 0; i < n; i++) {
    char c = host[i];
    if(!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '.' || c == '-')) return;
    letra |= (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
  }
  if(!letra) return;
  pthread_mutex_lock(&g_trava_hosts);
  int ja = 0;
  for(int i = 0; i < g_n_extras && !ja; i++) ja = strlen(g_extras[i]) == n && !strncasecmp(g_extras[i], host, n);
  if(!ja) {
    if(g_n_extras == MAX_EXTRAS) {   /* cheia: descarta o mais antigo */
      memmove(g_extras[0], g_extras[1], sizeof g_extras[0] * (MAX_EXTRAS - 1));
      g_n_extras--;
    }
    memcpy(g_extras[g_n_extras], host, n);
    g_extras[g_n_extras++][n] = 0;
  }
  pthread_mutex_unlock(&g_trava_hosts);
}

/* extras = 1: aceita tambem os servidores do speedtest (so o teste de internet). */
static int url_ok(const char *url, int extras) {
#ifndef __PROSPERO__
  /* So no PC, so nos testes: servidor local no lugar do GitHub (GLR_TESTE_BASE=http://127.0.0.1:PORTA/). */
  const char *teste = getenv("GLR_TESTE_BASE");
  if(teste && !strncmp(teste, "http://127.0.0.1:", 17) && !strncmp(url, teste, strlen(teste)) && !strchr(url, '\'')) return 1;
#endif
  if(strncmp(url, "https://", 8)) return 0;
  /* so caracteres comuns de URL (tambem evita qualquer problema ao passar para o curl no PC) */
  for(const char *p = url; *p; p++) {
    if(!strchr("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~:/?#[]@!$&()*+,;=%", *p)) return 0;
    /* R2: "https://site-permitido:x@outro/" conferia o host antes do @ e conectava no de depois */
    if(*p == '\'' || *p == '$' || *p == '(' || *p == ')' || *p == ';' || *p == '@') return 0;
  }
  const char *host = url + 8;
  size_t n = strcspn(host, "/:?#");
  /* depois do host: fim, "/", "?", "#" ou ":" + porta (so digitos) */
  const char *depois = host + n;
  if(*depois == ':') {
    size_t d = strspn(depois + 1, "0123456789");
    if(!d || (depois[1 + d] && !strchr("/?#", depois[1 + d]))) return 0;
  }
  for(int i = 0; HOSTS[i]; i++) {
    if(strlen(HOSTS[i]) == n && !strncasecmp(host, HOSTS[i], n)) return 1;
  }
  if(!extras) return 0;
  int ok = 0;
  pthread_mutex_lock(&g_trava_hosts);
  for(int i = 0; i < g_n_extras && !ok; i++) ok = strlen(g_extras[i]) == n && !strncasecmp(host, g_extras[i], n);
  pthread_mutex_unlock(&g_trava_hosts);
  return ok;
}

int url_permitida(const char *url) {
  return url_ok(url, 0);
}

#ifdef __PROSPERO__
/* PS5: biblioteca sceHttp do proprio console, do jeito que o ProsperoMgr usa (a 0.1 usava a sceHttp2 e nao
   conseguiu acessar a internet no PS5 real):
   - um contexto novo (pool de rede, SSL, HTTP, modelo) para cada pedido, fechado no fim;
   - SNI ligado (opcao 0x80 do sceHttps), como no JobeesLair: sem ele o GitHub e a Cloudflare recusam a negociacao
     segura (era o 0x8095f00c da 0.3/0.4). O certificado e verificado pelo PS5;
   - se mesmo assim a parte segura falhar (erro 0x8095fxxx), passa a aceitar o certificado sem verificar, como o
     ProsperoMgr - autorizado pelo usuario em 03/11/2026 (sites publicos; nada de senha ou dado pessoal enviado);
     a conexao continua criptografada e o diario registra quando isso acontece;
   - o nome do site e resolvido aqui: DNS do proprio PS5 e, se falhar, DNS publico (8.8.8.8 / 1.1.1.1); conecta
     pelo IP com o cabecalho Host e, se o site recusar (alguns exigem o nome na conexao), tenta pelo nome;
   - tempo limite de 20 s em cada etapa e redirecionamentos seguidos aqui (ate 5). */
#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/time.h>

int sceNetInit(void);
int sceNetPoolCreate(const char *, int, int);
int sceNetPoolDestroy(int);
int sceNetCtlInit(void);
int sceSslInit(size_t);
int sceSslTerm(int);
int sceHttpInit(int, int, size_t);
int sceHttpTerm(int);
int sceHttpCreateTemplate(int, const char *, int, int);
int sceHttpDeleteTemplate(int);
int sceHttpSetAutoRedirect(int, int);
int sceHttpSetResponseHeaderMaxSize(int, size_t);
int sceHttpsSetSslCallback(int, void *, void *);
int sceHttpsEnableOption(int, unsigned int);
int sceHttpSetResolveTimeOut(int, unsigned int);
int sceHttpSetConnectTimeOut(int, unsigned int);
int sceHttpSetSendTimeOut(int, unsigned int);
int sceHttpSetRecvTimeOut(int, unsigned int);
int sceHttpCreateConnectionWithURL(int, const char *, int);
int sceHttpDeleteConnection(int);
int sceHttpCreateRequestWithURL(int, int, const char *, uint64_t);
int sceHttpDeleteRequest(int);
int sceHttpAddRequestHeader(int, const char *, const char *, unsigned int);
int sceHttpSendRequest(int, const void *, size_t);
int sceHttpGetStatusCode(int, int *);
int sceHttpGetAllResponseHeaders(int, char **, size_t *);
int sceHttpReadData(int, void *, size_t);

#define METODO_GET 0
#define METODO_POST 1
#define METODO_PUT 4   /* SCE_HTTP_METHOD_PUT (GET, POST, HEAD, OPTIONS, PUT, ...) */
#define ESPERA_US (20u * 1000u * 1000u)
#define MAX_REDIRECIONAR 5

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;   /* downloads comuns: um por vez */
static pthread_mutex_t g_trava_dns = PTHREAD_MUTEX_INITIALIZER;

#define HTTPS_SNI 0x80
#define ERRO_SSL(r) (((unsigned)(r) & 0xfffff000u) == 0x8095f000u)
static volatile int g_sem_verificar;   /* 1 depois que a verificacao do certificado falhou (ver o inicio) */

/* Chamada pelo PS5 na verificacao do certificado: 0 = aceitar (so no modo sem verificar, ver o inicio). */
static int aceitar_certificado(void) {
  return 0;
}

void https_iniciar(void) {
  int r1 = sceNetInit(), r2 = sceNetCtlInit();
  diario("rede: sceNetInit 0x%08x, sceNetCtlInit 0x%08x", (unsigned)r1, (unsigned)r2);
}

/* ---- DNS ---- */

#define MAX_DNS 24
static struct {
  char host[128], ip[48];
  int modo;   /* 0 = ainda nao sabe; 1 = pelo IP funcionou; 2 = so pelo nome */
} g_dns[MAX_DNS];
static int g_n_dns;

static int dns_sistema(const char *host, char *ip, size_t tam) {
  struct addrinfo dica = {.ai_family = AF_INET, .ai_socktype = SOCK_STREAM}, *res = NULL;
  if(getaddrinfo(host, NULL, &dica, &res) || !res) return -1;
  const char *ok = inet_ntop(AF_INET, &((struct sockaddr_in *)res->ai_addr)->sin_addr, ip, tam);
  freeaddrinfo(res);
  return ok ? 0 : -1;
}

/* Pergunta direto a um DNS publico por UDP (registro A). */
static int dns_publico(const char *host, char *ip, size_t tam) {
  static const char *servidores[] = {"8.8.8.8", "1.1.1.1"};
  uint8_t q[512], r[1500];
  uint16_t id = (uint16_t)arc4random();
  size_t n = 0;
  q[n++] = id >> 8;
  q[n++] = id & 0xff;
  q[n++] = 0x01;   /* recursao desejada */
  q[n++] = 0x00;
  q[n++] = 0x00;
  q[n++] = 0x01;   /* 1 pergunta */
  memset(q + n, 0, 6);
  n += 6;
  for(const char *p = host; *p;) {
    size_t rot = strcspn(p, ".");
    if(!rot || rot > 63 || n + rot + 6 > sizeof q) return -1;
    q[n++] = (uint8_t)rot;
    memcpy(q + n, p, rot);
    n += rot;
    p += rot;
    if(*p == '.') p++;
  }
  q[n++] = 0;
  q[n++] = 0;
  q[n++] = 1;   /* tipo A */
  q[n++] = 0;
  q[n++] = 1;   /* classe IN */
  for(size_t s = 0; s < sizeof servidores / sizeof *servidores; s++) {
    int fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if(fd < 0) continue;
    struct timeval espera = {.tv_sec = 4};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &espera, sizeof espera);
    struct sockaddr_in end = {.sin_family = AF_INET, .sin_port = htons(53)};
    inet_pton(AF_INET, servidores[s], &end.sin_addr);
    ssize_t lidos = -1;
    if(!connect(fd, (struct sockaddr *)&end, sizeof end) && send(fd, q, n, 0) == (ssize_t)n) lidos = recv(fd, r, sizeof r, 0);
    close(fd);
    if(lidos < 12 || ((r[0] << 8) | r[1]) != id || !(r[2] & 0x80)) continue;
    int respostas = (r[6] << 8) | r[7];
    size_t pos = 12;
    /* pula a pergunta */
    while(pos < (size_t)lidos && r[pos]) pos += (r[pos] & 0xc0) == 0xc0 ? 1 : r[pos] + 1;
    pos += 5;
    for(int a = 0; a < respostas && pos + 12 <= (size_t)lidos; a++) {
      if((r[pos] & 0xc0) == 0xc0) pos += 2;
      else {
        while(pos < (size_t)lidos && r[pos]) pos += r[pos] + 1;
        pos++;
      }
      if(pos + 10 > (size_t)lidos) break;
      int tipo = (r[pos] << 8) | r[pos + 1], comp = (r[pos + 8] << 8) | r[pos + 9];
      pos += 10;
      if(tipo == 1 && comp == 4 && pos + 4 <= (size_t)lidos) {
        snprintf(ip, tam, "%u.%u.%u.%u", r[pos], r[pos + 1], r[pos + 2], r[pos + 3]);
        return 0;
      }
      pos += comp;
    }
  }
  return -1;
}

/* Indice do host no cache (resolve na primeira vez), ou -1. */
static int resolver(const char *host) {
  int i;
  /* 0.9.16: GitHub, catalogo e icones pelo dns_resolver.c (UDP -> TCP -> DoH, cache de 600 s/20 s); o IP pode mudar */
  int robusto = dns_host_robusto(host);
  pthread_mutex_lock(&g_trava_dns);
  for(i = 0; i < g_n_dns; i++)
    if(!strcmp(g_dns[i].host, host)) break;
  if(i < g_n_dns && robusto) {
    char ip[48] = "";
    pthread_mutex_unlock(&g_trava_dns);
    int ok = !dns_resolver(host, ip, sizeof ip, NULL);
    pthread_mutex_lock(&g_trava_dns);
    if(ok) snprintf(g_dns[i].ip, sizeof g_dns[i].ip, "%s", ip);
    else i = -1;
  } else if(i == g_n_dns) {
    char ip[48] = "";
    pthread_mutex_unlock(&g_trava_dns);
    int ok = robusto ? !dns_resolver(host, ip, sizeof ip, NULL) : (!dns_sistema(host, ip, sizeof ip) || !dns_publico(host, ip, sizeof ip));
    pthread_mutex_lock(&g_trava_dns);
    if(!ok) {
      diario("DNS: nao resolveu %s", host);
      i = -1;
    } else {
      i = g_n_dns < MAX_DNS ? g_n_dns++ : MAX_DNS - 1;
      snprintf(g_dns[i].host, sizeof g_dns[i].host, "%s", host);
      snprintf(g_dns[i].ip, sizeof g_dns[i].ip, "%s", ip);
      g_dns[i].modo = 0;
    }
  }
  pthread_mutex_unlock(&g_trava_dns);
  return i;
}

/* ---- pedidos ---- */

typedef struct {
  int pool, ssl, http, modelo, con, req, sem_verificar;
} contexto_t;

static void tempo_limite(int id) {
  sceHttpSetResolveTimeOut(id, ESPERA_US);
  sceHttpSetConnectTimeOut(id, ESPERA_US);
  sceHttpSetSendTimeOut(id, ESPERA_US);
  sceHttpSetRecvTimeOut(id, ESPERA_US);
}

static void fechar_pedido(contexto_t *c) {
  if(c->req >= 0) sceHttpDeleteRequest(c->req);
  if(c->con >= 0) sceHttpDeleteConnection(c->con);
  c->req = c->con = -1;
}

static void fechar(contexto_t *c) {
  fechar_pedido(c);
  if(c->modelo >= 0) sceHttpDeleteTemplate(c->modelo);
  if(c->http >= 0) sceHttpTerm(c->http);
  if(c->ssl >= 0) sceSslTerm(c->ssl);
  if(c->pool >= 0) sceNetPoolDestroy(c->pool);
}

static int abrir_contexto(contexto_t *c, int sem_verificar) {
  memset(c, 0xff, sizeof *c);   /* tudo -1 */
  c->sem_verificar = sem_verificar;
  if((c->pool = sceNetPoolCreate("glibren", 512 * 1024, 0)) < 0 || (c->ssl = sceSslInit(384 * 1024)) < 0 ||
     (c->http = sceHttpInit(c->pool, c->ssl, 256 * 1024)) < 0 ||
     (c->modelo = sceHttpCreateTemplate(c->http, USER_AGENT, 2, 1)) < 0) {
    diario("https: contexto falhou (pool %d ssl %d http %d modelo %d)", c->pool, c->ssl, c->http, c->modelo);
    return -1;
  }
  sceHttpSetResponseHeaderMaxSize(c->modelo, 0x4000);
  sceHttpSetAutoRedirect(c->modelo, 0);   /* redirecionamento seguido aqui, com o nosso DNS */
  sceHttpsEnableOption(c->modelo, HTTPS_SNI);   /* nome do site na negociacao segura */
  if(sem_verificar) sceHttpsSetSslCallback(c->modelo, (void *)aceitar_certificado, NULL);
  tempo_limite(c->modelo);
  return 0;
}

/* Um pedido (sem seguir redirecionamento). por_ip: conecta no IP resolvido aqui, com o cabecalho Host.
   Devolve 0 ou o codigo de erro do PS5. */
/* 0.9.21: token != NULL = PUT do diagnostico no GitHub (Authorization + cabecalhos da API, corpo JSON). */
static int enviar_ext(contexto_t *c, const char *url, int metodo, const void *corpo, size_t tam, int por_ip, int *status,
                      const char *token);
static int enviar(contexto_t *c, const char *url, int metodo, const void *corpo, size_t tam, int por_ip, int *status) {
  return enviar_ext(c, url, metodo, corpo, tam, por_ip, status, NULL);
}

static int enviar_ext(contexto_t *c, const char *url, int metodo, const void *corpo, size_t tam, int por_ip, int *status,
                      const char *token) {
  char host[128], url_ip[2048];
  const char *ini = strstr(url, "://");
  if(!ini) return -1;
  ini += 3;
  size_t n = strcspn(ini, "/:?#");
  if(!n || n >= sizeof host) return -1;
  memcpy(host, ini, n);
  host[n] = 0;
  const char *alvo = url;
  if(por_ip) {
    int i = resolver(host);
    if(i < 0) return -1;
    snprintf(url_ip, sizeof url_ip, "%.*s%s%s", (int)(ini - url), url, g_dns[i].ip, ini + n);
    alvo = url_ip;
  }
  int r;
  if((c->con = sceHttpCreateConnectionWithURL(c->modelo, alvo, 0)) < 0) {
    r = c->con;
    goto erro;
  }
  tempo_limite(c->con);
  if((c->req = sceHttpCreateRequestWithURL(c->con, metodo, alvo, corpo ? tam : 0)) < 0) {
    r = c->req;
    goto erro;
  }
  tempo_limite(c->req);
  if(por_ip) sceHttpAddRequestHeader(c->req, "Host", host, 0);
  sceHttpAddRequestHeader(c->req, "Accept-Encoding", "identity", 0);   /* sem compressao: a pagina le o HTML */
  if(token) {
    char aut[300];
    snprintf(aut, sizeof aut, "Bearer %s", token);
    sceHttpAddRequestHeader(c->req, "Authorization", aut, 0);
    memset(aut, 0, sizeof aut);
    sceHttpAddRequestHeader(c->req, "Accept", "application/vnd.github+json", 0);
    sceHttpAddRequestHeader(c->req, "X-GitHub-Api-Version", "2022-11-28", 0);
    sceHttpAddRequestHeader(c->req, "Content-Type", "application/json", 0);
  } else if(corpo) {
    sceHttpAddRequestHeader(c->req, "Content-Type", "application/octet-stream", 0);
  }
  if((r = sceHttpSendRequest(c->req, corpo, corpo ? tam : 0)) || (r = sceHttpGetStatusCode(c->req, status))) goto erro;
  return 0;
erro:
  diario("https: %s %s (%s%s) falhou 0x%08x", metodo == METODO_PUT ? "PUT" : metodo == METODO_POST ? "POST" : "GET", host, por_ip ? "pelo IP" : "pelo nome",
         c->sem_verificar ? ", sem verificar certificado" : "", (unsigned)r);
  fechar_pedido(c);
  return r ? r : -1;
}

static int ler_location(int req, const char *base, char *saida, size_t tam) {
  char *cabs = NULL;
  size_t n = 0;
  if(sceHttpGetAllResponseHeaders(req, &cabs, &n) || !cabs) return -1;
  for(const char *l = cabs, *fim = cabs + n; l < fim;) {
    const char *eol = memchr(l, '\n', fim - l);
    size_t t = eol ? (size_t)(eol - l) : (size_t)(fim - l);
    while(t && (l[t - 1] == '\r' || l[t - 1] == ' ')) t--;
    if(t > 9 && !strncasecmp(l, "location:", 9)) {
      const char *v = l + 9;
      size_t vt = t - 9;
      while(vt && *v == ' ') v++, vt--;
      if(!vt) return -1;
      if(*v == '/') {   /* relativo: mesmo site */
        const char *h = strstr(base, "://");
        if(!h) return -1;
        h += 3;
        size_t pre = (h - base) + strcspn(h, "/");
        snprintf(saida, tam, "%.*s%.*s", (int)pre, base, (int)vt, v);
      } else {
        snprintf(saida, tam, "%.*s", (int)vt, v);
      }
      return 0;
    }
    if(!eol) break;
    l = eol + 1;
  }
  return -1;
}

/* Abre a URL seguindo redirecionamentos (so para sites permitidos). Devolve o status HTTP, -1 (falhou) ou
   -2 (falhou na parte segura: certificado/negociacao). */
static int abrir_url(contexto_t *c, const char *url, int metodo, const void *corpo, size_t tam, int extras) {
  char atual[2048];
  snprintf(atual, sizeof atual, "%s", url);
  for(int salto = 0;; salto++) {
    if(!url_ok(atual, extras)) return -1;   /* cada salto (redirecionamento) passa pela mesma conferencia */
    char host[128];
    const char *ini = strstr(atual, "://") + 3;
    size_t n = strcspn(ini, "/:?#");
    snprintf(host, sizeof host, "%.*s", (int)(n < sizeof host ? n : sizeof host - 1), ini);
    int status = 0;
    /* pelo nome primeiro (com SNI o certificado confere com o site); pelo IP com o nosso DNS so se o nome falhar
       por outro motivo (DNS do PS5) - pelo IP o certificado nunca confere, entao so vale sem verificar. */
    int r = enviar(c, atual, metodo, corpo, tam, 0, &status);
    if(r && (!ERRO_SSL(r) || c->sem_verificar) && resolver(host) >= 0) r = enviar(c, atual, metodo, corpo, tam, 1, &status);
    if(r) return ERRO_SSL(r) ? -2 : -1;
    if(status >= 400) diario("https: %s respondeu %d", host, status);   /* ex.: 403 = o site bloqueou */
    if(status >= 300 && status < 400 && salto < MAX_REDIRECIONAR) {
      char prox[2048];
      if(!ler_location(c->req, atual, prox, sizeof prox)) {
        snprintf(atual, sizeof atual, "%s", prox);
        fechar_pedido(c);
        continue;
      }
    }
    return status;
  }
}

/* Contexto + pedido. Se a parte segura falhar com a verificacao do certificado ligada, passa (uma vez por todas)
   ao modo sem verificar e tenta de novo. O contexto fica aberto (fechar() depois). */
static int pedir_ext(contexto_t *c, const char *url, int metodo, const void *corpo, size_t tam, int extras) {
  if(abrir_contexto(c, g_sem_verificar)) return -1;
  int status = abrir_url(c, url, metodo, corpo, tam, extras);
  if(status == -2 && !c->sem_verificar) {
    if(!g_sem_verificar) diario("https: certificado nao verificado pelo PS5 - passando a aceitar sem verificar (autorizado)");
    g_sem_verificar = 1;
    fechar(c);
    if(abrir_contexto(c, 1)) return -1;
    status = abrir_url(c, url, metodo, corpo, tam, extras);
  }
  return status;
}

static int pedir(contexto_t *c, const char *url, int metodo, const void *corpo, size_t tam) {
  return pedir_ext(c, url, metodo, corpo, tam, 0);
}

/* DNS por HTTPS (0.9.16, dns_resolver.c): POST da pergunta para https://<ip>/dns-query (IP fixo; o certificado da
   Cloudflare e do Google cobre o IP). Tenta carregar as raizes embutidas (dns_ca.h) com sceHttpsLoadCert (weak) e
   verificar; se a parte segura falhar e o glibren ainda verifica certificados, desiste. No modo "sem verificar" (ja
   autorizado, ver o inicio) segue sem verificar, como os outros pedidos. Devolve o tamanho da resposta ou -1. */
int sceHttpsLoadCert(int, int, const void **, const void *, const void *) __attribute__((weak));
typedef struct {
  const char *ptr;
  size_t tam;
} dados_ssl_t;

int https_doh(const char *url, const char *nome, const char *ip, const void *pergunta, size_t n, void *resposta, size_t max) {
  static int avisado;
  if(url || !nome || !ip) return -1;
  char alvo[96];
  snprintf(alvo, sizeof alvo, "https://%s/dns-query", ip);
  contexto_t c;
  int sem = g_sem_verificar;
  if(abrir_contexto(&c, sem)) return -1;
  if(!sem && sceHttpsLoadCert) {
    dados_ssl_t ca = {DNS_CA_PEM, sizeof DNS_CA_PEM};
    const void *lista[1] = {&ca};
    int r = sceHttpsLoadCert(c.http, 1, lista, NULL, NULL);
    if(!avisado) diario("dns: raizes do DoH carregadas: 0x%08x", (unsigned)r);
  }
  int lidos = -1, status = 0, r;
  if((c.con = sceHttpCreateConnectionWithURL(c.modelo, alvo, 0)) < 0 ||
     (c.req = sceHttpCreateRequestWithURL(c.con, METODO_POST, alvo, n)) < 0) {
    r = c.con < 0 ? c.con : c.req;
  } else {
    sceHttpAddRequestHeader(c.req, "Host", nome, 0);
    sceHttpAddRequestHeader(c.req, "Content-Type", "application/dns-message", 0);
    sceHttpAddRequestHeader(c.req, "Accept", "application/dns-message", 0);
    r = sceHttpSendRequest(c.req, pergunta, n);
    if(!r) r = sceHttpGetStatusCode(c.req, &status);
    if(!r && status == 200) {
      size_t feito = 0;
      int k;
      while(feito < max && (k = sceHttpReadData(c.req, (char *)resposta + feito, max - feito)) > 0) feito += (size_t)k;
      lidos = (int)feito;
    }
  }
  if(lidos < 0 && !avisado) diario("dns: DoH %s (%s%s) falhou 0x%08x status %d", nome, ip, sem ? ", sem verificar" : "", (unsigned)r, status);
  avisado = 1;
  fechar(&c);
  return lidos;
}

int https_get(const char *url, buf_t *saida, size_t max, int segundos) {
  (void)segundos;   /* tempo limite fixo de 20 s por etapa */
  if(!url_permitida(url)) return -1;
  pthread_mutex_lock(&g_trava);
  contexto_t c;
  int status = pedir(&c, url, METODO_GET, NULL, 0);
  if(status > 0) {
    char bloco[16 * 1024];
    int n;
    while((n = sceHttpReadData(c.req, bloco, sizeof bloco)) > 0) {
      if(saida->n + n > max) {
        status = -1;
        break;
      }
      buf_add(saida, bloco, n);
    }
    if(n < 0) {
      diario("https: leitura falhou 0x%08x (%s)", (unsigned)n, url);
      status = -1;
    }
  }
  fechar(&c);
  pthread_mutex_unlock(&g_trava);
  return status;
}

int https_fluxo(const char *url, const void *corpo, size_t tam_corpo, https_recebeu_t recebeu, void *ctx) {
  if(!url_ok(url, 1)) return -1;
  /* sem a trava geral: o teste de internet usa varias conexoes ao mesmo tempo, cada uma com o seu contexto */
  contexto_t c;
  int status = pedir_ext(&c, url, corpo ? METODO_POST : METODO_GET, corpo, tam_corpo, 1);
  if(status > 0) {
    if(corpo) recebeu(NULL, tam_corpo, ctx);
    else {
      static __thread char bloco[64 * 1024];
      int n;
      while((n = sceHttpReadData(c.req, bloco, sizeof bloco)) > 0) {
        if(recebeu(bloco, n, ctx)) break;
      }
    }
  }
  fechar(&c);
  return status;
}

int https_baixar(const char *url, https_recebeu_t recebeu, void *ctx) {
  if(!url_permitida(url)) return -1;
  /* sem a trava geral: um download de varios minutos nao pode segurar os icones e a base */
  contexto_t c;
  int status = pedir(&c, url, METODO_GET, NULL, 0);   /* redirecionamentos: so para hosts permitidos */
  if(status == 200) {
    char *bloco = malloc(64 * 1024);
    int n = -1;
    while(bloco && (n = sceHttpReadData(c.req, bloco, 64 * 1024)) > 0) {
      if(recebeu(bloco, n, ctx)) break;
    }
    if(n < 0) {
      diario("https: leitura do download falhou 0x%08x (%.80s)", (unsigned)n, url);
      status = -1;
    }
    free(bloco);
  }
  fechar(&c);
  return status;
}

/* Valor do cabecalho "nome:" (sem diferenciar maiusculas) num bloco de cabecalhos. 0 = achou. */
static int cabecalho(const char *cabs, size_t n, const char *nome, char *saida, size_t tam) {
  size_t tn = strlen(nome);
  for(const char *l = cabs, *fim = cabs + n; l < fim;) {
    const char *eol = memchr(l, '\n', fim - l);
    size_t t = eol ? (size_t)(eol - l) : (size_t)(fim - l);
    while(t && (l[t - 1] == '\r' || l[t - 1] == ' ')) t--;
    if(t > tn && !strncasecmp(l, nome, tn) && l[tn] == ':') {
      const char *v = l + tn + 1;
      size_t vt = t - tn - 1;
      while(vt && *v == ' ') v++, vt--;
      snprintf(saida, tam, "%.*s", (int)vt, v);
      return 0;
    }
    if(!eol) break;
    l = eol + 1;
  }
  return -1;
}

int https_data(const char *url, char *data, size_t tam) {
  data[0] = 0;
  if(!url_permitida(url)) return -1;
  contexto_t c;
  int status = pedir(&c, url, METODO_GET, NULL, 0);
  if(status > 0) {
    char *cabs = NULL;
    size_t n = 0;
    if(sceHttpGetAllResponseHeaders(c.req, &cabs, &n) || !cabs || cabecalho(cabs, n, "date", data, tam)) status = -1;
  }
  fechar(&c);
  return status;
}

/* 0.9.21: diagnostico. PUT em https://api.github.com<caminho> (host fixo, fora da lista geral: so esta funcao fala
   com a API, sempre sem seguir redirecionamento). Pelo nome primeiro; pelo IP do DNS robusto se o nome falhar. Mesma
   regra de certificado do resto do glibren (ver o inicio): no processo elevado o PS5 recusa toda cadeia publica, entao
   na pratica vale o modo "sem verificar" ja autorizado; a chave e de escopo minimo (so o repositorio de diagnosticos). */
int https_github_put(const char *caminho, const char *token, const void *corpo, size_t n) {
  char url[1024];
  if(caminho[0] != '/' || strchr(caminho, '\'') || snprintf(url, sizeof url, "https://api.github.com%s", caminho) >= (int)sizeof url) return -1;
  for(int vez = 0; vez < 2; vez++) {
    contexto_t c;
    if(abrir_contexto(&c, g_sem_verificar)) return -1;
    int status = 0;
    int r = enviar_ext(&c, url, METODO_PUT, corpo, n, 0, &status, token);
    if(r && (!ERRO_SSL(r) || c.sem_verificar) && resolver("api.github.com") >= 0) r = enviar_ext(&c, url, METODO_PUT, corpo, n, 1, &status, token);
    if(!r) {
      char lixo[4096];
      while(sceHttpReadData(c.req, lixo, sizeof lixo) > 0) {}
      fechar(&c);
      return status;
    }
    int ssl = ERRO_SSL(r) && !c.sem_verificar;
    fechar(&c);
    if(!ssl) return -1;
    if(!g_sem_verificar) diario("https: certificado nao verificado pelo PS5 - passando a aceitar sem verificar (autorizado)");
    g_sem_verificar = 1;
  }
  return -1;
}

#else /* PC (teste no Linux/WSL): usa o curl */

void https_iniciar(void) {}

/* 0.9.16 (PC): o equivalente ao CURLOPT_RESOLVE. Para os hosts da lista do dns_resolver.c, se o DNS do sistema nao
   resolver (ou GLR_TESTE_DNS_FORCAR=1), passa "--resolve host:443:IP" ao curl com o IP do dns_resolver. */
#include <netdb.h>
#include <sys/socket.h>
static void opcao_resolve(const char *url, char *saida, size_t tam) {
  saida[0] = 0;
  const char *ini = strstr(url, "://");
  if(!ini) return;
  ini += 3;
  char host[128];
  size_t n = strcspn(ini, "/:?#");
  if(!n || n >= sizeof host) return;
  memcpy(host, ini, n);
  host[n] = 0;
  if(!dns_host_robusto(host)) return;
  if(!getenv("GLR_TESTE_DNS_FORCAR")) {
    struct addrinfo dica = {.ai_family = AF_INET, .ai_socktype = SOCK_STREAM}, *res = NULL;
    int ok = !getaddrinfo(host, NULL, &dica, &res) && res;
    if(res) freeaddrinfo(res);
    if(ok) return;
  }
  char ip[48];
  if(dns_resolver(host, ip, sizeof ip, NULL)) return;
  snprintf(saida, tam, "--resolve '%s:443:%s' ", host, ip);
  diario("https (PC): %s pelo dns_resolver (%s)", host, ip);
}

/* PC: DoH pelo curl, com as raizes embutidas (ou GLR_TESTE_DOH_CA) e o nome fixado no IP (--resolve). */
int https_doh(const char *url, const char *nome, const char *ip, const void *pergunta, size_t n, void *resposta, size_t max) {
  char ca[] = "/tmp/glr-ca-XXXXXX", q[] = "/tmp/glr-dq-XXXXXX", r[] = "/tmp/glr-dr-XXXXXX", cmd[1600], alvo[300], resolve[200] = "";
  const char *ca_teste = getenv("GLR_TESTE_DOH_CA");
  int fca = ca_teste ? -1 : mkstemp(ca), fq = mkstemp(q), fr = mkstemp(r), lidos = -1;
  if(fq < 0 || fr < 0 || (!ca_teste && fca < 0)) goto fim;
  if(!ca_teste && write(fca, DNS_CA_PEM, sizeof DNS_CA_PEM - 1) != (ssize_t)(sizeof DNS_CA_PEM - 1)) goto fim;
  if(write(fq, pergunta, n) != (ssize_t)n) goto fim;
  if(url) {
    if(strncmp(url, "https://", 8) || strchr(url, '\'')) goto fim;
    snprintf(alvo, sizeof alvo, "%s", url);
  } else {
    snprintf(alvo, sizeof alvo, "https://%s/dns-query", nome);
    snprintf(resolve, sizeof resolve, "--resolve '%s:443:%s' ", nome, ip);
  }
  snprintf(cmd, sizeof cmd, "curl -s --proto =https --max-time 4 --connect-timeout 2 %s--cacert '%s' -H 'Content-Type: application/dns-message' "
           "-H 'Accept: application/dns-message' --data-binary @'%s' -o '%s' -w '%%{http_code}' '%s'", resolve, ca_teste ? ca_teste : ca, q, r, alvo);
  FILE *p = popen(cmd, "r");
  int status = 0;
  if(p) {
    if(fscanf(p, "%d", &status) != 1) status = 0;
    pclose(p);
  }
  if(status == 200) {
    FILE *f = fopen(r, "rb");
    if(f) {
      lidos = (int)fread(resposta, 1, max, f);
      fclose(f);
    }
  }
fim:
  if(fca >= 0) close(fca), unlink(ca);
  if(fq >= 0) close(fq), unlink(q);
  if(fr >= 0) close(fr), unlink(r);
  return lidos;
}

int https_get(const char *url, buf_t *saida, size_t max, int segundos) {
  if(!url_permitida(url)) return -1;
  char tmp[] = "/tmp/glr-XXXXXX";
  int fd = mkstemp(tmp);
  if(fd < 0) return -1;
  close(fd);
  char cmd[3200], resolve[200];
  opcao_resolve(url, resolve, sizeof resolve);
  snprintf(cmd, sizeof cmd, "curl -s -L %s--max-time %d -A '%s' -o '%s' -w '%%{http_code}' '%s'", resolve, segundos, USER_AGENT, tmp, url);
  int status = -1;
  FILE *p = popen(cmd, "r");
  if(p) {
    if(fscanf(p, "%d", &status) != 1 || status == 0) status = -1;
    pclose(p);
  }
  FILE *f = fopen(tmp, "rb");
  if(f && status > 0) {
    char bloco[16 * 1024];
    size_t n;
    while((n = fread(bloco, 1, sizeof bloco, f)) > 0) {
      if(saida->n + n > max) {
        status = -1;
        break;
      }
      buf_add(saida, bloco, n);
    }
  }
  if(f) fclose(f);
  unlink(tmp);
  return status;
}

int https_fluxo(const char *url, const void *corpo, size_t tam_corpo, https_recebeu_t recebeu, void *ctx) {
  if(!url_ok(url, 1)) return -1;
  char cmd[1200], tmp[] = "/tmp/glr-up-XXXXXX";
  if(corpo) {
    int fd = mkstemp(tmp);
    if(fd < 0) return -1;
    if(write(fd, corpo, tam_corpo) != (ssize_t)tam_corpo) {
      close(fd);
      unlink(tmp);
      return -1;
    }
    close(fd);
    snprintf(cmd, sizeof cmd, "curl -s -o /dev/null --max-time 30 -w '%%{http_code}' -X POST --data-binary @'%s' '%s'", tmp, url);
  } else {
    snprintf(cmd, sizeof cmd, "curl -s --max-time 30 '%s'", url);
  }
  int status = -1;
  FILE *p = popen(cmd, "r");
  if(p) {
    if(corpo) {
      if(fscanf(p, "%d", &status) == 1 && status > 0) recebeu(NULL, tam_corpo, ctx);
    } else {
      char bloco[64 * 1024];
      size_t n;
      status = 200;
      while((n = fread(bloco, 1, sizeof bloco, p)) > 0) {
        if(recebeu(bloco, n, ctx)) break;
      }
    }
    pclose(p);
  }
  if(corpo) unlink(tmp);
  return status;
}

/* PC: o curl baixa cada salto para um arquivo temporario SEM seguir redirecionamentos; o Location e conferido
   aqui (url_permitida) antes do proximo salto, como no PS5. O corpo final e entregue em blocos. */
int https_baixar(const char *url, https_recebeu_t recebeu, void *ctx) {
  char atual[2048], prox[2048], cmd[3200], tmp[] = "/tmp/glr-dl-XXXXXX";
  snprintf(atual, sizeof atual, "%s", url);
  int fd = mkstemp(tmp);
  if(fd < 0) return -1;
  close(fd);
  int status = -1;
  for(int salto = 0; salto <= 5; salto++) {
    if(!url_permitida(atual)) {
      diario("download: endereco fora da lista recusado (%.80s)", atual);
      status = -1;
      break;
    }
    char resolve[200];
    opcao_resolve(atual, resolve, sizeof resolve);
    snprintf(cmd, sizeof cmd, "curl -s %s--max-time 900 -A '%s' -o '%s' -w '%%{http_code} %%{redirect_url}' '%s'", resolve, USER_AGENT, tmp, atual);
    FILE *p = popen(cmd, "r");
    prox[0] = 0;
    status = -1;
    if(p) {
      if(fscanf(p, "%d %2047s", &status, prox) < 1 || status == 0) status = -1;
      pclose(p);
    }
    if(status >= 300 && status < 400 && prox[0]) {
      snprintf(atual, sizeof atual, "%s", prox);
      continue;
    }
    break;
  }
  if(status == 200) {
    FILE *f = fopen(tmp, "rb");
    char bloco[64 * 1024];
    size_t n;
    while(f && (n = fread(bloco, 1, sizeof bloco, f)) > 0) {
      if(recebeu(bloco, n, ctx)) break;
    }
    if(f) fclose(f);
    else status = -1;
  }
  unlink(tmp);
  return status;
}

/* PC: curl com os cabecalhos e o corpo em arquivos temporarios 0600 (a chave nunca aparece na linha de comando).
   Nos testes, GLR_TESTE_GITHUB=http://127.0.0.1:PORTA no lugar de https://api.github.com. */
int https_github_put(const char *caminho, const char *token, const void *corpo, size_t n) {
  const char *base = "https://api.github.com", *teste = getenv("GLR_TESTE_GITHUB");
  if(teste && !strncmp(teste, "http://127.0.0.1:", 17) && !strchr(teste, '\'')) base = teste;
  if(caminho[0] != '/' || strchr(caminho, '\'')) return -1;
  /* os cabecalhos (com a chave) vao pela entrada do curl (-H @-): nada com a chave fica em disco */
  char st[] = "/tmp/glr-gh-s-XXXXXX", dados[] = "/tmp/glr-gh-d-XXXXXX", cmd[2400], resolve[200] = "";
  int fs = mkstemp(st), fd = mkstemp(dados), status = -1;
  if(fs < 0 || fd < 0 || write(fd, corpo, n) != (ssize_t)n) goto fim;
  char url[1200];
  snprintf(url, sizeof url, "%s%s", base, caminho);
  if(base != teste) opcao_resolve(url, resolve, sizeof resolve);
  snprintf(cmd, sizeof cmd, "curl -s %s--max-time 180 --max-redirs 0 -A '%s' -X PUT -H @- --data-binary @'%s' -o /dev/null -w '%%{http_code}' '%s' > '%s'",
           resolve, USER_AGENT, dados, url, st);
  FILE *p = popen(cmd, "w");
  if(p) {
    fprintf(p, "Authorization: Bearer %s\nAccept: application/vnd.github+json\nX-GitHub-Api-Version: 2022-11-28\nContent-Type: application/json\n", token);
    pclose(p);
    FILE *f = fopen(st, "r");
    if(f) {
      if(fscanf(f, "%d", &status) != 1 || status == 0) status = -1;
      fclose(f);
    }
  }
fim:
  if(fs >= 0) close(fs), unlink(st);
  if(fd >= 0) close(fd), unlink(dados);
  return status;
}

/* PC: curl -D - (so os cabecalhos). Nos testes o relogio usa um servidor local (GLR_TESTE_RELOGIO_HTTP), fora da lista. */
int https_data(const char *url, char *data, size_t tam) {
  data[0] = 0;
  const char *teste = getenv("GLR_TESTE_RELOGIO_HTTP");
  if(!url_permitida(url) && !(teste && *teste && !strcmp(url, teste))) return -1;
  char cmd[2400], linha[512];
  snprintf(cmd, sizeof cmd, "curl -s -o /dev/null -D - --max-time 8 -A '%s' '%s'", USER_AGENT, url);
  int status = -1;
  FILE *p = popen(cmd, "r");
  if(!p) return -1;
  while(fgets(linha, sizeof linha, p)) {
    size_t n = strlen(linha);
    while(n && (linha[n - 1] == '\n' || linha[n - 1] == '\r' || linha[n - 1] == ' ')) linha[--n] = 0;
    if(!strncmp(linha, "HTTP/", 5)) sscanf(strchr(linha, ' ') ? strchr(linha, ' ') : linha, "%d", &status);
    else if(!strncasecmp(linha, "date:", 5)) {
      const char *v = linha + 5;
      while(*v == ' ') v++;
      snprintf(data, tam, "%s", v);
    }
  }
  pclose(p);
  if(!data[0]) status = -1;
  return status;
}

#endif
