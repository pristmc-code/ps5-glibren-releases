/* Game Library Renamer (payload PS5) - "Enviar diagnostico" para o GitHub (0.9.21).

O jogador manda o diario e o estado do glibren sem o PC: uma chave do GitHub (fine-grained PAT so do repositorio
privado pristmc-code/ps5-diagnosticos, Contents read/write) e usada para gravar os arquivos, ja higienizados, em
glibren/<AAAA-MM-DD_HHMMSS>/ desse repositorio. A chave vem, nesta ordem: da que foi colada no glibren
(/data/glibren/diag/token, 0600) ou da que a Jobe ja guardou no mesmo console (/data/JobeesLair/diag/token, so leitura).
A chave nunca volta num GET (so "configurada, termina em ...xxxx") e nunca vai para o diario. Modelo: bg_diag.c da Jobe
(glibren.44), reescrito em C para o glibren. Reserva: o mesmo conjunto num .zip.

Rotas (api.c):
  GET  /api/diagnostico               {ok, configurada, origem, final, propria, estado, pasta, erro, http, enviados, total, em}
  POST /api/diagnostico/chave         chave=<PAT>   (pareamento + X-GLR)   400 {chave:"diag_chave_invalida"}
  POST /api/diagnostico/chave/remover               (pareamento + X-GLR)   apaga so a chave do glibren
  POST /api/diagnostico/enviar                      (pareamento + X-GLR)   400 diag_sem_chave / 409 diag_ocupado
  GET  /api/diagnostico/zip           application/zip com os mesmos arquivos (leitura livre, como o /diario) */
#pragma once

#include <stddef.h>

#include "http.h"
#include "util.h"

void diagnostico_rota_estado(pedido_t *p);
void diagnostico_rota_chave(pedido_t *p);
void diagnostico_rota_remover(pedido_t *p);
void diagnostico_rota_enviar(pedido_t *p);
void diagnostico_rota_zip(pedido_t *p);

/* Higienizacao (as regras ficam no topo de diagnostico.c). Devolve o texto limpo (malloc). */
char *diagnostico_limpar(const char *texto, size_t n, size_t *n_saida);
