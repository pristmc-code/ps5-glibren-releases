/* Game Library Renamer (payload PS5) - temperatura do SSD NVMe ligado por gaveta USB (teste).

O PS5 so da a temperatura do M.2 interno (sensor do SoC). Num SSD USB ela fica no log SMART do proprio SSD e o pedido
tem que atravessar o chip da gaveta. O Realtek RTL9210 repassa comandos NVMe de administracao pelo comando SCSI de
fabricante 0xE4 (mesmo metodo do smartmontools, "sntrealtek"): cdb[0]=0xE4, cdb[1..2]=tamanho (LE), cdb[3]=opcode
NVMe, cdb[4]=byte baixo do cdw10. Aqui so leitura: INQUIRY, LOG SENSE, Identify (0x06, cdw10=1) e Get Log Page SMART
(0x02, log 2).

Cuidados (0.9.10):
- o comando de fabricante 0xE4 so vai a aparelho que se identifica como Realtek no INQUIRY; outro chip de gaveta
  recebe so o INQUIRY e o LOG SENSE (padrao SCSI). Um 0xE4 que a ponte nao conhece pode vencer o tempo e reiniciar o
  aparelho USB, e o disco sumiria no meio de uma gravacao;
- nao le com copia/movimentacao na fila ou teste de disco rodando (quem chama confere: usb_temp_ler devolve o motivo);
- uma leitura por vez, sem segurar a trava durante os comandos (a pagina continua vendo o ultimo resultado);
- o que deu certo pelo pass* nao e repetido pelo da* (o mesmo disco);
- cada leitura comeca do zero (nada da anterior aparece ao lado do erro novo) e o resultado vai para o diario.

No PS5 o comando vai pelo CAM do FreeBSD (ioctl CAMIOCOMMAND num /dev/pass* ou /dev/da*). Se o sistema nao expuser
esses aparelhos ao payload, o resultado diz isso e lista o que existe em /dev, para a proxima tentativa.
No PC (teste) o resultado e simulado.
*/
#ifndef __PROSPERO__
#define _GNU_SOURCE   /* strcasestr na glibc (PC) */
#endif
#include "sce_prazo.h"
#include "usb_temp.h"

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <time.h>
#include <unistd.h>

#include "discos.h"
#include "plataforma.h"
#include "tarefas.h"

#ifdef __PROSPERO__
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/mount.h>
#include <sys/param.h>
#include <cam/cam.h>
#include <cam/cam_ccb.h>
#include <cam/scsi/scsi_all.h>
#include <cam/scsi/scsi_message.h>
#include <cam/scsi/scsi_pass.h>
#endif

#define MAX_TENTATIVAS 6
#define MAX_DEV 40

typedef struct {
  char dev[32];
  char inquiry[48];   /* fabricante + produto */
  char modelo[48];    /* modelo do SSD (Identify NVMe) */
  int celsius;        /* -1 = sem leitura */
  char metodo[16];    /* "rtl9210" ou "log sense" */
  char erro[96];
} tentativa_t;

typedef struct {
  time_t quando;
  int celsius;
  char montagens[400];
  char devs[400];
  char canais[400];   /* sensores do SoC canal a canal (para achar SSD interno x slot de expansao) */
  tentativa_t tent[MAX_TENTATIVAS];
  int qtd;
} leitura_t;

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static leitura_t g_ult = {.celsius = -1};   /* o ultimo resultado (o que a pagina ve) */
static leitura_t g_nova;                      /* a leitura em andamento (so uma por vez: g_lendo) */
static int g_lendo;

/* Copia texto ASCII de largura fixa sem os espacos do fim. */
__attribute__((unused)) static void texto_fixo(char *dest, size_t tam, const uint8_t *orig, size_t n) {
  size_t k = 0;
  for(size_t i = 0; i < n && k + 1 < tam; i++) dest[k++] = (orig[i] >= 32 && orig[i] < 127) ? (char)orig[i] : ' ';
  while(k && dest[k - 1] == ' ') k--;
  dest[k] = 0;
}

/* O chip da gaveta e Realtek (o unico a quem o comando de fabricante 0xE4 e mandado)? */
static int e_realtek(const char *fabricante, const char *produto) {
  return strcasestr(fabricante, "realtek") != NULL || !strncasecmp(produto, "RTL92", 5);
}

#ifdef __PROSPERO__
int sceKernelGetSocSensorTemperature(int, int *);

static int fn_canal(const void *e, void *s) {
  return sceKernelGetSocSensorTemperature(*(const int *)e, (int *)s);
}

/* Le os canais 0..15 do sensor do SoC (o glibren usa 0 = SoC e 2 = M.2; os outros ainda nao sao conhecidos).
   0.9.16: pelo watchdog (sce_prazo.c), com o mesmo nome da leitura da temperatura. */
static void ler_canais(leitura_t *l) {
  l->canais[0] = 0;
  for(int c = 0; c < 16; c++) {
    int v = -999, r = -1;
    int w = sce_com_prazo("sceKernelGetSocSensorTemperature", fn_canal, &c, sizeof c, &v, sizeof v, 800, &r);
    size_t k = strlen(l->canais);
    if(w != SCE_OK) snprintf(l->canais + k, sizeof l->canais - k, "%s%d=travou", c ? " " : "", c);
    else if(r) snprintf(l->canais + k, sizeof l->canais - k, "%s%d=erro%x", c ? " " : "", c, (unsigned)r);
    else snprintf(l->canais + k, sizeof l->canais - k, "%s%d=%d", c ? " " : "", c, v);
  }
}

/* Comando SCSI de leitura. 0 ou -1 com o motivo em erro. */
static int scsi_ler(int fd, const uint8_t *cdb, int cdb_len, uint8_t *dados, uint32_t tam, char *erro, size_t erro_tam) {
  union ccb ccb;
  memset(&ccb, 0, sizeof ccb);
  memset(dados, 0, tam);
  struct ccb_scsiio *c = &ccb.csio;
  c->ccb_h.func_code = XPT_SCSI_IO;
  c->ccb_h.flags = CAM_DIR_IN | CAM_DEV_QFRZDIS;
  c->ccb_h.retry_count = 0;
  c->ccb_h.timeout = 5000;
  c->data_ptr = dados;
  c->dxfer_len = tam;
  c->sense_len = SSD_FULL_SIZE;
  c->cdb_len = (u_int8_t)cdb_len;
  c->tag_action = MSG_SIMPLE_Q_TAG;
  memcpy(c->cdb_io.cdb_bytes, cdb, cdb_len);
  if(ioctl(fd, CAMIOCOMMAND, &ccb)) {
    snprintf(erro, erro_tam, "ioctl: %s", strerror(errno));
    return -1;
  }
  uint32_t estado = ccb.ccb_h.status & CAM_STATUS_MASK;
  if(estado != CAM_REQ_CMP) {
    snprintf(erro, erro_tam, "cam 0x%x scsi 0x%x sense %02x/%02x", estado, c->scsi_status,
             ((uint8_t *)&c->sense_data)[2] & 0x0f, ((uint8_t *)&c->sense_data)[12]);
    return -1;
  }
  return 0;
}

static void tentar(const char *nome, tentativa_t *t) {
  char caminho[48];
  memset(t, 0, sizeof *t);
  snprintf(caminho, sizeof caminho, "/dev/%s", nome);
  snprintf(t->dev, sizeof t->dev, "%s", nome);
  t->celsius = -1;
  /* pass* exige leitura+escrita para aceitar comandos; o disco da* (montado) so e aberto para leitura */
  int fd = open(caminho, strncmp(nome, "pass", 4) ? O_RDONLY : O_RDWR);
  if(fd < 0) {
    snprintf(t->erro, sizeof t->erro, "abrir: %s", strerror(errno));
    return;
  }
  static uint8_t dados[4096];   /* so uma leitura por vez (g_lendo) */
  /* 1) INQUIRY: so segue se o aparelho responde a comandos SCSI por aqui */
  uint8_t inq[6] = {0x12, 0, 0, 0, 36, 0};
  if(scsi_ler(fd, inq, 6, dados, 36, t->erro, sizeof t->erro)) {
    close(fd);
    return;
  }
  char fab[12], prod[20];
  texto_fixo(fab, sizeof fab, dados + 8, 8);
  texto_fixo(prod, sizeof prod, dados + 16, 16);
  snprintf(t->inquiry, sizeof t->inquiry, "%s %s", fab, prod);
  /* 1b) LOG SENSE pagina 0x0D (temperatura, padrao SCSI; o mesmo que o ps5upload/elf-arsenal usam): alguns chips de
     gaveta traduzem para a temperatura do SSD. Byte 9 = graus C (0xFF = sem leitura). */
  uint8_t logs[10] = {0x4D, 0, 0x40 | 0x0D, 0, 0, 0, 0, 0, 64, 0};
  char erro_log[96] = "";
  if(!scsi_ler(fd, logs, 10, dados, 64, erro_log, sizeof erro_log)) {
    if((dados[0] & 0x3f) == 0x0D && dados[9] != 0xFF && dados[9] > 0 && dados[9] < 120) {
      t->celsius = dados[9];
      snprintf(t->metodo, sizeof t->metodo, "log sense");
    } else snprintf(erro_log, sizeof erro_log, "log sense sem temperatura (pag %02x, %02x)", dados[0], dados[9]);
  }
  /* 2) e 3) so num chip Realtek: o 0xE4 e um comando de fabricante, outra ponte pode reiniciar o aparelho USB */
  if(!e_realtek(fab, prod)) {
    if(t->celsius < 0) snprintf(t->erro, sizeof t->erro, "a gaveta nao e Realtek: so o LOG SENSE (%.50s)", erro_log);
    close(fd);
    return;
  }
  /* 2) Identify NVMe pelo RTL9210 (modelo do SSD; confirma que o repasse funciona) */
  uint8_t cdb[16] = {0xE4, 0x00, 0x10, 0x06, 0x01};   /* 4096 bytes, opcode 0x06, cdw10 = 1 (controlador) */
  char erro_id[96] = "";
  if(!scsi_ler(fd, cdb, 16, dados, 4096, erro_id, sizeof erro_id)) texto_fixo(t->modelo, sizeof t->modelo, dados + 24, 40);
  /* 3) log SMART (pagina 2): bytes 1-2 = temperatura composta em kelvin */
  uint8_t smart[16] = {0xE4, 0x00, 0x02, 0x02, 0x02};  /* 512 bytes, opcode 0x02, log 2 */
  if(scsi_ler(fd, smart, 16, dados, 512, t->erro, sizeof t->erro)) {
    if(erro_id[0]) snprintf(t->erro + strlen(t->erro), sizeof t->erro - strlen(t->erro), " (identify: %.30s)", erro_id);
    if(erro_log[0]) snprintf(t->erro + strlen(t->erro), sizeof t->erro - strlen(t->erro), " (%.30s)", erro_log);
    if(t->celsius >= 0) t->erro[0] = 0;   /* o LOG SENSE ja deu a temperatura */
    close(fd);
    return;
  }
  int kelvin = dados[1] | (dados[2] << 8);
  if(kelvin > 273 && kelvin < 273 + 120) {
    t->celsius = kelvin - 273;   /* a do proprio SSD (composta) vale mais que a do LOG SENSE */
    snprintf(t->metodo, sizeof t->metodo, "rtl9210");
    t->erro[0] = 0;
  } else if(t->celsius < 0) snprintf(t->erro, sizeof t->erro, "resposta sem temperatura valida (%d K)", kelvin);
  close(fd);
}

/* Aparelhos que podem ser o disco USB: pass* (repasse do CAM) e da* sem particao. */
static int candidato(const char *n) {
  if(!strncmp(n, "pass", 4)) return n[4] >= '0' && n[4] <= '9';
  if(!strncmp(n, "da", 2) && n[2] >= '0' && n[2] <= '9') {
    for(const char *p = n + 2; *p; p++) if(*p < '0' || *p > '9') return 0;
    return 1;
  }
  return 0;
}

static void coletar(leitura_t *l) {
  /* montagens dos discos externos (de onde vem cada uma) */
  int n = getfsstat(NULL, 0, MNT_NOWAIT);
  struct statfs *lista = n > 0 ? calloc(n, sizeof *lista) : NULL;
  if(lista) {
    n = getfsstat(lista, n * sizeof *lista, MNT_NOWAIT);
    for(int i = 0; i < n; i++) {
      if(strncmp(lista[i].f_mntonname, "/mnt/usb", 8) && strncmp(lista[i].f_mntonname, "/mnt/ext", 8)) continue;
      size_t k = strlen(l->montagens);
      snprintf(l->montagens + k, sizeof l->montagens - k, "%s%s=%s(%s)", k ? " " : "", lista[i].f_mntonname,
               lista[i].f_mntfromname, lista[i].f_fstypename);
    }
    free(lista);
  }
  /* aparelhos em /dev ligados a discos */
  static const char *prefixos[] = {"da", "pass", "xpt", "umass", "ugen", "usb", "nvme", "sd", "ada", "lvd", "sbram", NULL};
  char nomes[MAX_DEV][32];
  int qtd = 0;
  DIR *d = opendir("/dev");
  struct dirent *e;
  while(d && (e = readdir(d))) {
    int casa = 0;
    for(int i = 0; prefixos[i]; i++) if(!strncmp(e->d_name, prefixos[i], strlen(prefixos[i]))) casa = 1;
    if(!casa) continue;
    size_t k = strlen(l->devs);
    snprintf(l->devs + k, sizeof l->devs - k, "%s%s", k ? " " : "", e->d_name);
    if(candidato(e->d_name) && qtd < MAX_DEV) snprintf(nomes[qtd++], sizeof nomes[0], "%s", e->d_name);
  }
  if(d) closedir(d);
  else snprintf(l->devs, sizeof l->devs, "(sem acesso a /dev: %s)", strerror(errno));
  /* pass* primeiro: e por eles que o FreeBSD aceita comandos SCSI diretos. Se um pass* ja deu a temperatura, os da*
     (o mesmo disco por outro caminho) nao recebem os comandos de novo. */
  int achou = 0;
  for(int vez = 0; vez < 2; vez++)
    for(int i = 0; i < qtd && l->qtd < MAX_TENTATIVAS; i++) {
      if((vez == 0) != !strncmp(nomes[i], "pass", 4)) continue;
      if(vez == 1 && achou) break;
      tentar(nomes[i], &l->tent[l->qtd]);
      achou |= l->tent[l->qtd].celsius >= 0;
      l->qtd++;
    }
}
#else
/* PC: resultado simulado */
static void ler_canais(leitura_t *l) {
  snprintf(l->canais, sizeof l->canais, "0=61 1=52 2=44 3=53 4=52 5=54 6=53 7=52 8=53 9=52 10=54 11=53 12=52 13=53 14=52 15=53");
}

static void coletar(leitura_t *l) {
  snprintf(l->montagens, sizeof l->montagens, "/mnt/usb0=/dev/da0s1(exfatfs)");
  snprintf(l->devs, sizeof l->devs, "da0 da0s1 pass0 xpt0");
  /* GLR_TESTE_USB_CHIP: o fabricante simulado (para testar a recusa de outra ponte); padrao Realtek */
  const char *chip = getenv("GLR_TESTE_USB_CHIP") ? getenv("GLR_TESTE_USB_CHIP") : "Realtek RTL9210 NVME";
  l->qtd = 1;
  tentativa_t *t = &l->tent[0];
  snprintf(t->dev, sizeof t->dev, "pass0");
  snprintf(t->inquiry, sizeof t->inquiry, "%s", chip);
  if(e_realtek(chip, chip)) {
    snprintf(t->modelo, sizeof t->modelo, "SSD de teste (PC)");
    t->celsius = 38 + rand() % 8;
    snprintf(t->metodo, sizeof t->metodo, "rtl9210");
  } else {
    t->celsius = -1;
    snprintf(t->erro, sizeof t->erro, "a gaveta nao e Realtek: so o LOG SENSE (log sense sem temperatura)");
  }
}
#endif

usb_temp_r usb_temp_ler(void) {
  if(tarefas_copiando()) return USB_TEMP_COPIANDO;
  if(discos_testando()) return USB_TEMP_TESTANDO;
  pthread_mutex_lock(&g_trava);
  if(g_lendo) {
    pthread_mutex_unlock(&g_trava);
    return USB_TEMP_LENDO;
  }
  g_lendo = 1;
  pthread_mutex_unlock(&g_trava);

  /* sem a trava: a pagina segue vendo o ultimo resultado enquanto os comandos rodam (ate alguns segundos) */
  memset(&g_nova, 0, sizeof g_nova);
  ler_canais(&g_nova);
  coletar(&g_nova);
  g_nova.celsius = -1;
  for(int i = 0; i < g_nova.qtd; i++) if(g_nova.tent[i].celsius > g_nova.celsius) g_nova.celsius = g_nova.tent[i].celsius;
  g_nova.quando = time(NULL);
  diario("ssd usb: %d C | montagens: %s | dev: %s | canais soc: %s", g_nova.celsius, g_nova.montagens, g_nova.devs, g_nova.canais);
  for(int i = 0; i < g_nova.qtd; i++) {
    tentativa_t *t = &g_nova.tent[i];
    diario("ssd usb: %s inquiry=[%s] modelo=[%s] temp=%d (%s) erro=[%s]", t->dev, t->inquiry, t->modelo, t->celsius, t->metodo,
           t->erro);
  }

  pthread_mutex_lock(&g_trava);
  g_ult = g_nova;
  g_lendo = 0;
  pthread_mutex_unlock(&g_trava);
  return USB_TEMP_OK;
}

const char *usb_temp_motivo(usb_temp_r r) {
  switch(r) {
  case USB_TEMP_COPIANDO: return "copiando";
  case USB_TEMP_TESTANDO: return "testando";
  case USB_TEMP_LENDO: return "lendo";
  default: return "";
  }
}

void usb_temp_json(buf_t *b) {
  pthread_mutex_lock(&g_trava);
  leitura_t *l = &g_ult;
  buf_fmt(b, "\"usb_temp\":{\"lendo\":%s,\"quando\":%lld,\"celsius\":%d,\"montagens\":", g_lendo ? "true" : "false",
          (long long)l->quando, l->celsius);
  buf_json(b, l->montagens);
  buf_str(b, ",\"canais\":");
  buf_json(b, l->canais);
  buf_str(b, ",\"dev\":");
  buf_json(b, l->devs);
  buf_str(b, ",\"tentativas\":[");
  for(int i = 0; i < l->qtd; i++) {
    tentativa_t *t = &l->tent[i];
    buf_str(b, i ? ",{\"dev\":" : "{\"dev\":");
    buf_json(b, t->dev);
    buf_str(b, ",\"inquiry\":");
    buf_json(b, t->inquiry);
    buf_str(b, ",\"modelo\":");
    buf_json(b, t->modelo);
    buf_fmt(b, ",\"celsius\":%d,\"metodo\":", t->celsius);
    buf_json(b, t->metodo);
    buf_str(b, ",\"erro\":");
    buf_json(b, t->erro);
    buf_str(b, "}");
  }
  buf_str(b, "]}");
  pthread_mutex_unlock(&g_trava);
}
