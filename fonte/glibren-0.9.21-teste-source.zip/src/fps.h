/* Game Library Renamer (payload PS5) - FPS do jogo aberto (teste), lido do contador de quadros da tela (/dev/dce).
   So le enquanto alguem pede: o primeiro pedido liga a leitura e ela para sozinha sem pedidos por ~10 s. */
#pragma once

#include "util.h"

/* {"ok":true,"lendo":..,"situacao":..,"fps":..,...}; liga a leitura se estiver parada. com_historico = pontos de 1 s. */
void fps_json(buf_t *b, int com_historico);
/* 1 = User-Agent do navegador do PS5 ("PlayStation" em qualquer caixa). A pagina de FPS e so para o celular/PC. */
int fps_agente_ps5(const char *agente);
