/* Game Library Renamer (payload PS5) - primeiro plano pelo kern.msgbuf (ver primeiro_plano.h).

No PC (testes): GLR_TESTE_MSGBUF = arquivo com o "msgbuf"; GLR_TESTE_APPIDS = "0x60000010=PPSA01234,..." (appId ->
title ID, para o titulo do foco e para o lancador). */
#include "primeiro_plano.h"

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>

#ifdef __PROSPERO__
#include <sys/sysctl.h>
#endif

#include "lancador.h"
#include "sce_prazo.h"

#define MAX_MSGBUF (512 * 1024)

/* Le o msgbuf inteiro (malloc; o chamador libera). 0 ou errno. */
static int ler_msgbuf(char **saida, size_t *n) {
  *saida = NULL;
  *n = 0;
#ifdef __PROSPERO__
  size_t tam = 0;
  if(sysctlbyname("kern.msgbuf", NULL, &tam, NULL, 0) || !tam) tam = 256 * 1024;   /* alguns kernels nao dizem o tamanho */
  if(tam > MAX_MSGBUF) tam = MAX_MSGBUF;
  char *b = malloc(tam + 1);
  if(!b) return ENOMEM;
  if(sysctlbyname("kern.msgbuf", b, &tam, NULL, 0)) {
    int e = errno ? errno : EIO;
    free(b);
    return e;
  }
#else
  const char *arq = getenv("GLR_TESTE_MSGBUF");
  if(!arq || !*arq) return ENOENT;
  FILE *f = fopen(arq, "rb");
  if(!f) return errno;
  char *b = malloc(MAX_MSGBUF + 1);
  if(!b) {
    fclose(f);
    return ENOMEM;
  }
  size_t tam = fread(b, 1, MAX_MSGBUF, f);
  fclose(f);
#endif
  b[tam] = 0;
  for(size_t i = 0; i < tam; i++) if(!b[i]) b[i] = '\n';   /* o buffer circular pode ter zeros no meio */
  *saida = b;
  *n = tam;
  return 0;
}

static void guardar_linha(char *dest, size_t tam, const char *ini, size_t n) {
  while(n && (ini[n - 1] == '\r' || ini[n - 1] == ' ')) n--;
  if(n >= tam) {   /* fica o fim da linha (onde esta o numero) */
    ini += n - (tam - 1);
    n = tam - 1;
  }
  memcpy(dest, ini, n);
  dest[n] = 0;
  for(char *c = dest; *c; c++) if((unsigned char)*c < ' ' || (unsigned char)*c > '~') *c = '?';
}

/* Numero em hexa ("0x..") ou decimal; 0 = leu. */
static int numero(const char *s, uint32_t *v) {
  char *fim;
  errno = 0;
  unsigned long x = strtoul(s, &fim, 0);
  if(errno || fim == s) return -1;
  *v = (uint32_t)x;
  return 0;
}

int primeiro_plano_ler(primeiro_plano_t *pp) {
  memset(pp, 0, sizeof *pp);
  char *b;
  size_t n;
  int e = ler_msgbuf(&b, &n);
  if(e) {
    pp->erro = e;
    return -1;
  }
  pp->lido = 1;
  pp->bytes = n;
  for(char *l = b; l < b + n;) {
    char *fim = memchr(l, '\n', (size_t)(b + n - l));
    size_t tl = fim ? (size_t)(fim - l) : (size_t)(b + n - l);
    char salvo = l[tl];
    l[tl] = 0;
    const char *p = strstr(l, "SetControllerFocus(");
    uint32_t v;
    if(p && p[19] != '-' && !numero(p + 19, &v)) {
      pp->sinal = 1;
      pp->foco = v;
      pp->focos++;
      guardar_linha(pp->linha_foco, sizeof pp->linha_foco, l, tl);
    }
    p = strstr(l, "VideoOut: shared (pid=");
    if(p) {
      uint32_t pid, app;
      const char *a = strstr(p, "appId=");
      if(!numero(p + 22, &pid) && a && !numero(a + 6, &app)) {
        pp->video = 1;
        pp->video_pid = pid;
        pp->video_appid = app;
        guardar_linha(pp->linha_video, sizeof pp->linha_video, l, tl);
      }
    }
    l[tl] = salvo;
    if(!fim) break;
    l = fim + 1;
  }
  free(b);
  return 0;
}

int primeiro_plano_foco(uint32_t *foco) {
  primeiro_plano_t pp;
  if(primeiro_plano_ler(&pp) || !pp.sinal) return 0;
  *foco = pp.foco;
  return 1;
}

#ifdef __PROSPERO__
int sceSystemServiceGetAppTitleId(int app_id, char *title_id) __attribute__((weak));

static int fn_titulo(const void *e, void *s) {
  if(!sceSystemServiceGetAppTitleId) return -1;
  return sceSystemServiceGetAppTitleId(*(const int *)e, (char *)s);
}
#endif

int primeiro_plano_titulo(uint32_t appid, char *tid, size_t tam) {
  tid[0] = 0;
  if(appid == FOCO_SISTEMA || !appid) return -1;
#ifdef __PROSPERO__
  char t[32];
  int id = (int)appid, r = -1;
  memset(t, 0, sizeof t);
  if(sce_com_prazo("sceSystemServiceGetAppTitleId", fn_titulo, &id, sizeof id, t, sizeof t, 1000, &r) != SCE_OK || r) return -1;
  t[sizeof t - 1] = 0;
  if(!titulo_valido(t)) return -1;
  snprintf(tid, tam, "%s", t);
  return 0;
#else
  const char *m = getenv("GLR_TESTE_APPIDS");
  for(const char *p = m ? m : ""; *p;) {
    uint32_t v;
    char *fim;
    v = (uint32_t)strtoul(p, &fim, 0);
    if(fim != p && *fim == '=' && v == appid) {
      char t[10];
      snprintf(t, sizeof t, "%.9s", fim + 1);
      if(titulo_valido(t)) {
        snprintf(tid, tam, "%s", t);
        return 0;
      }
    }
    p += strcspn(p, ",");
    if(*p == ',') p++;
  }
  return -1;
#endif
}

void primeiro_plano_json(buf_t *b) {
  primeiro_plano_t pp;
  primeiro_plano_ler(&pp);
  char tid[16] = "", tid_video[16] = "";
  if(pp.sinal) primeiro_plano_titulo(pp.foco, tid, sizeof tid);
  if(pp.video) primeiro_plano_titulo(pp.video_appid, tid_video, sizeof tid_video);
  buf_fmt(b, "{\"ok\":true,\"lido\":%s,\"errno\":%d,\"bytes\":%zu,\"sinal\":%s,\"focos\":%d,\"foco\":\"0x%08x\",\"foco_sistema\":%s,"
          "\"foco_tid\":", pp.lido ? "true" : "false", pp.erro, pp.bytes, pp.sinal ? "true" : "false", pp.focos, pp.foco,
          pp.sinal && pp.foco == FOCO_SISTEMA ? "true" : "false");
  buf_json(b, tid);
  buf_fmt(b, ",\"video\":%s,\"video_pid\":%u,\"video_appid\":\"0x%08x\",\"video_tid\":", pp.video ? "true" : "false", pp.video_pid,
          pp.video_appid);
  buf_json(b, tid_video);
  buf_str(b, ",\"linha_foco\":");
  buf_json(b, pp.linha_foco);
  buf_str(b, ",\"linha_video\":");
  buf_json(b, pp.linha_video);
  buf_str(b, ",");
  sce_prazo_json(b);
  buf_str(b, "}");
}
