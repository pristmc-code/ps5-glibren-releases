/* Game Library Renamer (payload PS5) - chamadas do sistema com prazo (watchdog).

Algumas funcoes do sistema (temperatura, ventoinha, LncUtil, SystemService) conversam com outros processos e, num
payload, podem responder em poucos ms ou nunca. Cada chamada roda numa thread destacada; quem chama espera ate o
prazo. Se estourar, a funcao entra na lista de "mortas" e nao e chamada de novo enquanto a chamada presa nao voltar.
Se a chamada presa voltar (atrasada), a funcao volta a valer; na 3a vez que estoura, fica morta de vez nesta sessao.
(Ideia vista no PS5-Suite de manos555555, GPL-3.0; codigo proprio, sem sigsetjmp.) */
#pragma once

#include <stddef.h>
#include "util.h"

#define SCE_PRAZO_ENTRADA 64    /* bytes copiados para a thread (a pilha de quem chama pode sumir) */
#define SCE_PRAZO_SAIDA 512     /* bytes devolvidos (a thread escreve numa copia propria) */

/* Funcao rodada na thread: le "entrada", escreve em "saida" (as duas sao copias com os tamanhos acima). */
typedef int (*sce_fn_t)(const void *entrada, void *saida);

#define SCE_OK 0
#define SCE_MORTA -1      /* ja travou antes: nao foi chamada */
#define SCE_ESTOUROU -2   /* travou agora (passou do prazo): vira morta */
#define SCE_SEM_THREAD -3

/* Chama fn com prazo (ms). SCE_OK: *ret = retorno da funcao e "saida" (n_saida bytes) preenchida. */
int sce_com_prazo(const char *nome, sce_fn_t fn, const void *entrada, size_t n_entrada, void *saida, size_t n_saida,
                  int prazo_ms, int *ret);
/* 1 se a funcao esta na lista de mortas. */
int sce_morta(const char *nome);
/* "watchdog":{"chamadas":N,"estouros":N,"mortas":["..."]} (sem chaves em volta) */
void sce_prazo_json(buf_t *b);
