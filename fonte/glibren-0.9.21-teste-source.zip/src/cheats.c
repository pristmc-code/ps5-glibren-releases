/* Game Library Renamer (payload PS5) - cheats do jogo aberto (teste). Fase 0 (0.9.17): leitura. Fase 1 (0.9.18):
ligar e desligar.

O que faz: descobre o jogo aberto e a versao dele, acha no catalogo os arquivos de cheat .json dessa versao exata,
e para cada cheat LE os bytes atuais da memoria do jogo e compara com o "off" (desligada) e o "on" (ligada) do
arquivo. Fase 1: POST /api/cheats/ligar e /desligar gravam o "on" ou os bytes originais, sempre com leitura de volta.

Regras da escrita (Fase 1, todas obrigatorias):
- ligar: os bytes atuais de TODOS os trechos tem de bater com o "off" (senao recusa com o motivo); os originais sao
  guardados em memoria e em <catalogo>/aplicadas.json ANTES de gravar; grava os trechos em ordem e le cada um de
  volta; se um falhar, desfaz os ja gravados.
- desligar: os bytes atuais tem de bater com o "on"; restaura os originais (que tem de ser iguais ao "off").
- jogo mudou (pid ou app id): as cheats ligadas viram "perdidas" e nada e gravado.
- ao fechar o glibren (/api/sair ou SIGTERM): restaura as ligadas se o jogo ainda for o mesmo.
- de fora nesta fase ("nao suportada"): code cave ("area extra": "off" todo zero), section != 0, endereco absoluto,
  trecho sem "off" e "process" diferente do eboot.bin.
- uma escrita por vez (g_trava_mem); cada acao vai para o diario ("cheats: ligou/desligou <nome> em <TID>").

Catalogo
- HEN-Cheats-Collection (TeeKay87, github.com/TeeKay87/HEN-Cheats-Collection), o mesmo que o onionHEN usa. Baixado
  como zip da branch master em codeload.github.com (POST /api/cheats/catalogo). Do zip so os .json de
  "<topo>/cheats/json/" sao extraidos, para /data/glibren/cheats/json/ (troca atomica da pasta inteira).
- Tambem le /data/OnionHEN/cheats/ (pasta plana do onionHEN) se existir; com o mesmo nome nos dois, vale o do onionHEN
  (pode ter sido editado pelo dono).
- Nome do arquivo: <TITLE_ID>_<VERSAO>[_<PROCESSO>][_<ID 8 hex>].json; a versao tem de ser IGUAL (texto) a do jogo.
  PS5: contentVersion do param.json ("01.000.002"). PS4: maior entre VERSION e APP_VER do param.sfo ("01.07").

Formato .json (conferido em arquivos reais do catalogo, 12/11/2026):
  {"name": jogo, "id": "PPSA04181", "version": "01.000.002", "process": "eboot.bin",
   "mods": [{"name": .., "description": .., "type": "checkbox",
             "memory": [{"offset": "80509753", "on": "9090..", "off": "C680..", "section": 0, "absolute": false}]}],
   "credits": [..]}
  offset = hex sem "0x", relativo a base do modulo "process" (o eboot.bin na maioria); "absolute": true = endereco
  direto. "on"/"off" = bytes em hex. "off" todo zero costuma ser "code cave" (area que o HEN cria ao ligar): antes
  disso a leitura falha ou da zeros - isso NAO quer dizer versao errada.

Como le a memoria do jogo (PS5) - ideia reescrita, sem copiar codigo, a partir de:
  ps5-payload-sdk (John Tornblom, GPL-3: crt/kernel_procio.c), ps5debug-NG (Pharaoh2k), etaHEN e onionHEN
  (aydencharles, GPL-3: source/util/source/cheats). Creditos no README.
  1. jogo: sceSystemServiceGetAppIdOfRunningBigApp (app id) + sceSystemServiceGetAppTitleId;
  2. processo: lista de processos (sysctl KERN_PROC_PROC) + sceKernelGetAppInfo(pid) com o mesmo app id (como a
     amostra "ps" do SDK); prefere o de nome "eboot.bin";
  3. base do modulo: kernel_dynlib_handle(pid, nome) + kernel_dynlib_mapbase_addr (SDK: lista de objetos em
     proc+0x3e8). Endereco = base + offset (ou o offset, se "absolute");
  4. leitura: kernel_proc_copyout(pid, endereco, ...) do SDK: tenta o mdbg (syscall 573, comando de LEITURA 0x12) e,
     se falhar, anda a tabela de paginas do processo (proc+0x200 -> vmspace -> pmap -> 4 niveis) e copia pelo DMAP
     com o kernel R/W que o elfldr entrega. Funcionou no PS5 PRO fw 12.00 (13/11/2026, Terminator 2D PPSA25872).
  5. escrita (Fase 1): kernel_proc_copyin do SDK, o par da leitura: mdbg de escrita e, se falhar (bloqueado no
     fw >= 8.40), tabela de paginas + DMAP (grava na memoria fisica, ignora a protecao da pagina). Nao usa ptrace nem
     mprotect. Leitura e escrita vao em pedacos dentro de uma pagina de 4 KB (ver pedaco()).
  Dependem do firmware (todos DENTRO do SDK v0.45, que tem tabela ate 14.xx e cobre o 12.00): offset do pmap no
  vmspace (0x2e8 no fw >= 6), proc+0x200 (vmspace), proc+0x3e8 (lista de modulos) e o numero/formato do mdbg. Neste
  arquivo nao ha offset de kernel nenhum. A confirmar no PS5 (fw 12.00): se o app id bate com o do processo, se a
  mapbase e a mesma base que os HENs usam (sections[0].vaddr), e se a leitura funciona. Tudo isso fica no diario
  (linhas "cheats:").

No PC (teste) o "jogo" e um processo chamado eboot.bin (testes/cheat_alvo.c): acha por /proc/<pid>/comm, base pela
primeira linha do modulo em /proc/<pid>/maps, le por /proc/<pid>/mem (O_RDONLY) e grava por /proc/<pid>/mem (O_RDWR,
so no modo de teste). GLR_TESTE_CHEATS_FALHAR=<endereco hex> faz a escrita nesse endereco falhar. Variaveis: GLR_TESTE_ABERTOS (jogo
aberto), GLR_TESTE_APPMETA (pasta no lugar de /user/appmeta), GLR_TESTE_CHEATS (pasta do catalogo),
GLR_TESTE_ONION (pasta do onionHEN), GLR_TESTE_CHEATS_PID (so este processo), GLR_TESTE_CHEATS_URL (zip do catalogo; servidor local via GLR_TESTE_BASE).
*/
#include "cheats.h"

#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#include "config.h"
#include "https.h"
#include "imagem.h"
#include "lancador.h"
#include "plataforma.h"
#include "zip.h"

#ifdef __PROSPERO__
#include <sys/sysctl.h>
#include <sys/user.h>
#include <ps5/kernel.h>
#endif

#define URL_CATALOGO "https://codeload.github.com/TeeKay87/HEN-Cheats-Collection/zip/refs/heads/master"
#define MAX_ZIP (256ull * 1024 * 1024)          /* o zip tinha 13,8 MB (2486 .json) em 12/11/2026 */
#define MAX_TOTAL_ZIP (2ull * 1024 * 1024 * 1024)
#define MAX_JSON (2 * 1024 * 1024)              /* um arquivo de cheat */
#define MAX_ARQUIVOS 8                          /* arquivos da mesma versao (fontes diferentes) */
#define MAX_TRECHO 4096                         /* bytes de um "on"/"off" */
#define MAX_LEITURAS 2000                       /* trechos lidos por pedido */
#define FOLGA_DISCO (300ull * 1024 * 1024)

/* ------------------------------------------------------------------ JSON (arvore pequena, so leitura) */

/* Parser JSON estrito e pequeno so para os arquivos de cheat: monta uma arvore (objetos, listas, textos, numeros,
   true/false/null) com limites de tamanho, de profundidade e de nos. Textos: escapes decodificados (\uXXXX vira
   UTF-8; \u0000 vira espaco). Liberar com jv_liberar. */
typedef enum { JV_NULO, JV_LOGICO, JV_NUMERO, JV_TEXTO, JV_LISTA, JV_OBJETO } jv_tipo_t;

typedef struct jv {
  jv_tipo_t tipo;
  char *chave;          /* dentro de objeto: o nome do campo */
  char *texto;          /* JV_TEXTO (e o numero como escrito, em JV_NUMERO) */
  int logico;
  struct jv *filho, *prox;
} jv_t;

#define JV_MAX_PROF 24
#define JV_MAX_NOS 200000

typedef struct {
  const char *p, *fim;
  int nos;
  const char *erro;
} jv_leitor_t;

static void jv_liberar(jv_t *v) {
  while(v) {
    jv_t *prox = v->prox;
    jv_liberar(v->filho);
    free(v->chave);
    free(v->texto);
    free(v);
    v = prox;
  }
}

static void jv_espacos(jv_leitor_t *l) {
  while(l->p < l->fim && (*l->p == ' ' || *l->p == '\t' || *l->p == '\n' || *l->p == '\r')) l->p++;
}

static int jv_hex4(const char *p, unsigned *v) {
  *v = 0;
  for(int i = 0; i < 4; i++) {
    char c = p[i];
    int d = c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1;
    if(d < 0) return -1;
    *v = *v * 16 + (unsigned)d;
  }
  return 0;
}

static void jv_utf8(buf_t *b, unsigned cp) {
  char s[4];
  size_t k;
  if(!cp) cp = ' ';
  if(cp < 0x80) { s[0] = (char)cp; k = 1; }
  else if(cp < 0x800) { s[0] = (char)(0xC0 | (cp >> 6)); s[1] = (char)(0x80 | (cp & 0x3F)); k = 2; }
  else if(cp < 0x10000) { s[0] = (char)(0xE0 | (cp >> 12)); s[1] = (char)(0x80 | ((cp >> 6) & 0x3F)); s[2] = (char)(0x80 | (cp & 0x3F)); k = 3; }
  else { s[0] = (char)(0xF0 | (cp >> 18)); s[1] = (char)(0x80 | ((cp >> 12) & 0x3F)); s[2] = (char)(0x80 | ((cp >> 6) & 0x3F)); s[3] = (char)(0x80 | (cp & 0x3F)); k = 4; }
  buf_add(b, s, k);
}

/* Le um texto entre aspas (l->p no '"'); devolve malloc ou NULL. */
static char *jv_texto(jv_leitor_t *l) {
  buf_t b = {0};
  l->p++;
  while(l->p < l->fim && *l->p != '"') {
    unsigned char c = (unsigned char)*l->p;
    if(c < 0x20) { l->erro = "caractere de controle dentro de texto"; buf_free(&b); return NULL; }
    if(c != '\\') { buf_add(&b, l->p++, 1); continue; }
    if(l->fim - l->p < 2) break;
    char e = l->p[1];
    l->p += 2;
    switch(e) {
    case '"': buf_add(&b, "\"", 1); break;
    case '\\': buf_add(&b, "\\", 1); break;
    case '/': buf_add(&b, "/", 1); break;
    case 'b': case 'f': case 'n': case 'r': case 't': buf_add(&b, " ", 1); break;
    case 'u': {
      unsigned cp, baixo;
      if(l->fim - l->p < 4 || jv_hex4(l->p, &cp)) { l->erro = "escape \\u invalido"; buf_free(&b); return NULL; }
      l->p += 4;
      if(cp >= 0xD800 && cp <= 0xDBFF && l->fim - l->p >= 6 && l->p[0] == '\\' && l->p[1] == 'u' && !jv_hex4(l->p + 2, &baixo) &&
         baixo >= 0xDC00 && baixo <= 0xDFFF) {
        cp = 0x10000 + ((cp - 0xD800) << 10) + (baixo - 0xDC00);
        l->p += 6;
      } else if(cp >= 0xD800 && cp <= 0xDFFF) cp = 0xFFFD;
      jv_utf8(&b, cp);
      break;
    }
    default: l->erro = "escape invalido"; buf_free(&b); return NULL;
    }
  }
  if(l->p >= l->fim) { l->erro = "texto sem fim"; buf_free(&b); return NULL; }
  l->p++;
  if(!b.d) buf_add(&b, "", 0);
  return b.d;
}

static jv_t *jv_valor(jv_leitor_t *l, int prof);

static jv_t *jv_novo(jv_leitor_t *l, jv_tipo_t tipo) {
  if(++l->nos > JV_MAX_NOS) { l->erro = "JSON grande demais"; return NULL; }
  jv_t *v = calloc(1, sizeof *v);
  if(!v) { l->erro = "sem memoria"; return NULL; }
  v->tipo = tipo;
  return v;
}

static jv_t *jv_composto(jv_leitor_t *l, int prof, int objeto) {
  jv_t *v = jv_novo(l, objeto ? JV_OBJETO : JV_LISTA), **ultimo;
  if(!v) return NULL;
  ultimo = &v->filho;
  l->p++;
  jv_espacos(l);
  if(l->p < l->fim && *l->p == (objeto ? '}' : ']')) { l->p++; return v; }
  for(;;) {
    char *chave = NULL;
    jv_espacos(l);
    if(objeto) {
      if(l->p >= l->fim || *l->p != '"') { l->erro = "esperava o nome de um campo"; goto falha; }
      if(!(chave = jv_texto(l))) goto falha;
      jv_espacos(l);
      if(l->p >= l->fim || *l->p != ':') { free(chave); l->erro = "esperava ':'"; goto falha; }
      l->p++;
    }
    jv_t *f = jv_valor(l, prof + 1);
    if(!f) { free(chave); goto falha; }
    f->chave = chave;
    *ultimo = f;
    ultimo = &f->prox;
    jv_espacos(l);
    if(l->p < l->fim && *l->p == ',') { l->p++; continue; }
    if(l->p < l->fim && *l->p == (objeto ? '}' : ']')) { l->p++; return v; }
    l->erro = objeto ? "esperava ',' ou '}'" : "esperava ',' ou ']'";
    goto falha;
  }
falha:
  jv_liberar(v);
  return NULL;
}

static jv_t *jv_valor(jv_leitor_t *l, int prof) {
  if(prof > JV_MAX_PROF) { l->erro = "JSON fundo demais"; return NULL; }
  jv_espacos(l);
  if(l->p >= l->fim) { l->erro = "fim inesperado"; return NULL; }
  char c = *l->p;
  if(c == '{' || c == '[') return jv_composto(l, prof, c == '{');
  if(c == '"') {
    char *s = jv_texto(l);
    if(!s) return NULL;
    jv_t *v = jv_novo(l, JV_TEXTO);
    if(!v) { free(s); return NULL; }
    v->texto = s;
    return v;
  }
  static const struct { const char *s; jv_tipo_t t; int b; } PAL[] = {{"true", JV_LOGICO, 1}, {"false", JV_LOGICO, 0}, {"null", JV_NULO, 0}};
  for(size_t i = 0; i < sizeof PAL / sizeof PAL[0]; i++) {
    size_t n = strlen(PAL[i].s);
    if((size_t)(l->fim - l->p) >= n && !memcmp(l->p, PAL[i].s, n)) {
      l->p += n;
      jv_t *v = jv_novo(l, PAL[i].t);
      if(v) v->logico = PAL[i].b;
      return v;
    }
  }
  if(c == '-' || (c >= '0' && c <= '9')) {
    const char *ini = l->p;
    if(*l->p == '-') l->p++;
    while(l->p < l->fim && strchr("0123456789.eE+-", *l->p)) l->p++;
    jv_t *v = jv_novo(l, JV_NUMERO);
    if(!v) return NULL;
    v->texto = strndup(ini, (size_t)(l->p - ini));
    if(!v->texto) { free(v); l->erro = "sem memoria"; return NULL; }
    return v;
  }
  l->erro = "valor invalido";
  return NULL;
}

/* Documento inteiro (com BOM UTF-8 opcional). NULL se invalido (erro recebe o motivo). */
static jv_t *jv_ler(const char *dados, size_t n, const char **erro) {
  jv_leitor_t l = {dados, dados + n, 0, NULL};
  if(n >= 3 && !memcmp(dados, "\xEF\xBB\xBF", 3)) l.p += 3;
  jv_t *v = jv_valor(&l, 0);
  if(v) {
    jv_espacos(&l);
    if(l.p != l.fim) { jv_liberar(v); v = NULL; l.erro = "sobra depois do JSON"; }
  }
  if(erro) *erro = l.erro ? l.erro : "";
  return v;
}

/* Campo de um objeto (nome sem diferenciar maiusculas: os arquivos da comunidade variam "Offset"/"offset"). */
static const jv_t *jv_campo(const jv_t *o, const char *nome) {
  if(!o || o->tipo != JV_OBJETO) return NULL;
  for(const jv_t *f = o->filho; f; f = f->prox)
    if(f->chave && !strcasecmp(f->chave, nome)) return f;
  return NULL;
}

/* Texto de um campo (numero tambem vale, como escrito); "" se nao tiver. */
static const char *jv_txt(const jv_t *o, const char *nome) {
  const jv_t *f = jv_campo(o, nome);
  return f && (f->tipo == JV_TEXTO || f->tipo == JV_NUMERO) ? f->texto : "";
}

/* ------------------------------------------------------------------ pastas */

static void pasta_catalogo(char *s, size_t tam) {
#ifdef __PROSPERO__
  snprintf(s, tam, "/data/glibren/cheats");
#else
  const char *e = getenv("GLR_TESTE_CHEATS");
  if(e && *e) snprintf(s, tam, "%s", e);
  else snprintf(s, tam, "%s/cheats", g_pasta_dados);
#endif
}

static const char *pasta_onion(void) {
#ifdef __PROSPERO__
  return "/data/OnionHEN/cheats";
#else
  const char *e = getenv("GLR_TESTE_ONION");
  return e && *e ? e : "/nao-existe";
#endif
}

static int ler_arquivo(const char *caminho, buf_t *b, size_t max) {
  FILE *f = fopen(caminho, "rb");
  if(!f) return -1;
  char bloco[16384];
  size_t n;
  int r = 0;
  while((n = fread(bloco, 1, sizeof bloco, f)) > 0) {
    if(b->n + n > max) { r = -1; break; }
    buf_add(b, bloco, n);
  }
  fclose(f);
  if(!r && !b->d) buf_add(b, "", 0);
  return r;
}

/* ------------------------------------------------------------------ jogo aberto e versao */

#ifdef __PROSPERO__
int sceSystemServiceGetAppIdOfRunningBigApp(void) __attribute__((weak));
int sceSystemServiceGetAppTitleId(int app_id, char *title_id) __attribute__((weak));
#endif

typedef struct {
  char tid[16];
  int app_id;          /* -1 = nao sabe (PC ou funcao ausente) */
  char tipo[16];       /* ps5, ps4, menu, desconhecido */
  char nome[256];
  char versao[32];     /* contentVersion (PS5) ou VERSION/APP_VER (PS4) */
  char versao_de[24];  /* de onde veio (campo) */
  char mestre[32];     /* masterVersion (so informativo) */
} jogo_t;

static void jogo_aberto(jogo_t *j) {
  memset(j, 0, sizeof *j);
  j->app_id = -1;
  int sabe = 0;
#ifdef __PROSPERO__
  if(sceSystemServiceGetAppIdOfRunningBigApp && sceSystemServiceGetAppTitleId) {
    int id = sceSystemServiceGetAppIdOfRunningBigApp();
    sabe = 1;
    if(id >= 0) {
      char t[32];
      memset(t, 0, sizeof t);
      if(!sceSystemServiceGetAppTitleId(id, t)) {
        t[sizeof t - 1] = 0;
        snprintf(j->tid, sizeof j->tid, "%s", t);
        j->app_id = id;
      } else sabe = 0;
    }
  }
#endif
  if(!sabe) sabe = app_de_jogo_aberto(j->tid, sizeof j->tid) >= 0;
  const char *t = j->tid;
  if(!sabe) snprintf(j->tipo, sizeof j->tipo, "desconhecido");
  else if(!t[0] || !titulo_valido(t) || !strncmp(t, "NPXS", 4) || !strcmp(t, GLIBREN_TITLE_ID)) snprintf(j->tipo, sizeof j->tipo, "menu");
  else if(!strncmp(t, "CUSA", 4)) snprintf(j->tipo, sizeof j->tipo, "ps4");
  else snprintf(j->tipo, sizeof j->tipo, "ps5");
}

static const char *pasta_appmeta(void) {
#ifdef __PROSPERO__
  return "/user/appmeta";
#else
  const char *e = getenv("GLR_TESTE_APPMETA");
  return e && *e ? e : "/nao-existe";
#endif
}

/* Versao de jogo: so digitos e pontos (vai para nome de arquivo e para a tela). */
static int versao_valida(const char *v) {
  if(!*v || strlen(v) > 20) return 0;
  for(; *v; v++)
    if(!isdigit((unsigned char)*v) && *v != '.') return 0;
  return 1;
}

static uint32_t le32(const unsigned char *p) {
  return p[0] | p[1] << 8 | p[2] << 16 | (uint32_t)p[3] << 24;
}

/* PS4: VERSION e APP_VER do param.sfo (formato em fmt_param.c). Fica com o maior (como o onionHEN). */
static int sfo_versao(const unsigned char *d, size_t n, char *saida, size_t tam, char *campo, size_t tam_campo) {
  if(n >= 0x800 + 0x14 && !memcmp(d, "SCEC", 4)) { d += 0x800; n -= 0x800; }
  if(n < 0x14 || memcmp(d, "\0PSF", 4)) return -1;
  uint32_t chaves = le32(d + 8), dados = le32(d + 12), qtd = le32(d + 16);
  if(qtd > 1000 || 0x14 + (size_t)qtd * 16 > n || chaves >= n || dados >= n) return -1;
  saida[0] = campo[0] = 0;
  for(uint32_t i = 0; i < qtd; i++) {
    const unsigned char *it = d + 0x14 + i * 16;
    uint32_t k = it[0] | it[1] << 8, fmt = it[2] | it[3] << 8, len = le32(it + 4), off = le32(it + 12);
    if((size_t)chaves + k >= n || (fmt & 0xff) != 4 || (size_t)dados + off + len > n || len == 0 || len > 31) continue;
    const char *nome = (const char *)d + chaves + k;
    if(strnlen(nome, n - chaves - k) == n - chaves - k) continue;
    if(strcmp(nome, "VERSION") && strcmp(nome, "APP_VER")) continue;
    char v[32];
    memcpy(v, d + dados + off, len);
    v[len] = 0;
    if(!versao_valida(v)) continue;
    if(!saida[0] || strcmp(v, saida) > 0) {
      snprintf(saida, tam, "%s", v);
      snprintf(campo, tam_campo, "%s", nome);
    }
  }
  return saida[0] ? 0 : -1;
}

/* Nome e versao pelo param.json (PS5) ou param.sfo (PS4) do jogo instalado. Caminhos na ordem do onionHEN/etaHEN. */
static void jogo_versao(jogo_t *j) {
  if(strcmp(j->tipo, "ps5") && strcmp(j->tipo, "ps4")) return;
  static char pastas[MAX_PASTAS][1024];
  static pthread_mutex_t trava = PTHREAD_MUTEX_INITIALIZER;
  char caminhos[6][320], idioma[16] = "pt-BR";
  pthread_mutex_lock(&trava);
  config_ler(pastas, idioma);
  pthread_mutex_unlock(&trava);
  int ps4 = !strcmp(j->tipo, "ps4");
  const char *arq = ps4 ? "param.sfo" : "param.json";
  int n = 0;
  snprintf(caminhos[n++], sizeof caminhos[0], "%s/%s/%s", pasta_appmeta(), j->tid, arq);
#ifdef __PROSPERO__
  snprintf(caminhos[n++], sizeof caminhos[0], "/system_data/priv/appmeta/%s/%s", j->tid, arq);
  snprintf(caminhos[n++], sizeof caminhos[0], "/system_data/priv/appmeta/external/%s/%s", j->tid, arq);
  snprintf(caminhos[n++], sizeof caminhos[0], "/system_ex/app/%s/sce_sys/%s", j->tid, arq);
  snprintf(caminhos[n++], sizeof caminhos[0], "/user/app/%s/sce_sys/%s", j->tid, arq);
#endif
  for(int i = 0; i < n && !j->versao[0]; i++) {
    buf_t b = {0};
    if(ler_arquivo(caminhos[i], &b, 1024 * 1024)) { buf_free(&b); continue; }
    info_jogo_t info;
    memset(&info, 0, sizeof info);
    if(ps4) {
      if(!param_sfo_ler(b.d, b.n, idioma, &info) && !j->nome[0]) snprintf(j->nome, sizeof j->nome, "%s", info.nome);
      sfo_versao((const unsigned char *)b.d, b.n, j->versao, sizeof j->versao, j->versao_de, sizeof j->versao_de);
    } else {
      if(!param_json_ler(b.d, b.n, idioma, &info) && !j->nome[0]) snprintf(j->nome, sizeof j->nome, "%s", info.nome);
      jv_t *r = jv_ler(b.d, b.n, NULL);
      static const char *CAMPOS[] = {"contentVersion", "content_version", "titleVersion", "version", "APP_VER", NULL};
      for(int c = 0; r && CAMPOS[c] && !j->versao[0]; c++) {
        const char *v = jv_txt(r, CAMPOS[c]);
        if(versao_valida(v)) {
          snprintf(j->versao, sizeof j->versao, "%s", v);
          snprintf(j->versao_de, sizeof j->versao_de, "%s", CAMPOS[c]);
        }
      }
      if(r && versao_valida(jv_txt(r, "masterVersion"))) snprintf(j->mestre, sizeof j->mestre, "%s", jv_txt(r, "masterVersion"));
      jv_liberar(r);
    }
    buf_free(&b);
  }
  for(char *c = j->nome; *c; c++) if((unsigned char)*c < ' ') *c = ' ';
}

/* ------------------------------------------------------------------ catalogo (download) */

static pthread_mutex_t g_trava_cat = PTHREAD_MUTEX_INITIALIZER;
static char g_cat_estado[16] = "parado";   /* parado, baixando, extraindo, pronto, erro */
static char g_cat_erro[200];
static unsigned long long g_cat_bytes;

static void cat_estado(const char *estado, const char *erro) {
  pthread_mutex_lock(&g_trava_cat);
  snprintf(g_cat_estado, sizeof g_cat_estado, "%s", estado);
  snprintf(g_cat_erro, sizeof g_cat_erro, "%s", erro ? erro : "");
  pthread_mutex_unlock(&g_trava_cat);
}

/* Apaga uma pasta so com arquivos (a pasta json/ do catalogo). Ignora o que nao existe. */
static void apagar_pasta_plana(const char *pasta) {
  DIR *d = opendir(pasta);
  if(d) {
    struct dirent *e;
    char c[1024];
    while((e = readdir(d))) {
      if(!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
      snprintf(c, sizeof c, "%s/%s", pasta, e->d_name);
      unlink(c);
    }
    closedir(d);
  }
  rmdir(pasta);
}

typedef struct {
  int fd;
  unsigned long long n;
  int excedeu, erro;
} baixando_t;

static int recebeu_zip(const void *dados, size_t n, void *ctx) {
  baixando_t *b = ctx;
  if(b->n + n > MAX_ZIP) { b->excedeu = 1; return 1; }
  const char *p = dados;
  size_t feito = 0;
  while(feito < n) {
    ssize_t w = write(b->fd, p + feito, n - feito);
    if(w <= 0) { b->erro = 1; return 1; }
    feito += (size_t)w;
  }
  b->n += n;
  pthread_mutex_lock(&g_trava_cat);
  g_cat_bytes = b->n;
  pthread_mutex_unlock(&g_trava_cat);
  return 0;
}

/* "<topo>/cheats/json/<arquivo>.json" (ou sem a pasta de topo): devolve o nome do arquivo, senao NULL. */
static const char *json_do_catalogo(const char *nome) {
  const char *m = strstr(nome, "cheats/json/");
  if(!m) return NULL;
  if(m != nome) {   /* antes: uma unica pasta de topo */
    const char *barra = strchr(nome, '/');
    if(!barra || barra + 1 != m) return NULL;
  }
  const char *arq = m + 12;
  size_t n = strlen(arq);
  if(n < 6 || n > 200 || strchr(arq, '/') || strcasecmp(arq + n - 5, ".json") || !nome_valido(arq) || arq[0] == '.') return NULL;
  return arq;
}

static void *baixar_catalogo(void *arg) {
  (void)arg;
  char pasta[512], parcial[600], novo[600], atual[600], antigo[600], info[600], erro[200] = "";
  pasta_catalogo(pasta, sizeof pasta);
  snprintf(parcial, sizeof parcial, "%s/.catalogo.zip.parcial", pasta);
  snprintf(novo, sizeof novo, "%s/json.novo", pasta);
  snprintf(atual, sizeof atual, "%s/json", pasta);
  snprintf(antigo, sizeof antigo, "%s/json.antigo", pasta);
  snprintf(info, sizeof info, "%s/catalogo.txt", pasta);
  const char *url = URL_CATALOGO;
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_CHEATS_URL")) url = getenv("GLR_TESTE_CHEATS_URL");
#endif
  zip_t z;
  memset(&z, 0, sizeof z);
  z.fd = -1;
  int abriu_zip = 0, qtd = 0;
  baixando_t b = {-1, 0, 0, 0};
  struct statvfs sv;
  if(mkdir_p(pasta)) { snprintf(erro, sizeof erro, "nao criou %s (errno %d)", pasta, errno); goto fim; }
  if(!statvfs(pasta, &sv) && (unsigned long long)sv.f_bavail * sv.f_frsize < FOLGA_DISCO) {
    snprintf(erro, sizeof erro, "pouco espaco livre no PS5 (%llu MB)", (unsigned long long)sv.f_bavail * sv.f_frsize / (1024 * 1024));
    goto fim;
  }
  diario("cheats: baixando o catalogo (%s)", url);
  unlink(parcial);
  if((b.fd = open(parcial, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644)) < 0) {
    snprintf(erro, sizeof erro, "nao criou o arquivo do download (errno %d)", errno);
    goto fim;
  }
  int status = https_baixar(url, recebeu_zip, &b);
  int fechou = close(b.fd);
  diario("cheats: catalogo: status %d, %llu bytes", status, b.n);
  if(status != 200 || b.excedeu || b.erro || fechou) {
    if(status != 200) snprintf(erro, sizeof erro, "nao baixou o catalogo (HTTP %d)", status);
    else if(b.excedeu) snprintf(erro, sizeof erro, "catalogo maior que o limite");
    else snprintf(erro, sizeof erro, "erro ao gravar o download");
    goto fim;
  }
  cat_estado("extraindo", NULL);
  char ezip[160] = "";
  if(zip_abrir(&z, parcial, MAX_TOTAL_ZIP, ezip, sizeof ezip)) {
    snprintf(erro, sizeof erro, "zip recusado: %s", ezip);
    goto fim;
  }
  abriu_zip = 1;
  apagar_pasta_plana(novo);
  if(mkdir(novo, 0777)) { snprintf(erro, sizeof erro, "nao criou %s (errno %d)", novo, errno); goto fim; }
  for(uint32_t i = 0; i < z.n; i++) {
    const zip_entrada_t *e = &z.e[i];
    const char *arq = e->pasta ? NULL : json_do_catalogo(e->nome);
    if(!arq || e->tam > MAX_JSON) continue;
    buf_t j = {0};
    char e2[160], destino[1024];
    if(zip_ler(&z, e, &j, MAX_JSON, e2, sizeof e2)) {
      diario("cheats: catalogo: %s pulado (%s)", arq, e2);
      buf_free(&j);
      continue;
    }
    snprintf(destino, sizeof destino, "%s/%s", novo, arq);
    int fd = open(destino, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644);
    int ok = fd >= 0 && write(fd, j.d ? j.d : "", j.n) == (ssize_t)j.n;
    if(fd >= 0 && close(fd)) ok = 0;
    buf_free(&j);
    if(!ok) { snprintf(erro, sizeof erro, "erro ao gravar %.100s (errno %d)", arq, errno); goto fim; }
    qtd++;
  }
  if(!qtd) { snprintf(erro, sizeof erro, "o zip nao tem cheats/json/*.json"); goto fim; }
  /* troca a pasta inteira: json -> json.antigo, json.novo -> json */
  apagar_pasta_plana(antigo);
  if(rename(atual, antigo) && errno != ENOENT) { snprintf(erro, sizeof erro, "nao trocou a pasta (errno %d)", errno); goto fim; }
  if(rename(novo, atual)) {
    snprintf(erro, sizeof erro, "nao trocou a pasta (errno %d)", errno);
    rename(antigo, atual);
    goto fim;
  }
  apagar_pasta_plana(antigo);
  FILE *f = fopen(info, "w");
  if(f) {
    fprintf(f, "quando=%lld\narquivos=%d\nbytes=%llu\n", (long long)time(NULL), qtd, b.n);
    fclose(f);
  }
fim:
  if(abriu_zip) zip_fechar(&z);
  unlink(parcial);
  if(erro[0]) {
    apagar_pasta_plana(novo);
    diario("cheats: catalogo: %s", erro);
    cat_estado("erro", erro);
  } else {
    diario("cheats: catalogo pronto: %d arquivos .json", qtd);
    cat_estado("pronto", NULL);
  }
  return NULL;
}

int cheats_catalogo_baixar(char *msg, size_t tam) {
  pthread_mutex_lock(&g_trava_cat);
  int ocupado = !strcmp(g_cat_estado, "baixando") || !strcmp(g_cat_estado, "extraindo");
  if(!ocupado) {
    snprintf(g_cat_estado, sizeof g_cat_estado, "baixando");
    g_cat_erro[0] = 0;
    g_cat_bytes = 0;
  }
  pthread_mutex_unlock(&g_trava_cat);
  if(ocupado) { snprintf(msg, tam, "o catalogo ja esta sendo baixado"); return -1; }
  if(criar_thread(baixar_catalogo, NULL, NULL)) {
    cat_estado("erro", "nao criou a thread do download");
    snprintf(msg, tam, "nao criou a thread do download");
    return -1;
  }
  msg[0] = 0;
  return 0;
}

static void catalogo_json(buf_t *b) {
  char pasta[512], info[600], linha[128];
  pasta_catalogo(pasta, sizeof pasta);
  snprintf(info, sizeof info, "%s/catalogo.txt", pasta);
  long long quando = 0;
  int arquivos = 0;
  FILE *f = fopen(info, "r");
  while(f && fgets(linha, sizeof linha, f)) {
    if(!strncmp(linha, "quando=", 7)) quando = atoll(linha + 7);
    else if(!strncmp(linha, "arquivos=", 9)) arquivos = atoi(linha + 9);
  }
  if(f) fclose(f);
  struct stat st;
  int onion = !stat(pasta_onion(), &st) && S_ISDIR(st.st_mode);
  pthread_mutex_lock(&g_trava_cat);
  buf_str(b, "\"catalogo\":{\"estado\":");
  buf_json(b, g_cat_estado);
  buf_str(b, ",\"erro\":");
  buf_json(b, g_cat_erro);
  buf_fmt(b, ",\"bytes\":%llu,\"quando\":%lld,\"arquivos\":%d,\"onion\":%s}", g_cat_bytes, quando, arquivos, onion ? "true" : "false");
  pthread_mutex_unlock(&g_trava_cat);
}

/* ------------------------------------------------------------------ escolha dos arquivos */

typedef struct {
  char caminho[700];
  char nome[256];
  const char *origem;   /* "onionhen" ou "catalogo" */
} arquivo_t;

/* Nome "<TID>_<VERSAO>" seguido de "_" ou de ".json" (sem diferenciar maiusculas no Title ID e na extensao). */
static int nome_combina(const char *nome, const char *tid, const char *versao) {
  size_t nt = strlen(tid), nv = strlen(versao), n = strlen(nome);
  if(!nt || !nv || n < 6 || strcasecmp(nome + n - 5, ".json")) return 0;
  if(strncasecmp(nome, tid, nt) || nome[nt] != '_' || strncmp(nome + nt + 1, versao, nv)) return 0;
  const char *depois = nome + nt + 1 + nv;
  return *depois == '_' || depois == nome + n - 5;
}

static int cmp_arquivo(const void *a, const void *b) {
  return strcmp(((const arquivo_t *)a)->nome, ((const arquivo_t *)b)->nome);
}

static int achar_arquivos(const jogo_t *j, arquivo_t *lista, int max) {
  int n = 0;
  char cat[512], pj[600];
  pasta_catalogo(cat, sizeof cat);
  snprintf(pj, sizeof pj, "%s/json", cat);
  const char *pastas[2] = {pasta_onion(), pj};
  const char *origens[2] = {"onionhen", "catalogo"};
  for(int p = 0; p < 2; p++) {
    DIR *d = opendir(pastas[p]);
    if(!d) continue;
    struct dirent *e;
    int inicio = n;
    while((e = readdir(d)) && n < max) {
      if(!nome_combina(e->d_name, j->tid, j->versao) || strlen(e->d_name) >= sizeof lista[0].nome) continue;
      int repetido = 0;
      for(int i = 0; i < inicio && !repetido; i++) repetido = !strcasecmp(lista[i].nome, e->d_name);
      if(repetido) continue;
      snprintf(lista[n].caminho, sizeof lista[n].caminho, "%s/%s", pastas[p], e->d_name);
      snprintf(lista[n].nome, sizeof lista[n].nome, "%s", e->d_name);
      lista[n].origem = origens[p];
      n++;
    }
    closedir(d);
    qsort(lista + inicio, (size_t)(n - inicio), sizeof lista[0], cmp_arquivo);
  }
  return n;
}

/* ------------------------------------------------------------------ memoria do jogo (leitura e escrita) */

static int digito_hex(int c) {
  return c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1;
}

/* "C6 80 cc 00" -> bytes. -1 se nao for hex par ou passar de max. */
static int hex_bytes(const char *s, unsigned char *saida, size_t max) {
  size_t n = 0;
  int alto = -1;
  for(; *s; s++) {
    if(*s == ' ' || *s == '\t') continue;
    int d = digito_hex(*s);
    if(d < 0) return -1;
    if(alto < 0) { alto = d; continue; }
    if(n == max) return -1;
    saida[n++] = (unsigned char)(alto << 4 | d);
    alto = -1;
  }
  return alto >= 0 ? -1 : (int)n;
}

/* Offset em hex (com ou sem 0x). -1 se invalido. */
static int hex_offset(const char *s, uint64_t *v) {
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) s += 2;
  if(!*s || strlen(s) > 16) return -1;
  *v = 0;
  for(; *s; s++) {
    int d = digito_hex(*s);
    if(d < 0) return -1;
    *v = *v << 4 | (uint64_t)d;
  }
  return 0;
}

static const char *base_nome(const char *caminho) {
  const char *b = strrchr(caminho, '/');
  return b ? b + 1 : caminho;
}

#define MAX_PIDS 8
#define PAGINA 4096ull

typedef struct {
  int pids[MAX_PIDS];
  int n;
  char comm[MAX_PIDS][24];
} processos_t;

#ifdef __PROSPERO__
/* Mesmo layout da amostra "ps" do ps5-payload-sdk (sceKernelGetAppInfo). */
typedef struct {
  uint32_t app_id;
  uint64_t desconhecido1;
  uint32_t app_type;
  char title_id[10];
  char desconhecido2[0x3c];
} app_info_t;
int sceKernelGetAppInfo(pid_t pid, app_info_t *info) __attribute__((weak));

/* Processos do jogo aberto: mesmo app id (ou, sem app id, mesmo Title ID). O "eboot.bin" fica primeiro. */
static void processos_do_jogo(const jogo_t *j, processos_t *pr) {
  pr->n = 0;
  if(!sceKernelGetAppInfo) return;
  int mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_PROC, 0};
  size_t tam = 0;
  if(sysctl(mib, 4, NULL, &tam, NULL, 0) || !tam) return;
  tam += 16 * sizeof(struct kinfo_proc);
  char *lista = malloc(tam);
  if(!lista) return;
  if(sysctl(mib, 4, lista, &tam, NULL, 0)) { free(lista); return; }
  for(char *p = lista; p + sizeof(int) <= lista + tam;) {
    struct kinfo_proc *ki = (struct kinfo_proc *)p;
    if(ki->ki_structsize <= 0) break;
    p += ki->ki_structsize;
    app_info_t ai;
    memset(&ai, 0, sizeof ai);
    if(sceKernelGetAppInfo(ki->ki_pid, &ai)) continue;
    ai.title_id[sizeof ai.title_id - 1] = 0;
    int mesmo = j->app_id >= 0 ? (int)ai.app_id == j->app_id : !strncmp(ai.title_id, j->tid, 9);
    if(!mesmo || pr->n == MAX_PIDS) continue;
    int i = pr->n++;
    if(!strcmp(ki->ki_comm, "eboot.bin") && i) {   /* eboot primeiro */
      pr->pids[i] = pr->pids[0];
      memcpy(pr->comm[i], pr->comm[0], sizeof pr->comm[0]);
      i = 0;
    }
    pr->pids[i] = ki->ki_pid;
    snprintf(pr->comm[i], sizeof pr->comm[i], "%s", ki->ki_comm);
  }
  free(lista);
}

/* Base do modulo (ex.: "eboot.bin") no processo. 0 = achou. */
static int base_do_modulo(int pid, const char *modulo, uint64_t *base) {
  uint32_t h = 0;
  if(kernel_dynlib_handle(pid, modulo, &h)) return -1;
  intptr_t b = kernel_dynlib_mapbase_addr(pid, h);
  if(!b || b == -1) return -1;
  *base = (uint64_t)b;
  return 0;
}

/* Tamanho do pedaco que fica dentro da pagina de 4 KB do endereco. O caminho pelo DMAP do SDK
   (crt/kernel_procio.c da v0.45) limita cada copia com "plen > len" em vez de "len - i": um trecho que cruza a
   fronteira de pagina copiaria bytes a mais (alem do buffer na leitura; alem do trecho, NA MEMORIA DO JOGO, na
   escrita). Pedacos dentro de uma pagina de 4 KB (que fica inteira dentro de uma pagina grande) evitam isso. */
static size_t pedaco(uint64_t endereco, size_t n) {
  size_t k = (size_t)(PAGINA - (endereco & (PAGINA - 1)));
  return k < n ? k : n;
}

/* Leitura: kernel_proc_copyout (mdbg de leitura e, se falhar, tabela de paginas + DMAP; ver o topo). */
static int ler_memoria(int pid, uint64_t endereco, void *saida, size_t n) {
  unsigned char *s = saida;
  while(n) {
    size_t k = pedaco(endereco, n);
    if(kernel_proc_copyout(pid, (intptr_t)endereco, s, k)) return -1;
    endereco += k;
    s += k;
    n -= k;
  }
  return 0;
}

/* ESCRITA (Fase 1): kernel_proc_copyin do SDK = mdbg de escrita e, se falhar (bloqueado no fw >= 8.40), tabela de
   paginas + DMAP com o kernel R/W do elfldr. Pelo DMAP grava na memoria FISICA e ignora a protecao da pagina (o
   codigo do jogo e so leitura e execucao), como o ps5debug-NG. Quem chama sempre le de volta e confere. */
static int escrever_memoria(int pid, uint64_t endereco, const void *dados, size_t n) {
  const unsigned char *s = dados;
  while(n) {
    size_t k = pedaco(endereco, n);
    if(kernel_proc_copyin(pid, s, (intptr_t)endereco, k)) return -1;
    endereco += k;
    s += k;
    n -= k;
  }
  return 0;
}
#else
/* Teste: GLR_TESTE_CHEATS_PID = so este pid; se comecar com "/", e um arquivo com o pid (o teste troca de "jogo"). */
static int pid_de_teste(void) {
  const char *so = getenv("GLR_TESTE_CHEATS_PID");
  if(!so || !*so) return 0;
  if(*so != '/') return atoi(so);
  char linha[32] = "";
  FILE *f = fopen(so, "r");
  if(f && !fgets(linha, sizeof linha, f)) linha[0] = 0;
  if(f) fclose(f);
  return atoi(linha) > 0 ? atoi(linha) : -1;
}

/* PC: processos chamados "eboot.bin" (o alvo de teste, testes/cheat_alvo.c). */
static void processos_do_jogo(const jogo_t *j, processos_t *pr) {
  (void)j;
  pr->n = 0;
  int so = pid_de_teste();
  DIR *d = opendir("/proc");
  if(!d) return;
  struct dirent *e;
  while((e = readdir(d)) && pr->n < MAX_PIDS) {
    if(!isdigit((unsigned char)e->d_name[0])) continue;
    char c[300], comm[32] = "";
    snprintf(c, sizeof c, "/proc/%s/comm", e->d_name);
    FILE *f = fopen(c, "r");
    if(!f) continue;
    if(!fgets(comm, sizeof comm, f)) comm[0] = 0;
    fclose(f);
    comm[strcspn(comm, "\n")] = 0;
    if(strcmp(comm, "eboot.bin")) continue;
    if(so && so != atoi(e->d_name)) continue;   /* teste: so este pid (a demo pode ter outro eboot.bin) */
    pr->pids[pr->n] = atoi(e->d_name);
    snprintf(pr->comm[pr->n], sizeof pr->comm[0], "%s", comm);
    pr->n++;
  }
  closedir(d);
}

static int base_do_modulo(int pid, const char *modulo, uint64_t *base) {
  char c[64], linha[1200];
  snprintf(c, sizeof c, "/proc/%d/maps", pid);
  FILE *f = fopen(c, "r");
  if(!f) return -1;
  int r = -1;
  while(r && fgets(linha, sizeof linha, f)) {
    unsigned long long ini;
    char caminho[1024] = "";
    linha[strcspn(linha, "\n")] = 0;
    if(sscanf(linha, "%llx-%*x %*s %*s %*s %*s %1023s", &ini, caminho) == 2 && !strcmp(base_nome(caminho), modulo)) {
      *base = ini;
      r = 0;
    }
  }
  fclose(f);
  return r;
}

/* Leitura no PC: /proc/<pid>/mem aberto em O_RDONLY. */
static int ler_memoria(int pid, uint64_t endereco, void *saida, size_t n) {
  char c[64];
  snprintf(c, sizeof c, "/proc/%d/mem", pid);
  int fd = open(c, O_RDONLY);
  if(fd < 0) return -1;
  ssize_t r = pread(fd, saida, n, (off_t)endereco);
  close(fd);
  return r == (ssize_t)n ? 0 : -1;
}

/* ESCRITA no PC (modo de teste): /proc/<pid>/mem em O_RDWR, so no alvo de teste (processo "eboot.bin").
   GLR_TESTE_CHEATS_FALHAR=<endereco hex>: a escrita nesse endereco falha sem gravar nada (teste do desfazer). */
static int escrever_memoria(int pid, uint64_t endereco, const void *dados, size_t n) {
  const char *falhar = getenv("GLR_TESTE_CHEATS_FALHAR");
  uint64_t f;
  if(falhar && *falhar && !hex_offset(falhar, &f) && f == endereco) return -1;
  char c[64];
  snprintf(c, sizeof c, "/proc/%d/mem", pid);
  int fd = open(c, O_RDWR);
  if(fd < 0) return -1;
  ssize_t r = pwrite(fd, dados, n, (off_t)endereco);
  close(fd);
  return r == (ssize_t)n ? 0 : -1;
}
#endif

/* ------------------------------------------------------------------ trechos de uma cheat */

#define MAX_TRECHOS_CHEAT 200
#define MAX_BYTES_CHEAT (64 * 1024)   /* soma dos trechos de uma cheat que o glibren aceita gravar */
#define MAX_APLICADAS 32

static int tudo_zero(const unsigned char *b, int n) {
  for(int i = 0; i < n; i++)
    if(b[i]) return 0;
  return n > 0;
}

/* Um trecho de "memory" ja convertido. tipo: normal, invalido, secao (section != 0), area_extra (code cave: "off"
   todo zero, area que o HEN cria ao ligar), absoluto ("absolute": true), sem_off (sem "off" para conferir). */
typedef struct {
  char offset_txt[24];
  uint64_t offset;
  int n;                    /* bytes do "on" (o "off" tem o mesmo tamanho quando existe) */
  unsigned char *on, *off;  /* malloc; off NULL sem "off" */
  const char *tipo;
} trecho_t;

static void trechos_liberar(trecho_t *t, int n) {
  for(int i = 0; t && i < n; i++) {
    free(t[i].on);
    free(t[i].off);
  }
  free(t);
}

/* Hex de um campo para malloc (n = bytes). NULL se vazio/invalido (*n = -1 se invalido, 0 se vazio). */
static unsigned char *hex_campo(const jv_t *m, const char *nome, int *n) {
  const char *s = jv_txt(m, nome);
  size_t cap = strlen(s) / 2 + 1;
  *n = 0;
  if(cap > MAX_TRECHO + 1) { *n = -1; return NULL; }
  unsigned char *d = malloc(cap);
  if(!d) { *n = -1; return NULL; }
  *n = hex_bytes(s, d, cap);
  if(*n <= 0) { free(d); return NULL; }
  return d;
}

/* Le a lista "memory" de uma cheat. Devolve a quantidade (ate MAX_TRECHOS_CHEAT) e *lista (malloc; liberar com
   trechos_liberar). -1 sem memoria. */
static int trechos_ler(const jv_t *mo, trecho_t **lista) {
  const jv_t *mem = jv_campo(mo, "memory");
  int n = 0;
  *lista = calloc(MAX_TRECHOS_CHEAT, sizeof **lista);
  if(!*lista) return -1;
  for(const jv_t *m = mem && mem->tipo == JV_LISTA ? mem->filho : NULL; m && n < MAX_TRECHOS_CHEAT; m = m->prox) {
    if(m->tipo != JV_OBJETO) continue;
    trecho_t *t = &(*lista)[n++];
    int non, noff;
    snprintf(t->offset_txt, sizeof t->offset_txt, "%s", jv_txt(m, "offset"));
    t->on = hex_campo(m, "on", &non);
    t->off = hex_campo(m, "off", &noff);
    t->n = non > 0 ? non : 0;
    const jv_t *abs = jv_campo(m, "absolute"), *sec = jv_campo(m, "section");
    int secao = sec && sec->tipo == JV_NUMERO ? atoi(sec->texto) : 0;
    if(hex_offset(jv_txt(m, "offset"), &t->offset) || non <= 0 || noff < 0 || (noff && noff != non)) t->tipo = "invalido";
    else if(secao) t->tipo = "secao";
    else if(noff && tudo_zero(t->off, noff)) t->tipo = "area_extra";
    else if(abs && abs->tipo == JV_LOGICO && abs->logico) t->tipo = "absoluto";
    else if(!noff) t->tipo = "sem_off";
    else t->tipo = "normal";
  }
  return n;
}

/* Por que a cheat nao pode ser ligada nesta fase ("" = pode). modulo = o "process" do arquivo. */
static int tem_tipo(const trecho_t *t, int n, const char *tipo) {
  for(int i = 0; i < n; i++)
    if(!strcmp(t[i].tipo, tipo)) return 1;
  return 0;
}

static const char *cheat_suporte(const trecho_t *t, int n, const char *modulo) {
  int bytes = 0;
  if(!n) return "vazia";
  if(tem_tipo(t, n, "invalido")) return "invalido";
  if(strcmp(modulo, "eboot.bin")) return "outro_processo";
  if(tem_tipo(t, n, "area_extra")) return "area_extra";
  if(tem_tipo(t, n, "secao")) return "secao";
  if(tem_tipo(t, n, "absoluto")) return "absoluto";
  if(tem_tipo(t, n, "sem_off")) return "sem_off";
  for(int i = 0; i < n; i++) bytes += t[i].n;
  return bytes > MAX_BYTES_CHEAT ? "grande" : "";
}

/* ------------------------------------------------------------------ cheats ligadas pelo glibren */

/* Cada cheat ligada guarda os bytes originais (lidos antes de gravar, iguais ao "off") para restaurar. Tudo fica
   em memoria e em <catalogo>/aplicadas.json (gravado ANTES de mexer no jogo), com pid, app id, Title ID, versao e
   enderecos: se o glibren cair e voltar com o mesmo jogo aberto, ele retoma a lista. Se o pid ou o app id do jogo
   mudarem, as cheats viram "perdidas" (o jogo fechou e a memoria dele sumiu) e nada e gravado. */
typedef struct {
  uint64_t endereco;
  int n;
  unsigned char *original, *on, *off;
} trecho_ap_t;

typedef struct {
  char arquivo[256];
  int indice;
  char nome[160];
  int n;
  trecho_ap_t *t;
} aplicada_t;

static pthread_mutex_t g_trava_mem = PTHREAD_MUTEX_INITIALIZER;   /* leitura, escrita (uma por vez) e g_ap */
static struct {
  int carregou;
  int pid, app_id;
  char tid[16], versao[32];
  int n;
  aplicada_t a[MAX_APLICADAS];
  char perdidas[600];
  time_t perdidas_quando;
} g_ap;

static void aplicada_liberar(aplicada_t *a) {
  for(int i = 0; a->t && i < a->n; i++) {
    free(a->t[i].original);
    free(a->t[i].on);
    free(a->t[i].off);
  }
  free(a->t);
  memset(a, 0, sizeof *a);
}

static void aplicada_tirar(int k) {
  aplicada_liberar(&g_ap.a[k]);
  memmove(&g_ap.a[k], &g_ap.a[k + 1], (size_t)(g_ap.n - k - 1) * sizeof g_ap.a[0]);
  g_ap.n--;
  memset(&g_ap.a[g_ap.n], 0, sizeof g_ap.a[0]);
}

static int aplicada_achar(const char *arquivo, int indice) {
  for(int k = 0; k < g_ap.n; k++)
    if(g_ap.a[k].indice == indice && !strcmp(g_ap.a[k].arquivo, arquivo)) return k;
  return -1;
}

static void caminho_aplicadas(char *s, size_t tam) {
  char p[512];
  pasta_catalogo(p, sizeof p);
  snprintf(s, tam, "%s/aplicadas.json", p);
}

void cheats_caminho_aplicadas(char *s, size_t tam) {
  caminho_aplicadas(s, tam);
}

static void hex_todo(buf_t *b, const unsigned char *d, int n) {
  static const char H[] = "0123456789ABCDEF";
  buf_str(b, "\"");
  for(int i = 0; i < n; i++) {
    char x[2] = {H[d[i] >> 4], H[d[i] & 15]};
    buf_add(b, x, 2);
  }
  buf_str(b, "\"");
}

/* Hex para o diario/mensagens (ate 32 bytes; mais que isso termina em ".."). */
static void hex_txt(char *s, size_t tam, const unsigned char *d, int n) {
  size_t p = 0;
  s[0] = 0;
  for(int i = 0; i < n && i < 32 && p + 3 < tam; i++) p += (size_t)snprintf(s + p, tam - p, "%02X", d[i]);
  if(n > 32 && p + 3 < tam) snprintf(s + p, tam - p, "..");
}

/* Grava g_ap em aplicadas.json (arquivo novo + rename). 0 = gravou. */
static int ap_gravar(void) {
  char c[600], tmp[640], pasta[512];
  pasta_catalogo(pasta, sizeof pasta);
  if(mkdir_p(pasta)) return -1;
  caminho_aplicadas(c, sizeof c);
  buf_t b = {0};
  buf_fmt(&b, "{\"formato\":1,\"gravado\":%lld,\"pid\":%d,\"app_id\":%d,\"tid\":", (long long)time(NULL), g_ap.n ? g_ap.pid : -1,
          g_ap.n ? g_ap.app_id : -1);
  buf_json(&b, g_ap.n ? g_ap.tid : "");
  buf_str(&b, ",\"versao\":");
  buf_json(&b, g_ap.n ? g_ap.versao : "");
  buf_str(&b, ",\"cheats\":[");
  for(int k = 0; k < g_ap.n; k++) {
    const aplicada_t *a = &g_ap.a[k];
    buf_str(&b, k ? ",\n{\"arquivo\":" : "\n{\"arquivo\":");
    buf_json(&b, a->arquivo);
    buf_fmt(&b, ",\"indice\":%d,\"nome\":", a->indice);
    buf_json(&b, a->nome);
    buf_str(&b, ",\"trechos\":[");
    for(int i = 0; i < a->n; i++) {
      buf_fmt(&b, "%s{\"endereco\":\"0x%llx\",\"original\":", i ? "," : "", (unsigned long long)a->t[i].endereco);
      hex_todo(&b, a->t[i].original, a->t[i].n);
      buf_str(&b, ",\"on\":");
      hex_todo(&b, a->t[i].on, a->t[i].n);
      buf_str(&b, ",\"off\":");
      hex_todo(&b, a->t[i].off, a->t[i].n);
      buf_str(&b, "}");
    }
    buf_str(&b, "]}");
  }
  buf_str(&b, "]}\n");
  snprintf(tmp, sizeof tmp, "%s.tmp", c);
  unlink(tmp);
  int fd = open(tmp, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644);
  int ok = fd >= 0 && write(fd, b.d, b.n) == (ssize_t)b.n;
  if(fd >= 0 && fsync(fd)) ok = 0;
  if(fd >= 0 && close(fd)) ok = 0;
  buf_free(&b);
  if(!ok || rename(tmp, c)) {
    unlink(tmp);
    diario("cheats: nao gravou %s (errno %d)", c, errno);
    return -1;
  }
  return 0;
}

/* Le aplicadas.json uma vez (o glibren pode ter caido com cheats ligadas). Quem decide se valem e ap_conferir. */
static void ap_carregar(void) {
  if(g_ap.carregou) return;
  g_ap.carregou = 1;
  char c[600];
  caminho_aplicadas(c, sizeof c);
  buf_t b = {0};
  if(ler_arquivo(c, &b, MAX_JSON)) { buf_free(&b); return; }
  jv_t *r = jv_ler(b.d, b.n, NULL);
  buf_free(&b);
  const jv_t *ch = jv_campo(r, "cheats");
  if(!r || !ch || ch->tipo != JV_LISTA || !ch->filho) { jv_liberar(r); return; }
  g_ap.pid = atoi(jv_txt(r, "pid"));
  g_ap.app_id = atoi(jv_txt(r, "app_id"));
  snprintf(g_ap.tid, sizeof g_ap.tid, "%s", jv_txt(r, "tid"));
  snprintf(g_ap.versao, sizeof g_ap.versao, "%s", jv_txt(r, "versao"));
  int ruins = 0;
  for(const jv_t *x = ch->filho; x && g_ap.n < MAX_APLICADAS; x = x->prox) {
    const jv_t *tr = jv_campo(x, "trechos");
    aplicada_t *a = &g_ap.a[g_ap.n];
    int ok = x->tipo == JV_OBJETO && tr && tr->tipo == JV_LISTA && g_ap.pid > 0;
    snprintf(a->arquivo, sizeof a->arquivo, "%s", jv_txt(x, "arquivo"));
    snprintf(a->nome, sizeof a->nome, "%s", jv_txt(x, "nome"));
    a->indice = atoi(jv_txt(x, "indice"));
    a->t = ok ? calloc(MAX_TRECHOS_CHEAT, sizeof *a->t) : NULL;
    ok = ok && a->t;
    for(const jv_t *y = ok ? tr->filho : NULL; y && ok && a->n < MAX_TRECHOS_CHEAT; y = y->prox) {
      trecho_ap_t *t = &a->t[a->n];
      int n1, n2, n3;
      t->original = hex_campo(y, "original", &n1);
      t->on = hex_campo(y, "on", &n2);
      t->off = hex_campo(y, "off", &n3);
      t->n = n1;
      a->n++;
      ok = !hex_offset(jv_txt(y, "endereco"), &t->endereco) && n1 > 0 && n1 == n2 && n1 == n3;
    }
    if(ok && a->n) g_ap.n++;
    else { ruins++; aplicada_liberar(a); }
  }
  jv_liberar(r);
  diario("cheats: %s: %d cheat(s) ligada(s) de antes (%s pid %d app %d)%s", c, g_ap.n, g_ap.tid, g_ap.pid, g_ap.app_id,
         ruins ? "; registros invalidos ignorados" : "");
}

/* Confere se as cheats ligadas ainda sao do jogo aberto. 0 = valem (ou nao ha nenhuma); 1 = viraram perdidas
   (jogo fechou/mudou: nada e gravado); -1 = nao deu para conferir agora (nada muda, nada e gravado). */
static int ap_conferir(const jogo_t *j, int pid_atual) {
  if(!g_ap.n) return 0;
  int mudou;
  if(!strcmp(j->tipo, "desconhecido")) return -1;
  if(strcmp(j->tid, g_ap.tid)) mudou = 1;   /* outro jogo ou nenhum (menu) */
  else if(j->app_id >= 0 && g_ap.app_id >= 0 && j->app_id != g_ap.app_id) mudou = 1;
  else if(pid_atual > 0) mudou = pid_atual != g_ap.pid;
  else if(kill(g_ap.pid, 0) && errno == ESRCH) mudou = 1;
  else return -1;
  if(!mudou) return 0;
  size_t p = 0;
  g_ap.perdidas[0] = 0;
  for(int k = 0; k < g_ap.n; k++)
    p += (size_t)snprintf(g_ap.perdidas + p, p < sizeof g_ap.perdidas ? sizeof g_ap.perdidas - p : 0, "%s%s", k ? ", " : "",
                          g_ap.a[k].nome);
  g_ap.perdidas_quando = time(NULL);
  diario("cheats: o jogo mudou (%s pid %d app %d -> %s pid %d app %d): %d cheat(s) ligada(s) perdida(s), nada foi gravado: %s",
         g_ap.tid, g_ap.pid, g_ap.app_id, j->tid[0] ? j->tid : "-", pid_atual, j->app_id, g_ap.n, g_ap.perdidas);
  while(g_ap.n) aplicada_tirar(g_ap.n - 1);
  ap_gravar();
  return 1;
}

/* ------------------------------------------------------------------ JSON de saida */

/* Bytes em hex (ate 24; mais que isso termina em ".."). */
static void hex_curto(buf_t *b, const unsigned char *d, int n) {
  char s[2 * 24 + 4];
  int k = n > 24 ? 24 : n, p = 0;
  for(int i = 0; i < k; i++) p += snprintf(s + p, sizeof s - (size_t)p, "%02X", d[i]);
  if(n > k) snprintf(s + p, sizeof s - (size_t)p, "..");
  s[sizeof s - 1] = 0;
  buf_json(b, s);
}

/* Contagem dos trechos por tipo e, nos conferiveis (normal, absoluto, sem_off, outro_processo), pelo que foi lido.
   As areas extras NAO entram em "lidos" (na 0.9.17 entravam duas vezes: "5 de 9" com 7 trechos). */
typedef struct {
  int trechos, normais, caves, secao, absolutos, sem_off, outro_processo, invalidos;
  int conferiveis, lidos, desligados, ligados, diferentes, erros;
} contagem_t;

static void contagem_somar(contagem_t *t, const contagem_t *c) {
  int *a = (int *)t;
  const int *b = (const int *)c;
  for(size_t i = 0; i < sizeof *t / sizeof(int); i++) a[i] += b[i];
}

/* Um trecho: le e compara. Estados: desligado, ligado, diferente, cave (area extra), erro (leitura falhou), invalido,
   secao, sem_base (modulo nao achado), limite. */
static void trecho_json(buf_t *b, const trecho_t *t, const char *modulo, int pid, int tem_base, uint64_t base, int *leituras,
                        contagem_t *c) {
  static unsigned char atual[MAX_TRECHO];   /* so com g_trava_mem */
  const char *estado = NULL, *tipo = t->tipo;
  int cave = !strcmp(tipo, "area_extra"), absoluto = !strcmp(tipo, "absoluto");
  if(!strcmp(tipo, "normal") && strcmp(modulo, "eboot.bin")) tipo = "outro_processo";
  c->trechos++;
  if(!strcmp(tipo, "normal")) c->normais++;
  else if(cave) c->caves++;
  else if(!strcmp(tipo, "secao")) c->secao++;
  else if(absoluto) c->absolutos++;
  else if(!strcmp(tipo, "sem_off")) c->sem_off++;
  else if(!strcmp(tipo, "outro_processo")) c->outro_processo++;
  else c->invalidos++;
  int conferivel = !cave && strcmp(tipo, "secao") && strcmp(tipo, "invalido");
  if(conferivel) c->conferiveis++;
  buf_str(b, "{\"offset\":");
  buf_json(b, t->offset_txt);
  buf_str(b, ",\"tipo\":");
  buf_json(b, tipo);
  if(!strcmp(tipo, "invalido") || !strcmp(tipo, "secao")) estado = tipo;
  else if(!tem_base && !absoluto) estado = "sem_base";
  else if(*leituras >= MAX_LEITURAS) estado = "limite";
  if(estado) {
    if(conferivel) c->erros++;
  } else {
    uint64_t end = absoluto ? t->offset : base + t->offset;
    (*leituras)++;
    buf_fmt(b, ",\"endereco\":\"0x%llx\"", (unsigned long long)end);
    if(ler_memoria(pid, end, atual, (size_t)t->n)) {
      estado = cave ? "cave" : "erro";
      if(!cave) c->erros++;
    } else {
      buf_str(b, ",\"lido\":");
      hex_curto(b, atual, t->n);
      int bate_off = t->off && !memcmp(atual, t->off, (size_t)t->n), bate_on = !memcmp(atual, t->on, (size_t)t->n);
      if(cave) estado = bate_off ? "cave" : bate_on ? "ligado" : "diferente";
      else {
        c->lidos++;
        if(bate_off) { estado = "desligado"; c->desligados++; }
        else if(bate_on) { estado = "ligado"; c->ligados++; }
        else if(!t->off) estado = "sem_off";   /* sem o "off" no arquivo: nao da para dizer que nao bate */
        else { estado = "diferente"; c->diferentes++; }
      }
    }
  }
  buf_str(b, ",\"estado\":");
  buf_json(b, estado);
  buf_fmt(b, ",\"bytes\":%d}", t->n);
}

/* As cheats de um arquivo, com a leitura de cada trecho. */
static void arquivo_cheats(buf_t *b, const arquivo_t *a, const jogo_t *j, const processos_t *pr, int *leituras, int *primeiro,
                           contagem_t *total, int *suportadas, int *nao_suportadas) {
  buf_t dados = {0};
  const char *erro = "";
  jv_t *r = NULL;
  if(ler_arquivo(a->caminho, &dados, MAX_JSON)) erro = "arquivo grande demais ou ilegivel";
  else r = jv_ler(dados.d, dados.n, &erro);
  buf_free(&dados);
  buf_fmt(b, "%s{\"arquivo\":", *primeiro ? "" : ",");
  *primeiro = 0;
  buf_json(b, a->nome);
  buf_str(b, ",\"origem\":");
  buf_json(b, a->origem);
  if(!r || r->tipo != JV_OBJETO) {
    if(r) erro = "o arquivo nao e um objeto JSON";
    buf_str(b, ",\"erro\":");
    buf_json(b, erro);
    buf_str(b, ",\"mods\":[]}");
    jv_liberar(r);
    return;
  }
  const char *processo = jv_txt(r, "process");
  if(!*processo) processo = "eboot.bin";
  const char *modulo = base_nome(processo);
  /* base do modulo: o primeiro processo do jogo que tiver o modulo */
  int pid = -1, tem_base = 0;
  uint64_t base = 0;
  for(int i = 0; i < pr->n && !tem_base; i++)
    if(!base_do_modulo(pr->pids[i], modulo, &base)) { tem_base = 1; pid = pr->pids[i]; }
  if(!tem_base && pr->n) pid = pr->pids[0];
  buf_str(b, ",\"jogo\":");
  buf_json(b, jv_txt(r, "name"));
  buf_str(b, ",\"processo\":");
  buf_json(b, processo);
  buf_fmt(b, ",\"versao_confere\":%s,\"pid\":%d", !strcmp(jv_txt(r, "version"), j->versao) ? "true" : "false", pid);
  if(tem_base) buf_fmt(b, ",\"base\":\"0x%llx\"", (unsigned long long)base);
  buf_str(b, ",\"creditos\":[");
  const jv_t *cr = jv_campo(r, "credits");
  if(!cr) cr = jv_campo(r, "authors");
  int k = 0;
  for(const jv_t *x = cr && cr->tipo == JV_LISTA ? cr->filho : NULL; x && k < 10; x = x->prox) {
    if(x->tipo != JV_TEXTO) continue;
    if(k++) buf_str(b, ",");
    buf_json(b, x->texto);
  }
  buf_str(b, "],\"mods\":[");
  const jv_t *mods = jv_campo(r, "mods");
  int nm = 0;
  for(const jv_t *mo = mods && mods->tipo == JV_LISTA ? mods->filho : NULL; mo && nm < 300; mo = mo->prox) {
    if(mo->tipo != JV_OBJETO) continue;
    buf_fmt(b, "%s{\"indice\":%d,\"nome\":", nm ? "," : "", nm);
    int indice = nm++;
    buf_json(b, jv_txt(mo, "name"));
    buf_str(b, ",\"descricao\":");
    buf_json(b, jv_txt(mo, "description"));
    buf_str(b, ",\"tipo\":");
    buf_json(b, jv_txt(mo, "type"));
    buf_str(b, ",\"trechos\":[");
    contagem_t c = {0};
    trecho_t *t = NULL;
    int nt = trechos_ler(mo, &t);
    for(int i = 0; i < nt; i++) {
      if(i) buf_str(b, ",");
      trecho_json(b, &t[i], modulo, pid, tem_base, base, leituras, &c);
    }
    const char *suporte = nt < 0 ? "invalido" : cheat_suporte(t, nt, modulo);
    trechos_liberar(t, nt);
    /* estado verdadeiro da cheat: so os trechos conferiveis contam (nas nao suportadas, o estado e "nao_suportada") */
    const char *estado = *suporte                       ? "nao_suportada"
                         : c.erros                      ? "erro"
                         : c.diferentes                 ? "diferente"
                         : c.ligados && c.desligados    ? "misto"
                         : c.ligados                    ? "ligado"
                                                        : "desligado";
    if(*suporte) (*nao_suportadas)++;
    else (*suportadas)++;
    buf_str(b, "],\"estado\":");
    buf_json(b, estado);
    buf_str(b, ",\"suporte\":");
    buf_json(b, suporte);
    buf_fmt(b, ",\"aplicada\":%s}", aplicada_achar(a->nome, indice) >= 0 ? "true" : "false");
    contagem_somar(total, &c);
  }
  buf_str(b, "]}");
  jv_liberar(r);
}

/* Processo eboot.bin do jogo aberto e a base dele (para gravar e para conferir as ligadas). -1 = nao achou. */
static int pid_do_eboot(const processos_t *pr, uint64_t *base) {
  for(int i = 0; i < pr->n; i++)
    if(!base_do_modulo(pr->pids[i], "eboot.bin", base)) return pr->pids[i];
  return -1;
}

static char g_ultimo_resumo[400];

void cheats_json(buf_t *b) {
  jogo_t j;
  jogo_aberto(&j);
  jogo_versao(&j);
#ifdef __PROSPERO__
  const char *simulado = "false";
#else
  const char *simulado = "true";
#endif
  buf_fmt(b, "{\"ok\":true,\"teste\":true,\"somente_leitura\":false,\"escrita\":true,\"simulado\":%s,\"jogo\":{\"tid\":", simulado);
  buf_json(b, j.tid);
  buf_str(b, ",\"tipo\":");
  buf_json(b, j.tipo);
  buf_str(b, ",\"nome\":");
  buf_json(b, j.nome);
  buf_str(b, ",\"versao\":");
  buf_json(b, j.versao);
  buf_str(b, ",\"versao_de\":");
  buf_json(b, j.versao_de);
  buf_str(b, ",\"mestre\":");
  buf_json(b, j.mestre);
  buf_fmt(b, ",\"app_id\":%d},", j.app_id);
  catalogo_json(b);

  arquivo_t *lista = calloc(MAX_ARQUIVOS, sizeof *lista);
  int n = lista && j.versao[0] && j.tid[0] ? achar_arquivos(&j, lista, MAX_ARQUIVOS) : 0;
  processos_t pr;
  memset(&pr, 0, sizeof pr);
  pthread_mutex_lock(&g_trava_mem);
  ap_carregar();
  if(n || g_ap.n) processos_do_jogo(&j, &pr);
  uint64_t base_eboot = 0;
  ap_conferir(&j, pid_do_eboot(&pr, &base_eboot));
  buf_str(b, ",\"processos\":[");
  for(int i = 0; i < pr.n; i++) {
    buf_fmt(b, "%s{\"pid\":%d,\"nome\":", i ? "," : "", pr.pids[i]);
    buf_json(b, pr.comm[i]);
    buf_str(b, "}");
  }
  buf_str(b, "],\"arquivos\":[");
  int leituras = 0, primeiro = 1, suportadas = 0, nao_suportadas = 0;
  contagem_t total = {0};
  for(int i = 0; i < n; i++) arquivo_cheats(b, &lista[i], &j, &pr, &leituras, &primeiro, &total, &suportadas, &nao_suportadas);
  buf_fmt(b,
          "],\"resumo\":{\"trechos\":%d,\"normais\":%d,\"caves\":%d,\"secao\":%d,\"absolutos\":%d,\"sem_off\":%d,"
          "\"outro_processo\":%d,\"invalidos\":%d,\"conferiveis\":%d,\"lidos\":%d,\"desligados\":%d,\"ligados\":%d,"
          "\"diferentes\":%d,\"erros\":%d,\"suportadas\":%d,\"nao_suportadas\":%d,\"aplicadas\":%d}",
          total.trechos, total.normais, total.caves, total.secao, total.absolutos, total.sem_off, total.outro_processo,
          total.invalidos, total.conferiveis, total.lidos, total.desligados, total.ligados, total.diferentes, total.erros,
          suportadas, nao_suportadas, g_ap.n);
  buf_str(b, ",\"aplicadas\":[");
  for(int k = 0; k < g_ap.n; k++) {
    buf_str(b, k ? ",{\"arquivo\":" : "{\"arquivo\":");
    buf_json(b, g_ap.a[k].arquivo);
    buf_fmt(b, ",\"indice\":%d,\"nome\":", g_ap.a[k].indice);
    buf_json(b, g_ap.a[k].nome);
    buf_str(b, "}");
  }
  buf_str(b, "],\"perdidas\":{\"nomes\":");
  buf_json(b, g_ap.perdidas);
  buf_fmt(b, ",\"quando\":%lld}}", (long long)g_ap.perdidas_quando);
  /* diario: uma linha quando o resultado muda (nao a cada consulta da pagina) */
  char resumo[400];
  snprintf(resumo, sizeof resumo,
           "%s %s v%s (%s): %d arquivo(s), %d processo(s)%s%s; %d trecho(s): %d conferiveis (desligados %d, ligados %d, "
           "diferentes %d, erros %d), area extra %d, secao %d, outro processo %d, invalidos %d; ligadas pelo glibren %d",
           j.tipo, j.tid[0] ? j.tid : "-", j.versao[0] ? j.versao : "?", j.versao_de[0] ? j.versao_de : "-", n, pr.n,
           pr.n ? " primeiro " : "", pr.n ? pr.comm[0] : "", total.trechos, total.conferiveis, total.desligados, total.ligados,
           total.diferentes, total.erros, total.caves, total.secao, total.outro_processo, total.invalidos, g_ap.n);
  if(strcmp(resumo, g_ultimo_resumo)) {
    snprintf(g_ultimo_resumo, sizeof g_ultimo_resumo, "%s", resumo);
    diario("cheats: %s", resumo);
  }
  pthread_mutex_unlock(&g_trava_mem);
  free(lista);
}

/* ------------------------------------------------------------------ ligar e desligar (Fase 1) */

/* Resposta de erro: {"ok":false,"chave":..,"erro":..,"params":{..}}. params_json = conteudo do objeto (ou ""). */
static int recusar(buf_t *r, int status, const char *chave, const char *params_json, const char *fmt, ...)
  __attribute__((format(printf, 5, 6)));
static int recusar(buf_t *r, int status, const char *chave, const char *params_json, const char *fmt, ...) {
  char msg[400];
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(msg, sizeof msg, fmt, ap);
  va_end(ap);
  buf_str(r, "{\"ok\":false,\"chave\":");
  buf_json(r, chave);
  buf_str(r, ",\"erro\":");
  buf_json(r, msg);
  buf_fmt(r, ",\"params\":{%s}}", params_json ? params_json : "");
  return status;
}

/* params de um trecho: {"trecho":N,"endereco":"0x..","lido":"..","esperado":".."} (conteudo, sem chaves) */
static void params_trecho(char *s, size_t tam, int i, uint64_t end, const unsigned char *lido, const unsigned char *esperado, int n) {
  char hl[80] = "", he[80] = "";
  if(lido) hex_txt(hl, sizeof hl, lido, n);
  if(esperado) hex_txt(he, sizeof he, esperado, n);
  snprintf(s, tam, "\"trecho\":%d,\"endereco\":\"0x%llx\",\"lido\":\"%s\",\"esperado\":\"%s\"", i + 1, (unsigned long long)end, hl, he);
}

/* Grava "dados" no trecho e le de volta. 0 = conferido; -1 = escrita falhou; -2 = leitura de volta diferente/falhou. */
static int gravar_conferir(int pid, uint64_t end, const unsigned char *dados, int n, unsigned char *lido) {
  if(escrever_memoria(pid, end, dados, (size_t)n)) return -1;
  if(ler_memoria(pid, end, lido, (size_t)n) || memcmp(lido, dados, (size_t)n)) return -2;
  return 0;
}

/* Volta os trechos 0..ate de uma cheat para "alvo_de" (original ou on), de tras para frente; so grava onde os bytes
   atuais sao diferentes. 0 = todos conferidos. */
static int voltar_trechos(int pid, const aplicada_t *a, int ate, int para_original, unsigned char *lido) {
  int falhas = 0;
  for(int i = ate; i >= 0; i--) {
    const trecho_ap_t *t = &a->t[i];
    const unsigned char *alvo = para_original ? t->original : t->on;
    if(!ler_memoria(pid, t->endereco, lido, (size_t)t->n) && !memcmp(lido, alvo, (size_t)t->n)) continue;
    int r = gravar_conferir(pid, t->endereco, alvo, t->n, lido);
    char h[80];
    hex_txt(h, sizeof h, alvo, t->n);
    diario("cheats:   desfazer trecho %d 0x%llx -> %s: %s", i + 1, (unsigned long long)t->endereco, h,
           !r ? "ok" : r == -1 ? "ESCRITA FALHOU" : "LEITURA DE VOLTA DIFERENTE");
    if(r) falhas++;
  }
  return falhas ? -1 : 0;
}

/* Desliga a cheat k de g_ap (com g_trava_mem). Exige os bytes atuais = "on" e originais = "off"; grava os originais
   de tras para frente e le de volta; se um trecho falhar, volta os ja restaurados para "on" (cheat continua ligada).
   0 = desligou (e saiu de g_ap). */
static int desligar_k(int k, int pid, const char *quando, buf_t *r) {
  aplicada_t *a = &g_ap.a[k];
  char nome[160], tid[16], params[300];
  unsigned char *lido = malloc(MAX_TRECHO);
  snprintf(nome, sizeof nome, "%s", a->nome);
  snprintf(tid, sizeof tid, "%s", g_ap.tid);
  if(!lido) return recusar(r, 500, "cheats_memoria", "", "sem memoria");
  for(int i = 0; i < a->n; i++) {
    trecho_ap_t *t = &a->t[i];
    if(memcmp(t->original, t->off, (size_t)t->n)) {
      free(lido);
      params_trecho(params, sizeof params, i, t->endereco, t->original, t->off, t->n);
      diario("cheats: desligar %s em %s recusado: registro com original diferente do desligado no trecho %d", nome, tid, i + 1);
      return recusar(r, 200, "cheats_registro_invalido", params, "os bytes originais guardados nao batem com o desligado do arquivo");
    }
    if(ler_memoria(pid, t->endereco, lido, (size_t)t->n)) {
      free(lido);
      params_trecho(params, sizeof params, i, t->endereco, NULL, t->on, t->n);
      diario("cheats: desligar %s em %s recusado: nao leu o trecho %d (0x%llx)", nome, tid, i + 1, (unsigned long long)t->endereco);
      return recusar(r, 200, "cheats_leitura", params, "nao leu a memoria do jogo no trecho %d", i + 1);
    }
    if(memcmp(lido, t->on, (size_t)t->n)) {
      params_trecho(params, sizeof params, i, t->endereco, lido, t->on, t->n);
      free(lido);
      diario("cheats: desligar %s em %s recusado: os bytes do trecho %d (0x%llx) nao estao mais ligados", nome, tid, i + 1,
             (unsigned long long)t->endereco);
      return recusar(r, 200, "cheats_mudou", params, "os bytes do trecho %d nao batem mais com o ligado", i + 1);
    }
  }
  diario("cheats: desligando %s em %s (pid %d, %d trecho(s))%s", nome, tid, pid, a->n, quando);
  for(int i = a->n - 1; i >= 0; i--) {
    trecho_ap_t *t = &a->t[i];
    int res = gravar_conferir(pid, t->endereco, t->original, t->n, lido);
    char h1[80], h2[80];
    hex_txt(h1, sizeof h1, t->on, t->n);
    hex_txt(h2, sizeof h2, t->original, t->n);
    diario("cheats:   trecho %d 0x%llx: %s -> %s: %s", i + 1, (unsigned long long)t->endereco, h1, h2,
           !res ? "lido de volta ok" : res == -1 ? "ESCRITA FALHOU" : "LEITURA DE VOLTA DIFERENTE");
    if(res) {
      /* volta para "on" os ja restaurados (i+1..fim) e o atual, para a cheat ficar inteira ligada */
      int voltou = 0;
      int falhas = 0;
      for(int m = i; m < a->n; m++) {
        const trecho_ap_t *u = &a->t[m];
        if(!ler_memoria(pid, u->endereco, lido, (size_t)u->n) && !memcmp(lido, u->on, (size_t)u->n)) continue;
        if(gravar_conferir(pid, u->endereco, u->on, u->n, lido)) falhas++;
      }
      voltou = !falhas;
      diario("cheats: desligar %s em %s falhou no trecho %d (0x%llx); a cheat %s", nome, tid, i + 1, (unsigned long long)t->endereco,
             voltou ? "continua ligada (voltou inteira para o ligado)" : "ficou PARCIAL: salve e feche o jogo");
      params_trecho(params, sizeof params, i, t->endereco, NULL, t->original, t->n);
      snprintf(params + strlen(params), sizeof params - strlen(params), ",\"voltou\":%s", voltou ? "true" : "false");
      free(lido);
      return recusar(r, 200, res == -1 ? "cheats_escrita" : "cheats_conferencia", params,
                     "%s no trecho %d", res == -1 ? "a escrita falhou" : "a leitura de volta nao bateu", i + 1);
    }
  }
  free(lido);
  int n = a->n;
  aplicada_tirar(k);
  ap_gravar();
  diario("cheats: desligou %s em %s (pid %d, %d trecho(s); leitura de volta OK)%s", nome, tid, pid, n, quando);
  buf_str(r, "{\"ok\":true,\"estado\":\"desligado\",\"nome\":");
  buf_json(r, nome);
  buf_fmt(r, ",\"trechos\":%d}", n);
  return 200;
}

/* Liga a cheat (com g_trava_mem). Ver as regras em ESTUDO-cheats (Fase 1). */
static int ligar_cheat(const jogo_t *j, int pid, uint64_t base, const char *arquivo, int indice, buf_t *r) {
  arquivo_t *lista = calloc(MAX_ARQUIVOS, sizeof *lista);
  if(!lista) return recusar(r, 500, "cheats_memoria", "", "sem memoria");
  int n = achar_arquivos(j, lista, MAX_ARQUIVOS), achou = -1;
  for(int i = 0; i < n && achou < 0; i++)
    if(!strcmp(lista[i].nome, arquivo)) achou = i;
  if(achou < 0) {
    free(lista);
    return recusar(r, 200, "cheats_arquivo", "", "arquivo de cheat nao encontrado para este jogo e versao");
  }
  buf_t dados = {0};
  jv_t *raiz = NULL;
  if(!ler_arquivo(lista[achou].caminho, &dados, MAX_JSON)) raiz = jv_ler(dados.d, dados.n, NULL);
  buf_free(&dados);
  free(lista);
  const jv_t *mods = jv_campo(raiz, "mods"), *mo = NULL;
  int nm = 0;
  for(const jv_t *x = mods && mods->tipo == JV_LISTA ? mods->filho : NULL; x && nm < 300 && !mo; x = x->prox) {
    if(x->tipo != JV_OBJETO) continue;
    if(nm++ == indice) mo = x;
  }
  if(!mo) {
    jv_liberar(raiz);
    return recusar(r, 200, "cheats_indice", "", "a cheat nao existe no arquivo");
  }
  const char *processo = jv_txt(raiz, "process");
  char modulo[128], nome[160], params[400];
  snprintf(modulo, sizeof modulo, "%s", base_nome(*processo ? processo : "eboot.bin"));   /* copia: raiz e liberada abaixo */
  snprintf(nome, sizeof nome, "%s", jv_txt(mo, "name"));
  for(char *c = nome; *c; c++) if((unsigned char)*c < ' ') *c = ' ';
  trecho_t *t = NULL;
  int nt = trechos_ler(mo, &t);
  jv_liberar(raiz);
  const char *suporte = nt < 0 ? "invalido" : cheat_suporte(t, nt, modulo);
  int status = 0;
  unsigned char *lido = NULL;
  aplicada_t *a = NULL;
  if(*suporte) {
    snprintf(params, sizeof params, "\"motivo\":\"%s\"", suporte);
    diario("cheats: ligar %s em %s recusado: nao suportada ainda (%s)", nome, j->tid, suporte);
    status = recusar(r, 200, "cheats_nao_suportada", params, "cheat nao suportada ainda (%s)", suporte);
    goto fim;
  }
  if(aplicada_achar(arquivo, indice) >= 0) {
    status = recusar(r, 200, "cheats_ja_ligada", "", "a cheat ja esta ligada");
    goto fim;
  }
  if(g_ap.n >= MAX_APLICADAS) {
    status = recusar(r, 200, "cheats_limite", "", "cheats ligadas demais (maximo %d)", MAX_APLICADAS);
    goto fim;
  }
  /* nao pode mexer nos mesmos bytes de outra cheat ligada */
  for(int i = 0; i < nt; i++)
    for(int k = 0; k < g_ap.n; k++)
      for(int m = 0; m < g_ap.a[k].n; m++) {
        uint64_t e1 = base + t[i].offset, e2 = g_ap.a[k].t[m].endereco;
        if(e1 < e2 + (uint64_t)g_ap.a[k].t[m].n && e2 < e1 + (uint64_t)t[i].n) {
          buf_t p = {0};
          buf_str(&p, "\"nome\":");
          buf_json(&p, g_ap.a[k].nome);
          diario("cheats: ligar %s em %s recusado: mexe nos mesmos bytes que %s (ligada)", nome, j->tid, g_ap.a[k].nome);
          status = recusar(r, 200, "cheats_sobreposta", p.d, "mexe nos mesmos bytes de outra cheat ligada");
          buf_free(&p);
          goto fim;
        }
      }
  /* bytes atuais de TODOS os trechos = "off" (senao: versao errada, outra ferramenta ou cheat ja ligada) */
  if(!(lido = malloc(MAX_TRECHO))) { status = recusar(r, 500, "cheats_memoria", "", "sem memoria"); goto fim; }
  a = &g_ap.a[g_ap.n];
  memset(a, 0, sizeof *a);
  if(!(a->t = calloc((size_t)nt, sizeof *a->t))) { status = recusar(r, 500, "cheats_memoria", "", "sem memoria"); goto fim; }
  for(int i = 0; i < nt; i++) {
    uint64_t end = base + t[i].offset;
    trecho_ap_t *u = &a->t[i];
    u->endereco = end;
    u->n = t[i].n;
    u->original = malloc((size_t)t[i].n);
    u->on = malloc((size_t)t[i].n);
    u->off = malloc((size_t)t[i].n);
    a->n = i + 1;
    if(!u->original || !u->on || !u->off) { status = recusar(r, 500, "cheats_memoria", "", "sem memoria"); goto fim; }
    if(ler_memoria(pid, end, u->original, (size_t)t[i].n)) {
      params_trecho(params, sizeof params, i, end, NULL, t[i].off, t[i].n);
      diario("cheats: ligar %s em %s recusado: nao leu o trecho %d (0x%llx)", nome, j->tid, i + 1, (unsigned long long)end);
      status = recusar(r, 200, "cheats_leitura", params, "nao leu a memoria do jogo no trecho %d", i + 1);
      goto fim;
    }
    memcpy(u->on, t[i].on, (size_t)t[i].n);
    memcpy(u->off, t[i].off, (size_t)t[i].n);
  }
  int todos_on = 1;
  for(int i = 0; i < nt; i++)
    if(memcmp(a->t[i].original, a->t[i].on, (size_t)a->t[i].n)) todos_on = 0;
  if(todos_on) {
    diario("cheats: ligar %s em %s recusado: os bytes ja estao ligados (outra ferramenta?)", nome, j->tid);
    status = recusar(r, 200, "cheats_ligada_fora", "", "os bytes ja estao ligados (outra ferramenta?)");
    goto fim;
  }
  for(int i = 0; i < nt; i++) {
    const trecho_ap_t *u = &a->t[i];
    if(!memcmp(u->original, u->off, (size_t)u->n)) continue;
    char hl[80], he[80];
    hex_txt(hl, sizeof hl, u->original, u->n);
    hex_txt(he, sizeof he, u->off, u->n);
    params_trecho(params, sizeof params, i, u->endereco, u->original, u->off, u->n);
    diario("cheats: ligar %s em %s recusado: trecho %d (0x%llx) tem %s, o desligado do arquivo e %s", nome, j->tid, i + 1,
           (unsigned long long)u->endereco, hl, he);
    status = recusar(r, 200, "cheats_nao_bate", params, "os bytes do trecho %d nao batem com o desligado do arquivo (outra versao?)", i + 1);
    goto fim;
  }
  /* registro ANTES de gravar no jogo: originais em memoria e em aplicadas.json */
  snprintf(a->arquivo, sizeof a->arquivo, "%s", arquivo);
  snprintf(a->nome, sizeof a->nome, "%s", nome);
  a->indice = indice;
  if(!g_ap.n) {
    g_ap.pid = pid;
    g_ap.app_id = j->app_id;
    snprintf(g_ap.tid, sizeof g_ap.tid, "%s", j->tid);
    snprintf(g_ap.versao, sizeof g_ap.versao, "%s", j->versao);
  }
  g_ap.n++;
  if(ap_gravar()) {
    g_ap.n--;
    status = recusar(r, 200, "cheats_registro", "", "nao gravou o registro das cheats (aplicadas.json): nada foi mudado no jogo");
    goto fim;
  }
  diario("cheats: ligando %s em %s (pid %d, %d trecho(s))", nome, j->tid, pid, nt);
  for(int i = 0; i < nt; i++) {
    trecho_ap_t *u = &a->t[i];
    int res = gravar_conferir(pid, u->endereco, u->on, u->n, lido);
    char h1[80], h2[80];
    hex_txt(h1, sizeof h1, u->original, u->n);
    hex_txt(h2, sizeof h2, u->on, u->n);
    diario("cheats:   trecho %d 0x%llx: %s -> %s: %s", i + 1, (unsigned long long)u->endereco, h1, h2,
           !res ? "lido de volta ok" : res == -1 ? "ESCRITA FALHOU" : "LEITURA DE VOLTA DIFERENTE");
    if(res) {
      int desfez = !voltar_trechos(pid, a, i, 1, lido);
      diario("cheats: ligar %s em %s falhou no trecho %d (0x%llx); desfeito: %s", nome, j->tid, i + 1, (unsigned long long)u->endereco,
             desfez ? "OK (jogo como antes)" : "FALHOU (salve e feche o jogo)");
      params_trecho(params, sizeof params, i, u->endereco, NULL, u->on, u->n);
      snprintf(params + strlen(params), sizeof params - strlen(params), ",\"desfeito\":%s", desfez ? "true" : "false");
      aplicada_tirar(g_ap.n - 1);
      a = NULL;
      ap_gravar();
      status = recusar(r, 200, res == -1 ? "cheats_escrita" : "cheats_conferencia", params, "%s no trecho %d",
                       res == -1 ? "a escrita falhou" : "a leitura de volta nao bateu", i + 1);
      goto fim;
    }
  }
  a = NULL;
  diario("cheats: ligou %s em %s (pid %d, %d trecho(s); leitura de volta OK)", nome, j->tid, pid, nt);
  buf_str(r, "{\"ok\":true,\"estado\":\"ligado\",\"nome\":");
  buf_json(r, nome);
  buf_fmt(r, ",\"trechos\":%d}", nt);
  status = 200;
fim:
  if(a) aplicada_liberar(a);   /* registro que nao chegou a valer */
  free(lido);
  trechos_liberar(t, nt);
  return status;
}

/* Campo do pedido: JSON {"tid":..} ou formulario tid=..&.. */
static void campo_pedido(const jv_t *json, const char *corpo, const char *nome, char *saida, size_t tam) {
  saida[0] = 0;
  if(json) snprintf(saida, tam, "%s", jv_txt(json, nome));
  else if(corpo) param(corpo, nome, 0, saida, tam);
}

int cheats_acao(int ligar, const char *corpo, size_t n, buf_t *r) {
  char tid[16], versao[32], arquivo[256], indice_txt[16];
  char *copia = malloc(n + 1);
  if(!copia) return recusar(r, 500, "cheats_memoria", "", "sem memoria");
  if(n) memcpy(copia, corpo, n);
  copia[n] = 0;
  const char *p = copia;
  while(*p == ' ' || *p == '\n' || *p == '\r' || *p == '\t') p++;
  jv_t *json = *p == '{' ? jv_ler(copia, n, NULL) : NULL;
  campo_pedido(json, *p == '{' ? NULL : copia, "tid", tid, sizeof tid);
  campo_pedido(json, *p == '{' ? NULL : copia, "versao", versao, sizeof versao);
  campo_pedido(json, *p == '{' ? NULL : copia, "arquivo", arquivo, sizeof arquivo);
  campo_pedido(json, *p == '{' ? NULL : copia, "indice", indice_txt, sizeof indice_txt);
  jv_liberar(json);
  free(copia);
  size_t na = strlen(arquivo);
  int indice = -1;
  if(indice_txt[0] && strspn(indice_txt, "0123456789") == strlen(indice_txt) && strlen(indice_txt) <= 3) indice = atoi(indice_txt);
  if(!titulo_valido(tid) || !versao_valida(versao) || na < 6 || strcasecmp(arquivo + na - 5, ".json") || !nome_valido(arquivo) ||
     arquivo[0] == '.' || indice < 0 || indice >= 300)
    return recusar(r, 400, "cheats_parametros", "", "pedido invalido (tid, versao, arquivo, indice)");

  pthread_mutex_lock(&g_trava_mem);   /* uma escrita por vez (e nenhuma leitura no meio) */
  ap_carregar();
  jogo_t j;
  jogo_aberto(&j);
  jogo_versao(&j);
  int status;
  processos_t pr;
  memset(&pr, 0, sizeof pr);
  uint64_t base = 0;
  int pid = -1;
  if(strcmp(j.tid, tid) || strcmp(j.versao, versao)) {
    status = recusar(r, 200, "cheats_jogo_mudou", "", "o jogo aberto nao e o do pedido (%s v%s)", j.tid[0] ? j.tid : "-", j.versao[0] ? j.versao : "?");
    goto fim;
  }
  processos_do_jogo(&j, &pr);
  pid = pid_do_eboot(&pr, &base);
  int conf = ap_conferir(&j, pid);
  if(conf < 0) {
    status = recusar(r, 200, "cheats_nao_conferiu", "", "nao deu para conferir o jogo agora: tente de novo");
    goto fim;
  }
  if(pid <= 0) {
    status = recusar(r, 200, "cheats_sem_processo", "", "processo eboot.bin do jogo nao encontrado");
    goto fim;
  }
  if(ligar) status = ligar_cheat(&j, pid, base, arquivo, indice, r);
  else {
    int k = aplicada_achar(arquivo, indice);
    if(k < 0) {
      diario("cheats: desligar %s#%d em %s recusado: nao foi ligada pelo glibren%s", arquivo, indice, j.tid, conf == 1 ? " (o jogo mudou)" : "");
      status = recusar(r, 200, conf == 1 ? "cheats_perdida" : "cheats_nao_ligada", "",
                       conf == 1 ? "o jogo fechou: a cheat se perdeu (nada foi gravado)" : "esta cheat nao foi ligada pelo glibren");
    } else status = desligar_k(k, pid, "", r);
  }
fim:
  pthread_mutex_unlock(&g_trava_mem);
  return status;
}

void cheats_restaurar_ao_sair(void) {
  pthread_mutex_lock(&g_trava_mem);
  ap_carregar();
  if(g_ap.n) {
    jogo_t j;
    jogo_aberto(&j);
    processos_t pr;
    memset(&pr, 0, sizeof pr);
    processos_do_jogo(&j, &pr);
    uint64_t base = 0;
    int pid = pid_do_eboot(&pr, &base);
    int conf = ap_conferir(&j, pid);
    if(conf < 0) diario("cheats: ao fechar: nao deu para conferir o jogo; %d cheat(s) ficam no registro (aplicadas.json)", g_ap.n);
    for(int k = g_ap.n - 1; conf == 0 && k >= 0; k--) {
      buf_t r = {0};
      if(desligar_k(k, pid, " ao fechar o glibren", &r) != 200) diario("cheats: ao fechar: %s continua ligada", g_ap.a[k].nome);
      buf_free(&r);
    }
  }
  pthread_mutex_unlock(&g_trava_mem);
}
