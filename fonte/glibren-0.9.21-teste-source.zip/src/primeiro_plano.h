/* Game Library Renamer (payload PS5) - qual app esta em primeiro plano, pelo diario do kernel (kern.msgbuf).

Ideia do ps-game-state-lib (StonedModder, MIT): o sistema escreve no kern.msgbuf linhas como
"SetControllerFocus(0x60000123)" (app com o foco do controle; 0x7 = tela do sistema/ShellUI) e
"VideoOut: shared (pid=0x5f, appId=0x60000123)". A ultima SetControllerFocus do buffer e o foco atual.
Codigo proprio. O que o sistema imprime pode mudar com o firmware: sem essas linhas, "sem sinal" (nada muda). */
#pragma once

#include <stddef.h>
#include <stdint.h>
#include "util.h"

#define FOCO_SISTEMA 0x7u   /* SetControllerFocus(0x7): ShellUI (menu, tela inicial) */

typedef struct {
  int lido;               /* 1 = o msgbuf foi lido */
  int erro;               /* errno quando nao leu */
  size_t bytes;           /* tamanho lido */
  int sinal;              /* 1 = achou SetControllerFocus(...) */
  uint32_t foco;          /* appId com o foco (vale com sinal) */
  int video;              /* 1 = achou "VideoOut: shared" */
  uint32_t video_pid, video_appid;   /* a ultima */
  int focos;              /* quantas linhas SetControllerFocus no buffer */
  char linha_foco[200], linha_video[200];   /* as ultimas, para o diagnostico */
} primeiro_plano_t;

/* Le o msgbuf agora. 0 = leu (veja .sinal); -1 = nao leu (.erro). */
int primeiro_plano_ler(primeiro_plano_t *pp);
/* Atalho: 1 = ha sinal e *foco recebe o appId; 0 = sem sinal (ou nao leu). */
int primeiro_plano_foco(uint32_t *foco);
/* Title ID de um appId (sceSystemServiceGetAppTitleId pelo watchdog). 0 = achou. */
int primeiro_plano_titulo(uint32_t appid, char *tid, size_t tam);
/* GET /api/primeiro-plano: {"ok":true,"lido":..,"sinal":..,"foco":"0x..","foco_tid":..,...} */
void primeiro_plano_json(buf_t *b);
