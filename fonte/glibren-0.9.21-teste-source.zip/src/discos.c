/* Game Library Renamer (payload PS5) - discos montados e teste de velocidade.

Teste: grava um arquivo temporario (".glr-teste-velocidade.tmp") na raiz do disco em blocos de 4 MB, com fsync no
fim (mede a gravacao de verdade, nao so o cache), e depois le de volta tentando nao usar o cache (O_DIRECT; se o
disco nao aceitar, le normal e avisa que a leitura pode ter vindo da memoria). O arquivo e apagado no fim, mesmo
cancelando. Um teste por vez; os resultados ficam guardados para comparar os discos.

Ejetar USB com seguranca (0.9.16; ideia do ps5-usb-manager de yibinsimon, GPL-3.0 - codigo reescrito):
- so /mnt/usb<numero> (lista positiva) e nunca um ponto da lista fixa de protegidos (/, /data, /user, /system*,
  /mnt/ext* = SSD interno e M.2/estendido, /dev, /preinst, /mnt/sandbox...);
- recusa com copia/mover/excluir na fila ou teste de velocidade rodando;
- sync(), depois desmonta as montagens nullfs cuja origem e o disco (vistas de apps em /mnt/sandbox), depois
  unmount(ponto, 0);
- se der EBUSY: lista quem esta com arquivos abertos no disco (sysctl KERN_PROC_FILEDESC) SEM encerrar nada;
  MNT_FORCE so com "forcar=1" (a pagina pede uma confirmacao explicita antes).
No PC (testes): montagens bind no lugar das nullfs (/proc/self/mountinfo), /proc/<pid>/fd no lugar do
KERN_PROC_FILEDESC e MNT_DETACH no lugar do MNT_FORCE (o Linux nao forca tmpfs).
*/
#include "discos.h"

#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#include <dirent.h>

#ifdef __PROSPERO__
#include <sys/mount.h>
#include <sys/param.h>
#include <sys/sysctl.h>
#include <sys/user.h>
#else
#include <mntent.h>
#include <sys/mount.h>
#endif

#include "config.h"
#include "plataforma.h"
#include "tarefas.h"

#define BLOCO (4 * 1024 * 1024)
#define NOME_TESTE ".glr-teste-velocidade.tmp"
#define MAX_RESULTADOS 32

typedef struct {
  char caminho[256];
  int tamanho_mb;
  double gravacao, leitura;     /* MB/s */
  int leitura_cache;            /* 1 = leitura pode ter vindo do cache */
  time_t quando;
} resultado_t;

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static int g_rodando;
static volatile int g_cancelar;
static char g_caminho[256], g_fase[16] = "", g_erro[200];
static long long g_total, g_feito;
static double g_velocidade, g_inicio_fase;
static resultado_t g_res[MAX_RESULTADOS];
static int g_qtd_res;

static double agora(void) {
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec / 1e6;
}

/* ------------------------------------------------------------------ discos montados */

/* So os discos de jogos/arquivos do usuario. tipo: "interno", "estendido", "usb". */
static const char *tipo_disco(const char *ponto) {
  if(!strcmp(ponto, "/data")) return "interno";
  if(!strncmp(ponto, "/mnt/ext", 8) && ponto[8] >= '0' && ponto[8] <= '9' && !ponto[9]) return "estendido";
  if(!strncmp(ponto, "/mnt/usb", 8) && ponto[8] >= '0' && ponto[8] <= '9' && !ponto[9]) return "usb";
#ifndef __PROSPERO__
  /* PC (demo): as pastas de teste montadas em tmpfs */
  if(!strcmp(ponto, "/data/homebrew")) return "interno";
  if(!strcmp(ponto, "/mnt/ext1/homebrew")) return "estendido";
#endif
  return NULL;
}

static void disco_json(buf_t *b, int *primeiro, const char *ponto, const char *fs) {
  const char *tipo = tipo_disco(ponto);
  struct statvfs v;
  if(!tipo || statvfs(ponto, &v)) return;
  buf_str(b, *primeiro ? "{\"caminho\":" : ",{\"caminho\":");
  *primeiro = 0;
  buf_json(b, ponto);
  buf_str(b, ",\"tipo\":");
  buf_json(b, tipo);
  buf_str(b, ",\"fs\":");
  buf_json(b, fs);
  buf_fmt(b, ",\"total\":%lld,\"livre\":%lld,\"gravavel\":%s}", (long long)v.f_blocks * (long long)v.f_frsize,
          (long long)v.f_bavail * (long long)v.f_frsize, access(ponto, W_OK) ? "false" : "true");
}

/* Chama "fn" com o ponto de montagem de cada disco do usuario. */
static void cada_disco(void (*fn)(const char *ponto)) {
#ifdef __PROSPERO__
  int n = getfsstat(NULL, 0, MNT_NOWAIT);
  struct statfs *lista = n > 0 ? calloc(n, sizeof *lista) : NULL;
  if(!lista) return;
  n = getfsstat(lista, n * sizeof *lista, MNT_NOWAIT);
  for(int i = 0; i < n; i++) {
    if(tipo_disco(lista[i].f_mntonname)) fn(lista[i].f_mntonname);
  }
  free(lista);
#else
  FILE *f = setmntent("/proc/mounts", "r");
  struct mntent *m;
  while(f && (m = getmntent(f))) {
    if(tipo_disco(m->mnt_dir)) fn(m->mnt_dir);
  }
  if(f) endmntent(f);
#endif
}

static void apagar_sobra(const char *ponto) {
  char arquivo[700];
  snprintf(arquivo, sizeof arquivo, "%s/%s", strcmp(ponto, "/data") ? ponto : g_pasta_dados, NOME_TESTE);
  if(!unlink(arquivo)) printf("teste de velocidade: sobra apagada em %s\n", arquivo);
}

void discos_limpar_sobras(void) {
  cada_disco(apagar_sobra);
}

void discos_listar(buf_t *b) {
  int primeiro = 1;
  buf_str(b, "{\"ok\":true,\"discos\":[");
#ifdef __PROSPERO__
  int n = getfsstat(NULL, 0, MNT_NOWAIT);
  struct statfs *lista = n > 0 ? calloc(n, sizeof *lista) : NULL;
  if(lista) {
    n = getfsstat(lista, n * sizeof *lista, MNT_NOWAIT);
    for(int i = 0; i < n; i++) disco_json(b, &primeiro, lista[i].f_mntonname, lista[i].f_fstypename);
    free(lista);
  }
#else
  FILE *f = setmntent("/proc/mounts", "r");
  struct mntent *m;
  while(f && (m = getmntent(f))) disco_json(b, &primeiro, m->mnt_dir, m->mnt_type);
  if(f) endmntent(f);
#endif
  buf_str(b, "]}");
}

/* ------------------------------------------------------------------ teste */

static void marcar(const char *fase, long long total) {
  pthread_mutex_lock(&g_trava);
  snprintf(g_fase, sizeof g_fase, "%s", fase);
  g_total = total;
  g_feito = 0;
  g_velocidade = 0;
  g_inicio_fase = agora();
  pthread_mutex_unlock(&g_trava);
}

static void avancou(long long n) {
#ifndef __PROSPERO__
  /* So no PC (demo): GLR_DEMO_MBPS limita a velocidade para dar para ver o teste andando. */
  static int limite = -1;
  if(limite < 0) limite = getenv("GLR_DEMO_MBPS") ? atoi(getenv("GLR_DEMO_MBPS")) : 0;
  if(limite > 0) usleep((useconds_t)((double)n / (limite * 1048576.0) * 1e6));
#endif
  pthread_mutex_lock(&g_trava);
  g_feito += n;
  double d = agora() - g_inicio_fase;
  if(d > 0.2) g_velocidade = g_feito / d / 1048576.0;
  pthread_mutex_unlock(&g_trava);
}

static void falhou(const char *fmt, const char *detalhe) {
  pthread_mutex_lock(&g_trava);
  snprintf(g_erro, sizeof g_erro, fmt, detalhe);
  pthread_mutex_unlock(&g_trava);
}

static void *testar(void *arg) {
  int tamanho_mb = (int)(long)arg;
  char arquivo[700];
  /* no SSD interno grava na pasta do app (mesmo disco que /data) */
  snprintf(arquivo, sizeof arquivo, "%s/%s", strcmp(g_caminho, "/data") ? g_caminho : g_pasta_dados, NOME_TESTE);
  long long total = (long long)tamanho_mb * 1048576;
  double gravacao = 0, leitura = 0;
  int cache = 0;
  char *buf = NULL;
  if(posix_memalign((void **)&buf, 4096, BLOCO)) buf = NULL;   /* O_DIRECT exige memoria alinhada */
  if(!buf) {
    falhou("sem memoria%s", "");
    goto fim;
  }
  for(int i = 0; i < BLOCO; i++) buf[i] = (char)(i * 131 + 7);   /* dados que nao comprimem a toa */

  /* gravacao */
  marcar("gravando", total);
  int fd = open(arquivo, O_WRONLY | O_CREAT | O_TRUNC, 0644);
  if(fd < 0) {
    falhou("nao conseguiu gravar no disco: %s", strerror(errno));
    goto fim;
  }
  double t0 = agora();
  for(long long feito = 0; feito < total && !g_cancelar;) {
    ssize_t w = write(fd, buf, BLOCO);
    if(w <= 0) {
      falhou("erro de gravacao: %s", errno == ENOSPC ? "disco cheio" : strerror(errno));
      break;
    }
    feito += w;
    avancou(w);
  }
  fsync(fd);
  gravacao = total / (agora() - t0) / 1048576.0;
  close(fd);
  if(g_cancelar || g_erro[0]) goto fim;

  /* leitura (tentando passar por fora do cache) */
  marcar("lendo", total);
#ifdef O_DIRECT
  fd = open(arquivo, O_RDONLY | O_DIRECT);
  if(fd < 0)
#endif
  {
    cache = 1;
    fd = open(arquivo, O_RDONLY);
#ifdef POSIX_FADV_DONTNEED
    if(fd >= 0 && !posix_fadvise(fd, 0, 0, POSIX_FADV_DONTNEED)) cache = 0;
#endif
  }
  if(fd < 0) {
    falhou("nao conseguiu ler: %s", strerror(errno));
    goto fim;
  }
  t0 = agora();
  long long lido = 0;
  while(lido < total && !g_cancelar) {
    ssize_t r = read(fd, buf, BLOCO);
    if(r < 0 && errno == EINVAL && !cache) {
      /* o disco nao aceitou leitura direta: le normal (pode vir do cache) */
      close(fd);
      fd = open(arquivo, O_RDONLY);
      cache = 1;
      lseek(fd, lido, SEEK_SET);
      continue;
    }
    if(r <= 0) break;
    lido += r;
    avancou(r);
  }
  leitura = lido / (agora() - t0) / 1048576.0;
  close(fd);
  if(g_cancelar) goto fim;

  pthread_mutex_lock(&g_trava);
  if(g_qtd_res == MAX_RESULTADOS) memmove(g_res, g_res + 1, sizeof *g_res * --g_qtd_res);
  resultado_t *res = &g_res[g_qtd_res++];
  snprintf(res->caminho, sizeof res->caminho, "%s", g_caminho);
  res->tamanho_mb = tamanho_mb;
  res->gravacao = gravacao;
  res->leitura = leitura;
  res->leitura_cache = cache;
  res->quando = time(NULL);
  pthread_mutex_unlock(&g_trava);

fim:
  unlink(arquivo);
  free(buf);
  pthread_mutex_lock(&g_trava);
  if(g_cancelar && !g_erro[0]) snprintf(g_erro, sizeof g_erro, "cancelado");
  g_fase[0] = 0;
  g_rodando = 0;
  pthread_mutex_unlock(&g_trava);
  return NULL;
}

int discos_testar(const char *caminho, int tamanho_mb, char *msg, size_t tam) {
  struct statvfs v;
  if(!caminho_valido(caminho) || !tipo_disco(caminho) || statvfs(caminho, &v)) {
    snprintf(msg, tam, "disco invalido");
    return -1;
  }
  /* arquivo grande o bastante para o cache do PS5 (16 GB de RAM) pesar pouco no resultado */
  if(tamanho_mb != 1024 && tamanho_mb != 2048 && tamanho_mb != 4096 && tamanho_mb != 8192) tamanho_mb = 4096;
  if((long long)v.f_bavail * (long long)v.f_frsize < (long long)tamanho_mb * 1048576 + 256LL * 1048576) {
    snprintf(msg, tam, "sem espaco livre para o teste");
    return -1;
  }
  pthread_mutex_lock(&g_trava);
  if(g_rodando) {
    pthread_mutex_unlock(&g_trava);
    snprintf(msg, tam, "ja tem um teste rodando");
    return -1;
  }
  g_rodando = 1;
  g_cancelar = 0;
  g_erro[0] = 0;
  snprintf(g_caminho, sizeof g_caminho, "%s", caminho);
  pthread_mutex_unlock(&g_trava);
  if(criar_thread(testar, (void *)(long)tamanho_mb, NULL)) {
    g_rodando = 0;
    snprintf(msg, tam, "nao iniciou o teste");
    return -1;
  }
  return 0;
}

void discos_cancelar(void) {
  g_cancelar = 1;
}

int discos_testando(void) {
  pthread_mutex_lock(&g_trava);
  int r = g_rodando;
  pthread_mutex_unlock(&g_trava);
  return r;
}

void discos_estado(buf_t *b) {
  pthread_mutex_lock(&g_trava);
  buf_fmt(b, "{\"ok\":true,\"rodando\":%s,\"caminho\":", g_rodando ? "true" : "false");
  buf_json(b, g_caminho);
  buf_str(b, ",\"fase\":");
  buf_json(b, g_fase);
  buf_fmt(b, ",\"total\":%lld,\"feito\":%lld,\"velocidade\":%.1f,\"erro\":", g_total, g_feito, g_velocidade);
  buf_json(b, g_erro);
  buf_str(b, ",\"resultados\":[");
  for(int i = 0; i < g_qtd_res; i++) {
    resultado_t *r = &g_res[i];
    buf_str(b, i ? ",{\"caminho\":" : "{\"caminho\":");
    buf_json(b, r->caminho);
    buf_fmt(b, ",\"tamanho_mb\":%d,\"gravacao\":%.1f,\"leitura\":%.1f,\"leitura_cache\":%s,\"quando\":%lld}", r->tamanho_mb,
            r->gravacao, r->leitura, r->leitura_cache ? "true" : "false", (long long)r->quando);
  }
  buf_str(b, "]}");
  pthread_mutex_unlock(&g_trava);
}

/* ------------------------------------------------------------------ ejetar USB (0.9.16) */

/* Pontos que nunca sao desmontados (alem da lista positiva /mnt/usbN abaixo). */
static const char *const PROTEGIDOS[] = {"/", "/data", "/user", "/dev", "/preinst", "/preinst2", "/hostapp", "/app0",
                                         "/mnt/sandbox", "/mnt/disc", "/mnt/pfs", "/update", "/usb", NULL};

static int protegido(const char *ponto) {
  for(int i = 0; PROTEGIDOS[i]; i++)
    if(!strcmp(ponto, PROTEGIDOS[i])) return 1;
  if(!strncmp(ponto, "/system", 7)) return 1;              /* /system, /system_ex, /system_data, /system_tmp */
  if(!strncmp(ponto, "/mnt/ext", 8)) return 1;             /* SSD interno (ext1) e estendido/M.2 (ext0, ext2...) */
  if(!strncmp(ponto, "/data/", 6) || !strncmp(ponto, "/user/", 6)) return 1;
  return 0;
}

/* So /mnt/usb + 1 ou 2 digitos, sem mais nada. */
static int usb_ejetavel(const char *ponto) {
  if(strncmp(ponto, "/mnt/usb", 8)) return 0;
  const char *d = ponto + 8;
  size_t n = strspn(d, "0123456789");
  return n >= 1 && n <= 2 && !d[n] && !protegido(ponto);
}

/* caminho dentro do disco: igual ao ponto ou ponto + "/..." */
static int dentro(const char *caminho, const char *ponto) {
  size_t n = strlen(ponto);
  return !strncmp(caminho, ponto, n) && (caminho[n] == 0 || caminho[n] == '/');
}

static int montado(const char *ponto) {
#ifdef __PROSPERO__
  int n = getfsstat(NULL, 0, MNT_NOWAIT), achou = 0;
  struct statfs *lista = n > 0 ? calloc(n, sizeof *lista) : NULL;
  if(!lista) return 0;
  n = getfsstat(lista, n * sizeof *lista, MNT_NOWAIT);
  for(int i = 0; i < n && !achou; i++) achou = !strcmp(lista[i].f_mntonname, ponto);
  free(lista);
  return achou;
#else
  FILE *f = setmntent("/proc/mounts", "r");
  struct mntent *m;
  int achou = 0;
  while(f && !achou && (m = getmntent(f))) achou = !strcmp(m->mnt_dir, ponto);
  if(f) endmntent(f);
  return achou;
#endif
}

static int desmontar(const char *ponto, int forcar) {
#ifdef __PROSPERO__
  return unmount(ponto, forcar ? MNT_FORCE : 0);
#else
  return umount2(ponto, forcar ? MNT_DETACH : 0);
#endif
}

/* Desmonta as vistas (nullfs no PS5, bind no PC) cuja origem e o disco. Cada resultado vai para o JSON. */
static int soltar_vistas(const char *ponto, int forcar, buf_t *b) {
  static char vistas[64][256];   /* so com g_trava_ejetar */
  int qtd = 0, soltas = 0;
#ifdef __PROSPERO__
  int n = getfsstat(NULL, 0, MNT_NOWAIT);
  struct statfs *lista = n > 0 ? calloc(n, sizeof *lista) : NULL;
  if(lista) {
    n = getfsstat(lista, n * sizeof *lista, MNT_NOWAIT);
    for(int i = 0; i < n && qtd < 64; i++) {
      if(strcmp(lista[i].f_fstypename, "nullfs") || !dentro(lista[i].f_mntfromname, ponto) || !strcmp(lista[i].f_mntonname, ponto))
        continue;
      snprintf(vistas[qtd++], sizeof vistas[0], "%s", lista[i].f_mntonname);
    }
    free(lista);
  }
#else
  /* mountinfo: id pai maior:menor raiz ponto ... ; vista = mesmo dispositivo, outro ponto (fora do disco) */
  char linha[1024], disp[32] = "";
  FILE *f = fopen("/proc/self/mountinfo", "r");
  while(f && fgets(linha, sizeof linha, f)) {
    char d[32], raiz[256], pt[256];
    if(sscanf(linha, "%*s %*s %31s %255s %255s", d, raiz, pt) == 3 && !strcmp(pt, ponto)) snprintf(disp, sizeof disp, "%s", d);
  }
  if(f) rewind(f);
  while(f && disp[0] && qtd < 64 && fgets(linha, sizeof linha, f)) {
    char d[32], raiz[256], pt[256];
    if(sscanf(linha, "%*s %*s %31s %255s %255s", d, raiz, pt) == 3 && !strcmp(d, disp) && strcmp(pt, ponto) && !dentro(pt, ponto))
      snprintf(vistas[qtd++], sizeof vistas[0], "%s", pt);
  }
  if(f) fclose(f);
#endif
  buf_str(b, "\"vistas\":[");
  for(int i = qtd - 1; i >= 0; i--) {   /* de tras para frente: as montadas por ultimo saem primeiro */
    int r = desmontar(vistas[i], 0);
    if(r && forcar) r = desmontar(vistas[i], 1);
    int e = r ? errno : 0;
    if(!r) soltas++;
    buf_str(b, i == qtd - 1 ? "{\"ponto\":" : ",{\"ponto\":");
    buf_json(b, vistas[i]);
    buf_fmt(b, ",\"ok\":%s,\"errno\":%d}", r ? "false" : "true", e);
    diario("ejetar: vista %s de %s: %s", vistas[i], ponto, r ? strerror(e) : "desmontada");
  }
  buf_str(b, "]");
  return soltas;
}

/* Quem esta com arquivos abertos no disco (nada e encerrado). */
static void ocupantes(const char *ponto, buf_t *b) {
  int qtd = 0, lidos = 0, varridos = 0;
  pid_t eu = getpid();
  buf_str(b, "\"ocupantes\":[");
#ifdef __PROSPERO__
  int mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_PROC, 0};
  size_t tam = 0;
  uint8_t *procs = NULL;
  if(!sysctl(mib, 4, NULL, &tam, NULL, 0) && tam) {
    tam += 16 * 1024;
    procs = malloc(tam);
    if(procs && sysctl(mib, 4, procs, &tam, NULL, 0)) tam = 0;
  }
  for(uint8_t *p = procs; procs && p + sizeof(struct kinfo_proc) <= procs + tam && qtd < 32;) {
    struct kinfo_proc *ki = (struct kinfo_proc *)p;
    if(ki->ki_structsize <= 0) break;
    p += ki->ki_structsize;
    if(ki->ki_pid <= 0) continue;
    varridos++;
    int mf[4] = {CTL_KERN, KERN_PROC, KERN_PROC_FILEDESC, ki->ki_pid};
    size_t tf = 0;
    if(sysctl(mf, 4, NULL, &tf, NULL, 0) || !tf) continue;
    uint8_t *fds = malloc(tf);
    if(!fds) continue;
    if(sysctl(mf, 4, fds, &tf, NULL, 0)) {
      free(fds);
      continue;
    }
    lidos++;
    for(uint8_t *q = fds; q + sizeof(int) <= fds + tf && qtd < 32;) {
      struct kinfo_file *kf = (struct kinfo_file *)q;
      if(kf->kf_structsize <= 0) break;
      q += kf->kf_structsize;
      if(!kf->kf_path[0] || !dentro(kf->kf_path, ponto)) continue;
      buf_str(b, qtd++ ? ",{\"pid\":" : "{\"pid\":");
      buf_fmt(b, "%d,\"nome\":", (int)ki->ki_pid);
      buf_json(b, ki->ki_comm);
      buf_str(b, ",\"arquivo\":");
      buf_json(b, kf->kf_path);
      buf_fmt(b, ",\"eu\":%s}", ki->ki_pid == eu ? "true" : "false");
    }
    free(fds);
  }
  free(procs);
#else
  DIR *d = opendir("/proc");
  struct dirent *e;
  while(d && qtd < 32 && (e = readdir(d))) {
    if(!(e->d_name[0] >= '1' && e->d_name[0] <= '9')) continue;
    varridos++;
    char pasta[300], nome[64] = "";
    snprintf(pasta, sizeof pasta, "/proc/%s/fd", e->d_name);
    DIR *fd = opendir(pasta);
    if(!fd) continue;
    lidos++;
    snprintf(pasta, sizeof pasta, "/proc/%s/comm", e->d_name);
    FILE *fc = fopen(pasta, "r");
    if(fc) {
      if(fgets(nome, sizeof nome, fc)) nome[strcspn(nome, "\n")] = 0;
      fclose(fc);
    }
    struct dirent *x;
    while(qtd < 32 && (x = readdir(fd))) {
      char link[600], alvo[1024];
      snprintf(link, sizeof link, "/proc/%s/fd/%s", e->d_name, x->d_name);
      ssize_t n = readlink(link, alvo, sizeof alvo - 1);
      if(n <= 0) continue;
      alvo[n] = 0;
      if(!dentro(alvo, ponto)) continue;
      buf_str(b, qtd++ ? ",{\"pid\":" : "{\"pid\":");
      buf_fmt(b, "%s,\"nome\":", e->d_name);
      buf_json(b, nome);
      buf_str(b, ",\"arquivo\":");
      buf_json(b, alvo);
      buf_fmt(b, ",\"eu\":%s}", atoi(e->d_name) == eu ? "true" : "false");
    }
    closedir(fd);
  }
  if(d) closedir(d);
#endif
  /* listas_lidas = 0: o sistema nao deixou ler as listas de arquivos abertos (a tela diz "nao deu para saber quem") */
  buf_fmt(b, "],\"processos\":%d,\"listas_lidas\":%d", varridos, lidos);
}

static pthread_mutex_t g_trava_ejetar = PTHREAD_MUTEX_INITIALIZER;

void discos_ejetar(const char *ponto, int forcar, buf_t *b) {
  if(!caminho_valido(ponto) || !usb_ejetavel(ponto)) {
    if(caminho_valido(ponto)) diario("ejetar: %s recusado (protegido ou nao e USB)", ponto);
    buf_str(b, "{\"ok\":false,\"chave\":\"ejetar_protegido\",\"erro\":\"so pendrive ou disco USB pode ser ejetado\",\"params\":{}}");
    return;
  }
  if(tarefas_ativas()) {
    buf_str(b, "{\"ok\":false,\"chave\":\"ejetar_tarefas\",\"erro\":\"espere as copias terminarem\",\"params\":{}}");
    return;
  }
  if(discos_testando()) {
    buf_str(b, "{\"ok\":false,\"chave\":\"ejetar_teste\",\"erro\":\"espere o teste de velocidade terminar\",\"params\":{}}");
    return;
  }
  if(pthread_mutex_trylock(&g_trava_ejetar)) {
    buf_str(b, "{\"ok\":false,\"chave\":\"ejetar_andamento\",\"erro\":\"ja esta ejetando\",\"params\":{}}");
    return;
  }
  if(!montado(ponto)) {
    pthread_mutex_unlock(&g_trava_ejetar);
    buf_str(b, "{\"ok\":false,\"chave\":\"ejetar_nao_montado\",\"erro\":\"o disco nao esta mais montado\",\"params\":{}}");
    return;
  }
  diario("ejetar: %s%s", ponto, forcar ? " (FORCADO, confirmado na tela)" : "");
  sync();
  buf_t vistas = {0};
  soltar_vistas(ponto, forcar, &vistas);
  sync();
  int r = desmontar(ponto, 0);
  int e = r ? errno : 0;
  if(r && forcar) {
    sync();
    r = desmontar(ponto, 1);
    e = r ? errno : 0;
  }
  if(!r) {
    diario("ejetar: %s desmontado - pode tirar o disco", ponto);
    buf_str(b, "{\"ok\":true,\"ejetado\":true,\"caminho\":");
    buf_json(b, ponto);
    buf_fmt(b, ",\"forcado\":%s,", forcar ? "true" : "false");
    buf_add(b, vistas.d, vistas.n);
    buf_str(b, "}");
  } else if(e == EBUSY) {
    diario("ejetar: %s ocupado (EBUSY)%s", ponto, forcar ? " mesmo forcando" : " - nada foi encerrado");
    buf_str(b, "{\"ok\":false,\"chave\":\"ejetar_ocupado\",\"erro\":\"o disco esta em uso\",\"params\":{},\"caminho\":");
    buf_json(b, ponto);
    buf_fmt(b, ",\"forcado\":%s,\"pode_forcar\":%s,", forcar ? "true" : "false", forcar ? "false" : "true");
    buf_add(b, vistas.d, vistas.n);
    buf_str(b, ",");
    ocupantes(ponto, b);
    buf_str(b, "}");
  } else {
    diario("ejetar: %s falhou: %s", ponto, strerror(e));
    buf_str(b, "{\"ok\":false,\"chave\":\"ejetar_falhou\",\"erro\":");
    buf_json(b, strerror(e));
    buf_fmt(b, ",\"errno\":%d,\"params\":{},", e);
    buf_add(b, vistas.d, vistas.n);
    buf_str(b, "}");
  }
  buf_free(&vistas);
  pthread_mutex_unlock(&g_trava_ejetar);
}
