/* Game Library Renamer (payload PS5) - DNS robusto (ver dns_resolver.h).

No PC (testes): GLR_TESTE_DNS_UDP e GLR_TESTE_DNS_TCP = "IP:porta" (um servidor so, no lugar da lista),
GLR_TESTE_DOH_URL = URL do DoH (no lugar dos dois) e GLR_TESTE_DOH_CA = arquivo PEM (no lugar das raizes embutidas). */
#include "dns_resolver.h"

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <poll.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#include "config.h"
#include "https.h"
#include "plataforma.h"

#define TTL_POSITIVO_S 600
#define TTL_NEGATIVO_S 20
#define ESPERA_UDP_MS 1200
#define ESPERA_TCP_MS 2000
#define MAX_CACHE 32
#define MAX_RESP 1500

static const char *const ROBUSTOS[] = {
  "raw.githubusercontent.com", "github.com", "release-assets.githubusercontent.com", "objects.githubusercontent.com", "codeload.github.com", "api.github.com",
  "prosperopatches.com", "cdn.prosperopatches.com", "orbispatches.com", "cdn.orbispatches.com", NULL};
static const char *const UDP[] = {"1.1.1.1", "8.8.8.8", "9.9.9.9", NULL};
static const char *const TCP[] = {"1.1.1.1", "8.8.8.8", NULL};

/* Trava a mais (a lista acima ja e fechada): nada da Sony passa por aqui. */
static int host_sony(const char *h) {
  static const char *const SUFIXOS[] = {"playstation.com", "playstation.net", "sonyentertainmentnetwork.com", "sony.com",
                                        "sony.net", "scea.com", "psn.com", NULL};
  size_t n = strlen(h);
  for(int i = 0; SUFIXOS[i]; i++) {
    size_t k = strlen(SUFIXOS[i]);
    if(n >= k && !strcasecmp(h + n - k, SUFIXOS[i]) && (n == k || h[n - k - 1] == '.')) return 1;
  }
  return 0;
}

int dns_host_robusto(const char *host) {
  if(!host || host_sony(host)) return 0;
  for(int i = 0; ROBUSTOS[i]; i++)
    if(!strcasecmp(host, ROBUSTOS[i])) return 1;
  return 0;
}

/* ------------------------------------------------------------------ cache (memoria + arquivo) */

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static struct {
  char host[128], ip[48];
  time_t ate;
  int negativo;
} g_cache[MAX_CACHE];
static int g_carregado;

static void arquivo_cache(char *s, size_t t) {
  snprintf(s, t, "%s/dns_cache.txt", g_pasta_dados);
}

/* Lugar do host (ou o mais velho). Chamar com g_trava. */
static int lugar(const char *host) {
  int livre = 0;
  for(int i = 0; i < MAX_CACHE; i++) {
    if(!strcasecmp(g_cache[i].host, host)) return i;
    if(g_cache[i].ate < g_cache[livre].ate) livre = i;
  }
  return livre;
}

static void guardar(const char *host, const char *ip, int negativo, time_t ate) {
  int i = lugar(host);
  snprintf(g_cache[i].host, sizeof g_cache[i].host, "%s", host);
  snprintf(g_cache[i].ip, sizeof g_cache[i].ip, "%s", ip);
  g_cache[i].ate = ate;
  g_cache[i].negativo = negativo;
}

/* Chamar com g_trava. Le os positivos ainda validos do arquivo (uma vez). */
static void carregar(void) {
  if(g_carregado) return;
  g_carregado = 1;
  char nome[600], linha[300];
  arquivo_cache(nome, sizeof nome);
  FILE *f = fopen(nome, "r");
  if(!f) return;
  time_t agora = time(NULL);
  while(fgets(linha, sizeof linha, f)) {
    char host[128], ip[48];
    long long ate;
    struct in_addr a;
    if(sscanf(linha, "%127s %47s %lld", host, ip, &ate) == 3 && dns_host_robusto(host) && inet_pton(AF_INET, ip, &a) == 1 &&
       ate > agora && ate <= agora + TTL_POSITIVO_S)
      guardar(host, ip, 0, (time_t)ate);
  }
  fclose(f);
}

/* Chamar com g_trava. So os positivos validos; .tmp + rename. */
static void gravar(void) {
  char nome[600], tmp[610];
  arquivo_cache(nome, sizeof nome);
  snprintf(tmp, sizeof tmp, "%s.tmp", nome);
  FILE *f = fopen(tmp, "w");
  if(!f) return;
  time_t agora = time(NULL);
  for(int i = 0; i < MAX_CACHE; i++)
    if(g_cache[i].host[0] && !g_cache[i].negativo && g_cache[i].ate > agora)
      fprintf(f, "%s %s %lld\n", g_cache[i].host, g_cache[i].ip, (long long)g_cache[i].ate);
  if(fclose(f) || rename(tmp, nome)) unlink(tmp);
}

/* ------------------------------------------------------------------ mensagem DNS */

/* Pergunta tipo A. Devolve o tamanho ou -1. */
static int montar(const char *host, uint16_t id, uint8_t *q, size_t max) {
  size_t n = 0;
  if(max < 18) return -1;
  q[n++] = id >> 8;
  q[n++] = id & 0xff;
  q[n++] = 0x01;   /* recursao */
  q[n++] = 0x00;
  q[n++] = 0x00;
  q[n++] = 0x01;   /* uma pergunta */
  memset(q + n, 0, 6);
  n += 6;
  for(const char *p = host; *p;) {
    size_t r = strcspn(p, ".");
    if(!r || r > 63 || n + r + 6 > max) return -1;
    q[n++] = (uint8_t)r;
    memcpy(q + n, p, r);
    n += r;
    p += r;
    if(*p == '.') p++;
  }
  q[n++] = 0;
  q[n++] = 0;
  q[n++] = 1;   /* A */
  q[n++] = 0;
  q[n++] = 1;   /* IN */
  return (int)n;
}

/* Endereco que nao serve (sinkhole de DNS bloqueado): 0/8, 10/8, 127/8, 169.254/16, 172.16/12, 192.168/16. */
static int endereco_ruim(const uint8_t *a) {
  return a[0] == 0 || a[0] == 10 || a[0] == 127 || (a[0] == 169 && a[1] == 254) || (a[0] == 172 && (a[1] & 0xf0) == 16) ||
         (a[0] == 192 && a[1] == 168) || a[0] >= 224;
}

/* Pula um nome (com compressao). Devolve a posicao depois dele ou -1. */
static int pular_nome(const uint8_t *r, int n, int pos) {
  while(pos < n) {
    if((r[pos] & 0xc0) == 0xc0) return pos + 2 <= n ? pos + 2 : -1;
    if(!r[pos]) return pos + 1;
    pos += r[pos] + 1;
  }
  return -1;
}

/* Resposta -> primeiro A bom. 0 = achou; 1 = truncada (TC); -1 = sem resposta util. */
static int ler_resposta(const uint8_t *r, int n, uint16_t id, char *ip, size_t tam) {
  if(n < 12 || ((r[0] << 8) | r[1]) != id || !(r[2] & 0x80)) return -1;
  if(r[2] & 0x02) return 1;
  if((r[3] & 0x0f) != 0) return -1;   /* NXDOMAIN, SERVFAIL, REFUSED... */
  int perguntas = (r[4] << 8) | r[5], respostas = (r[6] << 8) | r[7], pos = 12;
  for(int i = 0; i < perguntas; i++) {
    pos = pular_nome(r, n, pos);
    if(pos < 0 || pos + 4 > n) return -1;
    pos += 4;
  }
  int ruins = 0;
  for(int i = 0; i < respostas; i++) {
    pos = pular_nome(r, n, pos);
    if(pos < 0 || pos + 10 > n) return -1;
    int tipo = (r[pos] << 8) | r[pos + 1], comp = (r[pos + 8] << 8) | r[pos + 9];
    pos += 10;
    if(pos + comp > n) return -1;
    if(tipo == 1 && comp == 4) {
      if(endereco_ruim(r + pos)) ruins++;
      else {
        snprintf(ip, tam, "%u.%u.%u.%u", r[pos], r[pos + 1], r[pos + 2], r[pos + 3]);
        return 0;
      }
    }
    pos += comp;
  }
  if(ruins) diario("dns: resposta so com enderecos bloqueados (%d) - ignorada", ruins);
  return -1;
}

/* "IP" ou "IP:porta" -> endereco (porta padrao 53). */
static int endereco(const char *s, struct sockaddr_in *e) {
  char ip[48];
  int porta = 53;
  memset(e, 0, sizeof *e);
  snprintf(ip, sizeof ip, "%s", s);
  char *dp = strchr(ip, ':');
  if(dp) {
    *dp = 0;
    porta = atoi(dp + 1);
  }
  e->sin_family = AF_INET;
  e->sin_port = htons((uint16_t)porta);
  return inet_pton(AF_INET, ip, &e->sin_addr) == 1 && porta > 0 && porta < 65536 ? 0 : -1;
}

static const char *teste(const char *var) {
#ifndef __PROSPERO__
  const char *v = getenv(var);
  if(v && *v) return v;
#else
  (void)var;
#endif
  return NULL;
}

/* 0 = achou; 1 = alguma resposta veio truncada; -1 = nada. */
static int por_udp(const char *host, char *ip, size_t tam) {
  const char *um[] = {teste("GLR_TESTE_DNS_UDP"), NULL};
  const char *const *lista = um[0] ? um : UDP;
  int truncada = 0;
  for(int s = 0; lista[s]; s++) {
    uint8_t q[512], r[MAX_RESP];
    uint16_t id = (uint16_t)arc4random();
    int nq = montar(host, id, q, sizeof q);
    struct sockaddr_in e;
    if(nq < 0 || endereco(lista[s], &e)) return -1;
    int fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if(fd < 0) continue;
    struct timeval espera = {.tv_sec = ESPERA_UDP_MS / 1000, .tv_usec = (ESPERA_UDP_MS % 1000) * 1000};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &espera, sizeof espera);
    ssize_t n = -1;
    if(!connect(fd, (struct sockaddr *)&e, sizeof e) && send(fd, q, (size_t)nq, 0) == nq) n = recv(fd, r, sizeof r, 0);
    close(fd);
    if(n <= 0) continue;
    int v = ler_resposta(r, (int)n, id, ip, tam);
    if(!v) return 0;
    if(v == 1) truncada = 1;
  }
  return truncada ? 1 : -1;
}

/* connect com prazo (socket nao bloqueante + poll). */
static int conectar(int fd, const struct sockaddr_in *e, int ms) {
  int fl = fcntl(fd, F_GETFL, 0);
  fcntl(fd, F_SETFL, fl | O_NONBLOCK);
  int r = connect(fd, (const struct sockaddr *)e, sizeof *e);
  if(r && errno == EINPROGRESS) {
    struct pollfd p = {.fd = fd, .events = POLLOUT};
    int erro = 0;
    socklen_t te = sizeof erro;
    r = (poll(&p, 1, ms) == 1 && !getsockopt(fd, SOL_SOCKET, SO_ERROR, &erro, &te) && !erro) ? 0 : -1;
  }
  fcntl(fd, F_SETFL, fl);
  return r;
}

static int ler_tudo(int fd, uint8_t *d, size_t n) {
  size_t feito = 0;
  while(feito < n) {
    ssize_t r = recv(fd, d + feito, n - feito, 0);
    if(r < 0 && errno == EINTR) continue;
    if(r <= 0) return -1;
    feito += (size_t)r;
  }
  return 0;
}

static int por_tcp(const char *host, char *ip, size_t tam) {
  const char *um[] = {teste("GLR_TESTE_DNS_TCP"), NULL};
  const char *const *lista = um[0] ? um : TCP;
  for(int s = 0; lista[s]; s++) {
    uint8_t q[514], r[MAX_RESP];
    uint16_t id = (uint16_t)arc4random();
    int nq = montar(host, id, q + 2, sizeof q - 2);
    struct sockaddr_in e;
    if(nq < 0 || endereco(lista[s], &e)) return -1;
    q[0] = (uint8_t)(nq >> 8);
    q[1] = (uint8_t)nq;
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if(fd < 0) continue;
    struct timeval espera = {.tv_sec = ESPERA_TCP_MS / 1000, .tv_usec = (ESPERA_TCP_MS % 1000) * 1000};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &espera, sizeof espera);
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &espera, sizeof espera);
#ifdef SO_NOSIGPIPE
    setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &(int){1}, sizeof(int));
#endif
    uint8_t tam_r[2];
    int ok = !conectar(fd, &e, ESPERA_TCP_MS) && send(fd, q, (size_t)nq + 2, 0) == nq + 2 && !ler_tudo(fd, tam_r, 2);
    int n = ok ? (tam_r[0] << 8) | tam_r[1] : 0;
    if(ok && (n < 12 || n > MAX_RESP || ler_tudo(fd, r, (size_t)n))) ok = 0;
    close(fd);
    if(ok && !ler_resposta(r, n, id, ip, tam)) return 0;
  }
  return -1;
}

static int por_doh(const char *host, char *ip, size_t tam) {
  static const struct {
    const char *nome, *ip;
  } DOH[] = {{"cloudflare-dns.com", "1.1.1.1"}, {"dns.google", "8.8.8.8"}, {NULL, NULL}};
  const char *url_teste = teste("GLR_TESTE_DOH_URL");
  for(int s = 0; DOH[s].nome; s++) {
    uint8_t q[512], r[MAX_RESP];
    int nq = montar(host, 0, q, sizeof q);   /* RFC 8484: id 0 (ajuda o cache HTTP) */
    if(nq < 0) return -1;
    int n = url_teste ? https_doh(url_teste, NULL, NULL, q, (size_t)nq, r, sizeof r)
                      : https_doh(NULL, DOH[s].nome, DOH[s].ip, q, (size_t)nq, r, sizeof r);
    if(n > 0 && !ler_resposta(r, n, 0, ip, tam)) return 0;
    if(url_teste) break;
  }
  return -1;
}

/* ------------------------------------------------------------------ resolver */

int dns_resolver(const char *host, char *ip, size_t tam, const char **fonte) {
  const char *f = "";
  if(fonte) *fonte = f;
  if(!dns_host_robusto(host)) return -2;
  time_t agora = time(NULL);
  pthread_mutex_lock(&g_trava);
  carregar();
  for(int i = 0; i < MAX_CACHE; i++) {
    if(strcasecmp(g_cache[i].host, host) || g_cache[i].ate <= agora) continue;
    int neg = g_cache[i].negativo;
    if(!neg) snprintf(ip, tam, "%s", g_cache[i].ip);
    pthread_mutex_unlock(&g_trava);
    if(fonte) *fonte = neg ? "negativo" : "cache";
    return neg ? -1 : 0;
  }
  pthread_mutex_unlock(&g_trava);

  char achado[48] = "";
  int r = por_udp(host, achado, sizeof achado);
  f = "udp";
  if(r) {   /* sem resposta ou truncada: TCP */
    r = por_tcp(host, achado, sizeof achado);
    f = "tcp";
  }
  if(r) {
    r = por_doh(host, achado, sizeof achado);
    f = "doh";
  }
  pthread_mutex_lock(&g_trava);
  if(!r) {
    guardar(host, achado, 0, time(NULL) + TTL_POSITIVO_S);
    gravar();
  } else {
    guardar(host, "", 1, time(NULL) + TTL_NEGATIVO_S);
  }
  pthread_mutex_unlock(&g_trava);
  if(r) {
    diario("dns: %s nao resolveu (udp, tcp e doh) - tenta de novo em %d s", host, TTL_NEGATIVO_S);
    if(fonte) *fonte = "falhou";
    return -1;
  }
  diario("dns: %s -> %s (%s)", host, achado, f);
  snprintf(ip, tam, "%s", achado);
  if(fonte) *fonte = f;
  return 0;
}

void dns_json(const char *host, buf_t *b) {
  char ip[48] = "";
  const char *fonte = "";
  int r = dns_resolver(host, ip, sizeof ip, &fonte);
  buf_fmt(b, "{\"ok\":%s,\"host\":", r ? "false" : "true");
  buf_json(b, host);
  buf_str(b, ",\"ip\":");
  buf_json(b, ip);
  buf_str(b, ",\"fonte\":");
  buf_json(b, r == -2 ? "fora_da_lista" : fonte);
  buf_str(b, "}");
}
