/* Game Library Renamer (payload PS5) - notificacao, IP, permissoes, diario e icone na aba Midia.

No PS5, ao iniciar (como fazem o ProsperoMgr e o websrv):
- eleva as permissoes do proprio processo (uid 0, sistema de arquivos inteiro, authid de app de sistema);
- da o nome "glibren.elf" ao processo e encerra copias antigas com o mesmo nome;
- registra num diario (/data/GameLibraryRenamer/glibren.log) os passos e qualquer queda (sinal fatal),
  e avisa na tela do PS5 se o processo cair;
- instala o icone na aba Midia (/user/app/PMGL00001), que abre http://127.0.0.1:8765 - o proprio payload,
  sem depender do websrv. Se o payload nao estiver rodando, o icone abre uma pagina de erro (igual ao ProsperoMgr).
*/
#include "plataforma.h"

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <ifaddrs.h>
#include <netinet/in.h>
#include <pthread.h>
#include <signal.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "util.h"

static char g_diario[512];
static pthread_mutex_t g_trava_diario = PTHREAD_MUTEX_INITIALIZER;

#ifdef __PROSPERO__
#include <sys/syscall.h>
#include <sys/sysctl.h>
#include <ps5/kernel.h>

typedef struct {
  char reservado[45];
  char mensagem[3075];
} pedido_notificacao_t;

int sceKernelSendNotificationRequest(int, pedido_notificacao_t *, size_t, int);
int sceUserServiceInitialize(void *);
int sceAppInstUtilInitialize(void);
int sceAppInstUtilAppInstallAll(void *);
int sceAppInstUtilAppUnInstall(const char *);

/* Abrir outro app (modelo: websrv src/ps5/sys.c). weak: se o firmware nao tiver a funcao, o payload carrega mesmo
   assim e a chamada vira NULL (tratado). NUNCA usar sceSystemServiceKillApp: fecharia o jogo do usuario. */
typedef struct {
  uint32_t structsize;
  uint32_t user_id;
  uint32_t app_opt;
  uint64_t crash_report;
  uint32_t check_flag;
} contexto_app_t;
int sceUserServiceGetForegroundUser(uint32_t *) __attribute__((weak));
int sceSystemServiceLaunchApp(const char *, char **, contexto_app_t *) __attribute__((weak));

/* Energia, como o menu de energia do PS5 (libSceSystemService; os dois sem argumentos). Mesmas chamadas do
   shsrv (comando suspend, john-tornblom), do etaHEN (Byepervisor) e do ps5-homeassistant (rest/power off).
   NAO e o syscall reboot(): esse corta sem avisar o sistema. weak: firmware sem a funcao -> NULL (tratado). */
int sceSystemStateMgrTurnOff(void) __attribute__((weak));
int sceSystemStateMgrEnterStandby(void) __attribute__((weak));

#define NOME_PROCESSO "glibren.elf"
#define TITULO GLIBREN_TITLE_ID
#define PASTA_APP "/user/app/" TITULO

/* Icone embutido no .elf */
__asm__(".section .rodata\n.global icone_midia\n.global icone_midia_tam\n.align 16\nicone_midia:\n"
        ".incbin \"instalador/icon0.png\"\nicone_midia_fim:\n.align 8\nicone_midia_tam:\n"
        ".quad icone_midia_fim - icone_midia\n.previous\n");
extern const uint8_t icone_midia[];
extern const uint64_t icone_midia_tam;

/* Mesmo esquema do ProsperoMgr/websrv: o processo vira "app de sistema" com acesso a tudo. */
static int elevar_permissoes(void) {
  pid_t pid = getpid();
  int falhas = 0;
  falhas += kernel_set_ucred_uid(pid, 0) != 0;
  falhas += kernel_set_ucred_ruid(pid, 0) != 0;
  falhas += kernel_set_ucred_svuid(pid, 0) != 0;
  falhas += kernel_set_ucred_rgid(pid, 0) != 0;
  falhas += kernel_set_ucred_svgid(pid, 0) != 0;
  intptr_t raiz = kernel_get_root_vnode();
  if(raiz) {
    falhas += kernel_set_proc_rootdir(pid, raiz) != 0;   /* ve /data, /mnt/ext1, /mnt/usb0... */
    falhas += kernel_set_proc_jaildir(pid, raiz) != 0;
  }
  falhas += kernel_set_ucred_authid(pid, 0x4801000000000013ULL) != 0;
  uint8_t caps[16];
  memset(caps, 0xff, sizeof caps);
  falhas += kernel_set_ucred_caps(pid, caps) != 0;
  uint8_t attrs[32] = {0x80};
  falhas += kernel_set_ucred_attrs(pid, attrs) != 0;
  return falhas;
}

/* pid de outro processo com o nome dado (lista de processos do kernel: kinfo_proc). */
static pid_t achar_processo(const char *nome) {
  int mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_PROC, 0};
  size_t tam = 0;
  pid_t eu = getpid(), achado = -1;
  if(sysctl(mib, 4, NULL, &tam, NULL, 0) || !tam) return -1;
  tam += 16 * 1024;
  uint8_t *b = malloc(tam);
  if(!b) return -1;
  if(!sysctl(mib, 4, b, &tam, NULL, 0)) {
    for(uint8_t *p = b; p + 4 <= b + tam;) {
      int estrutura = *(int *)p;
      if(estrutura <= 0) break;
      pid_t pid = *(pid_t *)(p + 72);              /* ki_pid */
      const char *nome_thread = (const char *)(p + 447);   /* ki_tdname */
      if(pid != eu && !strncmp(nome_thread, nome, 16)) achado = pid;
      p += estrutura;
    }
  }
  free(b);
  return achado;
}

static void encerrar_copias_antigas(void) {
  pid_t pid;
  for(int i = 0; i < 20 && (pid = achar_processo(NOME_PROCESSO)) > 0; i++) {
    diario("encerrando copia antiga (pid %d)", (int)pid);
    kill(pid, SIGKILL);
    usleep(300000);
  }
}

static volatile sig_atomic_t g_desligando;   /* pedido de energia em andamento: SIGTERM do sistema e esperado */

static void ao_cair(int sinal) {
  /* so funcoes seguras dentro de um sinal: open/write/_exit */
  if(g_desligando && sinal == SIGTERM) _exit(0);   /* o sistema encerrando os processos ao desligar: sem aviso de queda */
  char linha[96];
  int n = snprintf(linha, sizeof linha, "QUEDA: sinal %d\n", sinal);
  int fd = open(g_diario, O_WRONLY | O_CREAT | O_APPEND, 0644);
  if(fd >= 0) {
    write(fd, linha, n);
    close(fd);
  }
  pedido_notificacao_t req;
  memset(&req, 0, sizeof req);
  snprintf(req.mensagem, sizeof req.mensagem, "Game Library Renamer parou (sinal %d). Veja glibren.log", sinal);
  sceKernelSendNotificationRequest(0, &req, sizeof req, 0);
  _exit(128 + sinal);
}

static int gravar_arquivo(const char *caminho, const void *dados, size_t tam) {
  FILE *f = fopen(caminho, "wb");
  if(!f) return -1;
  int ok = fwrite(dados, 1, tam, f) == tam;
  return (fclose(f) || !ok) ? -1 : 0;
}

static int arquivo_igual(const char *caminho, const char *conteudo) {
  FILE *f = fopen(caminho, "rb");
  if(!f) return 0;
  char b[1024];
  size_t n = fread(b, 1, sizeof b - 1, f);
  fclose(f);
  b[n] = 0;
  return !strcmp(b, conteudo);
}

/* Registra so este titulo (sceAppInstUtilAppInstallTitleDir, achada pelo NID, como no websrv); reserva: todos. */
static int registrar_titulo(void) {
  int (*instalar_pasta)(const char *, const char *, void *) = 0;
  uint32_t handle;
  if(!kernel_dynlib_handle(-1, "libSceAppInstUtil.sprx", &handle))
    instalar_pasta = (void *)kernel_dynlib_resolve(-1, handle, "Wudg3Xe3heE");
  if(instalar_pasta) return instalar_pasta(TITULO, "/user/app/", 0);
  return sceAppInstUtilAppInstallAll(0);
}

static void *instalar_icone(void *arg) {
  int porta = (int)(intptr_t)arg;
  char param[1024];
  /* applicationCategoryType 65536 = app de midia: o icone fica na aba Midia, nao em Jogos (o tile do
     ProsperoMgr usa esse valor). Mudou o conteudo: o payload reinstala o icone sozinho. */
  snprintf(param, sizeof param,
           "{\n"
           "    \"titleId\": \"" TITULO "\",\n"
           "    \"applicationCategoryType\": 65536,\n"
           "    \"deeplinkUri\": \"http://127.0.0.1:%d/\",\n"
           "    \"localizedParameters\": {\n"
           "        \"defaultLanguage\": \"en-US\",\n"
           "        \"en-US\": {\n"
           "            \"titleName\": \"Game Library Renamer\"\n"
           "        }\n"
           "    }\n"
           "}\n",
           porta);
  struct stat st;
  int instalado = !stat("/user/appmeta/" TITULO, &st);
  if(instalado && arquivo_igual(PASTA_APP "/sce_sys/param.json", param)) {
    diario("icone ja instalado");
    return NULL;
  }
  int r = sceAppInstUtilInitialize();
  if(r) {
    diario("icone: sceAppInstUtilInitialize falhou 0x%08x", (unsigned)r);
    notificar("Game Library Renamer: nao foi possivel criar o icone (0x%08x)", (unsigned)r);
    return NULL;
  }
  if(instalado) {   /* versao antiga (ex.: do glibren-install.elf, que abria pelo websrv) */
    r = sceAppInstUtilAppUnInstall(TITULO);
    diario("icone antigo removido: 0x%08x", (unsigned)r);
  }
  if((mkdir(PASTA_APP, 0755) && errno != EEXIST) || (mkdir(PASTA_APP "/sce_sys", 0755) && errno != EEXIST) ||
     gravar_arquivo(PASTA_APP "/sce_sys/param.json", param, strlen(param)) ||
     gravar_arquivo(PASTA_APP "/sce_sys/icon0.png", icone_midia, icone_midia_tam)) {
    diario("icone: falha ao gravar em " PASTA_APP ": %s", strerror(errno));
    notificar("Game Library Renamer: nao foi possivel gravar o icone");
    return NULL;
  }
  r = registrar_titulo();
  diario("icone: registro 0x%08x", (unsigned)r);
  if(r) notificar("Game Library Renamer: falha ao registrar o icone (0x%08x)", (unsigned)r);
  else notificar("Game Library Renamer: icone criado na aba Midia");
  return NULL;
}
#endif

void plataforma_iniciar(const char *pasta_dados) {
  mkdir_p(pasta_dados);
  snprintf(g_diario, sizeof g_diario, "%s/glibren.log", pasta_dados);
  /* diario pequeno: passou de 256 KB, comeca de novo */
  struct stat st;
  if(!stat(g_diario, &st) && st.st_size > 256 * 1024) unlink(g_diario);

  signal(SIGPIPE, SIG_IGN);   /* navegador fechou a conexao no meio: send() devolve erro em vez de matar o processo */
  signal(SIGHUP, SIG_IGN);
#ifdef __PROSPERO__
  int falhas = elevar_permissoes();
  syscall(SYS_thr_set_name, -1, NOME_PROCESSO);
  diario("iniciando (permissoes: %d falha(s))", falhas);
  encerrar_copias_antigas();
  sceUserServiceInitialize(0);
  static const int sinais[] = {SIGSEGV, SIGBUS, SIGFPE, SIGILL, SIGABRT, SIGTRAP, SIGSYS, SIGTERM};
  for(size_t s = 0; s < sizeof sinais / sizeof *sinais; s++) signal(sinais[s], ao_cair);
#else
  diario("iniciando (PC)");
#endif
}

void plataforma_nome(const char *nome) {
#ifdef __PROSPERO__
  syscall(SYS_thr_set_name, -1, nome ? nome : NOME_PROCESSO);
#else
  (void)nome;
#endif
}

void plataforma_encerrar_copias(void) {
#ifdef __PROSPERO__
  encerrar_copias_antigas();
#endif
}

void plataforma_instalar_icone(int porta) {
#ifdef __PROSPERO__
  criar_thread(instalar_icone, (void *)(intptr_t)porta, NULL);
#else
  (void)porta;
#endif
}

void diario(const char *fmt, ...) {
  if(!g_diario[0]) return;
  char linha[1024];
  time_t agora = time(NULL);
  struct tm t;
  localtime_r(&agora, &t);
  int n = strftime(linha, sizeof linha, "%d/%m %H:%M:%S ", &t);
  va_list args;
  va_start(args, fmt);
  vsnprintf(linha + n, sizeof linha - n - 1, fmt, args);
  va_end(args);
  strcat(linha, "\n");
  pthread_mutex_lock(&g_trava_diario);
  FILE *f = fopen(g_diario, "a");
  if(f) {
    fputs(linha, f);
    fclose(f);
  }
  pthread_mutex_unlock(&g_trava_diario);
}

void notificar(const char *fmt, ...) {
  va_list args;
#ifdef __PROSPERO__
  pedido_notificacao_t req;
  memset(&req, 0, sizeof req);
  va_start(args, fmt);
  vsnprintf(req.mensagem, sizeof req.mensagem, fmt, args);
  va_end(args);
  sceKernelSendNotificationRequest(0, &req, sizeof req, 0);
  puts(req.mensagem);
#else
  va_start(args, fmt);
  vprintf(fmt, args);
  va_end(args);
  putchar('\n');
  fflush(stdout);
#endif
}

int abrir_app(const char *title_id) {
#ifdef __PROSPERO__
  if(!sceSystemServiceLaunchApp || !sceUserServiceGetForegroundUser) {
    diario("abrir app %s: firmware sem sceSystemServiceLaunchApp/GetForegroundUser", title_id);
    return -1;
  }
  contexto_app_t ctx;
  memset(&ctx, 0, sizeof ctx);
  int r = sceUserServiceGetForegroundUser(&ctx.user_id);
  if(r) {
    diario("abrir app %s: sceUserServiceGetForegroundUser 0x%08x", title_id, (unsigned)r);
    return r;
  }
  char *argv[] = {NULL};
  /* structsize 0 como o websrv (funciona no PS5 real); se recusar, tenta com o tamanho da estrutura */
  r = sceSystemServiceLaunchApp(title_id, argv, &ctx);
  diario("abrir app %s: sceSystemServiceLaunchApp (usuario 0x%08x, structsize 0) = 0x%08x", title_id, ctx.user_id, (unsigned)r);
  if(r < 0) {
    ctx.structsize = sizeof ctx;
    r = sceSystemServiceLaunchApp(title_id, argv, &ctx);
    diario("abrir app %s: sceSystemServiceLaunchApp (structsize %u) = 0x%08x", title_id, ctx.structsize, (unsigned)r);
  }
  return r < 0 ? r : 0;
#else
  /* teste: GLR_TESTE_LANCAR_FALHAS = arquivo com N; as proximas N chamadas falham como o PS5 (0x80940011) */
  const char *arq = getenv("GLR_TESTE_LANCAR_FALHAS");
  FILE *f = arq && *arq ? fopen(arq, "r+") : NULL;
  if(f) {
    int n = 0;
    if(fscanf(f, "%d", &n) == 1 && n > 0) {
      rewind(f);
      fprintf(f, "%d \n", n - 1);
      fclose(f);
      diario("abrir app (PC): falha simulada ao abrir %s", title_id);
      return (int)0x80940011;
    }
    fclose(f);
  }
  diario("abrir app (PC): abriria o app %s", title_id);
  return 0;
#endif
}

int meu_ip(char *saida, size_t tam) {
  struct ifaddrs *lista;
  int achou = -1;
  if(getifaddrs(&lista)) return -1;
  for(struct ifaddrs *i = lista; i && achou; i = i->ifa_next) {
    if(!i->ifa_addr || i->ifa_addr->sa_family != AF_INET || !strncmp(i->ifa_name, "lo", 2)) continue;
    struct sockaddr_in *in = (struct sockaddr_in *)i->ifa_addr;
    inet_ntop(AF_INET, &in->sin_addr, saida, tam);
    if(strncmp(saida, "0.", 2) && strncmp(saida, "127.", 4)) achou = 0;
  }
  freeifaddrs(lista);
  return achou;
}

/* ======================= Energia: desligar / modo de repouso ======================= */
#define ESPERA_ENERGIA 3   /* segundos: a resposta chega ao navegador (e a tela mostra o aviso) antes de desligar */

static pthread_mutex_t g_trava_energia = PTHREAD_MUTEX_INITIALIZER;
static int g_energia_pendente;

static void *executar_energia(void *arg) {
  int repouso = (int)(intptr_t)arg;
  const char *nome = repouso ? "modo de repouso" : "desligar";
  sleep(ESPERA_ENERGIA);
  sync();   /* grava no disco o que estiver em cache (diario, config, copias) antes de o sistema encerrar */
#ifdef __PROSPERO__
  int (*fn)(void) = repouso ? sceSystemStateMgrEnterStandby : sceSystemStateMgrTurnOff;
  if(!fn) {
    diario("energia: %s - firmware sem a funcao do sistema", nome);
    notificar("Game Library Renamer: o PS5 nao aceitou %s", nome);
  } else {
    g_desligando = !repouso;
    int r = fn();
    diario("energia: %s -> 0x%08x", nome, (unsigned)r);
    if(r) {
      g_desligando = 0;
      notificar("Game Library Renamer: o PS5 recusou %s (0x%08x)", nome, (unsigned)r);
    }
  }
#else
  diario("energia (PC): %s - no PS5 chamaria %s", nome,
         repouso ? "sceSystemStateMgrEnterStandby" : "sceSystemStateMgrTurnOff");
#endif
  pthread_mutex_lock(&g_trava_energia);
  g_energia_pendente = 0;   /* no repouso o processo continua vivo: libera um novo pedido depois de acordar */
  pthread_mutex_unlock(&g_trava_energia);
  return NULL;
}

int energia_pedir(const char *acao, char *msg, size_t tam) {
  int repouso;
  if(acao && !strcmp(acao, "desligar")) repouso = 0;
  else if(acao && !strcmp(acao, "repouso")) repouso = 1;
  else {
    snprintf(msg, tam, "acao invalida");
    return -1;
  }
  pthread_mutex_lock(&g_trava_energia);
  int ja = g_energia_pendente;
  if(!ja) g_energia_pendente = 1;
  pthread_mutex_unlock(&g_trava_energia);
  if(ja) {
    snprintf(msg, tam, "ja existe um pedido em andamento");
    return -1;
  }
  diario("energia: pedido de %s pela tela (em %d s)", repouso ? "modo de repouso" : "desligar", ESPERA_ENERGIA);
#ifdef __PROSPERO__
  notificar("%s", repouso ? "Game Library Renamer: entrando em modo de repouso..." : "Game Library Renamer: desligando o PS5...");
#endif
  if(criar_thread(executar_energia, (void *)(intptr_t)repouso, NULL)) {
    pthread_mutex_lock(&g_trava_energia);
    g_energia_pendente = 0;
    pthread_mutex_unlock(&g_trava_energia);
    snprintf(msg, tam, "falha ao criar a thread");
    return -1;
  }
  return 0;
}

int plataforma_desligando(void) {
#ifdef __PROSPERO__
  return g_desligando;
#else
  return 0;
#endif
}
