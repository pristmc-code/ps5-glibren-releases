/* Game Library Renamer (payload PS5) - DNS robusto (0.9.16) so para os hosts do GitHub, do catalogo e dos icones.

Ordem: cache -> UDP (1.1.1.1, 8.8.8.8, 9.9.9.9) -> TCP (1.1.1.1, 8.8.8.8) -> DoH (cloudflare-dns.com em 1.1.1.1 e
dns.google em 8.8.8.8, IP fixo e raizes de certificado embutidas em dns_ca.h). Cache positivo 600 s, negativo 20 s;
os positivos tambem vao para <dados>/dns_cache.txt (sobrevivem ao reinicio). Respostas so com enderecos privados,
de loopback ou zero sao recusadas. NUNCA hosts da Sony (lista fechada abaixo, mais uma trava por nome).
Ideia do ps5-patchdl (knutwurst, GPL-3.0+, src/patchdl_dns.c); codigo reescrito. O patchdl_resolve.c deles (chave de
atualizacao de PS4) NAO foi usado. */
#pragma once

#include <stddef.h>
#include "util.h"

/* 1 = host da lista (GitHub/raw, catalogo, icones). */
int dns_host_robusto(const char *host);
/* Resolve (registro A). 0 = ip preenchido; -1 = nao resolveu; -2 = host fora da lista. fonte (opcional): "cache",
   "udp", "tcp", "doh", "arquivo" ou "negativo". */
int dns_resolver(const char *host, char *ip, size_t tam, const char **fonte);
/* GET /api/dns?host=...: diagnostico {"ok":..,"host":..,"ip":..,"fonte":..} */
void dns_json(const char *host, buf_t *b);
