/* Game Library Renamer (payload PS5) - temperaturas, ventoinha e alerta.

Leitura (sempre funciona): sceKernelGetCpuTemperature, sceKernelGetSocSensorTemperature (canal 0 = SoC,
canal 2 = SSD M.2; slot vazio le ~0, so vale de 20 C para cima) e sceKernelGetCurrentFanDuty (0..1024).
Ventoinha (precisa do kstuff): /dev/icc_fan, ioctl de leitura/gravacao do perfil "autoservo" (28 bytes; o
byte 5 e a temperatura em que ela acelera). O sistema volta ao perfil dele ao abrir jogos, por isso o limite
escolhido e reaplicado a cada 15 s. Faixa permitida 50..85 C.
Alvo de fabrica (G6, 0.9.12): o limite nunca passa do alvo do proprio sistema. Ele e lido do perfil so com o nosso
limite desligado (com ele ligado, o perfil pode ser o nosso, ex.: logo depois de uma atualizacao do payload) e
guardado em alvo_fabrica.txt; as sessoes seguintes usam o guardado. Antes, depois de atualizar com o limite ligado o
alvo ficava desconhecido pela sessao toda e a tela aceitava ate 85 C.
(As chamadas do sistema foram levantadas lendo o ProsperoMgr; este codigo e proprio.)
Watchdog (0.9.16): cada leitura passa por sce_com_prazo() (sce_prazo.c): uma chamada que trava nao congela mais a
thread nem a pagina; a funcao fica fora (sensor = -1) ate a chamada presa voltar.
Consumo do chip (0.9.16): sceKernelGetSocPowerConsumption (libkernel_sys, weak) preenche 0x70 bytes = 8 trilhos de
{mW, mV, mA} em uint32 (formato visto no PS5-Suite e no OrangeHUD; buffer de 128 bytes porque um de 4 estoura). O
valor mostrado e a soma dos mW dos trilhos (como o PS5-Suite); os trilhos crus vao no JSON e no diario (1a leitura).
Sem a funcao, ou com valor fora de 1..400 W, a linha some da pagina (potencia_w = -1). A confirmar no PS5.

No PC (teste) os valores sao simulados (GLR_TESTE_SEM_POTENCIA=1: como firmware sem a funcao).
*/
#include "termico.h"

#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <time.h>
#include <unistd.h>

#include "config.h"
#include "plataforma.h"
#include "sce_prazo.h"
#include "sistema.h"

#define INTERVALO_S 2
#define HISTORICO 450               /* 15 min com uma leitura a cada 2 s */
#define REAPLICAR_S 2      /* o firmware desfaz o limite logo depois (onionHEN issue #40): confere a cada 2 s, so grava se mudou */
#define LIMITE_MIN 50
#define LIMITE_MAX 85
#define ALERTA_REPETIR_S 300        /* no maximo um alerta a cada 5 min */

#define ICC_FAN "/dev/icc_fan"
#define ICC_FAN_GRAVAR 0xC01C8F07ul
#define ICC_FAN_LER 0xC01C8F08ul
#define PERFIL_TAM 28
#define PERFIL_ALVO 5

#define PRAZO_SENSOR_MS 800   /* uma leitura de sensor leva poucos ms; passou disso, travou */
#define TRILHOS 8

typedef struct {
  time_t quando;
  signed char cpu, soc, m2, ventoinha;   /* -1 = sem leitura */
} amostra_t;

static int g_potencia_dw = -1;            /* consumo do chip em decimos de W (-1 = sem leitura) */
static uint32_t g_trilhos_mw[TRILHOS];    /* ultima leitura crua (mW de cada trilho) */
static int g_potencia_logada;

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static amostra_t g_hist[HISTORICO];
static int g_inicio, g_qtd;
static amostra_t g_atual = {0, -1, -1, -1, -1};
static int g_max_cpu = -1, g_max_soc = -1, g_max_m2 = -1;
static int g_limite;        /* 0 = automatico */
static int g_alerta;        /* 0 = desligado */
static char g_erro_limite[160];
static int g_alvo_fabrica = -1;   /* alvo do sistema lido antes de qualquer mudanca (nunca passamos dele) */
static int g_falhas;              /* reaplicacoes seguidas que falharam */
static int g_ultimo_aplicado;     /* ultimo limite que NOS gravamos (para reconhecer outro programa mexendo) */
static int g_conflito;            /* 1 = outro programa (ex.: ProsperoMgr) controla a ventoinha */
#define MAX_FALHAS 5
static time_t g_ultimo_alerta;

/* ------------------------------------------------------------------ sensores */

#ifdef __PROSPERO__
int sceKernelGetCpuTemperature(int *);
int sceKernelGetSocSensorTemperature(int, int *);
int sceKernelGetCurrentFanDuty(uint16_t *, uint64_t *);
int sceKernelGetSocPowerConsumption(void *) __attribute__((weak));   /* opcional: firmware sem ela -> NULL */

/* Funcoes rodadas pelo watchdog (entrada e saida sao copias; ver sce_prazo.h). */
static int fn_cpu(const void *e, void *s) {
  (void)e;
  return sceKernelGetCpuTemperature((int *)s);
}
static int fn_soc(const void *e, void *s) {
  return sceKernelGetSocSensorTemperature(*(const int *)e, (int *)s);   /* nunca com ponteiro nulo: derruba o processo */
}
static int fn_ventoinha(const void *e, void *s) {
  (void)e;
  uint64_t chassi = 0;
  return sceKernelGetCurrentFanDuty((uint16_t *)s, &chassi);
}
static int fn_potencia(const void *e, void *s) {
  (void)e;
  if(!sceKernelGetSocPowerConsumption) return -1;
  return sceKernelGetSocPowerConsumption(s);   /* s tem SCE_PRAZO_SAIDA (512) bytes zerados; ela escreve 0x70 */
}
#else
/* PC: valores simulados (variam devagar, como num jogo), pelo mesmo caminho do watchdog. */
static double g_sim_carga;
static int fn_cpu(const void *e, void *s) {
  (void)e;
  static double t;
  t += 0.07;
  g_sim_carga = 0.5 + 0.5 * sin(t) * sin(t * 0.37);
  *(int *)s = (int)(52 + 26 * g_sim_carga + rand() % 3);
  return 0;
}
static int fn_soc(const void *e, void *s) {
  int canal = *(const int *)e;
  *(int *)s = canal == 2 ? (int)(44 + 8 * g_sim_carga) : (int)(48 + 26 * g_sim_carga + rand() % 3);
  return 0;
}
static int fn_ventoinha(const void *e, void *s) {
  (void)e;
  int base = g_limite ? (g_atual.cpu > g_limite ? 70 : 35) : 30 + (int)(40 * g_sim_carga);
  *(uint16_t *)s = (uint16_t)((base + rand() % 4) * 1024 / 100);
  return 0;
}
static int fn_potencia(const void *e, void *s) {
  (void)e;
  if(getenv("GLR_TESTE_SEM_POTENCIA")) return -1;
  uint32_t *t = s;
  t[0] = (uint32_t)(52000 + 50000 * g_sim_carga);   /* trilho 0: ~50..100 W */
  t[1] = 1000;                                      /* mV */
  t[2] = t[0];                                      /* mA */
  t[3] = (uint32_t)(9000 + 4000 * g_sim_carga);     /* trilho 1 */
  return 0;
}
#endif

/* Uma chamada pelo watchdog. -1 se travou, esta fora ou falhou. */
static int chamar(const char *nome, sce_fn_t fn, int arg, void *saida, size_t n) {
  int ret = -1;
  if(sce_com_prazo(nome, fn, &arg, sizeof arg, saida, n, PRAZO_SENSOR_MS, &ret) != SCE_OK) return -1;
  return ret;
}

static void ler_sensores(amostra_t *a) {
  int v = 0;
  uint16_t duty = 0;
  a->cpu = (!chamar("sceKernelGetCpuTemperature", fn_cpu, 0, &v, sizeof v) && v >= 0 && v <= 130) ? v : -1;
  a->soc = (!chamar("sceKernelGetSocSensorTemperature", fn_soc, 0, &v, sizeof v) && v >= 0 && v <= 130) ? v : -1;
  a->m2 = (!chamar("sceKernelGetSocSensorTemperature", fn_soc, 2, &v, sizeof v) && v >= 20 && v <= 130) ? v : -1;
  a->ventoinha = !chamar("sceKernelGetCurrentFanDuty", fn_ventoinha, 0, &duty, sizeof duty) ? (duty * 100 + 512) / 1024 : -1;
  if(a->ventoinha > 100) a->ventoinha = 100;

  /* consumo do chip: 8 trilhos {mW, mV, mA}; soma dos mW */
  uint32_t buf[SCE_PRAZO_SAIDA / 4];
  memset(buf, 0, sizeof buf);
  int dw = -1;
  if(!chamar("sceKernelGetSocPowerConsumption", fn_potencia, 0, buf, sizeof buf)) {
    unsigned long long soma = 0;
    for(int k = 0; k < TRILHOS; k++) soma += buf[k * 3];
    if(soma >= 1000 && soma <= 400000) dw = (int)((soma + 50) / 100);
    if(!g_potencia_logada) {
      g_potencia_logada = 1;
      diario("potencia: trilhos mW %u %u %u %u %u %u %u %u (soma %llu mW)", buf[0], buf[3], buf[6], buf[9], buf[12], buf[15],
             buf[18], buf[21], soma);
    }
  }
  pthread_mutex_lock(&g_trava);
  g_potencia_dw = dw;
  for(int k = 0; k < TRILHOS; k++) g_trilhos_mw[k] = dw >= 0 ? buf[k * 3] : 0;
  pthread_mutex_unlock(&g_trava);
}

#ifdef __PROSPERO__
static int ler_perfil(int fd, uint8_t perfil[PERFIL_TAM]) {
  memset(perfil, 0, PERFIL_TAM);
  return ioctl(fd, ICC_FAN_LER, perfil);
}

/* Grava o limite na ventoinha (se ja nao estiver). 0 ou -1 com a mensagem em g_erro_limite. */
static int aplicar_limite(int celsius) {
  uint8_t perfil[PERFIL_TAM], conferido[PERFIL_TAM];
  int fd = open(ICC_FAN, O_RDWR);
  if(fd < 0) {
    snprintf(g_erro_limite, sizeof g_erro_limite, "sem acesso a ventoinha (o kstuff esta carregado?): %s", strerror(errno));
    return -1;
  }
  int r = -1;
  if(ler_perfil(fd, perfil)) snprintf(g_erro_limite, sizeof g_erro_limite, "nao leu a ventoinha: %s", strerror(errno));
  else if(g_alvo_fabrica > 0 && celsius > g_alvo_fabrica)
    snprintf(g_erro_limite, sizeof g_erro_limite, "o limite nao pode passar do valor do sistema (%d C)", g_alvo_fabrica);
  else if(g_alvo_fabrica > 0 && perfil[PERFIL_ALVO] != g_alvo_fabrica && perfil[PERFIL_ALVO] != g_ultimo_aplicado &&
          perfil[PERFIL_ALVO] != celsius) {
    /* nem o valor do sistema nem o nosso: outro programa (ex.: ProsperoMgr) esta controlando - nao briga com ele */
    g_conflito = perfil[PERFIL_ALVO];
    snprintf(g_erro_limite, sizeof g_erro_limite, "outro programa ja controla a ventoinha (%d C); desligue o controle dele ou use so o dele",
             perfil[PERFIL_ALVO]);
  }
  else if(perfil[PERFIL_ALVO] == celsius) r = 0;
  else {
    perfil[PERFIL_ALVO] = (uint8_t)celsius;
    if(ioctl(fd, ICC_FAN_GRAVAR, perfil)) snprintf(g_erro_limite, sizeof g_erro_limite, "nao gravou na ventoinha: %s", strerror(errno));
    else if(ler_perfil(fd, conferido) || conferido[PERFIL_ALVO] != celsius)
      snprintf(g_erro_limite, sizeof g_erro_limite, "a ventoinha recusou o limite");
    else r = 0;
  }
  if(!r) {
    g_ultimo_aplicado = celsius;
    g_conflito = 0;
  }
  close(fd);
  if(!r) g_erro_limite[0] = 0;
  return r;
}

/* Alvo que esta no perfil agora (varia por placa: 91, 86, 69 C...), ou -1. */
static int ler_alvo_atual(void) {
  uint8_t perfil[PERFIL_TAM];
  int fd = open(ICC_FAN, O_RDWR), alvo = -1;
  if(fd < 0) return -1;
  if(!ler_perfil(fd, perfil) && perfil[PERFIL_ALVO] > 0) alvo = perfil[PERFIL_ALVO];
  close(fd);
  return alvo;
}
#else
static int aplicar_limite(int celsius) {
  if(g_alvo_fabrica > 0 && celsius > g_alvo_fabrica) {
    snprintf(g_erro_limite, sizeof g_erro_limite, "o limite nao pode passar do valor do sistema (%d C)", g_alvo_fabrica);
    return -1;
  }
  g_erro_limite[0] = 0;
  g_ultimo_aplicado = celsius;
  g_conflito = 0;
  return 0;
}

/* PC: valor simulado (testes: GLR_TESTE_ALVO = o alvo que esta no perfil "agora") */
static int ler_alvo_atual(void) {
  const char *t = getenv("GLR_TESTE_ALVO");
  return t && *t ? atoi(t) : 80;
}
#endif

/* ------------------------------------------------------------------ alvo de fabrica (G6) */

static void arquivo_alvo(char *saida, size_t tam) {
  snprintf(saida, tam, "%s/alvo_fabrica.txt", g_pasta_dados);
}

static int alvo_valido(int c) {
  return c >= 40 && c <= 120;
}

/* Guardado em alvo_fabrica.txt, ou -1. */
static int alvo_guardado(void) {
  char nome[600];
  int v = -1;
  arquivo_alvo(nome, sizeof nome);
  FILE *f = fopen(nome, "r");
  if(!f) return -1;
  if(fscanf(f, "factory_target = %d", &v) != 1 || !alvo_valido(v)) v = -1;
  fclose(f);
  return v;
}

static void guardar_alvo(int c) {
  char nome[600], tmp[610];
  arquivo_alvo(nome, sizeof nome);
  snprintf(tmp, sizeof tmp, "%s.tmp", nome);
  FILE *f = fopen(tmp, "w");
  if(!f) return;
  fprintf(f, "factory_target = %d\n", c);
  int ok = !fflush(f) && !fsync(fileno(f));
  if(fclose(f) || !ok || rename(tmp, nome)) unlink(tmp);
  else diario("ventoinha: alvo de fabrica %d C guardado", c);
}

/* Na partida e, enquanto o alvo for desconhecido, a cada minuto: o guardado vale; senao, le o perfil com o limite
   desligado e guarda. Com o limite ligado e nada guardado, so usa (sem guardar) um valor diferente do nosso. Chamar
   com g_trava. */
static void ler_alvo_sistema(void) {
  int guardado = alvo_guardado();
  if(guardado > 0) {
    g_alvo_fabrica = guardado;
    return;
  }
  int atual = ler_alvo_atual();
  if(!alvo_valido(atual)) return;
  if(!g_limite && (!g_ultimo_aplicado || atual != g_ultimo_aplicado)) {
    g_alvo_fabrica = atual;
    guardar_alvo(atual);
  } else if(g_limite && atual != g_limite && g_alvo_fabrica < 0) {
    g_alvo_fabrica = atual;
  }
}

/* ------------------------------------------------------------------ configuracao (limite e alerta) */

static void arquivo(char *saida, size_t tam) {
  snprintf(saida, tam, "%s/temperatura.txt", g_pasta_dados);
}

/* .tmp + fsync + rename: uma queda no meio deixa o arquivo antigo inteiro, nunca um vazio */
static void gravar_config(void) {
  char nome[600], tmp[610];
  arquivo(nome, sizeof nome);
  snprintf(tmp, sizeof tmp, "%s.tmp", nome);
  FILE *f = fopen(tmp, "w");
  if(!f) return;
  fprintf(f, "fan_threshold = %d\nalert = %d\n", g_limite, g_alerta);
  int ok = !fflush(f) && !fsync(fileno(f));
  if(fclose(f) || !ok || rename(tmp, nome)) unlink(tmp);
}

static void ler_config(void) {
  char nome[600], linha[128];
  arquivo(nome, sizeof nome);
  FILE *f = fopen(nome, "r");
  if(!f) return;
  while(fgets(linha, sizeof linha, f)) {
    int v;
    if(sscanf(linha, "fan_threshold = %d", &v) == 1 && (v == 0 || (v >= LIMITE_MIN && v <= LIMITE_MAX))) g_limite = v;
    if(sscanf(linha, "alert = %d", &v) == 1 && (v == 0 || (v >= 50 && v <= 100))) g_alerta = v;
  }
  fclose(f);
}

/* ------------------------------------------------------------------ thread */

static void *vigiar(void *arg) {
  (void)arg;
  pthread_mutex_lock(&g_trava);
  ler_alvo_sistema();
  pthread_mutex_unlock(&g_trava);
  int desde_reaplicar = REAPLICAR_S, desde_alvo = 0;
  for(;;) {
    desde_alvo += INTERVALO_S;
    if(desde_alvo >= 60) {   /* alvo ainda desconhecido (ou so em memoria): tenta guardar com o limite desligado */
      desde_alvo = 0;
      pthread_mutex_lock(&g_trava);
      if(alvo_guardado() < 0) ler_alvo_sistema();
      pthread_mutex_unlock(&g_trava);
    }
    amostra_t a = {time(NULL), -1, -1, -1, -1};
    ler_sensores(&a);
    pthread_mutex_lock(&g_trava);
    g_atual = a;
    g_hist[(g_inicio + g_qtd) % HISTORICO] = a;
    if(g_qtd < HISTORICO) g_qtd++;
    else g_inicio = (g_inicio + 1) % HISTORICO;
    if(a.cpu > g_max_cpu) g_max_cpu = a.cpu;
    if(a.soc > g_max_soc) g_max_soc = a.soc;
    if(a.m2 > g_max_m2) g_max_m2 = a.m2;
    int limite = g_limite, alerta = g_alerta;
    pthread_mutex_unlock(&g_trava);

    /* o sistema desfaz o limite ao abrir jogos: reaplica de tempos em tempos */
    desde_reaplicar += INTERVALO_S;
    if(limite && desde_reaplicar >= REAPLICAR_S) {
      desde_reaplicar = 0;
      pthread_mutex_lock(&g_trava);
      if(aplicar_limite(limite) == 0) g_falhas = 0;
      else if(g_conflito) {
        g_limite = 0;
        g_falhas = 0;
        gravar_config();
        notificar("Game Library Renamer: outro programa controla a ventoinha (%d C); o nosso voltou ao automatico", g_conflito);
      } else if(++g_falhas >= MAX_FALHAS) {
        /* falhou varias vezes seguidas: volta ao automatico do sistema e avisa */
        g_limite = 0;
        g_falhas = 0;
        gravar_config();
        notificar("Game Library Renamer: ventoinha voltou ao automatico (%s)", g_erro_limite);
      }
      pthread_mutex_unlock(&g_trava);
    }

    int quente = a.cpu > a.soc ? a.cpu : a.soc;
    if(a.m2 > quente) quente = a.m2;
    if(alerta && quente >= alerta && time(NULL) - g_ultimo_alerta >= ALERTA_REPETIR_S) {
      g_ultimo_alerta = time(NULL);
      notificar("Game Library Renamer: PS5 a %d C (alerta em %d C)", quente, alerta);
    }
    sleep(INTERVALO_S);
  }
  return NULL;
}

void termico_iniciar(void) {
  ler_config();
  criar_thread(vigiar, NULL, NULL);
}

int termico_definir_limite(int celsius, char *msg, size_t tam) {
  if(celsius && (celsius < LIMITE_MIN || celsius > LIMITE_MAX)) {
    snprintf(msg, tam, "o limite deve ficar entre %d e %d C", LIMITE_MIN, LIMITE_MAX);
    return -1;
  }
  pthread_mutex_lock(&g_trava);
  int r = 0;
  if(celsius && aplicar_limite(celsius)) {
    snprintf(msg, tam, "%s", g_erro_limite);
    r = -1;
  } else {
    /* automatico: so para de reaplicar; o sistema volta ao perfil dele no proximo jogo/menu */
    g_limite = celsius;
    gravar_config();
  }
  pthread_mutex_unlock(&g_trava);
  return r;
}

int termico_definir_alerta(int celsius) {
  if(celsius && (celsius < 50 || celsius > 100)) return -1;
  pthread_mutex_lock(&g_trava);
  g_alerta = celsius;
  g_ultimo_alerta = 0;
  gravar_config();
  pthread_mutex_unlock(&g_trava);
  return 0;
}

void termico_json(buf_t *b, int com_historico) {
  pthread_mutex_lock(&g_trava);
  amostra_t a = g_atual;
  buf_fmt(b, "{\"ok\":true,\"alvo_sistema\":%d,\"cpu\":%d,\"soc\":%d,\"m2\":%d,\"ventoinha\":%d,\"max_cpu\":%d,\"max_soc\":%d,\"max_m2\":%d,"
          "\"limite\":%d,\"conflito\":%d,\"alerta\":%d,\"limite_min\":%d,\"limite_max\":%d,\"intervalo\":%d,\"erro_limite\":",
          g_alvo_fabrica, a.cpu, a.soc, a.m2, a.ventoinha, g_max_cpu, g_max_soc, g_max_m2, g_limite, g_conflito, g_alerta, LIMITE_MIN, LIMITE_MAX,
          INTERVALO_S);
  buf_json(b, g_erro_limite);
  /* consumo do chip (0.9.16): -1 = sem a funcao/sem leitura (a pagina esconde a linha) */
  if(g_potencia_dw >= 0) buf_fmt(b, ",\"potencia_w\":%d.%d", g_potencia_dw / 10, g_potencia_dw % 10);
  else buf_str(b, ",\"potencia_w\":-1");
  buf_str(b, ",\"potencia_trilhos_mw\":[");
  for(int k = 0; k < TRILHOS; k++) buf_fmt(b, "%s%u", k ? "," : "", g_trilhos_mw[k]);
  buf_str(b, "]");
  if(com_historico) {
    /* [cpu, soc, m2, ventoinha] do mais antigo ao mais novo */
    buf_str(b, ",\"historico\":[");
    for(int i = 0; i < g_qtd; i++) {
      amostra_t *h = &g_hist[(g_inicio + i) % HISTORICO];
      buf_fmt(b, "%s[%d,%d,%d,%d]", i ? "," : "", h->cpu, h->soc, h->m2, h->ventoinha);
    }
    buf_str(b, "]");
  }
  pthread_mutex_unlock(&g_trava);
  buf_str(b, ",");
  sistema_json(b);
  buf_str(b, ",");
  sce_prazo_json(b);
  buf_str(b, "}");
}
