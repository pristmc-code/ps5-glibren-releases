/* Game Library Renamer (payload PS5) - "Enviar diagnostico" para o GitHub (0.9.21). Ver diagnostico.h. */
#include "diagnostico.h"

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "api.h"
#include "cheats.h"
#include "config.h"
#include "discos.h"
#include "https.h"
#include "miniz_cfg.h"
#include "payloads.h"
#include "plataforma.h"
#include "termico.h"

#define DIAG_TAIL (2u * 1024 * 1024)   /* cada arquivo: so os ultimos ~2 MB */
#define DIAG_MAX_ARQ 16
#define DIAG_REPO "/repos/pristmc-code/ps5-diagnosticos/contents/glibren/"
#define DIAG_COMMITTER "{\"name\":\"PristMC\",\"email\":\"285300718+pristmc-code@users.noreply.github.com\"}"
#define DIAG_OCULTO "[segredo]"

/* ---- AS REGRAS DE HIGIENIZACAO (lista unica; diagnostico_limpar as aplica a tudo que sai, envio e .zip) --------
   1. Valores secretos conhecidos (as chaves do GitHub do glibren e da Jobe, os SHA-256 dos aparelhos pareados) saem
      onde aparecerem.
   2. Endereco http(s): usuario:senha sai; a consulta (?...) e o #... saem sempre (links assinados); num host de
      DIAG_HOSTS_PRIVADOS (links temporarios: googlevideo, servicos debrid) sai o caminho inteiro.
   3. "Bearer xxx" / "Basic xxx" (Authorization).
   4. nome=valor / nome: valor / "nome":"valor" com um nome de DIAG_NOMES_SECRETOS (cookie, authorization e
      set-cookie levam a linha inteira).
   5. E-mails.
   6. Tokens soltos: os prefixos de DIAG_PREFIXOS (chaves do GitHub), UUID e qualquer trecho de 32+ letras e digitos
      misturados (hashes, tokens do pareamento, cookies).
   Alem disso, no config.ini as linhas "paired" (aparelhos pareados) viram "paired = [aparelho pareado]".
   Arquivos que nunca vao: as chaves (diag/token do glibren e da Jobe). */
static const char *const DIAG_NOMES_SECRETOS[] = {
  "access_token", "refresh_token", "id_token", "token", "apikey", "api_key", "api-key", "key", "chave", "password", "passwd",
  "senha", "secret", "client_secret", "authorization", "auth", "set-cookie", "cookie", "sessionid", "session", "sid",
  "sapisid", "signature", "sig", "x-glr-token", "x-jobe-token", "x-session", "code_verifier", "device_code", "user_code",
  "codigo", "paired", NULL};
static const char *const DIAG_NOMES_LINHA[] = {"authorization", "set-cookie", "cookie", NULL};
static const char *const DIAG_HOSTS_PRIVADOS[] = {
  "googlevideo.com", "youtube.com", "youtu.be", "googleapis.com", "torbox", "tb-cdn", "alldebrid", "debrid", "real-debrid",
  "rdeb.io", "premiumize", "debrid-link", "1fichier", NULL};
static const char *const DIAG_PREFIXOS[] = {"github_pat_", "ghp_", "gho_", "ghu_", "ghs_", "ghr_", NULL};

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static struct {
  int rodando;
  char estado[12], pasta[24], erro[16];
  int http, enviados, total;
  long long em;
} g_d = {0, "idle", "", "", 0, 0, 0, 0};
/* duas rodadas no mesmo segundo nao caem na mesma pasta (no GitHub, PUT num arquivo que ja existe sem "sha" da 422) */
static char g_ult_pasta[24];
static int g_usos;

/* ------------------------------------------------------------------ caminhos */

static void pasta_diag(char *s, size_t tam) {
#ifdef __PROSPERO__
  snprintf(s, tam, "/data/glibren/diag");
#else
  const char *e = getenv("GLR_TESTE_DIAG");
  if(e && *e) snprintf(s, tam, "%s", e);
  else snprintf(s, tam, "%s/diag", g_pasta_dados);
#endif
}

static void arquivo_chave(char *s, size_t tam) {
  char p[512];
  pasta_diag(p, sizeof p);
  snprintf(s, tam, "%s/token", p);
}

/* A chave que a Jobe guardou (bg_diag.c: <diag>/token com <diag> = /data/JobeesLair/diag). So leitura. */
static void arquivo_chave_jobe(char *s, size_t tam) {
#ifdef __PROSPERO__
  snprintf(s, tam, "/data/JobeesLair/diag/token");
#else
  const char *e = getenv("GLR_TESTE_JOBE_TOKEN");
  snprintf(s, tam, "%s", e ? e : "");
#endif
}

static void arquivo_fullscreen(char *s, size_t tam) {
#ifdef __PROSPERO__
  snprintf(s, tam, "/data/web-browser-fullscreen.ini");
#else
  const char *e = getenv("GLR_TESTE_FULLSCREEN_INI");
  snprintf(s, tam, "%s", e ? e : "");
#endif
}

/* Os ultimos `cap` bytes de `caminho` (comecando numa linha inteira quando corta). NULL se nao existe ou vazio. */
static char *ler_final(const char *caminho, size_t cap, size_t *n, int *cortado) {
  *cortado = 0;
  *n = 0;
  if(!caminho[0]) return NULL;
  int fd = open(caminho, O_RDONLY);
  if(fd < 0) return NULL;
  struct stat st;
  if(fstat(fd, &st) || !S_ISREG(st.st_mode) || st.st_size <= 0) {
    close(fd);
    return NULL;
  }
  size_t quer = (size_t)st.st_size;
  off_t de = 0;
  if(quer > cap) {
    de = st.st_size - (off_t)cap;
    quer = cap;
    *cortado = 1;
  }
  char *t = malloc(quer + 1);
  if(!t) {
    close(fd);
    return NULL;
  }
  size_t lidos = 0;
  while(lidos < quer) {
    ssize_t k = pread(fd, t + lidos, quer - lidos, de + (off_t)lidos);
    if(k < 0 && errno == EINTR) continue;
    if(k <= 0) break;
    lidos += (size_t)k;
  }
  close(fd);
  t[lidos] = 0;
  if(*cortado) {
    char *l = memchr(t, '\n', lidos);
    if(l && (size_t)(l - t) + 1 < lidos) {
      size_t pula = (size_t)(l - t) + 1;
      memmove(t, t + pula, lidos - pula + 1);
      lidos -= pula;
    }
  }
  for(size_t i = 0; i < lidos; i++)
    if(!t[i]) t[i] = ' ';   /* um \0 no meio cortaria o texto na limpeza */
  if(!lidos) {
    free(t);
    return NULL;
  }
  *n = lidos;
  return t;
}

/* ------------------------------------------------------------------ a chave */

static int chave_ok(const char *k) {
  size_t n = strlen(k);
  return n >= 20 && n <= 200 && strspn(k, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_") == n;
}

/* 1 = ha chave valida no arquivo (em `saida`). Quem chama apaga `saida` (memset) depois de usar. */
static int ler_chave_de(const char *caminho, char *saida, size_t cap) {
  saida[0] = 0;
  size_t n = 0;
  int cortado = 0;
  char *t = ler_final(caminho, 1024, &n, &cortado);
  if(!t) return 0;
  char *ini = t;
  while(*ini == ' ' || *ini == '\n' || *ini == '\r' || *ini == '\t') ini++;
  size_t k = strcspn(ini, " \r\n\t");
  if(k < cap) {
    memcpy(saida, ini, k);
    saida[k] = 0;
  }
  memset(t, 0, n);
  free(t);
  if(cortado || !chave_ok(saida)) {
    memset(saida, 0, cap);
    return 0;
  }
  return 1;
}

/* A chave em uso: a do glibren e, sem ela, a da Jobe. origem: "glibren", "jobe" ou "". */
static int ler_chave(char *saida, size_t cap, const char **origem) {
  char c[600];
  arquivo_chave(c, sizeof c);
  if(ler_chave_de(c, saida, cap)) {
    if(origem) *origem = "glibren";
    return 1;
  }
  arquivo_chave_jobe(c, sizeof c);
  if(ler_chave_de(c, saida, cap)) {
    if(origem) *origem = "jobe";
    return 1;
  }
  if(origem) *origem = "";
  return 0;
}

static void estado_json(buf_t *b) {
  char k[256], final[8] = "", c[600];
  const char *origem = "";
  int tem = ler_chave(k, sizeof k, &origem);
  if(tem) snprintf(final, sizeof final, "%s", k + strlen(k) - 4);
  memset(k, 0, sizeof k);
  arquivo_chave(c, sizeof c);
  struct stat st;
  int propria = !stat(c, &st);
  pthread_mutex_lock(&g_trava);
  buf_fmt(b, "{\"ok\":true,\"configurada\":%s,\"origem\":", tem ? "true" : "false");
  buf_json(b, origem);
  buf_str(b, ",\"final\":");
  buf_json(b, final);
  buf_fmt(b, ",\"propria\":%s,\"estado\":", propria ? "true" : "false");
  buf_json(b, g_d.estado);
  buf_str(b, ",\"pasta\":");
  buf_json(b, g_d.pasta);
  buf_str(b, ",\"erro\":");
  buf_json(b, g_d.erro);
  buf_fmt(b, ",\"http\":%d,\"enviados\":%d,\"total\":%d,\"em\":%lld}", g_d.http, g_d.enviados, g_d.total, g_d.em);
  pthread_mutex_unlock(&g_trava);
}

/* ------------------------------------------------------------------ higienizacao */

typedef struct {
  char v[12][160];
  int n;
} segredos_t;

static void segredo_add(segredos_t *s, const char *v) {
  if(s->n < 12 && strlen(v) >= 6 && strlen(v) < sizeof s->v[0]) snprintf(s->v[s->n++], sizeof s->v[0], "%s", v);
}

/* Os valores que o glibren conhece. Quem chama apaga (memset) depois. */
static void segredos_conhecidos(segredos_t *s) {
  memset(s, 0, sizeof *s);
  char k[256], c[600];
  arquivo_chave(c, sizeof c);
  if(ler_chave_de(c, k, sizeof k)) segredo_add(s, k);
  arquivo_chave_jobe(c, sizeof c);
  if(ler_chave_de(c, k, sizeof k)) segredo_add(s, k);
  memset(k, 0, sizeof k);
  char pareados[MAX_PAREADOS][TAM_PAREADO];
  int q = config_pareados(pareados, MAX_PAREADOS);
  for(int i = 0; i < q; i++) {
    pareados[i][strcspn(pareados[i], " ")] = 0;   /* so o sha256 */
    segredo_add(s, pareados[i]);
  }
  memset(pareados, 0, sizeof pareados);
}

static int alnum(char c) { return isalnum((unsigned char)c) != 0; }
static int tokch(char c) { return alnum(c) || c == '-' || c == '_'; }
static int mailch(char c) { return alnum(c) || c == '.' || c == '_' || c == '%' || c == '+' || c == '-'; }
static int fim_valor(char c) { return !c || isspace((unsigned char)c) || strchr("\"',;&}])<>`", c); }
static int fim_url(char c) { return !c || isspace((unsigned char)c) || strchr("\"'<>`\\", c); }

/* Regra 2: o endereco em `p` (comeca com http:// ou https://). Escreve a versao limpa e devolve quantos bytes leu. */
static size_t limpar_url(buf_t *o, const char *p) {
  size_t esquema = !strncasecmp(p, "https://", 8) ? 8 : 7, fim = esquema;
  while(!fim_url(p[fim])) fim++;
  size_t fim_host = esquema;
  while(fim_host < fim && p[fim_host] != '/' && p[fim_host] != '?' && p[fim_host] != '#') fim_host++;
  buf_add(o, p, esquema);
  size_t host = esquema;
  const char *arroba = memchr(p + esquema, '@', fim_host - esquema);
  if(arroba) {
    buf_str(o, DIAG_OCULTO "@");
    host = (size_t)(arroba - p) + 1;
  }
  buf_add(o, p + host, fim_host - host);
  char nome[256];
  size_t n = fim_host - host < sizeof nome - 1 ? fim_host - host : sizeof nome - 1;
  for(size_t i = 0; i < n; i++) nome[i] = (char)tolower((unsigned char)p[host + i]);
  nome[n] = 0;
  int privado = 0;
  for(int i = 0; DIAG_HOSTS_PRIVADOS[i] && !privado; i++) privado = strstr(nome, DIAG_HOSTS_PRIVADOS[i]) != NULL;
  if(privado) {
    if(fim_host < fim) buf_str(o, "/[...]");
    return fim;
  }
  size_t fim_caminho = fim_host;
  while(fim_caminho < fim && p[fim_caminho] != '?' && p[fim_caminho] != '#') fim_caminho++;
  buf_add(o, p + fim_host, fim_caminho - fim_host);
  if(fim_caminho < fim) buf_str(o, p[fim_caminho] == '?' ? "?[...]" : "#[...]");
  return fim;
}

/* Regra 4: um nome de DIAG_NOMES_SECRETOS em `p` seguido de = ou :. Devolve quantos bytes leu (0 = nao e). */
static size_t limpar_nomeado(buf_t *o, const char *p, int nome_entre_aspas) {
  for(int i = 0; DIAG_NOMES_SECRETOS[i]; i++) {
    size_t n = strlen(DIAG_NOMES_SECRETOS[i]);
    if(strncasecmp(p, DIAG_NOMES_SECRETOS[i], n) || alnum(p[n]) || p[n] == '_' || p[n] == '-') continue;
    size_t at = n;
    if(p[at] == '"') at++;
    while(p[at] == ' ' || p[at] == '\t') at++;
    if(p[at] != '=' && p[at] != ':') continue;
    at++;
    while(p[at] == ' ' || p[at] == '\t') at++;
    /* um objeto, uma lista, null/true/false/numero pequeno, ou nada: nao e um valor secreto */
    if(!p[at] || p[at] == '{' || p[at] == '[' || p[at] == '\n' || p[at] == '\r' || !strncmp(p + at, "null", 4) ||
       !strncmp(p + at, "true", 4) || !strncmp(p + at, "false", 5) || !strncmp(p + at, "\"\"", 2))
      return 0;
    int linha = 0;
    for(int k = 0; DIAG_NOMES_LINHA[k]; k++) linha |= !strcasecmp(DIAG_NOMES_SECRETOS[i], DIAG_NOMES_LINHA[k]);
    if(p[at] == '"') {
      buf_add(o, p, at + 1);
      buf_str(o, DIAG_OCULTO);
      at++;
      while(p[at] && p[at] != '"' && p[at] != '\n') at += p[at] == '\\' && p[at + 1] ? 2 : 1;
      return at;   /* a aspa de fechamento segue como texto */
    }
    buf_add(o, p, at);
    buf_str(o, nome_entre_aspas ? "\"" DIAG_OCULTO "\"" : DIAG_OCULTO);
    if(linha && !nome_entre_aspas)
      while(p[at] && p[at] != '\n' && p[at] != '\r') at++;
    else
      while(!fim_valor(p[at])) at++;
    return at;
  }
  return 0;
}

/* Regra 5: um e-mail em `p` (comeco de palavra). Devolve o tamanho (0 = nao e). */
static size_t email(const char *p) {
  size_t local = 0;
  while(local < 64 && mailch(p[local])) local++;
  if(!local || p[local] != '@') return 0;
  size_t at = local + 1, rotulo = 0, pontos = 0, ultimo = 0;
  for(;; at++) {
    char c = p[at];
    if(alnum(c) || c == '-') {
      rotulo++;
      continue;
    }
    if(c == '.' && rotulo) {
      pontos++;
      rotulo = 0;
      continue;
    }
    break;
  }
  for(size_t k = at; k > local + 1 && p[k - 1] != '.'; k--) {
    if(!isalpha((unsigned char)p[k - 1])) return 0;
    ultimo++;
  }
  return pontos && rotulo && ultimo >= 2 ? at : 0;
}

/* Regra 6: um token solto em `p` (comeco de trecho [A-Za-z0-9_-]). Devolve o tamanho e se e segredo. */
static size_t token_solto(const char *p, int *segredo) {
  size_t n = 0;
  while(tokch(p[n])) n++;
  *segredo = 0;
  for(int i = 0; DIAG_PREFIXOS[i]; i++)
    if(!strncmp(p, DIAG_PREFIXOS[i], strlen(DIAG_PREFIXOS[i])) && n > strlen(DIAG_PREFIXOS[i]) + 8) *segredo = 1;
  if(n == 36) {   /* UUID 8-4-4-4-12 */
    int uuid = 1;
    for(size_t i = 0; i < 36 && uuid; i++) uuid = i == 8 || i == 13 || i == 18 || i == 23 ? p[i] == '-' : isxdigit((unsigned char)p[i]) != 0;
    if(uuid) *segredo = 1;
  }
  for(size_t ini = 0; ini < n && !*segredo;) {   /* um pedaco sem - ou _ de 32+ com letras e digitos */
    size_t fim = ini;
    int letras = 0, digitos = 0;
    while(fim < n && alnum(p[fim])) {
      letras += isalpha((unsigned char)p[fim]) != 0;
      digitos += isdigit((unsigned char)p[fim]) != 0;
      fim++;
    }
    if(fim - ini >= 32 && letras && digitos) *segredo = 1;
    ini = fim + 1;
  }
  return n;
}

static char *limpar(const char *in, size_t tam, const segredos_t *sec, size_t *n_saida) {
  buf_t o = {0};
  buf_add(&o, "", 0);
  for(size_t i = 0; i < tam;) {
    const char *p = in + i;
    char ant = i ? in[i - 1] : ' ';
    size_t usado = 0;
    for(int k = 0; k < sec->n && !usado; k++) {   /* 1 */
      size_t n = strlen(sec->v[k]);
      if(*p == sec->v[k][0] && !strncmp(p, sec->v[k], n)) {
        buf_str(&o, DIAG_OCULTO);
        usado = n;
      }
    }
    if(usado) {
      i += usado;
      continue;
    }
    if((*p == 'h' || *p == 'H') && !alnum(ant) && (!strncasecmp(p, "http://", 7) || !strncasecmp(p, "https://", 8))) {   /* 2 */
      i += limpar_url(&o, p);
      continue;
    }
    if(!alnum(ant) && (!strncasecmp(p, "bearer ", 7) || !strncmp(p, "Basic ", 6))) {   /* 3 */
      size_t at = (*p == 'B' && p[1] == 'a') ? 6 : 7;
      while(p[at] == ' ') at++;
      if(!fim_valor(p[at])) {
        buf_add(&o, p, at);
        buf_str(&o, DIAG_OCULTO);
        while(!fim_valor(p[at])) at++;
        i += at;
        continue;
      }
    }
    if(!alnum(ant) && isalpha((unsigned char)*p) && (usado = limpar_nomeado(&o, p, ant == '"'))) {   /* 4 */
      i += usado;
      continue;
    }
    if(mailch(*p) && !mailch(ant) && (usado = email(p))) {   /* 5 */
      buf_str(&o, "[email]");
      i += usado;
      continue;
    }
    if(tokch(*p) && !tokch(ant)) {   /* 6 */
      int segredo = 0;
      usado = token_solto(p, &segredo);
      if(segredo) {
        buf_str(&o, DIAG_OCULTO);
        i += usado;
        continue;
      }
    }
    buf_add(&o, p, 1);
    i++;
  }
  *n_saida = o.n;
  return o.d;
}

char *diagnostico_limpar(const char *texto, size_t n, size_t *n_saida) {
  segredos_t s;
  segredos_conhecidos(&s);
  char *r = limpar(texto, n, &s, n_saida);
  memset(&s, 0, sizeof s);
  return r;
}

/* ------------------------------------------------------------------ os arquivos */

typedef struct {
  char nome[48];
  char *d;
  size_t n;
  int cortado;
} arq_t;

typedef struct {
  arq_t a[DIAG_MAX_ARQ];
  int n;
  char faltam[400];
} conjunto_t;

static void conjunto_liberar(conjunto_t *c) {
  for(int i = 0; i < c->n; i++) {
    if(c->a[i].d) memset(c->a[i].d, 0, c->a[i].n);
    free(c->a[i].d);
  }
  memset(c, 0, sizeof *c);
}

static void faltou(conjunto_t *c, const char *nome) {
  size_t n = strlen(c->faltam);
  snprintf(c->faltam + n, sizeof c->faltam - n, "%s%s", n ? "," : "", nome);
}

/* Junta o texto ja limpo (fica com `t`, que e apagado e liberado). */
static void juntar(conjunto_t *c, const char *nome, char *t, size_t n, int cortado, const segredos_t *sec) {
  if(c->n >= DIAG_MAX_ARQ) {
    memset(t, 0, n);
    free(t);
    return;
  }
  size_t nl = 0;
  char *l = limpar(t, n, sec, &nl);
  memset(t, 0, n);
  free(t);
  if(!l) {
    faltou(c, nome);
    return;
  }
  arq_t *a = &c->a[c->n++];
  snprintf(a->nome, sizeof a->nome, "%s", nome);
  a->d = l;
  a->n = nl;
  a->cortado = cortado;
}

static void juntar_arquivo(conjunto_t *c, const char *nome, const char *caminho, const segredos_t *sec, int opcional) {
  size_t n = 0;
  int cortado = 0;
  char *t = ler_final(caminho, DIAG_TAIL, &n, &cortado);
  if(!t) {
    if(!opcional) faltou(c, nome);
    return;
  }
  juntar(c, nome, t, n, cortado, sec);
}

static void juntar_buf(conjunto_t *c, const char *nome, buf_t *b, const segredos_t *sec) {
  if(!b->d || !b->n) {
    buf_free(b);
    faltou(c, nome);
    return;
  }
  char *t = b->d;
  size_t n = b->n;
  int cortado = 0;
  if(n > DIAG_TAIL) {   /* nao acontece com os JSON de hoje; por garantia */
    memmove(t, t + (n - DIAG_TAIL), DIAG_TAIL);
    n = DIAG_TAIL;
    t[n] = 0;
    cortado = 1;
  }
  b->d = NULL;
  b->n = b->cap = 0;
  juntar(c, nome, t, n, cortado, sec);
}

/* config.ini: as linhas "paired" (aparelhos pareados) viram "paired = [aparelho pareado]". */
static void juntar_config(conjunto_t *c, const segredos_t *sec) {
  char caminho[600];
  snprintf(caminho, sizeof caminho, "%s/config.ini", g_pasta_dados);
  size_t n = 0;
  int cortado = 0;
  char *t = ler_final(caminho, DIAG_TAIL, &n, &cortado);
  if(!t) {
    faltou(c, "config.ini");
    return;
  }
  buf_t b = {0};
  for(char *l = t; *l;) {
    char *fim = strchr(l, '\n');
    size_t tl = fim ? (size_t)(fim - l) + 1 : strlen(l);
    const char *x = l;
    while(*x == ' ' || *x == '\t') x++;
    if(!strncmp(x, "paired", 6) && (x[6] == ' ' || x[6] == '=' || x[6] == '\t')) buf_str(&b, "paired = [aparelho pareado]\n");
    else buf_add(&b, l, tl);
    l += tl;
  }
  memset(t, 0, n);
  free(t);
  if(!b.d) buf_add(&b, "", 0);
  juntar_buf(c, "config.ini", &b, sec);
}

/* Junta tudo (ja limpo) em `c`. */
static void coletar(conjunto_t *c, const char *pasta, const char *de) {
  memset(c, 0, sizeof *c);
  segredos_t sec;
  segredos_conhecidos(&sec);
  char caminho[600], fw[16] = "";
  const char *origem = "";
  char k[256];
  ler_chave(k, sizeof k, &origem);
  memset(k, 0, sizeof k);
  payloads_firmware(fw, sizeof fw);

  snprintf(caminho, sizeof caminho, "%s/glibren.log", g_pasta_dados);
  juntar_arquivo(c, "glibren.log", caminho, &sec, 0);
  juntar_config(c, &sec);
  buf_t b = {0};
  termico_json(&b, 1);   /* temperaturas, ventoinha, consumo (W) e o historico */
  juntar_buf(c, "termico.json", &b, &sec);
  payloads_json(&b);     /* payloads de teste: estado, erro e a saida do ultimo */
  juntar_buf(c, "payloads.json", &b, &sec);
  cheats_json(&b);       /* cheats: jogo aberto, catalogo e o que esta ligado */
  juntar_buf(c, "cheats.json", &b, &sec);
  cheats_caminho_aplicadas(caminho, sizeof caminho);
  juntar_arquivo(c, "cheats-aplicadas.json", caminho, &sec, 1);
  discos_listar(&b);     /* discos e espaco livre */
  juntar_buf(c, "discos.json", &b, &sec);
  arquivo_fullscreen(caminho, sizeof caminho);
  juntar_arquivo(c, "web-browser-fullscreen.ini", caminho, &sec, 1);

  /* info.json: versao, firmware, de onde veio o pedido e o que foi junto */
  char pareados[MAX_PAREADOS][TAM_PAREADO];
  int q = config_pareados(pareados, MAX_PAREADOS);
  memset(pareados, 0, sizeof pareados);
  buf_str(&b, "{\"pasta\":");
  buf_json(&b, pasta);
  buf_str(&b, ",\"pedido\":");
  buf_json(&b, de);
  buf_str(&b, ",\"glibren\":");
  buf_json(&b, VERSAO);
  buf_str(&b, ",\"firmware\":");
  buf_json(&b, fw);
  buf_fmt(&b, ",\"hora\":%lld,\"chave_de\":", (long long)time(NULL));
  buf_json(&b, origem);
  buf_fmt(&b, ",\"pareamento\":{\"ligado\":%s,\"aparelhos\":%d},\"arquivos\":[", config_pareamento() ? "true" : "false", q);
  for(int i = 0; i < c->n; i++) {
    buf_str(&b, i ? ",{\"nome\":" : "{\"nome\":");
    buf_json(&b, c->a[i].nome);
    buf_fmt(&b, ",\"bytes\":%zu,\"cortado\":%s}", c->a[i].n, c->a[i].cortado ? "true" : "false");
  }
  buf_str(&b, "],\"faltam\":");
  buf_json(&b, c->faltam);
  buf_str(&b, "}\n");
  juntar_buf(c, "info.json", &b, &sec);
  memset(&sec, 0, sizeof sec);
}

/* ------------------------------------------------------------------ envio */

static void base64(buf_t *b, const unsigned char *d, size_t n) {
  static const char T[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  char q[4];
  for(size_t i = 0; i < n; i += 3) {
    uint32_t v = (uint32_t)d[i] << 16 | (i + 1 < n ? (uint32_t)d[i + 1] << 8 : 0) | (i + 2 < n ? d[i + 2] : 0);
    q[0] = T[v >> 18 & 63];
    q[1] = T[v >> 12 & 63];
    q[2] = i + 1 < n ? T[v >> 6 & 63] : '=';
    q[3] = i + 2 < n ? T[v & 63] : '=';
    buf_add(b, q, 4);
  }
}

static int enviar_um(const char *chave, const char *pasta, const char *msg, const arq_t *a) {
  buf_t corpo = {0};
  buf_str(&corpo, "{\"message\":");
  buf_json(&corpo, msg);
  buf_str(&corpo, ",\"committer\":" DIAG_COMMITTER ",\"branch\":\"main\",\"content\":\"");
  base64(&corpo, (const unsigned char *)a->d, a->n);
  buf_str(&corpo, "\"}");
  char caminho[300];
  snprintf(caminho, sizeof caminho, DIAG_REPO "%s/%s", pasta, a->nome);
  int status = https_github_put(caminho, chave, corpo.d, corpo.n);
  buf_free(&corpo);
  return status;
}

static void terminar(const char *estado, const char *erro, int http) {
  pthread_mutex_lock(&g_trava);
  snprintf(g_d.estado, sizeof g_d.estado, "%s", estado);
  snprintf(g_d.erro, sizeof g_d.erro, "%s", erro);
  g_d.http = http;
  g_d.rodando = 0;
  g_d.em = (long long)time(NULL);
  pthread_mutex_unlock(&g_trava);
}

static void nome_pasta(char *s, size_t tam) {
#ifndef __PROSPERO__
  const char *e = getenv("GLR_TESTE_DIAG_PASTA");
  if(e && *e) {
    snprintf(s, tam, "%s", e);
    return;
  }
#endif
  time_t agora = time(NULL);
  struct tm t;
  localtime_r(&agora, &t);
  if(!strftime(s, tam, "%Y-%m-%d_%H%M%S", &t)) snprintf(s, tam, "sem-data");
}

static void *rodada(void *arg) {
  char pasta[24];
  snprintf(pasta, sizeof pasta, "%s", (char *)arg);
  free(arg);
  char chave[256];
  const char *origem = "";
  if(!ler_chave(chave, sizeof chave, &origem)) {
    terminar("failed", "no-key", 0);
    return NULL;
  }
  conjunto_t *c = malloc(sizeof *c);
  if(!c) {
    memset(chave, 0, sizeof chave);
    terminar("failed", "memory", 0);
    return NULL;
  }
  coletar(c, pasta, "celular");
  char msg[120];
  snprintf(msg, sizeof msg, "diagnostico glibren %s %s", pasta, VERSAO);
  pthread_mutex_lock(&g_trava);
  g_d.total = c->n;
  pthread_mutex_unlock(&g_trava);
  int status = 0, enviados = 0;
  for(int i = 0; i < c->n; i++) {
    status = enviar_um(chave, pasta, msg, &c->a[i]);
    if(status != 200 && status != 201) break;
    pthread_mutex_lock(&g_trava);
    g_d.enviados = ++enviados;
    pthread_mutex_unlock(&g_trava);
  }
  memset(chave, 0, sizeof chave);
  int total = c->n;
  conjunto_liberar(c);
  free(c);
  if(!total) {
    terminar("failed", "nothing", 0);
    diario("diagnostico: nada para enviar");
    return NULL;
  }
  if(enviados == total) {
    terminar("done", "", status);
    diario("diagnostico: enviado (%d arquivo(s), pasta glibren/%s, chave do %s)", enviados, pasta, origem);
    return NULL;
  }
  const char *erro = status == -1 ? "network" : status == 401 ? "unauthorized" : status == 403 ? "forbidden" : status == 404 ? "no-repo" : "http";
  terminar("failed", erro, status > 0 ? status : 0);
  diario("diagnostico: falhou (%s, HTTP %d) depois de %d de %d arquivo(s), pasta glibren/%s", erro, status > 0 ? status : 0, enviados, total, pasta);
  return NULL;
}

/* ------------------------------------------------------------------ zip (so "stored": os textos sao pequenos) */

static void le16(buf_t *b, unsigned v) {
  unsigned char x[2] = {(unsigned char)v, (unsigned char)(v >> 8)};
  buf_add(b, x, 2);
}
static void le32(buf_t *b, uint32_t v) {
  unsigned char x[4] = {(unsigned char)v, (unsigned char)(v >> 8), (unsigned char)(v >> 16), (unsigned char)(v >> 24)};
  buf_add(b, x, 4);
}

static void montar_zip(const conjunto_t *c, const char *pasta, buf_t *z) {
  time_t agora = time(NULL);
  struct tm t;
  localtime_r(&agora, &t);
  unsigned hora = (unsigned)(t.tm_hour << 11 | t.tm_min << 5 | t.tm_sec / 2);
  unsigned data = (unsigned)((t.tm_year > 80 ? t.tm_year - 80 : 0) << 9 | (t.tm_mon + 1) << 5 | t.tm_mday);
  uint32_t off[DIAG_MAX_ARQ], crc[DIAG_MAX_ARQ];
  char nomes[DIAG_MAX_ARQ][96];
  for(int i = 0; i < c->n; i++) {
    snprintf(nomes[i], sizeof nomes[i], "%s/%s", pasta, c->a[i].nome);
    crc[i] = (uint32_t)mz_crc32(MZ_CRC32_INIT, (const unsigned char *)c->a[i].d, c->a[i].n);
    off[i] = (uint32_t)z->n;
    le32(z, 0x04034b50);
    le16(z, 20);
    le16(z, 0x0800);   /* nomes em UTF-8 */
    le16(z, 0);        /* stored */
    le16(z, hora);
    le16(z, data);
    le32(z, crc[i]);
    le32(z, (uint32_t)c->a[i].n);
    le32(z, (uint32_t)c->a[i].n);
    le16(z, (unsigned)strlen(nomes[i]));
    le16(z, 0);
    buf_str(z, nomes[i]);
    buf_add(z, c->a[i].d, c->a[i].n);
  }
  uint32_t ini_cd = (uint32_t)z->n;
  for(int i = 0; i < c->n; i++) {
    le32(z, 0x02014b50);
    le16(z, 20);
    le16(z, 20);
    le16(z, 0x0800);
    le16(z, 0);
    le16(z, hora);
    le16(z, data);
    le32(z, crc[i]);
    le32(z, (uint32_t)c->a[i].n);
    le32(z, (uint32_t)c->a[i].n);
    le16(z, (unsigned)strlen(nomes[i]));
    le16(z, 0);
    le16(z, 0);
    le16(z, 0);
    le16(z, 0);
    le32(z, 0644u << 16);
    le32(z, off[i]);
    buf_str(z, nomes[i]);
  }
  uint32_t tam_cd = (uint32_t)z->n - ini_cd;
  le32(z, 0x06054b50);
  le16(z, 0);
  le16(z, 0);
  le16(z, (unsigned)c->n);
  le16(z, (unsigned)c->n);
  le32(z, tam_cd);
  le32(z, ini_cd);
  le16(z, 0);
}

/* ------------------------------------------------------------------ rotas */

static void responder_estado(pedido_t *p) {
  buf_t b = {0};
  estado_json(&b);
  responder_json(p, 200, &b);
  buf_free(&b);
}

void diagnostico_rota_estado(pedido_t *p) {
  responder_estado(p);
}

void diagnostico_rota_chave(pedido_t *p) {
  char k[300] = "";
  if(p->corpo) param(p->corpo, "chave", 0, k, sizeof k);
  /* espacos ou quebra de linha colados junto saem */
  char *ini = k;
  while(*ini == ' ' || *ini == '\t' || *ini == '\n' || *ini == '\r') ini++;
  size_t n = strlen(ini);
  while(n && (ini[n - 1] == ' ' || ini[n - 1] == '\t' || ini[n - 1] == '\n' || ini[n - 1] == '\r')) ini[--n] = 0;
  if(!chave_ok(ini)) {
    memset(k, 0, sizeof k);
    responder_erro(p, 400, "diag_chave_invalida", "isso nao parece uma chave do GitHub (github_pat_...)", NULL);
    return;
  }
  char pasta[512], arq[600], tmp[620];
  pasta_diag(pasta, sizeof pasta);
  arquivo_chave(arq, sizeof arq);
  snprintf(tmp, sizeof tmp, "%s.novo", arq);
  int ok = !mkdir_p(pasta);
  if(ok) {
    chmod(pasta, 0700);
    unlink(tmp);
    int fd = open(tmp, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0600);
    ok = fd >= 0 && write(fd, ini, n) == (ssize_t)n;
    if(fd >= 0) {
      fchmod(fd, 0600);
      if(close(fd)) ok = 0;
    }
    ok = ok && !rename(tmp, arq);
    if(!ok) unlink(tmp);
  }
  memset(k, 0, sizeof k);
  if(!ok) {
    responder_erro(p, 500, "diag_nao_gravou", "nao gravou a chave", NULL);
    return;
  }
  diario("diagnostico: chave do GitHub gravada pela pagina");
  responder_estado(p);
}

void diagnostico_rota_remover(pedido_t *p) {
  char arq[600];
  arquivo_chave(arq, sizeof arq);
  if(!unlink(arq)) diario("diagnostico: chave do GitHub removida pela pagina");
  responder_estado(p);
}

void diagnostico_rota_enviar(pedido_t *p) {
  char k[256];
  int tem = ler_chave(k, sizeof k, NULL);
  memset(k, 0, sizeof k);
  if(!tem) {
    responder_erro(p, 400, "diag_sem_chave", "falta a chave do GitHub", NULL);
    return;
  }
  char *pasta = calloc(1, 24);
  if(!pasta) {
    responder_erro(p, 500, "diag_memoria", "sem memoria", NULL);
    return;
  }
  nome_pasta(pasta, 24);
  pthread_mutex_lock(&g_trava);
  if(g_d.rodando) {
    pthread_mutex_unlock(&g_trava);
    free(pasta);
    responder_erro(p, 409, "diag_ocupado", "ja ha um envio em andamento", NULL);
    return;
  }
  if(!strcmp(pasta, g_ult_pasta)) {   /* a mesma hora da rodada anterior: -2, -3... */
    char base[24];
    snprintf(base, sizeof base, "%s", pasta);
    if(g_usos < 99) g_usos++;
    snprintf(pasta, 24, "%.17s-%d", base, g_usos);
  } else {
    snprintf(g_ult_pasta, sizeof g_ult_pasta, "%s", pasta);
    g_usos = 1;
  }
  g_d.rodando = 1;
  snprintf(g_d.estado, sizeof g_d.estado, "running");
  snprintf(g_d.pasta, sizeof g_d.pasta, "%s", pasta);
  g_d.erro[0] = 0;
  g_d.http = g_d.enviados = g_d.total = 0;
  g_d.em = (long long)time(NULL);
  pthread_mutex_unlock(&g_trava);
  diario("diagnostico: rodada pedida (pasta glibren/%s)", pasta);
  if(criar_thread(rodada, pasta, NULL)) {
    free(pasta);
    terminar("failed", "memory", 0);
    responder_erro(p, 500, "diag_memoria", "sem memoria", NULL);
    return;
  }
  responder(p, 200, "application/json", "{\"ok\":true,\"estado\":\"running\"}", 30, NULL);
}

void diagnostico_rota_zip(pedido_t *p) {
  char pasta[24];
  nome_pasta(pasta, sizeof pasta);
  conjunto_t *c = malloc(sizeof *c);
  if(!c) {
    responder(p, 500, "text/plain", "", 0, NULL);
    return;
  }
  coletar(c, pasta, "zip");
  buf_t z = {0};
  montar_zip(c, pasta, &z);
  conjunto_liberar(c);
  free(c);
  diario("diagnostico: .zip baixado (%zu bytes)", z.n);
  responder(p, 200, "application/zip", z.d, z.n, "no-store");
  if(z.d) memset(z.d, 0, z.n);
  buf_free(&z);
}
