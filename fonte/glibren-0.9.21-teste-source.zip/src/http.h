/* Game Library Renamer (payload PS5) - servidor HTTP minimo (uma thread por conexao). */
#pragma once

#include <stddef.h>
#include "util.h"

typedef struct {
  int fd;
  char metodo[8];
  char caminho[1024];       /* sem a query, ja decodificado */
  char query[4096];         /* bruta (urlencoded) */
  char tipo[128];           /* Content-Type */
  char se_nao_mudou[128];   /* If-None-Match */
  char host[128];           /* Host */
  char agente[256];         /* User-Agent (a pagina de FPS recusa o navegador do PS5) */
  char token[96];            /* X-GLR-Token: aparelho pareado (0.9.16) */
  int pedido_do_app;        /* cabecalho X-GLR presente (bloqueia formularios de outros sites) */
  int aceita_gzip;          /* Accept-Encoding com gzip */
  int local;                /* conexao vinda do proprio PS5 (127.0.0.0/8) */
  char *corpo;
  size_t corpo_n;
} pedido_t;

typedef void (*tratador_t)(pedido_t *p);

/* Escuta na porta e chama o tratador para cada pedido. So volta em erro (ou quando servidor_parar). */
int servidor_rodar(int porta, tratador_t tratador);
void servidor_parar(void);
/* Reabre a porta (depois do modo de repouso). */
void servidor_reabrir(void);

void responder(pedido_t *p, int status, const char *tipo, const void *corpo, size_t n, const char *cache);
void responder_json(pedido_t *p, int status, buf_t *json);
/* Pagina embutida: manda a versao gzip se o navegador aceitar (bem menor), senao a normal. */
void responder_pagina(pedido_t *p, const void *normal, size_t n_normal, const void *gz, size_t n_gz);
void responder_erro(pedido_t *p, int status, const char *chave, const char *mensagem, const char *nome);
/* Envia um arquivo do disco (com ETag: tamanho + data). Devolve 0 se enviou, -1 se nao existe. */
int responder_arquivo(pedido_t *p, const char *arquivo, const char *tipo, const char *cache);
