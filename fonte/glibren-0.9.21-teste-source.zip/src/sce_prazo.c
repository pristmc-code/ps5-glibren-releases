/* Game Library Renamer (payload PS5) - chamadas do sistema com prazo (ver sce_prazo.h).

No PC (testes): GLR_TESTE_SCE_TRAVA = nomes separados por virgula; a chamada com esse nome "trava" (a thread dorme
GLR_TESTE_SCE_TRAVA_S segundos, padrao 3600) em vez de chamar a funcao. */
#include "sce_prazo.h"

#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "plataforma.h"

#define MAX_NOMES 32
#define ESTOUROS_DE_VEZ 3   /* na 3a vez que estoura, fica morta ate o payload reiniciar */

typedef struct {
  pthread_mutex_t m;
  pthread_cond_t c;
  int pronto, refs, ret;
  sce_fn_t fn;
  char nome[48];
  struct timespec inicio;
  unsigned char entrada[SCE_PRAZO_ENTRADA], saida[SCE_PRAZO_SAIDA];
} trabalho_t;

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static struct {
  char nome[48];
  int presa;       /* 1 = uma chamada travada ainda nao voltou */
  int estouros;    /* quantas vezes estourou nesta sessao */
} g_nomes[MAX_NOMES];
static int g_qtd;
static unsigned long g_chamadas, g_estouros;

/* Indice do nome (cria se nao existe; -1 se a tabela encheu). Chamar com g_trava. */
static int achar(const char *nome) {
  for(int i = 0; i < g_qtd; i++)
    if(!strcmp(g_nomes[i].nome, nome)) return i;
  if(g_qtd == MAX_NOMES) return -1;
  snprintf(g_nomes[g_qtd].nome, sizeof g_nomes[g_qtd].nome, "%s", nome);
  return g_qtd++;
}

static int esta_morta(int i) {
  return i >= 0 && (g_nomes[i].presa || g_nomes[i].estouros >= ESTOUROS_DE_VEZ);
}

int sce_morta(const char *nome) {
  pthread_mutex_lock(&g_trava);
  int r = 0;
  for(int i = 0; i < g_qtd; i++)
    if(!strcmp(g_nomes[i].nome, nome)) r = esta_morta(i);
  pthread_mutex_unlock(&g_trava);
  return r;
}

static long ms_desde(const struct timespec *t0) {
  struct timespec t;
  clock_gettime(CLOCK_MONOTONIC, &t);
  return (t.tv_sec - t0->tv_sec) * 1000 + (t.tv_nsec - t0->tv_nsec) / 1000000;
}

static void soltar(trabalho_t *t) {
  pthread_mutex_lock(&t->m);
  int fim = --t->refs == 0;
  pthread_mutex_unlock(&t->m);
  if(fim) {
    pthread_mutex_destroy(&t->m);
    pthread_cond_destroy(&t->c);
    free(t);
  }
}

#ifndef __PROSPERO__
static int travar_no_teste(const char *nome) {
  const char *lista = getenv("GLR_TESTE_SCE_TRAVA");
  if(!lista || !*lista) return 0;
  size_t n = strlen(nome);
  for(const char *p = lista; *p;) {
    size_t k = strcspn(p, ",");
    if(k == n && !strncmp(p, nome, n)) return 1;
    p += k;
    if(*p == ',') p++;
  }
  return 0;
}
#endif

static void *rodar(void *arg) {
  trabalho_t *t = arg;
#ifndef __PROSPERO__
  if(travar_no_teste(t->nome)) {
    const char *s = getenv("GLR_TESTE_SCE_TRAVA_S");
    sleep(s && atoi(s) > 0 ? (unsigned)atoi(s) : 3600);
  }
#endif
  int r = t->fn(t->entrada, t->saida);
  pthread_mutex_lock(&t->m);
  t->ret = r;
  int atrasada = t->pronto < 0;   /* quem chamou ja desistiu (estourou o prazo) */
  t->pronto = 1;
  pthread_cond_signal(&t->c);
  pthread_mutex_unlock(&t->m);
  if(atrasada) {
    pthread_mutex_lock(&g_trava);
    int i = achar(t->nome);
    if(i >= 0) g_nomes[i].presa = 0;
    int de_vez = i >= 0 && g_nomes[i].estouros >= ESTOUROS_DE_VEZ;
    pthread_mutex_unlock(&g_trava);
    diario("watchdog: %s voltou depois de %ld ms%s", t->nome, ms_desde(&t->inicio),
           de_vez ? " (continua fora: estourou 3 vezes)" : " - volta a valer");
  }
  soltar(t);
  return NULL;
}

int sce_com_prazo(const char *nome, sce_fn_t fn, const void *entrada, size_t n_entrada, void *saida, size_t n_saida,
                  int prazo_ms, int *ret) {
  if(n_entrada > SCE_PRAZO_ENTRADA || n_saida > SCE_PRAZO_SAIDA) return SCE_SEM_THREAD;
  pthread_mutex_lock(&g_trava);
  int i = achar(nome);
  int morta = esta_morta(i);
  if(!morta) g_chamadas++;
  pthread_mutex_unlock(&g_trava);
  if(morta) return SCE_MORTA;

  trabalho_t *t = calloc(1, sizeof *t);
  if(!t) return SCE_SEM_THREAD;
  pthread_mutex_init(&t->m, NULL);
  pthread_cond_init(&t->c, NULL);
  t->refs = 2;   /* quem chama + a thread */
  t->fn = fn;
  snprintf(t->nome, sizeof t->nome, "%s", nome);
  if(entrada && n_entrada) memcpy(t->entrada, entrada, n_entrada);
  clock_gettime(CLOCK_MONOTONIC, &t->inicio);

  pthread_t th;
  pthread_attr_t attr;
  pthread_attr_init(&attr);
  pthread_attr_setstacksize(&attr, 256 * 1024);
  pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
  int erro = pthread_create(&th, &attr, rodar, t);
  pthread_attr_destroy(&attr);
  if(erro) {
    free(t);
    return SCE_SEM_THREAD;
  }

  struct timespec limite;
  clock_gettime(CLOCK_REALTIME, &limite);
  limite.tv_sec += prazo_ms / 1000;
  limite.tv_nsec += (long)(prazo_ms % 1000) * 1000000L;
  if(limite.tv_nsec >= 1000000000L) {
    limite.tv_sec++;
    limite.tv_nsec -= 1000000000L;
  }
  pthread_mutex_lock(&t->m);
  while(!t->pronto && pthread_cond_timedwait(&t->c, &t->m, &limite) != ETIMEDOUT) {}
  int pronto = t->pronto == 1;
  if(pronto) {
    if(ret) *ret = t->ret;
    if(saida && n_saida) memcpy(saida, t->saida, n_saida);
  }
  int n = 0;
  if(!pronto) {
    t->pronto = -1;   /* a thread avisa no diario se um dia voltar */
    /* marcada como presa ainda com t->m: a thread so limpa "presa" depois de ver pronto = -1 */
    pthread_mutex_lock(&g_trava);
    g_estouros++;
    if(i >= 0) {
      g_nomes[i].presa = 1;
      n = ++g_nomes[i].estouros;
    }
    pthread_mutex_unlock(&g_trava);
  }
  pthread_mutex_unlock(&t->m);
  soltar(t);
  if(pronto) return SCE_OK;
  diario("watchdog: %s nao respondeu em %d ms - fica fora ate voltar (%d de %d)", nome, prazo_ms, n, ESTOUROS_DE_VEZ);
  return SCE_ESTOUROU;
}

void sce_prazo_json(buf_t *b) {
  pthread_mutex_lock(&g_trava);
  buf_fmt(b, "\"watchdog\":{\"chamadas\":%lu,\"estouros\":%lu,\"mortas\":[", g_chamadas, g_estouros);
  int n = 0;
  for(int i = 0; i < g_qtd; i++) {
    if(!esta_morta(i)) continue;
    if(n++) buf_str(b, ",");
    buf_json(b, g_nomes[i].nome);
  }
  buf_str(b, "]}");
  pthread_mutex_unlock(&g_trava);
}
