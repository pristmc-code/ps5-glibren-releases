/* Game Library Renamer 0.9.20 - botao de tela cheia (⛶) no navegador do PS5.
   A pagina sozinha nao tira a moldura do navegador do PS5 (ela e desenhada pela interface do sistema). Este botao pede
   ao glibren o payload de teste "ps5-web-browser-fullscreen" (owendswang, GPL-3.0): o PS5 volta a tela inicial, o
   payload corrige a interface na memoria e o navegador reabre nesta mesma pagina, agora com 1920x1080.
   So no navegador do PS5; no celular/PC o botao de tela cheia de cada pagina continua o de sempre. */
(() => {
  if (!/PlayStation/i.test(navigator.userAgent)) return;
  const TX = {
    "pt-BR": { titulo: "Tela cheia no PS5", texto: "O glibren vai voltar à tela inicial, aplicar o payload de teste ps5-web-browser-fullscreen e reabrir esta página em tela cheia.",
      risco: "Teste: pode reiniciar a interface do PS5. Reiniciar o console desfaz.", ok: "Aplicar", nao: "Cancelar",
      indo: "Voltando à tela inicial… o navegador reabre sozinho em alguns segundos.", ativa: "Tela cheia ativa", botao: "Tela cheia",
      erro: "Não deu: {e}", jogo: "feche o jogo ou app aberto antes ({t})", ocupado: "outro payload está sendo baixado ou ativado: espere",
      falhou: "o PS5 não respondeu" },
    en: { titulo: "Fullscreen on the PS5", texto: "glibren will go back to the home screen, apply the test payload ps5-web-browser-fullscreen and reopen this page in fullscreen.",
      risco: "Test: it may restart the PS5 interface. Restarting the console undoes it.", ok: "Apply", nao: "Cancel",
      indo: "Going back to the home screen… the browser reopens by itself in a few seconds.", ativa: "Fullscreen on", botao: "Fullscreen",
      erro: "Failed: {e}", jogo: "close the open game or app first ({t})", ocupado: "another payload is being downloaded or activated: wait",
      falhou: "the PS5 did not respond" },
    es: { titulo: "Pantalla completa en la PS5", texto: "glibren volverá a la pantalla de inicio, aplicará el payload de prueba ps5-web-browser-fullscreen y reabrirá esta página en pantalla completa.",
      risco: "Prueba: puede reiniciar la interfaz de la PS5. Reiniciar la consola lo deshace.", ok: "Aplicar", nao: "Cancelar",
      indo: "Volviendo a la pantalla de inicio… el navegador se reabre solo en unos segundos.", ativa: "Pantalla completa activa", botao: "Pantalla completa",
      erro: "No se pudo: {e}", jogo: "cierre antes el juego o app abierto ({t})", ocupado: "otro payload se está descargando o activando: espere",
      falhou: "la PS5 no respondió" },
  };
  const tx = (k, p = {}) => { const l = TX[document.documentElement.lang] || TX["pt-BR"]; return (l[k] || TX["pt-BR"][k]).replace(/\{(\w+)\}/g, (_, x) => p[x] ?? ""); };
  // Em tela cheia (patch aplicado) a janela mede 1920x1080; com a moldura, ~1540x700 (pesquisa de 13/11/2026)
  const cheia = () => innerWidth >= 1900 && innerHeight >= 1060;

  let janela = null;
  function montar() {
    janela = document.createElement("div");
    janela.id = "glrTelaPs5";
    janela.innerHTML = `<style>
      #glrTelaPs5 { position: fixed; inset: 0; z-index: 2147483000; background: rgba(2,6,12,.75); display: flex; align-items: center; justify-content: center; padding: 16px; }
      #glrTelaPs5[hidden] { display: none; }
      #glrTelaPs5 .caixa { width: min(560px, 100%); background: #10161f; color: #eef3f9; border: 2px solid #2f8cff; border-radius: 16px; padding: 16px 18px;
        font: 500 17px/1.35 "Segoe UI", system-ui, sans-serif; display: grid; gap: 12px; overflow-wrap: anywhere; }
      #glrTelaPs5 h2 { margin: 0; font-size: 21px; }
      #glrTelaPs5 p { margin: 0; }
      #glrTelaPs5 .risco { color: #facc15; font-size: 15px; }
      #glrTelaPs5 .estado { color: #38bdf8; min-height: 1.35em; }
      #glrTelaPs5 .estado.erro { color: #ff6b6b; }
      #glrTelaPs5 .botoes { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
      #glrTelaPs5 button { font: 700 17px "Segoe UI", system-ui, sans-serif; color: #eef3f9; background: #161e2a; border: 1px solid #3d5178; border-radius: 10px; padding: 10px 14px; min-height: 48px; cursor: pointer; }
      #glrTelaPs5 button.prim { background: #2f8cff; border-color: #2f8cff; }
      #glrTelaPs5 button:focus { outline: 3px solid #eef3f9; }
    </style><div class="caixa" role="dialog" aria-modal="true" aria-labelledby="glrTelaTit">
      <h2 id="glrTelaTit"></h2><p id="glrTelaTxt"></p><p class="risco" id="glrTelaRisco"></p><p class="estado" id="glrTelaEst"></p>
      <div class="botoes"><button type="button" class="prim" id="glrTelaOk"></button><button type="button" id="glrTelaNao"></button></div></div>`;
    document.body.append(janela);
    const $j = id => janela.querySelector("#" + id);
    $j("glrTelaNao").onclick = () => { janela.hidden = true; };
    janela.addEventListener("keydown", e => { if (e.key === "Escape") janela.hidden = true; });
    $j("glrTelaOk").onclick = async () => {
      const est = $j("glrTelaEst");
      $j("glrTelaOk").disabled = true;
      est.className = "estado";
      est.textContent = "…";
      let r = null;
      try {
        const resp = await fetch("/api/payloads/ativar", { method: "POST", headers: { "X-GLR": "1" },
          body: new URLSearchParams({ id: "web-browser-fullscreen", reabrir: location.pathname + location.search }) });
        r = await resp.json();
      } catch { r = null; }
      if (r && r.ok) { est.textContent = tx("indo"); return; }
      const motivo = !r ? tx("falhou") : r.chave === "payload_jogo_aberto" ? tx("jogo", { t: r.params?.nome || "" })
        : r.chave === "payload_ocupado" ? tx("ocupado") : (r.erro || tx("falhou"));
      est.className = "estado erro";
      est.textContent = tx("erro", { e: motivo });
      $j("glrTelaOk").disabled = false;
    };
  }
  function abrir() {
    if (!janela) montar();
    const $j = id => janela.querySelector("#" + id);
    for (const [id, k] of [["glrTelaTit", "titulo"], ["glrTelaTxt", "texto"], ["glrTelaRisco", "risco"], ["glrTelaOk", "ok"], ["glrTelaNao", "nao"]]) $j(id).textContent = tx(k);
    $j("glrTelaEst").textContent = "";
    $j("glrTelaEst").className = "estado";
    $j("glrTelaOk").disabled = false;
    janela.hidden = false;
    setTimeout(() => $j("glrTelaOk").focus(), 50);
  }
  window.glrTelaCheiaPs5 = abrir;

  function ligar() {
    // botao de tela cheia que a pagina ja tem (escondido no PS5); a pagina /payloads e o teste usam glrTelaCheiaPs5()
    const b = document.getElementById("btnTelaCheia") || document.getElementById("telaCheia");
    document.documentElement.classList.toggle("ps5-cheia", cheia());
    if (!b) return;
    b.hidden = cheia();   // ja em tela cheia: nada a fazer (reiniciar o PS5 desfaz)
    b.title = tx("botao");
    b.onclick = e => { e.preventDefault(); abrir(); };
    if (typeof window.ajustarChips === "function") window.ajustarChips();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", ligar); else ligar();
  addEventListener("resize", ligar);
})();
