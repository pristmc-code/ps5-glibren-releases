// 0.9.37: pagina principal - versao de cada jogo e "Existe X (pede firmware Y)" com os resultados guardados pelo
// celular/PC, destaque quando o firmware pedido passa o do console, "consultado em", filtro "Com atualizacao" e sem rolar
// de lado (celular em pe/deitado e PC). Chamado pelo testes/teste_versoes.sh com o glibren-pc no ar.
//   node teste_versoes_pagina.mjs http://127.0.0.1:8921 <pasta do pacote playwright>
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const [base, pw] = process.argv.slice(2);
const { chromium } = await import(pathToFileURL(path.join(pw, 'index.mjs')).href);
let ok = 0, falhas = 0;
const confere = (nome, cond, info = '') => { if (cond) { ok++; console.log('OK   ' + nome); } else { falhas++; console.log('FALHA ' + nome + (info ? ': ' + info : '')); } };

let navegador;
for (const channel of ['msedge', 'chrome']) { try { navegador = await chromium.launch({ channel }); break; } catch { /* outro */ } }
if (!navegador) { console.log('FALHA nenhum navegador abriu'); console.log('=== pagina 0 ok, 1 falhas'); process.exit(1); }

for (const tela of [{ w: 360, h: 780, nome: 'celular em pe' }, { w: 780, h: 360, nome: 'celular deitado' }, { w: 1280, h: 800, nome: 'PC' }]) {
  const pagina = await navegador.newPage({ viewport: { width: tela.w, height: tela.h }, locale: 'pt-BR' });
  const n = s => `${s} (${tela.nome})`;
  await pagina.goto(base + '/');
  await pagina.evaluate(() => { try { localStorage.clear(); } catch { /* nada */ } });
  await pagina.reload();
  await pagina.click('#btnConectar');
  await pagina.waitForFunction(() => document.querySelectorAll('#corpoFtp .ver-jogo').length >= 3, null, { timeout: 30000 });
  await pagina.click('#filtrosFtp [data-filtro="todos"]');
  const linha = nome => pagina.$$eval('#corpoFtp tr', (trs, nome) => {
    const tr = trs.find(t => (t.querySelector('.arq:not(.novo)')?.textContent || '') === nome);
    return tr ? { txt: tr.innerText, alerta: !!tr.querySelector('.upd.alerta'), upd: !!tr.querySelector('.upd') } : null;
  }, nome);
  let l = await linha('Saros');
  confere(n('versao local + firmware'), l && l.txt.includes('Versão 01.000.002 · pede firmware 10.40'), l?.txt);
  confere(n('existe versao nova'), l && l.txt.includes('Existe 02.000.003 (pede firmware 14.20)'), l?.txt);
  confere(n('pre-download junto'), l && l.txt.includes('também 02.000.002 (pede firmware 13.00)'), l?.txt);
  confere(n('destaque: firmware maior que o do PS5'), l && l.alerta && l.txt.includes('Firmware maior que o deste PS5 (12.00)'), l?.txt);
  confere(n('consultado em'), l && /consultado em \d\d\/\d\d \d\d:\d\d/.test(l.txt), l?.txt);
  l = await linha('EmDia');
  confere(n('em dia'), l && l.txt.includes('Em dia com a Sony') && !l.upd, l?.txt);
  l = await linha('Ps4Jogo');
  confere(n('PS4: so a versao local'), l && l.txt.includes('Versão 01.05 · pede firmware 5.05') && !l.txt.includes('Sony'), l?.txt);
  l = await linha('Malicioso');
  confere(n('sem dado: nada da Sony'), l && l.txt.includes('Versão 01.000.000') && !l.txt.includes('Existe') && !l.txt.includes('Sony'), l?.txt);
  const chip = '#chipsFtp [data-grupo="upd"]';
  confere(n('filtro Com atualizacao visivel com 1'), await pagina.isVisible(chip) && (await pagina.textContent(chip)).includes('Com atualização1'), await pagina.textContent(chip));
  const semRolagem = () => pagina.evaluate(() => document.scrollingElement.scrollWidth <= innerWidth);
  confere(n('lista sem rolar de lado'), await semRolagem());
  await pagina.click(chip);
  const nomes = await pagina.$$eval('#corpoFtp .arq:not(.novo)', ds => ds.map(d => d.textContent));
  confere(n('filtro: so o jogo com atualizacao'), nomes.length === 1 && nomes[0] === 'Saros', nomes.join(','));
  confere(n('filtrado sem rolar de lado'), await semRolagem());
  await pagina.click(chip);
  await pagina.close();
}
await navegador.close();
console.log(`=== pagina ${ok} ok, ${falhas} falhas`);
process.exit(falhas ? 1 : 0);
