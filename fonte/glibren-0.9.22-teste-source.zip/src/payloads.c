/* Game Library Renamer (payload PS5) - payloads de terceiros para teste (0.9.20). Ver payloads.h.

Regras:
  - so os itens do catalogo abaixo (id fora da lista = recusado); URL, tamanho e SHA-256 fixados aqui;
  - o arquivo baixado E o arquivo guardado sao conferidos pelo SHA-256 antes de enviar ao elfldr (adulterado = recusado
    e apagado);
  - 0.9.22: os itens marcados "shellui" (tela cheia e PrefBar) mexem na mesma interface: um ativo nesta sessao do PS5
    bloqueia os outros; "uma_vez" (PrefBar fica rodando) nao ativa duas vezes. .ativado = "hora pid_da_SceShellUI";
    vale depois do kern.boottime e com a mesma ShellUI;
  - um trabalho por vez; nada com jogo/app aberto (se a interface do PS5 reiniciar, o jogo fecharia sem salvar);
  - rota POST com X-GLR e pareamento (api.c). O navegador do PS5 (e outros programas do proprio PS5, que o pareamento
    deixa passar) so pode acionar o item marcado "navegador" (tela cheia): e o unico que faz sentido ali, e e o mesmo
    gesto de quem esta com o controle na mao diante da TV;
  - item "navegador" (modelo do PS5 Web File Manager, botao de tela cheia): responde, 250 ms, volta a tela inicial
    (sceShellUIUtilLaunchByUri "pshomeui:navigateToHome"), 1 s, envia ao elfldr, espera o resultado e reabre o navegador
    na pagina pedida (sceSystemServiceLaunchWebBrowser), mesmo se falhar, para ninguem ficar perdido na tela inicial.
O resultado vem da saida do proprio payload: o elfldr (ps5-payload-dev) liga stdin/stdout/stderr do payload a conexao
que o enviou. O ps5-web-browser-fullscreen escreve "Result=N; ..." (0 = ok, 2 = ok mas o INI nao gravou, 1 = falhou) e
"Notification: <texto>".
Testes no PC: GLR_TESTE_ELFLDR (porta do elfldr falso), GLR_TESTE_PAYLOADS_URL (base no lugar do GitHub, servidor local
de GLR_TESTE_BASE), GLR_TESTE_PAYLOAD_SHA/GLR_TESTE_PAYLOAD_TAM (outro arquivo no lugar do .elf real), GLR_TESTE_FW. */
#include "payloads.h"

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#include "api.h"
#include "config.h"
#include "fps.h"
#include "https.h"
#include "lancador.h"
#include "plataforma.h"
#include "prefbar.h"
#include "sha256.h"

#ifdef __PROSPERO__
#include <ps5/kernel.h>
#include <sys/sysctl.h>
#include <sys/user.h>
int sceKernelLoadStartModule(const char *, size_t, const void *, uint32_t, void *, int *) __attribute__((weak));
int sceSystemServiceLaunchWebBrowser(const char *, void *) __attribute__((weak));
int sceUserServiceGetForegroundUser(uint32_t *) __attribute__((weak));
#endif

#define PORTA_ELFLDR 9021
#define MAX_SAIDA (16 * 1024)
#ifdef MSG_NOSIGNAL
#define SEM_SINAL MSG_NOSIGNAL   /* elfldr fechou no meio: erro, nao queda */
#else
#define SEM_SINAL 0
#endif

typedef struct {
  const char *id, *nome, *autor, *licenca, *repo, *tag, *url, *arquivo, *sha256;
  unsigned long long tamanho;
  const char *firmwares;              /* testados em console (autor e comunidade), separados por espaco */
  const char *descricao[3];           /* pt-BR, en, es */
  const char *desfazer[3];
  const char *aviso[3];
  int espera_s;                       /* quanto esperar a saida do payload (ele termina sozinho) */
  int navegador;                      /* 1 = tela cheia do navegador: volta a home, aplica e reabre */
  int shellui;                        /* 0.9.22: 1 = mexe na interface do PS5 (SceShellUI): so um destes por sessao */
  int uma_vez;                        /* 0.9.22: 1 = fica rodando; ativar de novo na mesma sessao = duas copias (recusado) */
} item_t;

static const item_t ITENS[] = {
  {"web-browser-fullscreen", "PS5 Web Browser Fullscreen", "owendswang", "GPL-3.0-or-later",
   "https://github.com/owendswang/ps5-web-browser-fullscreen", "v0.1b",
   "https://github.com/owendswang/ps5-web-browser-fullscreen/releases/download/v0.1b/web-browser-fullscreen-v0.1b.elf",
   "web-browser-fullscreen-v0.1b.elf",
   "520977607a22ecdf51c8d8b75360486026e0bd8780ded8026c3456fac7997a97",   /* baixado e calculado em 13/11/2026 (= digest do GitHub) */
   463848ULL,
   "4.03 6.50 7.00 7.61 10.01 10.20 11.20 12.02 12.20 13.00 13.60",
   {"Deixa o navegador do PS5 em tela cheia (1920x1080, sem a moldura). Corrige a interface do PS5 (ShellUI) só na memória: nenhum arquivo do sistema é alterado.",
    "Makes the PS5 web browser fullscreen (1920x1080, without the frame). Patches the PS5 interface (ShellUI) in memory only: no system file is changed.",
    "Pone el navegador de la PS5 en pantalla completa (1920x1080, sin el marco). Corrige la interfaz de la PS5 (ShellUI) solo en la memoria: ningún archivo del sistema se modifica."},
   {"Reinicie o PS5 (trocar o idioma do sistema também desfaz). O glibren não usa o \"restore\" do autor: no 11.60 ele derrubou a interface.",
    "Restart the PS5 (changing the system language also undoes it). glibren does not use the author's \"restore\": on 11.60 it crashed the interface.",
    "Reinicie la PS5 (cambiar el idioma del sistema también lo deshace). glibren no usa el \"restore\" del autor: en 11.60 tumbó la interfaz."},
   {"O PS5 volta à tela inicial, aplica e reabre o navegador. Outros cartões do sistema podem mudar de tamanho enquanto valer.",
    "The PS5 goes back to the home screen, applies it and reopens the browser. Other system cards may change size while it lasts.",
    "La PS5 vuelve a la pantalla de inicio, lo aplica y reabre el navegador. Otras tarjetas del sistema pueden cambiar de tamaño mientras dure."},
   30, 1, 1, 0},
  /* 0.9.22: PrefBar (numeros por cima do jogo). Fica rodando: espera um jogo abrir e a interface do PS5 ficar estavel e
     so entao se injeta na SceShellUI (o README manda carregar e DEPOIS abrir o jogo). Nao escreve nada na saida quando
     da certo: o glibren espera 4 s por um erro do elfldr e solta a conexao. */
  {"prefbar", "PrefBar", "X1NONs", "GPL-3.0",
   "https://github.com/X1NONs/PrefBar", "v0.3.0",
   "https://github.com/X1NONs/PrefBar/releases/download/v0.3.0/Prefbar_V0.3.0.elf",
   "Prefbar_V0.3.0.elf",
   "e4379590115ef87b2f0310b502321d7da30783536d939bfb1c4c0e511972af30",   /* baixado e calculado em 13/11/2026 (= digest do GitHub) */
   964272ULL,
   "7.xx 8.xx 9.xx 10.xx 11.xx 12.xx 13.xx",
   {"Mostra FPS, 1% low, CPU e GPU (uso, temperatura, MHz), ventoinha, RAM, VRAM e consumo numa barra por cima do jogo. Ative fora do jogo e depois abra o jogo: a barra aparece alguns segundos depois. Três toques no touchpad mostram ou escondem.",
    "Shows FPS, 1% low, CPU and GPU (usage, temperature, MHz), fan, RAM, VRAM and power in a bar over the game. Activate it outside the game, then open the game: the bar shows up a few seconds later. Triple-tap the touchpad to show or hide it.",
    "Muestra FPS, 1% low, CPU y GPU (uso, temperatura, MHz), ventilador, RAM, VRAM y consumo en una barra sobre el juego. Actívelo fuera del juego y luego abra el juego: la barra aparece unos segundos después. Tres toques en el touchpad la muestran u ocultan."},
   {"Reinicie o PS5 (nada fica instalado; para limpar tudo, apague a pasta /data/prefbar).",
    "Restart the PS5 (nothing stays installed; to clean everything, delete the /data/prefbar folder).",
    "Reinicie la PS5 (nada queda instalado; para limpiar todo, borre la carpeta /data/prefbar)."},
   {"Espere ~2 min depois de ligar o PS5. Não use junto com a tela cheia do navegador: os dois mexem na interface do PS5 (ShellUI). Não testado no PS5 Pro 12.00.",
    "Wait ~2 min after turning the PS5 on. Do not use it together with the browser fullscreen: both change the PS5 interface (ShellUI). Not tested on the PS5 Pro 12.00.",
    "Espere ~2 min después de encender la PS5. No lo use junto con la pantalla completa del navegador: los dos modifican la interfaz de la PS5 (ShellUI). No probado en la PS5 Pro 12.00."},
   4, 0, 1, 1},
};
#define N_ITENS ((int)(sizeof ITENS / sizeof ITENS[0]))

typedef struct {
  char fase[16];        /* "", baixando, conferindo, home, aplicando, reabrindo */
  char erro[300];
  char saida[600];      /* resumo da saida do payload (Result/Notification) */
  time_t ativado_em;
  unsigned long long baixados;
  /* cache do SHA-256 do arquivo guardado (refeito quando tamanho/data mudam) */
  long long cache_tam, cache_mtime;
  int cache_ok;
} estado_t;

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static estado_t g_est[N_ITENS];
static int g_ocupado;

/* ------------------------------------------------------------------ catalogo e pastas */

static const char *sha_item(const item_t *it) {
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_PAYLOAD_SHA")) return getenv("GLR_TESTE_PAYLOAD_SHA");
#endif
  return it->sha256;
}

static unsigned long long tam_item(const item_t *it) {
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_PAYLOAD_TAM")) return strtoull(getenv("GLR_TESTE_PAYLOAD_TAM"), NULL, 10);
#endif
  return it->tamanho;
}

static void url_item(const item_t *it, char *saida, size_t tam) {
#ifndef __PROSPERO__
  const char *base = getenv("GLR_TESTE_PAYLOADS_URL");
  if(base && *base) {
    snprintf(saida, tam, "%s%s", base, it->arquivo);
    return;
  }
#endif
  snprintf(saida, tam, "%s", it->url);
}

static void pasta(char *saida, size_t tam) {
#ifdef __PROSPERO__
  snprintf(saida, tam, "/data/glibren/payloads");
#else
  snprintf(saida, tam, "%s/payloads", g_pasta_dados);   /* PC: dentro da pasta de dados do teste */
#endif
}

/* ext NULL = o .elf; ".ativado" = hora da ultima ativacao */
static void caminho(const item_t *it, const char *ext, char *saida, size_t tam) {
  char p[512];
  pasta(p, sizeof p);
  if(ext) snprintf(saida, tam, "%s/%s%s", p, it->id, ext);
  else snprintf(saida, tam, "%s/%s", p, it->arquivo);
}

static int achar(const char *id) {
  for(int i = 0; i < N_ITENS; i++)
    if(!strcmp(ITENS[i].id, id)) return i;
  return -1;
}

/* "12.00" (vazio = nao sabe) */
static void firmware(char *saida, size_t tam) {
  saida[0] = 0;
#ifdef __PROSPERO__
  uint32_t v = kernel_get_fw_version();
  if(v) snprintf(saida, tam, "%x.%02x", (unsigned)((v >> 24) & 0xff), (unsigned)((v >> 16) & 0xff));
#else
  if(getenv("GLR_TESTE_FW")) snprintf(saida, tam, "%s", getenv("GLR_TESTE_FW"));
#endif
}

/* "4.03 12.02" contem "12.02"? (palavra inteira). 0.9.22: "12.xx" na lista vale para qualquer 12.yy. */
static int palavra(const char *lista, const char *fw) {
  size_t n = strlen(fw);
  for(const char *p = lista; n && (p = strstr(p, fw)); p++)
    if((p == lista || p[-1] == ' ') && (p[n] == 0 || p[n] == ' ')) return 1;
  return 0;
}

static int na_lista(const char *lista, const char *fw) {
  if(palavra(lista, fw)) return 1;
  char familia[16];
  const char *ponto = strchr(fw, '.');
  if(!ponto || ponto - fw > 3) return 0;
  snprintf(familia, sizeof familia, "%.*s.xx", (int)(ponto - fw), fw);
  return palavra(lista, familia);
}

/* Hora em que o PS5 ligou (os patches da interface valem ate reiniciar). 0.9.22: kern.boottime no PS5 (o mesmo do
   "Ligado ha" da Temperatura); reserva: relogio monotonico. */
static time_t ligou_em(void) {
#ifdef __PROSPERO__
  struct timeval boot;
  size_t tam = sizeof boot;
  if(!sysctlbyname("kern.boottime", &boot, &tam, NULL, 0) && boot.tv_sec > 0) return boot.tv_sec;
#endif
  struct timespec ts;
  if(clock_gettime(CLOCK_MONOTONIC, &ts)) return 0;
  return time(NULL) - ts.tv_sec;
}

/* 0.9.22: pid da SceShellUI (a interface do PS5). Os patches vivem na memoria dela: se ela reiniciar (pid novo), o
   patch acabou. 0 = nao sabe. PC: GLR_TESTE_SHELLUI_PID. */
static int pid_shellui(void) {
#ifdef __PROSPERO__
  int mib[3] = {CTL_KERN, KERN_PROC, KERN_PROC_PROC}, pid = 0;
  size_t tam = 0;
  if(sysctl(mib, 3, NULL, &tam, NULL, 0) || !tam) return 0;
  tam += 64 * 1024;
  uint8_t *b = malloc(tam);
  if(!b) return 0;
  if(!sysctl(mib, 3, b, &tam, NULL, 0)) {
    for(uint8_t *q = b; q + sizeof(int) <= b + tam;) {
      struct kinfo_proc *ki = (struct kinfo_proc *)q;
      if(ki->ki_structsize <= 0) break;
      if(!strcmp(ki->ki_comm, "SceShellUI")) {
        pid = ki->ki_pid;
        break;
      }
      q += ki->ki_structsize;
    }
  }
  free(b);
  return pid;
#else
  const char *v = getenv("GLR_TESTE_SHELLUI_PID");
  return v ? atoi(v) : 0;
#endif
}

/* ------------------------------------------------------------------ arquivo guardado */

/* Le o arquivo e confere tamanho e SHA-256. 1 = ok (b recebe o conteudo, se nao for NULL). */
static int arquivo_confere(const item_t *it, buf_t *b) {
  char arq[600], hex[65];
  caminho(it, NULL, arq, sizeof arq);
  int fd = open(arq, O_RDONLY | O_NOFOLLOW);
  if(fd < 0) return 0;
  unsigned long long esperado = tam_item(it), lidos = 0;
  sha256_t s;
  sha256_iniciar(&s);
  char bloco[64 * 1024];
  ssize_t r;
  int ok = 1;
  while(ok && (r = read(fd, bloco, sizeof bloco)) > 0) {
    lidos += (unsigned long long)r;
    if(lidos > esperado) ok = 0;
    else {
      sha256_atualizar(&s, bloco, (size_t)r);
      if(b) buf_add(b, bloco, (size_t)r);
    }
  }
  if(r < 0) ok = 0;
  close(fd);
  uint8_t resumo[32];
  sha256_final(&s, resumo);
  sha256_hex(resumo, hex);
  return ok && lidos == esperado && !strcmp(hex, sha_item(it));
}

/* Pronto (guardado e conferido)? Usa o cache pelo tamanho/data do arquivo. Chamar sem a trava. */
static int pronto(int i) {
  char arq[600];
  struct stat st;
  caminho(&ITENS[i], NULL, arq, sizeof arq);
  if(lstat(arq, &st) || !S_ISREG(st.st_mode)) return 0;
  pthread_mutex_lock(&g_trava);
  int sabe = g_est[i].cache_tam == (long long)st.st_size && g_est[i].cache_mtime == (long long)st.st_mtime, ok = g_est[i].cache_ok;
  pthread_mutex_unlock(&g_trava);
  if(sabe) return ok;
  ok = arquivo_confere(&ITENS[i], NULL);
  pthread_mutex_lock(&g_trava);
  g_est[i].cache_tam = (long long)st.st_size;
  g_est[i].cache_mtime = (long long)st.st_mtime;
  g_est[i].cache_ok = ok;
  pthread_mutex_unlock(&g_trava);
  return ok;
}

/* ------------------------------------------------------------------ estado */

static void fase(int i, const char *f) {
  pthread_mutex_lock(&g_trava);
  snprintf(g_est[i].fase, sizeof g_est[i].fase, "%s", f);
  pthread_mutex_unlock(&g_trava);
}

static void falhou(int i, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
static void falhou(int i, const char *fmt, ...) {
  char msg[300];
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(msg, sizeof msg, fmt, ap);
  va_end(ap);
  pthread_mutex_lock(&g_trava);
  snprintf(g_est[i].erro, sizeof g_est[i].erro, "%s", msg);
  g_est[i].fase[0] = 0;
  pthread_mutex_unlock(&g_trava);
  diario("payloads: %s: erro: %s", ITENS[i].id, msg);
}

/* Hora da ativacao nesta sessao do PS5, ou 0. O arquivo .ativado guarda "hora pid_da_ShellUI" (0.9.22; antes so a
   hora; o arquivo vale mais que a memoria: e o que sobra depois de reabrir o glibren). Ativado antes de o PS5 ligar,
   ou com outra ShellUI (ela reiniciou), ja foi desfeito. */
static time_t ativado_em(int i) {
  char arq[600];
  long long v = 0;
  int pid = 0;
  pthread_mutex_lock(&g_trava);
  time_t mem = g_est[i].ativado_em;
  pthread_mutex_unlock(&g_trava);
  caminho(&ITENS[i], ".ativado", arq, sizeof arq);
  FILE *f = fopen(arq, "r");
  if(f) {
    int n = fscanf(f, "%lld %d", &v, &pid);
    if(n < 1) v = 0;
    if(n < 2) pid = 0;
    fclose(f);
  } else v = (long long)mem;   /* arquivo nao gravou: vale o da memoria */
  time_t t = (time_t)v;
  if(t <= ligou_em() + 5) return 0;   /* antes de o PS5 ligar: ja foi desfeito */
  int agora = pid ? pid_shellui() : 0;
  if(pid && agora && agora != pid) return 0;   /* a interface do PS5 reiniciou: o patch foi junto */
  return t;
}

/* 0.9.22: o item esta valendo nesta sessao (ativado pelo glibren ou, no PrefBar, rodando por outro caminho: os
   arquivos de estado dele mudaram depois que o PS5 ligou). */
static int ativo_na_sessao(int i) {
  if(ativado_em(i)) return 1;
  return !strcmp(ITENS[i].id, "prefbar") && prefbar_rodou_desde((long long)ligou_em());
}

/* Outro item que mexe na ShellUI e esta ativo nesta sessao (indice) ou -1. */
static int conflito_com(int i) {
  if(!ITENS[i].shellui) return -1;
  for(int j = 0; j < N_ITENS; j++)
    if(j != i && ITENS[j].shellui && ativo_na_sessao(j)) return j;
  return -1;
}

void payloads_firmware(char *saida, size_t tam) {
  firmware(saida, tam);
}

void payloads_rota_estado(pedido_t *p) {
  buf_t b = {0};
  payloads_json(&b);
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* 0.9.21: o mesmo JSON do GET /api/payloads, tambem para o diagnostico */
void payloads_json(buf_t *saida) {
  static const char *const LING[] = {"pt-BR", "en", "es"};
  static const char *const CAMPOS[] = {"descricao", "desfazer", "aviso"};
  char fw[16], arq[600];
  firmware(fw, sizeof fw);
  buf_t b = {0};
  buf_str(&b, "{\"ok\":true,\"firmware\":");
  buf_json(&b, fw);
  pthread_mutex_lock(&g_trava);
  buf_fmt(&b, ",\"ocupado\":%s,\"agora\":%lld,\"itens\":[", g_ocupado ? "true" : "false", (long long)time(NULL));
  pthread_mutex_unlock(&g_trava);
  for(int i = 0; i < N_ITENS; i++) {
    const item_t *it = &ITENS[i];
    int ok = pronto(i);
    time_t ativ = ativado_em(i);
    struct stat st;
    caminho(it, NULL, arq, sizeof arq);
    int existe = !lstat(arq, &st);
    pthread_mutex_lock(&g_trava);
    estado_t e = g_est[i];
    pthread_mutex_unlock(&g_trava);
    /* 0.9.22: exclusao mutua dos que mexem na ShellUI (quem esta ativo nesta sessao do PS5 bloqueia os outros);
       "rodando" = PrefBar rodando nesta sessao sem ter sido ativado pelo glibren */
    int outro = conflito_com(i), ativo = ativo_na_sessao(i);
    const char *estado = e.fase[0] ? e.fase : e.erro[0] ? "erro" : ativ ? "ativado" : ativo ? "rodando" : ok ? "pronto" : "nao_baixado";
    buf_str(&b, i ? ",{" : "{");
    buf_str(&b, "\"id\":"); buf_json(&b, it->id);
    buf_str(&b, ",\"nome\":"); buf_json(&b, it->nome);
    buf_str(&b, ",\"autor\":"); buf_json(&b, it->autor);
    buf_str(&b, ",\"licenca\":"); buf_json(&b, it->licenca);
    buf_str(&b, ",\"repo\":"); buf_json(&b, it->repo);
    buf_str(&b, ",\"tag\":"); buf_json(&b, it->tag);
    buf_str(&b, ",\"url\":"); buf_json(&b, it->url);
    buf_str(&b, ",\"sha256\":"); buf_json(&b, it->sha256);
    buf_fmt(&b, ",\"tamanho\":%llu", it->tamanho);
    buf_str(&b, ",\"firmwares\":"); buf_json(&b, it->firmwares);
    /* 0.9.22: "12.xx" na lista do autor = so a faixa que ele diz suportar (nao um teste no 12.00): "faixa_do_autor" */
    int exato = fw[0] && palavra(it->firmwares, fw), faixa = fw[0] && !exato && na_lista(it->firmwares, fw);
    buf_fmt(&b, ",\"testado_no_seu\":%s,\"faixa_do_autor\":%s", !fw[0] ? "null" : exato ? "true" : "false", faixa ? "true" : "false");
    const char *const *textos[] = {it->descricao, it->desfazer, it->aviso};
    for(int c = 0; c < 3; c++) {
      buf_fmt(&b, ",\"%s\":{", CAMPOS[c]);
      for(int l = 0; l < 3; l++) {
        buf_str(&b, l ? "," : "");
        buf_json(&b, LING[l]);
        buf_str(&b, ":");
        buf_json(&b, textos[c][l]);
      }
      buf_str(&b, "}");
    }
    buf_fmt(&b, ",\"shellui\":%s,\"uma_vez\":%s,\"ativo_sessao\":%s,\"rodando_fora\":%s,\"bloqueado_por\":", it->shellui ? "true" : "false",
            it->uma_vez ? "true" : "false", ativo ? "true" : "false", ativo && !ativ ? "true" : "false");
    buf_json(&b, outro >= 0 ? ITENS[outro].nome : "");
    buf_fmt(&b, ",\"navegador\":%s,\"estado\":", it->navegador ? "true" : "false");
    buf_json(&b, estado);
    buf_fmt(&b, ",\"guardado\":%s,\"conferido\":%s,\"ativado_em\":%lld,\"baixados\":%llu,\"erro\":", existe ? "true" : "false",
            ok ? "true" : "false", (long long)ativ, e.baixados);
    buf_json(&b, e.erro);
    buf_str(&b, ",\"saida\":");
    buf_json(&b, e.saida);
    buf_str(&b, "}");
  }
  buf_str(&b, "]}");
  buf_add(saida, b.d, b.n);
  buf_free(&b);
}

int payloads_ocupado(void) {
  pthread_mutex_lock(&g_trava);
  int o = g_ocupado;
  pthread_mutex_unlock(&g_trava);
  return o;
}

/* ------------------------------------------------------------------ baixar */

typedef struct {
  int fd, excedeu, erro_gravar, i;
  unsigned long long n, limite;
  sha256_t sha;
} download_t;

static int recebeu(const void *dados, size_t n, void *ctx) {
  download_t *d = ctx;
  if(!dados) return 0;
  if(d->n + n > d->limite) {
    d->excedeu = 1;
    return 1;
  }
  for(size_t feitos = 0; feitos < n;) {
    ssize_t r = write(d->fd, (const char *)dados + feitos, n - feitos);
    if(r <= 0) {
      d->erro_gravar = 1;
      return 1;
    }
    feitos += (size_t)r;
  }
  sha256_atualizar(&d->sha, dados, n);
  d->n += n;
  pthread_mutex_lock(&g_trava);
  g_est[d->i].baixados = d->n;
  pthread_mutex_unlock(&g_trava);
  return 0;
}

/* Baixa, confere o SHA-256 e guarda. 0 = ok. */
static int baixar(int i) {
  const item_t *it = &ITENS[i];
  char p[512], arq[600], parcial[620], url[700], hex[65];
  pasta(p, sizeof p);
  caminho(it, NULL, arq, sizeof arq);
  snprintf(parcial, sizeof parcial, "%s.part", arq);
  url_item(it, url, sizeof url);
  fase(i, "baixando");
  if(mkdir_p(p)) {
    falhou(i, "nao criou a pasta %s (%s)", p, strerror(errno));
    return -1;
  }
  download_t d;
  memset(&d, 0, sizeof d);
  d.i = i;
  d.limite = tam_item(it);
  sha256_iniciar(&d.sha);
  unlink(parcial);
  if((d.fd = open(parcial, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644)) < 0) {
    falhou(i, "nao criou %s (%s)", parcial, strerror(errno));
    return -1;
  }
  int status = https_baixar(url, recebeu, &d);
  int erro_fechar = fsync(d.fd);
  erro_fechar |= close(d.fd);
  diario("payloads: %s: download %s status %d, %llu bytes", it->id, url, status, d.n);
  if(status != 200 || d.excedeu || d.erro_gravar || erro_fechar || d.n != d.limite) {
    unlink(parcial);
    if(status != 200) falhou(i, "nao foi possivel baixar (HTTP %d)", status);
    else if(d.excedeu || d.n != d.limite) falhou(i, "tamanho diferente do fixado (%llu de %llu bytes): recusado", d.n, d.limite);
    else falhou(i, "erro ao gravar no PS5");
    return -1;
  }
  fase(i, "conferindo");
  uint8_t resumo[32];
  sha256_final(&d.sha, resumo);
  sha256_hex(resumo, hex);
  if(strcmp(hex, sha_item(it))) {
    unlink(parcial);
    falhou(i, "SHA-256 nao confere: arquivo recusado (veio %.16s..., esperado %.16s...)", hex, sha_item(it));
    return -1;
  }
  if(rename(parcial, arq)) {
    unlink(parcial);
    falhou(i, "nao guardou o arquivo (%s)", strerror(errno));
    return -1;
  }
  diario("payloads: %s: baixado e conferido (sha256 %.16s...) em %s", it->id, hex, arq);
  return 0;
}

/* ------------------------------------------------------------------ PS5: tela inicial e navegador */

static int ir_para_home(void) {
#ifdef __PROSPERO__
  if(!sceKernelLoadStartModule || !sceUserServiceGetForegroundUser) return -1;
  int modulo = sceKernelLoadStartModule("/system_ex/common_ex/lib/libSceShellUIUtil.sprx", 0, NULL, 0, NULL, NULL);
  if(modulo < 0) {
    diario("payloads: libSceShellUIUtil nao carregou (0x%08x)", (unsigned)modulo);
    return modulo;
  }
  int (*iniciar)(void) = (void *)kernel_dynlib_dlsym(-1, (uint32_t)modulo, "sceShellUIUtilInitialize");
  int (*por_uri)(const char *, void *) = (void *)kernel_dynlib_dlsym(-1, (uint32_t)modulo, "sceShellUIUtilLaunchByUri");
  if(!iniciar || !por_uri) {
    diario("payloads: libSceShellUIUtil sem as funcoes esperadas");
    return -1;
  }
  int r = iniciar();
  if(r < 0) diario("payloads: sceShellUIUtilInitialize 0x%08x", (unsigned)r);
  struct {
    uint32_t tamanho, usuario;
  } par = {8, 0};
  sceUserServiceGetForegroundUser(&par.usuario);
  r = por_uri("pshomeui:navigateToHome?bootCondition=psButton", &par);
  diario("payloads: tela inicial 0x%08x", (unsigned)r);
  return r;
#else
  diario("payloads (PC): voltaria para a tela inicial");
  return 0;
#endif
}

static int abrir_navegador(const char *url) {
#ifdef __PROSPERO__
  if(!sceSystemServiceLaunchWebBrowser) return -1;
  int r = sceSystemServiceLaunchWebBrowser(url, NULL);
  diario("payloads: navegador reaberto em %s (0x%08x)", url, (unsigned)r);
  return r;
#else
  diario("payloads (PC): abriria o navegador em %s", url);
  return 0;
#endif
}

/* ------------------------------------------------------------------ elfldr */

/* Envia ao elfldr e le a saida do payload ate ele terminar (ou espera_s). 0 = enviado. */
static int enviar_elfldr(const void *dados, size_t n, int espera_s, buf_t *saida) {
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if(fd < 0) return -1;
  int porta = PORTA_ELFLDR;
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_ELFLDR")) porta = atoi(getenv("GLR_TESTE_ELFLDR"));
#endif
  struct timeval um = {.tv_sec = 1};
  setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &um, sizeof um);
  struct timeval dez = {.tv_sec = 10};
  setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &dez, sizeof dez);
#ifdef SO_NOSIGPIPE
  int sim = 1;
  setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &sim, sizeof sim);
#endif
  struct sockaddr_in end = {.sin_family = AF_INET, .sin_port = htons(porta)};
  end.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  int ok = !connect(fd, (struct sockaddr *)&end, sizeof end);
  for(size_t enviados = 0; ok && enviados < n;) {
    ssize_t r = send(fd, (const char *)dados + enviados, n - enviados, SEM_SINAL);
    if(r <= 0) ok = 0;
    else enviados += (size_t)r;
  }
  if(ok) {
    shutdown(fd, SHUT_WR);   /* fim do .elf; a leitura continua: a saida do payload chega por aqui */
    time_t limite = time(NULL) + espera_s;
    char bloco[2048];
    while(time(NULL) < limite) {
      ssize_t r = recv(fd, bloco, sizeof bloco, 0);
      if(r == 0) break;   /* o payload terminou */
      if(r < 0) {
        if(errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) continue;
        break;
      }
      if(saida->n + (size_t)r <= MAX_SAIDA) buf_add(saida, bloco, (size_t)r);
    }
  }
  close(fd);
  buf_add(saida, "", 1);
  return ok ? 0 : -1;
}

/* Linha que comeca com "prefixo" (sem o prefixo e o fim de linha; so ASCII visivel). 1 = achou. */
static int linha(const char *texto, const char *prefixo, char *saida, size_t tam) {
  saida[0] = 0;
  size_t np = strlen(prefixo);
  for(const char *p = texto; p && *p;) {
    if(!strncmp(p, prefixo, np)) {
      size_t k = 0;
      for(const char *c = p + np; *c && *c != '\n' && *c != '\r' && k + 1 < tam; c++) saida[k++] = (*c >= ' ' && *c <= '~') ? *c : '?';
      saida[k] = 0;
      return 1;
    }
    p = strchr(p, '\n');
    if(p) p++;
  }
  return 0;
}

/* ------------------------------------------------------------------ trabalho */

typedef struct {
  int i, ativar;
  char reabrir[300];   /* URL completa para reabrir o navegador ("" = nao reabre) */
} trabalho_t;

static void gravar_ativado(const item_t *it, time_t quando) {
  char arq[600], tmp[620];
  caminho(it, ".ativado", arq, sizeof arq);
  snprintf(tmp, sizeof tmp, "%s.tmp", arq);
  FILE *f = fopen(tmp, "w");
  if(!f) return;
  int pid = pid_shellui();
  fprintf(f, "%lld %d\n", (long long)quando, pid);   /* quem foi ativado (o arquivo) e quando, nesta ShellUI */
  int ok = !fflush(f) && !fsync(fileno(f));
  if(fclose(f) || !ok || rename(tmp, arq)) unlink(tmp);
  else diario("payloads: %s: ativacao gravada (hora %lld, ShellUI pid %d, PS5 ligado desde %lld)", it->id, (long long)quando, pid,
              (long long)ligou_em());
}

/* Envia ao elfldr e interpreta a saida. 0 = ativado. */
static int aplicar(int i, const buf_t *elf) {
  const item_t *it = &ITENS[i];
  buf_t saida = {0};
  int r = -1;
  char res[200] = "", aviso[400] = "", resumo[600] = "";
  fase(i, "aplicando");
  diario("payloads: %s: enviando ao elfldr (%zu bytes)", it->id, elf->n);
  if(enviar_elfldr(elf->d, elf->n, it->espera_s, &saida)) {
    falhou(i, "o elfldr (porta 9021) nao respondeu");
    goto fim;
  }
  int tem_res = linha(saida.d, "Result=", res, sizeof res);
  if(!linha(saida.d, "Notification: ", aviso, sizeof aviso)) linha(saida.d, "[elfldr.elf] ", aviso, sizeof aviso);
  snprintf(resumo, sizeof resumo, "%s%s%s%s", tem_res ? "Result=" : "", res, tem_res && aviso[0] ? " | " : "", aviso);
  diario("payloads: %s: saida do payload: %s", it->id, resumo[0] ? resumo : "(nada)");
  pthread_mutex_lock(&g_trava);
  snprintf(g_est[i].saida, sizeof g_est[i].saida, "%s", resumo);
  pthread_mutex_unlock(&g_trava);
  int codigo = tem_res ? atoi(res) : -1;
  if(tem_res && codigo != 0 && codigo != 2) {
    falhou(i, "o payload informou falha: %s", aviso[0] ? aviso : res);
    goto fim;
  }
  if(!tem_res && strstr(saida.d, "[elfldr.elf]")) {
    falhou(i, "o elfldr recusou: %s", aviso);
    goto fim;
  }
  time_t agora = time(NULL);
  gravar_ativado(it, agora);
  pthread_mutex_lock(&g_trava);
  g_est[i].ativado_em = agora;
  g_est[i].erro[0] = 0;
  pthread_mutex_unlock(&g_trava);
  diario("payloads: %s: ativado%s", it->id, tem_res ? "" : " (o payload nao confirmou; veja a notificacao do PS5)");
  r = 0;
fim:
  buf_free(&saida);
  return r;
}

static void *trabalhar(void *arg) {
  trabalho_t t = *(trabalho_t *)arg;
  free(arg);
  const item_t *it = &ITENS[t.i];
  buf_t elf = {0};
  int home = 0;
  if(!pronto(t.i) && baixar(t.i)) goto fim;
  if(!t.ativar) goto fim;
  /* confere de novo o arquivo guardado (pode ter sido trocado no disco depois do download) */
  fase(t.i, "conferindo");
  if(!arquivo_confere(it, &elf)) {
    char arq[600];
    caminho(it, NULL, arq, sizeof arq);
    unlink(arq);
    falhou(t.i, "o arquivo guardado nao confere com o SHA-256 fixado: apagado (baixe de novo)");
    goto fim;
  }
  if(it->navegador) {
    fase(t.i, "home");
    usleep(250000);   /* a resposta chega ao navegador antes de sair dele */
    home = !ir_para_home();
    if(home) usleep(1000000);
  }
  aplicar(t.i, &elf);
  if(it->navegador && t.reabrir[0]) {
    fase(t.i, "reabrindo");
    if(!home) usleep(250000);
    abrir_navegador(t.reabrir);   /* mesmo se falhou: ninguem fica perdido na tela inicial */
  }
fim:
  buf_free(&elf);
  pthread_mutex_lock(&g_trava);
  g_est[t.i].fase[0] = 0;
  g_ocupado = 0;
  pthread_mutex_unlock(&g_trava);
  return NULL;
}

/* Pagina para reabrir: "/" + letras, numeros e - _ . / ? = & (sem "//" nem ".."). */
static int caminho_reabrir_ok(const char *c) {
  if(c[0] != '/' || c[1] == '/' || strstr(c, "..") || strlen(c) > 200) return 0;
  for(const char *p = c; *p; p++)
    if(!((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') || (*p >= '0' && *p <= '9') || strchr("-_./?=&", *p))) return 0;
  return 1;
}

void payloads_rota_acao(pedido_t *p, int ativar) {
  char id[64] = "", reabrir[256] = "", tid[16] = "";
  param(p->corpo, "id", 0, id, sizeof id);
  param(p->corpo, "reabrir", 0, reabrir, sizeof reabrir);
  int i = achar(id);
  if(i < 0) {
    for(char *c = id; *c; c++) if(*c < ' ' || *c > '~') *c = '?';
    diario("payloads: pedido recusado: \"%.60s\" nao esta na lista", id);
    responder_erro(p, 404, "payload_fora_da_lista", "este payload nao esta na lista do glibren", NULL);
    return;
  }
  const item_t *it = &ITENS[i];
  int ps5 = fps_agente_ps5(p->agente);
  if((ps5 || p->local) && !(it->navegador && ps5)) {
    responder_erro(p, 403, "payload_so_celular", "payloads de teste so pelo celular ou PC pareado", NULL);
    return;
  }
  if(reabrir[0] && !caminho_reabrir_ok(reabrir)) {
    responder_erro(p, 400, "payload_reabrir", "pagina para reabrir invalida", NULL);
    return;
  }
  if(ativar) {
    int r = app_de_jogo_aberto(tid, sizeof tid);
    if(r == 1) {
      responder_erro(p, 409, "payload_jogo_aberto", "feche o jogo ou app antes: se a interface do PS5 reiniciar, ele fecha sem salvar", tid);
      return;
    }
    if(r < 0) diario("payloads: nao deu para saber se ha jogo aberto; seguindo");
    /* 0.9.22: so um patch da ShellUI por sessao do PS5 (o PrefBar e a tela cheia mexem na mesma interface) */
    int outro = conflito_com(i);
    if(outro >= 0) {
      diario("payloads: %s recusado: %s ja esta ativo nesta sessao do PS5 (os dois mexem na ShellUI)", it->id, ITENS[outro].id);
      responder_erro(p, 409, "payload_conflito", "outro payload que mexe na interface do PS5 ja esta ativo: reinicie o PS5 antes", ITENS[outro].nome);
      return;
    }
    if(it->uma_vez && ativo_na_sessao(i)) {
      diario("payloads: %s recusado: ja esta rodando nesta sessao do PS5", it->id);
      responder_erro(p, 409, "payload_ja_ativo", "ja esta ativo nesta sessao do PS5 (ativar de novo criaria uma segunda copia)", it->nome);
      return;
    }
  }
  trabalho_t *t = calloc(1, sizeof *t);
  if(!t) {
    responder_erro(p, 500, "payload_erro", "sem memoria", NULL);
    return;
  }
  t->i = i;
  t->ativar = ativar;
  if(reabrir[0]) snprintf(t->reabrir, sizeof t->reabrir, "http://127.0.0.1:%d%s", g_porta, reabrir);
  pthread_mutex_lock(&g_trava);
  if(g_ocupado) {
    pthread_mutex_unlock(&g_trava);
    free(t);
    responder_erro(p, 409, "payload_ocupado", "outro payload esta sendo baixado ou ativado: espere", NULL);
    return;
  }
  g_ocupado = 1;
  g_est[i].erro[0] = 0;
  g_est[i].saida[0] = 0;
  g_est[i].baixados = 0;
  snprintf(g_est[i].fase, sizeof g_est[i].fase, "%s", "conferindo");
  pthread_mutex_unlock(&g_trava);
  diario("payloads: %s: %s pedido pelo %s%s", it->id, ativar ? "ativar" : "baixar", ps5 ? "navegador do PS5" : "aparelho pareado",
         t->reabrir[0] ? " (reabre o navegador depois)" : "");
  if(criar_thread(trabalhar, t, NULL)) {
    free(t);
    pthread_mutex_lock(&g_trava);
    g_ocupado = 0;
    g_est[i].fase[0] = 0;
    pthread_mutex_unlock(&g_trava);
    responder_erro(p, 500, "payload_erro", "nao iniciou", NULL);
    return;
  }
  responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
}
