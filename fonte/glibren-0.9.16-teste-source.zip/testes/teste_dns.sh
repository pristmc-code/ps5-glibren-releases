#!/bin/bash
# Testa o DNS robusto (0.9.16, dns_resolver.c) na versao de PC com servidores de mentira (testes/dns_falso.py) em
# 127.0.0.1: UDP, TCP e DoH (HTTPS com um certificado feito aqui, passado em GLR_TESTE_DOH_CA).
# Confere: UDP; cache (sem perguntar de novo); arquivo dns_cache.txt e leitura dele ao reiniciar; UDP truncado -> TCP;
# UDP e TCP mortos -> DoH; resposta "sinkhole" ignorada; tudo morto -> falhou e cache negativo; DoH com outra CA
# recusado; hosts fora da lista e da Sony recusados; o curl recebe --resolve (equivalente ao CURLOPT_RESOLVE).
# No fim, se houver internet: DoH de verdade (cloudflare-dns.com / dns.google) com as raizes embutidas.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_dns.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8875
U="http://127.0.0.1:$PORTA"
T=/root/glr-dns; DADOS=$T/dados; LOG=$T/perguntas.log
PU=8851; PT=8852; PD=8853; MORTA=8859
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
rm -rf "$T"; mkdir -p "$DADOS"
printf 'language = pt-BR\n' > "$DADOS/config.ini"
openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:P-256 -nodes -days 2 -subj /CN=127.0.0.1 \
  -addext subjectAltName=IP:127.0.0.1 -keyout "$T/key.pem" -out "$T/cert.pem" 2>/dev/null
openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:P-256 -nodes -days 2 -subj /CN=outra -keyout "$T/k2.pem" -out "$T/outra.pem" 2>/dev/null
FPID=; PID=
mata() { for x in "$@"; do [ -n "$x" ] && kill "$x" 2>/dev/null && wait "$x" 2>/dev/null; done; return 0; }
trap 'mata $FPID $PID' EXIT
falso() { mata $FPID; python3 "$ORIGEM/testes/dns_falso.py" --log "$LOG" --cert "$T/cert.pem" --key "$T/key.pem" "$@" & FPID=$!; sleep 0.7; }
inicia() { mata $PID
  env GLR_TESTE_DNS_UDP=127.0.0.1:${UDPP:-$PU} GLR_TESTE_DNS_TCP=127.0.0.1:${TCPP:-$PT} GLR_TESTE_DOH_URL=https://127.0.0.1:${DOHP:-$PD}/dns-query \
    GLR_TESTE_DOH_CA="${CA:-$T/cert.pem}" "$@" "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1; }
dns() { curl -s "$U/api/dns?host=$1"; }

echo "--- UDP e cache"
falso --udp $PU --tcp $PT --doh $PD
inicia
confere "UDP"                         "$(dns raw.githubusercontent.com)" '"ok":true,"host":"raw.githubusercontent.com","ip":"140.82.112.3","fonte":"udp"'
confere "cache"                       "$(dns raw.githubusercontent.com)" '"fonte":"cache"'
confere "perguntou 1 vez so"          "$(grep -c 'raw.githubusercontent.com' $LOG)" "^1$"
confere "arquivo dns_cache.txt"       "$(cat $DADOS/dns_cache.txt)" "raw.githubusercontent.com 140.82.112.3 [0-9]*"
confere "diario"                      "$(cat $DADOS/glibren.log)" "dns: raw.githubusercontent.com -> 140.82.112.3 (udp)"
confere "Sony recusado"               "$(dns store.playstation.com)" '"fonte":"fora_da_lista"'
confere "Sony (outro) recusado"       "$(dns gs2.ww.prod.dl.playstation.net)" '"fonte":"fora_da_lista"'
confere "fora da lista"               "$(dns example.com)" '"ok":false,"host":"example.com","ip":"","fonte":"fora_da_lista"'
confere "parecido recusado"           "$(dns github.com.example.com)" '"fonte":"fora_da_lista"'
confere "nada perguntado por eles"    "$(grep -c 'example\|playstation' $LOG)" "^0$"

echo "--- UDP truncado -> TCP"
falso --udp $PU --udp-modo tc --tcp $PT --doh $PD
confere "TCP"                         "$(dns github.com)" '"ip":"140.82.112.3","fonte":"tcp"'
confere "tentou UDP antes"            "$(grep 'github.com$' $LOG | tr '\n' ' ')" "udp github.com tcp github.com"

echo "--- sinkhole ignorado"
falso --udp $PU --udp-modo sink --tcp $PT --doh $PD
confere "sinkhole -> TCP"             "$(dns orbispatches.com)" '"ip":"140.82.112.3","fonte":"tcp"'
confere "diario: bloqueados"          "$(cat $DADOS/glibren.log)" "resposta so com enderecos bloqueados"

echo "--- UDP e TCP mortos -> DoH"
UDPP=$MORTA TCPP=$MORTA inicia
falso --doh $PD
confere "DoH"                         "$(dns prosperopatches.com)" '"ip":"140.82.112.3","fonte":"doh"'
confere "DoH perguntado"              "$(grep -c 'doh prosperopatches.com' $LOG)" "^1$"

echo "--- tudo morto: falhou e cache negativo; reinicio usa o arquivo"
UDPP=$MORTA TCPP=$MORTA DOHP=$MORTA inicia
mata $FPID; FPID=
confere "falhou"                      "$(dns cdn.prosperopatches.com)" '"ok":false,"host":"cdn.prosperopatches.com","ip":"","fonte":"falhou"'
confere "negativo (20 s)"             "$(dns cdn.prosperopatches.com)" '"fonte":"negativo"'
confere "diario: nao resolveu"        "$(cat $DADOS/glibren.log)" "dns: cdn.prosperopatches.com nao resolveu (udp, tcp e doh)"
confere "do arquivo depois de reiniciar" "$(dns raw.githubusercontent.com)" '"ip":"140.82.112.3","fonte":"cache"'

echo "--- DoH com outra CA: recusado"
UDPP=$MORTA TCPP=$MORTA CA=$T/outra.pem inicia
falso --doh $PD
confere "certificado nao confere"     "$(dns cdn.orbispatches.com)" '"fonte":"falhou"'
confere "nem chegou a perguntar"      "$(grep -c 'doh cdn.orbispatches.com' $LOG)" "^0$"

echo "--- curl recebe --resolve (PC)"
falso --udp $PU --tcp $PT --doh $PD
inicia GLR_TESTE_DNS_FORCAR=1
curl -s -o /dev/null --max-time 15 "$U/icone/PPSA01234?url=https%3A%2F%2Fcdn.prosperopatches.com%2Fx.png"
confere "diario: --resolve"           "$(cat $DADOS/glibren.log)" "https (PC): cdn.prosperopatches.com pelo dns_resolver (140.82.112.3)"

echo "--- DoH de verdade com as raizes embutidas (precisa de internet)"
if curl -s -o /dev/null --max-time 5 https://1.1.1.1/; then
  mata $PID; rm -f "$DADOS/dns_cache.txt"
  env GLR_TESTE_DNS_UDP=127.0.0.1:$MORTA GLR_TESTE_DNS_TCP=127.0.0.1:$MORTA "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1
  R=$(dns raw.githubusercontent.com)
  confere "DoH real (cloudflare/google)" "$R" '"ok":true,"host":"raw.githubusercontent.com","ip":"[0-9.]*","fonte":"doh"'
else
  echo "PULADO DoH de verdade: sem internet"
fi

mata $PID $FPID
rm -rf "$T"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
