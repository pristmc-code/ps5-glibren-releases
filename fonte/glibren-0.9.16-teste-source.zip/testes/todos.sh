#!/bin/bash
# Roda todos os testes do PC, um depois do outro, e devolve erro se algum falhar (para o publicar_versao.py e para
# conferir antes de publicar). Os testes usam portas e pastas proprias; rodar so um de cada vez (a demo em 8765 pode
# estar ligada: nenhum teste daqui usa essa porta).
#   wsl -d Ubuntu-24.04 -u root -- bash testes/todos.sh
# O teste_jogo_local.sh fica de fora: precisa da demo rodando e de montar imagens (rodar a mao).
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LOGS=$(mktemp -d /tmp/glr-todos.XXXXXX)
falhos=()
for t in apps/teste_unidade.sh teste_smp_config.sh teste_api.sh teste_tarefas.sh teste_apps.sh teste_relogio.sh teste_ativar.sh teste_seguranca.sh teste_atualizacao.sh teste_fps.sh teste_pareamento.sh teste_watchdog.sh teste_primeiro_plano.sh teste_ejetar.sh teste_dns.sh; do
  nome=$(basename "$t" .sh)
  if bash "$ORIGEM/testes/$t" > "$LOGS/$nome.log" 2>&1; then
    echo "OK     $nome ($(grep -E '^=== ' "$LOGS/$nome.log" | tail -1))"
    grep -E '^PULADO' "$LOGS/$nome.log" | sed 's/^/       /' || true
  else
    echo "FALHOU $nome ($(grep -E '^=== ' "$LOGS/$nome.log" | tail -1)); log: $LOGS/$nome.log"
    grep -E '^(FALHOU|FALHA)' "$LOGS/$nome.log" | head -5 | sed 's/^/       /'
    falhos+=("$nome")
  fi
done
if [ ${#falhos[@]} -eq 0 ]; then
  echo "=== todos os testes passaram"
  rm -rf "$LOGS"
  exit 0
fi
echo "=== ${#falhos[@]} teste(s) falharam: ${falhos[*]}"
exit 1
