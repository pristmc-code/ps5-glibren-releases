#!/bin/bash
# Testa o pareamento por codigo mostrado na TV (0.9.16) na versao de PC. Os pedidos "da rede" vao pelo IP do WSL
# (nao 127.0.0.1); o codigo "mostrado na TV" e lido da saida do programa (no PC a notificacao vai para a tela).
# Confere: leitura livre; acoes protegidas recusadas (401) sem token e nada apagado; 127.0.0.1 isento; codigo errado,
# certo, reusado; token valido/errado; so o SHA-256 no config.ini; o codigo nunca no diario; bloqueio depois de 5
# erros; pairing = off; esquecer.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_pareamento.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8871
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R="http://$IP:$PORTA"
T=/root/glr-par; DADOS=$T/dados; A=$T/lista
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
codigo() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
rm -rf "$T"; mkdir -p "$DADOS" "$A"
printf 'language = pt-BR\nfolder = %s/\n' "$A" > "$DADOS/config.ini"
for i in 1 2 3; do head -c 100 /dev/urandom > "$A/jogo$i.pkg"; done
inicia() { "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
ultimo_codigo() { grep -o 'pareamento [0-9]\{6\}' "$T/glr.log" | tail -1 | awk '{print $2}'; }
inicia
echo "IP da rede: $IP"

echo "--- leitura livre, acoes protegidas"
confere "rede: /api/estado livre"        "$(codigo $R/api/estado)" "200"
confere "rede: /api/tarefas GET livre"   "$(codigo $R/api/tarefas)" "200"
confere "rede: estado do pareamento"     "$(curl -s $R/api/pareamento)" '"ligado":true,"local":false,"pareado":false'
confere "rede: excluir sem token = 401"  "$(codigo -H 'X-GLR: 1' -d tipo=excluir -d "pasta=$A" -d de=jogo1.pkg $R/api/tarefas)" "401"
confere "rede: resposta pede pareamento" "$(post -d tipo=excluir -d "pasta=$A" -d de=jogo1.pkg $R/api/tarefas)" "parear_necessario"
confere "rede: renomear sem token"       "$(codigo -H 'X-GLR: 1' -d "pasta=$A" -d de=jogo1.pkg -d para=x.pkg $R/api/renomear)" "401"
confere "rede: ativar sem token"         "$(codigo -H 'X-GLR: 1' -d "pasta=$A" -d nome=jogo1.pkg $R/api/ativar)" "401"
confere "rede: atualizar sem token"      "$(codigo -H 'X-GLR: 1' -X POST $R/api/atualizar)" "401"
confere "rede: ejetar sem token"         "$(codigo -H 'X-GLR: 1' -d caminho=/mnt/usb0 $R/api/discos/ejetar)" "401"
confere "rede: youtube sem token"        "$(codigo -H 'X-GLR: 1' -d busca=x $R/api/youtube)" "401"
confere "rede: energia sem token"        "$(codigo -H 'X-GLR: 1' -d acao=repouso $R/api/energia)" "401"
confere "rede: sair sem token"           "$(codigo -H 'X-GLR: 1' -X POST $R/api/sair)" "401"
confere "rede: apps/instalar sem token"  "$(codigo -H 'X-GLR: 1' -d id=x $R/api/apps/instalar)" "401"
confere "rede: idioma (nao protegido)"   "$(post -d idioma=en $R/api/idioma)" '"ok":true'
sleep 0.3
confere "nada apagado nem renomeado"     "$(ls $A | tr '\n' ' ')" "jogo1.pkg jogo2.pkg jogo3.pkg"
confere "local: estado"                  "$(curl -s $L/api/pareamento)" '"local":true'
confere "local: excluir isento"          "$(post -d tipo=excluir -d "pasta=$A" -d de=jogo3.pkg $L/api/tarefas)" '"criadas":1'
confere "sem X-GLR continua 403"         "$(codigo -d tipo=excluir -d "pasta=$A" -d de=jogo1.pkg $R/api/tarefas)" "403"

echo "--- codigo"
confere "conferir sem codigo ativo"      "$(post -d codigo=123456 $R/api/parear)" "parear_sem_codigo"
confere "pedir codigo"                   "$(post -X POST $R/api/parear/pedir)" '"ok":true,"validade":120'
C=$(ultimo_codigo)
confere "codigo mostrado (notificacao)"  "$C" "^[0-9]\{6\}$"
nao_tem "codigo nao vai para o diario"   "$(cat $DADOS/glibren.log)" "$C"
nao_tem "codigo nao vai na resposta"     "$(post -X POST $R/api/parear/pedir)" "$C"
confere "pedir de novo logo: espere"     "$(post -X POST $R/api/parear/pedir)" "parear_espere"
ERRADO=$(printf '%06d' $(( (10#$C + 1) % 1000000 )))
confere "codigo errado"                  "$(post -d codigo=$ERRADO $R/api/parear)" '"restam":4'
confere "codigo curto conta como erro"   "$(post -d codigo=12 $R/api/parear)" '"restam":3'
RESP=$(post -d codigo=$C -d 'nome=Celular do teste<script>' $R/api/parear)
confere "codigo certo: token"            "$RESP" '"ok":true,"token":"[0-9a-f]\{64\}"'
TOKEN=$(echo "$RESP" | python3 -c 'import json,sys; print(json.load(sys.stdin)["token"])')
confere "codigo nao serve 2 vezes"       "$(post -d codigo=$C $R/api/parear)" "parear_sem_codigo"
HASH=$(printf '%s' "$TOKEN" | sha256sum | awk '{print $1}')
confere "config.ini: so o sha256"        "$(grep '^paired' $DADOS/config.ini)" "paired = $HASH [0-9]* Celular do testescript"
nao_tem "config.ini sem o token"         "$(cat $DADOS/config.ini)" "$TOKEN"
confere "diario: pareado"                "$(cat $DADOS/glibren.log)" 'aparelho "Celular do testescript" pareado'

echo "--- token"
confere "estado com token: pareado"      "$(curl -s -H "X-GLR-Token: $TOKEN" $R/api/pareamento)" '"pareado":true'
confere "renomear com token"             "$(post -H "X-GLR-Token: $TOKEN" -d "pasta=$A" -d de=jogo1.pkg -d para=jogo9.pkg $R/api/renomear)" '"ok":true'
confere "token errado: 401"              "$(codigo -H 'X-GLR: 1' -H "X-GLR-Token: ${TOKEN%?}0" -d "pasta=$A" -d de=jogo9.pkg -d para=x.pkg $R/api/renomear)" "401"
confere "token com maiusculas: 401"      "$(codigo -H 'X-GLR: 1' -H "X-GLR-Token: ${TOKEN^^}" -d "pasta=$A" -d de=jogo9.pkg -d para=x.pkg $R/api/renomear)" "401"
confere "arquivo renomeado so 1 vez"     "$(ls $A | tr '\n' ' ')" "jogo2.pkg jogo9.pkg"
para; inicia
confere "token vale depois de reiniciar" "$(curl -s -H "X-GLR-Token: $TOKEN" $R/api/pareamento)" '"pareado":true,"aparelhos":1'

echo "--- bloqueio"
post -X POST $R/api/parear/pedir > /dev/null
C2=$(ultimo_codigo)
E2=$(printf '%06d' $(( (10#$C2 + 7) % 1000000 )))
for i in 1 2 3 4; do post -d codigo=$E2 $R/api/parear > /dev/null; done
confere "5o erro bloqueia"               "$(post -d codigo=$E2 $R/api/parear)" '"chave":"parear_bloqueado","erro":"muitas tentativas erradas: espere","params":{"espera":30}'
confere "codigo certo nao vale depois"   "$(post -d codigo=$C2 $R/api/parear)" "parear_bloqueado"
confere "pedir durante o bloqueio"       "$(post -X POST $R/api/parear/pedir)" "parear_espere"
confere "diario: bloqueado"              "$(cat $DADOS/glibren.log)" "bloqueado por 30 s"
confere "token antigo continua valendo"  "$(curl -s -H "X-GLR-Token: $TOKEN" $R/api/pareamento)" '"pareado":true'

echo "--- esquecer"
confere "esquecer sem token: 401"        "$(codigo -H 'X-GLR: 1' -X POST $R/api/parear/esquecer)" "401"
confere "esquecer com token"             "$(post -H "X-GLR-Token: $TOKEN" -X POST $R/api/parear/esquecer)" '"ok":true'
confere "token deixou de valer"          "$(codigo -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" -d "pasta=$A" -d de=jogo9.pkg -d para=x.pkg $R/api/renomear)" "401"
nao_tem "config.ini sem paired"          "$(cat $DADOS/config.ini)" "^paired"
para

echo "--- pairing = off"
sed -i 's/^pairing = on/pairing = off/' "$DADOS/config.ini"
inicia
confere "desligado: estado"              "$(curl -s $R/api/pareamento)" '"ligado":false'
confere "desligado: renomear sem token"  "$(post -d "pasta=$A" -d de=jogo9.pkg -d para=jogo8.pkg $R/api/renomear)" '"ok":true'
confere "desligado: pedir codigo"        "$(post -X POST $R/api/parear/pedir)" "parear_desligado"
confere "desligado: grava pairing = off" "$(post -d idioma=pt-BR $R/api/idioma; grep pairing $DADOS/config.ini)" "pairing = off"
para

rm -rf "$T"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
