/* Game Library Renamer (payload PS5) - rotas da API. */
#pragma once

#include "http.h"

#define VERSAO "0.9.16-teste"

extern int g_porta;

void api_tratar(pedido_t *p);
void api_atualizar_base(int forcar);
