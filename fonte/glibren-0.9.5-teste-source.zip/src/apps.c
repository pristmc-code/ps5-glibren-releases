/* Game Library Renamer (payload PS5) - instalador/atualizador de apps homebrew com um clique e botao YouTube.

Catalogo no repositorio publico de versoes (mesma BASE da atualizacao do payload):
  apps.json       {"apps":[{"id":"ytps5","titulo":"YouTube (ytps5)","title_id":"PPSA99350","versao":"1.2.3-glibren1",
                   "url":"https://github.com/.../PPSA99350.zip","tamanho":12345678,"sha256":"<hex>",
                   "preservar":["yt-token.json"],"busca":"glibren_busca.txt"}, ...]}
  apps.json.sig   assinatura Ed25519 (64 bytes) do apps.json inteiro, mesma chave do payload (tools/publicar_app.py)
A assinatura garante url, tamanho e sha256; o zip e conferido pelo SHA-256 calculado durante o download (em fluxo,
gravando em /data/GameLibraryRenamer/apps/<id>.zip.part - nada inteiro na memoria).

Instalar em /data/homebrew/<TITLE_ID> (onde o ShadowMountPlus procura apps):
  1. confere o zip: eboot.bin e sce_sys/param.json na raiz (ou dentro de uma pasta de topo unica, que e tirada -
     o YouTube Max'd vem assim), titleId do param.json igual ao do catalogo (zip.c recusa nomes perigosos, links,
     ZIP64, CRC errado e bombas; tudo e inflado em fluxo, com janela de 32 KB);
  2. extrai para <TID>.glibren_novo e copia para dentro os arquivos de "preservar" da instalacao atual (ex.: o login
     yt-token.json) e grava glibren_app.json (versao instalada);
  3. abre as permissoes de tudo (0777, dono 0 - como chega um app copiado por FTP: com 0644 o PS5 recusa abrir o app,
     "Nao e possivel iniciar o jogo ou app" CE-107750-0; o 0.8/0.8.1 extraia com 0644 e os apps nao abriam);
  4. renomeia a atual para <TID>.glibren_antigo, a nova para <TID> e apaga a antiga. Falhou no meio: restaura a antiga.
Apps instalados pelo glibren com permissoes fechadas (versoes 0.8/0.8.1) sao reparados ao listar e antes de abrir.

Desinstalar: pede ao ShadowMountPlus (API em 127.0.0.1:10101, POST /api/v1/games/uninstall) que tire o app do
sistema e apaga a pasta (renomeada antes para <TID>.glibren_antigo). App aberto (game_active): nao apaga nada.
Sem a API do ShadowMountPlus, apaga a pasta mesmo assim e o icone some na proxima busca dele (ou ao reiniciar).
Os apps oficiais do YouTube (PPSA01650/1/2) nunca sao instalados nem abertos: com o Y2JB o app oficial e a porta do
exploit.

Botao YouTube no PS5: grava a busca (uma linha UTF-8, ate 200 bytes) em /data/homebrew/<TID>/<busca> e abre o app
(sceSystemServiceLaunchApp, sem fechar nada). Para o YouTube Max'd o arquivo ganha a 2a linha "voltar=PMGL00001"
(o icone do glibren): ao sair, o Max'd reabre a tela do glibren. Acao "YouTube" da janela Apps: abre sempre o Max'd,
com a busca digitada ou vazia (apps_youtube_maxd).
*/
#include "apps.h"

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <time.h>
#include <unistd.h>

#include "assinatura.h"
#include "config.h"
#include "https.h"
#include "imagem.h"
#include "lancador.h"
#include "plataforma.h"
#include "sha256.h"
#include "smp_config.h"
#include "zip.h"

#define BASE "https://raw.githubusercontent.com/pristmc-code/ps5-glibren-releases/main/"
#define HOMEBREW "/data/homebrew"
#define MAX_APPS 16
#define MAX_PRESERVAR 8
#define MAX_CATALOGO (256 * 1024)
#define MAX_ZIP (2000ull * 1024 * 1024)       /* tamanho maximo do zip baixado */
#define MAX_EXTRAIDO (2048ull * 1024 * 1024)  /* soma maxima dos arquivos extraidos */
#define FOLGA (64ull * 1024 * 1024)           /* espaco livre que sobra depois de instalar */
#define VALIDADE_S (15 * 60)
#define BUSCA_PADRAO "glibren_busca.txt"
#define MAX_BUSCA 200
#define SMP_CONFIG "/data/shadowmount/config.ini"
#define SMP_PORTA 10101

typedef struct {
  char id[33], titulo[97], title_id[10], versao[33], url[1024], sha256[65], busca[64];
  unsigned long long tamanho;
  char preservar[MAX_PRESERVAR][64];
  int n_preservar;
} app_t;

/* Apps de YouTube, na ordem de preferencia (nunca o oficial). */
static const struct {
  const char *id, *title_id;
} YOUTUBE[] = {{"ytps5", "PPSA99350"}, {"youtube-maxd", "PPSA99991"}};

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static app_t g_apps[MAX_APPS];
static int g_n_apps, g_catalogo_ok;
static time_t g_verificado;
static char g_erro_catalogo[200];
/* trabalho em andamento (um por vez) */
static char g_trab_id[33], g_fase[16], g_erro[300], g_aviso[300];
static unsigned long long g_bytes, g_total;
static int g_rodando;

static const char *base(void) {
#ifndef __PROSPERO__
  const char *teste = getenv("GLR_TESTE_BASE");   /* so testes no PC (ver url_permitida) */
  if(teste && *teste) return teste;
#endif
  return BASE;
}

static const char *homebrew(void) {
#ifndef __PROSPERO__
  const char *teste = getenv("GLR_TESTE_HOMEBREW");
  if(teste && *teste == '/') return teste;
#endif
  return HOMEBREW;
}

static int oficial_youtube(const char *tid) {
  return !strcmp(tid, "PPSA01650") || !strcmp(tid, "PPSA01651") || !strcmp(tid, "PPSA01652") || !strcmp(tid, "PMGL00001");
}

/* ------------------------------------------------------------------ JSON (so o necessario para o catalogo) */

typedef struct {
  const char *p, *fim;
} json_t;

static void espacos(json_t *j) {
  while(j->p < j->fim && (*j->p == ' ' || *j->p == '\t' || *j->p == '\n' || *j->p == '\r')) j->p++;
}

static int caractere(json_t *j, char c) {
  espacos(j);
  if(j->p < j->fim && *j->p == c) {
    j->p++;
    return 1;
  }
  return 0;
}

static int hex4(const char *p, unsigned *v) {
  *v = 0;
  for(int i = 0; i < 4; i++) {
    char c = p[i];
    *v <<= 4;
    if(c >= '0' && c <= '9') *v |= (unsigned)(c - '0');
    else if(c >= 'a' && c <= 'f') *v |= (unsigned)(c - 'a' + 10);
    else if(c >= 'A' && c <= 'F') *v |= (unsigned)(c - 'A' + 10);
    else return -1;
  }
  return 0;
}

/* String JSON para saida (UTF-8). saida NULL = so pula. -1 = invalida ou maior que tam-1. */
static int ler_string(json_t *j, char *saida, size_t tam) {
  espacos(j);
  if(j->p >= j->fim || *j->p != '"') return -1;
  j->p++;
  size_t n = 0;
  while(j->p < j->fim && *j->p != '"') {
    unsigned char c = (unsigned char)*j->p++;
    char tmp[4];
    size_t k = 1;
    tmp[0] = (char)c;
    if(c < 0x20) return -1;
    if(c == '\\') {
      if(j->p >= j->fim) return -1;
      c = (unsigned char)*j->p++;
      switch(c) {
      case '"': case '\\': case '/': tmp[0] = (char)c; break;
      case 'n': case 'r': case 't': case 'b': case 'f': tmp[0] = ' '; break;   /* nada de controle nos textos */
      case 'u': {
        unsigned v;
        if(j->fim - j->p < 4 || hex4(j->p, &v)) return -1;
        j->p += 4;
        if(v >= 0xd800 && v <= 0xdbff) {   /* par substituto */
          unsigned v2;
          if(j->fim - j->p < 6 || j->p[0] != '\\' || j->p[1] != 'u' || hex4(j->p + 2, &v2) || v2 < 0xdc00 || v2 > 0xdfff) return -1;
          j->p += 6;
          v = 0x10000 + ((v - 0xd800) << 10) + (v2 - 0xdc00);
        } else if(v >= 0xdc00 && v <= 0xdfff) {
          return -1;
        }
        if(v < 0x20) v = ' ';
        if(v < 0x80) tmp[0] = (char)v;
        else if(v < 0x800) {
          tmp[0] = (char)(0xc0 | v >> 6);
          tmp[1] = (char)(0x80 | (v & 0x3f));
          k = 2;
        } else if(v < 0x10000) {
          tmp[0] = (char)(0xe0 | v >> 12);
          tmp[1] = (char)(0x80 | ((v >> 6) & 0x3f));
          tmp[2] = (char)(0x80 | (v & 0x3f));
          k = 3;
        } else {
          tmp[0] = (char)(0xf0 | v >> 18);
          tmp[1] = (char)(0x80 | ((v >> 12) & 0x3f));
          tmp[2] = (char)(0x80 | ((v >> 6) & 0x3f));
          tmp[3] = (char)(0x80 | (v & 0x3f));
          k = 4;
        }
        break;
      }
      default: return -1;
      }
    }
    if(saida) {
      if(n + k >= tam) return -1;
      memcpy(saida + n, tmp, k);
    }
    n += k;
  }
  if(j->p >= j->fim) return -1;
  j->p++;
  if(saida) saida[n] = 0;
  return 0;
}

/* Inteiro sem sinal (sem fracao nem expoente). */
static int ler_inteiro(json_t *j, unsigned long long *v) {
  espacos(j);
  *v = 0;
  int digitos = 0;
  while(j->p < j->fim && *j->p >= '0' && *j->p <= '9') {
    if(*v > 1000000000000000ull) return -1;
    *v = *v * 10 + (unsigned long long)(*j->p++ - '0');
    digitos++;
  }
  if(!digitos || (j->p < j->fim && (*j->p == '.' || *j->p == 'e' || *j->p == 'E'))) return -1;
  return 0;
}

static int pular_valor(json_t *j, int nivel) {
  if(nivel > 16) return -1;
  espacos(j);
  if(j->p >= j->fim) return -1;
  char c = *j->p;
  if(c == '"') return ler_string(j, NULL, 0);
  if(c == '{' || c == '[') {
    char fecha = c == '{' ? '}' : ']';
    j->p++;
    if(caractere(j, fecha)) return 0;
    do {
      if(c == '{' && (ler_string(j, NULL, 0) || !caractere(j, ':'))) return -1;
      if(pular_valor(j, nivel + 1)) return -1;
    } while(caractere(j, ','));
    return caractere(j, fecha) ? 0 : -1;
  }
  const char *ini = j->p;
  while(j->p < j->fim && strchr("0123456789+-.eEtruefalsn", *j->p)) j->p++;
  return j->p > ini ? 0 : -1;
}

static int so_caracteres(const char *s, const char *permitidos, size_t min, size_t max) {
  size_t n = strlen(s);
  if(n < min || n > max) return 0;
  for(; *s; s++) {
    if(!strchr(permitidos, *s)) return 0;
  }
  return 1;
}

#define MINUSCULAS "abcdefghijklmnopqrstuvwxyz"
#define DIGITOS "0123456789"

static int title_id_valido(const char *t) {
  if(strlen(t) != 9) return 0;
  for(int i = 0; i < 4; i++) if(t[i] < 'A' || t[i] > 'Z') return 0;
  for(int i = 4; i < 9; i++) if(t[i] < '0' || t[i] > '9') return 0;
  return 1;
}

/* Nome de arquivo simples dentro da pasta do app (sem pastas). */
static int nome_simples(const char *n) {
  return nome_valido(n) && zip_nome_seguro(n) && strlen(n) < 64 && strcmp(n, "glibren_app.json") && strncmp(n, ".", 1);
}

/* Um app do catalogo. 0 = valido. */
static int ler_app(json_t *j, app_t *a) {
  memset(a, 0, sizeof *a);
  if(!caractere(j, '{')) return -1;
  if(caractere(j, '}')) return -1;
  do {
    char chave[32];
    if(ler_string(j, chave, sizeof chave) || !caractere(j, ':')) return -1;
    int r = 0;
    if(!strcmp(chave, "id")) r = ler_string(j, a->id, sizeof a->id);
    else if(!strcmp(chave, "titulo")) r = ler_string(j, a->titulo, sizeof a->titulo);
    else if(!strcmp(chave, "title_id")) r = ler_string(j, a->title_id, sizeof a->title_id);
    else if(!strcmp(chave, "versao")) r = ler_string(j, a->versao, sizeof a->versao);
    else if(!strcmp(chave, "url")) r = ler_string(j, a->url, sizeof a->url);
    else if(!strcmp(chave, "sha256")) r = ler_string(j, a->sha256, sizeof a->sha256);
    else if(!strcmp(chave, "busca")) r = ler_string(j, a->busca, sizeof a->busca);
    else if(!strcmp(chave, "tamanho")) r = ler_inteiro(j, &a->tamanho);
    else if(!strcmp(chave, "preservar")) {
      if(!caractere(j, '[')) return -1;
      if(!caractere(j, ']')) {
        do {
          if(a->n_preservar == MAX_PRESERVAR) return -1;
          if(ler_string(j, a->preservar[a->n_preservar], sizeof a->preservar[0])) return -1;
          if(!nome_simples(a->preservar[a->n_preservar])) return -1;
          a->n_preservar++;
        } while(caractere(j, ','));
        if(!caractere(j, ']')) return -1;
      }
    } else r = pular_valor(j, 1);
    if(r) return -1;
  } while(caractere(j, ','));
  if(!caractere(j, '}')) return -1;
  for(char *c = a->sha256; *c; c++) if(*c >= 'A' && *c <= 'F') *c = (char)(*c - 'A' + 'a');
  if(!a->busca[0]) snprintf(a->busca, sizeof a->busca, "%s", BUSCA_PADRAO);
  if(!so_caracteres(a->id, MINUSCULAS DIGITOS "-_", 1, 32) || !a->titulo[0] || !title_id_valido(a->title_id) ||
     oficial_youtube(a->title_id) || !so_caracteres(a->versao, MINUSCULAS DIGITOS "ABCDEFGHIJKLMNOPQRSTUVWXYZ.-_", 1, 32) ||
     !url_permitida(a->url) || !a->tamanho || a->tamanho > MAX_ZIP || !so_caracteres(a->sha256, DIGITOS "abcdef", 64, 64) ||
     !nome_simples(a->busca))
    return -1;
  return 0;
}

/* {"apps":[...]} - outros campos sao ignorados. Devolve quantos apps validos leu, ou -1. */
static int ler_catalogo(const char *dados, size_t n, app_t *apps, int max) {
  json_t j = {dados, dados + n};
  int qtd = 0;
  if(!caractere(&j, '{')) return -1;
  if(caractere(&j, '}')) return 0;
  do {
    char chave[32];
    if(ler_string(&j, chave, sizeof chave) || !caractere(&j, ':')) return -1;
    if(strcmp(chave, "apps")) {
      if(pular_valor(&j, 1)) return -1;
      continue;
    }
    if(!caractere(&j, '[')) return -1;
    if(caractere(&j, ']')) continue;
    do {
      if(qtd == max) return -1;
      const char *ini = j.p;
      if(ler_app(&j, &apps[qtd])) {
        diario("apps: entrada do catalogo invalida perto do byte %ld - ignorada", (long)(ini - dados));
        j.p = ini;
        if(pular_valor(&j, 1)) return -1;
        continue;
      }
      int repetido = 0;
      for(int i = 0; i < qtd; i++) repetido |= !strcmp(apps[i].id, apps[qtd].id) || !strcmp(apps[i].title_id, apps[qtd].title_id);
      if(repetido) diario("apps: app repetido no catalogo (%s) - ignorado", apps[qtd].id);
      else qtd++;
    } while(caractere(&j, ','));
    if(!caractere(&j, ']')) return -1;
  } while(caractere(&j, ','));
  if(!caractere(&j, '}')) return -1;
  espacos(&j);
  return j.p == j.fim ? qtd : -1;
}

/* ------------------------------------------------------------------ catalogo */

static void verificar(int forcar) {
  pthread_mutex_lock(&g_trava);
  int recente = !forcar && g_verificado && time(NULL) - g_verificado < VALIDADE_S;
  pthread_mutex_unlock(&g_trava);
  if(recente) return;
  char url[512], erro[200] = "";
  buf_t json = {0}, sig = {0};
  static app_t novos[MAX_APPS];   /* so usado com a trava de baixo... */
  static pthread_mutex_t trava_novos = PTHREAD_MUTEX_INITIALIZER;
  int qtd = -1, s1, s2 = 0;
  snprintf(url, sizeof url, "%sapps.json", base());
  s1 = https_get(url, &json, MAX_CATALOGO, 20);
  if(s1 == 200) {
    snprintf(url, sizeof url, "%sapps.json.sig", base());
    s2 = https_get(url, &sig, 1024, 15);
  }
  pthread_mutex_lock(&trava_novos);
  if(s1 != 200 || s2 != 200) {
    snprintf(erro, sizeof erro, "nao foi possivel baixar o catalogo de apps (%d/%d)", s1, s2);
  } else if(sig.n != 64 || !assinatura_valida(json.d, json.n, (const unsigned char *)sig.d)) {
    snprintf(erro, sizeof erro, "assinatura do catalogo de apps invalida: recusado");
  } else if((qtd = ler_catalogo(json.d, json.n, novos, MAX_APPS)) < 0) {
    snprintf(erro, sizeof erro, "catalogo de apps com formato invalido");
  }
  if(erro[0]) diario("apps: %s", erro);
  else diario("apps: catalogo conferido (%d app(s), %zu bytes)", qtd, json.n);
  pthread_mutex_lock(&g_trava);
  snprintf(g_erro_catalogo, sizeof g_erro_catalogo, "%s", erro);
  if(!erro[0]) {
    memcpy(g_apps, novos, sizeof(app_t) * (size_t)qtd);
    g_n_apps = qtd;
    g_catalogo_ok = 1;
  } else if(strstr(erro, "assinatura") || strstr(erro, "formato")) {
    g_n_apps = 0;   /* catalogo adulterado: nao mostra nada dele (nem o antigo: na duvida, nada) */
    g_catalogo_ok = 0;
  }
  g_verificado = time(NULL);
  pthread_mutex_unlock(&g_trava);
  pthread_mutex_unlock(&trava_novos);
  buf_free(&json);
  buf_free(&sig);
}

/* Le "versao" de /data/homebrew/<TID>/glibren_app.json ("" se nao existe ou invalido). */
static void versao_instalada(const char *tid, char *saida, size_t tam) {
  char arq[600], dados[4096];
  saida[0] = 0;
  snprintf(arq, sizeof arq, "%s/%s/glibren_app.json", homebrew(), tid);
  int fd = open(arq, O_RDONLY | O_NOFOLLOW);
  if(fd < 0) return;
  ssize_t n = read(fd, dados, sizeof dados);
  close(fd);
  if(n <= 0 || n == (ssize_t)sizeof dados) return;
  json_t j = {dados, dados + n};
  if(!caractere(&j, '{')) return;
  do {
    char chave[32], valor[64];
    if(ler_string(&j, chave, sizeof chave) || !caractere(&j, ':')) return;
    if(!strcmp(chave, "versao")) {
      if(!ler_string(&j, valor, sizeof valor)) snprintf(saida, tam, "%s", valor);
      return;
    }
    if(pular_valor(&j, 1)) return;
  } while(caractere(&j, ','));
}

static int pasta_existe(const char *caminho) {
  struct stat st;
  return !lstat(caminho, &st) && S_ISDIR(st.st_mode);
}

/* Deixa a arvore como chega um app copiado por FTP: tudo 0777, dono 0 (o PS5 so abre o app assim). Links nao sao
   seguidos nem mudados. 0 = tudo certo. */
static int abrir_permissoes(const char *caminho, int nivel) {
  struct stat st;
  if(lstat(caminho, &st) || nivel > 64) return -1;
  if(S_ISLNK(st.st_mode)) return 0;
  int r = chmod(caminho, 0777) ? -1 : 0;
  if(chown(caminho, 0, 0)) { /* melhor esforco: o que decide e o modo */ }
  if(!S_ISDIR(st.st_mode)) return r;
  DIR *d = opendir(caminho);
  if(!d) return -1;
  struct dirent *e;
  char filho[1200];
  while((e = readdir(d))) {
    if(!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
    int n = snprintf(filho, sizeof filho, "%s/%s", caminho, e->d_name);
    if(n < 0 || (size_t)n >= sizeof filho || abrir_permissoes(filho, nivel + 1)) r = -1;
  }
  closedir(d);
  return r;
}

/* Pasta do app, eboot.bin e sce_sys com 0777 (amostra barata: o reparo abre a arvore toda). */
static int permissoes_ok(const char *tid) {
  const char *partes[] = {"", "/eboot.bin", "/sce_sys", "/sce_sys/param.json"};
  for(size_t i = 0; i < sizeof partes / sizeof *partes; i++) {
    char arq[700];
    struct stat st;
    snprintf(arq, sizeof arq, "%s/%s%s", homebrew(), tid, partes[i]);
    if(!lstat(arq, &st) && !S_ISLNK(st.st_mode) && (st.st_mode & 0777) != 0777) return 0;
  }
  return 1;
}

/* Abre as permissoes de um app ja instalado, se estiverem fechadas. 0 = ok (ou nada a fazer). */
static int reparar_permissoes(const char *tid) {
  if(permissoes_ok(tid)) return 0;
  char pasta[600];
  snprintf(pasta, sizeof pasta, "%s/%s", homebrew(), tid);
  int r = abrir_permissoes(pasta, 0);
  diario("apps: %s: permissoes abertas para 0777 (o PS5 recusava abrir o app)%s", tid, r ? " - FALHOU em parte" : "");
  return r;
}

static int app_instalado(const char *tid) {
  char pasta[600];
  snprintf(pasta, sizeof pasta, "%s/%s", homebrew(), tid);
  return pasta_existe(pasta);
}

void apps_json(buf_t *b, int forcar) {
  verificar(forcar);
  app_t apps[MAX_APPS];
  pthread_mutex_lock(&g_trava);
  int n = g_n_apps, ok = g_catalogo_ok, ocupado = g_rodando;
  memcpy(apps, g_apps, sizeof(app_t) * (size_t)n);
  char erro[200];
  snprintf(erro, sizeof erro, "%s", g_erro_catalogo);
  pthread_mutex_unlock(&g_trava);
  /* agora: a tela compara com a hora de quem esta vendo - relogio do PS5 errado = os apps de YouTube (curl/OpenSSL
     com a lista de certificados do PS5) recusam todos os certificados e nao acham nada, sem mensagem */
  buf_fmt(b, "{\"ok\":true,\"agora\":%lld,\"catalogo\":%s,\"erro\":", (long long)time(NULL), ok ? "true" : "false");
  buf_json(b, erro);
  buf_str(b, ",\"apps\":[");
  for(int i = 0; i < n; i++) {
    const app_t *a = &apps[i];
    char inst[64];
    int instalado = app_instalado(a->title_id);
    versao_instalada(a->title_id, inst, sizeof inst);
    if(instalado && inst[0] && !ocupado) reparar_permissoes(a->title_id);   /* instalado pelo 0.8/0.8.1 */
    int perm = !instalado || permissoes_ok(a->title_id);
    int youtube = 0;
    for(size_t k = 0; k < sizeof YOUTUBE / sizeof *YOUTUBE; k++) youtube |= !strcmp(YOUTUBE[k].title_id, a->title_id);
    buf_str(b, i ? ",{\"id\":" : "{\"id\":");
    buf_json(b, a->id);
    buf_str(b, ",\"titulo\":");
    buf_json(b, a->titulo);
    buf_str(b, ",\"title_id\":");
    buf_json(b, a->title_id);
    buf_str(b, ",\"versao\":");
    buf_json(b, a->versao);
    buf_fmt(b, ",\"tamanho\":%llu,\"instalado\":%s,\"versao_instalada\":", a->tamanho, instalado ? "true" : "false");
    buf_json(b, inst);
    buf_fmt(b, ",\"atualizar\":%s,\"youtube\":%s,\"permissoes_ok\":%s}", instalado && strcmp(inst, a->versao) ? "true" : "false",
            youtube ? "true" : "false", perm ? "true" : "false");
  }
  pthread_mutex_lock(&g_trava);
  buf_str(b, "],\"trabalho\":{\"id\":");
  buf_json(b, g_trab_id);
  buf_str(b, ",\"fase\":");
  buf_json(b, g_fase);
  buf_fmt(b, ",\"bytes\":%llu,\"total\":%llu,\"erro\":", g_bytes, g_total);
  buf_json(b, g_erro);
  buf_str(b, ",\"aviso\":");
  buf_json(b, g_aviso);
  buf_fmt(b, ",\"rodando\":%s}}", g_rodando ? "true" : "false");
  pthread_mutex_unlock(&g_trava);
}

/* ------------------------------------------------------------------ instalacao */

static void fase(const char *f, unsigned long long total) {
  pthread_mutex_lock(&g_trava);
  snprintf(g_fase, sizeof g_fase, "%s", f);
  g_bytes = 0;
  g_total = total;
  pthread_mutex_unlock(&g_trava);
}

static void progresso(unsigned long long bytes) {
  pthread_mutex_lock(&g_trava);
  g_bytes = bytes;
  pthread_mutex_unlock(&g_trava);
}

/* Erro: registra (codigo em hex) e encerra o trabalho. */
static void falhou(const char *id, int codigo, const char *fmt, ...) __attribute__((format(printf, 3, 4)));
static void falhou(const char *id, int codigo, const char *fmt, ...) {
  char msg[300];
  va_list args;
  va_start(args, fmt);
  vsnprintf(msg, sizeof msg, fmt, args);
  va_end(args);
  diario("apps: %s: ERRO 0x%08x: %s", id, (unsigned)codigo, msg);
  pthread_mutex_lock(&g_trava);
  snprintf(g_fase, sizeof g_fase, "erro");
  snprintf(g_erro, sizeof g_erro, "%s", msg);
  g_rodando = 0;
  pthread_mutex_unlock(&g_trava);
}

/* Apaga uma arvore sem seguir links (links sao apagados como arquivos). */
static int apagar_arvore(const char *caminho, int nivel) {
  struct stat st;
  if(lstat(caminho, &st)) return errno == ENOENT ? 0 : -1;
  if(!S_ISDIR(st.st_mode)) return unlink(caminho);
  if(nivel > 64) return -1;
  DIR *d = opendir(caminho);
  if(!d) return -1;
  int r = 0;
  struct dirent *e;
  char filho[1200];
  while((e = readdir(d))) {
    if(!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
    int n = snprintf(filho, sizeof filho, "%s/%s", caminho, e->d_name);
    if(n < 0 || (size_t)n >= sizeof filho || apagar_arvore(filho, nivel + 1)) r = -1;
  }
  closedir(d);
  return rmdir(caminho) || r ? -1 : 0;
}

/* So apaga as pastas temporarias do instalador: <homebrew>/<TID>.glibren_novo ou .glibren_antigo. */
static int apagar_temporaria(const char *caminho) {
  const char *hb = homebrew();
  size_t n = strlen(hb);
  const char *nome = caminho + n + 1;
  size_t t = strlen(caminho);
  char tid[10] = "";
  int ok = t < 600 && !strncmp(caminho, hb, n) && caminho[n] == '/' && !strchr(nome, '/') && strlen(nome) > 9 &&
           (!strcmp(nome + 9, ".glibren_novo") || !strcmp(nome + 9, ".glibren_antigo"));
  if(ok) {
    memcpy(tid, nome, 9);
    ok = title_id_valido(tid);
  }
  if(!ok) {
    diario("apps: recusado apagar %s (fora das pastas temporarias)", caminho);
    return -1;
  }
  int r = apagar_arvore(caminho, 0);
  if(r) diario("apps: nao apagou tudo em %s (errno %d)", caminho, errno);
  return r;
}

/* Copia um arquivo comum (sem seguir links) para destino (gravando .tmp e renomeando). */
static int copiar_arquivo(const char *origem, const char *destino) {
  char tmp[700];
  snprintf(tmp, sizeof tmp, "%s.glibren_tmp", destino);
  int de = open(origem, O_RDONLY | O_NOFOLLOW);
  if(de < 0) return -1;
  unlink(tmp);
  int para = open(tmp, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644);
  int ok = para >= 0;
  char bloco[16 * 1024];
  ssize_t n;
  while(ok && (n = read(de, bloco, sizeof bloco)) > 0) ok = write(para, bloco, (size_t)n) == n;
  if(ok && n < 0) ok = 0;
  close(de);
  if(para >= 0 && close(para)) ok = 0;
  if(ok && rename(tmp, destino)) ok = 0;
  if(!ok) unlink(tmp);
  return ok ? 0 : -1;
}

static int gravar_texto(const char *arquivo, const char *texto) {
  char tmp[700];
  snprintf(tmp, sizeof tmp, "%s.tmp", arquivo);
  unlink(tmp);
  int fd = open(tmp, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644);
  if(fd < 0) return -1;
  size_t n = strlen(texto);
  int ok = write(fd, texto, n) == (ssize_t)n;
  if(close(fd)) ok = 0;
  if(ok && rename(tmp, arquivo)) ok = 0;
  if(!ok) unlink(tmp);
  return ok ? 0 : -1;
}

static unsigned long long espaco_livre(const char *pasta) {
  struct statvfs v;
  if(statvfs(pasta, &v)) return 0;
  return (unsigned long long)v.f_bavail * (unsigned long long)v.f_frsize;
}

typedef struct {
  int fd, excedeu, erro_gravar;
  unsigned long long n, limite;
  sha256_t sha;
} download_t;

static int recebeu(const void *dados, size_t n, void *ctx) {
  download_t *d = ctx;
  if(!dados) return 0;
  if(d->n + n > d->limite) {
    d->excedeu = 1;
    return 1;
  }
  for(size_t feitos = 0; feitos < n;) {
    ssize_t r = write(d->fd, (const char *)dados + feitos, n - feitos);
    if(r <= 0) {
      d->erro_gravar = 1;
      return 1;
    }
    feitos += (size_t)r;
  }
  sha256_atualizar(&d->sha, dados, n);
  d->n += n;
  progresso(d->n);
  return 0;
}

static void progresso_extracao(uint64_t feitos, uint64_t total, void *ctx) {
  (void)total;
  (void)ctx;
  progresso(feitos);
}

static void *instalar(void *arg) {
  app_t a = *(app_t *)arg;
  free(arg);
  char pasta_zips[600], parcial[700], zip_arq[700], final[600], novo[640], antigo[640], erro[300] = "";
  const char *hb = homebrew();
  snprintf(pasta_zips, sizeof pasta_zips, "%s/apps", g_pasta_dados);
  snprintf(parcial, sizeof parcial, "%s/%s.zip.part", pasta_zips, a.id);
  snprintf(zip_arq, sizeof zip_arq, "%s/%s.zip", pasta_zips, a.id);
  snprintf(final, sizeof final, "%s/%s", hb, a.title_id);
  snprintf(novo, sizeof novo, "%s.glibren_novo", final);
  snprintf(antigo, sizeof antigo, "%s.glibren_antigo", final);
  zip_t z;
  memset(&z, 0, sizeof z);
  z.fd = -1;
  diario("apps: %s: instalando versao %s (%llu bytes) em %s", a.id, a.versao, a.tamanho, final);

  /* ---- baixando */
  fase("baixando", a.tamanho);
  if(mkdir_p(pasta_zips) || mkdir_p(hb)) {
    falhou(a.id, errno, "nao criou as pastas (%s)", strerror(errno));
    return NULL;
  }
  unsigned long long livre = espaco_livre(hb);
  if(livre < a.tamanho * 2 + FOLGA) {
    falhou(a.id, ENOSPC, "espaco livre insuficiente no PS5 (%llu MB livres)", livre / (1024 * 1024));
    return NULL;
  }
  download_t d;
  memset(&d, 0, sizeof d);
  d.limite = a.tamanho;
  sha256_iniciar(&d.sha);
  unlink(parcial);
  if((d.fd = open(parcial, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644)) < 0) {
    falhou(a.id, errno, "nao criou %s (%s)", parcial, strerror(errno));
    return NULL;
  }
  int status = https_baixar(a.url, recebeu, &d);
  int fechou = close(d.fd);
  diario("apps: %s: download status %d, %llu bytes", a.id, status, d.n);
  if(status != 200 || d.excedeu || d.erro_gravar || fechou || d.n != a.tamanho) {
    unlink(parcial);
    if(status != 200) falhou(a.id, status, "nao foi possivel baixar o app (HTTP %d)", status);
    else if(d.excedeu || d.n != a.tamanho) falhou(a.id, 0, "tamanho do download diferente do catalogo (%llu de %llu bytes)", d.n, a.tamanho);
    else falhou(a.id, errno, "erro ao gravar o download no PS5");
    return NULL;
  }

  /* ---- conferindo */
  fase("conferindo", 0);
  uint8_t resumo[32];
  char hex[65];
  sha256_final(&d.sha, resumo);
  sha256_hex(resumo, hex);
  if(strcmp(hex, a.sha256)) {
    unlink(parcial);
    falhou(a.id, 0, "SHA-256 do download nao confere: arquivo recusado (veio %.16s..., esperado %.16s...)", hex, a.sha256);
    return NULL;
  }
  if(rename(parcial, zip_arq)) {
    unlink(parcial);
    falhou(a.id, errno, "nao renomeou o download (%s)", strerror(errno));
    return NULL;
  }
  int r = zip_abrir(&z, zip_arq, MAX_EXTRAIDO, erro, sizeof erro);
  if(r) {
    unlink(zip_arq);
    falhou(a.id, r, "zip recusado: %s", erro);
    return NULL;
  }
  /* zip com tudo dentro de uma pasta de topo (o YouTube Max'd vem assim: PPSA99991/...): tira a pasta */
  char topo[ZIP_MAX_NOME];
  if(!zip_achar(&z, "eboot.bin") && zip_pasta_topo(&z, topo, sizeof topo)) {
    diario("apps: %s: zip com pasta de topo \"%s\" - extraindo o conteudo dela", a.id, topo);
    zip_tirar_pasta_topo(&z, topo);
  }
  const zip_entrada_t *eboot = zip_achar(&z, "eboot.bin"), *param = zip_achar(&z, "sce_sys/param.json");
  buf_t pj = {0};
  info_jogo_t info;
  if(!eboot || eboot->pasta || !param) {
    falhou(a.id, ZIP_E_FORMATO, "o zip nao tem eboot.bin e sce_sys/param.json na raiz");
    goto sair;
  }
  if((r = zip_ler(&z, param, &pj, 256 * 1024, erro, sizeof erro))) {
    falhou(a.id, r, "param.json do zip: %s", erro);
    goto sair;
  }
  if(param_json_ler(pj.d, pj.n, NULL, &info) || strcmp(info.title_id, a.title_id)) {
    falhou(a.id, 0, "titleId do param.json (%s) diferente do catalogo (%s)", info.title_id, a.title_id);
    buf_free(&pj);
    goto sair;
  }
  buf_free(&pj);
  livre = espaco_livre(hb);
  if(livre < z.total + FOLGA) {
    falhou(a.id, ENOSPC, "espaco livre insuficiente para extrair (%llu MB livres, precisa %llu MB)", livre / (1024 * 1024),
           (unsigned long long)(z.total + FOLGA) / (1024 * 1024));
    goto sair;
  }

  /* ---- extraindo */
  /* sobra de uma tentativa interrompida (o PS5 desligou no meio da troca): a instalacao atual esta em .glibren_antigo */
  if(!pasta_existe(final) && pasta_existe(antigo)) {
    diario("apps: %s: recuperando a instalacao anterior de %s", a.id, antigo);
    if(rename(antigo, final)) diario("apps: %s: nao recuperou (errno %d)", a.id, errno);
  }
  if(pasta_existe(antigo)) apagar_temporaria(antigo);
  if(apagar_temporaria(novo) || mkdir(novo, 0777)) {
    falhou(a.id, errno, "nao criou a pasta temporaria %s (%s)", novo, strerror(errno));
    goto sair;
  }
  fase("extraindo", z.total);
  if((r = zip_extrair(&z, novo, progresso_extracao, NULL, erro, sizeof erro))) {
    apagar_temporaria(novo);
    falhou(a.id, r, "extracao: %s", erro);
    goto sair;
  }
  diario("apps: %s: extraido (%u entradas, %llu bytes)", a.id, z.n, (unsigned long long)z.total);

  /* ---- instalando */
  fase("instalando", 0);
  int tem_atual = pasta_existe(final);
  for(int i = 0; tem_atual && i < a.n_preservar; i++) {
    char de[700], para[700];
    struct stat st;
    snprintf(de, sizeof de, "%s/%s", final, a.preservar[i]);
    snprintf(para, sizeof para, "%s/%s", novo, a.preservar[i]);
    if(lstat(de, &st) || !S_ISREG(st.st_mode)) continue;
    if(copiar_arquivo(de, para)) {
      apagar_temporaria(novo);
      falhou(a.id, errno, "nao copiou %s da instalacao atual: instalacao cancelada para nao perder o arquivo", a.preservar[i]);
      goto sair;
    }
    diario("apps: %s: preservado %s (%lld bytes)", a.id, a.preservar[i], (long long)st.st_size);
  }
  char info_app[400], arq_info[700];
  snprintf(info_app, sizeof info_app, "{\"id\":\"%s\",\"versao\":\"%s\",\"sha256\":\"%s\",\"instalado_em\":%lld}\n", a.id,
           a.versao, a.sha256, (long long)time(NULL));
  snprintf(arq_info, sizeof arq_info, "%s/glibren_app.json", novo);
  if(gravar_texto(arq_info, info_app)) {
    apagar_temporaria(novo);
    falhou(a.id, errno, "nao gravou glibren_app.json (%s)", strerror(errno));
    goto sair;
  }
  if(abrir_permissoes(novo, 0)) {
    apagar_temporaria(novo);
    falhou(a.id, errno, "nao conseguiu ajustar as permissoes dos arquivos (o PS5 nao abriria o app)");
    goto sair;
  }
  if(tem_atual && rename(final, antigo)) {
    apagar_temporaria(novo);
    falhou(a.id, errno, "nao conseguiu tirar a versao atual do lugar (%s)", strerror(errno));
    goto sair;
  }
  if(rename(novo, final)) {
    int e = errno;
    if(tem_atual && rename(antigo, final)) diario("apps: %s: ATENCAO: nao restaurou %s (errno %d)", a.id, antigo, errno);
    apagar_temporaria(novo);
    falhou(a.id, e, "nao conseguiu colocar a versao nova no lugar (%s); a anterior foi mantida", strerror(e));
    goto sair;
  }
  if(tem_atual) apagar_temporaria(antigo);
  diario("apps: %s: versao %s instalada em %s", a.id, a.versao, final);
  pthread_mutex_lock(&g_trava);
  snprintf(g_fase, sizeof g_fase, "pronto");
  g_erro[0] = 0;
  g_rodando = 0;
  pthread_mutex_unlock(&g_trava);
  notificar("Game Library Renamer: %s %s instalado", a.titulo, a.versao);
sair:
  zip_fechar(&z);
  unlink(zip_arq);
  return NULL;
}

int apps_instalar(const char *id, char *msg, size_t tam) {
  verificar(0);
  app_t *a = malloc(sizeof *a);
  if(!a) {
    snprintf(msg, tam, "sem memoria");
    return -1;
  }
  pthread_mutex_lock(&g_trava);
  int i = 0;
  while(i < g_n_apps && strcmp(g_apps[i].id, id)) i++;
  if(g_rodando || i == g_n_apps) {
    snprintf(msg, tam, g_rodando ? "ja existe uma instalacao em andamento" : "app nao esta no catalogo");
    pthread_mutex_unlock(&g_trava);
    free(a);
    return -1;
  }
  *a = g_apps[i];
  g_rodando = 1;
  snprintf(g_trab_id, sizeof g_trab_id, "%s", id);
  snprintf(g_fase, sizeof g_fase, "baixando");
  g_erro[0] = g_aviso[0] = 0;
  g_bytes = 0;
  g_total = a->tamanho;
  pthread_mutex_unlock(&g_trava);
  if(criar_thread(instalar, a, NULL)) {
    free(a);
    falhou(id, -1, "nao iniciou a instalacao");
    snprintf(msg, tam, "nao iniciou a instalacao");
    return -1;
  }
  return 0;
}

/* ------------------------------------------------------------------ desinstalar */

/* Endereco da API do ShadowMountPlus pelo config.ini dele, formato v1 (api_port/api_bind_address) ou v2 ([api] port/
   bind_address) - ver smp_config.c. Padrao 127.0.0.1:10101. */
static void smp_endereco(struct sockaddr_in *end) {
  memset(end, 0, sizeof *end);
  end->sin_family = AF_INET;
  end->sin_port = htons(SMP_PORTA);
  end->sin_addr.s_addr = htonl(INADDR_LOOPBACK);
#ifndef __PROSPERO__
  const char *teste = getenv("GLR_TESTE_SMP_PORTA");   /* so testes no PC: ShadowMountPlus de mentira */
  if(teste && *teste) {
    end->sin_port = htons((unsigned short)atoi(teste));
    return;
  }
#endif
  const char *arquivo = SMP_CONFIG;
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_SMP_CONFIG")) arquivo = getenv("GLR_TESTE_SMP_CONFIG");
#endif
  FILE *f = fopen(arquivo, "r");
  if(!f) return;
  int porta = ntohs(end->sin_port);
  char valor[64] = "";
  struct in_addr ip;
  smp_config_ler(f, &porta, valor, sizeof valor);
  end->sin_port = htons((unsigned short)porta);
  if(valor[0] && inet_pton(AF_INET, valor, &ip) == 1 && ip.s_addr != htonl(INADDR_ANY))
    end->sin_addr = ip;   /* ligada num IP so (nao 0.0.0.0): o 127.0.0.1 nao responde */
  fclose(f);
}

/* POST /api/v1/games/uninstall {"title_id":tid}. Devolve o "status" do ShadowMountPlus (0 = ok, senao errno) ou -1 sem
   resposta (API desligada ou ShadowMountPlus nao carregado); motivo recebe error_reason (ou error). */
static int smp_desinstalar(const char *tid, char *motivo, size_t tam) {
  char pedido[512], resposta[4096], corpo[64];
  motivo[0] = 0;
  int n = snprintf(corpo, sizeof corpo, "{\"title_id\":\"%s\"}", tid);
  int k = snprintf(pedido, sizeof pedido,
                   "POST /api/v1/games/uninstall HTTP/1.1\r\nHost: 127.0.0.1\r\nContent-Type: application/json\r\n"
                   "Content-Length: %d\r\nConnection: close\r\n\r\n%s", n, corpo);
  struct sockaddr_in end;
  smp_endereco(&end);
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if(fd < 0) return -1;
  struct timeval espera = {30, 0};   /* desinstalar pode levar alguns segundos */
  setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &espera, sizeof espera);
  setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &espera, sizeof espera);
  size_t lidos = 0;
  int ok = !connect(fd, (struct sockaddr *)&end, sizeof end) && send(fd, pedido, (size_t)k, 0) == k;
  while(ok && lidos < sizeof resposta - 1) {
    ssize_t r = recv(fd, resposta + lidos, sizeof resposta - 1 - lidos, 0);
    if(r <= 0) break;
    lidos += (size_t)r;
  }
  close(fd);
  resposta[lidos] = 0;
  const char *json = strstr(resposta, "\r\n\r\n");
  const char *st = json ? strstr(json, "\"status\"") : NULL;
  const char *dois_pontos = st ? strchr(st, ':') : NULL;
  int status = -1;
  if(!ok || !dois_pontos || sscanf(dois_pontos + 1, " %d", &status) != 1 || status < 0) return -1;
  const char *chaves[] = {"\"error_reason\"", "\"error\""};
  for(size_t i = 0; status && !motivo[0] && i < 2; i++) {
    json_t j = {strstr(json, chaves[i]), resposta + lidos};
    if(!j.p) continue;
    j.p += strlen(chaves[i]);
    if(!caractere(&j, ':') || ler_string(&j, motivo, tam)) motivo[0] = 0;
  }
  return status;
}

static void *desinstalar(void *arg) {
  app_t a = *(app_t *)arg;
  free(arg);
  char final[600], antigo[640], motivo[160], zip_arq[700], aviso[300] = "";
  snprintf(final, sizeof final, "%s/%s", homebrew(), a.title_id);
  snprintf(antigo, sizeof antigo, "%s.glibren_antigo", final);
  snprintf(zip_arq, sizeof zip_arq, "%s/apps/%s.zip", g_pasta_dados, a.id);
  diario("apps: %s: desinstalando %s", a.id, final);

  /* 1. tira do sistema (icone e app.db) pelo ShadowMountPlus */
  int smp = smp_desinstalar(a.title_id, motivo, sizeof motivo);
  diario("apps: %s: ShadowMountPlus uninstall: status %d %s", a.id, smp, motivo);
  if(smp > 0 && strstr(motivo, "active")) {
    falhou(a.id, smp, "o app esta aberto: feche o app (tambem em segundo plano) e tente de novo");
    return NULL;
  }

  /* 2. apaga a pasta (renomeada antes, para o ShadowMountPlus nao achar um app pela metade) */
  if(pasta_existe(antigo)) apagar_temporaria(antigo);
  if(pasta_existe(final) && rename(final, antigo)) {
    falhou(a.id, errno, "nao conseguiu tirar a pasta %s (%s)", final, strerror(errno));
    return NULL;
  }
  if(pasta_existe(antigo) && apagar_temporaria(antigo)) {
    falhou(a.id, errno, "a pasta saiu do lugar mas nao foi apagada inteira (%s)", antigo);
    return NULL;
  }
  unlink(zip_arq);

  /* 3. o ShadowMountPlus falhou antes (sem ser app aberto): com a pasta ja apagada ele sincroniza e tira o icone */
  if(smp > 0 && smp != ENOENT) {
    int de_novo = smp_desinstalar(a.title_id, motivo, sizeof motivo);
    diario("apps: %s: ShadowMountPlus uninstall (2a vez): status %d %s", a.id, de_novo, motivo);
    if(de_novo > 0 && de_novo != ENOENT)
      snprintf(aviso, sizeof aviso, "pasta apagada, mas o ShadowMountPlus respondeu \"%s\": se o icone continuar, reinicie o PS5", motivo);
  } else if(smp < 0) {
    snprintf(aviso, sizeof aviso, "pasta apagada; a API do ShadowMountPlus nao respondeu: o icone some na proxima busca dele ou ao reiniciar o PS5");
  }
  diario("apps: %s: desinstalado%s%s", a.id, aviso[0] ? " - " : "", aviso);
  pthread_mutex_lock(&g_trava);
  snprintf(g_fase, sizeof g_fase, "desinstalado");
  g_erro[0] = 0;
  snprintf(g_aviso, sizeof g_aviso, "%s", aviso);
  g_rodando = 0;
  pthread_mutex_unlock(&g_trava);
  notificar("Game Library Renamer: %s desinstalado", a.titulo);
  return NULL;
}

int apps_desinstalar(const char *id, char *msg, size_t tam) {
  app_t *a = malloc(sizeof *a);
  if(!a) {
    snprintf(msg, tam, "sem memoria");
    return -1;
  }
  pthread_mutex_lock(&g_trava);
  int i = 0;
  while(i < g_n_apps && strcmp(g_apps[i].id, id)) i++;
  const char *recusa = g_rodando ? "ja existe uma instalacao em andamento" : i == g_n_apps ? "app nao esta no catalogo" : NULL;
  if(!recusa && !app_instalado(g_apps[i].title_id)) recusa = "o app nao esta instalado";
  if(recusa) {
    snprintf(msg, tam, "%s", recusa);
    pthread_mutex_unlock(&g_trava);
    free(a);
    return -1;
  }
  *a = g_apps[i];
  g_rodando = 1;
  snprintf(g_trab_id, sizeof g_trab_id, "%s", id);
  snprintf(g_fase, sizeof g_fase, "desinstalando");
  g_erro[0] = g_aviso[0] = 0;
  g_bytes = g_total = 0;
  pthread_mutex_unlock(&g_trava);
  if(criar_thread(desinstalar, a, NULL)) {
    free(a);
    falhou(id, -1, "nao iniciou a desinstalacao");
    snprintf(msg, tam, "nao iniciou a desinstalacao");
    return -1;
  }
  return 0;
}

/* ------------------------------------------------------------------ log do app (diagnostico) */

/* Ultimos ~48 KB do log do app (so o ytps5 grava arquivo: /download0/hui/dev/yt.log, visivel de fora em
   /mnt/sandbox/<TID>_000/... enquanto o app esta aberto), com a hora do PS5 no topo. */
void apps_log(const char *id, buf_t *b) {
  time_t agora = time(NULL);
  char hora[64];
  strftime(hora, sizeof hora, "%d/%m/%Y %H:%M:%S UTC", gmtime(&agora));
  buf_fmt(b, "Hora do PS5: %s (compare com a hora certa: diferenca grande = HTTPS dos apps falha)\n", hora);
  if(strcmp(id, "ytps5")) {
    buf_str(b, "Este app nao grava log em arquivo. No YouTube Max'd: Configuracoes > Sobre > Bug-report export.\n");
    return;
  }
  const char *caminhos[] = {"/mnt/sandbox/PPSA99350_000/download0/hui/dev/yt.log", "/mnt/sandbox/PPSA99350_001/download0/hui/dev/yt.log"};
  for(size_t i = 0; i < sizeof caminhos / sizeof *caminhos; i++) {
    int fd = open(caminhos[i], O_RDONLY | O_NOFOLLOW);
    if(fd < 0) continue;
    struct stat st;
    off_t ini = 0;
    if(!fstat(fd, &st) && st.st_size > 48 * 1024) ini = st.st_size - 48 * 1024;
    buf_fmt(b, "%s (%lld bytes%s)\n\n", caminhos[i], (long long)st.st_size, ini ? ", so o final" : "");
    if(lseek(fd, ini, SEEK_SET) == ini) {
      char bloco[16 * 1024];
      ssize_t n;
      while((n = read(fd, bloco, sizeof bloco)) > 0) buf_add(b, bloco, (size_t)n);
    }
    close(fd);
    return;
  }
  buf_str(b, "yt.log nao encontrado: abra o ytps5, tente buscar um video e, com o app ainda aberto, recarregue esta pagina\n"
             "(pelo celular ou PC em http://IP-DO-PS5:8765/app-log).\n");
}

/* ------------------------------------------------------------------ YouTube */

/* Busca em uma linha: so UTF-8 valido, controles e espacos seguidos viram um espaco, sem espacos nas pontas, ate
   MAX_BUSCA bytes (sem cortar um caractere no meio). */
static void limpar_busca(const char *busca, char *saida) {
  size_t n = 0;
  const unsigned char *p = (const unsigned char *)busca;
  while(*p) {
    size_t k = *p < 0x80 ? 1 : (*p & 0xe0) == 0xc0 ? 2 : (*p & 0xf0) == 0xe0 ? 3 : (*p & 0xf8) == 0xf0 ? 4 : 0;
    int ok = k > 0 && (k < 2 || *p >= 0xc2) && (k < 4 || *p <= 0xf4);
    for(size_t i = 1; ok && i < k; i++) ok = (p[i] & 0xc0) == 0x80;
    if(!ok) {   /* byte invalido: descarta */
      p++;
      continue;
    }
    if(n + k > MAX_BUSCA) break;
    if(k == 1 && (*p <= 0x20 || *p == 0x7f)) {   /* espacos e controles seguidos viram um espaco so */
      if(n && saida[n - 1] != ' ') saida[n++] = ' ';
    } else {
      memcpy(saida + n, p, k);
      n += k;
    }
    p += k;
  }
  while(n && saida[n - 1] == ' ') n--;
  saida[n] = 0;
  size_t ini = strspn(saida, " ");
  memmove(saida, saida + ini, n - ini + 1);
}

/* App de YouTube instalado (eboot.bin em /data/homebrew/<TID>): o indice em YOUTUBE ou -1. so = so esse title_id. */
static int youtube_instalado(const char *so) {
  char eboot[700];
  struct stat st;
  for(size_t i = 0; i < sizeof YOUTUBE / sizeof *YOUTUBE; i++) {
    if(so && strcmp(so, YOUTUBE[i].title_id)) continue;
    snprintf(eboot, sizeof eboot, "%s/%s/eboot.bin", homebrew(), YOUTUBE[i].title_id);
    if(!lstat(eboot, &st) && S_ISREG(st.st_mode)) return (int)i;
  }
  return -1;
}

/* Grava a busca no app YOUTUBE[i] e abre o app. O YouTube Max'd (PPSA99991) le uma 2a linha "voltar=<TITLEID>" e,
   ao sair, reabre esse titulo: o glibren manda o proprio icone (GLIBREN_TITLE_ID). O ytps5 le so a 1a linha, entao
   para ele o arquivo continua com uma linha so. */
static int youtube_abrir(int i, const char *texto, buf_t *json, char *chave, size_t tam_chave, char *msg, size_t tam_msg) {
  char pasta[600], arquivo[700], nome_busca[64] = BUSCA_PADRAO, conteudo[MAX_BUSCA + 64];
  const char *tid = YOUTUBE[i].title_id;
  int maxd = !strcmp(tid, "PPSA99991");
  /* nunca lancar por cima de outro app de jogo (falha 0x80940011/0x80940031, suspeito de derrubar o console); a
     pagina do glibren no navegador nao conta (lancador.c). msg recebe so o titulo aberto. */
  char aberto[16];
  if(app_de_jogo_aberto(aberto, sizeof aberto) == 1) {
    diario("youtube: %s nao aberto: %s esta aberto", tid, aberto);
    snprintf(chave, tam_chave, "app_aberto");
    snprintf(msg, tam_msg, "%s", aberto);
    return -1;
  }
  pthread_mutex_lock(&g_trava);
  for(int k = 0; k < g_n_apps; k++) {
    if(!strcmp(g_apps[k].title_id, tid) && g_apps[k].busca[0])
      snprintf(nome_busca, sizeof nome_busca, "%s", g_apps[k].busca);
  }
  pthread_mutex_unlock(&g_trava);
  if(maxd) snprintf(conteudo, sizeof conteudo, "%s\nvoltar=%s", texto, GLIBREN_TITLE_ID);
  else snprintf(conteudo, sizeof conteudo, "%s", texto);
  snprintf(pasta, sizeof pasta, "%s/%s", homebrew(), tid);
  snprintf(arquivo, sizeof arquivo, "%s/%s", pasta, nome_busca);
  if(gravar_texto(arquivo, conteudo)) {
    diario("youtube: nao gravou %s (errno %d)", arquivo, errno);
    snprintf(chave, tam_chave, "youtube");
    snprintf(msg, tam_msg, "nao foi possivel gravar a busca no app (%s)", strerror(errno));
    return -1;
  }
  reparar_permissoes(tid);
  diario("youtube: busca gravada em %s (%zu bytes%s); abrindo %s", arquivo, strlen(texto),
         maxd ? ", voltar=" GLIBREN_TITLE_ID : "", tid);
  int r = abrir_app(tid);
  if(r) {
    snprintf(chave, tam_chave, "youtube");
    snprintf(msg, tam_msg, "o PS5 nao abriu o app %s (0x%08x)", tid, (unsigned)r);
    return -1;
  }
  buf_str(json, "{\"ok\":true,\"app\":");
  buf_json(json, YOUTUBE[i].id);
  buf_str(json, ",\"title_id\":");
  buf_json(json, tid);
  buf_str(json, ",\"busca\":");
  buf_json(json, texto);
  if(maxd) {
    buf_str(json, ",\"voltar\":");
    buf_json(json, GLIBREN_TITLE_ID);
  }
  buf_str(json, "}");
  return 0;
}

int apps_youtube(const char *busca, buf_t *json, char *chave, size_t tam_chave, char *msg, size_t tam_msg) {
  char texto[MAX_BUSCA + 1];
  limpar_busca(busca, texto);
  if(!texto[0]) {
    snprintf(chave, tam_chave, "requisicao_invalida");
    snprintf(msg, tam_msg, "busca vazia");
    return -1;
  }
  int i = youtube_instalado(NULL);
  if(i < 0) {
    diario("youtube: nenhum app de YouTube instalado (ytps5 PPSA99350 / YouTube Max'd PPSA99991)");
    snprintf(chave, tam_chave, "sem_app_youtube");
    snprintf(msg, tam_msg, "nenhum app de YouTube instalado");
    return -1;
  }
  return youtube_abrir(i, texto, json, chave, tam_chave, msg, tam_msg);
}

int apps_youtube_maxd(const char *busca, buf_t *json, char *chave, size_t tam_chave, char *msg, size_t tam_msg) {
  char texto[MAX_BUSCA + 1];
  limpar_busca(busca ? busca : "", texto);   /* vazia vale: o Max'd abre na tela de busca */
  int i = youtube_instalado("PPSA99991");
  if(i < 0) {
    diario("youtube: YouTube Max'd (PPSA99991) nao instalado");
    snprintf(chave, tam_chave, "sem_maxd");
    snprintf(msg, tam_msg, "YouTube Max'd nao instalado");
    return -1;
  }
  return youtube_abrir(i, texto, json, chave, tam_chave, msg, tam_msg);
}
