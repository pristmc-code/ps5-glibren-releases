#!/bin/bash
# Teste de ponta a ponta do instalador de apps e do botao YouTube, com a versao de PC do payload:
# servidor local no lugar do GitHub (GLR_TESTE_BASE), chave de TESTE gerada na hora (GLR_TESTE_CHAVE - so no build de
# PC) e uma pasta homebrew de mentira (GLR_TESTE_HOMEBREW). Catalogo assinado por tools/publicar_app.py --teste.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_apps.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
T=$(mktemp -d /tmp/glr-apps.XXXXXX)
PORTA=8796; PORTA_SRV=8794
U="http://127.0.0.1:$PORTA"
BASE="http://127.0.0.1:$PORTA_SRV/"
HB=/root/glr-hb-teste; DADOS=/root/glr-dados-apps; SRV="$T/srv"; PORTA_SMP=8797
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
espera() {   # espera o trabalho de instalacao terminar
  for i in $(seq 1 120); do curl -s $U/api/apps | grep -q '"rodando":true' || return; sleep 0.25; done
}
trabalho() { curl -s $U/api/apps | python3 -c "import json,sys; t=json.load(sys.stdin)['trabalho']; print(t['fase'], '|', t['erro'])"; }
campo_app() { curl -s "$U/api/apps$2" | python3 -c "import json,sys; a=[x for x in json.load(sys.stdin)['apps'] if x['id']=='$1']; print(a[0]['$3'] if a else 'SEM_APP')"; }
rm -rf "$HB" "$DADOS"; mkdir -p "$HB" "$SRV"

# chave de teste (nunca a de verdade)
python3 -I - "$T" <<'EOF'
import sys
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
k = Ed25519PrivateKey.generate()
open(sys.argv[1] + "/chave.pem", "wb").write(k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
open(sys.argv[1] + "/chave.hex", "w").write(k.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex())
EOF
CHAVE_HEX=$(cat "$T/chave.hex")

# assina um apps.json escrito a mao (para entradas que o publicar_app.py recusaria)
assinar() { python3 -I - "$T/chave.pem" "$SRV/apps.json" <<'EOF'
import sys
from cryptography.hazmat.primitives import serialization
k = serialization.load_pem_private_key(open(sys.argv[1], "rb").read(), None)
open(sys.argv[2] + ".sig", "wb").write(k.sign(open(sys.argv[2], "rb").read()))
EOF
}
# zip de app: $1 = zip, $2 = title_id do param.json, $3 = conteudo de dados.txt, $4 = pasta de topo (opcional)
fazer_zip() { python3 -I - "$@" <<'EOF'
import sys, zipfile, os
z, tid, txt = sys.argv[1], sys.argv[2], sys.argv[3]
p = sys.argv[4] + "/" if len(sys.argv) > 4 and sys.argv[4] else ""
with zipfile.ZipFile(z, "w") as f:
    f.writestr(p + "eboot.bin", os.urandom(200000), compress_type=zipfile.ZIP_STORED)
    f.writestr(p + "sce_sys/param.json", '{"titleId":"%s","contentVersion":"01.000.000"}' % tid, compress_type=zipfile.ZIP_DEFLATED)
    f.writestr(p + "assets/dados.txt", txt * 1000, compress_type=zipfile.ZIP_DEFLATED)
    f.writestr(p + "yt-token.json", "token-do-zip (nao pode sobrescrever o do usuario)")
EOF
}
publicar() {   # $1 versao, $2 zip (dentro de $SRV)
  python3 -I "$ORIGEM/tools/publicar_app.py" --teste --chave "$T/chave.pem" --repo "$SRV" --id ytps5 --titulo "YouTube (ytps5)" \
    --title-id PPSA99350 --versao "$1" --zip "$SRV/$2" --url "$BASE$2" --preservar yt-token.json --busca glibren_busca.txt
}

(cd "$SRV" && exec python3 -m http.server $PORTA_SRV --bind 127.0.0.1) > "$T/srv.log" 2>&1 &
PID_SRV=$!
fazer_zip "$SRV/v1.zip" PPSA99350 "versao 1 "
confere "publicar_app.py: v1" "$(publicar 1.0-glibren1 v1.zip)" "ytps5 1.0-glibren1 (novo)"
confere "publicar_app.py recusa titleId errado" "$(fazer_zip "$SRV/errado.zip" PPSA00001 x; python3 -I "$ORIGEM/tools/publicar_app.py" --teste --chave "$T/chave.pem" --repo "$T/outro" --id x --titulo X --title-id PPSA99350 --versao 1 --zip "$SRV/errado.zip" --url ${BASE}errado.zip)" "titleId do param.json"
confere "publicar_app.py recusa o app oficial" "$(python3 -I "$ORIGEM/tools/publicar_app.py" --teste --chave "$T/chave.pem" --repo "$T/outro" --id x --titulo X --title-id PPSA01650 --versao 1 --zip "$SRV/v1.zip" --url https://github.com/x.zip)" "proibido"
confere "publicar_app.py exige a chave embutida" "$(python3 -I "$ORIGEM/tools/publicar_app.py" --chave "$T/chave.pem" --repo "$T/outro" --id x --titulo X --title-id PPSA99350 --versao 1 --zip "$SRV/v1.zip" --url https://github.com/x.zip)" "nao corresponde"

pkill -f "glibren-pc -p $PORTA" 2>/dev/null
: > "$T/abertos"; echo 0 > "$T/falhas"
GLR_TESTE_ABERTOS="$T/abertos" GLR_TESTE_SEGUNDO_MS=20 GLR_TESTE_LANCAR_FALHAS="$T/falhas" GLR_TESTE_BASE="$BASE" GLR_TESTE_CHAVE="$CHAVE_HEX" GLR_TESTE_HOMEBREW="$HB" GLR_TESTE_SMP_PORTA=$PORTA_SMP "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 &
PID=$!
sleep 1

echo "--- catalogo e instalacao"
r=$(curl -s "$U/api/apps?verificar=1")
confere "catalogo conferido"           "$r" '"catalogo":true'
confere "app no catalogo, nao instalado" "$r" '"id":"ytps5","titulo":"YouTube (ytps5)","title_id":"PPSA99350","versao":"1.0-glibren1"'
confere "nao instalado"                "$r" '"instalado":false'
confere "instalar sem X-GLR: 403"      "$(curl -s -o /dev/null -w '%{http_code}' -d id=ytps5 $U/api/apps/instalar)" "403"
confere "instalar app inexistente"     "$(post -d id=nada $U/api/apps/instalar)" "nao esta no catalogo"
confere "instalar v1"                  "$(post -d id=ytps5 $U/api/apps/instalar)" '"ok":true'
espera
confere "v1: pronto"                   "$(trabalho)" "^pronto"
confere "v1: eboot.bin"                "$(ls $HB/PPSA99350/eboot.bin)" "eboot.bin"
confere "v1: dados"                    "$(head -c 20 $HB/PPSA99350/assets/dados.txt)" "versao 1"
confere "v1: versao instalada"         "$(campo_app ytps5 '' versao_instalada)" "1.0-glibren1"
confere "v1: nada a atualizar"         "$(campo_app ytps5 '' atualizar)" "False"
confere "v1: zip baixado foi apagado"  "$(ls $DADOS/apps/ | wc -l)" "^0$"
modos() { find "$1" -exec stat -c '%a' {} + | sort -u | tr '\n' ' '; }
confere "v1: tudo 0777 (o PS5 so abre assim)" "$(modos $HB/PPSA99350)" "^777 $"
confere "v1: permissoes_ok"            "$(campo_app ytps5 '' permissoes_ok)" "True"

echo "--- reparo das permissoes (apps instalados pelo 0.8/0.8.1 com 0644)"
find $HB/PPSA99350 -type f -exec chmod 0644 {} +; find $HB/PPSA99350 -type d -exec chmod 0755 {} +
campo_app ytps5 '' permissoes_ok > /dev/null   # listar repara
confere "reparo: tudo 0777 de novo"    "$(modos $HB/PPSA99350)" "^777 $"
confere "reparo: no diario"            "$(grep -c 'PPSA99350: permissoes abertas' $DADOS/glibren.log)" "^1$"

echo "--- atualizacao (zip com pasta de topo) preservando o login"
echo "TOKEN-SECRETO-DO-USUARIO" > $HB/PPSA99350/yt-token.json
fazer_zip "$SRV/v2.zip" PPSA99350 "versao 2 " PPSA99350
publicar 2.0-glibren1 v2.zip > /dev/null
confere "v2: atualizacao disponivel"   "$(campo_app ytps5 '?verificar=1' atualizar)" "True"
confere "instalar v2"                  "$(post -d id=ytps5 $U/api/apps/instalar)" '"ok":true'
espera
confere "v2: pronto"                   "$(trabalho)" "^pronto"
confere "v2: dados novos"              "$(head -c 20 $HB/PPSA99350/assets/dados.txt)" "versao 2"
confere "v2: pasta de topo tirada"     "$(ls $HB/PPSA99350/eboot.bin && ls $HB/PPSA99350 | grep -c PPSA99350)" "^0$"
confere "v2: login preservado"         "$(cat $HB/PPSA99350/yt-token.json)" "TOKEN-SECRETO-DO-USUARIO"
confere "v2: sem pastas temporarias"   "$(ls $HB)" "^PPSA99350$"
confere "v2: versao instalada"         "$(campo_app ytps5 '' versao_instalada)" "2.0-glibren1"

echo "--- recusas (a instalacao atual fica intacta)"
cp "$SRV/apps.json.sig" "$T/sig.bom"
python3 -I -c "import sys; b=bytearray(open(sys.argv[1],'rb').read()); b[5]^=1; open(sys.argv[1],'wb').write(b)" "$SRV/apps.json.sig"
r=$(curl -s "$U/api/apps?verificar=1")
confere "assinatura errada: recusado"  "$r" '"catalogo":false,"erro":"assinatura do catalogo de apps invalida: recusado","apps":\[\]'
confere "assinatura errada: instalar recusado" "$(post -d id=ytps5 $U/api/apps/instalar)" "nao esta no catalogo"
cp "$T/sig.bom" "$SRV/apps.json.sig"
fazer_zip "$SRV/v3.zip" PPSA99350 "versao 3 "
publicar 3.0-glibren1 v3.zip > /dev/null
python3 -I -c "import sys; b=bytearray(open(sys.argv[1],'rb').read()); b[-30]^=1; open(sys.argv[1],'wb').write(b)" "$SRV/v3.zip"
curl -s "$U/api/apps?verificar=1" > /dev/null
post -d id=ytps5 $U/api/apps/instalar > /dev/null; espera
confere "sha errado: recusado"         "$(trabalho)" "^erro | SHA-256 do download nao confere"
confere "sha errado: v2 continua"      "$(head -c 20 $HB/PPSA99350/assets/dados.txt)" "versao 2"
confere "sha errado: .part apagado"    "$(ls $DADOS/apps/ | wc -l)" "^0$"
echo "x" >> "$SRV/v3.zip"
post -d id=ytps5 $U/api/apps/instalar > /dev/null; espera
confere "tamanho errado: recusado"     "$(trabalho)" "^erro | tamanho do download diferente"
# catalogo escrito a mao (assinado): titleId diferente, zip malicioso, app oficial e url fora da lista
fazer_zip "$SRV/outro.zip" PPSA00001 "outro "
python3 -I - "$SRV" > /dev/null <<'EOF'
import sys, zipfile, hashlib, json, os
s = sys.argv[1]
with zipfile.ZipFile(s + "/mal.zip", "w") as f:
    f.writestr("eboot.bin", "e")
    f.writestr("sce_sys/param.json", '{"titleId":"PPSA99991"}')
    f.writestr("../../fora.txt", "escapou")
def e(id, tid, z, url=None):
    d = open(s + "/" + z, "rb").read()
    return {"id": id, "titulo": id, "title_id": tid, "versao": "9", "url": url or "http://127.0.0.1:8794/" + z, "tamanho": len(d),
            "sha256": hashlib.sha256(d).hexdigest(), "preservar": [], "busca": "glibren_busca.txt"}
cat = {"apps": [e("trocado", "PPSA99992", "outro.zip"), e("youtube-maxd", "PPSA99991", "mal.zip"), e("oficial", "PPSA01650", "outro.zip"),
                e("fora", "PPSA99993", "outro.zip", "https://example.com/x.zip"), {"id": "lixo"}]}
open(s + "/apps.json", "w").write(json.dumps(cat))
EOF
assinar
r=$(curl -s "$U/api/apps?verificar=1")
confere "catalogo a mao: aceitos so os validos" "$(echo "$r" | python3 -c "import json,sys; print(sorted(a['id'] for a in json.load(sys.stdin)['apps']))")" "\['trocado', 'youtube-maxd'\]"
confere "app oficial do YouTube ignorado" "$(grep -c 'entrada do catalogo invalida' $DADOS/glibren.log)" "^3$"
post -d id=trocado $U/api/apps/instalar > /dev/null; espera
confere "titleId diferente: recusado"  "$(trabalho)" "titleId do param.json (PPSA00001) diferente do catalogo (PPSA99992)"
post -d id=youtube-maxd $U/api/apps/instalar > /dev/null; espera
confere "zip com ../: recusado"        "$(trabalho)" "zip recusado: nome perigoso no zip: ../../fora.txt"
confere "zip com ../: nada fora"       "$(ls $HB/../fora.txt $DADOS/fora.txt /root/fora.txt 2>&1 | grep -c 'No such')" "3"
confere "zip com ../: nao instalou"    "$(ls $HB)" "^PPSA99350$"

echo "--- botao YouTube"
confere "youtube sem X-GLR: 403"       "$(curl -s -o /dev/null -w '%{http_code}' --data-urlencode 'busca=x' $U/api/youtube)" "403"
r=$(post --data-urlencode $'busca=  God of War\r\nRagnarok\x01 gameplay  ' $U/api/youtube)
confere "youtube: ok com ytps5"        "$r" '"ok":true,"app":"ytps5","title_id":"PPSA99350"'
confere "youtube: arquivo de busca"    "[$(cat $HB/PPSA99350/glibren_busca.txt)]" "^\[God of War Ragnarok gameplay\]$"
confere "youtube: uma linha, sem \\n"  "$(tr -cd '\n\r' < $HB/PPSA99350/glibren_busca.txt | wc -c)" "^0$"
confere "youtube: sem .tmp"            "$(ls $HB/PPSA99350 | grep -c tmp)" "^0$"
confere "youtube: diario (PC)"         "$(grep 'abriria o app' $DADOS/glibren.log | tail -1)" "abriria o app PPSA99350"
LONGA=$(python3 -c "print('ação ' * 80)")
post --data-urlencode "busca=$LONGA" $U/api/youtube > /dev/null
confere "youtube: ate 200 bytes, UTF-8 inteiro" "$(python3 -c "import sys; d=open(sys.argv[1],'rb').read(); d.decode('utf-8'); print(len(d) <= 200, len(d) > 190)" $HB/PPSA99350/glibren_busca.txt)" "True True"
confere "youtube: busca vazia"         "$(post --data-urlencode 'busca=   ' $U/api/youtube)" "busca vazia"
mkdir -p $HB/PPSA99991; echo e > $HB/PPSA99991/eboot.bin
confere "youtube: prefere o ytps5"     "$(post --data-urlencode 'busca=x' $U/api/youtube)" '"app":"ytps5"'
mv $HB/PPSA99350 $HB/guardado
confere "youtube: usa o Max'd sem o ytps5" "$(post --data-urlencode 'busca=x' $U/api/youtube)" '"app":"youtube-maxd","title_id":"PPSA99991"'
rm -rf $HB/PPSA99991
confere "youtube: sem app instalado"   "$(post --data-urlencode 'busca=x' $U/api/youtube)" '"chave":"sem_app_youtube"'
mkdir -p $HB/PPSA01650; echo e > $HB/PPSA01650/eboot.bin
confere "youtube: nunca o oficial"     "$(post --data-urlencode 'busca=x' $U/api/youtube)" '"chave":"sem_app_youtube"'

echo "--- acao YouTube (Max'd) com voltar= o glibren"
confere "maxd sem X-GLR: 403"          "$(curl -s -o /dev/null -w '%{http_code}' -d busca=x $U/api/youtube/maxd)" "403"
confere "maxd nao instalado"           "$(post -d busca=x $U/api/youtube/maxd)" '"chave":"sem_maxd"'
mkdir -p $HB/PPSA99991; echo e > $HB/PPSA99991/eboot.bin
r=$(post --data-urlencode 'busca=' $U/api/youtube/maxd)
confere "maxd: busca vazia aceita"     "$r" '"ok":true,"app":"youtube-maxd","title_id":"PPSA99991","busca":"","voltar":"PMGL00001"'
confere "maxd: arquivo (vazia)"        "$(python3 -c "import sys; print(open(sys.argv[1],'rb').read().decode().replace(chr(10),'|'))" $HB/PPSA99991/glibren_busca.txt)" "^|voltar=PMGL00001$"
post --data-urlencode $'busca=  lofi\r\nhip hop ' $U/api/youtube/maxd > /dev/null
confere "maxd: arquivo (com busca)"    "$(python3 -c "import sys; print(open(sys.argv[1],'rb').read().decode().replace(chr(10),'|'))" $HB/PPSA99991/glibren_busca.txt)" "^lofi hip hop|voltar=PMGL00001$"
confere "maxd: diario (PC)"            "$(grep 'abriria o app' $DADOS/glibren.log | tail -1)" "abriria o app PPSA99991"
post --data-urlencode 'busca=God of War gameplay' $U/api/youtube > /dev/null
confere "botao do jogo com Max'd: 2 linhas" "$(python3 -c "import sys; print(open(sys.argv[1],'rb').read().decode().replace(chr(10),'|'))" $HB/PPSA99991/glibren_busca.txt)" "^God of War gameplay|voltar=PMGL00001$"
mv $HB/guardado $HB/PPSA99350
post --data-urlencode 'busca=x' $U/api/youtube/maxd > /dev/null
confere "maxd mesmo com o ytps5"       "$(grep 'abriria o app' $DADOS/glibren.log | tail -1)" "abriria o app PPSA99991"
confere "ytps5 continua com 1 linha"   "$(post --data-urlencode 'busca=abc' $U/api/youtube > /dev/null; python3 -c "import sys; print(open(sys.argv[1],'rb').read().decode().replace(chr(10),'|'))" $HB/PPSA99350/glibren_busca.txt)" "^abc$"
rm -rf $HB/PPSA99991; mv $HB/PPSA99350 $HB/guardado

echo "--- POST /launch (so do proprio PS5)"
lanca() { curl -s -H 'Content-Type: application/json' "$@"; }
confere "launch: Max'd"                "$(lanca -d '{"title":"PPSA99991"}' $U/launch)" '^{"ok":true,"title":"PPSA99991"}$'
confere "launch: diario"               "$(grep 'abriria o app' $DADOS/glibren.log | tail -1)" "abriria o app PPSA99991"
confere "launch: glibren"              "$(lanca -d '{ "title" : "PMGL00001" }' $U/launch)" '"ok":true,"title":"PMGL00001"'
confere "launch: Jobe"                 "$(lanca -d '{"title":"PPSA99471"}' http://localhost:$PORTA/launch)" '"ok":true'
confere "launch: ytps5"                "$(lanca -d '{"title":"PPSA99350"}' $U/launch)" '"ok":true'
confere "launch: fora da lista"        "$(lanca -o /dev/null -w '%{http_code}' -d '{"title":"PPSA01650"}' $U/launch)" "^403$"
confere "launch: fora da lista (diario)" "$(grep -c 'launch: PPSA01650 recusado' $DADOS/glibren.log)" "^1$"
confere "launch: sem JSON (form)"      "$(curl -s -o /dev/null -w '%{http_code}' -H 'Content-Type: text/plain' -d '{"title":"PPSA99991"}' $U/launch)" "^415$"
confere "launch: urlencoded"           "$(curl -s -o /dev/null -w '%{http_code}' -d 'title=PPSA99991' $U/launch)" "^415$"
confere "launch: title invalido"       "$(lanca -o /dev/null -w '%{http_code}' -d '{"title":"ppsa99991"}' $U/launch)" "^400$"
confere "launch: sem title"            "$(lanca -o /dev/null -w '%{http_code}' -d '{}' $U/launch)" "^400$"
confere "launch: title longo"          "$(lanca -o /dev/null -w '%{http_code}' -d '{"title":"PPSA999911"}' $U/launch)" "^400$"
confere "launch: Host de outro site"   "$(lanca -o /dev/null -w '%{http_code}' -H 'Host: evil.example:8765' -d '{"title":"PPSA99991"}' $U/launch)" "^403$"
confere "launch: GET"                  "$(curl -s -o /dev/null -w '%{http_code}' $U/launch)" "^404$"
IP_REDE=$(hostname -I | awk '{print $1}')
if [ -n "$IP_REDE" ]; then
  confere "launch: da rede (nao 127.x)" "$(lanca -o /dev/null -w '%{http_code}' -H 'Host: 127.0.0.1' -d '{"title":"PPSA99991"}' http://$IP_REDE:$PORTA/launch)" "^403$"
fi

echo "--- nunca abrir por cima de outro app de jogo"
mkdir -p $HB/PPSA99991; echo e > $HB/PPSA99991/eboot.bin; echo marca > $HB/PPSA99991/glibren_busca.txt
echo PPSA99471 > $T/abertos
r=$(post -d busca=x $U/api/youtube/maxd)
confere "maxd com a Jobe aberta: app_aberto" "$r" '"chave":"app_aberto"'
confere "maxd com a Jobe aberta: diz qual"   "$r" '"nome":"PPSA99471"'
confere "maxd com a Jobe aberta: nao gravou" "$(cat $HB/PPSA99991/glibren_busca.txt)" "^marca$"
confere "youtube do jogo com app aberto"     "$(post -d busca=x $U/api/youtube)" '"chave":"app_aberto"'
echo PMGL00001 > $T/abertos
confere "pagina do glibren nao conta"        "$(post -d busca=x $U/api/youtube/maxd)" '"ok":true'
echo PPSA99471 > $T/abertos
r=$(curl -s -w ' %{http_code}' -H 'Content-Type: application/json' -d '{"title":"PPSA99991"}' $U/launch)
confere "launch sem from com app aberto: 409" "$r" '"error":"app_aberto".*"open":"PPSA99471".* 409$'
confere "launch: from invalido"               "$(curl -s -o /dev/null -w '%{http_code}' -H 'Content-Type: application/json' -d '{"title":"PMGL00001","from":"x"}' $U/launch)" "^400$"
rm -rf $HB/PPSA99991

echo "--- launch com from (espera fechar, ~15 s, 4 tentativas; 1 s = 20 ms no teste)"
lanca() { curl -s -H 'Content-Type: application/json' "$@"; }
estado() { curl -s $U/api/launch | python3 -c "import json,sys; print(json.load(sys.stdin)['estado'])"; }
abriu() { grep -c "abriria o app $1" $DADOS/glibren.log; }
echo PPSA99991 > $T/abertos
antes=$(abriu PMGL00001)
confere "from: pendente"            "$(lanca -d '{"title":"PMGL00001","from":"PPSA99991"}' $U/launch)" '^{"ok":true,"pending":true,"title":"PMGL00001","from":"PPSA99991"}$'
sleep 0.6
confere "from aberto: esperando"    "$(estado)" "^esperando$"
confere "from aberto: nao lancou"   "$(abriu PMGL00001)" "^$antes$"
: > $T/abertos
sleep 1
confere "from fechou: abriu"        "$(estado) $(abriu PMGL00001)" "^aberto $((antes+1))$"
confere "from fechou: diario"       "$(grep -c 'launch: PPSA99991 fechou' $DADOS/glibren.log)" "^1$"
echo 2 > $T/falhas
lanca -d '{"title":"PPSA99471","from":"PPSA99991"}' $U/launch > /dev/null
sleep 1.5
confere "2 falhas: abriu na 3a"     "$(estado) $(grep -c 'falha simulada ao abrir PPSA99471' $DADOS/glibren.log) $(grep 'tentativa 3 de abrir PPSA99471' $DADOS/glibren.log | grep -c 0x00000000)" "^aberto 2 1$"
echo 9 > $T/falhas
lanca -d '{"title":"PPSA99350","from":"PPSA99991"}' $U/launch > /dev/null
sleep 1.8
confere "4 falhas: desiste"         "$(estado) $(grep -c 'tentativa [1-4] de abrir PPSA99350 -> 0x80940011' $DADOS/glibren.log)" "^falhou 4$"
confere "4 falhas: diario"          "$(grep -c 'desistiu de abrir PPSA99350 depois de 4' $DADOS/glibren.log)" "^1$"
echo 0 > $T/falhas
echo PPSA99991 > $T/abertos
lanca -d '{"title":"PMGL00001","from":"PPSA99991"}' $U/launch > /dev/null
sleep 3
confere "from nao fecha em 2 min: desiste" "$(estado) $(grep -c 'PPSA99991 nao fechou em 120 s' $DADOS/glibren.log)" "^desistiu 1$"
antes=$(abriu PMGL00001)
lanca -d '{"title":"PMGL00001","from":"PPSA99991"}' $U/launch > /dev/null
sleep 0.3
lanca -d '{"title":"PPSA99350","from":"PPSA99471"}' $U/launch > /dev/null
sleep 0.2
: > $T/abertos
sleep 1
confere "pedido novo substitui"     "$(estado) $(abriu PMGL00001) $(grep -c 'pedido anterior (PMGL00001) substituido' $DADOS/glibren.log)" "^aberto $antes 1$"
confere "pedido novo: abriu o novo" "$(grep 'abriria o app' $DADOS/glibren.log | tail -1)" "PPSA99350"
echo PPSA99471 > $T/abertos
lanca -d '{"title":"PMGL00001","from":"PPSA99991"}' $U/launch > /dev/null
sleep 1.6
confere "outro app aberto na hora: nao lanca" "$(grep -c 'PPSA99471 esta aberto - nao lancou PMGL00001' $DADOS/glibren.log)" "^4$"
: > $T/abertos

echo "--- botao YouTube repara as permissoes antes de abrir"
mv $HB/guardado $HB/PPSA99350
chmod 0644 $HB/PPSA99350/eboot.bin
post --data-urlencode 'busca=x' $U/api/youtube > /dev/null
confere "youtube: eboot.bin 0777"      "$(stat -c %a $HB/PPSA99350/eboot.bin)" "^777$"

echo "--- desinstalar"
# ShadowMountPlus de mentira: responde conforme $T/smp_modo (ok | ativo | erro) e anota cada pedido
python3 -I - "$PORTA_SMP" "$T" > /dev/null 2>&1 <<'EOF' &
import sys, json, http.server
porta, pasta = int(sys.argv[1]), sys.argv[2]
class H(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        corpo = self.rfile.read(int(self.headers["Content-Length"]))
        open(pasta + "/smp_pedidos", "a").write(self.path + " " + corpo.decode() + "\n")
        modo = open(pasta + "/smp_modo").read().strip()
        r = {"ok": (200, {"status": 0, "scan_queued": False}),
             "ativo": (409, {"status": 16, "error": "Title is running", "error_reason": "game_active"}),
             "erro": (409, {"status": 16, "error": "Mutation gate busy", "error_reason": "mutation_busy"})}[modo]
        d = json.dumps(r[1]).encode()
        self.send_response(r[0]); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(d))); self.end_headers(); self.wfile.write(d)
    def log_message(self, *a): pass
http.server.HTTPServer(("127.0.0.1", porta), H).serve_forever()
EOF
PID_SMP=$!
sleep 0.5
curl -s "$U/api/apps?verificar=1" > /dev/null
publicar 2.0-glibren1 v2.zip > /dev/null; curl -s "$U/api/apps?verificar=1" > /dev/null
confere "desinstalar sem X-GLR: 403"   "$(curl -s -o /dev/null -w '%{http_code}' -d id=ytps5 $U/api/apps/desinstalar)" "403"
confere "desinstalar fora do catalogo" "$(post -d id=nada $U/api/apps/desinstalar)" "nao esta no catalogo"
echo ativo > $T/smp_modo
confere "desinstalar: app aberto"      "$(post -d id=ytps5 $U/api/apps/desinstalar)" '"ok":true'
espera
confere "app aberto: recusado"         "$(trabalho)" "^erro | o app esta aberto"
confere "app aberto: pasta intacta"    "$(ls $HB/PPSA99350/eboot.bin)" "eboot.bin"
echo ok > $T/smp_modo
confere "desinstalar: iniciou"         "$(post -d id=ytps5 $U/api/apps/desinstalar)" '"ok":true'
espera
confere "desinstalado"                 "$(trabalho)" "^desinstalado"
confere "pedido ao ShadowMountPlus"    "$(tail -1 $T/smp_pedidos)" '^/api/v1/games/uninstall {"title_id":"PPSA99350"}$'
confere "pasta apagada (e sem sobras)" "$(ls $HB | grep -c PPSA99350)" "^0$"
confere "nao instalado"                "$(campo_app ytps5 '' instalado)" "False"
confere "desinstalar de novo: recusado" "$(post -d id=ytps5 $U/api/apps/desinstalar)" "nao esta instalado"
post -d id=ytps5 $U/api/apps/instalar > /dev/null; espera
echo erro > $T/smp_modo; : > $T/smp_pedidos
post -d id=ytps5 $U/api/apps/desinstalar > /dev/null; espera
confere "ShadowMountPlus ocupado: apaga e pede de novo" "$(trabalho) $(wc -l < $T/smp_pedidos)" "^desinstalado .* 2$"
confere "ShadowMountPlus ocupado: aviso" "$(curl -s $U/api/apps | python3 -c "import json,sys; print(json.load(sys.stdin)['trabalho']['aviso'])")" "mutation_busy"
kill $PID_SMP; wait $PID_SMP 2>/dev/null
post -d id=ytps5 $U/api/apps/instalar > /dev/null; espera
post -d id=ytps5 $U/api/apps/desinstalar > /dev/null; espera
confere "sem ShadowMountPlus: apaga e avisa" "$(trabalho) $(curl -s $U/api/apps | python3 -c "import json,sys; print(json.load(sys.stdin)['trabalho']['aviso'])")" "^desinstalado .*nao respondeu"
confere "sem ShadowMountPlus: pasta apagada" "$(ls $HB | grep -c PPSA99350)" "^0$"

echo "--- diagnostico"
confere "catalogo traz a hora do PS5"  "$(curl -s $U/api/apps | python3 -c "import json,sys,time; print(abs(json.load(sys.stdin)['agora'] - time.time()) < 5)")" "True"
confere "/app-log: hora e aviso sem yt.log" "$(curl -s "$U/app-log?id=ytps5")" "Hora do PS5: .*UTC"
confere "/app-log do Max'd: sem arquivo" "$(curl -s "$U/app-log?id=youtube-maxd")" "Bug-report export"

echo "--- versao gravada pela atualizacao assume ao iniciar (o autoloader manda a antiga)"
kill $PID 2>/dev/null; wait $PID 2>/dev/null
gravar_elf() {   # $1 versao no marcador, $2 = "ruim" para assinatura invalida
  python3 -I - "$T/chave.pem" "$DADOS/glibren.elf" "$1" "${2:-}" <<'EOF'
import sys, os
from cryptography.hazmat.primitives import serialization
k = serialization.load_pem_private_key(open(sys.argv[1], "rb").read(), None)
d = os.urandom(5000) + b"GLIBREN-VERSAO:\0" + os.urandom(100) + b"GLIBREN-VERSAO:" + sys.argv[3].encode() + b"\n" + os.urandom(5000)
open(sys.argv[2], "wb").write(d)
s = k.sign(d)
if sys.argv[4]: s = bytes([s[0] ^ 1]) + s[1:]
open(sys.argv[2] + ".sig", "wb").write(s)
EOF
}
inicia() { GLR_TESTE_BASE="$BASE" GLR_TESTE_CHAVE="$CHAVE_HEX" GLR_TESTE_HOMEBREW="$HB" "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1; kill $PID; wait $PID 2>/dev/null; }
gravar_elf 9.9.9; inicia
confere "gravada mais nova: passa a vez" "$(grep -c 'passaria a vez para a 9.9.9' $DADOS/glibren.log)" "^1$"
gravar_elf 0.1.0; inicia
confere "gravada mais velha: fica"      "$(grep -c 'passaria a vez para a 0.1.0' $DADOS/glibren.log)" "^0$"
gravar_elf 9.9.8 ruim; inicia
confere "assinatura invalida: fica"     "$(grep -c '9.9.8\|assinatura invalida - ignorado' $DADOS/glibren.log)" "^1$"
touch $DADOS/passou_a_vez; gravar_elf 9.9.7; inicia
confere "trava: nao passa duas vezes"   "$(grep -c 'passaria a vez para a 9.9.7' $DADOS/glibren.log) $(ls $DADOS/passou_a_vez 2>&1 | grep -c 'No such')" "^0 1$"
rm -f $DADOS/glibren.elf $DADOS/glibren.elf.sig

kill $PID $PID_SRV 2>/dev/null
wait 2>/dev/null
rm -rf "$T" "$HB"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
