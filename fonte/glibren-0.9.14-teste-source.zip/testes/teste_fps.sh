#!/bin/bash
# Testa o FPS do jogo aberto (0.9.14, teste) na versao de PC: o contador da tela e simulado (GLR_TESTE_FPS quadros por
# segundo), o jogo "aberto" vem de GLR_TESTE_ABERTOS e o nome de um param.json em GLR_TESTE_APPMETA.
# Confere: rota e pagina respondem; FPS simulado (60 e 30); jogo de PS5 com nome, media e minimo; menu sem media; jogo
# de PS4 sem medicao; troca de jogo; erro ao abrir o /dev/dce; recusa pelo User-Agent do PS5 (sem ligar a leitura);
# Host estranho recusado; e a leitura que para sozinha sem pedidos e volta no proximo pedido.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_fps.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8788
U="http://127.0.0.1:$PORTA"
T=/root/glr-fps; DADOS=$T/dados
UA_PS5='Mozilla/5.0 (PlayStation; PlayStation 5/12.00) AppleWebKit/605.1.15 (KHTML, like Gecko)'
UA_CEL='Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Mobile Safari/537.36'
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
# campo numerico do JSON entre min e max
faixa() {
  local v
  v=$(echo "$2" | python3 -c "import json,sys; print(json.load(sys.stdin).get('$3'))" 2>/dev/null)
  if python3 -c "import sys; v=float('$v'); sys.exit(0 if $4 <= v <= $5 else 1)" 2>/dev/null; then ok=$((ok+1)); echo "OK   $1 ($3=$v)"
  else falhas=$((falhas+1)); echo "FALHA $1: $3=$v (esperado $4..$5)"; fi
}
codigo() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
fps() { curl -s -A "$UA_CEL" "$U/api/fps${1:-}"; }
rm -rf "$T"; mkdir -p "$DADOS" "$T/appmeta/PPSA01234" "$T/appmeta/CUSA00001"
printf 'language = pt-BR\n' > "$DADOS/config.ini"
cat > "$T/appmeta/PPSA01234/param.json" <<'JSON'
{"titleId":"PPSA01234","localizedParameters":{"defaultLanguage":"en-US","en-US":{"titleName":"Jogo de Teste"},"pt-BR":{"titleName":"Jogo de Teste BR"}}}
JSON
: > "$T/abertos"
inicia() { env GLR_TESTE_ABERTOS="$T/abertos" GLR_TESTE_APPMETA="$T/appmeta" "$@" "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }

echo "--- rota, pagina e recusa do PS5"
inicia GLR_TESTE_FPS=60 GLR_TESTE_FPS_PARAR_S=5
confere "PS5: pagina recusada"       "$(codigo -A "$UA_PS5" $U/fps)" "403"
confere "PS5: api recusada"          "$(codigo -A "$UA_PS5" $U/api/fps)" "403"
confere "PS5 (caixa baixa): recusada" "$(codigo -A 'mozilla playstation 5' $U/api/fps)" "403"
confere "PS5: mensagem"              "$(curl -s -A "$UA_PS5" $U/fps)" "so para o celular ou o PC"
if grep -q "fps: leitura ligada" "$DADOS/glibren.log" 2>/dev/null; then falhas=$((falhas+1)); echo "FALHA PS5 ligou a leitura"; else ok=$((ok+1)); echo "OK   PS5 nao ligou a leitura"; fi
confere "Host estranho recusado"     "$(codigo -A "$UA_CEL" -H 'Host: ataque.example.com' $U/api/fps)" "403"
confere "celular: pagina"            "$(curl -s -A "$UA_CEL" $U/fps)" "FPS do jogo"
confere "pagina sem User-Agent"      "$(codigo -A '' $U/fps)" "200"
R=$(fps)
confere "primeiro pedido liga"       "$R" '"lendo":true'
confere "simulado no PC"             "$R" '"simulado":true'
confere "primeira leitura"           "$R" '"leituras":1'
sleep 3
R=$(fps "?historico=1")
confere "medindo"                    "$R" '"situacao":"medindo"'
faixa   "menu: ~60 FPS"              "$R" fps 57 63
confere "menu: tipo"                 "$R" '"tipo":"menu"'
confere "menu: sem media"            "$R" '"media":-1'
confere "historico"                  "$R" '"historico":\[[0-9]'
confere "variante normal"            "$R" '"variante":"normal"'
confere "diario: ligada"             "$(cat $DADOS/glibren.log)" "fps: leitura ligada"

echo "--- jogo de PS5 aberto, troca de jogo e PS4"
echo PPSA01234 > "$T/abertos"
sleep 3
R=$(fps)
confere "jogo: tid"                  "$R" '"tid":"PPSA01234"'
confere "jogo: nome (idioma)"        "$R" '"nome":"Jogo de Teste BR"'
confere "jogo: tipo"                 "$R" '"tipo":"ps5"'
sleep 2
R=$(fps)
faixa   "jogo: media ~60"            "$R" media 57 63
faixa   "jogo: minimo ~60"           "$R" minimo 55 63
faixa   "jogo: segundos"             "$R" segundos 1 10
confere "diario: jogo aberto"        "$(cat $DADOS/glibren.log)" "fps: aberto agora: PPSA01234 (ps5) - Jogo de Teste BR"
echo CUSA00001 > "$T/abertos"
sleep 3
R=$(fps)
confere "PS4: sem medicao"           "$R" '"situacao":"ps4"'
confere "PS4: fps -1"                "$R" '"fps":-1'
confere "PS4: tid"                   "$R" '"tid":"CUSA00001"'
: > "$T/abertos"

echo "--- para sozinha sem pedidos e volta"
sleep 7   # prazo de teste: 5 s
confere "diario: parada"             "$(cat $DADOS/glibren.log)" "fps: leitura parada (sem pedidos ha 5 s"
R=$(fps)
confere "volta no proximo pedido"    "$R" '"leituras":2'
confere "volta lendo"                "$R" '"lendo":true'
sleep 1.5
R=$(fps)
confere "segue a mesma leitura"      "$R" '"leituras":2'
para

echo "--- jogo travado em 30"
echo PPSA01234 > "$T/abertos"
inicia GLR_TESTE_FPS=30
fps > /dev/null; sleep 4
R=$(fps)
faixa   "30 FPS"                     "$R" fps 28 32
faixa   "30 FPS: media"              "$R" media 28 32
confere "prazo padrao 10 s"          "$R" '"parar_s":10'
para

echo "--- erro ao abrir o /dev/dce"
inicia GLR_TESTE_FPS_ERRO=13
fps > /dev/null; sleep 1.5
R=$(fps)
confere "erro: situacao"             "$R" '"situacao":"erro"'
confere "erro: errno"                "$R" '"errno":13'
confere "erro: mensagem"             "$R" 'nao abriu /dev/dce: Permission denied (errno 13)'
confere "erro: no diario"            "$(cat $DADOS/glibren.log)" "fps: nao abriu /dev/dce: Permission denied (errno 13)"
para

rm -rf "$T"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
