/* Game Library Renamer (payload PS5) - temperatura do SSD NVMe ligado por gaveta USB (teste).
   So le quando o usuario pede (botao na pagina Temperatura). Comandos de leitura apenas: INQUIRY e o repasse NVMe do
   chip Realtek RTL9210 (Identify + log SMART). Guarda o ultimo resultado e escreve o diagnostico no log. */
#pragma once

#include "util.h"

/* Le agora (alguns segundos no maximo) e guarda o resultado. */
void usb_temp_ler(void);
/* "usb_temp":{...} (sem chaves em volta) com o ultimo resultado */
void usb_temp_json(buf_t *b);
