/* Game Library Renamer (payload PS5) - 0.9.64: bateria automatica de testes. Ver bateria.h e
   ps5/contribuicoes/DESENHO-GL-0964-BATERIA.md. Nada disto foi testado no PS5 (so no PC, com os servicos falsos). */
#include "bateria.h"

#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <math.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <time.h>
#include <unistd.h>

#ifdef __PROSPERO__
#include <sys/sysctl.h>
#endif

#include "ampr_ajuste.h"
#include "ampr_teste.h"
#include "api.h"
#include "apps.h"
#include "arquivos.h"
#include "backup.h"
#include "config.h"
#include "diagnostico.h"
#include "discos.h"
#include "fps.h"
#include "https.h"
#include "json_min.h"
#include "lancador.h"
#include "pad_virtual.h"
#include "payloads.h"
#include "plataforma.h"
#include "primeiro_plano.h"
#include "sha256.h"
#include "sk_pastas.h"
#include "tarefas.h"
#include "termico.h"

#ifdef __PROSPERO__
/* 0.9.64: SO a bateria usa (excecao autorizada pelo dono a regra "nunca KillApp"; ver bateria.h). weak: firmware sem a
   funcao = NULL (tratado). Assinaturas do codigo aberto ps5-controllers/close.c (evo). */
int sceLncUtilKillApp(uint32_t app_id) __attribute__((weak));
int sceSystemServiceKillApp(int app_id, int a, int b, int c) __attribute__((weak));
#endif

#define PLANO_CAMINHO "/repos/pristmc-code/ps5-diagnosticos/contents/glibren/ampr-bateria.json"
#define PLANO_MAX (256u * 1024)
#define MAX_RODADAS 60
#define MAX_JOGOS 16
#define MAX_VERSOES 8
#define MAX_AJ 16
#define MAX_BOTOES 24
#define TAM_C 600
#define MIB (1024.0 * 1024.0)
#define AMOSTRAS_MAX 64

/* ================================================================== plano */

typedef struct {
  char nome[24];
  char caminho[TAM_C];    /* onde fica GUARDADA (pasta secundaria) */
} versao_t;

typedef struct {
  char tid[16], nome[96], ativa[TAM_C];
  versao_t v[MAX_VERSOES];
  int nv;
} jogo_t;

typedef struct {
  char id[32];
  int jogo, versao;            /* indices */
  char ampr[128];              /* "manter" | "embutido" | nome do .sprx em <dados>/ampr-builds/ */
  int aj_objeto;               /* 0 = padrao (apaga o arquivo de ajustes), 1 = os pares abaixo */
  char aj_nomes[MAX_AJ][AMPR_AJ_NOME + 1];
  long long aj_vals[MAX_AJ];
  int naj;
  int compat;                  /* tipo "compat": so abre, espera e fecha */
  int carregar_max_s, trecho_s, repeticoes, esfriar_s;
  char nota[120];
} rodada_t;

typedef struct {
  int carregar_max_s, trecho_s, repeticoes, esfriar_s, fps, temp_max_c, esfriar_ate_c;
  int sk_espera_s, prep_parado_s, fechar_espera_s, fechar_pad_espera_s, compat_s, espera_dono_s, esfriar_extra_s,
      espera_temp_s, sk_fora_s, desmontar_espera_s;
  double calmo_mib_s, pico_mib;
  int janela_s, fps_min, fps_desvio_pct, min_tela_s, sem9090_s, amostra_s, exigir_foco;
  int livre_min_mib, folga_pkg_pct, quedas_seguidas, reabrir_proxima;
  int fechar_metodo;           /* 0 = controle virtual e depois KillApp, 1 = so KillApp */
  char fechar[MAX_BOTOES][24];
  int nfechar;
  char inicio[MAX_BOTOES][24];
  int ninicio;
  int pad_repouso_ms, botao_ms, botao_depois_ms;
} cfg_t;

typedef struct {
  int versao_plano;
  char id[48], titulo[160], sha256[65];
  cfg_t cfg;
  jogo_t jogos[MAX_JOGOS];
  int nj;
  rodada_t r[MAX_RODADAS];
  int nr;
  long long estimativa_s;
} plano_t;

static plano_t g_plano;             /* o plano em uso (so a thread da bateria e o conferir mexem; g_trava_plano) */
static pthread_mutex_t g_trava_plano = PTHREAD_MUTEX_INITIALIZER;

/* ================================================================== estado */

static struct {
  char estado[16];      /* parado, rodando, pausando, pausado, parando, desfazendo, concluida, interrompida, erro */
  char passo[16];
  long long desde;      /* time() do passo */
  int rodada, rep;      /* atuais (0..) */
  char msg[300], erro[300];
  char plano_id[48], plano_sha[65];
  long long boot, iniciado;
  int cancelar, pausar, rodando_thread;
  char aberto_bat[16];  /* titulo que a bateria abriu (para fechar so ele) */
  char ampr_original[12];   /* "", "embutido", "arquivo" */
  int ampr_mexeu, tune_mexeu;
  char tune_original[8];    /* "", "sim", "nao" */
  int quedas_seguidas;
  double t_tela, t_carregado;
  char carregar[160];
  char problemas[2400];
  char envio[300];
  char relatorio[200];
  long long buscado;
  char plano_erro[300];
  int plano_ok;
  buf_t conferencia;    /* JSON (array de linhas) do ultimo conferir */
  int conferencia_ok;
  int interrompida;      /* o desfazer depois de um reinicio termina em "interrompida" (Iniciar continua) */
} g = {.estado = "parado", .t_tela = -1, .t_carregado = -1};
static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t g_sinal = PTHREAD_COND_INITIALIZER;

/* ------------------------------------------------------------------ tempo e caminhos */

static long long agora_ms(void) {
  struct timespec t;
  clock_gettime(CLOCK_MONOTONIC, &t);
  return (long long)t.tv_sec * 1000 + t.tv_nsec / 1000000;
}

static long seg_ms(void) {
#ifndef __PROSPERO__
  const char *s = getenv("GLR_TESTE_SEGUNDO_MS");
  if(s && atol(s) > 0) return atol(s);
#endif
  return 1000;
}

static void pasta_bat(char *s, size_t t) { snprintf(s, t, "%s/bateria", g_pasta_dados); }
static void arq_bat(char *s, size_t t, const char *nome) { snprintf(s, t, "%s/bateria/%s", g_pasta_dados, nome); }
static void pasta_builds(char *s, size_t t) { snprintf(s, t, "%s/ampr-builds", g_pasta_dados); }

/* Hora em que o PS5 ligou (kern.boottime); muda a cada boot. PC: GLR_TESTE_BOOT ou relogio - monotonico. */
static long long boot_atual(void) {
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_BOOT")) return atoll(getenv("GLR_TESTE_BOOT"));
#else
  struct timeval boot;
  size_t tam = sizeof boot;
  if(!sysctlbyname("kern.boottime", &boot, &tam, NULL, 0) && boot.tv_sec > 0) return (long long)boot.tv_sec;
#endif
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (long long)time(NULL) - ts.tv_sec;
}

static int mesmo_boot(long long a, long long b) { return a && b && llabs(a - b) <= 5; }

static void sem_barra(char *c) {
  size_t n = strlen(c);
  while(n > 1 && c[n - 1] == '/') c[--n] = 0;
}

static const char *base_de(const char *c) {
  const char *b = strrchr(c, '/');
  return b ? b + 1 : c;
}

static void pai_de(const char *c, char *s, size_t t) {
  snprintf(s, t, "%s", c);
  char *b = strrchr(s, '/');
  if(b && b != s) *b = 0;
  else if(b) b[1] = 0;
}

static int termina(const char *s, const char *fim) {
  size_t a = strlen(s), b = strlen(fim);
  return a >= b && !strcasecmp(s + a - b, fim);
}

/* ------------------------------------------------------------------ arquivos pequenos */

static int gravar_atomico(const char *c, const void *d, size_t n) {
  char tmp[TAM_C + 16];
  snprintf(tmp, sizeof tmp, "%s.tmp", c);
  int fd = open(tmp, O_WRONLY | O_CREAT | O_TRUNC, 0644);
  if(fd < 0) return -1;
  size_t f = 0;
  while(f < n) {
    ssize_t w = write(fd, (const char *)d + f, n - f);
    if(w <= 0) break;
    f += (size_t)w;
  }
  int ok = f == n && !fsync(fd);
  if(close(fd)) ok = 0;
  if(!ok || rename(tmp, c)) {
    unlink(tmp);
    return -1;
  }
  return 0;
}

static int ler_arquivo(const char *c, buf_t *b, size_t max) {
  int fd = open(c, O_RDONLY);
  if(fd < 0) return -1;
  char bloco[8192];
  ssize_t r;
  while((r = read(fd, bloco, sizeof bloco)) > 0 && b->n < max) buf_add(b, bloco, (size_t)r);
  close(fd);
  buf_add(b, "", 1);
  b->n--;
  return 0;
}

/* copia um arquivo PEQUENO de configuracao (ajustes, .sprx do ampr); nunca um jogo */
static int copiar_pequeno(const char *de, const char *para, size_t max) {
  buf_t b = {0};
  struct stat st;
  if(lstat(de, &st) || !S_ISREG(st.st_mode) || (size_t)st.st_size > max || ler_arquivo(de, &b, max)) {
    buf_free(&b);
    return -1;
  }
  int r = gravar_atomico(para, b.d ? b.d : "", b.n);
  buf_free(&b);
  return r;
}

/* ================================================================== leitura do plano */

typedef int (*obj_fn)(const char *chave, const js_t *v, void *ctx);

/* Percorre um objeto JSON: fn(chave, valor) para cada par. -1 = quebrado. */
static int obj_cada(const js_t *o, obj_fn fn, void *ctx) {
  js_t j = *o;
  js_esp(&j);
  if(j.p >= j.fim || *j.p != '{') return -1;
  j.p++;
  int n = 0;
  for(;;) {
    js_esp(&j);
    if(j.p >= j.fim) return -1;
    if(*j.p == '}') return n;
    if(*j.p == ',') {
      j.p++;
      continue;
    }
    char k[128];
    if(*j.p != '"' || js_string(&j, k, sizeof k)) return -1;
    js_esp(&j);
    if(j.p >= j.fim || *j.p != ':') return -1;
    j.p++;
    js_esp(&j);
    js_t v = {j.p, j.fim};
    if(js_pular(&j, 1)) return -1;
    v.fim = j.p;
    n++;
    if(!fn(k, &v, ctx)) return -2;
  }
}

static int eh_num(const js_t *v) { return v->p < v->fim && (isdigit((unsigned char)*v->p) || *v->p == '-'); }

/* inteiro opcional com limite. 0 = ok (ausente = def); -1 = invalido (erro preenchido) */
static int ler_int(const js_t *o, const char *k, int def, int min, int max, int *saida, char *erro, size_t te) {
  js_t v;
  *saida = def;
  if(!js_campo(o, k, &v)) return 0;
  if(!strncmp(v.p, "true", 4) || !strncmp(v.p, "false", 5)) {   /* "fps": true */
    *saida = !strncmp(v.p, "true", 4);
    if(*saida < min || *saida > max) goto ruim;
    return 0;
  }
  if(!eh_num(&v)) goto ruim;
  char *fim;
  long x = strtol(v.p, &fim, 10);
  if(fim == v.p || x < min || x > max) goto ruim;
  *saida = (int)x;
  return 0;
ruim:
  snprintf(erro, te, "%s fora do limite (%d a %d)", k, min, max);
  return -1;
}

static int ler_dbl(const js_t *o, const char *k, double def, double min, double max, double *saida, char *erro, size_t te) {
  js_t v;
  *saida = def;
  if(!js_campo(o, k, &v)) return 0;
  char *fim;
  double x = eh_num(&v) ? strtod(v.p, &fim) : NAN;
  if(!eh_num(&v) || fim == v.p || !(x >= min && x <= max)) {
    snprintf(erro, te, "%s fora do limite (%g a %g)", k, min, max);
    return -1;
  }
  *saida = x;
  return 0;
}

static int ler_str(const js_t *o, const char *k, char *s, size_t t) {
  js_t v;
  s[0] = 0;
  if(!js_campo(o, k, &v)) return 0;
  if(*v.p != '"' || js_string(&v, s, t)) return -1;
  for(char *c = s; *c; c++)
    if((unsigned char)*c < ' ') *c = ' ';
  return 1;
}

static int id_ok(const char *s, size_t max) {
  size_t n = strlen(s);
  if(!n || n > max) return 0;
  for(size_t i = 0; i < n; i++)
    if(!isalnum((unsigned char)s[i]) && s[i] != '_' && s[i] != '-' && s[i] != '.') return 0;
  return strcmp(s, ".") && strcmp(s, "..");
}

/* lista de botoes ["ps","espera:1500",...] */
typedef struct {
  char (*l)[24];
  int n, ruim;
} botoes_ctx_t;
static int um_botao(const js_t *it, void *ctx) {
  botoes_ctx_t *b = ctx;
  char s[32];
  js_t j = *it;
  if(*j.p != '"' || js_string(&j, s, sizeof s) || b->n >= MAX_BOTOES) {
    b->ruim = 1;
    return 0;
  }
  if(!strncmp(s, "espera:", 7)) {
    int ms = atoi(s + 7);
    if(ms < 0 || ms > 30000 || strspn(s + 7, "0123456789") != strlen(s + 7) || !s[7]) b->ruim = 1;
  } else if(!pad_botao(s)) b->ruim = 1;
  if(b->ruim) return 0;
  snprintf(b->l[b->n++], 24, "%s", s);
  return 1;
}
static int ler_botoes(const js_t *o, const char *k, char l[][24], int *n, char *erro, size_t te) {
  js_t v;
  if(!js_campo(o, k, &v)) return 0;
  botoes_ctx_t b = {l, 0, 0};
  if(js_cada(&v, um_botao, &b) < 0 || b.ruim) {
    snprintf(erro, te, "%s: botao desconhecido ou espera fora do limite", k);
    return -1;
  }
  *n = b.n;
  return 0;
}

static void cfg_padrao(cfg_t *c) {
  /* 0.9.67: o controle novo abre "Quem esta usando este controle?" (teste-pad 1.3, PS5 Pro 12.00): 2 s, X escolhe o
     usuario, 4 s para a janela fechar; depois PS, Options, X, X ("Fechar jogo"). */
  static const char *const FECHAR[] = {"espera:2000", "cruz", "espera:4000", "ps", "espera:1500", "options", "espera:1200",
                                       "cruz", "espera:1200", "cruz"};
  memset(c, 0, sizeof *c);
  *c = (cfg_t){.carregar_max_s = 240, .trecho_s = 120, .repeticoes = 3, .esfriar_s = 300, .fps = 1, .temp_max_c = 85,
               .esfriar_ate_c = 60, .sk_espera_s = 300, .prep_parado_s = 600, .fechar_espera_s = 30, .fechar_pad_espera_s = 20,
               .compat_s = 60, .espera_dono_s = 1800, .esfriar_extra_s = 600, .espera_temp_s = 1800, .sk_fora_s = 120,
               .desmontar_espera_s = 120, .calmo_mib_s = 2.0, .pico_mib = 16.0, .janela_s = 20, .fps_min = 20,
               .fps_desvio_pct = 15, .min_tela_s = 15, .sem9090_s = 30, .amostra_s = 2, .exigir_foco = -1, .livre_min_mib = 4096,
               .folga_pkg_pct = 10, .quedas_seguidas = 2, .reabrir_proxima = 1, .fechar_metodo = 0, .pad_repouso_ms = 1500,
               .botao_ms = 250, .botao_depois_ms = 800};
  for(size_t i = 0; i < sizeof FECHAR / sizeof FECHAR[0]; i++) snprintf(c->fechar[c->nfechar++], 24, "%s", FECHAR[i]);
}

static int ler_cfg(const js_t *o, cfg_t *c, char *e, size_t te) {
  char metodo[16];
  int fq = 0;
  if(ler_int(o, "carregar_max_s", c->carregar_max_s, 30, 900, &c->carregar_max_s, e, te) ||
     ler_int(o, "trecho_s", c->trecho_s, 10, 900, &c->trecho_s, e, te) ||
     ler_int(o, "repeticoes", c->repeticoes, 1, 5, &c->repeticoes, e, te) ||
     ler_int(o, "esfriar_s", c->esfriar_s, 0, 1800, &c->esfriar_s, e, te) || ler_int(o, "fps", c->fps, 0, 1, &c->fps, e, te) ||
     ler_int(o, "temp_max_c", c->temp_max_c, 60, 95, &c->temp_max_c, e, te) ||
     ler_int(o, "esfriar_ate_c", c->esfriar_ate_c, 30, 90, &c->esfriar_ate_c, e, te) ||
     ler_int(o, "sk_espera_s", c->sk_espera_s, 30, 3600, &c->sk_espera_s, e, te) ||
     ler_int(o, "prep_parado_s", c->prep_parado_s, 60, 3600, &c->prep_parado_s, e, te) ||
     ler_int(o, "fechar_espera_s", c->fechar_espera_s, 5, 300, &c->fechar_espera_s, e, te) ||
     ler_int(o, "fechar_pad_espera_s", c->fechar_pad_espera_s, 5, 300, &c->fechar_pad_espera_s, e, te) ||
     ler_int(o, "compat_s", c->compat_s, 10, 900, &c->compat_s, e, te) ||
     ler_int(o, "espera_dono_s", c->espera_dono_s, 0, 7200, &c->espera_dono_s, e, te) ||
     ler_int(o, "esfriar_extra_s", c->esfriar_extra_s, 0, 3600, &c->esfriar_extra_s, e, te) ||
     ler_int(o, "espera_temp_s", c->espera_temp_s, 0, 7200, &c->espera_temp_s, e, te) ||
     ler_int(o, "sk_fora_s", c->sk_fora_s, 10, 1800, &c->sk_fora_s, e, te) ||
     ler_int(o, "desmontar_espera_s", c->desmontar_espera_s, 5, 600, &c->desmontar_espera_s, e, te) ||
     ler_dbl(o, "calmo_mib_s", c->calmo_mib_s, 0.01, 1024, &c->calmo_mib_s, e, te) ||
     ler_dbl(o, "pico_mib", c->pico_mib, 0.01, 4096, &c->pico_mib, e, te) ||
     ler_int(o, "janela_s", c->janela_s, 4, 300, &c->janela_s, e, te) || ler_int(o, "fps_min", c->fps_min, 1, 240, &c->fps_min, e, te) ||
     ler_int(o, "fps_desvio_pct", c->fps_desvio_pct, 1, 100, &c->fps_desvio_pct, e, te) ||
     ler_int(o, "min_tela_s", c->min_tela_s, 0, 600, &c->min_tela_s, e, te) ||
     ler_int(o, "sem9090_s", c->sem9090_s, 4, 600, &c->sem9090_s, e, te) ||
     ler_int(o, "amostra_s", c->amostra_s, 1, 30, &c->amostra_s, e, te) ||
     ler_int(o, "exigir_foco", c->exigir_foco, -1, 1, &c->exigir_foco, e, te) ||
     ler_int(o, "livre_min_mib", c->livre_min_mib, 0, 1024 * 1024, &c->livre_min_mib, e, te) ||
     ler_int(o, "folga_pkg_pct", c->folga_pkg_pct, 0, 200, &c->folga_pkg_pct, e, te) ||
     ler_int(o, "quedas_seguidas", c->quedas_seguidas, 1, 60, &c->quedas_seguidas, e, te) ||
     ler_int(o, "reabrir_proxima", c->reabrir_proxima, 0, 1, &c->reabrir_proxima, e, te) ||
     ler_int(o, "pad_repouso_ms", c->pad_repouso_ms, 100, 10000, &c->pad_repouso_ms, e, te) ||
     ler_int(o, "botao_ms", c->botao_ms, 30, 2000, &c->botao_ms, e, te) ||
     ler_int(o, "botao_depois_ms", c->botao_depois_ms, 0, 10000, &c->botao_depois_ms, e, te) ||
     ler_botoes(o, "fechar_botoes", c->fechar, &c->nfechar, e, te) || ler_botoes(o, "sequencia_inicio", c->inicio, &c->ninicio, e, te))
    return -1;
  if(ler_str(o, "fechar_metodo", metodo, sizeof metodo) < 0) fq = 1;
  else if(metodo[0] && strcmp(metodo, "auto") && strcmp(metodo, "kill")) fq = 1;
  if(fq) {
    snprintf(e, te, "fechar_metodo: use \"auto\" ou \"kill\"");
    return -1;
  }
  if(!strcmp(metodo, "kill")) c->fechar_metodo = 1;
  else if(metodo[0]) c->fechar_metodo = 0;
  return 0;
}

/* caminho aceito no plano: absoluto, sem "..", sem caracteres de controle, fora das pastas do sistema e do BACKUP */
static int caminho_plano_ok(const char *c) {
  if(!caminho_valido(c) || strlen(c) >= TAM_C - 64 || !strcmp(c, "/")) return 0;
  for(const char *x = c; *x; x++)
    if((unsigned char)*x < ' ' || *x == '\t') return 0;
  static const char *const PROIBIDO[] = {"/user", "/preinst", "/mnt/sandbox", "/mnt/shadowmnt", "/mnt/disc", "/dev", "/proc", NULL};
  if(!strncmp(c, "/system", 7)) return 0;   /* /system, /system_ex, /system_data... */
  for(int i = 0; PROIBIDO[i]; i++) {
    size_t k = strlen(PROIBIDO[i]);
    if(!strncmp(c, PROIBIDO[i], k) && (c[k] == '/' || !c[k])) return 0;
  }
  return !backup_dentro(c);
}

typedef struct {
  plano_t *pl;
  char *e;
  size_t te;
  int ruim;
} ler_ctx_t;

static int uma_versao(const char *k, const js_t *v, void *ctx) {
  ler_ctx_t *c = ctx;
  jogo_t *j = &c->pl->jogos[c->pl->nj];
  if(j->nv >= MAX_VERSOES || !id_ok(k, 20)) {
    snprintf(c->e, c->te, "%s: nome de versao invalido ou versoes demais (%s)", j->tid, k);
    c->ruim = 1;
    return 0;
  }
  js_t x = *v;
  versao_t *ve = &j->v[j->nv];
  if(*x.p != '"' || js_string(&x, ve->caminho, sizeof ve->caminho) || !caminho_plano_ok(ve->caminho)) {
    snprintf(c->e, c->te, "%s: caminho da versao %s invalido (absoluto, sem .., fora do sistema e do BACKUP)", j->tid, k);
    c->ruim = 1;
    return 0;
  }
  sem_barra(ve->caminho);
  for(int i = 0; i < j->nv; i++)
    if(!strcmp(j->v[i].nome, k) || !strcmp(base_de(j->v[i].caminho), base_de(ve->caminho))) {
      snprintf(c->e, c->te, "%s: versoes com o mesmo nome ou o mesmo nome de arquivo (%s)", j->tid, k);
      c->ruim = 1;
      return 0;
    }
  snprintf(ve->nome, sizeof ve->nome, "%s", k);
  j->nv++;
  return 1;
}

static int um_jogo(const char *k, const js_t *v, void *ctx) {
  ler_ctx_t *c = ctx;
  if(c->pl->nj >= MAX_JOGOS || !titulo_valido(k)) {
    snprintf(c->e, c->te, "jogo invalido ou jogos demais: %s", k);
    c->ruim = 1;
    return 0;
  }
  for(int i = 0; i < c->pl->nj; i++)
    if(!strcmp(c->pl->jogos[i].tid, k)) {
      snprintf(c->e, c->te, "jogo repetido: %s", k);
      c->ruim = 1;
      return 0;
    }
  jogo_t *j = &c->pl->jogos[c->pl->nj];
  memset(j, 0, sizeof *j);
  snprintf(j->tid, sizeof j->tid, "%s", k);
  js_t vs;
  if(ler_str(v, "nome", j->nome, sizeof j->nome) < 0 || ler_str(v, "ativa_pasta", j->ativa, sizeof j->ativa) <= 0 ||
     !caminho_plano_ok(j->ativa)) {
    snprintf(c->e, c->te, "%s: ativa_pasta ausente ou invalida", k);
    c->ruim = 1;
    return 0;
  }
  sem_barra(j->ativa);
  if(!js_campo(v, "versoes", &vs) || obj_cada(&vs, uma_versao, c) < 0 || c->ruim || !j->nv) {
    if(!c->ruim) snprintf(c->e, c->te, "%s: versoes ausentes ou quebradas", k);
    c->ruim = 1;
    return 0;
  }
  c->pl->nj++;
  return 1;
}

typedef struct {
  rodada_t *r;
  int ruim;
} aj_ctx_t;
static int um_ajuste(const char *k, const js_t *v, void *ctx) {
  aj_ctx_t *a = ctx;
  size_t n = strlen(k);
  int ok = n && n <= AMPR_AJ_NOME && (islower((unsigned char)k[0]) || k[0] == '_') && a->r->naj < MAX_AJ;
  for(size_t i = 0; ok && i < n; i++) ok = islower((unsigned char)k[i]) || isdigit((unsigned char)k[i]) || k[i] == '_';
  if(!ok || !isdigit((unsigned char)*v->p) || v->fim - v->p > 15) {
    a->ruim = 1;
    return 0;
  }
  snprintf(a->r->aj_nomes[a->r->naj], AMPR_AJ_NOME + 1, "%s", k);
  a->r->aj_vals[a->r->naj++] = strtoll(v->p, NULL, 10);
  return 1;
}

typedef struct {
  plano_t *pl;
  char *e;
  size_t te;
  int ruim;
} rod_ctx_t;
static int uma_rodada(const js_t *it, void *ctx) {
  rod_ctx_t *c = ctx;
  plano_t *pl = c->pl;
  if(pl->nr >= MAX_RODADAS) {
    snprintf(c->e, c->te, "rodadas demais (maximo %d)", MAX_RODADAS);
    c->ruim = 1;
    return 0;
  }
  rodada_t *r = &pl->r[pl->nr];
  memset(r, 0, sizeof *r);
  char jogo[16] = "", versao[24] = "", tipo[16] = "";
  if(ler_str(it, "id", r->id, sizeof r->id) <= 0 || !id_ok(r->id, 24)) {
    snprintf(c->e, c->te, "rodada %d: id ausente ou invalido", pl->nr + 1);
    goto ruim;
  }
  for(int i = 0; i < pl->nr; i++)
    if(!strcmp(pl->r[i].id, r->id)) {
      snprintf(c->e, c->te, "rodada %s repetida", r->id);
      goto ruim;
    }
  ler_str(it, "jogo", jogo, sizeof jogo);
  ler_str(it, "versao", versao, sizeof versao);
  r->jogo = r->versao = -1;
  for(int i = 0; i < pl->nj; i++)
    if(!strcmp(pl->jogos[i].tid, jogo)) {
      r->jogo = i;
      for(int k = 0; k < pl->jogos[i].nv; k++)
        if(!strcmp(pl->jogos[i].v[k].nome, versao)) r->versao = k;
    }
  if(r->jogo < 0 || r->versao < 0) {
    snprintf(c->e, c->te, "rodada %s: jogo %s ou versao %s fora da lista de jogos", r->id, jogo, versao);
    goto ruim;
  }
  if(ler_str(it, "ampr", r->ampr, sizeof r->ampr) < 0) {
    snprintf(c->e, c->te, "rodada %s: ampr invalido", r->id);
    goto ruim;
  }
  if(!r->ampr[0]) snprintf(r->ampr, sizeof r->ampr, "manter");
  if(strcmp(r->ampr, "manter") && strcmp(r->ampr, "embutido") &&
     (!nome_valido(r->ampr) || !termina(r->ampr, ".sprx") || strlen(r->ampr) > 100)) {
    snprintf(c->e, c->te, "rodada %s: ampr tem de ser \"manter\", \"embutido\" ou um arquivo .sprx", r->id);
    goto ruim;
  }
  js_t v;
  if(js_campo(it, "ajustes", &v) && *v.p == '{') {
    aj_ctx_t a = {r, 0};
    if(obj_cada(&v, um_ajuste, &a) < 0 || a.ruim) {
      snprintf(c->e, c->te, "rodada %s: ajustes fora do formato (nome: numero, ate %d)", r->id, MAX_AJ);
      goto ruim;
    }
    r->aj_objeto = 1;
  } else if(js_campo(it, "ajustes", &v) && strncmp(v.p, "\"padrao\"", 8) && !js_nulo(&v)) {
    snprintf(c->e, c->te, "rodada %s: ajustes tem de ser um objeto ou \"padrao\"", r->id);
    goto ruim;
  }
  ler_str(it, "tipo", tipo, sizeof tipo);
  if(tipo[0] && strcmp(tipo, "desempenho") && strcmp(tipo, "compat")) {
    snprintf(c->e, c->te, "rodada %s: tipo tem de ser desempenho ou compat", r->id);
    goto ruim;
  }
  r->compat = !strcmp(tipo, "compat");
  const cfg_t *p = &pl->cfg;
  if(ler_int(it, "carregar_max_s", p->carregar_max_s, 30, 900, &r->carregar_max_s, c->e, c->te) ||
     ler_int(it, "trecho_s", p->trecho_s, 10, 900, &r->trecho_s, c->e, c->te) ||
     ler_int(it, "repeticoes", p->repeticoes, 1, 5, &r->repeticoes, c->e, c->te) ||
     ler_int(it, "esfriar_s", p->esfriar_s, 0, 1800, &r->esfriar_s, c->e, c->te)) {
    char t[300];
    snprintf(t, sizeof t, "rodada %s: %s", r->id, c->e);
    snprintf(c->e, c->te, "%s", t);
    goto ruim;
  }
  ler_str(it, "nota", r->nota, sizeof r->nota);
  pl->nr++;
  return 1;
ruim:
  c->ruim = 1;
  return 0;
}

/* Le e confere o formato do plano (sem olhar o disco). 0 = ok. */
static int plano_ler(const char *d, size_t n, plano_t *pl, char *e, size_t te) {
  memset(pl, 0, sizeof *pl);
  cfg_padrao(&pl->cfg);
  e[0] = 0;
  uint8_t h[32];
  sha256_t s;
  sha256_iniciar(&s);
  sha256_atualizar(&s, d, n);
  sha256_final(&s, h);
  sha256_hex(h, pl->sha256);
  js_t o = {d, d + n}, v;
  js_esp(&o);
  if(o.p >= o.fim || *o.p != '{') {
    snprintf(e, te, "nao e um objeto JSON");
    return -1;
  }
  if(ler_int(&o, "versao_plano", 1, 1, 1, &pl->versao_plano, e, te)) {
    snprintf(e, te, "versao_plano desconhecida (este glibren le a 1)");
    return -1;
  }
  if(ler_str(&o, "id", pl->id, sizeof pl->id) <= 0 || !id_ok(pl->id, 40)) {
    snprintf(e, te, "id do plano ausente ou invalido (letras, numeros, . _ -)");
    return -1;
  }
  ler_str(&o, "titulo", pl->titulo, sizeof pl->titulo);
  if(js_campo(&o, "padrao", &v) && ler_cfg(&v, &pl->cfg, e, te)) return -1;
  ler_ctx_t c = {pl, e, te, 0};
  if(!js_campo(&o, "jogos", &v) || obj_cada(&v, um_jogo, &c) < 0 || c.ruim || !pl->nj) {
    if(!e[0]) snprintf(e, te, "lista de jogos ausente ou quebrada");
    return -1;
  }
  rod_ctx_t rc = {pl, e, te, 0};
  if(!js_campo(&o, "rodadas", &v) || js_cada(&v, uma_rodada, &rc) < 0 || rc.ruim || !pl->nr) {
    if(!e[0]) snprintf(e, te, "lista de rodadas ausente ou quebrada");
    return -1;
  }
  pl->estimativa_s = 0;
  for(int i = 0; i < pl->nr; i++) {
    const rodada_t *r = &pl->r[i];
    long long uma = r->carregar_max_s / 2 + (r->compat ? pl->cfg.compat_s : r->trecho_s) + r->esfriar_s + 60;
    pl->estimativa_s += uma * r->repeticoes;
  }
  return 0;
}

/* Le o plano guardado. 0 = ok. */
static int plano_do_disco(plano_t *pl, char *e, size_t te) {
  char c[TAM_C];
  buf_t b = {0};
  arq_bat(c, sizeof c, "plano.json");
  if(ler_arquivo(c, &b, PLANO_MAX) || !b.n) {
    buf_free(&b);
    snprintf(e, te, "nenhum plano buscado ainda");
    return -1;
  }
  int r = plano_ler(b.d, b.n, pl, e, te);
  buf_free(&b);
  return r;
}

/* ================================================================== ensaio seco (disco e ShadowKraken) */

static void caminho_ativo(const jogo_t *j, int k, char *s, size_t t) { snprintf(s, t, "%s/%s", j->ativa, base_de(j->v[k].caminho)); }

/* sem links no caminho (realpath igual) */
static int sem_links(const char *c) {
  char r[PATH_MAX];
  return realpath(c, r) && !strcmp(r, c);
}

static void linha(buf_t *l, int *n, const char *fmt, ...) __attribute__((format(printf, 3, 4)));
static void linha(buf_t *l, int *n, const char *fmt, ...) {
  char t[700];
  va_list a;
  va_start(a, fmt);
  vsnprintf(t, sizeof t, fmt, a);
  va_end(a);
  buf_str(l, (*n)++ ? "," : "");
  buf_json(l, t);
}

/* jogos do ShadowKraken: o item do titulo (path, source_type, image_type, source_available) */
typedef struct {
  const char *tid;
  int achados;
  char path[4][TAM_C];
  char tipo[24], imagem[24];
  int disponivel;   /* -1 = campo ausente */
} sk_jogo_t;
static int ver_sk_jogo(const js_t *it, void *ctx) {
  sk_jogo_t *s = ctx;
  js_t v;
  char tid[16] = "";
  if(js_campo(it, "title_id", &v)) js_string(&v, tid, sizeof tid);
  if(strcmp(tid, s->tid)) return 1;
  if(s->achados < 4) {
    char *pp = s->path[s->achados];
    pp[0] = 0;
    if(js_campo(it, "path", &v)) js_string(&v, pp, TAM_C);
    sem_barra(pp);
  }
  if(!s->achados) {
    s->tipo[0] = s->imagem[0] = 0;
    if(js_campo(it, "source_type", &v)) js_string(&v, s->tipo, sizeof s->tipo);
    if(js_campo(it, "image_type", &v)) js_string(&v, s->imagem, sizeof s->imagem);
    s->disponivel = js_campo(it, "source_available", &v) ? js_verdade(&v) : -1;
  }
  s->achados++;
  return 1;
}
/* 1 = respondeu (s preenchido), 0 = sem resposta */
static int sk_jogo(const char *tid, sk_jogo_t *s) {
  memset(s, 0, sizeof *s);
  s->tid = tid;
  s->disponivel = -1;
  buf_t r = {0};
  int st = apps_smp_pedir("/api/v1/games", "{}", &r, 10);
  if(st != 200 || !r.d) {
    buf_free(&r);
    return 0;
  }
  buf_add(&r, "", 1);
  js_t o = {r.d, r.d + r.n - 1}, l;
  int ok = js_campo(&o, "games", &l) && js_cada(&l, ver_sk_jogo, s) >= 0;
  buf_free(&r);
  return ok;
}

/* formato que o ShadowKraken deve mostrar para a versao: pkg -> "pkg"; pasta -> "folder"; imagem -> "image" (+ exfat) */
static void formato_esperado(const char *caminho, int pasta, char *tipo, size_t tt, char *imagem, size_t ti) {
  imagem[0] = 0;
  if(pasta) snprintf(tipo, tt, "folder");
  else if(termina(caminho, ".pkg")) snprintf(tipo, tt, "pkg");
  else {
    snprintf(tipo, tt, "image");
    if(termina(caminho, ".exfat")) snprintf(imagem, ti, "exfat");
  }
}

/* Confere o plano contra o disco e o ShadowKraken (nada e movido). linhas = array JSON de textos. 0 = pode. */
static int ensaio(const plano_t *pl, buf_t *l, char *e, size_t te) {
  static char sk[64][SK_PASTA_TAM];
  int n = 0, ruim = 0, padrao = 0, prof = 1;
  e[0] = 0;
  buf_str(l, "[");
  int ns = sk_pastas_listar(sk, 64, &padrao, &prof);
  if(ns < 0) {
    snprintf(e, te, "o ShadowKraken nao respondeu (a lista de pastas vigiadas vem da API dele)");
    linha(l, &n, "ShadowKraken: sem resposta");
    buf_str(l, "]");
    return -1;
  }
  linha(l, &n, "ShadowKraken: %d pasta(s) vigiada(s)%s, profundidade %d", ns, padrao ? " (lista padrao)" : "", prof);
  for(int ij = 0; ij < pl->nj && !ruim; ij++) {
    const jogo_t *j = &pl->jogos[ij];
    struct stat sa;
    int vigiada = 0;
    for(int i = 0; i < ns; i++) {
      char x[SK_PASTA_TAM];
      snprintf(x, sizeof x, "%s", sk[i]);
      sem_barra(x);
      if(!strcmp(x, j->ativa)) vigiada = 1;
    }
    if(!vigiada) {
      snprintf(e, te, "%s: a pasta ativa %s nao esta nas pastas do ShadowKraken", j->tid, j->ativa);
      ruim = 1;
      break;
    }
    if(stat(j->ativa, &sa) || !S_ISDIR(sa.st_mode) || !sem_links(j->ativa)) {
      snprintf(e, te, "%s: a pasta ativa %s nao existe ou tem link", j->tid, j->ativa);
      ruim = 1;
      break;
    }
    int ativas = 0;
    for(int k = 0; k < j->nv && !ruim; k++) {
      const versao_t *v = &j->v[k];
      char pai[TAM_C], at[TAM_C];
      struct stat sg, sp, sx;
      pai_de(v->caminho, pai, sizeof pai);
      caminho_ativo(j, k, at, sizeof at);
      int na_guarda = !lstat(v->caminho, &sg), na_ativa = !lstat(at, &sx);
      if(!config_pasta_permitida(pai)) {
        snprintf(e, te, "%s/%s: a pasta %s nao esta na lista de pastas do glibren", j->tid, v->nome, pai);
        ruim = 1;
        break;
      }
      for(int i = 0; i < ns; i++) {   /* a guardada nao pode ser vista pelo ShadowKraken */
        char x[SK_PASTA_TAM];
        snprintf(x, sizeof x, "%s", sk[i]);
        sem_barra(x);
        size_t kx = strlen(x);
        if(!strncmp(pai, x, kx) && (pai[kx] == '/' || !pai[kx])) {
          int niv = 0;
          for(const char *q = pai + kx; *q; q++) niv += *q == '/';
          if(niv <= prof - 1) {
            snprintf(e, te, "%s/%s: a pasta guardada %s e vigiada pelo ShadowKraken (seria jogo repetido)", j->tid, v->nome, pai);
            ruim = 1;
          }
        }
      }
      if(ruim) break;
      if(stat(pai, &sp) || !sem_links(pai)) {
        snprintf(e, te, "%s/%s: a pasta guardada %s nao existe ou tem link", j->tid, v->nome, pai);
        ruim = 1;
        break;
      }
      if(sp.st_dev != sa.st_dev) {
        snprintf(e, te, "%s/%s: a pasta guardada e a ativa estao em discos diferentes (so renomear no mesmo disco)", j->tid, v->nome);
        ruim = 1;
        break;
      }
      if(na_guarda && na_ativa) {
        snprintf(e, te, "%s/%s: existe na pasta guardada E na ativa (%s): resolva na mao", j->tid, v->nome, at);
        ruim = 1;
        break;
      }
      if(!na_guarda && !na_ativa) {
        snprintf(e, te, "%s/%s: nao achei %s (nem na pasta ativa)", j->tid, v->nome, v->caminho);
        ruim = 1;
        break;
      }
      const struct stat *s = na_guarda ? &sg : &sx;
      if(S_ISLNK(s->st_mode) || (!S_ISREG(s->st_mode) && !S_ISDIR(s->st_mode))) {
        snprintf(e, te, "%s/%s: nao e arquivo nem pasta (link?)", j->tid, v->nome);
        ruim = 1;
        break;
      }
      if(em_download(na_guarda ? pai : j->ativa, base_de(v->caminho))) {
        snprintf(e, te, "%s/%s: arquivo em download", j->tid, v->nome);
        ruim = 1;
        break;
      }
      ativas += na_ativa;
      linha(l, &n, "%s %s: versao %s %s (%s)", j->tid, j->nome, v->nome, na_ativa ? "na pasta ativa" : "guardada",
            na_ativa ? at : v->caminho);
    }
    if(!ruim && ativas > 1) {
      snprintf(e, te, "%s: mais de uma versao na pasta ativa (o ShadowKraken so usa uma)", j->tid);
      ruim = 1;
    }
    if(ruim) break;
    sk_jogo_t s;
    if(sk_jogo(j->tid, &s)) {   /* outra copia do jogo que nao e do plano = repetido no ShadowKraken */
      for(int a = 0; a < s.achados && a < 4 && !ruim; a++) {
        int nosso = 0;
        for(int k = 0; k < j->nv; k++) {
          char at[TAM_C];
          caminho_ativo(j, k, at, sizeof at);
          if(!strcmp(s.path[a], at) || !strcmp(s.path[a], j->v[k].caminho)) nosso = 1;
        }
        if(!nosso && s.path[a][0]) {
          snprintf(e, te, "%s: o ShadowKraken tem outra copia do jogo fora do plano (%s)", j->tid, s.path[a]);
          ruim = 1;
        }
      }
    }
  }
  for(int i = 0; i < pl->nr && !ruim; i++) {   /* builds do ampr */
    const rodada_t *r = &pl->r[i];
    if(!strcmp(r->ampr, "manter") || !strcmp(r->ampr, "embutido")) continue;
    char pb[TAM_C], c[TAM_C + 140], sha[65];
    pasta_builds(pb, sizeof pb);
    snprintf(c, sizeof c, "%s/%s", pb, r->ampr);
    if(ampr_teste_conferir_arquivo(c, sha, NULL, 0, NULL, 0, NULL)) {
      snprintf(e, te, "rodada %s: %s nao existe em %s ou nao e um ampr-emu-ng", r->id, r->ampr, pb);
      ruim = 1;
    }
  }
  if(!ruim)
    linha(l, &n, "Plano %s: %d rodada(s), cerca de %lld min no total", pl->id, pl->nr, (pl->estimativa_s + 59) / 60);
  else linha(l, &n, "Recusado: %s", e);
  buf_str(l, "]");
  return ruim ? -1 : 0;
}

/* ================================================================== estado gravado */

static void salvar_estado(void) {
  char c[TAM_C], pb[TAM_C];
  pasta_bat(pb, sizeof pb);
  mkdir_p(pb);
  arq_bat(c, sizeof c, "estado.json");
  buf_t b = {0};
  pthread_mutex_lock(&g_trava);
  buf_str(&b, "{\"estado\":");
  buf_json(&b, g.estado);
  buf_str(&b, ",\"passo\":");
  buf_json(&b, g.passo);
  buf_fmt(&b, ",\"rodada\":%d,\"rep\":%d,\"boot\":%lld,\"iniciado\":%lld,\"desde\":%lld,\"quedas_seguidas\":%d,\"plano_id\":", g.rodada, g.rep,
          g.boot, g.iniciado, g.desde, g.quedas_seguidas);
  buf_json(&b, g.plano_id);
  buf_str(&b, ",\"plano_sha\":");
  buf_json(&b, g.plano_sha);
  buf_str(&b, ",\"aberto_bat\":");
  buf_json(&b, g.aberto_bat);
  buf_str(&b, ",\"ampr_original\":");
  buf_json(&b, g.ampr_original);
  buf_fmt(&b, ",\"ampr_mexeu\":%d,\"tune_mexeu\":%d,\"tune_original\":", g.ampr_mexeu, g.tune_mexeu);
  buf_json(&b, g.tune_original);
  buf_str(&b, ",\"erro\":");
  buf_json(&b, g.erro);
  buf_str(&b, ",\"relatorio\":");
  buf_json(&b, g.relatorio);
  buf_str(&b, "}\n");
  pthread_mutex_unlock(&g_trava);
  if(gravar_atomico(c, b.d, b.n)) diario("bateria: nao gravou %s (%s)", c, strerror(errno));
  buf_free(&b);
}

static void ler_estado(void) {
  char c[TAM_C];
  buf_t b = {0};
  arq_bat(c, sizeof c, "estado.json");
  if(ler_arquivo(c, &b, 64 * 1024) || !b.n) {
    buf_free(&b);
    return;
  }
  js_t o = {b.d, b.d + b.n}, v;
#define S(k, d) ler_str(&o, k, d, sizeof d)
#define N(k, d) \
  if(js_campo(&o, k, &v)) d = atoll(v.p)
  S("estado", g.estado);
  S("passo", g.passo);
  S("plano_id", g.plano_id);
  S("plano_sha", g.plano_sha);
  S("aberto_bat", g.aberto_bat);
  S("ampr_original", g.ampr_original);
  S("tune_original", g.tune_original);
  S("erro", g.erro);
  S("relatorio", g.relatorio);
  N("rodada", g.rodada);
  N("rep", g.rep);
  N("boot", g.boot);
  N("iniciado", g.iniciado);
  N("desde", g.desde);
  N("quedas_seguidas", g.quedas_seguidas);
  N("ampr_mexeu", g.ampr_mexeu);
  N("tune_mexeu", g.tune_mexeu);
#undef S
#undef N
  buf_free(&b);
  if(!g.estado[0]) snprintf(g.estado, sizeof g.estado, "parado");
}

static void definir(const char *estado, const char *passo, const char *fmt, ...) __attribute__((format(printf, 3, 4)));
static void definir(const char *estado, const char *passo, const char *fmt, ...) {
  pthread_mutex_lock(&g_trava);
  if(estado) snprintf(g.estado, sizeof g.estado, "%s", estado);
  if(passo && strcmp(passo, g.passo)) {
    snprintf(g.passo, sizeof g.passo, "%s", passo);
    g.desde = (long long)time(NULL);
  }
  if(fmt) {
    va_list a;
    va_start(a, fmt);
    vsnprintf(g.msg, sizeof g.msg, fmt, a);
    va_end(a);
  }
  pthread_mutex_unlock(&g_trava);
  salvar_estado();
}

static void erro_def(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
static void erro_def(const char *fmt, ...) {
  pthread_mutex_lock(&g_trava);
  va_list a;
  va_start(a, fmt);
  vsnprintf(g.erro, sizeof g.erro, fmt, a);
  va_end(a);
  pthread_mutex_unlock(&g_trava);
  diario("bateria: ERRO: %s", g.erro);
}

static int cancelado(void) {
  pthread_mutex_lock(&g_trava);
  int c = g.cancelar;
  pthread_mutex_unlock(&g_trava);
  return c;
}

/* espera "segundos" do plano (escala de teste); 1 = pediram para parar */
static int dormir(double segundos) {
  long long total = (long long)(segundos * seg_ms()), feito = 0;
  while(feito < total) {
    if(cancelado()) return 1;
    long long passo = total - feito < 50 ? total - feito : 50;
    usleep((useconds_t)(passo * 1000));
    feito += passo;
  }
  return cancelado();
}

static double seg_desde(long long t0) { return (double)(agora_ms() - t0) / (double)seg_ms(); }

/* ================================================================== leituras do PS5 */

/* maior temperatura entre CPU e SoC agora; -1 = sem leitura */
static int temperatura(void) {
#ifndef __PROSPERO__
  const char *a = getenv("GLR_TESTE_BAT_TEMP");
  if(a && *a) {
    FILE *f = fopen(a, "r");
    int t = -1;
    if(f) {
      if(fscanf(f, "%d", &t) != 1) t = -1;
      fclose(f);
    }
    return t;
  }
#endif
  buf_t b = {0};
  termico_json(&b, 0);
  js_t o = {b.d, b.d + b.n}, v;
  int cpu = b.d && js_campo(&o, "cpu", &v) ? atoi(v.p) : -1, soc = b.d && js_campo(&o, "soc", &v) ? atoi(v.p) : -1;
  buf_free(&b);
  return cpu > soc ? cpu : soc;
}

/* espaco livre (MiB) no disco do caminho; -1 = nao sabe */
static long long livre_mib(const char *c) {
#ifndef __PROSPERO__
  const char *a = getenv("GLR_TESTE_BAT_LIVRE_MIB");
  if(a && *a) {
    FILE *f = fopen(a, "r");
    long long t = -1;
    if(f) {
      if(fscanf(f, "%lld", &t) != 1) t = -1;
      fclose(f);
    }
    return t;
  }
#endif
  struct statvfs s;
  if(statvfs(c, &s)) return -1;
  return (long long)((unsigned long long)s.f_bavail * s.f_frsize / (1024ULL * 1024ULL));
}

static double ler_fps(void) {
  buf_t b = {0};
  fps_json(&b, 0);
  js_t o = {b.d, b.d + b.n}, v;
  double f = -1;
  if(b.d && js_campo(&o, "fps", &v) && eh_num(&v)) f = strtod(v.p, NULL);
  buf_free(&b);
  return f > 0 ? f : -1;
}

/* 1 = o jogo tem o foco (ou nao ha sinal e o plano nao exige) */
static int em_foco(const char *tid, int exigir) {
  if(exigir == 0) return 1;
  primeiro_plano_t pp;
  if(primeiro_plano_ler(&pp) || !pp.sinal) return exigir < 0;   /* sem sinal: so exige se o plano mandar */
  int appid = lancador_appid(tid);
  return appid >= 0 && pp.foco == (uint32_t)appid;
}

static int sk_vivo(void) {
  char v[64];
  return apps_smp_versao(v, sizeof v);
}

#ifndef __PROSPERO__
/* PC: tira/poe o titulo do arquivo GLR_TESTE_ABERTOS */
static void teste_abertos(const char *tid, int por) {
  const char *arq = getenv("GLR_TESTE_ABERTOS");
  if(!arq || !*arq) return;
  char lista[4096] = "", nova[4200] = "";
  FILE *f = fopen(arq, "r");
  if(f) {
    size_t n = fread(lista, 1, sizeof lista - 1, f);
    lista[n] = 0;
    fclose(f);
  }
  size_t o = 0;
  for(char *sv = NULL, *p = strtok_r(lista, " \t\r\n", &sv); p; p = strtok_r(NULL, " \t\r\n", &sv))
    if(strcmp(p, tid)) o += (size_t)snprintf(nova + o, sizeof nova - o, "%s\n", p);
  if(por) snprintf(nova + o, sizeof nova - o, "%s\n", tid);
  f = fopen(arq, "w");
  if(f) {
    fputs(nova, f);
    fclose(f);
  }
}
static void teste_log(const char *fmt, const char *a, const char *b) {
  const char *arq = getenv("GLR_TESTE_KILL_LOG");
  FILE *f = arq && *arq ? fopen(arq, "a") : NULL;
  if(!f) return;
  fprintf(f, fmt, a, b);
  fclose(f);
}
#endif

/* algum dump novo do CoreDump Dumper para o titulo desde "desde" (nome da pasta) */
static void achar_dump(const char *tid, time_t desde, char *nome, size_t tam) {
  nome[0] = 0;
  const char *pasta = "/data/ps5-coredump-dumper";
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_COREDUMPS")) pasta = getenv("GLR_TESTE_COREDUMPS");
#endif
  DIR *d = opendir(pasta);
  if(!d) return;
  struct dirent *e;
  size_t k = strlen(tid);
  while((e = readdir(d))) {
    char c[TAM_C + 300];
    struct stat st;
    if(strncmp(e->d_name, tid, k) || e->d_name[k] != '_') continue;
    snprintf(c, sizeof c, "%s/%s", pasta, e->d_name);
    if(!lstat(c, &st) && st.st_mtime >= desde) snprintf(nome, tam, "%s", e->d_name);
  }
  closedir(d);
}

/* ================================================================== journal e movimentos */

#define MOV_MAX 256
typedef struct {
  int seq, ok, falhou, desfeito;
  unsigned long long dev, ino;
  long long tam;
  char de[TAM_C], para[TAM_C];
} mov_t;

static mov_t g_mov[MOV_MAX];   /* so com g_trava_j */
static pthread_mutex_t g_trava_j = PTHREAD_MUTEX_INITIALIZER;

static void arq_journal(char *s, size_t t) { arq_bat(s, t, "journal.txt"); }

static int journal_linha(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
static int journal_linha(const char *fmt, ...) {
  char c[TAM_C], pb[TAM_C], l[TAM_C * 2 + 200];
  pasta_bat(pb, sizeof pb);
  mkdir_p(pb);
  arq_journal(c, sizeof c);
  va_list a;
  va_start(a, fmt);
  int n = vsnprintf(l, sizeof l, fmt, a);
  va_end(a);
  if(n < 0 || (size_t)n >= sizeof l - 1) return -1;
  l[n++] = '\n';
  int fd = open(c, O_WRONLY | O_CREAT | O_APPEND, 0644);
  if(fd < 0) return -1;
  int ok = write(fd, l, (size_t)n) == n && !fsync(fd);
  if(close(fd)) ok = 0;
  return ok ? 0 : -1;
}

/* Le o journal: os movimentos em g_mov. Devolve quantos (-1 = sem journal). Chamar com g_trava_j. */
static int journal_ler(void) {
  char c[TAM_C];
  arq_journal(c, sizeof c);
  FILE *f = fopen(c, "r");
  if(!f) return -1;
  int n = 0;
  static char l[TAM_C * 2 + 300];
  while(fgets(l, sizeof l, f)) {
    l[strcspn(l, "\r\n")] = 0;
    int seq = 0;
    if(!strncmp(l, "MOVER ", 6) && n < MOV_MAX) {
      mov_t *m = &g_mov[n];
      memset(m, 0, sizeof *m);
      char *t1 = strchr(l, '\t'), *t2 = t1 ? strchr(t1 + 1, '\t') : NULL;
      if(!t1 || !t2 || sscanf(l, "MOVER %d dev=%llu ino=%llu tam=%lld", &m->seq, &m->dev, &m->ino, &m->tam) != 4) continue;
      *t2 = 0;
      snprintf(m->de, sizeof m->de, "%s", t1 + 1);
      snprintf(m->para, sizeof m->para, "%s", t2 + 1);
      n++;
    } else if(sscanf(l, "OK %d", &seq) == 1 || sscanf(l, "FALHOU %d", &seq) == 1 || sscanf(l, "DESFEITO %d", &seq) == 1 ||
              sscanf(l, "RESOLVIDO %d", &seq) == 1) {
      for(int i = 0; i < n; i++)
        if(g_mov[i].seq == seq) {
          if(l[0] == 'O') g_mov[i].ok = 1;
          else if(l[0] == 'F') g_mov[i].falhou = 1;
          else g_mov[i].desfeito = 1;
        }
    }
  }
  fclose(f);
  return n;
}

/* movimentos ainda nao desfeitos (OK sem DESFEITO, ou sem OK/FALHOU) */
static int journal_pendentes(void) {
  pthread_mutex_lock(&g_trava_j);
  int n = journal_ler(), p = 0;
  for(int i = 0; i < n; i++) p += !g_mov[i].desfeito && !g_mov[i].falhou;
  pthread_mutex_unlock(&g_trava_j);
  return p;
}

static int g_seq;

/* So rename no mesmo disco. Recusa: destino existe, discos diferentes, link, download, jogo aberto. 0 = movido. */
static int mover(const char *de, const char *para, char *e, size_t te) {
  struct stat sd, sp, sx;
  char pai[TAM_C], tid[16];
  pai_de(para, pai, sizeof pai);
  int aberto = app_de_jogo_aberto(tid, sizeof tid);
  if(aberto != 0) {
    snprintf(e, te, "jogo aberto (%s): nada e movido", aberto > 0 ? tid : "nao deu para saber");
    return -1;
  }
  if(lstat(de, &sd)) {
    snprintf(e, te, "origem sumiu: %s", de);
    return -1;
  }
  if(S_ISLNK(sd.st_mode) || (!S_ISREG(sd.st_mode) && !S_ISDIR(sd.st_mode))) {
    snprintf(e, te, "origem nao e arquivo nem pasta: %s", de);
    return -1;
  }
  if(!lstat(para, &sx)) {
    snprintf(e, te, "destino ja existe (nada e sobrescrito): %s", para);
    return -1;
  }
  if(stat(pai, &sp) || !S_ISDIR(sp.st_mode)) {
    snprintf(e, te, "pasta de destino nao existe: %s", pai);
    return -1;
  }
  if(sp.st_dev != sd.st_dev) {
    snprintf(e, te, "discos diferentes (so renomear no mesmo disco; nunca copiar): %s -> %s", de, pai);
    return -1;
  }
  char pde[TAM_C];
  pai_de(de, pde, sizeof pde);
  if(em_download(pde, base_de(de))) {
    snprintf(e, te, "arquivo em download: %s", de);
    return -1;
  }
  if(!g_seq) {
    pthread_mutex_lock(&g_trava_j);
    int n = journal_ler();
    for(int i = 0; i < n; i++)
      if(g_mov[i].seq > g_seq) g_seq = g_mov[i].seq;
    pthread_mutex_unlock(&g_trava_j);
  }
  int seq = ++g_seq;
  if(journal_linha("MOVER %d dev=%llu ino=%llu tam=%lld\t%s\t%s", seq, (unsigned long long)sd.st_dev, (unsigned long long)sd.st_ino,
                   (long long)sd.st_size, de, para)) {
    snprintf(e, te, "nao gravou o journal: nada movido");
    return -1;
  }
  if(rename(de, para)) {
    int er = errno;
    journal_linha("FALHOU %d %d", seq, er);
    snprintf(e, te, "rename falhou (%s): %s", strerror(er), de);
    return -1;
  }
  journal_linha("OK %d", seq);
  diario("bateria: movido (rename) %s -> %s", de, para);
  return 0;
}

static void pedir_releitura(void) { backup_pedir_releitura(); }

/* Desfazer tudo: o journal de tras para frente. Para no primeiro problema (lista "resolver na mao"). 0 = tudo desfeito. */
static int desfazer_journal(void) {
  pthread_mutex_lock(&g_trava_j);
  int n = journal_ler(), problema = 0, mexeu = 0;
  char prob[2400] = "";
  size_t pk = 0;
  for(int i = n - 1; i >= 0 && !problema; i--) {
    mov_t *m = &g_mov[i];
    if(m->desfeito || m->falhou) continue;
    struct stat sp, sd;
    int em_para = !lstat(m->para, &sp) && sp.st_dev == m->dev && sp.st_ino == m->ino;
    int em_de = !lstat(m->de, &sd) && sd.st_dev == m->dev && sd.st_ino == m->ino;
    if(!m->ok && em_de && !em_para) {   /* o rename nao aconteceu */
      journal_linha("RESOLVIDO %d (nao tinha movido)", m->seq);
      continue;
    }
    if(!em_para) {
      pk += (size_t)snprintf(prob + pk, sizeof prob - pk, "%s nao esta mais em %s (ou foi trocado); deveria voltar para %s. ", base_de(m->de),
                             m->para, m->de);
      problema = 1;
      break;
    }
    if(!lstat(m->de, &sd)) {
      pk += (size_t)snprintf(prob + pk, sizeof prob - pk, "%s ja existe: nao da para devolver %s. ", m->de, m->para);
      problema = 1;
      break;
    }
    backup_res_t r;
    if(backup_soltar(m->para, &r)) {
      pk += (size_t)snprintf(prob + pk, sizeof prob - pk, "o ShadowKraken nao soltou %s (%s %s). ", m->para, r.chave, r.detalhe);
      problema = 1;
      break;
    }
    char tid[16];
    if(app_de_jogo_aberto(tid, sizeof tid) != 0) {
      snprintf(prob + pk, sizeof prob - pk, "jogo aberto: o desfazer espera ele fechar. ");
      problema = 1;
      break;
    }
    if(rename(m->para, m->de)) {
      pk += (size_t)snprintf(prob + pk, sizeof prob - pk, "rename de volta falhou (%s): %s. ", strerror(errno), m->para);
      problema = 1;
      break;
    }
    journal_linha("DESFEITO %d", m->seq);
    diario("bateria: desfeito (rename) %s -> %s", m->para, m->de);
    mexeu = 1;
  }
  int pend = 0;
  if(!problema) {   /* tudo desfeito: o journal vai para o historico (nao e apagado) */
    n = journal_ler();
    for(int i = 0; i < n; i++) pend += !g_mov[i].desfeito && !g_mov[i].falhou;
    if(!pend && n >= 0) {
      char c[TAM_C], h[TAM_C + 40];
      arq_journal(c, sizeof c);
      snprintf(h, sizeof h, "%s.%lld", c, (long long)time(NULL));
      if(n > 0) rename(c, h);
      else unlink(c);   /* journal vazio (nenhum movimento) */
    }
  }
  pthread_mutex_unlock(&g_trava_j);
  pthread_mutex_lock(&g_trava);
  snprintf(g.problemas, sizeof g.problemas, "%s", prob);
  pthread_mutex_unlock(&g_trava);
  if(mexeu) pedir_releitura();
  if(problema) diario("bateria: desfazer parou: %s", prob);
  return problema ? -1 : 0;
}

/* GL reaberto no mesmo boot: linha MOVER sem OK/FALHOU vira OK ou FALHOU conforme onde o inode esta. 0 = resolvido. */
static int journal_resolver(void) {
  pthread_mutex_lock(&g_trava_j);
  int n = journal_ler(), ruim = 0;
  for(int i = 0; i < n; i++) {
    mov_t *m = &g_mov[i];
    if(m->ok || m->falhou || m->desfeito) continue;
    struct stat s;
    if(!lstat(m->para, &s) && s.st_ino == m->ino && s.st_dev == m->dev) journal_linha("OK %d", m->seq);
    else if(!lstat(m->de, &s) && s.st_ino == m->ino && s.st_dev == m->dev) journal_linha("FALHOU %d 0", m->seq);
    else ruim = 1;
  }
  pthread_mutex_unlock(&g_trava_j);
  return ruim ? -1 : 0;
}

/* ================================================================== ampr e ajustes (guardar e voltar) */

static void guardar_original(void) {
  char c[TAM_C], dest[TAM_C], tune[TAM_C];
  pthread_mutex_lock(&g_trava);
  int ja = g.ampr_original[0] != 0;
  pthread_mutex_unlock(&g_trava);
  if(ja) return;
  arq_bat(dest, sizeof dest, "ampr-original.sprx");
  int tem = ampr_teste_runtime(c, sizeof c, NULL, NULL, 0, NULL, 0, NULL);
  int copiou = tem && !copiar_pequeno(c, dest, 8u * 1024 * 1024);
  ampr_arquivo_ajustes(tune, sizeof tune);
  arq_bat(dest, sizeof dest, "tune-original.txt");
  struct stat st;
  int tem_tune = !lstat(tune, &st) && !copiar_pequeno(tune, dest, 64 * 1024);
  pthread_mutex_lock(&g_trava);
  snprintf(g.ampr_original, sizeof g.ampr_original, "%s", copiou ? "arquivo" : "embutido");
  snprintf(g.tune_original, sizeof g.tune_original, "%s", tem_tune ? "sim" : "nao");
  pthread_mutex_unlock(&g_trava);
  salvar_estado();
}

static void voltar_original(void) {
  char c[TAM_C], erro[240];
  pthread_mutex_lock(&g_trava);
  int am = g.ampr_mexeu, tm = g.tune_mexeu;
  char orig[12], tune_o[8];
  snprintf(orig, sizeof orig, "%s", g.ampr_original);
  snprintf(tune_o, sizeof tune_o, "%s", g.tune_original);
  pthread_mutex_unlock(&g_trava);
  if(am) {
    int r;
    if(!strcmp(orig, "arquivo")) {
      arq_bat(c, sizeof c, "ampr-original.sprx");
      r = ampr_teste_instalar_arquivo(c, erro, sizeof erro);
    } else r = ampr_teste_embutido(erro, sizeof erro);
    diario("bateria: ampr-emu-ng de volta ao de antes (%s)%s%s", orig, r ? ": " : "", r ? erro : "");
  }
  if(tm) {
    char tune[TAM_C];
    ampr_arquivo_ajustes(tune, sizeof tune);
    if(!strcmp(tune_o, "sim")) {
      arq_bat(c, sizeof c, "tune-original.txt");
      copiar_pequeno(c, tune, 64 * 1024);
    } else ampr_padrao();
    diario("bateria: ajustes do ampr de volta ao de antes (%s)", tune_o);
  }
  pthread_mutex_lock(&g_trava);
  g.ampr_mexeu = g.tune_mexeu = 0;
  g.ampr_original[0] = g.tune_original[0] = 0;
  pthread_mutex_unlock(&g_trava);
  salvar_estado();
}

/* ================================================================== uma repeticao */

typedef struct {
  char resultado[20], compat[12], fechar[16], formato_sk[48], build[160], fmt_ampr[24];
  char ajustes_erro[200], ignorados[200], medida[48], dump[96], erro[300], carregou_por[24];
  double t_tela, t_ampr, t_carregado;
  long long bytes_menu;
  int reaberto, tem_res;
  ampr_resumo_t res;
  double fps_media, temp_max;
} rep_t;

enum { RP_OK = 0, RP_QUEDA = 1, RP_PARAR = 2 };

static void num_json(buf_t *b, const char *k, double v, int casas) {
  if(!(v >= 0))   /* negativo ou NaN */ buf_fmt(b, ",\"%s\":null", k);
  else buf_fmt(b, ",\"%s\":%.*f", k, casas, v);
}

static void gravar_resultado(const plano_t *pl, int ir, int rep, const rep_t *x) {
  const rodada_t *r = &pl->r[ir];
  const jogo_t *j = &pl->jogos[r->jogo];
  buf_t b = {0};
  buf_fmt(&b, "{\"rodada\":%d,\"id\":", ir + 1);
  buf_json(&b, r->id);
  buf_str(&b, ",\"jogo\":");
  buf_json(&b, j->tid);
  buf_str(&b, ",\"nome\":");
  buf_json(&b, j->nome);
  buf_str(&b, ",\"versao\":");
  buf_json(&b, j->v[r->versao].nome);
  buf_str(&b, ",\"arquivo\":");
  buf_json(&b, base_de(j->v[r->versao].caminho));
  buf_fmt(&b, ",\"rep\":%d,\"reps\":%d,\"tipo\":\"%s\",\"resultado\":", rep + 1, r->repeticoes, r->compat ? "compat" : "desempenho");
  buf_json(&b, x->resultado);
  buf_str(&b, ",\"compat\":");
  buf_json(&b, x->compat);
  buf_str(&b, ",\"formato_sk\":");
  buf_json(&b, x->formato_sk);
  buf_str(&b, ",\"ampr\":{\"pedido\":");
  buf_json(&b, r->ampr);
  buf_str(&b, ",\"build\":");
  buf_json(&b, x->build);
  buf_str(&b, ",\"formato\":");
  buf_json(&b, x->fmt_ampr);
  buf_str(&b, "},\"ajustes\":");
  char aj[600] = "";
  size_t k = 0;
  if(!r->aj_objeto) snprintf(aj, sizeof aj, "padrao");
  for(int i = 0; i < r->naj && k < sizeof aj; i++) k += (size_t)snprintf(aj + k, sizeof aj - k, "%s%s=%lld", i ? "," : "", r->aj_nomes[i], r->aj_vals[i]);
  buf_json(&b, aj);
  buf_str(&b, ",\"ajustes_erro\":");
  buf_json(&b, x->ajustes_erro);
  buf_str(&b, ",\"ignorados\":");
  buf_json(&b, x->ignorados);
  num_json(&b, "t_tela", x->t_tela, 1);
  num_json(&b, "t_ampr", x->t_ampr, 1);
  num_json(&b, "t_carregado", x->t_carregado, 1);
  if(x->bytes_menu >= 0) buf_fmt(&b, ",\"bytes_ate_menu\":%lld", x->bytes_menu);
  else buf_str(&b, ",\"bytes_ate_menu\":null");
  buf_str(&b, ",\"carregou_por\":");
  buf_json(&b, x->carregou_por);
  buf_fmt(&b, ",\"reaberto\":%d,\"trecho\":", x->reaberto);
  if(x->tem_res) {
    buf_str(&b, "{\"x\":0");
    num_json(&b, "bloco_ms", x->res.bloco_ms, 3);
    num_json(&b, "leitura_ms", x->res.leitura_ms, 3);
    num_json(&b, "decode_us", x->res.decode_us, 3);
    num_json(&b, "cache_pct", x->res.cache_pct, 2);
    num_json(&b, "peso_decode_pct", x->res.peso_decode_pct, 2);
    num_json(&b, "disco_kib", x->res.disco_kib, 1);
    num_json(&b, "low1", x->res.low1, 1);
    num_json(&b, "pior_ms", x->res.pior_ms, 1);
    num_json(&b, "segundos", x->res.segundos, 0);
    buf_str(&b, "}");
  } else buf_str(&b, "null");
  num_json(&b, "fps_media", x->fps_media, 1);
  num_json(&b, "temp_max", x->temp_max, 0);
  buf_str(&b, ",\"medida\":");
  buf_json(&b, x->medida);
  buf_str(&b, ",\"fechar\":");
  buf_json(&b, x->fechar);
  buf_str(&b, ",\"dump\":");
  buf_json(&b, x->dump);
  buf_str(&b, ",\"erro\":");
  buf_json(&b, x->erro);
  buf_fmt(&b, ",\"hora\":%lld}\n", (long long)time(NULL));
  char c[TAM_C];
  arq_bat(c, sizeof c, "resultados.jsonl");
  int fd = open(c, O_WRONLY | O_CREAT | O_APPEND, 0644);
  if(fd >= 0) {
    if(write(fd, b.d, b.n) != (ssize_t)b.n) diario("bateria: resultado nao gravou inteiro");
    fsync(fd);
    close(fd);
  }
  diario("bateria: rodada %d (%s) rep %d/%d: %s (%s), menu %.1f s, fechar %s%s%s", ir + 1, r->id, rep + 1, r->repeticoes, x->resultado,
         x->compat, x->t_carregado, x->fechar, x->erro[0] ? ", " : "", x->erro);
  buf_free(&b);
}

/* ------------------------------------------------------------------ vigia (temperatura, espaco, ShadowKraken) */

static long long g_sk_sumiu_ms;

/* 0 = tudo bem; 1 = parar a bateria (erro definido) */
static int vigiar(const plano_t *pl, const char *ativa) {
  int t = temperatura();
  if(t >= pl->cfg.temp_max_c) {
    erro_def("temperatura %d C (limite %d C): bateria parada", t, pl->cfg.temp_max_c);
    return 1;
  }
  long long l = livre_mib(ativa);
  if(l >= 0 && l < pl->cfg.livre_min_mib) {
    erro_def("espaco livre baixo (%lld MiB, minimo %d MiB): bateria parada", l, pl->cfg.livre_min_mib);
    return 1;
  }
  if(!plataforma_processo_rodando("shadowmountplus.elf") && !sk_vivo()) {
    if(!g_sk_sumiu_ms) g_sk_sumiu_ms = agora_ms();
    if(seg_desde(g_sk_sumiu_ms) >= pl->cfg.sk_fora_s) {
      erro_def("o ShadowKraken sumiu (sem processo e sem resposta ha %d s): bateria parada", pl->cfg.sk_fora_s);
      return 1;
    }
  } else g_sk_sumiu_ms = 0;
  return 0;
}

/* ------------------------------------------------------------------ fechar o jogo */

static int esperar_fechar(const char *tid, int segundos) {
  long long t0 = agora_ms();
  while(seg_desde(t0) < segundos) {
    if(app_aberto(tid) == 0) return 1;
    usleep((useconds_t)(seg_ms() / 4 * 1000 + 1000));
  }
  return app_aberto(tid) == 0;
}

static void sequencia(const cfg_t *c, const char l[][24], int n) {
  for(int i = 0; i < n; i++) {
    if(!strncmp(l[i], "espera:", 7)) pad_esperar(atoi(l[i] + 7));
    else pad_apertar(pad_botao(l[i]), c->botao_ms, c->botao_depois_ms);
  }
}

/* Fecha SO o titulo que a bateria abriu: controle virtual (sequencia do plano) e, se nao fechou, KillApp. metodo recebe
   pad | kill | kill_sys | ja_fechado | falhou. 0 = fechado. */
static int fechar_jogo(const plano_t *pl, const char *tid, char *metodo, size_t tm) {
  snprintf(metodo, tm, "falhou");
  pthread_mutex_lock(&g_trava);
  int nosso = !strcmp(g.aberto_bat, tid);
  pthread_mutex_unlock(&g_trava);
  if(app_aberto(tid) == 0) {
    snprintf(metodo, tm, "ja_fechado");
    return 0;
  }
  char outro[16];
  if(!nosso || app_de_jogo_aberto(outro, sizeof outro) != 1 || strcmp(outro, tid)) {
    diario("bateria: nao fecha %s: nao foi a bateria que abriu (ou ha outro jogo aberto)", tid);
    return -1;
  }
  if(pl->cfg.fechar_metodo == 0) {
    char e[120];
    int r = pad_abrir(pl->cfg.pad_repouso_ms, e, sizeof e);
    if(!r) {
      sequencia(&pl->cfg, pl->cfg.fechar, pl->cfg.nfechar);
      pad_fechar();
#ifndef __PROSPERO__
      if(getenv("GLR_TESTE_PAD_FECHA")) teste_abertos(tid, 0);
#endif
      if(esperar_fechar(tid, pl->cfg.fechar_pad_espera_s)) {
        snprintf(metodo, tm, "pad");
        diario("bateria: %s fechado pelo controle virtual", tid);
        return 0;
      }
      diario("bateria: o controle virtual nao fechou %s em %d s: reserva KillApp", tid, pl->cfg.fechar_pad_espera_s);
    } else diario("bateria: controle virtual nao criado (%s): reserva KillApp", e);
  }
  int appid = lancador_appid(tid);
#ifdef __PROSPERO__
  if(appid >= 0 && sceLncUtilKillApp) {
    int r = sceLncUtilKillApp((uint32_t)appid);
    diario("bateria: sceLncUtilKillApp(0x%08x) %s = 0x%08x", (unsigned)appid, tid, (unsigned)r);
    if(!r && esperar_fechar(tid, pl->cfg.fechar_espera_s)) {
      snprintf(metodo, tm, "kill");
      return 0;
    }
  }
  appid = lancador_appid(tid);
  if(appid >= 0 && sceSystemServiceKillApp) {
    int r = sceSystemServiceKillApp(appid, -1, 0, 0);
    diario("bateria: sceSystemServiceKillApp(0x%08x,-1,0,0) %s = 0x%08x", (unsigned)appid, tid, (unsigned)r);
    if(!r && esperar_fechar(tid, pl->cfg.fechar_espera_s)) {
      snprintf(metodo, tm, "kill_sys");
      return 0;
    }
  }
#else
  (void)appid;
  const char *k = getenv("GLR_TESTE_KILL");
  if(!k || strcmp(k, "falha")) {
    int sys = k && !strcmp(k, "sys");
    teste_log("kill %s %s\n", tid, sys ? "sceSystemServiceKillApp" : "sceLncUtilKillApp");
    teste_abertos(tid, 0);
    if(esperar_fechar(tid, pl->cfg.fechar_espera_s)) {
      snprintf(metodo, tm, "%s", sys ? "kill_sys" : "kill");
      return 0;
    }
  } else teste_log("kill %s %s\n", tid, "falhou");
#endif
  diario("bateria: %s nao fechou nem com KillApp", tid);
  return -1;
}

/* desmonta pelo ShadowKraken depois de fechar (409 = ocupado: tenta a cada 5 s) */
static void desmontar(const plano_t *pl, const char *tid) {
  char corpo[64];
  snprintf(corpo, sizeof corpo, "{\"title_id\":\"%.12s\"}", tid);
  long long t0 = agora_ms();
  for(;;) {
    buf_t r = {0};
    int st = apps_smp_pedir("/api/v1/games/unmount", corpo, &r, 30);
    buf_free(&r);
    if(st != 409 || seg_desde(t0) >= pl->cfg.desmontar_espera_s) {
      diario("bateria: desmontar %s pelo ShadowKraken: HTTP %d", tid, st);
      return;
    }
    if(dormir(5)) return;
  }
}

/* ------------------------------------------------------------------ trocar a versao ativa */

static int trocar(const plano_t *pl, const rodada_t *r, char *e, size_t te) {
  const jogo_t *j = &pl->jogos[r->jogo];
  char at[TAM_C];
  struct stat s;
  caminho_ativo(j, r->versao, at, sizeof at);
  int ja = !lstat(at, &s);
  if(ja && !lstat(j->v[r->versao].caminho, &s)) {   /* nas duas pastas: algo apareceu no destino; nao mexe */
    snprintf(e, te, "%s existe na pasta guardada e na ativa (%s): resolva na mao", base_de(at), j->ativa);
    return -1;
  }
  for(int k = 0; k < j->nv; k++) {   /* tira as outras versoes da pasta ativa */
    if(k == r->versao) continue;
    char ak[TAM_C];
    caminho_ativo(j, k, ak, sizeof ak);
    if(lstat(ak, &s)) continue;
    backup_res_t br;
    if(backup_soltar(ak, &br)) {
      snprintf(e, te, "o ShadowKraken nao soltou %s (%s %s)", ak, br.chave, br.detalhe);
      return -1;
    }
    if(mover(ak, j->v[k].caminho, e, te)) return -1;
  }
  if(!ja) {
    if(lstat(j->v[r->versao].caminho, &s)) {
      snprintf(e, te, "a versao %s sumiu de %s", j->v[r->versao].nome, j->v[r->versao].caminho);
      return -1;
    }
    if(termina(at, ".pkg") && S_ISREG(s.st_mode)) {   /* o cache fpkg do ShadowKraken ocupa ~o tamanho do .pkg */
      long long l = livre_mib(j->ativa), precisa = (long long)((double)s.st_size * (100 + pl->cfg.folga_pkg_pct) / 100.0 / MIB);
      if(l >= 0 && l < precisa) {
        snprintf(e, te, "espaco livre %lld MiB, o .pkg pede %lld MiB (cache do ShadowKraken + %d%%)", l, precisa, pl->cfg.folga_pkg_pct);
        return -1;
      }
    }
    if(mover(j->v[r->versao].caminho, at, e, te)) return -1;
  }
  pedir_releitura();
  return 0;
}

/* fpkg/progress: 1 = o ShadowKraken esta preparando este titulo (marca = bytes+conferido, para ver se anda) */
static int preparando(const char *tid, long long *marca) {
  buf_t r = {0};
  int st = apps_smp_get("/api/v1/fpkg/progress", &r, 2);
  if(st == 404 || st == 405) {
    buf_free(&r);
    st = apps_smp_pedir("/api/v1/fpkg/progress", "{}", &r, 2);
  }
  int sim = 0;
  if(st == 200 && r.d) {
    buf_add(&r, "", 1);
    js_t o = {r.d, r.d + r.n - 1}, v;
    char id[16] = "";
    if(js_campo(&o, "active", &v) && js_verdade(&v) && js_campo(&o, "title_id", &v) && !js_string(&v, id, sizeof id) && !strcmp(id, tid)) {
      sim = 1;
      long long m = 0;
      if(js_campo(&o, "bytes", &v)) m += (long long)js_num(&v);
      if(js_campo(&o, "hashed", &v)) m += (long long)js_num(&v);
      *marca = m;
    }
  }
  buf_free(&r);
  return sim;
}

/* espera o ShadowKraken mostrar o titulo com o caminho e o formato da versao pedida. 0 = ok. */
static int esperar_sk(const plano_t *pl, const rodada_t *r, rep_t *x, char *e, size_t te) {
  const jogo_t *j = &pl->jogos[r->jogo];
  char at[TAM_C], tipo[16], imagem[16];
  struct stat s;
  caminho_ativo(j, r->versao, at, sizeof at);
  formato_esperado(at, !lstat(at, &s) && S_ISDIR(s.st_mode), tipo, sizeof tipo, imagem, sizeof imagem);
  long long t0 = agora_ms(), ult_releitura = agora_ms(), marca = -1;
  for(;;) {
    sk_jogo_t k;
    if(sk_jogo(j->tid, &k)) {
      for(int a = 0; a < k.achados && a < 4; a++) {
        if(strcmp(k.path[a], at)) continue;
        if(k.disponivel == 0) break;
        int tipo_ok = !strcmp(k.tipo, tipo) && (!imagem[0] || strstr(k.imagem, imagem));
        if(tipo_ok) {
          snprintf(x->formato_sk, sizeof x->formato_sk, "%s%s%s", k.tipo, k.imagem[0] ? "/" : "", k.imagem);
          return 0;
        }
        snprintf(x->formato_sk, sizeof x->formato_sk, "%s%s%s", k.tipo, k.imagem[0] ? "/" : "", k.imagem);
      }
    }
    long long m = -1;
    if(preparando(j->tid, &m)) {   /* preparando o cache do .pkg: sem limite fixo enquanto anda */
      if(m != marca) {
        marca = m;
        t0 = agora_ms();
        definir(NULL, NULL, "ShadowKraken preparando o .pkg de %s", j->tid);
      } else if(seg_desde(t0) >= pl->cfg.prep_parado_s) {
        snprintf(e, te, "o ShadowKraken parou de preparar %s ha %d s", j->tid, pl->cfg.prep_parado_s);
        return -1;
      }
    } else if(seg_desde(t0) >= pl->cfg.sk_espera_s) {
      snprintf(e, te, "o ShadowKraken nao mostrou %s com %s (%s%s%s) em %d s (visto: %s)", j->tid, base_de(at), tipo, imagem[0] ? "/" : "",
               imagem, pl->cfg.sk_espera_s, x->formato_sk[0] ? x->formato_sk : "nada");
      return -1;
    }
    if(seg_desde(ult_releitura) >= 60) {   /* releitura adiada (jogo/runtime): pede de novo */
      pedir_releitura();
      ult_releitura = agora_ms();
    }
    if(dormir(5)) return 1;
  }
}

/* ------------------------------------------------------------------ ampr */

static int preparar_ampr(const rodada_t *r, char *e, size_t te) {
  if(strcmp(r->ampr, "manter")) {
    char atual[TAM_C], sha_at[65] = "";
    int tem = ampr_teste_runtime(atual, sizeof atual, sha_at, NULL, 0, NULL, 0, NULL);
    if(!strcmp(r->ampr, "embutido")) {
      if(tem) {
        pthread_mutex_lock(&g_trava);
        g.ampr_mexeu = 1;
        pthread_mutex_unlock(&g_trava);
        salvar_estado();
        if(ampr_teste_embutido(e, te)) return -1;
      }
    } else {
      char pb[TAM_C], c[TAM_C + 140], sha[65];
      pasta_builds(pb, sizeof pb);
      snprintf(c, sizeof c, "%s/%s", pb, r->ampr);
      if(ampr_teste_conferir_arquivo(c, sha, NULL, 0, NULL, 0, NULL)) {
        snprintf(e, te, "%s nao e um ampr-emu-ng valido", c);
        return -1;
      }
      if(!tem || strcmp(sha, sha_at)) {
        pthread_mutex_lock(&g_trava);
        g.ampr_mexeu = 1;
        pthread_mutex_unlock(&g_trava);
        salvar_estado();
        if(ampr_teste_instalar_arquivo(c, e, te)) return -1;
      }
    }
  }
  /* ajustes: a base e sempre o padrao (o arquivo de ajustes sai antes de abrir); os pares vao por /set depois de
     carregar (o formato do arquivo nao e conhecido: Q6 do desenho) */
  pthread_mutex_lock(&g_trava);
  g.tune_mexeu = 1;
  pthread_mutex_unlock(&g_trava);
  salvar_estado();
  if(ampr_padrao() < 0) {
    snprintf(e, te, "nao apagou o arquivo de ajustes do ampr");
    return -1;
  }
  return 0;
}

/* ------------------------------------------------------------------ abrir e carregar */

static int abrir(const char *tid, char *e, size_t te) {
  static const int PAUSAS[] = {0, 5, 10, 20};
  for(int i = 0; i < 3; i++) {
    if(i && dormir(PAUSAS[i])) return 1;
    char outro[16];
    int ab = app_de_jogo_aberto(outro, sizeof outro);
    if(ab == 1 && !strcmp(outro, tid)) return 0;
    if(ab != 0) {
      snprintf(e, te, "outro app aberto (%s)", ab > 0 ? outro : "nao deu para saber");
      continue;
    }
    pthread_mutex_lock(&g_trava);
    snprintf(g.aberto_bat, sizeof g.aberto_bat, "%s", tid);
    pthread_mutex_unlock(&g_trava);
    salvar_estado();
    int r = abrir_app(tid);
    diario("bateria: abrir %s tentativa %d -> 0x%08x", tid, i + 1, (unsigned)r);
    if(!r) {
#ifndef __PROSPERO__
      if(getenv("GLR_TESTE_BAT_ABRE")) teste_abertos(tid, 1);
#endif
      return 0;
    }
    snprintf(e, te, "sceSystemServiceLaunchApp 0x%08x", (unsigned)r);
  }
  return -1;
}

typedef struct {
  long long t;            /* ms */
  int vivo, foco, tem9090;
  unsigned long long bytes;
  double fps;
} am_t;

enum { C_CARREGOU = 0, C_QUEDA, C_NAO_CARREGOU, C_PARAR };

/* Heuristica de "chegou ao menu" (sec. 4 do desenho; limites no plano). */
static int carregar(const plano_t *pl, const rodada_t *r, const char *tid, rep_t *x) {
  const cfg_t *c = &pl->cfg;
  static am_t a[AMOSTRAS_MAX];
  int n = 0, viu_vivo = 0;
  long long t0 = agora_ms();
  long sm = seg_ms();
  int nj = c->janela_s / c->amostra_s, ns = c->sem9090_s / c->amostra_s;
  if(nj < 3) nj = 3;
  if(ns < 3) ns = 3;
  if(nj + 1 > AMOSTRAS_MAX) nj = AMOSTRAS_MAX - 1;
  if(ns + 1 > AMOSTRAS_MAX) ns = AMOSTRAS_MAX - 1;
  x->t_tela = x->t_ampr = x->t_carregado = -1;
  x->bytes_menu = -1;
  for(;;) {
    if(cancelado()) return C_PARAR;
    double el = seg_desde(t0);
    if(el > r->carregar_max_s) {
      snprintf(x->carregou_por, sizeof x->carregou_por, "%s", viu_vivo ? "nao_estabilizou" : "nao_abriu");
      return C_NAO_CARREGOU;
    }
    if(vigiar(pl, pl->jogos[r->jogo].ativa)) return C_PARAR;
    am_t s = {agora_ms(), 0, 0, 0, 0, -1};
    s.vivo = app_aberto(tid) == 1;
    if(s.vivo) viu_vivo = 1;
    else if(viu_vivo) return C_QUEDA;
    s.foco = s.vivo && em_foco(tid, c->exigir_foco);
    ampr_cont4_t k;
    s.tem9090 = ampr_contadores(&k) == 1 && k.tem_bytes;
    s.bytes = k.apr_read_bytes;
    if(s.tem9090 && x->t_ampr < 0) x->t_ampr = el;
    if(c->fps && s.vivo) s.fps = ler_fps();
    if(s.vivo && s.foco && x->t_tela < 0) x->t_tela = el;
    if(n == AMOSTRAS_MAX) {
      memmove(a, a + 1, sizeof a[0] * (AMOSTRAS_MAX - 1));
      n--;
    }
    a[n++] = s;
    pthread_mutex_lock(&g_trava);
    g.t_tela = x->t_tela;
    snprintf(g.carregar, sizeof g.carregar, "%s%s%s, %.0f s", s.vivo ? "vivo" : "esperando abrir", s.tem9090 ? ", 9090 no ar" : "",
             s.fps > 0 ? ", com FPS" : "", el);
    pthread_mutex_unlock(&g_trava);
    if(x->t_tela >= 0 && el - x->t_tela >= c->min_tela_s) {
      int janela = a[n - 1].tem9090 ? nj : ns;
      if(n >= janela + 1) {
        const am_t *w = &a[n - janela - 1];
        int ok = 1, com9090 = 1, todos_fps = 1;
        for(int i = 0; i <= janela; i++) {
          ok &= w[i].vivo && w[i].foco;
          com9090 &= w[i].tem9090;
          todos_fps &= w[i].fps > 0;
        }
        double dur = (double)(w[janela].t - w[0].t) / (double)sm;
        if(ok && dur > 0 && com9090) {
          double taxa = (double)(w[janela].bytes - w[0].bytes) / MIB / dur;
          ok = taxa < c->calmo_mib_s;
          for(int i = 1; ok && i <= janela; i++) ok = (double)(w[i].bytes - w[i - 1].bytes) / MIB <= c->pico_mib;
        }
        if(ok && !com9090 && !todos_fps) ok = 0;   /* sem 9090 e sem FPS: nao da para saber */
        if(ok && todos_fps) {
          double m = 0, v = 0;
          for(int i = 0; i <= janela; i++) m += w[i].fps;
          m /= janela + 1;
          for(int i = 0; i <= janela; i++) v += (w[i].fps - m) * (w[i].fps - m);
          double dp = sqrt(v / (janela + 1));
          ok = m >= c->fps_min && dp / m * 100 < c->fps_desvio_pct;
        }
        if(ok) {
          x->t_carregado = (double)(w[0].t - t0) / (double)sm;
          x->bytes_menu = com9090 ? (long long)w[0].bytes : -1;
          snprintf(x->carregou_por, sizeof x->carregou_por, "%s", com9090 ? (todos_fps ? "io+fps" : "io") : "fps");
          return C_CARREGOU;
        }
      }
    }
    long long passo = (long long)c->amostra_s * sm - (agora_ms() - s.t);
    if(passo > 0 && dormir((double)passo / (double)sm)) return C_PARAR;
  }
}

/* espera "segundos" com o jogo vivo; 1 = queda, 2 = parar; tambem amostra FPS e temperatura (sem o 9090) */
static int esperar_vivo(const plano_t *pl, const char *tid, const char *ativa, int segundos, rep_t *x) {
  long long t0 = agora_ms();
  double soma = 0;
  int nf = 0;
  while(seg_desde(t0) < segundos) {
    if(cancelado() || vigiar(pl, ativa)) return 2;
    if(app_aberto(tid) == 0) return 1;
    int t = temperatura();
    if(t > x->temp_max) x->temp_max = t;
    if(pl->cfg.fps) {
      double f = ler_fps();
      if(f > 0) {
        soma += f;
        nf++;
      }
    }
    if(dormir(1)) return 2;
  }
  if(nf && x->fps_media < 0) x->fps_media = soma / nf;
  return 0;
}

/* ------------------------------------------------------------------ a repeticao inteira */

static int repeticao(const plano_t *pl, int ir, int rep) {
  const rodada_t *r = &pl->r[ir];
  const jogo_t *j = &pl->jogos[r->jogo];
  static rep_t x;
  memset(&x, 0, sizeof x);
  x.t_tela = x.t_ampr = x.t_carregado = x.fps_media = x.temp_max = -1;
  x.bytes_menu = -1;
  snprintf(x.fechar, sizeof x.fechar, "nao_precisou");
  char e[300] = "";
  time_t inicio = time(NULL);
  pthread_mutex_lock(&g_trava);
  g.t_tela = g.t_carregado = -1;
  g.carregar[0] = 0;
  pthread_mutex_unlock(&g_trava);

  /* 1 PREPARAR */
  definir(NULL, "preparar", "rodada %d/%d (%s), repeticao %d/%d: %s %s", ir + 1, pl->nr, r->id, rep + 1, r->repeticoes, j->tid,
          j->v[r->versao].nome);
  long long t0 = agora_ms();
  while(!sk_vivo()) {   /* ShadowKraken no ar */
    if(seg_desde(t0) >= pl->cfg.sk_fora_s) {
      erro_def("o ShadowKraken nao responde ha %d s", pl->cfg.sk_fora_s);
      return RP_PARAR;
    }
    if(dormir(5)) return RP_PARAR;
  }
  t0 = agora_ms();
  for(;;) {   /* nada aberto (o dono jogando = espera) */
    char outro[16];
    int ab = app_de_jogo_aberto(outro, sizeof outro);
    if(ab == 0) break;
    pthread_mutex_lock(&g_trava);
    int nosso = ab == 1 && !strcmp(outro, g.aberto_bat);
    pthread_mutex_unlock(&g_trava);
    if(nosso) {   /* sobrou da repeticao interrompida (glibren reaberto) */
      char m[16];
      if(fechar_jogo(pl, outro, m, sizeof m)) {
        erro_def("o jogo %s que a bateria abriu nao fechou", outro);
        return RP_PARAR;
      }
      continue;
    }
    if(seg_desde(t0) >= pl->cfg.espera_dono_s) {
      erro_def("um jogo que a bateria nao abriu continua aberto (%s) ha %d s: bateria parada", ab > 0 ? outro : "?", pl->cfg.espera_dono_s);
      return RP_PARAR;
    }
    definir(NULL, NULL, "esperando: ha um jogo aberto que a bateria nao abriu (%s)", ab > 0 ? outro : "?");
    if(dormir(5)) return RP_PARAR;
  }
  t0 = agora_ms();
  for(;;) {   /* console frio */
    int t = temperatura();
    if(t < 0 || t <= pl->cfg.esfriar_ate_c) break;
    if(seg_desde(t0) >= pl->cfg.espera_temp_s) {
      erro_def("o console nao esfriou ate %d C em %d s (agora %d C)", pl->cfg.esfriar_ate_c, pl->cfg.espera_temp_s, t);
      return RP_PARAR;
    }
    definir(NULL, NULL, "esperando esfriar: %d C (quer %d C)", t, pl->cfg.esfriar_ate_c);
    if(dormir(5)) return RP_PARAR;
  }
  if(vigiar(pl, j->ativa)) return RP_PARAR;

  /* 2 TROCAR */
  definir(NULL, "trocar", "pondo %s (%s) na pasta ativa", j->v[r->versao].nome, base_de(j->v[r->versao].caminho));
  if(trocar(pl, r, e, sizeof e)) {
    erro_def("trocar a versao: %s", e);
    return RP_PARAR;
  }
  /* 3 ESPERAR_SK */
  definir(NULL, "esperar_sk", "esperando o ShadowKraken mostrar %s", base_de(j->v[r->versao].caminho));
  int w = esperar_sk(pl, r, &x, e, sizeof e);
  if(w) {
    if(w > 0) return RP_PARAR;
    erro_def("formato: %s", e);
    return RP_PARAR;
  }
  /* 4 AMPR */
  definir(NULL, "ampr", "ampr-emu-ng: %s", r->ampr);
  if(preparar_ampr(r, e, sizeof e)) {
    erro_def("ampr: %s", e);
    return RP_PARAR;
  }

  int reabrir = 0;
abrir_de_novo:
  /* 5 ABRIR */
  definir(NULL, "abrir", "abrindo %s", j->tid);
  int a = abrir(j->tid, e, sizeof e);
  if(a > 0) return RP_PARAR;
  if(a < 0) {
    snprintf(x.resultado, sizeof x.resultado, "falha_abrir");
    snprintf(x.compat, sizeof x.compat, "nao_abriu");
    snprintf(x.erro, sizeof x.erro, "%s", e);
    gravar_resultado(pl, ir, rep, &x);
    return RP_QUEDA;
  }
  /* 6 CARREGAR */
  definir(NULL, "carregar", "esperando %s chegar ao menu (ate %d s)", j->tid, r->carregar_max_s);
  int cr = carregar(pl, r, j->tid, &x);
  ampr_build_atual(x.build, sizeof x.build, x.fmt_ampr, sizeof x.fmt_ampr);
  pthread_mutex_lock(&g_trava);
  g.t_tela = x.t_tela;
  g.t_carregado = x.t_carregado;
  pthread_mutex_unlock(&g_trava);
  if(cr == C_PARAR) {
    char m[16];
    fechar_jogo(pl, j->tid, m, sizeof m);
    return RP_PARAR;
  }
  if(cr == C_QUEDA) {
    snprintf(x.resultado, sizeof x.resultado, "queda");
    snprintf(x.compat, sizeof x.compat, "caiu");
    snprintf(x.fechar, sizeof x.fechar, "caiu");
    if(dormir(5)) return RP_PARAR;
    achar_dump(j->tid, inicio, x.dump, sizeof x.dump);
    gravar_resultado(pl, ir, rep, &x);
    notificar("bateria: %s caiu ao carregar (rodada %d/%d)", j->tid, ir + 1, pl->nr);
    pthread_mutex_lock(&g_trava);
    g.aberto_bat[0] = 0;
    pthread_mutex_unlock(&g_trava);
    desmontar(pl, j->tid);
    return RP_QUEDA;
  }
  int carregou = cr == C_CARREGOU;
  if(carregou && pl->cfg.ninicio) {   /* botoes opcionais depois de abrir (plano; padrao: nenhum) */
    char pe[120];
    if(!pad_abrir(pl->cfg.pad_repouso_ms, pe, sizeof pe)) {
      sequencia(&pl->cfg, pl->cfg.inicio, pl->cfg.ninicio);
      pad_fechar();
    } else diario("bateria: sequencia_inicio sem controle virtual (%s)", pe);
  }
  /* 7 AJUSTAR */
  if(carregou && r->aj_objeto && !reabrir) {
    definir(NULL, "ajustar", "aplicando %d ajuste(s) no ampr", r->naj);
    int prox = 0;
    int st = ampr_aplicar_pares((char (*)[AMPR_AJ_NOME + 1])r->aj_nomes, r->aj_vals, r->naj, x.ajustes_erro, sizeof x.ajustes_erro,
                                x.ignorados, sizeof x.ignorados, &prox);
    if(st) diario("bateria: ajustes nao aplicados: %s", x.ajustes_erro);
    else if(prox && pl->cfg.reabrir_proxima) {   /* ajuste "na proxima abertura": fecha e abre de novo */
      definir(NULL, "fechar", "reabrindo %s para valer os ajustes da proxima abertura", j->tid);
      if(fechar_jogo(pl, j->tid, x.fechar, sizeof x.fechar)) {
        snprintf(x.resultado, sizeof x.resultado, "travou");
        snprintf(x.compat, sizeof x.compat, "travou");
        gravar_resultado(pl, ir, rep, &x);
        erro_def("o jogo %s nao fechou (nem com KillApp)", j->tid);
        return RP_PARAR;
      }
      desmontar(pl, j->tid);
      reabrir = x.reaberto = 1;
      if(dormir(10)) return RP_PARAR;
      goto abrir_de_novo;
    }
  }
  /* 8 TRECHO */
  int q = 0;
  if(carregou) {
    char nota[200], cab[400];
    snprintf(nota, sizeof nota, "bateria %s %s r%d/%d %s %s", pl->id, r->id, rep + 1, r->repeticoes, j->v[r->versao].nome, r->ampr);
    snprintf(cab, sizeof cab, "bateria: %s %s rep %d/%d versao=%s ampr=%s t_tela=%.1f t_carregado=%.1f resultado=carregou\n", pl->id,
             r->id, rep + 1, r->repeticoes, j->v[r->versao].nome, r->ampr, x.t_tela, x.t_carregado);
    if(r->compat) {
      definir(NULL, "trecho", "compatibilidade: %d s no menu", pl->cfg.compat_s);
      q = esperar_vivo(pl, j->tid, j->ativa, pl->cfg.compat_s, &x);
      if(!q && ampr_dep_no_ar()) ampr_medir_curto(nota, cab, x.medida, sizeof x.medida);
    } else {
      definir(NULL, "trecho", "trecho de %d s", r->trecho_s);
      char et[200];
      int com_ampr = !ampr_trecho_comecar(pl->cfg.fps, et, sizeof et);
      if(!com_ampr) diario("bateria: trecho sem o ampr de depuracao (%s): so FPS e temperatura", et);
      q = esperar_vivo(pl, j->tid, j->ativa, r->trecho_s, &x);
      if(com_ampr) {
        if(!q && !ampr_trecho_terminar(nota, cab, x.medida, sizeof x.medida, &x.res, et, sizeof et)) {
          x.tem_res = 1;
          if(x.res.fps_media > 0) x.fps_media = x.res.fps_media;
          if(x.res.temp_max > x.temp_max) x.temp_max = x.res.temp_max;
        } else ampr_trecho_desistir();
      }
    }
  }
  if(q == 2) {
    char m[16];
    fechar_jogo(pl, j->tid, m, sizeof m);
    return RP_PARAR;
  }
  if(q == 1) {
    snprintf(x.resultado, sizeof x.resultado, "queda");
    snprintf(x.compat, sizeof x.compat, "caiu");
    snprintf(x.fechar, sizeof x.fechar, "caiu");
    if(dormir(5)) return RP_PARAR;
    achar_dump(j->tid, inicio, x.dump, sizeof x.dump);
    gravar_resultado(pl, ir, rep, &x);
    pthread_mutex_lock(&g_trava);
    g.aberto_bat[0] = 0;
    pthread_mutex_unlock(&g_trava);
    desmontar(pl, j->tid);
    return RP_QUEDA;
  }
  /* 9 FECHAR */
  definir(NULL, "fechar", "fechando %s", j->tid);
  if(fechar_jogo(pl, j->tid, x.fechar, sizeof x.fechar)) {
    snprintf(x.resultado, sizeof x.resultado, "travou");
    snprintf(x.compat, sizeof x.compat, "travou");
    gravar_resultado(pl, ir, rep, &x);
    erro_def("o jogo %s nao fechou (nem com KillApp)", j->tid);
    return RP_PARAR;
  }
  pthread_mutex_lock(&g_trava);
  g.aberto_bat[0] = 0;
  pthread_mutex_unlock(&g_trava);
  salvar_estado();
  desmontar(pl, j->tid);
  snprintf(x.resultado, sizeof x.resultado, "%s", carregou ? "ok" : "nao_carregou");
  snprintf(x.compat, sizeof x.compat, "%s", carregou ? "carregou" : "abriu");
  gravar_resultado(pl, ir, rep, &x);
  if(carregou) notificar("bateria: rodada %d/%d rep %d/%d ok, menu em %.0f s", ir + 1, pl->nr, rep + 1, r->repeticoes, x.t_carregado);
  else notificar("bateria: rodada %d/%d: %s nao estabilizou em %d s", ir + 1, pl->nr, j->tid, r->carregar_max_s);
  /* 10 ESFRIAR */
  definir(NULL, "esfriar", "esfriando %d s", r->esfriar_s);
  if(dormir(r->esfriar_s)) return RP_PARAR;
  t0 = agora_ms();
  for(;;) {
    int t = temperatura();
    if(t < 0 || t <= pl->cfg.esfriar_ate_c || seg_desde(t0) >= pl->cfg.esfriar_extra_s) break;
    definir(NULL, NULL, "esfriando: %d C (quer %d C)", t, pl->cfg.esfriar_ate_c);
    if(dormir(5)) return RP_PARAR;
  }
  return RP_OK;
}

/* ================================================================== relatorio */

typedef struct {
  char id[32], nome[96], versao[24], fmt[48], ampr[128], build[160], ajustes[300];
  int rodada, reps, ok, quedas, nao_carregou, falha_abrir, travou, compat;
  double carregado[5], leitura[5], bloco[5], fps[5], low[5];
  int nc, nl, nb, nfp, nlo;
  char dump[96], erro[200];
} agg_t;

static double num_linha(const js_t *o, const char *k1, const char *k2) {
  js_t v, w;
  if(!js_campo(o, k1, &v)) return -1;
  if(k2) {
    if(*v.p != '{' || !js_campo(&v, k2, &w)) return -1;
    v = w;
  }
  return eh_num(&v) ? strtod(v.p, NULL) : -1;
}

static int cmp_d(const void *a, const void *b) {
  double x = *(const double *)a, y = *(const double *)b;
  return x < y ? -1 : x > y;
}

static void med(buf_t *b, double *v, int n, int casas) {
  if(!n) {
    buf_str(b, " - |");
    return;
  }
  qsort(v, (size_t)n, sizeof v[0], cmp_d);
  double m = n % 2 ? v[n / 2] : (v[n / 2 - 1] + v[n / 2]) / 2;
  if(n == 1) buf_fmt(b, " %.*f |", casas, m);
  else buf_fmt(b, " %.*f (%.*f-%.*f) |", casas, m, casas, v[0], casas, v[n - 1]);
}

static void md_texto(buf_t *b, const char *s) {   /* sem | nem quebra de linha dentro da tabela */
  for(; *s; s++) {
    if(*s == '|') buf_str(b, "/");
    else if((unsigned char)*s < ' ') buf_str(b, " ");
    else buf_add(b, s, 1);
  }
}

/* 0.9.64: relatorio publico: alem da higienizacao do diagnostico, nenhum IPv4 (a.b.c.d vira x.x.x.x). */
static void sem_ip(char *t, size_t n) {
  for(size_t i = 0; i < n; i++) {
    if(!isdigit((unsigned char)t[i]) || (i && (isalnum((unsigned char)t[i - 1]) || t[i - 1] == '.'))) continue;
    size_t j = i;
    int partes = 0, ok = 1;
    while(partes < 4) {
      size_t k = j;
      while(k < n && isdigit((unsigned char)t[k]) && k - j < 3) k++;
      if(k == j || (k < n && isdigit((unsigned char)t[k]))) {
        ok = 0;
        break;
      }
      partes++;
      j = k;
      if(partes < 4) {
        if(j >= n || t[j] != '.') {
          ok = 0;
          break;
        }
        j++;
      }
    }
    if(!ok || partes != 4 || (j < n && (isalnum((unsigned char)t[j]) || (t[j] == '.' && j + 1 < n && isdigit((unsigned char)t[j + 1]))))) continue;
    for(size_t k = i; k < j; k++)
      if(isdigit((unsigned char)t[k])) t[k] = 'x';
    i = j;
  }
}

/* Gera resultado-<id>.json e relatorio-<id>.md. 0 = ok. */
static int gerar_relatorio(const plano_t *pl) {
  static agg_t ag[MAX_RODADAS];
  char c[TAM_C];
  buf_t l = {0}, js = {0}, md = {0};
  memset(ag, 0, sizeof ag);
  arq_bat(c, sizeof c, "resultados.jsonl");
  ler_arquivo(c, &l, 16u * 1024 * 1024);
  buf_fmt(&js, "{\"plano\":");
  buf_json(&js, pl->id);
  buf_str(&js, ",\"titulo\":");
  buf_json(&js, pl->titulo);
  buf_fmt(&js, ",\"glibren\":\"%s\",\"repeticoes\":[", VERSAO);
  int nlin = 0;
  for(char *p = l.d; p && *p;) {
    char *fim = strchr(p, '\n');
    size_t k = fim ? (size_t)(fim - p) : strlen(p);
    if(k > 2 && *p == '{') {
      buf_str(&js, nlin++ ? "," : "");
      buf_add(&js, p, k);
      js_t o = {p, p + k};
      int ir = (int)num_linha(&o, "rodada", NULL) - 1;
      if(ir >= 0 && ir < pl->nr) {
        agg_t *a = &ag[ir];
        char res[24] = "";
        ler_str(&o, "resultado", res, sizeof res);
        a->rodada = ir + 1;
        a->reps++;
        if(!a->id[0]) {
          ler_str(&o, "id", a->id, sizeof a->id);
          ler_str(&o, "nome", a->nome, sizeof a->nome);
          ler_str(&o, "versao", a->versao, sizeof a->versao);
          js_t am;
          if(js_campo(&o, "ampr", &am)) {
            ler_str(&am, "pedido", a->ampr, sizeof a->ampr);
            ler_str(&am, "build", a->build, sizeof a->build);
          }
          ler_str(&o, "ajustes", a->ajustes, sizeof a->ajustes);
          a->compat = pl->r[ir].compat;
        }
        char f[48] = "";
        ler_str(&o, "formato_sk", f, sizeof f);
        if(f[0]) snprintf(a->fmt, sizeof a->fmt, "%s", f);
        if(!strcmp(res, "ok")) {
          a->ok++;
          double v;
          if((v = num_linha(&o, "t_carregado", NULL)) >= 0 && a->nc < 5) a->carregado[a->nc++] = v;
          if((v = num_linha(&o, "trecho", "leitura_ms")) >= 0 && a->nl < 5) a->leitura[a->nl++] = v;
          if((v = num_linha(&o, "trecho", "bloco_ms")) >= 0 && a->nb < 5) a->bloco[a->nb++] = v;
          if((v = num_linha(&o, "fps_media", NULL)) >= 0 && a->nfp < 5) a->fps[a->nfp++] = v;
          if((v = num_linha(&o, "trecho", "low1")) >= 0 && a->nlo < 5) a->low[a->nlo++] = v;
        } else if(!strcmp(res, "queda")) a->quedas++;
        else if(!strcmp(res, "nao_carregou")) a->nao_carregou++;
        else if(!strcmp(res, "falha_abrir")) a->falha_abrir++;
        else a->travou++;
        char d[96] = "", er[200] = "";
        ler_str(&o, "dump", d, sizeof d);
        ler_str(&o, "erro", er, sizeof er);
        if(d[0]) snprintf(a->dump, sizeof a->dump, "%s", d);
        if(er[0]) snprintf(a->erro, sizeof a->erro, "%s", er);
      }
    }
    p = fim ? fim + 1 : NULL;
  }
  buf_str(&js, "]}\n");
  char fw[32] = "";
  payloads_firmware(fw, sizeof fw);
  buf_fmt(&md, "# ampr-emu-ng automated test battery: ");
  md_texto(&md, pl->titulo[0] ? pl->titulo : pl->id);
  buf_fmt(&md, "\n\nPlan `%s`, %d configuration(s).\n\n## Environment\n\n", pl->id, pl->nr);
  buf_fmt(&md, "- Console: PS5, firmware %s, internal SSD\n", fw[0] ? fw : "unknown");
  buf_str(&md, "- Loader: a loader based on kraken-mount (games mounted from .pkg, exFAT images and folders)\n");
  buf_str(&md, "- ampr-emu-ng builds:");
  int nb = 0;
  for(int i = 0; i < pl->nr; i++) {
    if(!ag[i].build[0]) continue;
    int rep = 0;
    for(int k = 0; k < i; k++) rep |= !strcmp(ag[k].build, ag[i].build);
    if(rep) continue;
    buf_str(&md, nb++ ? "; " : " ");
    md_texto(&md, ag[i].build);
  }
  if(!nb) buf_str(&md, " release builds (no debug counters)");
  buf_fmt(&md, "\n- Test harness: glibren %s, automatic battery (no human input during the runs)\n\n## Method\n\n", VERSAO);
  const cfg_t *cf = &pl->cfg;
  buf_fmt(&md, "- Console cooled down between runs (%d s and until CPU/SoC <= %d C); runs abort above %d C.\n", pl->r[0].esfriar_s,
          cf->esfriar_ate_c, cf->temp_max_c);
  buf_fmt(&md, "- Each configuration repeated up to %d time(s); tables show the median (min-max) of the successful runs.\n", cf->repeticoes);
  buf_fmt(&md, "- \"Menu reached\" without input: game alive and focused, then a %d s window with ampr reads below %.1f MiB/s and no "
               "burst above %.0f MiB per %d s sample, and FPS >= %d varying less than %d%% (FPS only when the ampr debug port is "
               "missing, %d s window), at least %d s after the game showed up. Timeout %d s = \"did not settle\".\n",
          cf->janela_s, cf->calmo_mib_s, cf->pico_mib, cf->amostra_s, cf->fps_min, cf->fps_desvio_pct, cf->sem9090_s, cf->min_tela_s,
          cf->carregar_max_s);
  buf_fmt(&md, "- Measured window right after the menu settled: %d s (ampr debug counters, end minus start).\n\n", cf->trecho_s);
  buf_str(&md, "## Performance (median, min-max)\n\n| Game | Format | ampr | Tweaks | Menu (s) | Read (ms/read) | Block (ms) | FPS avg | 1% low | OK runs |\n|---|---|---|---|---|---|---|---|---|---|\n");
  for(int i = 0; i < pl->nr; i++) {
    agg_t *a = &ag[i];
    if(!a->reps || a->compat) continue;
    buf_str(&md, "| ");
    md_texto(&md, a->nome[0] ? a->nome : pl->jogos[pl->r[i].jogo].tid);
    buf_str(&md, " | ");
    md_texto(&md, a->versao);
    if(a->fmt[0]) {
      buf_str(&md, " (");
      md_texto(&md, a->fmt);
      buf_str(&md, ")");
    }
    buf_str(&md, " | ");
    md_texto(&md, a->ampr);
    buf_str(&md, " | ");
    md_texto(&md, a->ajustes);
    buf_str(&md, " |");
    med(&md, a->carregado, a->nc, 1);
    med(&md, a->leitura, a->nl, 3);
    med(&md, a->bloco, a->nb, 3);
    med(&md, a->fps, a->nfp, 1);
    med(&md, a->low, a->nlo, 1);
    buf_fmt(&md, " %d/%d |\n", a->ok, a->reps);
  }
  buf_str(&md, "\n## Compatibility\n\n| Game | Format | ampr | Result | Runs | Notes |\n|---|---|---|---|---|---|\n");
  for(int i = 0; i < pl->nr; i++) {
    agg_t *a = &ag[i];
    if(!a->reps) continue;
    const char *res = a->quedas ? "crash" : a->travou ? "hang (did not close)" : a->falha_abrir ? "failed to launch"
                      : a->nao_carregou ? (a->ok ? "partial (did not settle in some runs)" : "did not settle") : "pass";
    buf_str(&md, "| ");
    md_texto(&md, a->nome[0] ? a->nome : pl->jogos[pl->r[i].jogo].tid);
    buf_str(&md, " | ");
    md_texto(&md, a->versao);
    buf_str(&md, " | ");
    md_texto(&md, a->ampr);
    buf_fmt(&md, " | %s | %d ok, %d crash, %d not settled, %d launch fail | ", res, a->ok, a->quedas, a->nao_carregou, a->falha_abrir);
    if(a->dump[0]) buf_str(&md, "coredump saved; ");
    md_texto(&md, a->erro);
    buf_str(&md, " |\n");
  }
  buf_str(&md, "\nFile names are shown only as `<active>/<file>`; no IPs, account IDs or user names.\n");
  /* higienizado como o diagnostico (chaves, IPs, contas) */
  size_t nl1 = 0, nl2 = 0;
  char *l1 = diagnostico_limpar(js.d ? js.d : "", js.n, &nl1), *l2 = diagnostico_limpar(md.d ? md.d : "", md.n, &nl2);
  if(l1) sem_ip(l1, nl1);
  if(l2) sem_ip(l2, nl2);
  char cj[TAM_C], cm[TAM_C], nj[96], nm[96];
  snprintf(nj, sizeof nj, "resultado-%s.json", pl->id);
  snprintf(nm, sizeof nm, "relatorio-%s.md", pl->id);
  arq_bat(cj, sizeof cj, nj);
  arq_bat(cm, sizeof cm, nm);
  int r = (l1 ? gravar_atomico(cj, l1, nl1) : -1) | (l2 ? gravar_atomico(cm, l2, nl2) : -1);
  free(l1);
  free(l2);
  buf_free(&l);
  buf_free(&js);
  buf_free(&md);
  pthread_mutex_lock(&g_trava);
  snprintf(g.relatorio, sizeof g.relatorio, "%s", r ? "" : nm);
  pthread_mutex_unlock(&g_trava);
  diario("bateria: relatorio %s %s", nm, r ? "NAO gravado" : "gravado");
  return r ? -1 : 0;
}

/* Sobe resultado + relatorio + medidas para glibren/ampr-bateria/<id>/. 0 = tudo subiu. */
static int enviar(const plano_t *pl) {
  char chave[256];
  if(!diagnostico_chave_ler(chave, sizeof chave)) {
    pthread_mutex_lock(&g_trava);
    snprintf(g.envio, sizeof g.envio, "sem chave do GitHub (pagina Diagnostico): nada enviado");
    pthread_mutex_unlock(&g_trava);
    return -1;
  }
  char c[TAM_C], dest[300], nome[96], msg[160];
  int falhas = 0, n = 0;
  snprintf(msg, sizeof msg, "bateria %s (glibren %s)", pl->id, VERSAO);
  static const char *const ARQ[][2] = {{"resultado-%s.json", "resultado.json"}, {"relatorio-%s.md", "relatorio.md"}};
  for(int i = 0; i < 2; i++) {
    struct stat st;
    snprintf(nome, sizeof nome, ARQ[i][0], pl->id);
    arq_bat(c, sizeof c, nome);
    if(lstat(c, &st)) continue;
    snprintf(dest, sizeof dest, "glibren/ampr-bateria/%s/%s", pl->id, ARQ[i][1]);
    diag_partes_t r;
    int s = diagnostico_subir_arquivo(chave, dest, msg, c, 0, (unsigned long long)st.st_size, 8u * 1024 * 1024, 1, &r, NULL);
    falhas += s != 201;
    n++;
  }
  /* as medidas citadas nos resultados */
  buf_t l = {0};
  arq_bat(c, sizeof c, "resultados.jsonl");
  ler_arquivo(c, &l, 16u * 1024 * 1024);
  for(char *p = l.d; p && *p;) {
    char *fim = strchr(p, '\n');
    js_t o = {p, fim ? fim : p + strlen(p)};
    char m[48] = "";
    ler_str(&o, "medida", m, sizeof m);
    if(m[0] && nome_valido(m)) {
      char cm[TAM_C + 64];
      struct stat st;
      snprintf(cm, sizeof cm, "%s/ampr-medidas/%s", g_pasta_dados, m);
      if(!lstat(cm, &st) && S_ISREG(st.st_mode)) {
        snprintf(dest, sizeof dest, "glibren/ampr-bateria/%s/medidas/%s", pl->id, m);
        diag_partes_t r;
        int s = diagnostico_subir_arquivo(chave, dest, msg, cm, 0, (unsigned long long)st.st_size, 8u * 1024 * 1024, 1, &r, NULL);
        falhas += s != 201;
        n++;
      }
    }
    p = fim ? fim + 1 : NULL;
  }
  buf_free(&l);
  memset(chave, 0, sizeof chave);
  pthread_mutex_lock(&g_trava);
  if(falhas) snprintf(g.envio, sizeof g.envio, "%d de %d arquivo(s) nao subiram", falhas, n);
  else snprintf(g.envio, sizeof g.envio, "enviado: ps5-diagnosticos/glibren/ampr-bateria/%s (%d arquivo(s))", pl->id, n);
  pthread_mutex_unlock(&g_trava);
  diario("bateria: envio: %s", g.envio);
  return falhas ? -1 : 0;
}

/* ================================================================== a thread */

enum { T_RODAR = 0, T_DESFAZER, T_ENVIAR };

static void fim_thread(void) {
  pthread_mutex_lock(&g_trava);
  g.rodando_thread = 0;
  g.cancelar = 0;
  g.pausar = 0;
  pthread_cond_broadcast(&g_sinal);
  pthread_mutex_unlock(&g_trava);
}

/* desfaz tudo (journal + ampr + ajustes). 0 = ok. */
static int desfazer_tudo(void) {
  definir(NULL, "desfazer", "desfazendo: as versoes voltam para as pastas guardadas");
  int r = desfazer_journal();
  if(!r) voltar_original();
  return r;
}

static void *trabalho(void *arg) {
  int modo = (int)(intptr_t)arg;
  static char e[300];
  pthread_mutex_lock(&g_trava_plano);
  plano_t *pl = &g_plano;
  if(modo == T_DESFAZER) {
    definir("desfazendo", "desfazer", "desfazendo");
    int r = desfazer_tudo();
    pthread_mutex_lock(&g_trava);
    int interrompida = g.interrompida;
    g.interrompida = 0;
    pthread_mutex_unlock(&g_trava);
    definir(r ? "erro" : interrompida ? "interrompida" : "parado", r ? "resolver" : "", "%s",
            r ? "o desfazer parou: veja a lista para resolver na mao"
              : interrompida ? "interrompida pelo reinicio do PS5 e desfeita: Iniciar continua da rodada seguinte"
                             : "desfeito: a biblioteca voltou como estava");
    pthread_mutex_unlock(&g_trava_plano);
    fim_thread();
    return NULL;
  }
  if(modo == T_ENVIAR) {
    if(!plano_do_disco(pl, e, sizeof e)) {
      gerar_relatorio(pl);
      enviar(pl);
    }
    pthread_mutex_unlock(&g_trava_plano);
    fim_thread();
    return NULL;
  }
  if(plano_do_disco(pl, e, sizeof e)) {
    erro_def("plano: %s", e);
    definir("erro", "", "plano invalido");
    pthread_mutex_unlock(&g_trava_plano);
    fim_thread();
    return NULL;
  }
  pthread_mutex_lock(&g_trava);
  int sha_ok = !g.plano_sha[0] || !strcmp(g.plano_sha, pl->sha256);
  pthread_mutex_unlock(&g_trava);
  if(!sha_ok) {
    erro_def("o plano guardado mudou desde o inicio da bateria: pare e inicie de novo");
    definir("erro", "", "plano mudou");
    pthread_mutex_unlock(&g_trava_plano);
    fim_thread();
    return NULL;
  }
  ampr_trecho_desistir();   /* trecho que ficou aberto (glibren reaberto no meio) e refeito */
  if(journal_resolver()) {
    erro_def("o journal tem um movimento que nao achei em lugar nenhum: resolva na mao");
    definir("erro", "resolver", "journal com problema");
    pthread_mutex_unlock(&g_trava_plano);
    fim_thread();
    return NULL;
  }
  guardar_original();
  int parar = 0, quedas_seguidas;
  pthread_mutex_lock(&g_trava);
  int ir0 = g.rodada, rep0 = g.rep;
  quedas_seguidas = g.quedas_seguidas;
  pthread_mutex_unlock(&g_trava);
  for(int ir = ir0; ir < pl->nr && !parar; ir++) {
    int caiu = 0;
    for(int rep = ir == ir0 ? rep0 : 0; rep < pl->r[ir].repeticoes; rep++) {
      pthread_mutex_lock(&g_trava);
      g.rodada = ir;
      g.rep = rep;
      pthread_mutex_unlock(&g_trava);
      salvar_estado();   /* o estado (rodando/pausando/parando) e de quem pediu; aqui so a posicao */
      int r = repeticao(pl, ir, rep);
      if(r == RP_PARAR) {
        parar = 1;
        break;
      }
      if(r == RP_QUEDA) {
        caiu = 1;
        break;   /* pula as repeticoes que faltam desta rodada */
      }
      /* pausar: depois da repeticao, antes da proxima */
      pthread_mutex_lock(&g_trava);
      if(g.pausar && !g.cancelar) {
        g.rep = rep + 1 < pl->r[ir].repeticoes ? rep + 1 : 0;
        g.rodada = rep + 1 < pl->r[ir].repeticoes ? ir : ir + 1;
        snprintf(g.estado, sizeof g.estado, "pausado");
        snprintf(g.msg, sizeof g.msg, "pausada antes da rodada %d", g.rodada + 1);
        g.rodando_thread = 0;
        g.pausar = 0;
        pthread_mutex_unlock(&g_trava);
        salvar_estado();
        pthread_mutex_unlock(&g_trava_plano);
        diario("bateria: pausada");
        fim_thread();
        return NULL;
      }
      pthread_mutex_unlock(&g_trava);
    }
    if(parar) break;
    quedas_seguidas = caiu ? quedas_seguidas + 1 : 0;
    pthread_mutex_lock(&g_trava);
    g.quedas_seguidas = quedas_seguidas;
    g.rodada = ir + 1;
    g.rep = 0;
    pthread_mutex_unlock(&g_trava);
    salvar_estado();
    if(quedas_seguidas >= pl->cfg.quedas_seguidas) {
      erro_def("%d rodadas seguidas com o jogo caindo: bateria parada", quedas_seguidas);
      parar = 1;
    }
    pthread_mutex_lock(&g_trava);
    if(g.pausar && !g.cancelar && !parar && ir + 1 < pl->nr) {
      snprintf(g.estado, sizeof g.estado, "pausado");
      snprintf(g.msg, sizeof g.msg, "pausada antes da rodada %d", g.rodada + 1);
      g.pausar = 0;
      pthread_mutex_unlock(&g_trava);
      salvar_estado();
      pthread_mutex_unlock(&g_trava_plano);
      fim_thread();
      return NULL;
    }
    pthread_mutex_unlock(&g_trava);
  }
  pthread_mutex_lock(&g_trava);
  int cancel = g.cancelar;
  g.cancelar = 0;   /* o desfazer precisa das esperas */
  pthread_mutex_unlock(&g_trava);
  if(parar && cancel) erro_def("parada pelo dono");
  if(parar) definir("parando", NULL, "parando: %s", g.erro);
  int d = desfazer_tudo();
  gerar_relatorio(pl);
  enviar(pl);
  if(d) definir("erro", "resolver", "o desfazer parou: veja a lista para resolver na mao");
  else if(parar) definir(cancel ? "parado" : "erro", "", "%s", cancel ? "parada pelo dono e desfeita" : g.erro);
  else {
    definir("concluida", "", "concluida: %d rodada(s); biblioteca de volta como estava", pl->nr);
    notificar("bateria %s concluida (%d rodadas)", pl->id, pl->nr);
  }
  pthread_mutex_unlock(&g_trava_plano);
  fim_thread();
  return NULL;
}

static int lancar(int modo) {
  pthread_mutex_lock(&g_trava);
  if(g.rodando_thread) {
    pthread_mutex_unlock(&g_trava);
    return -1;
  }
  g.rodando_thread = 1;
  g.cancelar = g.pausar = 0;
  pthread_mutex_unlock(&g_trava);
  if(criar_thread(trabalho, (void *)(intptr_t)modo, NULL)) {
    fim_thread();
    return -1;
  }
  return 0;
}

/* ================================================================== API */

int bateria_ocupada(void) {
  pthread_mutex_lock(&g_trava);
  int o = g.rodando_thread || !strcmp(g.estado, "pausado");
  pthread_mutex_unlock(&g_trava);
  return o;
}

void bateria_iniciar(void) {
  ler_estado();
  long long b = boot_atual();
  pthread_mutex_lock(&g_trava);
  char est[16];
  snprintf(est, sizeof est, "%s", g.estado);
  long long b0 = g.boot;
  pthread_mutex_unlock(&g_trava);
  int andando = !strcmp(est, "rodando") || !strcmp(est, "pausando") || !strcmp(est, "parando") || !strcmp(est, "desfazendo");
  if(!andando) return;
  if(mesmo_boot(b, b0)) {
    diario("bateria: glibren reaberto no meio da bateria (%s, passo %s): retomando", est, g.passo);
    if(!strcmp(est, "parando") || !strcmp(est, "desfazendo")) lancar(T_DESFAZER);
    else lancar(T_RODAR);
    return;
  }
  /* PS5 reiniciado: provavel travamento; nao continua sozinho */
  diario("bateria: o PS5 reiniciou no meio da bateria (passo %s): desfazendo e esperando o dono", g.passo);
  plano_t *pl = &g_plano;
  char e[300];
  pthread_mutex_lock(&g_trava_plano);
  if(!plano_do_disco(pl, e, sizeof e) && g.rodada < pl->nr && strcmp(g.passo, "preparar") && strcmp(g.passo, "esfriar") &&
     strcmp(g.passo, "trocar") && strcmp(g.passo, "esperar_sk") && strcmp(g.passo, "ampr")) {
    static rep_t x;
    memset(&x, 0, sizeof x);
    x.t_tela = x.t_ampr = x.t_carregado = x.fps_media = x.temp_max = -1;
    x.bytes_menu = -1;
    snprintf(x.resultado, sizeof x.resultado, "queda_reinicio");
    snprintf(x.compat, sizeof x.compat, "travou");
    snprintf(x.fechar, sizeof x.fechar, "reinicio");
    snprintf(x.erro, sizeof x.erro, "o PS5 reiniciou durante o passo %s", g.passo);
    gravar_resultado(pl, g.rodada, g.rep, &x);
  }
  pthread_mutex_unlock(&g_trava_plano);
  pthread_mutex_lock(&g_trava);
  g.aberto_bat[0] = 0;
  g.boot = b;
  snprintf(g.erro, sizeof g.erro, "interrompida: o PS5 reiniciou no passo %s da rodada %d", g.passo, g.rodada + 1);
  pthread_mutex_unlock(&g_trava);
  definir("interrompida", NULL, "interrompida pelo reinicio do PS5; desfazendo");
  /* desfaz numa thread; no fim o estado volta a "interrompida" (Iniciar continua da rodada seguinte) */
  pthread_mutex_lock(&g_trava);
  g.interrompida = 1;
  pthread_mutex_unlock(&g_trava);
  lancar(T_DESFAZER);
}

void bateria_json(buf_t *b) {
  int pend = journal_pendentes();
  pthread_mutex_lock(&g_trava);
  buf_str(b, "{\"ok\":true,\"estado\":");
  buf_json(b, g.estado);
  buf_str(b, ",\"passo\":");
  buf_json(b, g.passo);
  buf_fmt(b, ",\"desde\":%lld,\"agora\":%lld,\"msg\":", g.desde, (long long)time(NULL));
  buf_json(b, g.msg);
  buf_str(b, ",\"erro\":");
  buf_json(b, g.erro);
  buf_str(b, ",\"problemas\":");
  buf_json(b, g.problemas);
  buf_str(b, ",\"envio\":");
  buf_json(b, g.envio);
  buf_str(b, ",\"relatorio\":");
  buf_json(b, g.relatorio);
  buf_fmt(b, ",\"journal_pendente\":%d,\"trabalhando\":%s,\"plano_ok\":%s,\"plano_erro\":", pend, g.rodando_thread ? "true" : "false",
          g.plano_ok ? "true" : "false");
  buf_json(b, g.plano_erro);
  buf_fmt(b, ",\"buscado\":%lld,\"conferencia\":", g.buscado);
  if(g.conferencia.d) buf_add(b, g.conferencia.d, g.conferencia.n);
  else buf_str(b, "[]");
  buf_fmt(b, ",\"conferencia_ok\":%s", g.conferencia_ok ? "true" : "false");
  int ir = g.rodada, rep = g.rep;
  double tt = g.t_tela, tc = g.t_carregado;
  char car[160];
  snprintf(car, sizeof car, "%s", g.carregar);
  pthread_mutex_unlock(&g_trava);
  /* o plano guardado (sem esperar a thread: le do disco) */
  static plano_t pl;
  static pthread_mutex_t trava = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_lock(&trava);
  char e[300];
  int ok = !plano_do_disco(&pl, e, sizeof e);
  if(ok) {
    buf_str(b, ",\"plano\":{\"id\":");
    buf_json(b, pl.id);
    buf_str(b, ",\"titulo\":");
    buf_json(b, pl.titulo);
    int reps = 0;
    for(int i = 0; i < pl.nr; i++) reps += pl.r[i].repeticoes;
    buf_fmt(b, ",\"rodadas\":%d,\"repeticoes\":%d,\"estimativa_s\":%lld,\"jogos\":%d}", pl.nr, reps, pl.estimativa_s, pl.nj);
    if(ir < pl.nr) {
      const rodada_t *r = &pl.r[ir];
      const jogo_t *j = &pl.jogos[r->jogo];
      buf_fmt(b, ",\"atual\":{\"rodada\":%d,\"rodadas\":%d,\"rep\":%d,\"reps\":%d,\"id\":", ir + 1, pl.nr, rep + 1, r->repeticoes);
      buf_json(b, r->id);
      buf_str(b, ",\"jogo\":");
      buf_json(b, j->tid);
      buf_str(b, ",\"nome\":");
      buf_json(b, j->nome);
      buf_str(b, ",\"versao\":");
      buf_json(b, j->v[r->versao].nome);
      buf_str(b, ",\"ampr\":");
      buf_json(b, r->ampr);
      /* 0.9.69: a nota da rodada e o bloco (rodadas seguidas do mesmo jogo e versao = uma "bateria" para quem acompanha) */
      buf_str(b, ",\"nota\":");
      buf_json(b, r->nota);
      int bloco = 0, blocos = 0, no_bloco = 0, tam_bloco = 0;
      for(int i = 0; i < pl.nr; i++) {
        int novo = !i || pl.r[i].jogo != pl.r[i - 1].jogo || pl.r[i].versao != pl.r[i - 1].versao;
        if(novo) blocos++;
        if(i <= ir && novo) {
          bloco = blocos;
          no_bloco = tam_bloco = 0;
        }
        if(i <= ir) no_bloco++;
        if(blocos == bloco) tam_bloco++;
      }
      buf_fmt(b, ",\"bloco\":%d,\"blocos\":%d,\"no_bloco\":%d,\"tam_bloco\":%d", bloco, blocos, no_bloco, tam_bloco);
      num_json(b, "t_tela", tt, 1);
      num_json(b, "t_carregado", tc, 1);
      buf_str(b, ",\"carregar\":");
      buf_json(b, car);
      buf_str(b, "}");
    } else buf_str(b, ",\"atual\":null");
  } else buf_str(b, ",\"plano\":null,\"atual\":null");
  pthread_mutex_unlock(&trava);
  /* os ultimos resultados (curtos) */
  char c[TAM_C];
  buf_t l = {0};
  arq_bat(c, sizeof c, "resultados.jsonl");
  ler_arquivo(c, &l, 16u * 1024 * 1024);
  int total = 0;
  for(char *p = l.d; p && *p; p = strchr(p, '\n') ? strchr(p, '\n') + 1 : NULL) total += *p == '{';
  buf_str(b, ",\"resultados\":[");
  int k = 0, n = 0;
  for(char *p = l.d; p && *p;) {
    char *fim = strchr(p, '\n');
    if(*p == '{' && k++ >= total - 30) {
      js_t o = {p, fim ? fim : p + strlen(p)};
      char id[32] = "", res[24] = "", comp[12] = "", fe[16] = "", ve[24] = "", jo[16] = "", med_[48] = "";
      ler_str(&o, "id", id, sizeof id);
      ler_str(&o, "resultado", res, sizeof res);
      ler_str(&o, "compat", comp, sizeof comp);
      ler_str(&o, "fechar", fe, sizeof fe);
      ler_str(&o, "versao", ve, sizeof ve);
      ler_str(&o, "jogo", jo, sizeof jo);
      ler_str(&o, "medida", med_, sizeof med_);
      buf_fmt(b, "%s{\"rodada\":%d,\"rep\":%d,\"id\":", n++ ? "," : "", (int)num_linha(&o, "rodada", NULL), (int)num_linha(&o, "rep", NULL));
      buf_json(b, id);
      buf_str(b, ",\"jogo\":");
      buf_json(b, jo);
      buf_str(b, ",\"versao\":");
      buf_json(b, ve);
      buf_str(b, ",\"resultado\":");
      buf_json(b, res);
      buf_str(b, ",\"compat\":");
      buf_json(b, comp);
      buf_str(b, ",\"fechar\":");
      buf_json(b, fe);
      buf_str(b, ",\"medida\":");
      buf_json(b, med_);
      num_json(b, "t_carregado", num_linha(&o, "t_carregado", NULL), 1);
      buf_str(b, "}");
    }
    p = fim ? fim + 1 : NULL;
  }
  buf_fmt(b, "],\"resultados_total\":%d}", total);
  buf_free(&l);
}

void bateria_rota_estado(pedido_t *p) {
  buf_t b = {0};
  bateria_json(&b);
  responder_json(p, 200, &b);
  buf_free(&b);
}

static void responder_ok(pedido_t *p) { bateria_rota_estado(p); }

/* busca o plano no repositorio privado (mesmo jeito da sugestao do Claude) */
/* ================================================================== 0.9.68: versoes achadas pelo codigo do jogo

No Buscar (so ali: o plano guardado fica explicito e a bateria nao olha o disco de novo para saber o plano):
  "jogos": {"PPSA12771": {"ativa_pasta": "/data/homebrew", "guardar_pasta": "/data/backup", "versoes": "auto"}}
procura nas duas pastas (so no 1o nivel) os itens com o codigo do jogo no nome e da um nome a cada versao pelo tipo:
pkg, exfat, ffpkg, ffpfs, ffpfsc e pasta; com a marca -zstd/-lz4 no nome (a que o GL mantem ao renomear) ganha
"_zstd"/"_lz4" (ex.: exfat_zstd). A versao guardada fica sempre em guardar_pasta/<nome do arquivo> (a que esta na
ativa e levada para la quando outra versao entra; o Desfazer devolve tudo para onde estava pelo journal). As duas
pastas tem de estar no mesmo disco (troca por rename). Dois itens do mesmo tipo = recusado (escolha no plano).
  {"id": "r", "jogo": "PPSA12771", "versao": "todas"} vira uma rodada por versao do jogo ("r-pkg", "r-exfat", ...),
tambem com "versoes" escrito a mao. */

#define AUTO_MAX 8

typedef struct {
  char tid[16];
  int n;
  char nome[AUTO_MAX][24];
  char base[AUTO_MAX][256];
  int auto_;                    /* 1 = veio de "auto" (vira objeto no texto) */
  char guardar[TAM_C];
  const char *ini, *fim;        /* trecho do valor "auto" no texto */
} auto_jogo_t;

typedef struct {
  auto_jogo_t j[MAX_JOGOS];
  int nj;
  char *e;
  size_t te;
  int ruim;
} auto_ctx_t;

/* nome da versao pelo nome do item; "" = nao e versao de jogo */
static void auto_tipo(const char *nome, int pasta, char *t, size_t tt) {
  static const char *const EXT[] = {".pkg", ".exfat", ".ffpkg", ".ffpfs", ".ffpfsc", NULL};
  t[0] = 0;
  size_t n = strlen(nome), corpo = n;
  if(!n || nome[0] == '.') return;
  if(pasta) snprintf(t, tt, "pasta");
  else {
    for(int i = 0; EXT[i]; i++) {
      size_t k = strlen(EXT[i]);
      if(n > k && !strcasecmp(nome + n - k, EXT[i])) {
        snprintf(t, tt, "%s", EXT[i] + 1);
        corpo = n - k;
        break;
      }
    }
    if(!t[0]) return;
  }
  static const char *const MARCA[] = {"zstd", "lz4", NULL};
  for(int m = 0; MARCA[m]; m++) {
    size_t k = strlen(MARCA[m]);
    for(size_t i = 1; i + k <= corpo; i++) {
      char antes = nome[i - 1], depois = i + k < corpo ? nome[i + k] : '.';
      if((antes == '-' || antes == '_') && !strncasecmp(nome + i, MARCA[m], k) &&
         (depois == '-' || depois == '_' || depois == '.')) {
        size_t u = strlen(t);
        snprintf(t + u, tt - u, "_%s", MARCA[m]);
        return;
      }
    }
  }
}

/* procura em uma pasta; 0 = ok */
static int auto_pasta(auto_jogo_t *j, const char *pasta, char *e, size_t te) {
  DIR *d = opendir(pasta);
  if(!d) {
    snprintf(e, te, "%s: nao abriu a pasta %s", j->tid, pasta);
    return -1;
  }
  struct dirent *it;
  size_t ntid = strlen(j->tid);
  while((it = readdir(d))) {
    const char *nm = it->d_name;
    int tem = 0;
    for(size_t i = 0; nm[i] && !tem; i++) tem = !strncasecmp(nm + i, j->tid, ntid);
    if(!tem || strlen(nm) >= sizeof j->base[0]) continue;
    char c[TAM_C], tipo[24];
    struct stat s;
    snprintf(c, sizeof c, "%s/%s", pasta, nm);
    if(lstat(c, &s) || (!S_ISREG(s.st_mode) && !S_ISDIR(s.st_mode))) continue;   /* links ficam de fora */
    auto_tipo(nm, S_ISDIR(s.st_mode), tipo, sizeof tipo);
    if(!tipo[0]) continue;
    for(int k = 0; k < j->n; k++) {
      if(!strcmp(j->nome[k], tipo)) {
        snprintf(e, te, "%s: duas versoes %s (%s e %s): escreva as versoes no plano", j->tid, tipo, j->base[k], nm);
        closedir(d);
        return -1;
      }
      if(!strcmp(j->base[k], nm)) {
        snprintf(e, te, "%s: %s esta na pasta ativa e na guardada: resolva na mao", j->tid, nm);
        closedir(d);
        return -1;
      }
    }
    if(j->n >= AUTO_MAX) {
      snprintf(e, te, "%s: versoes demais (maximo %d)", j->tid, AUTO_MAX);
      closedir(d);
      return -1;
    }
    snprintf(j->nome[j->n], sizeof j->nome[0], "%s", tipo);
    snprintf(j->base[j->n], sizeof j->base[0], "%s", nm);
    j->n++;
  }
  closedir(d);
  return 0;
}

static int auto_um_jogo(const char *k, const js_t *v, void *ctx) {
  auto_ctx_t *c = ctx;
  if(c->nj >= MAX_JOGOS) return 1;   /* plano_ler recusa depois */
  auto_jogo_t *j = &c->j[c->nj++];
  memset(j, 0, sizeof *j);
  snprintf(j->tid, sizeof j->tid, "%s", k);
  js_t vs;
  if(!js_campo(v, "versoes", &vs)) return 1;
  if(*vs.p == '{') {   /* escritas a mao: so os nomes, para "todas" */
    js_t o = vs;
    o.p++;
    for(;;) {
      js_esp(&o);
      if(o.p >= o.fim || *o.p == '}') break;
      if(*o.p == ',') {
        o.p++;
        continue;
      }
      char nome[24];
      if(*o.p != '"' || js_string(&o, nome, sizeof nome)) break;
      js_esp(&o);
      if(o.p >= o.fim || *o.p != ':') break;
      o.p++;
      js_esp(&o);
      if(js_pular(&o, 1)) break;
      if(j->n < AUTO_MAX) snprintf(j->nome[j->n++], sizeof j->nome[0], "%s", nome);
    }
    return 1;
  }
  char val[16];
  js_t x = vs;
  if(*x.p != '"' || js_string(&x, val, sizeof val) || strcmp(val, "auto")) return 1;   /* plano_ler recusa */
  j->auto_ = 1;
  j->ini = vs.p;
  j->fim = x.p;
  char ativa[TAM_C];
  if(ler_str(v, "ativa_pasta", ativa, sizeof ativa) <= 0 || !caminho_plano_ok(ativa) ||
     ler_str(v, "guardar_pasta", j->guardar, sizeof j->guardar) <= 0 || !caminho_plano_ok(j->guardar)) {
    snprintf(c->e, c->te, "%s: com \"versoes\": \"auto\" o plano precisa de ativa_pasta e guardar_pasta validas", k);
    c->ruim = 1;
    return 0;
  }
  sem_barra(ativa);
  sem_barra(j->guardar);
  struct stat sa, sg;
  if(!strcmp(ativa, j->guardar) || stat(ativa, &sa) || stat(j->guardar, &sg) || !S_ISDIR(sa.st_mode) || !S_ISDIR(sg.st_mode)) {
    snprintf(c->e, c->te, "%s: ativa_pasta e guardar_pasta tem de ser pastas diferentes que existem", k);
    c->ruim = 1;
    return 0;
  }
  if(sa.st_dev != sg.st_dev) {
    snprintf(c->e, c->te, "%s: ativa_pasta e guardar_pasta em discos diferentes (a troca e so no mesmo disco)", k);
    c->ruim = 1;
    return 0;
  }
  if(auto_pasta(j, j->guardar, c->e, c->te) || auto_pasta(j, ativa, c->e, c->te)) {
    c->ruim = 1;
    return 0;
  }
  if(!j->n) {
    snprintf(c->e, c->te, "%s: nenhuma versao com o codigo do jogo em %s nem em %s", k, ativa, j->guardar);
    c->ruim = 1;
    return 0;
  }
  return 1;
}

typedef struct {
  const char *ini, *fim;
  buf_t txt;
} troca_t;

typedef struct {
  auto_ctx_t *a;
  troca_t *t;
  int nt, max;
  char *e;
  size_t te;
  int ruim;
} auto_rod_ctx_t;

static int auto_rodada(const js_t *it, void *ctx) {
  auto_rod_ctx_t *c = ctx;
  js_t vv, iv, jv;
  char versao[24] = "", id[32] = "", jogo[16] = "";
  if(!js_campo(it, "versao", &vv) || *vv.p != '"') return 1;
  js_t x = vv;
  if(js_string(&x, versao, sizeof versao) || strcmp(versao, "todas")) return 1;
  const char *vfim = x.p;
  if(!js_campo(it, "id", &iv) || *iv.p != '"' || !js_campo(it, "jogo", &jv) || *jv.p != '"') return 1;   /* plano_ler recusa */
  js_t y = iv, z = jv;
  if(js_string(&y, id, sizeof id) || js_string(&z, jogo, sizeof jogo)) return 1;
  const char *ifim = y.p;
  const auto_jogo_t *j = NULL;
  for(int i = 0; i < c->a->nj; i++)
    if(!strcmp(c->a->j[i].tid, jogo)) j = &c->a->j[i];
  if(!j || !j->n) {
    snprintf(c->e, c->te, "rodada %s: \"todas\" sem versoes do jogo %s", id, jogo);
    c->ruim = 1;
    return 0;
  }
  if(c->nt >= c->max) {
    snprintf(c->e, c->te, "rodadas com \"todas\" demais");
    c->ruim = 1;
    return 0;
  }
  troca_t *t = &c->t[c->nt++];
  t->ini = it->p;
  t->fim = it->fim;
  memset(&t->txt, 0, sizeof t->txt);
  /* o objeto da rodada repetido por versao, com o id e a versao trocados (os dois trechos em ordem) */
  const char *a1 = iv.p < vv.p ? iv.p : vv.p, *f1 = iv.p < vv.p ? ifim : vfim;
  const char *a2 = iv.p < vv.p ? vv.p : iv.p, *f2 = iv.p < vv.p ? vfim : ifim;
  for(int k = 0; k < j->n; k++) {
    char nid[64], nv[32];
    snprintf(nid, sizeof nid, "\"%s-%s\"", id, j->nome[k]);
    snprintf(nv, sizeof nv, "\"%s\"", j->nome[k]);
    if(k) buf_str(&t->txt, ",");
    buf_add(&t->txt, it->p, (size_t)(a1 - it->p));
    buf_str(&t->txt, a1 == iv.p ? nid : nv);
    buf_add(&t->txt, f1, (size_t)(a2 - f1));
    buf_str(&t->txt, a2 == iv.p ? nid : nv);
    buf_add(&t->txt, f2, (size_t)(it->fim - f2));
  }
  return 1;
}

/* Troca "auto" e "todas" no texto do plano. 0 = ok (saida com o texto novo; sem nada para trocar, igual ao original).
   -1 = recusado (e preenchido). */
static int plano_expandir(const char *d, size_t n, buf_t *saida, char *e, size_t te) {
  static auto_ctx_t a;   /* ~50 KB: fora da pilha; so o Buscar chama (trava propria la) */
  memset(&a, 0, sizeof a);
  a.e = e;
  a.te = te;
  e[0] = 0;
  js_t o = {d, d + n}, v;
  js_esp(&o);
  if(o.p >= o.fim || *o.p != '{') {
    buf_add(saida, d, n);   /* plano_ler explica */
    return 0;
  }
  if(js_campo(&o, "jogos", &v) && (obj_cada(&v, auto_um_jogo, &a) < 0 || a.ruim)) {
    if(!e[0]) snprintf(e, te, "lista de jogos quebrada");
    return -1;
  }
  troca_t t[MAX_JOGOS + MAX_RODADAS];
  int nt = 0;
  for(int i = 0; i < a.nj; i++) {
    auto_jogo_t *j = &a.j[i];
    if(!j->auto_) continue;
    troca_t *x = &t[nt++];
    x->ini = j->ini;
    x->fim = j->fim;
    memset(&x->txt, 0, sizeof x->txt);
    buf_str(&x->txt, "{");
    for(int k = 0; k < j->n; k++) {
      char c[TAM_C + 256];
      snprintf(c, sizeof c, "%s/%s", j->guardar, j->base[k]);
      buf_fmt(&x->txt, "%s\"%s\":", k ? "," : "", j->nome[k]);
      buf_json(&x->txt, c);
    }
    buf_str(&x->txt, "}");
    diario("bateria: %s: %d versao(oes) achada(s) pelo codigo do jogo", j->tid, j->n);
  }
  auto_rod_ctx_t rc = {&a, t + nt, 0, (int)(sizeof t / sizeof t[0]) - nt, e, te, 0};
  if(js_campo(&o, "rodadas", &v) && *v.p == '[' && (js_cada(&v, auto_rodada, &rc) < 0 || rc.ruim)) {
    for(int i = 0; i < nt + rc.nt; i++) buf_free(&t[i].txt);
    if(!e[0]) snprintf(e, te, "lista de rodadas quebrada");
    return -1;
  }
  nt += rc.nt;
  /* aplica em ordem de posicao (jogos vem antes ou depois das rodadas no texto: ordena) */
  for(int i = 1; i < nt; i++)
    for(int k = i; k > 0 && t[k].ini < t[k - 1].ini; k--) {
      troca_t s = t[k];
      t[k] = t[k - 1];
      t[k - 1] = s;
    }
  const char *p = d;
  for(int i = 0; i < nt; i++) {
    buf_add(saida, p, (size_t)(t[i].ini - p));
    buf_add(saida, t[i].txt.d, t[i].txt.n);
    p = t[i].fim;
    buf_free(&t[i].txt);
  }
  buf_add(saida, p, (size_t)(d + n - p));
  return 0;
}

static void rota_buscar(pedido_t *p) {
  static time_t ult;
  time_t agora = time(NULL);
  int espera = 30;
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_BAT_BUSCA_S")) espera = atoi(getenv("GLR_TESTE_BAT_BUSCA_S"));   /* testes */
#endif
  if(ult && agora - ult < espera) {
    responder_erro(p, 429, "bat_espera", "busca feita ha menos de 30 s: espere um pouco", NULL);
    return;
  }
  if(bateria_ocupada()) {
    responder_erro(p, 409, "bat_ocupado", "a bateria esta andando ou pausada: pare antes de trocar o plano", NULL);
    return;
  }
  ult = agora;
  char chave[256];
  if(!diagnostico_chave_ler(chave, sizeof chave)) {
    responder_erro(p, 400, "bat_sem_chave", "falta a chave do GitHub (pagina Diagnostico)", NULL);
    return;
  }
  buf_t r = {0};
  int st = https_github_get(PLANO_CAMINHO, chave, &r, 2 * PLANO_MAX);
  memset(chave, 0, sizeof chave);
  if(st == 404) {
    buf_free(&r);
    responder_erro(p, 404, "bat_sem_plano", "nenhum plano publicado (glibren/ampr-bateria.json)", NULL);
    return;
  }
  if(st != 200 || !r.d) {
    buf_free(&r);
    char m[80];
    snprintf(m, sizeof m, "o GitHub nao respondeu (HTTP %d)", st);
    responder_erro(p, 502, "bat_http", m, NULL);
    return;
  }
  buf_add(&r, "", 1);
  js_t o = {r.d, r.d + r.n - 1}, v;
  buf_t dec = {0};
  char *conteudo = malloc(r.n + 1);
  int ok = conteudo && js_campo(&o, "content", &v) && !js_string(&v, conteudo, r.n + 1);
  if(ok) ampr_base64_dec(conteudo, strlen(conteudo), &dec);
  free(conteudo);
  buf_free(&r);
  static plano_t pl;
  static pthread_mutex_t trava = PTHREAD_MUTEX_INITIALIZER;
  char e[300] = "";
  pthread_mutex_lock(&trava);
  if(dec.d) buf_add(&dec, "", 1), dec.n--;
  /* 0.9.68: "versoes": "auto" e "versao": "todas" viram o plano explicito que fica guardado */
  buf_t exp = {0};
  int valido = ok && dec.d && dec.n <= PLANO_MAX && !plano_expandir(dec.d, dec.n, &exp, e, sizeof e) && exp.d &&
               exp.n <= PLANO_MAX;
  if(valido) {
    buf_add(&exp, "", 1);
    exp.n--;
    valido = !plano_ler(exp.d, exp.n, &pl, e, sizeof e);
  }
  buf_free(&dec);
  dec = exp;
  if(!valido) {
    pthread_mutex_unlock(&trava);
    buf_free(&dec);
    char m[400];
    snprintf(m, sizeof m, "plano recusado: %s", e[0] ? e : "sem conteudo ou grande demais");
    pthread_mutex_lock(&g_trava);
    g.plano_ok = 0;
    snprintf(g.plano_erro, sizeof g.plano_erro, "%s", m);
    pthread_mutex_unlock(&g_trava);
    responder_erro(p, 422, "bat_plano", m, NULL);
    return;
  }
  char c[TAM_C], pb[TAM_C];
  pasta_bat(pb, sizeof pb);
  mkdir_p(pb);
  arq_bat(c, sizeof c, "plano.json");
  int g1 = gravar_atomico(c, dec.d, dec.n);
  diario("bateria: plano %s buscado (%d rodadas, %zu bytes, sha256 %.16s...)", pl.id, pl.nr, dec.n, pl.sha256);
  pthread_mutex_unlock(&trava);
  buf_free(&dec);
  if(g1) {
    responder_erro(p, 500, "bat_gravar", "nao gravou o plano no PS5", NULL);
    return;
  }
  pthread_mutex_lock(&g_trava);
  g.plano_ok = 1;
  g.plano_erro[0] = 0;
  g.buscado = (long long)time(NULL);
  buf_free(&g.conferencia);
  g.conferencia_ok = 0;
  pthread_mutex_unlock(&g_trava);
  responder_ok(p);
}

/* validacao + ensaio seco. 0 = pode; senao responde o erro (se p) */
static int conferir(pedido_t *p, char *e, size_t te) {
  static plano_t pl;
  static pthread_mutex_t trava = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_lock(&trava);
  buf_t l = {0};
  int r = plano_do_disco(&pl, e, te);
  if(r) {
    buf_str(&l, "[");
    buf_json(&l, e);
    buf_str(&l, "]");
  } else r = ensaio(&pl, &l, e, te);
  pthread_mutex_lock(&g_trava);
  buf_free(&g.conferencia);
  g.conferencia = l;
  g.conferencia_ok = !r;
  pthread_mutex_unlock(&g_trava);
  pthread_mutex_unlock(&trava);
  if(r && p) responder_erro(p, 409, "bat_conferir", e, NULL);
  return r;
}

static void rota_iniciar(pedido_t *p) {
  char e[300], tid[16], v[16] = "";
  if(bateria_ocupada()) {
    pthread_mutex_lock(&g_trava);
    int pausado = !strcmp(g.estado, "pausado");
    pthread_mutex_unlock(&g_trava);
    responder_erro(p, 409, "bat_ocupado", pausado ? "a bateria esta pausada: use Continuar ou Parar e desfazer" : "a bateria ja esta andando", NULL);
    return;
  }
  if(journal_pendentes()) {
    responder_erro(p, 409, "bat_journal", "ha movimentos da bateria anterior sem desfazer: toque em Desfazer", NULL);
    return;
  }
  int ab = app_de_jogo_aberto(tid, sizeof tid);
  if(ab != 0) {
    responder_erro(p, 409, "bat_jogo_aberto", "feche o jogo antes de iniciar a bateria", ab > 0 ? tid : NULL);
    return;
  }
  if(!sk_vivo()) {
    responder_erro(p, 409, "bat_sk_fora", "o ShadowKraken nao respondeu (a bateria precisa dele)", NULL);
    return;
  }
  if(tarefas_ativas() || apps_ocupado() || payloads_ocupado() || discos_testando()) {
    responder_erro(p, 409, "bat_tarefas", "ha tarefas, instalacao, payload ou teste de disco andando: espere terminar", NULL);
    return;
  }
  if(conferir(p, e, sizeof e)) return;
  static plano_t pl;
  plano_do_disco(&pl, e, sizeof e);
  param(p->corpo, "a_partir", 0, v, sizeof v);
  pthread_mutex_lock(&g_trava);
  /* sem a_partir: depois de um reinicio continua da rodada seguinte; depois de um erro, da rodada que parou */
  int mesmo_plano = !strcmp(g.plano_id, pl.id), de = 1;
  if(v[0]) de = atoi(v);
  else if(mesmo_plano && !strcmp(g.estado, "interrompida")) de = g.rodada + 2;
  else if(mesmo_plano && !strcmp(g.estado, "erro") && g.rodada > 0) de = g.rodada + 1;
  if(!v[0] && de > pl.nr) de = 1;
  pthread_mutex_unlock(&g_trava);
  if(de < 1 || de > pl.nr) {
    responder_erro(p, 400, "bat_a_partir", "a_partir fora das rodadas do plano", NULL);
    return;
  }
  char c[TAM_C], h[TAM_C + 40];
  arq_bat(c, sizeof c, "resultados.jsonl");
  pthread_mutex_lock(&g_trava);
  int mesmo = !strcmp(g.plano_id, pl.id);
  pthread_mutex_unlock(&g_trava);
  if(de == 1 || !mesmo) {   /* resultados novos: os antigos vao para o historico */
    snprintf(h, sizeof h, "%s.%lld", c, (long long)time(NULL));
    rename(c, h);
  }
  pthread_mutex_lock(&g_trava);
  snprintf(g.plano_id, sizeof g.plano_id, "%s", pl.id);
  snprintf(g.plano_sha, sizeof g.plano_sha, "%s", pl.sha256);
  g.rodada = de - 1;
  g.rep = 0;
  g.quedas_seguidas = 0;
  g.boot = boot_atual();
  g.iniciado = (long long)time(NULL);
  g.erro[0] = g.problemas[0] = g.envio[0] = g.relatorio[0] = 0;
  g.aberto_bat[0] = 0;
  g.ampr_original[0] = g.tune_original[0] = 0;
  g.ampr_mexeu = g.tune_mexeu = 0;
  snprintf(g.estado, sizeof g.estado, "rodando");
  pthread_mutex_unlock(&g_trava);
  definir("rodando", "preparar", "iniciando na rodada %d de %d", de, pl.nr);
  diario("bateria: iniciada (plano %s, rodada %d de %d)", pl.id, de, pl.nr);
  notificar("bateria %s: iniciando (%d rodadas)", pl.id, pl.nr);
  if(lancar(T_RODAR)) {
    definir("erro", "", "nao criou a thread");
    responder_erro(p, 500, "bat_thread", "nao criou a thread da bateria", NULL);
    return;
  }
  responder_ok(p);
}

static void rota_pausar(pedido_t *p) {
  pthread_mutex_lock(&g_trava);
  int r = g.rodando_thread && !strcmp(g.estado, "rodando");
  if(r) {
    g.pausar = 1;
    snprintf(g.estado, sizeof g.estado, "pausando");
  }
  pthread_mutex_unlock(&g_trava);
  if(!r) {
    responder_erro(p, 409, "bat_nao_rodando", "a bateria nao esta andando", NULL);
    return;
  }
  salvar_estado();
  responder_ok(p);
}

static void rota_continuar(pedido_t *p) {
  pthread_mutex_lock(&g_trava);
  int pausado = !strcmp(g.estado, "pausado") && !g.rodando_thread, pausando = !strcmp(g.estado, "pausando");
  if(pausando) {
    g.pausar = 0;
    snprintf(g.estado, sizeof g.estado, "rodando");
  }
  pthread_mutex_unlock(&g_trava);
  if(pausando) {
    salvar_estado();
    responder_ok(p);
    return;
  }
  if(!pausado) {
    responder_erro(p, 409, "bat_nao_pausado", "a bateria nao esta pausada", NULL);
    return;
  }
  char tid[16];
  if(app_de_jogo_aberto(tid, sizeof tid) == 1) {
    responder_erro(p, 409, "bat_jogo_aberto", "feche o jogo antes de continuar", tid);
    return;
  }
  definir("rodando", NULL, "continuando");
  if(lancar(T_RODAR)) {
    responder_erro(p, 500, "bat_thread", "nao criou a thread da bateria", NULL);
    return;
  }
  responder_ok(p);
}

static void rota_parar(pedido_t *p) {
  pthread_mutex_lock(&g_trava);
  int rodando = g.rodando_thread, pausado = !strcmp(g.estado, "pausado");
  if(rodando) {
    g.cancelar = 1;
    snprintf(g.estado, sizeof g.estado, "parando");
  }
  pthread_mutex_unlock(&g_trava);
  if(rodando) {   /* a thread cancela o trecho e fecha o jogo */
    salvar_estado();
    responder_ok(p);
    return;
  }
  if(!pausado && !journal_pendentes()) {
    responder_erro(p, 409, "bat_nao_rodando", "a bateria nao esta andando nem pausada", NULL);
    return;
  }
  erro_def("parada pelo dono");
  lancar(T_DESFAZER);
  responder_ok(p);
}

static void rota_desfazer(pedido_t *p) {
  pthread_mutex_lock(&g_trava);
  int rodando = g.rodando_thread;
  pthread_mutex_unlock(&g_trava);
  if(rodando) {
    responder_erro(p, 409, "bat_ocupado", "a bateria esta andando: use Parar e desfazer", NULL);
    return;
  }
  if(lancar(T_DESFAZER)) {
    responder_erro(p, 409, "bat_ocupado", "outra acao da bateria esta andando", NULL);
    return;
  }
  responder_ok(p);
}

static void rota_enviar(pedido_t *p) {
  char chave[256];
  if(!diagnostico_chave_ler(chave, sizeof chave)) {
    responder_erro(p, 400, "bat_sem_chave", "falta a chave do GitHub (pagina Diagnostico)", NULL);
    return;
  }
  memset(chave, 0, sizeof chave);
  if(lancar(T_ENVIAR)) {
    responder_erro(p, 409, "bat_ocupado", "a bateria esta andando: o envio e automatico no fim", NULL);
    return;
  }
  responder_ok(p);
}

static void rota_conferir(pedido_t *p) {
  char e[300];
  if(conferir(p, e, sizeof e)) return;
  responder_ok(p);
}

int bateria_rota_acao(pedido_t *p) {
  static const struct {
    const char *caminho;
    void (*fn)(pedido_t *);
  } R[] = {{"/api/bateria/buscar", rota_buscar},     {"/api/bateria/conferir", rota_conferir}, {"/api/bateria/iniciar", rota_iniciar},
           {"/api/bateria/pausar", rota_pausar},     {"/api/bateria/continuar", rota_continuar}, {"/api/bateria/parar", rota_parar},
           {"/api/bateria/desfazer", rota_desfazer}, {"/api/bateria/enviar", rota_enviar}};
  for(size_t i = 0; i < sizeof R / sizeof R[0]; i++)
    if(!strcmp(p->caminho, R[i].caminho)) {
      if(fps_agente_ps5(p->agente) || p->local) {   /* no navegador do PS5: so leitura */
        responder_erro(p, 403, "bat_so_celular", "a bateria so e comandada pelo celular ou PC pareado", NULL);
        return 1;
      }
      R[i].fn(p);
      return 1;
    }
  return 0;
}

int bateria_arquivos(char nomes[][96], char caminhos[][600], int max) {
  static const char *const A[] = {"estado.json", "journal.txt", "resultados.jsonl", "plano.json"};
  int n = 0;
  struct stat st;
  for(size_t i = 0; i < sizeof A / sizeof A[0] && n < max; i++) {
    arq_bat(caminhos[n], 600, A[i]);
    if(lstat(caminhos[n], &st)) continue;
    snprintf(nomes[n], 96, "bateria-%s", A[i]);
    n++;
  }
  pthread_mutex_lock(&g_trava);
  char rel[200];
  snprintf(rel, sizeof rel, "%s", g.relatorio);
  pthread_mutex_unlock(&g_trava);
  if(rel[0] && n < max) {
    arq_bat(caminhos[n], 600, rel);
    if(!lstat(caminhos[n], &st)) {
      snprintf(nomes[n], 96, "bateria-relatorio.md");
      n++;
    }
  }
  return n;
}
