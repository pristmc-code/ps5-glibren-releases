/* Game Library Renamer (payload PS5) - configuracao.

Arquivo <pasta de dados>/config.ini:
  language = pt-BR
  folder = /data/homebrew/
  folder = /mnt/ext1/homebrew/
  shadowmount = /mnt/ext1/homebrew/   (pasta da lista que o ShadowMount monitora)
  hide = PPSA01234-ferramenta.pkg       (arquivo oculto da lista de jogos, pelo nome)
  show = jogo.exfat.complete            (.complete que o usuario mandou mostrar: sai dos ocultos automaticos)
  pairing = on                          (0.9.16: on = acoes que apagam/movem/renomeiam/atualizam/ejetam/ativam/trocam de
                                         app pedem um aparelho pareado; off = desliga o pareamento - ver o README)
  paired = <sha256 do token> <quando> <nome>   (aparelhos pareados; o token em si fica so no navegador)
  cheats_area_extra = on                (Fase 2 das cheats, TESTE: deixa ligar cheats com "area extra" (code cave) que ja
                                         existe na memoria do jogo; o padrao e off - ver src/cheats.c;
                                         0.9.25: tambem pela chave da pagina Cheats, POST /api/cheats/area-extra)
  convert_format = ffpkg                (0.9.30: formato padrao da conversao pelo Dump Forge - ver src/conversao.c)
  convert_level = 9                     (0.9.30: nivel de compressao do formato padrao; sem a linha = padrao do Dump Forge)
  convert_backup = off                  (0.9.36: off = o original fica ao lado da conversao; sem a linha = on, o original
                                         vai para <disco>/BACKUP/<jogo>/ depois de converter - ver src/backup.c)
*/
#include "config.h"

#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>

char g_pasta_dados[512];

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static char g_pastas[MAX_PASTAS][1024];
static int g_qtd;
static char g_monit[MAX_PASTAS][1024];   /* pastas da lista marcadas como monitoradas pelo ShadowMount */
static int g_qtd_monit;
static char g_ocultos[MAX_OCULTOS][TAM_OCULTO];
static int g_qtd_ocultos;
static char g_mostrados[MAX_OCULTOS][TAM_OCULTO];
static int g_qtd_mostrados;
static char g_idioma[16] = "pt-BR";
static int g_pareamento = 1;   /* pairing = on (padrao) */
static int g_cheats_area_extra;   /* cheats_area_extra = on (teste; padrao off) */
static char g_conv_formato[16] = "ffpkg";   /* 0.9.30: convert_format */
static char g_conv_nivel[12] = "";          /* 0.9.30: convert_level ("" = padrao do Dump Forge) */
static int g_conv_mover = 1;                /* 0.9.36: convert_backup (padrao on) */
static char g_pareados[MAX_PAREADOS][TAM_PAREADO];
static int g_qtd_pareados;

static const char *PADRAO[] = {"/data/homebrew/", "/mnt/ext1/homebrew/"};

static void arquivo(char *saida, size_t tam) {
  snprintf(saida, tam, "%s/config.ini", g_pasta_dados);
}

static int idioma_valido(const char *idioma) {
  return !strcmp(idioma, "pt-BR") || !strcmp(idioma, "en") || !strcmp(idioma, "es");
}

static void aparar(char *s) {
  size_t n = strlen(s);
  while(n && (s[n - 1] == '\n' || s[n - 1] == '\r' || s[n - 1] == ' ' || s[n - 1] == '\t')) s[--n] = 0;
}

/* Nome de arquivo (sem pasta), como aparece na lista de jogos. */
static int nome_oculto_valido(const char *nome) {
  size_t n = strlen(nome);
  return n && n < TAM_OCULTO && !strchr(nome, '/') && strcmp(nome, ".") && strcmp(nome, "..");
}

/* Arquivo ".complete" (marca de download terminado), o unico tipo que a pagina oculta sozinha. */
static int nome_mostrado_valido(const char *nome) {
  size_t n = strlen(nome), s = sizeof ".complete" - 1;
  return nome_oculto_valido(nome) && n > s && !strcasecmp(nome + n - s, ".complete");
}

static int na_lista(const char *pasta) {
  for(int i = 0; i < g_qtd; i++) {
    if(!strcmp(g_pastas[i], pasta)) return 1;
  }
  return 0;
}

/* Tira as marcadas que sairam da lista (e as repetidas). */
static void limpar_monit(void) {
  int n = 0;
  for(int i = 0; i < g_qtd_monit; i++) {
    int repetida = 0;
    for(int j = 0; j < n; j++) repetida |= !strcmp(g_monit[j], g_monit[i]);
    if(!repetida && na_lista(g_monit[i])) {
      if(n != i) memcpy(g_monit[n], g_monit[i], sizeof g_monit[n]);
      n++;
    }
  }
  g_qtd_monit = n;
}

/* 0.9.30: so letras minusculas, numeros e "_" (a lista de verdade fica em conversao.c); vazio = nivel padrao */
static int conv_id_ok(const char *v, size_t tam) {
  size_t n = strlen(v);
  if(n >= tam) return 0;
  for(const char *c = v; *c; c++)
    if(!((*c >= 'a' && *c <= 'z') || (*c >= '0' && *c <= '9') || *c == '_')) return 0;
  return 1;
}

static int gravar_arquivo(void) {
  char nome[600], tmp[610];
  arquivo(nome, sizeof nome);
  snprintf(tmp, sizeof tmp, "%s.tmp", nome);
  FILE *f = fopen(tmp, "w");
  if(!f) return -1;
  fprintf(f, "; Game Library Renamer (payload PS5)\nlanguage = %s\n", g_idioma);
  for(int i = 0; i < g_qtd; i++) fprintf(f, "folder = %s\n", g_pastas[i]);
  for(int i = 0; i < g_qtd_monit; i++) fprintf(f, "shadowmount = %s\n", g_monit[i]);
  for(int i = 0; i < g_qtd_ocultos; i++) fprintf(f, "hide = %s\n", g_ocultos[i]);
  for(int i = 0; i < g_qtd_mostrados; i++) fprintf(f, "show = %s\n", g_mostrados[i]);
  fprintf(f, "pairing = %s\n", g_pareamento ? "on" : "off");
  for(int i = 0; i < g_qtd_pareados; i++) fprintf(f, "paired = %s\n", g_pareados[i]);
  if(g_cheats_area_extra) fprintf(f, "cheats_area_extra = on\n");   /* teste das cheats (Fase 2): so aparece ligada */
  fprintf(f, "convert_format = %s\n", g_conv_formato);
  if(g_conv_nivel[0]) fprintf(f, "convert_level = %s\n", g_conv_nivel);   /* sem a linha = padrao do Dump Forge */
  if(!g_conv_mover) fprintf(f, "convert_backup = off\n");   /* sem a linha = on (o padrao) */
  /* no disco antes do rename: uma queda de energia logo depois nao deixa um config.ini vazio no lugar do bom */
  int ok = !fflush(f) && !fsync(fileno(f));
  if(fclose(f) || !ok) {
    unlink(tmp);
    return -1;
  }
  return rename(tmp, nome);
}

void config_iniciar(const char *pasta_dados) {
  snprintf(g_pasta_dados, sizeof g_pasta_dados, "%s", pasta_dados);
  mkdir_p(g_pasta_dados);

  char nome[600], linha[1200];
  arquivo(nome, sizeof nome);
  pthread_mutex_lock(&g_trava);
  FILE *f = fopen(nome, "r");
  if(!f) {
    g_qtd = 0;
    for(size_t i = 0; i < sizeof PADRAO / sizeof *PADRAO; i++) snprintf(g_pastas[g_qtd++], 1024, "%s", PADRAO[i]);
    gravar_arquivo();
  } else {
    g_qtd = 0;
    g_qtd_monit = 0;
    g_qtd_ocultos = 0;
    g_qtd_mostrados = 0;
    g_qtd_pareados = 0;
    while(fgets(linha, sizeof linha, f)) {
      aparar(linha);
      char *igual = strchr(linha, '=');
      if(linha[0] == ';' || !igual) continue;
      char *valor = igual + 1;
      while(*valor == ' ') valor++;
      *igual = 0;
      aparar(linha);
      if(!strcmp(linha, "language") && idioma_valido(valor)) snprintf(g_idioma, sizeof g_idioma, "%s", valor);
      else if(!strcmp(linha, "folder") && caminho_valido(valor) && g_qtd < MAX_PASTAS)
        snprintf(g_pastas[g_qtd++], 1024, "%s", valor);
      else if(!strcmp(linha, "shadowmount") && caminho_valido(valor) && g_qtd_monit < MAX_PASTAS)
        snprintf(g_monit[g_qtd_monit++], 1024, "%s", valor);
      else if(!strcmp(linha, "hide") && nome_oculto_valido(valor) && g_qtd_ocultos < MAX_OCULTOS)
        snprintf(g_ocultos[g_qtd_ocultos++], TAM_OCULTO, "%s", valor);
      else if(!strcmp(linha, "show") && nome_mostrado_valido(valor) && g_qtd_mostrados < MAX_OCULTOS)
        snprintf(g_mostrados[g_qtd_mostrados++], TAM_OCULTO, "%s", valor);
      else if(!strcmp(linha, "pairing"))
        g_pareamento = !(!strcasecmp(valor, "off") || !strcmp(valor, "0") || !strcasecmp(valor, "false") || !strcasecmp(valor, "no"));
      else if(!strcmp(linha, "cheats_area_extra"))
        g_cheats_area_extra = !strcasecmp(valor, "on") || !strcmp(valor, "1") || !strcasecmp(valor, "true") || !strcasecmp(valor, "yes");
      else if(!strcmp(linha, "convert_format") && valor[0] && conv_id_ok(valor, sizeof g_conv_formato))
        snprintf(g_conv_formato, sizeof g_conv_formato, "%s", valor);
      else if(!strcmp(linha, "convert_level") && conv_id_ok(valor, sizeof g_conv_nivel))
        snprintf(g_conv_nivel, sizeof g_conv_nivel, "%s", valor);
      else if(!strcmp(linha, "convert_backup"))
        g_conv_mover = !(!strcasecmp(valor, "off") || !strcmp(valor, "0") || !strcasecmp(valor, "false") || !strcasecmp(valor, "no"));
      else if(!strcmp(linha, "paired") && g_qtd_pareados < MAX_PAREADOS && strlen(valor) < TAM_PAREADO)
        snprintf(g_pareados[g_qtd_pareados++], TAM_PAREADO, "%s", valor);
    }
    fclose(f);
    limpar_monit();
  }
  pthread_mutex_unlock(&g_trava);
}

int config_ler(char pastas[MAX_PASTAS][1024], char idioma[16]) {
  pthread_mutex_lock(&g_trava);
  int qtd = g_qtd;
  if(pastas) memcpy(pastas, g_pastas, sizeof g_pastas);
  if(idioma) memcpy(idioma, g_idioma, sizeof g_idioma);
  pthread_mutex_unlock(&g_trava);
  return qtd;
}

int config_gravar(char (*pastas)[1024], int qtd, const char *idioma) {
  if(idioma && !idioma_valido(idioma)) return -1;
  if(pastas) {
    if(qtd > MAX_PASTAS) return -1;
    for(int i = 0; i < qtd; i++) {
      if(!caminho_valido(pastas[i])) return -1;
    }
  }
  pthread_mutex_lock(&g_trava);
  if(idioma) snprintf(g_idioma, sizeof g_idioma, "%s", idioma);
  if(pastas) {
    /* sem repetidas, na ordem recebida */
    g_qtd = 0;
    for(int i = 0; i < qtd; i++) {
      int repetida = 0;
      for(int j = 0; j < g_qtd; j++) repetida |= !strcmp(g_pastas[j], pastas[i]);
      if(!repetida) snprintf(g_pastas[g_qtd++], 1024, "%s", pastas[i]);
    }
    limpar_monit();
  }
  int r = gravar_arquivo();
  pthread_mutex_unlock(&g_trava);
  return r;
}

int config_gravar_monitoradas(char (*pastas)[1024], int qtd) {
  if(qtd > MAX_PASTAS) return -1;
  pthread_mutex_lock(&g_trava);
  for(int i = 0; i < qtd; i++) {
    if(!na_lista(pastas[i])) {
      pthread_mutex_unlock(&g_trava);
      return -1;
    }
  }
  memcpy(g_monit, pastas, (size_t)qtd * sizeof *g_monit);
  g_qtd_monit = qtd;
  limpar_monit();
  int r = gravar_arquivo();
  pthread_mutex_unlock(&g_trava);
  return r;
}

int config_monitoradas(char (*pastas)[1024], int max) {
  pthread_mutex_lock(&g_trava);
  int qtd = g_qtd_monit < max ? g_qtd_monit : max;
  memcpy(pastas, g_monit, (size_t)qtd * sizeof *g_monit);
  pthread_mutex_unlock(&g_trava);
  return qtd;
}

/* Mesma pasta, ignorando as barras do fim ("/data/homebrew/" = "/data/homebrew"). */
static int mesma_pasta(const char *a, const char *b) {
  size_t na = strlen(a), nb = strlen(b);
  while(na > 1 && a[na - 1] == '/') na--;
  while(nb > 1 && b[nb - 1] == '/') nb--;
  return na == nb && !strncmp(a, b, na);
}

int config_pasta_permitida(const char *pasta) {
  if(!pasta || pasta[0] != '/') return 0;
  pthread_mutex_lock(&g_trava);
  int ok = 0;
  for(int i = 0; i < g_qtd && !ok; i++) ok = mesma_pasta(g_pastas[i], pasta);
  pthread_mutex_unlock(&g_trava);
  return ok;
}

/* Substitui uma lista de nomes (sem repetidos, na ordem recebida). */
static int gravar_nomes(char (*nomes)[TAM_OCULTO], int qtd, int (*valido)(const char *),
                        char (*lista)[TAM_OCULTO], int *qtd_lista) {
  if(qtd > MAX_OCULTOS) return -1;
  for(int i = 0; i < qtd; i++) {
    if(!valido(nomes[i])) return -1;
  }
  pthread_mutex_lock(&g_trava);
  *qtd_lista = 0;
  for(int i = 0; i < qtd; i++) {
    int repetido = 0;
    for(int j = 0; j < *qtd_lista; j++) repetido |= !strcmp(lista[j], nomes[i]);
    if(!repetido) snprintf(lista[(*qtd_lista)++], TAM_OCULTO, "%s", nomes[i]);
  }
  int r = gravar_arquivo();
  pthread_mutex_unlock(&g_trava);
  return r;
}

int config_gravar_ocultos(char (*nomes)[TAM_OCULTO], int qtd) {
  return gravar_nomes(nomes, qtd, nome_oculto_valido, g_ocultos, &g_qtd_ocultos);
}

int config_gravar_mostrados(char (*nomes)[TAM_OCULTO], int qtd) {
  return gravar_nomes(nomes, qtd, nome_mostrado_valido, g_mostrados, &g_qtd_mostrados);
}

void config_json(buf_t *b) {
  char pastas[MAX_PASTAS][1024], idioma[16];
  int qtd = config_ler(pastas, idioma);
  buf_str(b, "\"idioma\":");
  buf_json(b, idioma);
  buf_str(b, ",\"pastas\":[");
  for(int i = 0; i < qtd; i++) {
    if(i) buf_str(b, ",");
    buf_json(b, pastas[i]);
  }
  buf_str(b, "],\"monitoradas\":[");
  pthread_mutex_lock(&g_trava);
  for(int i = 0; i < g_qtd_monit; i++) {
    if(i) buf_str(b, ",");
    buf_json(b, g_monit[i]);
  }
  buf_str(b, "],\"ocultos\":[");
  for(int i = 0; i < g_qtd_ocultos; i++) {
    if(i) buf_str(b, ",");
    buf_json(b, g_ocultos[i]);
  }
  buf_str(b, "],\"mostrados\":[");
  for(int i = 0; i < g_qtd_mostrados; i++) {
    if(i) buf_str(b, ",");
    buf_json(b, g_mostrados[i]);
  }
  buf_str(b, "],\"conv_formato\":");
  buf_json(b, g_conv_formato);
  buf_str(b, ",\"conv_nivel\":");
  buf_json(b, g_conv_nivel);
  pthread_mutex_unlock(&g_trava);
}

int config_pareamento(void) {
  pthread_mutex_lock(&g_trava);
  int r = g_pareamento;
  pthread_mutex_unlock(&g_trava);
  return r;
}

int config_cheats_area_extra(void) {
  pthread_mutex_lock(&g_trava);
  int r = g_cheats_area_extra;
  pthread_mutex_unlock(&g_trava);
  return r;
}

/* 0.9.25: liga/desliga a area extra (teste) pela pagina Cheats; grava o config.ini de forma atomica (como o resto).
   Se a gravacao falhar, o valor antigo volta. */
int config_gravar_cheats_area_extra(int ligado) {
  pthread_mutex_lock(&g_trava);
  int antes = g_cheats_area_extra;
  g_cheats_area_extra = !!ligado;
  int r = gravar_arquivo();
  if(r) g_cheats_area_extra = antes;
  pthread_mutex_unlock(&g_trava);
  return r;
}

void config_conversao(char formato[16], char nivel[12]) {
  pthread_mutex_lock(&g_trava);
  snprintf(formato, 16, "%s", g_conv_formato);
  snprintf(nivel, 12, "%s", g_conv_nivel);
  pthread_mutex_unlock(&g_trava);
}

int config_gravar_conversao(const char *formato, const char *nivel) {
  if(!formato[0] || !conv_id_ok(formato, sizeof g_conv_formato) || !conv_id_ok(nivel, sizeof g_conv_nivel)) return -1;
  pthread_mutex_lock(&g_trava);
  char f_antes[16], n_antes[12];
  snprintf(f_antes, sizeof f_antes, "%s", g_conv_formato);
  snprintf(n_antes, sizeof n_antes, "%s", g_conv_nivel);
  snprintf(g_conv_formato, sizeof g_conv_formato, "%s", formato);
  snprintf(g_conv_nivel, sizeof g_conv_nivel, "%s", nivel);
  int r = gravar_arquivo();
  if(r) {
    snprintf(g_conv_formato, sizeof g_conv_formato, "%s", f_antes);
    snprintf(g_conv_nivel, sizeof g_conv_nivel, "%s", n_antes);
  }
  pthread_mutex_unlock(&g_trava);
  return r;
}

int config_conversao_mover(void) {
  pthread_mutex_lock(&g_trava);
  int r = g_conv_mover;
  pthread_mutex_unlock(&g_trava);
  return r;
}

int config_gravar_conversao_mover(int ligado) {
  pthread_mutex_lock(&g_trava);
  int antes = g_conv_mover;
  g_conv_mover = !!ligado;
  int r = gravar_arquivo();
  if(r) g_conv_mover = antes;
  pthread_mutex_unlock(&g_trava);
  return r;
}

int config_pareados(char (*linhas)[TAM_PAREADO], int max) {
  pthread_mutex_lock(&g_trava);
  int qtd = g_qtd_pareados < max ? g_qtd_pareados : max;
  memcpy(linhas, g_pareados, (size_t)qtd * sizeof *g_pareados);
  pthread_mutex_unlock(&g_trava);
  return qtd;
}

int config_gravar_pareados(char (*linhas)[TAM_PAREADO], int qtd) {
  if(qtd < 0 || qtd > MAX_PAREADOS) return -1;
  for(int i = 0; i < qtd; i++)
    if(!memchr(linhas[i], 0, TAM_PAREADO) || strchr(linhas[i], '\n')) return -1;
  pthread_mutex_lock(&g_trava);
  if(qtd) memcpy(g_pareados, linhas, (size_t)qtd * sizeof *g_pareados);
  g_qtd_pareados = qtd;
  int r = gravar_arquivo();
  pthread_mutex_unlock(&g_trava);
  return r;
}
