/* Game Library Renamer (payload PS5) - 0.9.33/0.9.34: ultima release de um repositorio do GitHub. Ver github_rel.h. */
#include "github_rel.h"

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "https.h"
#include "plataforma.h"
#include "util.h"

#define MAX_RESPOSTA (1024 * 1024)

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static time_t g_pedidos[GH_MAX_POR_HORA];   /* hora dos ultimos pedidos (anel) */
static int g_prox;
static time_t g_bloqueado;

long long gh_bloqueado_ate(void) {
  pthread_mutex_lock(&g_trava);
  time_t b = g_bloqueado > time(NULL) ? g_bloqueado : 0;
  pthread_mutex_unlock(&g_trava);
  return (long long)b;
}

/* Reserva um pedido: 0 = pode; -1 = limite proprio (GH_MAX_POR_HORA na ultima hora) ou pausa depois de 403/429. */
static int reservar(void) {
  time_t agora = time(NULL);
  pthread_mutex_lock(&g_trava);
  int ok = g_bloqueado <= agora && (!g_pedidos[g_prox] || agora - g_pedidos[g_prox] >= 3600);
  if(ok) {
    g_pedidos[g_prox] = agora;
    g_prox = (g_prox + 1) % GH_MAX_POR_HORA;
  }
  pthread_mutex_unlock(&g_trava);
  return ok ? 0 : -1;
}

static void bloquear(void) {
  pthread_mutex_lock(&g_trava);
  g_bloqueado = time(NULL) + GH_PAUSA_LIMITE;
  pthread_mutex_unlock(&g_trava);
}

int gh_casa(const char *p, const char *n) {
  if(!*p) return !*n;
  if(*p == '*') {
    for(;; n++) {
      if(gh_casa(p + 1, n)) return 1;
      if(!*n) return 0;
    }
  }
  return *n && *p == *n && gh_casa(p + 1, n + 1);
}

int gh_nome_ok(const char *s, size_t max) {
  size_t n = strlen(s);
  if(!n || n >= max || s[0] == '.' || strstr(s, "..")) return 0;
  for(; *s; s++)
    if(!strchr("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-+", *s)) return 0;
  return 1;
}

/* ------------------------------------------------------------------ JSON minimo */

typedef struct {
  const char *p, *fim;
} js_t;

static void esp(js_t *j) {
  while(j->p < j->fim && (*j->p == ' ' || *j->p == '\t' || *j->p == '\n' || *j->p == '\r')) j->p++;
}

static int ch(js_t *j, char c) {
  esp(j);
  if(j->p < j->fim && *j->p == c) {
    j->p++;
    return 1;
  }
  return 0;
}

/* String; saida NULL = so pula. Os campos lidos sao ASCII: \u e escapes de controle viram '?'. -1 = invalida/grande. */
static int str(js_t *j, char *saida, size_t tam) {
  esp(j);
  if(j->p >= j->fim || *j->p != '"') return -1;
  j->p++;
  size_t n = 0;
  while(j->p < j->fim && *j->p != '"') {
    char c = *j->p++;
    if((unsigned char)c < 0x20) return -1;
    if(c == '\\') {
      if(j->p >= j->fim) return -1;
      c = *j->p++;
      if(c == 'u') {
        if(j->fim - j->p < 4) return -1;
        j->p += 4;
        c = '?';
      } else if(c != '"' && c != '\\' && c != '/') c = '?';
    }
    if(saida) {
      if(n + 1 >= tam) return -1;
      saida[n] = c;
    }
    n++;
  }
  if(j->p >= j->fim) return -1;
  j->p++;
  if(saida) saida[n] = 0;
  return 0;
}

static int pular(js_t *j, int nivel);

/* String que pode ser grande demais ou nao ser string: le se couber; senao pula o valor e deixa "". */
static int str_ou_pula(js_t *j, char *saida, size_t tam) {
  esp(j);
  const char *ini = j->p;
  if(j->p < j->fim && *j->p == '"' && !str(j, saida, tam)) return 0;
  j->p = ini;
  saida[0] = 0;
  return pular(j, 1);
}

static int pular(js_t *j, int nivel) {
  if(nivel > 24) return -1;
  esp(j);
  if(j->p >= j->fim) return -1;
  char c = *j->p;
  if(c == '"') return str(j, NULL, 0);
  if(c == '{' || c == '[') {
    char fecha = c == '{' ? '}' : ']';
    j->p++;
    if(ch(j, fecha)) return 0;
    do {
      if(c == '{' && (str(j, NULL, 0) || !ch(j, ':'))) return -1;
      if(pular(j, nivel + 1)) return -1;
    } while(ch(j, ','));
    return ch(j, fecha) ? 0 : -1;
  }
  const char *ini = j->p;
  while(j->p < j->fim && strchr("0123456789+-.eEtruefalsn", *j->p)) j->p++;
  return j->p > ini ? 0 : -1;
}

/* true/false (outro valor: pula e vale 0) */
static int logico(js_t *j, int *v) {
  esp(j);
  *v = 0;
  if(j->fim - j->p >= 4 && !strncmp(j->p, "true", 4)) {
    j->p += 4;
    *v = 1;
    return 0;
  }
  return pular(j, 0);
}

static int inteiro(js_t *j, unsigned long long *v) {
  esp(j);
  *v = 0;
  int d = 0;
  while(j->p < j->fim && *j->p >= '0' && *j->p <= '9' && d < 18) {
    *v = *v * 10 + (unsigned long long)(*j->p++ - '0');
    d++;
  }
  return d ? 0 : pular(j, 0);
}

/* Um asset: guarda em r se casar com o padrao. casou += 1 quando casa. */
static int ler_asset(js_t *j, const char *padrao, gh_release_t *r, int *casou) {
  char nome[160] = "", digest[100] = "";
  unsigned long long tam = 0;
  if(!ch(j, '{')) return -1;
  if(!ch(j, '}')) {
    do {
      char chave[32];
      if(str_ou_pula(j, chave, sizeof chave) || !ch(j, ':')) return -1;
      int e = 0;
      if(!strcmp(chave, "name")) e = str_ou_pula(j, nome, sizeof nome);
      else if(!strcmp(chave, "digest")) e = str_ou_pula(j, digest, sizeof digest);
      else if(!strcmp(chave, "size")) e = inteiro(j, &tam);
      else e = pular(j, 1);
      if(e) return -1;
    } while(ch(j, ','));
    if(!ch(j, '}')) return -1;
  }
  if(nome[0] && gh_casa(padrao, nome)) {
    if(!*casou) {
      snprintf(r->asset, sizeof r->asset, "%s", nome);
      r->tamanho = tam;
      r->sha256[0] = 0;
      /* "sha256:" + 64 hex minusculos; outro formato = sem digest */
      if(!strncmp(digest, "sha256:", 7) && strlen(digest) == 71 && strspn(digest + 7, "0123456789abcdef") == 64)
        snprintf(r->sha256, sizeof r->sha256, "%s", digest + 7);
    }
    (*casou)++;
  }
  return 0;
}

/* Uma release. 0 = leu (r preenchido; draft/casou dizem o resto). */
static int ler_release(js_t *j, const char *padrao, gh_release_t *r, int *draft, int *casou) {
  memset(r, 0, sizeof *r);
  *draft = 0;
  *casou = 0;
  if(!ch(j, '{')) return -1;
  if(ch(j, '}')) return 0;
  do {
    char chave[32];
    if(str_ou_pula(j, chave, sizeof chave) || !ch(j, ':')) return -1;
    int e = 0;
    if(!strcmp(chave, "tag_name")) e = str_ou_pula(j, r->tag, sizeof r->tag);
    else if(!strcmp(chave, "prerelease")) e = logico(j, &r->pre);
    else if(!strcmp(chave, "draft")) e = logico(j, draft);
    else if(!strcmp(chave, "published_at")) e = str_ou_pula(j, r->publicado, sizeof r->publicado);
    else if(!strcmp(chave, "assets")) {
      if(!ch(j, '[')) return -1;
      if(!ch(j, ']')) {
        do {
          if(ler_asset(j, padrao, r, casou)) return -1;
        } while(ch(j, ','));
        if(!ch(j, ']')) return -1;
      }
    } else e = pular(j, 1);
    if(e) return -1;
  } while(ch(j, ','));
  return ch(j, '}') ? 0 : -1;
}

static void base_api(char *saida, size_t tam, int api) {
#ifndef __PROSPERO__
  const char *t = getenv("GLR_TESTE_GH");
  if(t && *t) {
    snprintf(saida, tam, "%s%s", t, api ? "" : "/dl");
    return;
  }
#endif
  snprintf(saida, tam, "%s", api ? "https://api.github.com" : "https://github.com");
}

void gh_url_asset(const char *repo, const gh_release_t *r, char *saida, size_t tam) {
  char base[160];
  base_api(base, sizeof base, 0);
  snprintf(saida, tam, "%s/%s/releases/download/%s/%s", base, repo, r->tag, r->asset);
}

/* 0.9.34: /releases/latest da 404 tanto sem release quanto sem repositorio: pergunta pelo repositorio (1 pedido a mais,
   so neste caso). 0 = respondeu 404/410/451 (removido ou privado); 1 = existe ou nao deu para saber (fica "sem release"). */
static int repo_existe(const char *base, const char *repo) {
  char url[400];
  snprintf(url, sizeof url, "%s/repos/%s", base, repo);
  if(reservar()) return 1;
  buf_t b = {0};
  int st = https_get(url, &b, MAX_RESPOSTA, 20);
  buf_free(&b);
  diario("github: %s: GET repo -> %d", repo, st);
  if(st == 403 || st == 429) bloquear();
  return !(st == 404 || st == 410 || st == 451);
}

int gh_consultar(const char *repo, int incluir_pre, const char *padrao, gh_release_t *r, int *http) {
  char base[160], url[400];
  memset(r, 0, sizeof *r);
  *http = -1;
  base_api(base, sizeof base, 1);
  if(incluir_pre) snprintf(url, sizeof url, "%s/repos/%s/releases?per_page=5", base, repo);
  else snprintf(url, sizeof url, "%s/repos/%s/releases/latest", base, repo);
  if(reservar()) {
    diario("github: %s: pedido nao feito (limite do glibren ou pausa depois de 403/429)", repo);
    return GH_LIMITE;
  }
  buf_t b = {0};
  int st = https_get(url, &b, MAX_RESPOSTA, 20);
  *http = st;
  diario("github: %s: GET %s -> %d (%zu bytes)", repo, incluir_pre ? "releases" : "releases/latest", st, b.n);
  int res = GH_OK;
  if(st < 0) res = GH_REDE;
  else if(st == 403 || st == 429) {
    bloquear();
    res = GH_LIMITE;
  } else if(st == 410 || st == 451 || (st == 404 && incluir_pre)) res = GH_REPO_SUMIU;   /* 0.9.34: lista 404 = repo sumiu */
  else if(st == 404) res = repo_existe(base, repo) ? GH_SEM_RELEASE : GH_REPO_SUMIU;   /* /latest 404: sem release ou sem repo */
  else if(st != 200) res = GH_HTTP;
  if(res != GH_OK) {
    buf_free(&b);
    return res;
  }
  js_t j = {b.d, b.d + b.n};
  int draft = 0, casou = 0, achou = 0;
  if(incluir_pre) {
    /* lista (mais nova primeiro): a primeira que nao e rascunho */
    if(!ch(&j, '[')) res = GH_JSON;
    else if(!ch(&j, ']')) {
      do {
        gh_release_t t;
        int d, c;
        if(achou) {
          if(pular(&j, 0)) res = GH_JSON;
          continue;
        }
        if(ler_release(&j, padrao, &t, &d, &c)) res = GH_JSON;
        else if(!d && t.tag[0]) {
          *r = t;
          casou = c;
          achou = 1;
        }
      } while(res == GH_OK && ch(&j, ','));
    }
  } else {
    if(ler_release(&j, padrao, r, &draft, &casou)) res = GH_JSON;
    else achou = r->tag[0] && !draft;
  }
  buf_free(&b);
  if(res != GH_OK) return res;
  if(!achou) return GH_SEM_RELEASE;
  if(!gh_nome_ok(r->tag, sizeof r->tag)) return GH_JSON;
  if(!casou) return GH_SEM_ASSET;
  if(casou > 1) return GH_VARIOS_ASSETS;
  if(!gh_nome_ok(r->asset, sizeof r->asset)) return GH_SEM_ASSET;
  return GH_OK;
}
