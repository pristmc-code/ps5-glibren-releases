// 0.9.30: pagina principal - filtro por formato (caixas por tipo), selecao, botao Converter e a pergunta de 3 escolhas
// (padrao / outro formato / cancelar), janela Conversoes (opcao geral + nivel avancado). Roda no Node do Windows com o
// Playwright do cache do npx (Edge ou Chrome instalados), chamado pelo testes/teste_conversao.sh com o glibren-pc e o
// Dump Forge falso no ar.
//   node teste_conversao_pagina.mjs http://127.0.0.1:8911 <pasta do pacote playwright>
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const [base, pw] = process.argv.slice(2);
const { chromium } = await import(pathToFileURL(path.join(pw, 'index.mjs')).href);
let ok = 0, falhas = 0;
const confere = (nome, cond, info = '') => { if (cond) { ok++; console.log('OK   ' + nome); } else { falhas++; console.log('FALHA ' + nome + (info ? ': ' + info : '')); } };

let navegador;
for (const channel of ['msedge', 'chrome']) { try { navegador = await chromium.launch({ channel }); break; } catch { /* outro */ } }
if (!navegador) { console.log('FALHA nenhum navegador abriu'); console.log('=== pagina 0 ok, 1 falhas'); process.exit(1); }

for (const tela of [{ w: 360, h: 780, nome: 'celular' }, { w: 1280, h: 800, nome: 'PC' }]) {
  const pagina = await navegador.newPage({ viewport: { width: tela.w, height: tela.h } });
  const n = s => `${s} (${tela.nome})`;
  await pagina.goto(base + '/');
  await pagina.click('#btnConectar');
  await pagina.waitForSelector('#corpoFtp .sel-item', { timeout: 20000 });
  await pagina.click('#filtrosFtp [data-filtro="todos"]');
  // caixas por formato: exfat, ffpkg, ffpfs, ffpfsc, pkg
  const chips = await pagina.$$eval('#chipsFtp [data-grupo="fmt"]', bs => bs.map(b => b.dataset.valor));
  confere(n('filtro: um botao por formato'), ['exfat', 'ffpkg', 'ffpfs', 'ffpfsc', 'pkg', 'pasta', 'compactado'].every(f => chips.includes(f)), chips.join(','));
  const semRolagem = () => pagina.evaluate(() => document.scrollingElement.scrollWidth <= innerWidth);
  // 0.9.31: pastas de jogo e compactados na lista, so Converter e Ocultar
  const linhas = () => pagina.$$eval('#corpoFtp tr', trs => trs.map(tr => ({ nome: tr.querySelector('.arq:not(.novo)')?.textContent || '',
    st: tr.querySelector('td.st')?.textContent || '', renomear: !!tr.querySelector('button.renomear'), ativar: !!tr.querySelector('.ativar') })));
  await pagina.click('#chipsFtp [data-valor="pasta"]');
  let ls = await linhas();
  confere(n('filtro pasta: as 2 pastas de jogo'), ls.length === 2 && ls.some(l => l.nome === 'PastaJogo-PPSA05555') && ls.some(l => l.nome === 'Ps4Pasta-CUSA06666'), ls.map(l => l.nome).join(','));
  confere(n('pasta: motivo claro, sem Renomear'), ls.every(l => l.st.includes('pasta de jogo') && !l.renomear && !l.ativar), ls.map(l => l.st).join('|'));
  await pagina.click('#chipsFtp [data-valor="pasta"]');
  await pagina.click('#chipsFtp [data-valor="compactado"]');
  ls = await linhas();
  const nomesC = ls.map(l => l.nome).sort().join(',');
  confere(n('filtro compactado: so o 1o volume'), nomesC === 'Arq-PPSA07777.zip,Arq2.part1.rar,Arq3.7z', nomesC);
  confere(n('compactado: motivo claro, sem Renomear'), ls.every(l => l.st.includes('compactado:') && !l.renomear), ls.map(l => l.st).join('|'));
  await pagina.$eval('#selTodos', c => c.click());
  const lote = await pagina.evaluate(() => ['btnCopiar', 'btnMover', 'btnExcluir', 'btnConverter', 'btnOcultar'].map(id => [id, document.getElementById(id).disabled, document.getElementById(id).textContent]));
  confere(n('compactados: Copiar/Mover/Excluir desligados'), lote.slice(0, 3).every(([, d, tx]) => d && tx.includes('(0)')), JSON.stringify(lote));
  confere(n('compactados: Converter (3) e Ocultar ligados'), !lote[3][1] && lote[3][2].includes('(3)') && !lote[4][1], JSON.stringify(lote));
  confere(n('compactados: dica no Excluir'), (await pagina.getAttribute('#btnExcluir', 'title')).includes('só Converter e Ocultar'));
  confere(n('lista com pastas/compactados: sem rolar de lado'), await semRolagem());
  await pagina.$eval('#selTodos', c => c.click());
  await pagina.click('#chipsFtp [data-valor="compactado"]');
  await pagina.click('#chipsFtp [data-valor="ffpkg"]');
  const nomes = await pagina.$$eval('#corpoFtp .arq:not(.novo)', ds => ds.map(d => d.textContent));
  confere(n('filtro ffpkg: so .ffpkg'), nomes.length >= 1 && nomes.every(x => x.endsWith('.ffpkg')), nomes.join(','));
  await pagina.$eval('#selTodos', c => c.click());
  const txt = await pagina.textContent('#btnConverter');
  confere(n('Converter (n) ligado'), txt.includes(`(${nomes.length})`) && !(await pagina.isDisabled('#btnConverter')), txt);
  await pagina.click('#btnConverter');
  await pagina.waitForSelector('#conversao.aberto');
  const padrao = await pagina.textContent('#cvPadrao');
  confere(n('pergunta: nome do formato padrao no botao'), /Converter para \.pkg \(FPKG\)/.test(padrao), padrao);
  const caixas = await pagina.$$eval('.cv-botoes button', bs => bs.filter(b => b.offsetParent).map(b => { const r = b.getBoundingClientRect(); return [Math.round(r.width), Math.round(r.top)]; }));
  confere(n('3 botoes lado a lado, mesma largura'), caixas.length === 3 && new Set(caixas.map(c => c[0])).size === 1 && new Set(caixas.map(c => c[1])).size === 1, JSON.stringify(caixas));
  confere(n('pergunta: sem rolar de lado'), await semRolagem());
  const reticencias = await pagina.$$eval('#conversao button, #janelaConv button', bs => bs.filter(b => getComputedStyle(b).textOverflow === 'ellipsis').length);
  confere(n('sem reticencias nos botoes'), reticencias === 0, String(reticencias));
  await pagina.click('#cvOutro');
  const outros = await pagina.$$eval('#cvOutros button[data-fmt]', bs => bs.map(b => b.dataset.fmt));
  confere(n('outro formato: lista com os 12'), outros.length === 12 && outros.includes('exfat_zstd') && outros.includes('pasta_lz4'), outros.join(','));
  // 0.9.31: formato com nivel mostra a escolha do nivel (avancado, Padrao primeiro); Voltar volta para a lista
  await pagina.click('#cvOutros button[data-fmt="exfat_zstd"]');
  confere(n('outro com nivel: escolha aparece'), await pagina.isVisible('#cvEscolha') && !(await pagina.isVisible('#cvOutros')) && !(await pagina.isVisible('#cvPadrao')));
  await pagina.click('#cvAvancado summary');
  const nivOutro = await pagina.$$eval('#cvNivel option', os => os.map(o => o.textContent));
  confere(n('outro com nivel: Padrao (recomendado) primeiro'), nivOutro[0] === 'Padrão (recomendado)' && nivOutro.some(x => x.startsWith('zstd 19')), nivOutro.join('|'));
  const bEsc = await pagina.$$eval('#cvEscolha .cv-botoes button', bs => bs.map(b => { const r = b.getBoundingClientRect(); return [Math.round(r.width), Math.round(r.top)]; }));
  confere(n('outro com nivel: 2 botoes lado a lado, mesma largura'), bEsc.length === 2 && bEsc[0][0] === bEsc[1][0] && bEsc[0][1] === bEsc[1][1] && bEsc[0][0] > 0, JSON.stringify(bEsc));
  confere(n('outro com nivel: botao com o formato'), (await pagina.textContent('#cvConfirmar')) === 'Converter para .exfat com zstd');
  confere(n('outro com nivel: sem rolar de lado'), await semRolagem());
  await pagina.click('#cvVoltar');
  confere(n('Voltar: lista de formatos de novo'), await pagina.isVisible('#cvOutros') && !(await pagina.isVisible('#cvEscolha')));
  if (tela.nome === 'PC') {   // PC: converte com nivel escolhido (zstd 19)
    await pagina.click('#cvOutros button[data-fmt="exfat_zstd"]');
    await pagina.click('#cvAvancado summary');
    await pagina.selectOption('#cvNivel', '19');
    await pagina.click('#cvConfirmar');
    await pagina.waitForSelector('#janelaConv.aberto', { timeout: 8000 });
    await pagina.waitForFunction(() => document.querySelector('#convLista').textContent.includes('-zstd.exfat'), null, { timeout: 8000 });
    const item = await pagina.textContent('#convLista');
    confere(n('outro com nivel: pedido com zstd 19'), item.includes('.exfat com zstd · zstd 19'), item.slice(0, 300));
    await pagina.click('#convFechar');
    await pagina.$eval('#selTodos', c => { if (!c.checked) c.click(); });
    await pagina.click('#btnConverter');
    await pagina.waitForSelector('#conversao.aberto');
    await pagina.click('#cvOutro');
  }
  if (tela.nome === 'PC') {   // na 2a volta o Outro ja virou .exfat: so cancela
    await pagina.click('#cvCancelar');
    confere(n('cancelar fecha'), !(await pagina.isVisible('#conversao')));
  } else {
    await pagina.click('#cvOutros button[data-fmt="exfat"]');
    await pagina.waitForSelector('#janelaConv.aberto', { timeout: 8000 });
    await pagina.waitForFunction(() => document.querySelector('#convLista').textContent.includes('Outro-CUSA00001.exfat'), null, { timeout: 8000 });
    confere(n('janela Conversoes com o andamento'), true);
    confere(n('Dump Forge no ar'), (await pagina.textContent('#convDf')).includes('no ar'));
  }
  if (!(await pagina.isVisible('#janelaConv'))) {
    // nada marcado: o mesmo botao vira "Conversoes" e abre a janela da opcao geral
    await pagina.$eval('#selTodos', c => c.click());
    const rot = await pagina.textContent('#btnConverter');
    confere(n('sem marcados: botao Conversoes'), rot.includes('Conversões') && !(await pagina.isDisabled('#btnConverter')), rot);
    await pagina.$eval('#btnConverter', b => b.click());
  }
  await pagina.waitForSelector('#janelaConv.aberto');
  const opcoes = await pagina.$$eval('#convPadrao option', os => os.length);
  confere(n('opcao geral: 12 formatos'), opcoes === 12, String(opcoes));
  await pagina.selectOption('#convPadrao', 'exfat');
  confere(n('formato sem nivel: avancado escondido'), !(await pagina.isVisible('#convAvancado')));
  await pagina.selectOption('#convPadrao', 'ffpkg_zstd');
  await pagina.click('#convAvancado summary');
  const niveis = await pagina.$$eval('#convNivel option', os => os.map(o => o.textContent));
  confere(n('nivel: Padrao (recomendado) primeiro'), niveis[0] === 'Padrão (recomendado)' && niveis.some(x => x.startsWith('zstd 19')), niveis.join('|'));
  // 0.9.36: chave "Mover o original para BACKUP" (ligada por padrao) e "Mover agora" nos itens cujo original ficou
  confere(n('mover: chave ligada por padrao'), await pagina.isChecked('#convMover'));
  const rotMover = await pagina.$eval('.conv-mover', l => ({ inteiro: l.scrollWidth <= l.clientWidth + 1, tx: l.textContent }));
  confere(n('mover: texto inteiro'), rotMover.inteiro && rotMover.tx.includes('Mover o original para BACKUP depois de converter'), JSON.stringify(rotMover));
  await pagina.uncheck('#convMover');
  await pagina.waitForTimeout(600);
  let est = await (await pagina.request.get(base + '/api/conversao')).json();
  confere(n('mover: desligar grava'), est.mover === false);
  await pagina.check('#convMover');
  await pagina.waitForTimeout(600);
  est = await (await pagina.request.get(base + '/api/conversao')).json();
  confere(n('mover: ligar de novo'), est.mover === true);
  await pagina.waitForSelector('#convLista .conv-mover-agora', { timeout: 20000 });
  const ma = await pagina.$eval('#convLista .conv-mover-agora', b => { const r = b.getBoundingClientRect(), p = b.parentElement.getBoundingClientRect();
    return { w: Math.round(r.width), pw: Math.round(p.width), tx: b.textContent, o: getComputedStyle(b).textOverflow, inteiro: b.scrollWidth <= b.clientWidth + 1 }; });
  confere(n('Mover agora: largura inteira, texto inteiro'), ma.w === ma.pw && ma.tx === 'Mover agora' && ma.o !== 'ellipsis' && ma.inteiro, JSON.stringify(ma));
  const bkTxt = await pagina.textContent('#convLista .conv-backup');
  confere(n('original ficou: motivo na tela'), bkTxt.includes('Original ficou no lugar: o arquivo convertido não foi achado'), bkTxt);
  confere(n('janela: sem rolar de lado'), await semRolagem());
  await pagina.selectOption('#convPadrao', 'pkg');
  await pagina.waitForTimeout(400);
  await pagina.close();
}
await navegador.close();
console.log(`=== pagina ${ok} ok, ${falhas} falhas`);
process.exit(falhas ? 1 : 0);
