# glibren — Game Library Renamer payload for PS5

A PS5 payload (`.elf`) that runs a small web app **on the console itself**. It renames your game files
to clean, readable names from their Title ID, and adds a file manager, batch copy / move / delete, a
temperature and fan monitor, a drive speed test and an internet speed test.

It is the console-side version of [Game Library Renamer](https://github.com/pristmc-code/ps5-game-library-renamer)
(the Windows app that does the same over FTP/SFTP). Here there is no FTP: the payload reads and renames the
files directly on the PS5.

```
PPSA08329-app.pkg          →  God_of_War_Ragnarok-PPSA08329-US-PS5.pkg
CUSA07408 God of War.pkg   →  God_of_War-CUSA07408-US-PS4.pkg
```

**Download (public, signed, with source):** [pristmc-code/ps5-glibren-releases](https://github.com/pristmc-code/ps5-glibren-releases) — send `glibren.elf` once; after that the payload updates itself from there.

> **Status: 0.1-test, private.** Everything below works in the PC test build (Linux/WSL, same C code).
> **It has not been run on a real PS5 yet.** See [Status and known risks](#status-and-known-risks).

![Games page (PC)](docs/jogos-pc.png)

| Temperature | Drives | Internet | Games |
|---|---|---|---|
| ![](docs/temperatura-celular.png) | ![](docs/discos-celular.png) | ![](docs/internet-celular.png) | ![](docs/jogos-celular.png) |

## How you use it

- **On the PS5:** an icon in the **Media** tab opens the app in the PS5 web browser, on top of whatever
  is running. You can keep a store app downloading games and open glibren next to it to rename what has
  finished. The layout is larger for TV.
- **On a PC or phone:** open `http://PS5-IP:8765` in any browser on the same network. There is a desktop
  layout and a compact phone layout. The PS5 notification shows the address when the payload starts.
- The page is in **English, Português (BR) and Español**.
- On a phone every page fits the screen without scrolling, upright or sideways, with or without full screen.
  In full screen, switching between Games, Temperature, Drives and Internet keeps the full screen.

## Features

### Rename games
- **File manager** to browse the PS5 folders and choose which ones go into the list (internal SSD, M.2,
  extended storage, USB drives). Only the root of each chosen folder is read, and only when you open the
  page or click **Read folders**.
- Finds the Title ID (`PPSA`, `CUSA`, …) in each file name and shows the game name, cover, platform,
  region, publisher, Content ID and **file size**.
- Proposes the new name `Game_Name-TITLEID-REGION-PS4|PS5` (no accents or special characters, spaces
  become `_`, the extension is kept - also a double one like `.exfat.complete`) with **Rename** per game and
  **Rename all**.
- Games that still need renaming are listed first; everything already named correctly goes below, in
  alphabetical order.
- Safe renaming: never overwrites, checks that the source still exists and its size has not changed,
  detects two files that would get the same name, and keeps the ShadowMountPlus path length limit.
- Never renames:
  - folders and compressed files (`.zip`, `.rar`, `.7z`, …);
  - patches and backports (`patch`, `backport`, `update` in the name);
  - files that are still downloading (`.part`, `.crdownload`, `.tmp`, …).
- Game names come from a local database of ~71,000 titles
  ([andshrew/PlayStation-Titles](https://github.com/andshrew/PlayStation-Titles)), downloaded by the PS5
  and refreshed once a day. Covers and publishers come from [prosperopatches.com](https://prosperopatches.com)
  (PS5) and [orbispatches.com](https://orbispatches.com) (PS4), cached on the PS5. Nothing is fetched from the
  Sony store.
- YouTube button per game (hidden in the PS5 browser, where it would open the YouTube app).

### Copy, move and delete in batch
- Checkboxes per game plus **Copy**, **Move** and **Delete** at the top.
- The destination can only be one of the listed folders. Files that already exist in the destination are
  skipped, never overwritten.
- Renaming while copying/moving is an option, off by default.
- Delete asks for confirmation in a warning that stays on screen at least 3 seconds before the button
  is enabled.
- Progress panel with every queued file, speed and remaining time. Copies are written as `.part` and only
  renamed when complete; free space is checked first; a move on the same drive is an instant rename.
- The folders are read again when the queue finishes.

### Temperature and fan
- CPU, SoC and M.2 SSD temperatures, fan speed (%), session maximums and an 8-minute chart.
- **BASIC / ADVANCED** view; advanced adds CPU use per core, RAM, IP and uptime. Since 0.9.22 also the **CPU and GPU
  clocks (MHz)**, **RAM and VRAM** from the kernel (`get_page_table_stats`) and **CPU use per core** from
  `sceKernelGetCpuUsage` (idle threads `SceIdleCpuN`); each line hides itself when the firmware does not have the function
  or the call fails (all calls go through the watchdog; absurd values hold the last good one for 10 s). Read only while
  the Temperature or FPS page is open. Idea seen in PrefBar (X1NONs, GPL-3.0), our own code.
- Optional notification on the PS5 screen when a temperature limit is passed (at most every 5 minutes).
- **Fan control:** choose the temperature at which the fan speeds up (50–85 °C, never above the console's
  own value). The payload checks every 2 seconds and applies it again, because the PS5 resets it when a
  game starts. If another program (for example ProsperoMgr) changes the value, glibren backs off and
  returns to automatic; after 5 failures in a row it also returns to automatic.
- Keeps running while you play, so you can watch it on the phone.

### PS5 clock from the internet
- Without PSN the PS5 never sets its clock, and a wrong clock breaks HTTPS (the YouTube apps find no videos).
  glibren checks the time when it starts, every 6 hours and after rest mode, against NTP servers
  (Cloudflare, NTP.br, Google, by IP, no DNS needed) and the `Date` header of an HTTPS site.
- It only changes the clock when most sources (at least two) agree within 3 seconds and the clock is more
  than 30 seconds off. It sets the UTC time; the time zone stays the one chosen on the PS5.
- **Clock** card on the Temperature page: automatic on/off, a **Check** button, the last result and the PS5
  time zone. Every check and fix goes to the log.

### Drive speed test
- Write and read speed of the internal SSD, extended storage and every USB drive, with 1, 2, 4 or 8 GB
  test files.
- The test file is deleted at the end, and leftovers from an interrupted test are removed when the
  payload starts.

### Internet speed test
- Ping (with jitter), download and upload, measured **by the PS5 itself**.
- **Server** box like speedtest.net: *Automatic (closest)*, the 10 nearest speedtest.net servers
  (the list is requested by the PS5, so it follows wherever the console is) or Cloudflare.
- Automatic mode pings the 5 closest servers, uses the fastest one that answers, and falls back to
  Cloudflare if the download fails.
- History of previous tests with the server used.

### Send diagnostics (0.9.21)
- **Apps → 📤 Send diagnostics** (page `/diagnostico`, also in the footer): sends the glibren log and the PS5 state to
  the owner's **private** GitHub repository `ps5-diagnosticos`, in `glibren/<YYYY-MM-DD_HHMMSS>/`, one file per
  GitHub API `PUT`. Then just tell the folder name.
- Key: a fine-grained GitHub token limited to that repository (Contents: read and write). glibren first uses the key
  that **Jobe** already saved on the same console (`/data/JobeesLair/diag/token`); otherwise paste it once on the page
  (kept in `/data/glibren/diag/token`, 0600). The key is never shown again (only "ends with …xxxx") and never logged.
  Saving, removing and sending need a paired device.
- What goes (each file cut to the last ~2 MB, then **cleaned**: keys, `Authorization`, cookies, query strings of
  links, e-mails, pairing tokens and hashes): `glibren.log`, `config.ini` (without paired devices), `info.json`
  (version, firmware), `termico.json` (temperatures, fan, power), `payloads.json`, `web-browser-fullscreen.ini`,
  `cheats.json`, `cheats-aplicadas.json`, `discos.json`.
- Fallback: **⬇ Download diagnostics (.zip)** with the same cleaned files.

### FPS: 1% low and worst frame (0.9.22)
- The FPS page also shows **1% low** (average FPS of the slowest 1% of the last 1000 frames) and the **worst frame** (ms):
  between the 250 ms reads the `/dev/dce` frame counter is read every ~2 ms, only while the page asks. Plus the CPU/GPU
  MHz, RAM, VRAM and per-core usage above. Idea seen in PrefBar, our own code.

### Test payloads (0.9.20)
- **Apps → 🧪 Test payloads** (page `/payloads`): third-party payloads that we checked, activated with one tap from the
  phone. The list is **fixed in the code**: each item has the GitHub release asset, its size and a **pinned SHA-256**
  (we downloaded the asset and computed it). Anything else is refused.
- **Activate** downloads it through glibren's HTTPS client (robust DNS), refuses it if the SHA-256 does not match,
  keeps it in `/data/glibren/payloads/`, checks it again and sends it to the elfldr (`127.0.0.1:9021`). The payload's
  own output comes back on the same connection (the elfldr wires its stdout to it), so the page shows the result
  ("Result=0 … succeeded") and the log keeps it. Status: not downloaded, ready, activated at HH:MM, error.
- Needs a paired device and no game/app open (if the PS5 interface restarts, the game would close without saving).
  The PS5 browser can only trigger the fullscreen item below.
- First item: **[ps5-web-browser-fullscreen](https://github.com/owendswang/ps5-web-browser-fullscreen) v0.1b**
  (owendswang, GPL-3.0-or-later): makes the PS5 web browser **fullscreen (1920×1080, no frame)** by patching the
  system UI in memory. Tested by the author on 4.03, 6.50, 7.00, 7.61, 10.01, 10.20, 11.20, 12.02, 12.20, 13.00 and
  13.60; **confirmed by us on a PS5 Pro 12.00** (13/11/2026, 0.9.23: works, and a restart undoes it). Undo: restart the PS5
  (glibren does not use the author's restore payload; on 11.60 it crashed the system UI).
- Second item (0.9.22): **[PrefBar](https://github.com/X1NONs/PrefBar) v0.3.0** (X1NONs, GPL-3.0), an on-screen bar
  over the game (FPS, 1% low, CPU/GPU, fan, RAM, VRAM, power). Pinned `Prefbar_V0.3.0.elf`, 964,272 bytes, SHA-256
  `e4379590115ef87b2f0310b502321d7da30783536d939bfb1c4c0e511972af30` (equal to GitHub's digest). The author lists
  7.xx–13.xx as supported; **not tested on a PS5 Pro 12.00**. Activate it **outside the game** (its README loads it first
  and then starts the game; it waits for the game and the system UI to be ready), wait ~2 min after turning the PS5 on.
  Undo: restart the PS5. **"⚙ Configure the bar"** edits `/data/prefbar/prefbar.conf` from the phone (position, horizontal
  bar, alignment, spacing, format, font, color, shadow, which numbers, touchpad toggle): every value is validated against
  the ranges PrefBar accepts and the file is written atomically (temp file + fsync + rename), keeping comments and
  unknown keys. PrefBar rereads it when a game opens.
- **One system-UI patch per PS5 session** (0.9.22): PrefBar and the browser fullscreen both change SceShellUI, so glibren
  refuses to activate one while the other is active in this session (`409 payload_conflito`), and refuses PrefBar twice
  (`payload_ja_ativo`). Each activation is recorded as "time + SceShellUI pid"; it stops counting after the PS5 restarts
  (time before `kern.boottime`) or when SceShellUI restarts (new pid). PrefBar started outside glibren is detected by its
  own status files in `/data/prefbar` changing after boot.
- **⛶ Full screen** on the glibren pages **in the PS5 browser** uses the same item, like the PS5 Web File Manager:
  the PS5 goes back to the home screen, the patch is applied and the browser reopens on the same page. Once the window
  is 1920×1080 the button hides itself.

## Install

Requirements: a jailbroken PS5 with an ELF loader (port **9021**). Nothing else is needed.

1. Send `glibren.elf` to the ELF loader (for example `nc -q0 PS5-IP 9021 < glibren.elf`), or add it to your
   autoloader so it starts with the console.
2. A notification shows the address (`http://PS5-IP:8765`). On the first run the payload also creates the
   **Game Library Renamer** icon in the Media tab (`/user/app/PMGL00001`), which opens `http://127.0.0.1:8765`.
   Like ProsperoMgr's tile, the icon only works while the payload is running.

Updates: the **Update** button downloads the signed new version to `/data/GameLibraryRenamer/glibren.elf` and
starts it. Your autoloader keeps sending the file it has, so from 0.8.2 on every start checks that saved file:
when it is newer and its signature is valid, the payload hands over to it. (Coming from 0.8.1 or older, replace
the `.elf` in your autoloader once.)

Apps window: installs, updates and **uninstalls** the homebrew apps of the signed catalog (ytps5, YouTube
Max'd) in `/data/homebrew/<TITLE_ID>`. Files get mode 0777, as with FTP (with 0644 the PS5 answers "Can't start
the game or app", CE-107750-0). Uninstall asks ShadowMountPlus to remove the title (its API on port 10101) and
deletes the folder.

**YouTube** box in the Apps window (PS5, PC and phone): opens YouTube Max'd on the PS5 with the typed search (or
empty, on the search screen). The payload writes `/data/homebrew/PPSA99991/glibren_busca.txt` (UTF-8, `.tmp` +
rename) with two lines: the search (may be empty) and `voltar=PMGL00001` (glibren's own Media icon), so that Max'd
reopens glibren when you leave it. The per-game YouTube button also adds that second line when it opens Max'd
(ytps5 keeps a one-line file).

**0.9.37 (test): each game's version and "a newer version exists at Sony".** The game list shows the version read
from inside each game (PS5 `contentVersion`, PS4 `APP_VER`/`VERSION`) and the minimum firmware it asks for. The PS5
itself never contacts Sony: the check is made by the Jobe Controle Android app (0.4-test, "Game versions" screen) or by
the Game Library Renamer PC app (1.3, "Check for updates at Sony"), which read `GET /api/versoes` (games with their
`versionJsonUri` from `param.json`), ask Sony's version server with its own root certificate pinned, and send the
results back with `POST /api/versoes` (paired device). glibren keeps them in `versoes.json` and the list then says
"⬆ 02.000.003 is available (needs firmware 14.20)", in red when that firmware is higher than the console's, with "checked
on DD/MM HH:MM". New filter "⬆ With update". Since 0.9.38 PS4 games are checked too (the phone/PC app builds
the PS4 update address from the title ID); their firmware is shown as "needs PS4 firmware X.YY", for reference only.

**0.9.36 (test): the original goes to BACKUP after converting.** When a conversion finishes and the result is checked
(it exists; a file larger than 0 bytes; a game folder with eboot.bin + sce_sys), the original is moved to
`<drive>/BACKUP/<game>/` on the same drive (just a rename, nothing is copied): images (.exfat/.ffpkg/.ffpfs/.ffpfsc/.pkg),
game folders and archives (zip/7z/rar, all volumes of a multi-part RAR together: `.partN.rar` or `.rar` + `.r00`...). It is
the same place and marker Jobe uses (`.jobe-backup.json` with `titleId`, `platform`, `format`, `source: "glibren"`; the
folder name is the game title made safe, an existing one gets " (2)"), so the original shows up in Jobe's BACKUP list,
where it can be deleted. A failed, cancelled or stopped conversion never moves anything. If the original is mounted by
ShadowMount+/ShadowKraken, glibren asks it to unmount first (it refuses while the game is open); if it cannot be released
safely (game open, image held, ShadowMount+ running but not answering) the original stays and the Conversions window says
why, with a "Move now" button. After a move glibren asks ShadowMount+ to rescan. ShadowMount+/ShadowKraken do not scan
BACKUP (default depth 1, at most 2; the original sits at depth 3 inside `BACKUP/<game>/`). Option "Move the original to
BACKUP after converting" in the Conversions window, on by default (`convert_backup = off` in config.ini turns it off). A
list folder inside BACKUP has its items marked "original kept in BACKUP" instead of counting as extra games.

**0.9.35 (test): ZhiThemes on the Payloads page + a GitHub link on every item.** New tracked item: ZhiThemes
(itsRealZhi/ZhiThemes, GPL-3.0, by Zhi): themes for the PS5's real home screen (game folders, vertical covers, picture or
video wallpaper, font, a new top bar, themed Settings and Trophies), edited from a PC or phone at `http://<PS5-IP>:4444`.
It only has a pre-release (v0.1.0-alpha), so the item takes it and installs only `ZhiThemes.elf` (the release's
`ZhiThemes-themes.zip` with ready-made themes is not installed by glibren). It is alpha, changes the home screen in memory
only (it writes only to /data/ZhiThemes), counts as a PS5 interface patch (one per session, like the browser fullscreen
and PrefBar), and its editor on port 4444 has no password. "Running now" comes from its `GET /version` on port 4444,
with the version. To undo: restart the PS5 without sending it again. Not tested by us on the PS5 Pro 12.00. Every item
with a GitHub repository now also has a "Project page on GitHub" link (new tab).

**0.9.34 (test): GitHub repository gone (404) + BlueV + cheats that need a new area.** A tracked repository that
answers 404 (removed or private) now shows "Repository unavailable on GitHub" on its line, with no generic error and no
new question on every page open (that answer is kept for 24 h); the other items keep working. ShadowKraken
(MNeroba/ShadowKraken) was removed from GitHub on 17/11/2026: if it is not saved on the PS5 the item is gone; if it is,
it stays for Activate, "Go back" (when a previous one is saved) and a new "Remove from glibren" button, with the note
"Repository removed from GitHub on 17/11/2026; no updates". New tracked item: BlueV (0xZ3n0x/BlueV, PS5 sound on
Bluetooth A2DP speakers/headphones; "running now" by its page on port 7733). Cheats: a cheat whose extra area does
not exist in the game (it would have to create one) now says "This cheat needs to create a new area in the game;
glibren does not do that. Use onionHEN for it."; an area that exists but could not be read keeps its own reason.

**0.9.33 (test): payloads tracked on GitHub (install and update) + "running now".** The Payloads page now installs
and updates payloads that the PS5 Payload Manager does not offer updates for: PS5 Dump Forge (quer3q/ps5-dump-forge,
was pinned to v0.5.6), kraken-mount (quer3q/kraken-mount) and ShadowKraken (MNeroba/ShadowKraken, pre-releases only,
shown as "EXPERIMENTAL"); PS5 Web Browser Fullscreen and PrefBar, pinned until now, are tracked the same way
(their special handling stays: fullscreen from the PS5 browser reopening the page; PrefBar settings). Files already
kept by older versions are adopted as the installed version when their SHA-256 matches the old pinned one. glibren asks the public GitHub API (no token) for the latest release, picks the single asset
that matches the item's pattern (`ps5-dump-forge-*-ps5.elf`, `kraken-mount.elf`, `ShadowKraken.elf`, `web-browser-fullscreen-*.elf`, `*.elf` for PrefBar) and shows
installed x available with Install / Update. The download comes from GitHub over HTTPS and is checked against the
SHA-256 `digest` that the GitHub API reports for that asset; **if the API does not report a digest, glibren refuses to
install** (no "unchecked" option). Size limit per item, written to `<id>.elf.tmp` then renamed; the previous version is
kept (`<id>.anterior.elf` + `.info`) for "Go back to vX". Activation uses the same elfldr path and rules (paired
phone/PC + X-GLR, not from the PS5 browser, refused with a game open). kraken-mount and ShadowKraken do not run together
with ShadowMount+: activating them needs an explicit confirmation and glibren never stops ShadowMount+ (ShadowKraken
itself replaces it). Checks: when the page opens (cache of 1 h) and with "Check for updates" (at most once a minute per
item); glibren limits itself to 30 API calls per hour and pauses 30 min after a 403/429. Each item also shows whether
it is **running now** (Dump Forge: `GET :8095/api/session`; kraken-mount: `GET :8097/api/state`; ShadowKraken and
ShadowMount+: their API `POST /api/v1/version` and the process `shadowmountplus.elf`), with the running version and a
warning when it differs from the installed one; a top card shows whether ShadowMount+ (or ShadowKraken) is running. The
PS5 notification at start now shows the loaded version too ("Game Library Renamer 0.9.33-teste" + address). Tested on
PC only (🖥️) with a fake GitHub. Adding other repositories by hand was left for later.


**0.9.32 (test): cheats with an execute-only extra area ("--x") can be turned on.** On the PS5 the game code is
execute-only, so code caves inside it show as "--x". With the "Extra area (test)" switch on, glibren now accepts them
like onionHEN does, as long as reading the area through the kernel works and returns exactly the expected zeros. It
still writes the area first and the jump after (turning off in reverse), reads back every write and undoes on failure.
It still never creates a new area.

**0.9.31 (test): game folders and archives in the list; level in "Another format".** The list now also shows game
folders (a folder with `eboot.bin` and `sce_sys/param.json` or `param.sfo`, as ShadowMount+ sees it; name and icon read
from inside) and `.zip`/`.7z`/`.rar` archives (first volume only), with "folder" and "zip/7z/rar" boxes in the format
filter, so they can be marked and converted. They are never renamed, copied, moved or deleted by glibren (the row says
so; only Convert and Hide apply). In "Another format", a format with compression levels (zstd, LZ4, zlib, Kraken) now
asks for the level (advanced, "Default (recommended)" first) before converting.

**0.9.30 (test): convert game formats (engine: PS5 Dump Forge).** Mark games in the list and press "🔁 Convert (n)":
a question offers "Convert to <default format>", "Another format" (the full list, one line of gain/loss each) or
"Cancel". Formats: `.exfat`, `.ffpkg`, `.ffpfs`, `.ffpfsc`, `.pkg` (debug FPKG, Kraken; runs directly only with
kraken-mount/ShadowKraken, ShadowMount+ only installs it), plain folder, zstd folder, LZ4 folder, and images with zstd
packs inside (`.exfat`/`.ffpkg`/`.ffpfs`/`.ffpfsc` + zstd; zstd/LZ4 need ampr-emu-ng, which Dump Forge adds). With
nothing marked the same button opens "Conversions": the general option (default format, plus the compression level as
an advanced option, "Default (recommended)" first), Dump Forge status, progress, errors and cancel. The new file goes
next to the source (same name, new extension; zstd/LZ4 get `-zstd`/`-lz4`); the source is never deleted and an existing
target is refused. glibren converts nothing by itself: it calls the local API of
[ps5-dump-forge](https://github.com/quer3q/ps5-dump-forge) (quer3q, GPL-3.0, v0.5.6) on 127.0.0.1:8095, which you
start from the Payloads page (new "PS5 Dump Forge" item, pinned URL/size/SHA-256, from a paired phone or PC). The
list filter now has one box per format (exFAT, ffpkg, ffpfs, ffpfsc, pkg).

**0.9.29 (test): browse the internet.** The PS5 browser has no address bar, so glibren now has an "Internet" way
in: the "Open in the PS5 browser" dialog (phone/paired PC) has a 4th button, "🌍 Internet (Google)", that goes to the
home screen and opens the PS5 browser on https://www.google.com/ (fixed address, still no URL from the request); and
inside the PS5 browser the main screen shows a "🌍 Browse" shortcut to the same page.

**0.9.28 (test): "rename first" default order.** When no sort is chosen in the Sort bar, reading the folders now
lists first what still has to be renamed (ready, name conflict, rename failed), in folder order; then what is never
renamed or is still being looked up (patch/backport, no code, still downloading, not found); and last what already
has the right name, A to Z. Choosing Name, Size or Extension still decides the order, and the third tap goes back to
this default. Only the page changed (`web/index.html`).

**0.9.27 (test): "Start the Jobe payload" (Jobee'sLair downloads without opening the app).** A card on the
**Payloads** page shows whether Jobe's download payload (bg-downloader) is running ("Running v1.37.2" / "Not running")
and a button that sends to the elfldr the copy Jobe itself left on the PS5 in `/data/JobeesLair/bg`. Nothing is
downloaded except a small manifest, and nothing is sent unless it checks out: `bg-downloader.elf` (or `.prev.elf`) only
with its signed manifest (Ed25519 over `"jobe-bg-signature-v1\n"` + the manifest, Jobe's key = glibren's public key)
and the same size and SHA-256, not marked bad in `self-update.json` and compatible with the installed Jobe
(`app.json`); `embedded.elf` only when its SHA-256 matches a signed manifest (a local one, or the
`bg-downloader-<version>` release manifest fetched from GitHub at that moment). The newest checked copy is sent; the
file is read again and re-hashed right before sending. Refused when the payload is already running (port 34200
answers): the bg-downloader keeps a single copy through its lock (a new copy SIGTERMs the old one and takes over), so a
second send would restart it. The status probe is a `GET /health` WITHOUT Jobe's token (it answers 401 and does not
count as "the app is talking"); the version comes from its log line `==== iniciando bg-downloader X ... pid N` matching
`bgdl.pid`. Pairing + `X-GLR` like the other actions; the PS5 browser may use it, other local programs may not. The card
also explains how to start it with the console: put `bg-downloader.elf` from the newest `bg-downloader-X.Y.Z` release
next to `glibren.elf` in your autoloader folder and add it to `autoload.txt` after `glibren.elf`. Limit (Jobe side):
until Jobe opens once in that session, the payload has no TorBox key (it only gets it from the app or from the app's
own mounted folder), so expiring TorBox links and new phone requests wait for Jobe.

**0.9.26 (test): `.xml` cheats can be turned on and off, and "--x" extra areas are counted right.** The Illusion
`.xml` format has no "off" value, so turning a patch on first reads and saves the ORIGINAL bytes (in memory and in
`aplicadas.json`, `"fonte":"xml"`), writes and reads back; turning it off puts the saved originals back and checks them.
Same engine as phase 1: one action at a time, a partial write is undone, everything is restored when glibren closes,
refused if the game pid/app changed or if it overlaps another cheat that is on. `mask` patches only when the pattern
is found exactly once in the game module (ambiguous or missing stay "not supported"); `mask_jump32` only with the
extra area test option on and a target area that exists, is r-x, inside the module and zeroed (otherwise "not
supported" with the reason). Bug seen on a real PS5 (Terminator 2D): with the test option on, Easy Score and 10x Score
showed "extra area: --x" (execute-only page) but the summary said "5 can be turned on". Now an area without read
access counts as "can't turn on", the cheat line says "can't turn on: the game area is execute-only (--x)" (pt-BR, en,
es; wraps, no ellipsis) and its switch is disabled.

**0.9.23 (test): game cheats, phase 2 (.shn, .mc4 and .xml).** Phase 1 (turn on and off a `.json` cheat from the phone)
was confirmed on a real PS5 Pro 12.00 on 13/11/2026; phase 2 is tested on PC only. `/cheats` also reads `.shn` (GoldHEN/PS4 Cheats
Manager XML "Trainer"), `.mc4` (the same XML, Base64 of AES-256-CBC with the public GoldHEN Cheat Manager key, PKCS#7
padding; decoded by our own AES) and Illusion PS4-PS5-Game-Patch `.xml` (`<TITLE_ID>.xml` or
`<TITLE_ID>_<VERSION>.xml` in the onionHEN folder or `/data/glibren/cheats/xml/`). The catalog download now keeps
`cheats/json`, `cheats/shn` and `cheats/mc4`. When a game has files in several formats the order is json > shn > mc4 >
xml, and a lower-priority file with exactly the same patches is left out (listed in `ignorados`). `.shn`/`.mc4` cheats
are turned on and off with the same safe engine as `.json` (check `off` first, read back, undo, restore); `.xml` is
read only (no `off` value): direct addresses show the bytes read, `mask` patterns are searched in the module ranges
and a pattern found zero or several times makes the cheat "not supported". `<StartUP>` blocks (startup/master code)
must be on before the other cheats of the file, and a cheat that jumps (E8/E9/0F 8x rel32) into another cheat's extra
area needs that cheat on first (and it cannot be turned off before). "Extra area" (code cave) cheats stay off unless
`cheats_area_extra = on` is in `config.ini` (test option); even then glibren only uses an area that already exists,
reads as the `off` zeros and is in an executable page of the game (checked with the SDK's read-only
`kernel_get_vmem_protection`); it writes the area first and the jump after, and puts the zeros back last. Creating an
area like onionHEN does (ptrace + mmap inside the game + mprotect) is not done. `glibren-pc --teste-cheat FILE TID
VERSION` prints how a cheat file is read (`testes/cheats_reais.py` compares it with every real catalog file).
Also in 0.9.23: **Send diagnostics** no longer hides public hashes (a 40/64-digit hex value right after `sha256`, `sha1`,
`sha` or `commit`, such as the pinned SHA-256 in `payloads.json`; a known secret is still hidden), and each upload is
**retried up to 3 times** (network error, 408, 429, 5xx; waits 1 s and 2 s). A file that still fails is listed as
missing and the others still go; a refused key (401/403/404) or two files in a row failing stop the round. The page
says how many went up and which are missing (`"faltaram"` in `GET /api/diagnostico`). The **browser fullscreen**
v0.1b is now marked as **confirmed by us on 12.00** (PS5 Pro, 13/11/2026: works, and a restart undoes it), so the
page says "tested" on 12.00 (`confirmados`, `confirmado_em`, `confirmado_no_seu` in `/api/payloads`).

**0.9.19 (test): screens without cut text.** No page cuts text with "…" any more: a text longer than its line wraps
and its card grows (Temperature clock and USB SSD notes, the Drives note, titles, labels, the main screen summaries,
the YouTube test page). Only native drop-downs keep the browser's own cut (internet server list); on narrow phones the
language list shows short names (PT (BR), EN, ES) instead of a cut "Português (". Buttons in the same row have the
same width: the main screen chips on PC and PS5 (a grid of equal columns, the width of the widest chip, split evenly
when they need two rows: 4 + 4 on a 1280 px PC, 5 in one row on the PS5; the full-screen chip got its name), the
folder buttons, BASIC/ADVANCED and Apply/Automatic on the Temperature page. Temperature in ADVANCED mode now fits
without scrolling on a 360x780 phone (it was ~140 px too tall; ~210 px with long notes), 780x360 and 1280x800 (on PC
and PS5 the advanced card moved above the chart). The YouTube test page no longer overflows on phones; the FPS page
header wraps in Spanish on a landscape phone (the full-screen button was off screen).

**0.9.18 (test): game cheats, phase 1 (turn on and off).** Each cheat on `/cheats` gets a switch (a confirmation the
first time per session). `POST /api/cheats/ligar` and `/api/cheats/desligar` (`{tid, versao, arquivo, indice}`, JSON or
form) need pairing and `X-GLR`, and are refused for the PS5 browser and for any other program on the PS5 (127.0.0.1).
Writes use the SDK's `kernel_proc_copyin` (mdbg write, then page-table walk through the DMAP), always read back.
Safety rules: turning on requires the current bytes of every patch to match the file's `off` (otherwise it refuses and
says why); the original bytes are saved in memory and in `/data/glibren/cheats/aplicadas.json` (pid, app id, title id,
version, addresses) before anything is written; patches are written in order and the ones already written are undone if
one fails. Turning off requires the bytes to match `on` and restores the originals. If the game's pid or app id
changes, the cheats that were on become "lost" and nothing is written. Closing glibren (`/api/sair` or SIGTERM) puts
the originals back if the game is still the same; after a crash (SIGKILL) the next copy takes the list back for the
same game. Not supported yet (shown as such, with the reason): code caves ("extra area": `off` all zeros), `section != 0`,
absolute addresses, patches without `off` and processes other than `eboot.bin`. One write at a time; every action goes
to the log (`cheats: ligou/desligou <name> em <TID>` and the read back). Reads and writes are split so that no call
crosses a 4 KB page (the SDK v0.45 DMAP loop copies too many bytes when a range crosses a page). Also fixed: the
summary counted readable code-cave patches twice ("5 of 9" with 7 patches); it now says how many patches of each type
there are, and each cheat shows its real state. Reading was confirmed on a real PS5 Pro on firmware 12.00 (Terminator
2D: NO FATE, PPSA25872); writing is still untested on the console.

**0.9.17 (test): game cheats, phase 0 (READ ONLY).** A new page `/cheats` (phone or PC only: the PS5 browser
gets a 403; nothing is drawn on the PS5 screen) shows the open game and its version (`contentVersion` of the
installed `param.json`; PS4: `VERSION`/`APP_VER` of `param.sfo`), lists the `.json` cheats of the
[HEN-Cheats-Collection](https://github.com/TeeKay87/HEN-Cheats-Collection) catalog (downloaded on request to
`/data/glibren/cheats/json/`) and of `/data/OnionHEN/cheats/` for that exact version, and for every cheat READS the
current bytes of the game memory to show whether they match the file's "off" (version confirmed) or "on" value.
Nothing is written to the game: there is no write function and no write route; turning cheats on and off is phase 1.
Downloading the catalog is a POST that needs pairing (0.9.16), like the other actions that change files. Cheats are for offline play only: using them online can get the PSN account banned (the page says so).
The main screen (phone/PC only) and the FPS page link to it. Also in 0.9.17: the Temperature page fits a 360x780 phone
again with the USB SSD card shown (and a 1280x800 PC screen); clock and USB texts wrap instead of being cut; the
Internet page shortcuts have the same width, like the other pages.

**0.9.16 (test): pairing, safe eject, chip power, watchdog, foreground, robust DNS.**
- **Pairing by a code shown on the TV.** Reading stays open, but actions that delete, move, rename, update, eject,
  activate or switch apps (plus power off and stopping the payload) need a paired device. The page asks for the code,
  the PS5 shows a 6-digit code in a notification (valid 2 min, 5 wrong tries, growing lock-out), and the browser keeps
  a token in `localStorage` (the payload keeps only its SHA-256 in `config.ini`, `paired = ...`). Requests from
  127.0.0.1 (the PS5's own browser, the Jobe, YouTube Max'd's `/launch`) are exempt. To turn pairing off, write
  `pairing = off` in `/data/GameLibraryRenamer/config.ini` and restart the payload (no known external caller needs it:
  the PC app talks FTP, the Jobe uses files and its own `/switch`, the glibren Controle app is a WebView with storage).
- **Eject USB safely** (Drives page, "⏏ Eject" next to Test): `sync()`, unmount the app views (nullfs) that come from
  the drive, then `unmount`. If the drive is busy it lists who has files open on it (`KERN_PROC_FILEDESC`) and closes
  nothing; forcing (`MNT_FORCE`) needs a second, explicit confirmation. Only `/mnt/usb<N>` can be ejected (never
  `/data`, `/user`, `/system*`, `/mnt/ext*`...), and not while a copy or a speed test runs.
- **Chip power** on the Temperature page ("Chip power: N W", `sceKernelGetSocPowerConsumption`, optional; hidden when
  the firmware does not report it).
- **Watchdog for system calls**: temperature, fan, LncUtil and SystemService calls run in a thread with a deadline; a
  call that hangs is skipped until it returns (third time: off for the session), so the page never freezes.
- **Foreground from `kern.msgbuf`** (`SetControllerFocus`, `VideoOut: shared`): when present, `/launch` waits for the
  focus to leave the old app (+3 s) instead of a fixed 15 s (15 s stays the limit and the fallback); `/api/primeiro-plano`
  and a diagnostics button on the FPS page; the FPS page takes the game name from the foreground when available.
- **Robust DNS** for GitHub, the catalog and the cover sites only (never Sony hosts): UDP → TCP → DNS-over-HTTPS
  (1.1.1.1 / 8.8.8.8 fixed, with embedded root certificates), 600 s / 20 s cache also kept in `dns_cache.txt`.

**Game FPS page redesign (0.9.15, test).** The `/fps` page now shows the open game's cover (from `/icone/<CODE>`, which also serves the installed game's own `icon0.png`) and its full name in up to two lines, with the chart filling the rest of the screen; a lost connection no longer replaces the game name.

**Game FPS (0.9.14, test).** A new page `/fps` (phone or PC only: the PS5 browser gets a 403 and the shortcut is
hidden there; nothing is drawn on the PS5 screen) shows the frame rate of the open PS5 game, the session average and
minimum, and a 5-minute chart. It reads the display flip counter of `/dev/dce` with one read-only ioctl (technique from
PHU Games Tools / onionHEN, as used in rawalakshay's fps-monitor-panel; our own C code): the game is not touched and no
game memory is read. It only reads while the page is open (the first request starts it, it stops by itself ~10 s after
the last one). It is the screen's rate, not the game's: still to be confirmed on a real PS5. PS4 games are not measured.

**Interface (0.9.13).** Buttons are updated in place instead of being recreated on every refresh (a tap on Cancel is
no longer lost), the game list redraws only the rows that changed, the Activity panel has "Cancel all", confirmations
open with the focus on Cancel, server errors are translated into English and Spanish, phone touch targets are at least
40 px, and the Temperature page fits a landscape phone in Advanced mode (the duplicated fan block was removed).

**Update and network hardening (0.9.12).** An update is accepted only if the downloaded `.elf` carries the announced
version and it is newer than the running one (no going back); app catalog updates likewise need a higher version. A
saved version that does not answer on the port within 60 s (or crashes three times in a row) is renamed to `.ruim` and
the previous copy keeps running. Updating waits for queued copy/move/delete tasks, drive tests and app installs; apps
are not installed or removed while open. Every request must use an IP address or `localhost` as Host (blocks DNS
rebinding), delete/move/copy/rename only work inside the folders in the list, URLs with `@` are refused and the
speed-test servers are only allowed for the speed test.

**Safer copy, move and delete (0.9.10).** Copies are flushed to disk every 256 MB and before the source of a move is
deleted; a copy in progress uses its own `.glr-part` suffix, and leftovers from an interrupted copy are removed at start.
Files still downloading are not copied or moved (and not deleted while they are being written). Copy, move and delete
act only on the files you can see in the list, and every refusal says why. The Read button of the USB SSD card only
sends the Realtek vendor command to a Realtek enclosure, and never while a copy or a drive test is running.

**USB SSD temperature (0.9.8-0.9.9, test).** The Temperature page has a "SSD in USB enclosure (test)" card with a Read
button. It asks an NVMe SSD in a Realtek RTL9210 enclosure for its SMART temperature (read-only SCSI pass-through,
vendor command 0xE4, the same method smartmontools uses; 0.9.9 also tries the standard SCSI LOG SENSE temperature
page) and also lists the PS5's SoC sensor channels 0..15. The
details are shown on the page and written to the log (`ssd usb:` lines).

**Game search (0.9.7).** A "Search game (name or code)" box at the top of the sort/filter bar narrows the list as
you type: it looks in the file name, the corrected name, the PPSA/CUSA code and the database name; every word must
match, ignoring accents and case ("_", "-" and "." count as spaces). It works together with the other filters.

**YouTube in Jobe (0.9.6).** When Jobe (`PPSA99471`) is installed and announces it can play YouTube
(`/data/JobeesLair/tube/jobe-tube.txt`, written by Jobe itself), both YouTube buttons (the Apps box and the
per-game one) open Jobe instead: the payload writes `/data/JobeesLair/tube/abrir.txt` (UTF-8, `.tmp` + rename,
folder created if missing) with the search (up to 200 bytes, may be empty in the Apps box) and `voltar=PMGL00001`,
no trailing newline, and launches Jobe with the same rules; Jobe goes back to glibren by itself when you leave.
Without that, the old behavior (ytps5 / Max'd). The line under the search box says where it opens ("Opens in
Jobe" / "Opens in YouTube Max'd"); `/api/apps` reports it as `youtube_destino` (`jobe`, `maxd` or empty).

**Never on top of another app.** Launching a title while another app is open fails (0x80940011 / 0x80940031) and is
suspected of crashing the console. So when a game/app is open (any title in `/user/appmeta` or `/data/homebrew`
for which `sceLncUtilGetAppId` answers >= 0, except glibren's own `PMGL00001`, which is just its page in the
system browser), both YouTube buttons write nothing, launch nothing and answer the key `app_aberto` with the open
title in `params.nome`; the page says "Close the open app (Jobe) and try again".

Local launch endpoint, for other apps on the PS5 (for example Max'd going back to glibren when it closes):

```
POST http://127.0.0.1:8765/launch
Content-Type: application/json
{"title":"PMGL00001","from":"PPSA99991"}
```

- with `from` (the title open now): answers `200 {"ok":true,"pending":true,"title":"...","from":"..."}` at once;
  a thread waits for `from` to close (up to 2 min, then gives up), waits ~15 s and launches with up to 4 attempts
  (pauses 5/10/20 s, skipping an attempt while another app is open), each result in `glibren.log`. A new request
  replaces the pending one. `GET /api/launch` shows its state (`esperando`, `aguardando`, `lancando`, `aberto`,
  `desistiu`, `falhou`). Same contract as `POST /switch` of Jobe's background payload (127.0.0.1:34200);
- without `from`: launches only when no game/app is open, otherwise `409 {"ok":false,"error":"app_aberto",
  "open":"<title>"}`;

- only from the PS5 itself: the connection must come from `127.0.0.0/8` and `Host` must be `127.0.0.1` or
  `localhost` (with or without port); anything else gets `403`;
- `Content-Type: application/json` is required (`415` otherwise) - a web page can't send it without a CORS
  preflight, which glibren never allows;
- `title` must be one of `PPSA99471` (Jobe), `PPSA99991` (YouTube Max'd), `PPSA99350` (ytps5), `PMGL00001`
  (glibren); other titles get `403`, a malformed body (or `from` not like `PPSA00000`) `400`;
- the title is opened with `sceSystemServiceLaunchApp`, nothing is closed. Immediate answer `200
  {"ok":true,"title":"..."}`, or `502 {"ok":false,"chave":"launch","erro":"... (0x8...)"}` when the PS5 refuses.
3. Open the icon on the PS5, or the address on a PC or phone.

How it stays running (same approach as ProsperoMgr and websrv): the payload raises its own process
credentials, names its process `glibren.elf`, kills older copies with that name, ignores `SIGPIPE`
(a browser closing a connection can't kill it), uses 1 MB thread stacks, and reopens its port after rest mode
(`SIGCONT`). If it ever crashes, a PS5 notification says so and the reason is written to
`/data/GameLibraryRenamer/glibren.log`.

The log can also be read in a browser at `http://PS5-IP:8765/diario`.

Data is kept in `/data/GameLibraryRenamer/` (settings, title database, lookup cache, covers, fan setting, log).

## Build

The SDK only builds on Linux/macOS. On Windows, use WSL.

1. Install [ps5-payload-sdk](https://github.com/ps5-payload-dev/sdk) (v0.45 was used) in
   `/opt/ps5-payload-sdk`, plus `clang-18`, `lld-18`, `make`, `xxd`, `gzip`, `curl` and `rsync`.
2. Build:
   ```sh
   make                 # glibren.elf (payload; it creates its Media icon when it runs)
   make pc              # glibren-pc: Linux build of the same code, for testing without a PS5
   make test PS5_HOST=192.168.x.x   # sends glibren.elf to the PS5 ELF loader
   ```
   `compilar.sh` does the same from Windows: it copies the sources to the WSL file system, builds there and
   copies the results back to `saida/`:
   ```sh
   wsl -d Ubuntu-24.04 -u root -- bash compilar.sh all pc
   ```

The pages in `web/` are embedded in the ELF at build time (plain and gzip versions, via `xxd`).

### Testing without a PS5

`glibren-pc` runs the same server on Linux. HTTPS uses `curl` instead of the PS5 libraries, and the "PS5
folders" are ordinary folders.

- `testes/demo.sh` starts a demo on `http://localhost:8765` with fake folders and games (`demo.sh parar` stops it).
- `testes/teste_api.sh` is an API test suite.
- `testes/teste_tarefas.sh` tests the copy/move/delete queue.
- `testes/comparar_nomes.py base_titulos.tsv` checks that the JavaScript naming rule gives the same result as
  the Windows app for every title in the database.
- `GLR_DEMO_MBPS=120` (PC build only) slows copies and the drive test down, to see the progress screens.

## How it works

The C side is thin: it serves the pages and a JSON API and does only what a browser cannot do (files,
console sensors, HTTPS without CORS). The naming rules run in JavaScript in the page, ported from the
Windows app.

| Part | Where | File |
|---|---|---|
| HTTP server (thread per connection, port 8765) | payload | `src/http.c` |
| Routes / API | payload | `src/api.c` |
| File manager, folder reading, safe rename | payload | `src/arquivos.c` |
| Copy / move / delete queue | payload | `src/tarefas.c` |
| Temperatures, fan, alerts | payload | `src/termico.c` |
| CPU per core, RAM, uptime, IP | payload | `src/sistema.c` |
| Game FPS from the display counter (on demand, test) | payload | `src/fps.c` |
| Drive list and speed test | payload | `src/discos.c` |
| Internet speed test and server list | payload | `src/internet.c` |
| HTTPS client (sceHttp2 on PS5, curl on PC), host allow-list | payload | `src/https.c` |
| Settings | payload | `src/config.c` |
| Permissions, process name, old copies, log, crash notice, Media icon | payload | `src/plataforma.c` |
| Media icon image | payload | `instalador/icon0.png` |
| Pages | browser | `web/*.html` |

### API

Every `POST` takes a form-urlencoded body and must carry the `X-GLR` header, so other web sites cannot
send commands to the PS5 from your browser. Since 0.9.16 the protected actions (`/api/tarefas`, `/api/renomear`,
`/api/ativar`, `/api/atualizar`, `/api/apps/instalar`, `/api/apps/desinstalar`, `/api/discos/ejetar`, `/api/youtube`,
`/api/youtube/maxd`, `/api/energia`, `/api/sair`, `/api/cheats/*`, `/api/payloads/*`) also need `X-GLR-Token: <token>` from another device (401
`parear_necessario` otherwise); 127.0.0.1 is exempt.

| Method | Path | What it does |
|---|---|---|
| GET | `/`, `/temperatura`, `/discos`, `/internet`, `/youtube` | pages |
| GET | `/api/estado` | settings, language, IP, version, database status |
| GET | `/api/fs?caminho=` | list a folder (file manager) |
| GET | `/api/escanear` | files in the root of each chosen folder, with size |
| POST | `/api/pastas`, `/api/idioma` | save the chosen folders / the language |
| POST | `/api/renomear` | rename one file (all safety checks on the server) |
| GET | `/base_titulos.tsv` | the title database kept on the PS5 |
| POST | `/api/atualizar-base` | download the title database again |
| GET | `/api/web?url=` | fetch a page from an allowed site (publisher lookup) |
| GET | `/icone/CODE?url=` | cover image, cached on the PS5 |
| GET / POST | `/api/cache` | lookup cache |
| POST | `/api/limpar-cache` | clear cache and covers |
| GET / POST | `/api/tarefas` | copy/move/delete queue: state / add |
| POST | `/api/tarefas/cancelar`, `/api/tarefas/limpar` | cancel a task / clear finished ones |
| POST | `/api/ativar` (`pasta`, `nome`) | ACTIVATE: copy a stored-only game to the ShadowMount folder with the most free space |
| GET | `/api/espaco` | free space of a folder |
| GET | `/api/termico` (`?historico=1`) | temperatures, fan, system info, chart history |
| GET | `/fps`, `/api/fps` (`?historico=1`) | game FPS page and data (test; refused for the PS5 browser) |
| GET | `/cheats`, `/api/cheats` | cheats of the open game with the bytes read from its memory (test; refused for the PS5 browser) |
| POST | `/api/cheats/ligar`, `/api/cheats/desligar` | turn a cheat on/off in the open game (pairing + `X-GLR`; refused for the PS5 browser and 127.0.0.1) |
| POST | `/api/cheats/catalogo` | download the HEN-Cheats-Collection catalog (the `cheats/json`, `cheats/shn` and `cheats/mc4` files are kept) |
| POST | `/api/termico/limite`, `/api/termico/alerta` | fan target / alert temperature |
| GET | `/api/relogio` | PS5 clock: last check, sources, time zone |
| POST | `/api/relogio` (`auto=1|0`), `/api/relogio/conferir` | automatic clock check on/off / check (and fix) now |
| GET | `/api/discos` | mounted drives |
| GET / POST | `/api/velocidade` | drive test: state / start |
| POST | `/api/velocidade/cancelar` | cancel the drive test |
| GET | `/api/internet/servidores` | nearest test servers |
| GET / POST | `/api/internet` | internet test: state / start (`servidor=auto|cloudflare|host:port`) |
| POST | `/api/internet/cancelar` | cancel the internet test |
| POST | `/api/sair` | stop the payload |
| GET | `/api/pareamento` | pairing on/off, whether this device is paired |
| POST | `/api/parear/pedir`, `/api/parear` (`codigo`, `nome`), `/api/parear/esquecer` | show a code on the TV / pair (returns the token) / forget all devices |
| POST | `/api/discos/ejetar` (`caminho`, `forcar=1`) | eject a USB drive (busy: who uses it; nothing is closed) |
| GET | `/api/primeiro-plano` | foreground diagnostics (kern.msgbuf) |
| GET | `/api/dns?host=` | robust DNS diagnostics (allowed hosts only) |
| GET | `/payloads`, `/api/payloads` | test payloads page and status (fixed list, pinned SHA-256) |
| POST | `/api/payloads/baixar`, `/api/payloads/ativar` (`id`, `reabrir=/path`) | download / activate a listed payload (pairing + `X-GLR`; the PS5 browser only for the fullscreen item) |
| GET / POST | `/api/prefbar/conf` | PrefBar settings (`key=value` form; pairing + `X-GLR` to save; 400 for unknown key or value out of range) |
| GET | `/ps5tela.js` | the ⛶ button for the PS5 browser |
| GET | `/api/versoes` (`?resultados=1`) | games with local version, minimum firmware and `versionJsonUri` (PS5), the console firmware and the saved Sony results (0.9.37) |
| POST | `/api/versoes` | save results checked by the phone/PC app: JSON `{"resultados":[{titleId, versao_nova, fw_exigido, tamanho, consultado_em, erro}]}` (pairing + `X-GLR`) |

### Safety notes

- Anyone on your local network can open the page and read; since 0.9.16 changing things needs a paired device
  (code on the TV), unless `pairing = off`.
- Outgoing HTTPS only goes to a fixed list of sites (title database, cover sites, speed test
  servers); speed test servers are allowed only after they come from the speedtest.net list.
- The fan setting is never above the console's own value, and goes back to automatic on any conflict
  or failure.
- The speed test uses public speedtest.net servers outside the official app, which their terms of use do
  not allow. Cloudflare is offered as an alternative.

## Status and known risks

First real-PS5 test (0.1) found that the Media icon was not created and the payload did not stay running;
0.2 changes the start-up to the ProsperoMgr/websrv approach above. Things to confirm on the next run:

- folder permissions (the payload switches to the full file system root);
- `sceHttp2` under parallel connections (internet test) and its default timeouts;
- `sysctl` values (CPU per core, RAM, uptime);
- the fan device needs kernel access; the console's original fan value is misread if another tool
  changed it before glibren started;
- the Media icon creation (see the notification and `glibren.log`).

Planned: a controller shortcut to open the temperature page during a game (needs injection into the
system UI, off by default, and it would stay off if another tool that hooks the controller is running).
Notes in [docs/IDEIAS.md](docs/IDEIAS.md); development log in [docs/PROJETO.md](docs/PROJETO.md).

## Credits

- [ps5-payload-dev/sdk](https://github.com/ps5-payload-dev/sdk) — the PS5 payload SDK (GPL-3.0).
- [andshrew/PlayStation-Titles](https://github.com/andshrew/PlayStation-Titles) — title database.
- [prosperopatches.com](https://prosperopatches.com), [orbispatches.com](https://orbispatches.com) — covers
  and publishers.
- Ideas from ProsperoMgr, onionHEN and the ftpsrv/websrv payloads (studied, no code copied).
- FPS technique (`/dev/dce` flip counter): PHU Games Tools (ArkSama), onionHEN/HyperHEN (LightningMods) and
  [rawalakshay/fps-monitor-panel](https://github.com/rawalakshay/fps-monitor-panel) (GPL-3.0); facts only, our own code.
- Safe USB eject: idea from [yibinsimon/ps5-usb-manager](https://github.com/yibinsimon/ps5-usb-manager) (GPL-3.0),
  rewritten.
- Robust DNS (UDP → TCP → DoH with cache): idea from [knutwurst/ps5-patchdl](https://github.com/knutwurst/ps5-patchdl)
  `src/patchdl_dns.c` (GPL-3.0-or-later), rewritten; nothing from its update/HMAC code.
- Pairing by a code on the TV: modelled on [Phynix88/ps5-hass-payload](https://github.com/Phynix88/ps5-hass-payload)
  (GPL-3.0), our own code.
- Foreground from `kern.msgbuf`: idea from [StonedModder/ps-game-state-lib](https://github.com/StonedModder/ps-game-state-lib) (MIT).
- System-call watchdog and the chip power format: ideas seen in manos555555/PS5-Suite (GPL-3.0) and OrangeHUD; our own code.
- DoH root certificates (SSL.com Root CA ECC, GTS Root R1/R4, DigiCert Global Root G2): public CA certificates.
- Cheats (phase 0 read, phase 1 write): catalog and file format from
  [TeeKay87/HEN-Cheats-Collection](https://github.com/TeeKay87/HEN-Cheats-Collection); how the HENs find the game
  process, the module base and read its memory on firmware 8.40+ studied in
  [aydencharles/onionHEN](https://github.com/aydencharles/onionHEN) (GPL-3.0), [etaHEN](https://github.com/etaHEN/etaHEN)
  and [Pharaoh2k/ps5debug-NG](https://github.com/Pharaoh2k/ps5debug-NG); the memory read itself is the SDK's
  `kernel_proc_copyout` (mdbg read, then page-table walk through the DMAP) and the write is `kernel_proc_copyin`; the
  safety rules (originals kept, restore on off, refuse when bytes differ) follow the onionHEN idea. Ideas only, our own code.
- Cheats phase 2 (formats only, no code copied): `.shn`/`.mc4` as written by GoldHEN Cheat Manager / PS4 Cheats Manager
  and read by onionHEN (`source/util/source/cheats`, GPL-3.0), including the public `.mc4` AES key and IV; Illusion
  [PS4-PS5-Game-Patch](https://github.com/illusion0001/PS4-PS5-Game-Patch) `.xml` (`mask`, `mask_jump32`); module
  ranges from the `dl_get_list`/`dl_get_info_2` reply layout used by NineS/onionHEN; page protection from the SDK's
  `kernel_get_vmem_protection`. Our own XML reader, Base64 and AES (from FIPS-197).

- [X1NONs/PrefBar](https://github.com/X1NONs/PrefBar) (GPL-3.0): offered unchanged in Test payloads (pinned SHA-256,
  not bundled); the `prefbar.conf` keys and ranges, and the ideas for the new numbers (`sceKernelGetCpuFrequency`,
  `sceKernelGetSocClock` domain 20, `get_page_table_stats` (1,1)/(1,2), idle threads with `sceKernelGetCpuUsage`, the 1%
  low from the `/dev/dce` counter, holding the last good value) come from reading its source. Our own code.
- Test payloads: [owendswang/ps5-web-browser-fullscreen](https://github.com/owendswang/ps5-web-browser-fullscreen)
  (GPL-3.0-or-later) — the fullscreen payload itself is downloaded unchanged from its release (pinned SHA-256), not
  bundled; the "home → patch → reopen the browser" flow follows
  [owendswang/ps5-web-file-manager](https://github.com/owendswang/ps5-web-file-manager) (GPL-3.0-or-later), our own code.
  Reading the payload output through the elfldr connection: [ps5-payload-dev/elfldr](https://github.com/ps5-payload-dev/elfldr).

## License

[GPL-3.0-or-later](LICENSE). Developed by **PristMC**.
