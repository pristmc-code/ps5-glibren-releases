/* Game Library Renamer (payload PS5) - 0.9.36: o original de uma conversao vai para <disco>/BACKUP/<jogo>/.

Mesmo lugar e mesmo marcador da Jobe (JobeesLair glibren.12+, app/state/exfat-convert.js e app/native/bg_convert.c): a
pasta do jogo no BACKUP e o nome seguro do titulo (safeFolderName: tira \x00-\x1f / \ : * ? " < > |, junta espacos, tira
pontos/espacos das pontas, ate 96 caracteres; vazio = "Jogo"); pasta ja usada ganha " (2)", " (3)"... e dentro dela fica
.jobe-backup.json = {"titleId","platform","format","source":"glibren"}. Assim o original aparece na lista de BACKUP da
Jobe (Configuracoes > Downloads e a pagina do celular), que tambem o apaga quando o jogador quiser.

<disco> = a raiz do disco do original: /data, /mnt/usbN ou /mnt/extN (no PC, testes: GLR_TESTE_RAIZES = raizes
separadas por ":"). Mesmo disco = rename (instantaneo); nada e copiado. RAR em volumes: todos os volumes juntos
(x.part1.rar, x.part2.rar...; x.rar + x.r00, x.r01... x.s00...).

ShadowMount+/ShadowKraken (mesmo processo shadowmountplus.elf, API 127.0.0.1:10101): antes de mover uma imagem, pasta
ou .pkg, pergunta a lista de jogos (/api/v1/games) e de imagens (/api/v1/images). O original montado e desmontado
antes (/api/v1/games/unmount, que o SMP recusa com o jogo aberto); recusou, ou a imagem esta presa sem jogo, ou o
processo esta rodando e a API nao responde: o original fica e a tela avisa "mova depois". Depois de mover, pede a
releitura (/api/v1/scan {"reset_attempts":false}): a conversao nova monta no lugar. zip/7z/rar nao sao montados.

O BACKUP nao e varrido por eles: as raizes padrao sao <disco>/homebrew, <disco>/etaHEN/games e a raiz dos discos
externos (/mnt/usbN, /mnt/extN), com profundidade 1 por padrao e no maximo 2 (sm_limits.h DEFAULT_SCAN_DEPTH 1u,
MAX_SCAN_DEPTH 2u; sm_scan_tree.c). Da raiz do disco: BACKUP = profundidade 1 (so a pasta e olhada: nao tem eboot.bin),
BACKUP/<jogo> = 2 (so com scan_depth = 2 e olhada, e ela tambem nao tem eboot.bin: o original fica DENTRO dela),
BACKUP/<jogo>/<original> = 3 (nunca). Imagens so sao vistas como arquivo dentro de uma pasta que o SMP percorre: a
mais funda que ele percorre e BACKUP (com scan_depth 2), e la so ha pastas. /data nao e raiz de varredura. */
#pragma once

#include <stddef.h>

/* Raiz do disco do caminho. 0 = achou. */
int backup_raiz(const char *caminho, char *raiz, size_t tam);
/* 1 = o caminho esta em <raiz do disco>/BACKUP (ou e ela) */
int backup_dentro(const char *caminho);

typedef struct {
  char chave[24];     /* "" = movido; senao o motivo (a pagina traduz: bk_<chave>) */
  char detalhe[300];  /* texto do SMP, do sistema (strerror) etc. */
  char pasta[1100];   /* movido: a pasta do jogo no BACKUP */
  int adiado;         /* 1 = nao moveu por seguranca (montado, jogo aberto, SMP sem resposta): "mova depois" */
} backup_res_t;

/* Move o original (e os outros volumes do RAR) para <raiz>/BACKUP/<jogo>/. convertido = a saida da conversao, ja
   conferida (de onde sai o nome e o Title ID; senao nome_base, o nome do original sem extensao). 0 = movido. */
int backup_mover(const char *origem, const char *convertido, const char *nome_base, backup_res_t *r);
/* 0.9.48: so pergunta (nao desmonta nada): 1 = o ShadowMount+/ShadowKraken tem este caminho montado ou anexado, ou esta
   rodando e nao respondeu (motivo: "montado", "imagem_presa", "smp_sem_resposta", "smp_lista"); 0 = livre. */
int backup_em_uso(const char *caminho, char *motivo, size_t tam);
/* 0.9.48: pede ao ShadowMount+/ShadowKraken para reler as pastas (depois de mover ou excluir uma pasta de jogo) */
void backup_pedir_releitura(void);
