#!/bin/bash
# 0.9.36: o original de uma conversao vai para <disco>/BACKUP/<jogo>/ (src/backup.c), na versao de PC, com o Dump Forge
# falso (testes/dumpforge_falso.py, criando a saida) e o ShadowMount+ falso (testes/smp_falso.py). Discos de mentira por
# GLR_TESTE_RAIZES; vigia a cada 1 s (GLR_TESTE_CONV_VIGIA_S). Casos: imagem, pasta de jogo, RAR em volumes (.partN e
# .rNN), nome pelo param.json da saida (nome seguro como o da Jobe), pasta ja usada (" (2)"), marcador .jobe-backup.json,
# pagina fechada (o vigia move), falha/cancelada nao move, saida vazia nao move, montado com jogo aberto (adiado) e depois
# "Mover agora", montado sem jogo aberto (desmonta e move), imagem presa sem jogo, chave desligada (e "Mover agora"),
# disco desconhecido, duas conversoes do mesmo original, ShadowMount+ rodando sem responder (adiado) e compactado (move
# mesmo assim), releitura pedida ao SMP, rotas protegidas e a marca "backup" na lista.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_conversao_backup.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8915; PORTA_DF=8916; PORTA_SMP=8917
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R="http://$IP:$PORTA"
T=/root/glr-backup; DADOS=$T/dados; D1=$T/disco1; D2=$T/disco2; H=$D1/homebrew; F=$T/fora; B=$D1/BACKUP
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
existe() { if [ -e "$2" ]; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: nao existe $2"; fi; }
sumiu() { if [ -e "$2" ]; then falhas=$((falhas+1)); echo "FALHA $1: ainda existe $2"; else ok=$((ok+1)); echo "OK   $1"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
codigo() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
conv() { post -d "formato=$1" -d "pasta=${3:-$H}/" --data-urlencode "de=$2" $L/api/conversao; }
# item da conversao pelo fim do destino (JSON do item, com ": " entre chave e valor)
item() { curl -s $L/api/conversao | python3 -I -c '
import json, sys
d = json.load(sys.stdin)
it = [i for i in d["itens"] if i["destino"].endswith(sys.argv[1])]
print(json.dumps(it[0], ensure_ascii=False) if it else "")' "$1"; }
# espera o item chegar no estado do original (backup) ou da conversao: espera <fim do destino> <texto>
espera() { local v=""; for _ in $(seq 1 80); do v=$(item "$1"); echo "$v" | grep -q -- "$2" && break; sleep 0.25; done; echo "$v"; }
id_de() { echo "$1" | python3 -I -c 'import json,sys; print(json.load(sys.stdin)["id"])'; }
smp_estado() { python3 -I -c 'import json,sys; json.dump(json.loads(sys.argv[1]), open(sys.argv[2], "w", encoding="utf-8"), ensure_ascii=False)' "$1" "$T/smp/estado.json"; }
liga() { (exec python3 -I "$ORIGEM/testes/$1" $2 "$3") >> "$T/$1.log" 2>&1 & }

rm -rf "$T"; mkdir -p "$DADOS" "$H" "$F" "$D2" "$B/Antigo" "$T/df" "$T/smp"
printf 'language = pt-BR\nfolder = %s/\nfolder = %s/\nfolder = %s/\n' "$H" "$F" "$B/Antigo" > "$DADOS/config.ini"
for f in "Jogo Um-PPSA01234.exfat" Img-PPSA02222.ffpkg "Jogo Dois-PPSA03333.exfat" Falha-PPSA06666.exfat Cancela-PPSA06667.exfat \
         Vazio-PPSA07777.exfat "Montado Ação-PPSA04444.exfat" Montado2-PPSA04445.exfat Presa-PPSA04446.exfat \
         Desligado-PPSA08888.exfat Duplo-PPSA01111.exfat Anexada-PPSA04447.exfat SemSmp-PPSA01212.exfat Zip-PPSA01313.zip \
         Arq.part1.rar Arq.part2.rar Arq.part3.rar Arq2.part1.rar Velho.rar Velho.r00 Velho.r01; do echo dados > "$H/$f"; done
echo dados > "$F/Fora-PPSA09999.exfat"
echo dados > "$B/Antigo/velho-PPSA00001.exfat"
mkdir -p "$H/PastaJogo-PPSA05555/sce_sys" "$B/Jogo Dois-PPSA03333"
echo elf > "$H/PastaJogo-PPSA05555/eboot.bin"
echo '{"titleId":"PPSA05555","localizedParameters":{"defaultLanguage":"en-US","en-US":{"titleName":"Pasta Jogo"}}}' > "$H/PastaJogo-PPSA05555/sce_sys/param.json"
echo ok > "$T/df/modo"; echo 1 > "$T/df/cria"
smp_estado "{\"games\":[{\"path\":\"$H/Montado Ação-PPSA04444.exfat\",\"title_id\":\"PPSA04444\",\"mounted\":true},
  {\"path\":\"$H/Montado2-PPSA04445.exfat\",\"title_id\":\"PPSA04445\",\"mounted\":true},
  {\"path\":\"/mnt/usb0/homebrew/Outro-PPSA00002.exfat\",\"title_id\":\"PPSA00002\",\"mounted\":true}],
  \"images\":[{\"path\":\"$H/Presa-PPSA04446.exfat\",\"mapped\":true,\"mounted\":true}],\"ativos\":[\"PPSA04444\"]}"
liga dumpforge_falso.py $PORTA_DF "$T/df"
liga smp_falso.py $PORTA_SMP "$T/smp"; PID_SMP=$!
sleep 0.5
GLR_TESTE_SONDA_S=0 GLR_TESTE_DUMPFORGE_PORTA=$PORTA_DF GLR_TESTE_SMP_PORTA=$PORTA_SMP GLR_TESTE_RAIZES="$D1:$D2" \
  GLR_TESTE_PROCESSOS="shadowmountplus.elf" GLR_TESTE_CONV_VIGIA_S=1 "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!
sleep 1

echo "--- opcao e rotas"
confere "padrao: mover ligado"              "$(curl -s $L/api/conversao)" '"mover":true'
confere "Mover agora sem pareamento: 401"   "$(codigo -H 'X-GLR: 1' -d id=1 $R/api/conversao/backup)" "401"
confere "opcao sem pareamento: 401"         "$(codigo -H 'X-GLR: 1' -d ligado=0 $R/api/conversao/mover)" "401"
confere "opcao sem X-GLR: 403"              "$(codigo -d ligado=0 $L/api/conversao/mover)" "403"
confere "opcao invalida: 400"               "$(codigo -H 'X-GLR: 1' -d ligado=2 $L/api/conversao/mover)" "400"
confere "Mover agora id desconhecido: 404"  "$(codigo -H 'X-GLR: 1' -d id=999 $L/api/conversao/backup)" "404"
nao_tem "config.ini sem convert_backup"     "$(cat $DADOS/config.ini)" 'convert_backup'

echo "--- imagem: pagina fechada (o vigia acompanha e move)"
confere "pedido"                            "$(conv ffpkg 'Jogo Um-PPSA01234.exfat')" '"criadas":1'
for _ in $(seq 1 40); do [ -e "$B/Jogo Um-PPSA01234/Jogo Um-PPSA01234.exfat" ] && break; sleep 0.25; done
existe "original no BACKUP/<jogo>/"         "$B/Jogo Um-PPSA01234/Jogo Um-PPSA01234.exfat"
sumiu  "original saiu da pasta"             "$H/Jogo Um-PPSA01234.exfat"
existe "conversao ficou na pasta"           "$H/Jogo Um-PPSA01234.ffpkg"
confere "marcador da Jobe"                  "$(cat "$B/Jogo Um-PPSA01234/.jobe-backup.json")" '^{"titleId":"PPSA01234","platform":"ps5","format":"exfat","source":"glibren"}$'
V=$(espera "Jogo Um-PPSA01234.ffpkg" '"backup": "movido"')
confere "estado: movido"                    "$V" '"backup": "movido"'
confere "estado: pasta no BACKUP"           "$V" "\"bk_pasta\": \"$B/Jogo Um-PPSA01234\""
confere "SMP: releitura sem reset"          "$(cat $T/smp/pedidos.jsonl)" '"rota": "/api/v1/scan", "corpo": {"reset_attempts": false}'
nao_tem "SMP: nada desmontado"              "$(cat $T/smp/pedidos.jsonl)" 'unmount'

echo "--- imagem para pasta: nome do jogo de dentro da saida (nome seguro como o da Jobe)"
printf 'Título: Com "Dois" Pontos.' > "$T/df/titulo"
conv pasta Img-PPSA02222.ffpkg > /dev/null
V=$(espera "/Img-PPSA02222" '"backup": "movido"')
confere "movido"                            "$V" '"backup": "movido"'
existe "BACKUP/<titulo seguro>/"            "$B/Título Com Dois Pontos/Img-PPSA02222.ffpkg"
confere "marcador: ffpkg"                   "$(cat "$B/Título Com Dois Pontos/.jobe-backup.json")" '"titleId":"PPSA02222","platform":"ps5","format":"ffpkg"'
existe "a pasta nova ficou"                 "$H/Img-PPSA02222/eboot.bin"

echo "--- pasta de jogo"
conv exfat PastaJogo-PPSA05555 > /dev/null
V=$(espera "PastaJogo-PPSA05555.exfat" '"backup": "movido"')
confere "movido"                            "$V" '"backup": "movido"'
existe "pasta inteira dentro do BACKUP"     "$B/PastaJogo-PPSA05555/PastaJogo-PPSA05555/sce_sys/param.json"
sumiu  "pasta saiu da lista"                "$H/PastaJogo-PPSA05555"
confere "marcador: pasta sem formato"       "$(cat "$B/PastaJogo-PPSA05555/.jobe-backup.json")" '"titleId":"PPSA05555","platform":"ps5","format":""'

echo "--- RAR em volumes"
conv exfat Arq.part1.rar > /dev/null
V=$(espera "/Arq.exfat" '"backup": "movido"')
confere "part1: movido"                     "$V" '"backup": "movido"'
confere "os 3 volumes juntos"               "$(ls "$B/Arq" | tr '\n' ' ')" '^Arq.part1.rar Arq.part2.rar Arq.part3.rar $'
existe "outro RAR parecido ficou"           "$H/Arq2.part1.rar"
confere "marcador: rar sem codigo"          "$(cat "$B/Arq/.jobe-backup.json")" '"titleId":"","platform":"","format":"rar"'
conv exfat Velho.rar > /dev/null
V=$(espera "/Velho.exfat" '"backup": "movido"')
confere ".rar + .r00/.r01 juntos"           "$(ls "$B/Velho" | tr '\n' ' ')" '^Velho.r00 Velho.r01 Velho.rar $'

echo "--- nome de pasta ja usado"
conv ffpkg "Jogo Dois-PPSA03333.exfat" > /dev/null
V=$(espera "Jogo Dois-PPSA03333.ffpkg" '"backup": "movido"')
confere "pasta (2)"                         "$V" "\"bk_pasta\": \"$B/Jogo Dois-PPSA03333 (2)\""
existe "original em (2)"                    "$B/Jogo Dois-PPSA03333 (2)/Jogo Dois-PPSA03333.exfat"
confere "a pasta que ja existia ficou vazia" "$(ls -A "$B/Jogo Dois-PPSA03333" | wc -l)" '^0$'

echo "--- falha e cancelada nao movem"
echo erro > "$T/df/modo"
conv ffpkg Falha-PPSA06666.exfat > /dev/null
V=$(espera "Falha-PPSA06666.ffpkg" '"estado": "erro"')
confere "erro"                              "$V" '"estado": "erro".*"backup": ""'
existe "original ficou (erro)"              "$H/Falha-PPSA06666.exfat"
echo lento > "$T/df/modo"
conv ffpkg Cancela-PPSA06667.exfat > /dev/null
V=$(espera "Cancela-PPSA06667.ffpkg" '"estado": "rodando"')
post -d "id=$(id_de "$V")" $L/api/conversao/cancelar > /dev/null
V=$(espera "Cancela-PPSA06667.ffpkg" '"estado": "cancelado"')
confere "cancelado"                         "$V" '"estado": "cancelado".*"backup": ""'
existe "original ficou (cancelada)"         "$H/Cancela-PPSA06667.exfat"
echo ok > "$T/df/modo"

echo "--- saida vazia nao move"
echo vazio > "$T/df/cria"
conv ffpkg Vazio-PPSA07777.exfat > /dev/null
V=$(espera "Vazio-PPSA07777.ffpkg" '"backup": "falhou"')
confere "falhou: saida vazia"               "$V" '"backup": "falhou", "bk_chave": "saida_vazia"'
existe "original ficou (saida vazia)"       "$H/Vazio-PPSA07777.exfat"
post -d "id=$(id_de "$V")" $L/api/conversao/backup > /dev/null
V=$(espera "Vazio-PPSA07777.ffpkg" '"backup": "falhou"')
confere "Mover agora confere de novo"       "$V" '"bk_chave": "saida_vazia"'
existe "original continua"                  "$H/Vazio-PPSA07777.exfat"
echo 1 > "$T/df/cria"

echo "--- montado com o jogo aberto: adiado, depois Mover agora"
conv ffpkg "Montado Ação-PPSA04444.exfat" > /dev/null
V=$(espera "Montado Ação-PPSA04444.ffpkg" '"backup": "adiado"')
confere "adiado: montado"                   "$V" '"backup": "adiado", "bk_chave": "montado"'
confere "motivo do SMP"                     "$V" 'game_active'
existe "original ficou (jogo aberto)"       "$H/Montado Ação-PPSA04444.exfat"
confere "SMP: pediu para desmontar"         "$(grep -c '"rota": "/api/v1/games/unmount", "corpo": {"title_id": "PPSA04444"}' $T/smp/pedidos.jsonl)" '^1$'
smp_estado "{\"games\":[{\"path\":\"$H/Montado Ação-PPSA04444.exfat\",\"title_id\":\"PPSA04444\",\"mounted\":true},
  {\"path\":\"$H/Montado2-PPSA04445.exfat\",\"title_id\":\"PPSA04445\",\"mounted\":true},
  {\"path\":\"$H/Anexada-PPSA04447.exfat\",\"title_id\":\"PPSA04447\",\"mounted\":false}],
  \"images\":[{\"path\":\"$H/Presa-PPSA04446.exfat\",\"mapped\":true,\"mounted\":true},
  {\"path\":\"$H/Anexada-PPSA04447.exfat\",\"mapped\":true,\"mounted\":false}],\"ativos\":[]}"
confere "Mover agora: aceito"               "$(post -d "id=$(id_de "$V")" $L/api/conversao/backup)" '"ok":true'
V=$(espera "Montado Ação-PPSA04444.ffpkg" '"backup": "movido"')
confere "jogo fechado: movido"              "$V" '"backup": "movido"'
existe "original com acento no BACKUP"      "$B/Montado Ação-PPSA04444/Montado Ação-PPSA04444.exfat"
confere "SMP: desmontou na 2a vez"          "$(grep -c '"title_id": "PPSA04444"' $T/smp/pedidos.jsonl)" '^2$'

echo "--- montado sem jogo aberto: desmonta e move"
conv ffpkg Montado2-PPSA04445.exfat > /dev/null
V=$(espera "Montado2-PPSA04445.ffpkg" '"backup": "movido"')
confere "movido"                            "$V" '"backup": "movido"'
confere "SMP: desmontou"                    "$(cat $T/smp/pedidos.jsonl)" '"title_id": "PPSA04445"'

echo "--- jogo nao montado mas com a imagem anexada: desmonta e move"
conv ffpkg Anexada-PPSA04447.exfat > /dev/null
V=$(espera "Anexada-PPSA04447.ffpkg" '"backup": "movido"')
confere "movido"                            "$V" '"backup": "movido"'
confere "SMP: soltou a imagem anexada"      "$(cat $T/smp/pedidos.jsonl)" '"title_id": "PPSA04447"'

echo "--- imagem presa sem jogo"
conv ffpkg Presa-PPSA04446.exfat > /dev/null
V=$(espera "Presa-PPSA04446.ffpkg" '"backup": "adiado"')
confere "adiado: imagem presa"              "$V" '"bk_chave": "imagem_presa"'
existe "original ficou (presa)"             "$H/Presa-PPSA04446.exfat"

echo "--- chave desligada"
confere "desligar"                          "$(post -d ligado=0 $L/api/conversao/mover)" '"mover":false'
confere "config.ini: convert_backup = off"  "$(cat $DADOS/config.ini)" 'convert_backup = off'
conv ffpkg Desligado-PPSA08888.exfat > /dev/null
V=$(espera "Desligado-PPSA08888.ffpkg" '"backup": "desligado"')
confere "desligado: nao move"               "$V" '"backup": "desligado"'
existe "original ficou (desligada)"         "$H/Desligado-PPSA08888.exfat"
post -d "id=$(id_de "$V")" $L/api/conversao/backup > /dev/null
V=$(espera "Desligado-PPSA08888.ffpkg" '"backup": "movido"')
confere "Mover agora com a chave desligada" "$V" '"backup": "movido"'
confere "ligar de novo"                     "$(post -d ligado=1 $L/api/conversao/mover)" '"mover":true'
nao_tem "config.ini sem a linha"            "$(cat $DADOS/config.ini)" 'convert_backup'

echo "--- disco desconhecido"
conv ffpkg Fora-PPSA09999.exfat "$F" > /dev/null
V=$(espera "Fora-PPSA09999.ffpkg" '"backup": "falhou"')
confere "falhou: disco desconhecido"        "$V" '"bk_chave": "disco_desconhecido"'
existe "original ficou (fora)"              "$F/Fora-PPSA09999.exfat"

echo "--- duas conversoes do mesmo original"
conv ffpkg Duplo-PPSA01111.exfat > /dev/null
conv ffpfs Duplo-PPSA01111.exfat > /dev/null
V1=$(espera "Duplo-PPSA01111.ffpkg" '"backup": "movido"'); V2=$(espera "Duplo-PPSA01111.ffpfs" '"backup": "movido"')
confere "1a: movido"                        "$V1" "\"bk_pasta\": \"$B/Duplo-PPSA01111\""
confere "2a: o mesmo BACKUP"                "$V2" "\"bk_pasta\": \"$B/Duplo-PPSA01111\""
existe "as duas conversoes ficaram"         "$H/Duplo-PPSA01111.ffpfs"

echo "--- lista: pasta dentro do BACKUP marcada"
E=$(curl -s $L/api/escanear)
confere "item do BACKUP marcado"            "$E" '"nome":"velho-PPSA00001.exfat","backup":true'
nao_tem "homebrew sem a marca"              "$(echo "$E" | grep -o '"nome":"Jogo Um-PPSA01234.ffpkg"[^}]*')" 'backup'

echo "--- ShadowMount+ rodando sem responder"
kill $PID_SMP 2>/dev/null; wait $PID_SMP 2>/dev/null
conv ffpkg SemSmp-PPSA01212.exfat > /dev/null
V=$(espera "SemSmp-PPSA01212.ffpkg" '"backup": "adiado"')
confere "adiado: SMP sem resposta"          "$V" '"bk_chave": "smp_sem_resposta"'
existe "original ficou (SMP mudo)"          "$H/SemSmp-PPSA01212.exfat"
conv exfat Zip-PPSA01313.zip > /dev/null
V=$(espera "Zip-PPSA01313.exfat" '"backup": "movido"')
confere "compactado move mesmo assim"       "$V" '"backup": "movido"'
confere "marcador: zip"                     "$(cat "$B/Zip-PPSA01313/.jobe-backup.json")" '"titleId":"PPSA01313","platform":"ps5","format":"zip"'
confere "diario: backup"                    "$(cat $DADOS/glibren.log)" 'backup: .*Jogo Um-PPSA01234.exfat -> '

echo "--- 0.9.48: tamanho do original e do convertido"
# o Dump Forge falso grava "convertido" (10 bytes) na saida; os originais do teste tem 6 bytes ("dados" + fim de linha)
V=$(item "Jogo Um-PPSA01234.ffpkg")
confere "tamanhos: original (movido) continua" "$V" '"tam_origem": 6'
confere "tamanhos: convertido pelo disco"   "$V" '"tam_destino": 10'
confere "diario: feita com os tamanhos"     "$(cat $DADOS/glibren.log)" 'conversao: [0-9]* feita: .*Jogo Um-PPSA01234.ffpkg (original 6 bytes -> convertido 10 bytes, 67% maior)'
V=$(item "Zip-PPSA01313.exfat")
confere "tamanhos: compactado"              "$V" '"tam_origem": 6, "tam_destino": 10'
# pasta de jogo como origem: o medidor soma os arquivos (eboot.bin + sce_sys/param.json)
mkdir -p "$H/Soma-PPSA05656/sce_sys"; printf '1234567' > "$H/Soma-PPSA05656/eboot.bin"
printf '{"titleId":"PPSA05656"}' > "$H/Soma-PPSA05656/sce_sys/param.json"
conv exfat Soma-PPSA05656 > /dev/null
V=$(espera "Soma-PPSA05656.exfat" '"tam_origem": 30')
confere "tamanhos: pasta = soma dos arquivos" "$V" '"tam_origem": 30'
V=$(espera "Soma-PPSA05656.exfat" '"tam_destino": 10')
confere "tamanhos: pasta -> imagem"         "$V" '"tam_destino": 10'
for _ in $(seq 1 20); do grep -q 'original 30 bytes -> convertido 10 bytes' $DADOS/glibren.log && break; sleep 0.25; done
confere "diario: 67% menor"                 "$(cat $DADOS/glibren.log)" 'original 30 bytes -> convertido 10 bytes, 67% menor'

echo "--- 0.9.48: a lista sobrevive ao glibren reiniciar (atualizacao no meio de uma conversao)"
echo lento > "$T/df/modo"
echo dados > "$H/Longa-PPSA01515.exfat"
confere "longa: pedida"                     "$(conv ffpkg Longa-PPSA01515.exfat)" '"criadas":1'
V=$(espera "Longa-PPSA01515.ffpkg" '"estado": "rodando"')
ID_LONGA=$(id_de "$V")
existe "lista gravada"                      "$DADOS/conversoes.json"
QTD=$(curl -s $L/api/conversao | python3 -I -c 'import json,sys; print(len(json.load(sys.stdin)["itens"]))')
kill $PID 2>/dev/null; wait $PID 2>/dev/null
GLR_TESTE_SONDA_S=0 GLR_TESTE_DUMPFORGE_PORTA=$PORTA_DF GLR_TESTE_SMP_PORTA=$PORTA_SMP GLR_TESTE_RAIZES="$D1:$D2" \
  GLR_TESTE_PROCESSOS="shadowmountplus.elf" GLR_TESTE_CONV_VIGIA_S=1 "$BIN" -p $PORTA -d "$DADOS" >> "$T/glr.log" 2>&1 & PID=$!
sleep 1.5
confere "reinicio: mesma quantidade"        "$(curl -s $L/api/conversao | python3 -I -c 'import json,sys; print(len(json.load(sys.stdin)["itens"]))')" "^$QTD\$"
V=$(espera "Longa-PPSA01515.ffpkg" '"estado": "rodando"')
confere "reinicio: a longa segue rodando"   "$V" '"estado": "rodando"'
confere "reinicio: mesmo id"                "$(id_de "$V")" "^$ID_LONGA\$"
confere "reinicio: tamanho do original"     "$V" '"tam_origem": 6'
V=$(item "Jogo Um-PPSA01234.ffpkg")
confere "reinicio: pronta com os tamanhos"  "$V" '"tam_origem": 6, "tam_destino": 10'
confere "reinicio: original movido"         "$V" '"backup": "movido"'
confere "diario: lista gravada lida"        "$(cat $DADOS/glibren.log)" 'tarefa(s) da lista gravada (1 em andamento)'
confere "cancelar depois do reinicio"       "$(post -d id=$ID_LONGA $L/api/conversao/cancelar)" '"ok":true'
V=$(espera "Longa-PPSA01515.ffpkg" '"estado": "cancelado"')
confere "longa: cancelada"                  "$V" '"estado": "cancelado"'
existe "longa: original fica"               "$H/Longa-PPSA01515.exfat"

echo "--- 0.9.48: conversao que ja estava no Dump Forge e adotada (lista perdida ou glibren antigo)"
echo dados > "$H/Adota-PPSA01414.exfat"; echo dados > "$F/ForaAdota-PPSA01416.exfat"
curl -s -H 'Content-Type: application/json' -d "{\"request\":{\"source\":\"$H/Adota-PPSA01414.exfat\",\"output\":\"$H/Adota-PPSA01414.pkg\",\"format\":\"pkg\",\"delete_source\":false}}" http://127.0.0.1:$PORTA_DF/api/start_job > /dev/null
curl -s -H 'Content-Type: application/json' -d "{\"request\":{\"source\":\"/tmp/x.exfat\",\"output\":\"/tmp/x.pkg\",\"format\":\"pkg\",\"delete_source\":false}}" http://127.0.0.1:$PORTA_DF/api/start_job > /dev/null
kill $PID 2>/dev/null; wait $PID 2>/dev/null
rm -f "$DADOS/conversoes.json"
GLR_TESTE_CONV_ADOTAR=1 GLR_TESTE_SONDA_S=0 GLR_TESTE_DUMPFORGE_PORTA=$PORTA_DF GLR_TESTE_SMP_PORTA=$PORTA_SMP GLR_TESTE_RAIZES="$D1:$D2" \
  GLR_TESTE_PROCESSOS="shadowmountplus.elf" GLR_TESTE_CONV_VIGIA_S=1 "$BIN" -p $PORTA -d "$DADOS" >> "$T/glr.log" 2>&1 & PID=$!
sleep 1.5
V=$(espera "Adota-PPSA01414.pkg" '"estado": "rodando"')
confere "adotada: aparece rodando"          "$V" '"estado": "rodando"'
confere "adotada: formato pelo pedido"      "$V" '"formato": "pkg"'
confere "adotada: tamanho do original"      "$V" '"tam_origem": 6'
confere "adotada: so ela (fora das pastas nao)" "$(curl -s $L/api/conversao | python3 -I -c 'import json,sys; print(len(json.load(sys.stdin)["itens"]))')" '^1$'
confere "diario: adotada"                   "$(cat $DADOS/glibren.log)" 'adotada (pedida antes de o glibren reiniciar): .*Adota-PPSA01414.exfat -> .*Adota-PPSA01414.pkg (pkg)'
confere "adotada: cancelar"                 "$(post -d id=$(id_de "$V") $L/api/conversao/cancelar)" '"ok":true'
echo ok > "$T/df/modo"
# adotada que termina: o original NAO vai sozinho para o BACKUP (pode ter sido pedida por outro programa); "Mover agora" vale
echo dados > "$H/Adota2-PPSA01417.exfat"
curl -s -H 'Content-Type: application/json' -d "{\"request\":{\"source\":\"$H/Adota2-PPSA01417.exfat\",\"output\":\"$H/Adota2-PPSA01417.ffpkg\",\"format\":\"ffpkg\",\"delete_source\":false}}" http://127.0.0.1:$PORTA_DF/api/start_job > /dev/null
kill $PID 2>/dev/null; wait $PID 2>/dev/null
rm -f "$DADOS/conversoes.json"
GLR_TESTE_CONV_ADOTAR=1 GLR_TESTE_SONDA_S=0 GLR_TESTE_DUMPFORGE_PORTA=$PORTA_DF GLR_TESTE_SMP_PORTA=$PORTA_SMP GLR_TESTE_RAIZES="$D1:$D2"   GLR_TESTE_PROCESSOS="shadowmountplus.elf" GLR_TESTE_CONV_VIGIA_S=1 "$BIN" -p $PORTA -d "$DADOS" >> "$T/glr.log" 2>&1 & PID=$!
sleep 1.5
V=$(espera "Adota2-PPSA01417.ffpkg" '"backup": "desligado"')
confere "adotada pronta: original fica"     "$V" '"estado": "feito".*"backup": "desligado"'
confere "adotada pronta: tamanhos"          "$V" '"tam_origem": 6, "tam_destino": 10'
existe "adotada pronta: original no lugar"  "$H/Adota2-PPSA01417.exfat"
confere "adotada: Mover agora"              "$(post -d id=$(id_de "$V") $L/api/conversao/backup)" '"ok":true'
# (o ShadowMount+ falso ja foi parado mais acima neste teste: "adiado" por ele nao responder tambem prova que o pedido andou)
V=$(espera "Adota2-PPSA01417.ffpkg" '"backup": "\(movido\|adiado\)"')
confere "adotada: Mover agora andou"        "$V" '"backup": "\(movido\|adiado\)"'

kill $PID 2>/dev/null; wait $PID 2>/dev/null
pkill -f "dumpforge_falso.py $PORTA_DF" 2>/dev/null
echo "=== $ok ok, $falhas falhas"
[ $falhas -eq 0 ]
