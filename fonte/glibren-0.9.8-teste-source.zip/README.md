# glibren — Game Library Renamer payload for PS5

A PS5 payload (`.elf`) that runs a small web app **on the console itself**. It renames your game files
to clean, readable names from their Title ID, and adds a file manager, batch copy / move / delete, a
temperature and fan monitor, a drive speed test and an internet speed test.

It is the console-side version of [Game Library Renamer](https://github.com/pristmc-code/ps5-game-library-renamer)
(the Windows app that does the same over FTP/SFTP). Here there is no FTP: the payload reads and renames the
files directly on the PS5.

```
PPSA08329-app.pkg          →  God_of_War_Ragnarok-PPSA08329-US-PS5.pkg
CUSA07408 God of War.pkg   →  God_of_War-CUSA07408-US-PS4.pkg
```

**Download (public, signed, with source):** [pristmc-code/ps5-glibren-releases](https://github.com/pristmc-code/ps5-glibren-releases) — send `glibren.elf` once; after that the payload updates itself from there.

> **Status: 0.1-test, private.** Everything below works in the PC test build (Linux/WSL, same C code).
> **It has not been run on a real PS5 yet.** See [Status and known risks](#status-and-known-risks).

![Games page (PC)](docs/jogos-pc.png)

| Temperature | Drives | Internet | Games |
|---|---|---|---|
| ![](docs/temperatura-celular.png) | ![](docs/discos-celular.png) | ![](docs/internet-celular.png) | ![](docs/jogos-celular.png) |

## How you use it

- **On the PS5:** an icon in the **Media** tab opens the app in the PS5 web browser, on top of whatever
  is running. You can keep a store app downloading games and open glibren next to it to rename what has
  finished. The layout is larger for TV.
- **On a PC or phone:** open `http://PS5-IP:8765` in any browser on the same network. There is a desktop
  layout and a compact phone layout. The PS5 notification shows the address when the payload starts.
- The page is in **English, Português (BR) and Español**.
- On a phone every page fits the screen without scrolling, upright or sideways, with or without full screen.
  In full screen, switching between Games, Temperature, Drives and Internet keeps the full screen.

## Features

### Rename games
- **File manager** to browse the PS5 folders and choose which ones go into the list (internal SSD, M.2,
  extended storage, USB drives). Only the root of each chosen folder is read, and only when you open the
  page or click **Read folders**.
- Finds the Title ID (`PPSA`, `CUSA`, …) in each file name and shows the game name, cover, platform,
  region, publisher, Content ID and **file size**.
- Proposes the new name `Game_Name-TITLEID-REGION-PS4|PS5` (no accents or special characters, spaces
  become `_`, the extension is kept - also a double one like `.exfat.complete`) with **Rename** per game and
  **Rename all**.
- Games that still need renaming are listed first; everything already named correctly goes below, in
  alphabetical order.
- Safe renaming: never overwrites, checks that the source still exists and its size has not changed,
  detects two files that would get the same name, and keeps the ShadowMountPlus path length limit.
- Never renames:
  - folders and compressed files (`.zip`, `.rar`, `.7z`, …);
  - patches and backports (`patch`, `backport`, `update` in the name);
  - files that are still downloading (`.part`, `.crdownload`, `.tmp`, …).
- Game names come from a local database of ~71,000 titles
  ([andshrew/PlayStation-Titles](https://github.com/andshrew/PlayStation-Titles)), downloaded by the PS5
  and refreshed once a day. Covers and publishers come from [prosperopatches.com](https://prosperopatches.com)
  (PS5) and [orbispatches.com](https://orbispatches.com) (PS4), cached on the PS5. Nothing is fetched from the
  Sony store.
- YouTube button per game (hidden in the PS5 browser, where it would open the YouTube app).

### Copy, move and delete in batch
- Checkboxes per game plus **Copy**, **Move** and **Delete** at the top.
- The destination can only be one of the listed folders. Files that already exist in the destination are
  skipped, never overwritten.
- Renaming while copying/moving is an option, off by default.
- Delete asks for confirmation in a warning that stays on screen at least 3 seconds before the button
  is enabled.
- Progress panel with every queued file, speed and remaining time. Copies are written as `.part` and only
  renamed when complete; free space is checked first; a move on the same drive is an instant rename.
- The folders are read again when the queue finishes.

### Temperature and fan
- CPU, SoC and M.2 SSD temperatures, fan speed (%), session maximums and an 8-minute chart.
- **BASIC / ADVANCED** view; advanced adds CPU use per core, RAM, IP and uptime.
- Optional notification on the PS5 screen when a temperature limit is passed (at most every 5 minutes).
- **Fan control:** choose the temperature at which the fan speeds up (50–85 °C, never above the console's
  own value). The payload checks every 2 seconds and applies it again, because the PS5 resets it when a
  game starts. If another program (for example ProsperoMgr) changes the value, glibren backs off and
  returns to automatic; after 5 failures in a row it also returns to automatic.
- Keeps running while you play, so you can watch it on the phone.

### PS5 clock from the internet
- Without PSN the PS5 never sets its clock, and a wrong clock breaks HTTPS (the YouTube apps find no videos).
  glibren checks the time when it starts, every 6 hours and after rest mode, against NTP servers
  (Cloudflare, NTP.br, Google, by IP, no DNS needed) and the `Date` header of an HTTPS site.
- It only changes the clock when most sources (at least two) agree within 3 seconds and the clock is more
  than 30 seconds off. It sets the UTC time; the time zone stays the one chosen on the PS5.
- **Clock** card on the Temperature page: automatic on/off, a **Check** button, the last result and the PS5
  time zone. Every check and fix goes to the log.

### Drive speed test
- Write and read speed of the internal SSD, extended storage and every USB drive, with 1, 2, 4 or 8 GB
  test files.
- The test file is deleted at the end, and leftovers from an interrupted test are removed when the
  payload starts.

### Internet speed test
- Ping (with jitter), download and upload, measured **by the PS5 itself**.
- **Server** box like speedtest.net: *Automatic (closest)*, the 10 nearest speedtest.net servers
  (the list is requested by the PS5, so it follows wherever the console is) or Cloudflare.
- Automatic mode pings the 5 closest servers, uses the fastest one that answers, and falls back to
  Cloudflare if the download fails.
- History of previous tests with the server used.

## Install

Requirements: a jailbroken PS5 with an ELF loader (port **9021**). Nothing else is needed.

1. Send `glibren.elf` to the ELF loader (for example `nc -q0 PS5-IP 9021 < glibren.elf`), or add it to your
   autoloader so it starts with the console.
2. A notification shows the address (`http://PS5-IP:8765`). On the first run the payload also creates the
   **Game Library Renamer** icon in the Media tab (`/user/app/PMGL00001`), which opens `http://127.0.0.1:8765`.
   Like ProsperoMgr's tile, the icon only works while the payload is running.

Updates: the **Update** button downloads the signed new version to `/data/GameLibraryRenamer/glibren.elf` and
starts it. Your autoloader keeps sending the file it has, so from 0.8.2 on every start checks that saved file:
when it is newer and its signature is valid, the payload hands over to it. (Coming from 0.8.1 or older, replace
the `.elf` in your autoloader once.)

Apps window: installs, updates and **uninstalls** the homebrew apps of the signed catalog (ytps5, YouTube
Max'd) in `/data/homebrew/<TITLE_ID>`. Files get mode 0777, as with FTP (with 0644 the PS5 answers "Can't start
the game or app", CE-107750-0). Uninstall asks ShadowMountPlus to remove the title (its API on port 10101) and
deletes the folder.

**YouTube** box in the Apps window (PS5, PC and phone): opens YouTube Max'd on the PS5 with the typed search (or
empty, on the search screen). The payload writes `/data/homebrew/PPSA99991/glibren_busca.txt` (UTF-8, `.tmp` +
rename) with two lines: the search (may be empty) and `voltar=PMGL00001` (glibren's own Media icon), so that Max'd
reopens glibren when you leave it. The per-game YouTube button also adds that second line when it opens Max'd
(ytps5 keeps a one-line file).

**USB SSD temperature (0.9.8, test).** The Temperature page has a "SSD in USB enclosure (test)" card with a Read
button. It asks an NVMe SSD in a Realtek RTL9210 enclosure for its SMART temperature (read-only SCSI pass-through,
vendor command 0xE4, the same method smartmontools uses) and also lists the PS5's SoC sensor channels 0..7. The
details are shown on the page and written to the log (`ssd usb:` lines).

**Game search (0.9.7).** A "Search game (name or code)" box at the top of the sort/filter bar narrows the list as
you type: it looks in the file name, the corrected name, the PPSA/CUSA code and the database name; every word must
match, ignoring accents and case ("_", "-" and "." count as spaces). It works together with the other filters.

**YouTube in Jobe (0.9.6).** When Jobe (`PPSA99471`) is installed and announces it can play YouTube
(`/data/JobeesLair/tube/jobe-tube.txt`, written by Jobe itself), both YouTube buttons (the Apps box and the
per-game one) open Jobe instead: the payload writes `/data/JobeesLair/tube/abrir.txt` (UTF-8, `.tmp` + rename,
folder created if missing) with the search (up to 200 bytes, may be empty in the Apps box) and `voltar=PMGL00001`,
no trailing newline, and launches Jobe with the same rules; Jobe goes back to glibren by itself when you leave.
Without that, the old behavior (ytps5 / Max'd). The line under the search box says where it opens ("Opens in
Jobe" / "Opens in YouTube Max'd"); `/api/apps` reports it as `youtube_destino` (`jobe`, `maxd` or empty).

**Never on top of another app.** Launching a title while another app is open fails (0x80940011 / 0x80940031) and is
suspected of crashing the console. So when a game/app is open (any title in `/user/appmeta` or `/data/homebrew`
for which `sceLncUtilGetAppId` answers >= 0, except glibren's own `PMGL00001`, which is just its page in the
system browser), both YouTube buttons write nothing, launch nothing and answer the key `app_aberto` with the open
title in `params.nome`; the page says "Close the open app (Jobe) and try again".

Local launch endpoint, for other apps on the PS5 (for example Max'd going back to glibren when it closes):

```
POST http://127.0.0.1:8765/launch
Content-Type: application/json
{"title":"PMGL00001","from":"PPSA99991"}
```

- with `from` (the title open now): answers `200 {"ok":true,"pending":true,"title":"...","from":"..."}` at once;
  a thread waits for `from` to close (up to 2 min, then gives up), waits ~15 s and launches with up to 4 attempts
  (pauses 5/10/20 s, skipping an attempt while another app is open), each result in `glibren.log`. A new request
  replaces the pending one. `GET /api/launch` shows its state (`esperando`, `aguardando`, `lancando`, `aberto`,
  `desistiu`, `falhou`). Same contract as `POST /switch` of Jobe's background payload (127.0.0.1:34200);
- without `from`: launches only when no game/app is open, otherwise `409 {"ok":false,"error":"app_aberto",
  "open":"<title>"}`;

- only from the PS5 itself: the connection must come from `127.0.0.0/8` and `Host` must be `127.0.0.1` or
  `localhost` (with or without port); anything else gets `403`;
- `Content-Type: application/json` is required (`415` otherwise) - a web page can't send it without a CORS
  preflight, which glibren never allows;
- `title` must be one of `PPSA99471` (Jobe), `PPSA99991` (YouTube Max'd), `PPSA99350` (ytps5), `PMGL00001`
  (glibren); other titles get `403`, a malformed body (or `from` not like `PPSA00000`) `400`;
- the title is opened with `sceSystemServiceLaunchApp`, nothing is closed. Immediate answer `200
  {"ok":true,"title":"..."}`, or `502 {"ok":false,"chave":"launch","erro":"... (0x8...)"}` when the PS5 refuses.
3. Open the icon on the PS5, or the address on a PC or phone.

How it stays running (same approach as ProsperoMgr and websrv): the payload raises its own process
credentials, names its process `glibren.elf`, kills older copies with that name, ignores `SIGPIPE`
(a browser closing a connection can't kill it), uses 1 MB thread stacks, and reopens its port after rest mode
(`SIGCONT`). If it ever crashes, a PS5 notification says so and the reason is written to
`/data/GameLibraryRenamer/glibren.log`.

The log can also be read in a browser at `http://PS5-IP:8765/diario`.

Data is kept in `/data/GameLibraryRenamer/` (settings, title database, lookup cache, covers, fan setting, log).

## Build

The SDK only builds on Linux/macOS. On Windows, use WSL.

1. Install [ps5-payload-sdk](https://github.com/ps5-payload-dev/sdk) (v0.45 was used) in
   `/opt/ps5-payload-sdk`, plus `clang-18`, `lld-18`, `make`, `xxd`, `gzip`, `curl` and `rsync`.
2. Build:
   ```sh
   make                 # glibren.elf (payload; it creates its Media icon when it runs)
   make pc              # glibren-pc: Linux build of the same code, for testing without a PS5
   make test PS5_HOST=192.168.x.x   # sends glibren.elf to the PS5 ELF loader
   ```
   `compilar.sh` does the same from Windows: it copies the sources to the WSL file system, builds there and
   copies the results back to `saida/`:
   ```sh
   wsl -d Ubuntu-24.04 -u root -- bash compilar.sh all pc
   ```

The pages in `web/` are embedded in the ELF at build time (plain and gzip versions, via `xxd`).

### Testing without a PS5

`glibren-pc` runs the same server on Linux. HTTPS uses `curl` instead of the PS5 libraries, and the "PS5
folders" are ordinary folders.

- `testes/demo.sh` starts a demo on `http://localhost:8765` with fake folders and games (`demo.sh parar` stops it).
- `testes/teste_api.sh` is an API test suite.
- `testes/teste_tarefas.sh` tests the copy/move/delete queue.
- `testes/comparar_nomes.py base_titulos.tsv` checks that the JavaScript naming rule gives the same result as
  the Windows app for every title in the database.
- `GLR_DEMO_MBPS=120` (PC build only) slows copies and the drive test down, to see the progress screens.

## How it works

The C side is thin: it serves the pages and a JSON API and does only what a browser cannot do (files,
console sensors, HTTPS without CORS). The naming rules run in JavaScript in the page, ported from the
Windows app.

| Part | Where | File |
|---|---|---|
| HTTP server (thread per connection, port 8765) | payload | `src/http.c` |
| Routes / API | payload | `src/api.c` |
| File manager, folder reading, safe rename | payload | `src/arquivos.c` |
| Copy / move / delete queue | payload | `src/tarefas.c` |
| Temperatures, fan, alerts | payload | `src/termico.c` |
| CPU per core, RAM, uptime, IP | payload | `src/sistema.c` |
| Drive list and speed test | payload | `src/discos.c` |
| Internet speed test and server list | payload | `src/internet.c` |
| HTTPS client (sceHttp2 on PS5, curl on PC), host allow-list | payload | `src/https.c` |
| Settings | payload | `src/config.c` |
| Permissions, process name, old copies, log, crash notice, Media icon | payload | `src/plataforma.c` |
| Media icon image | payload | `instalador/icon0.png` |
| Pages | browser | `web/*.html` |

### API

Every `POST` takes a form-urlencoded body and must carry the `X-GLR` header, so other web sites cannot
send commands to the PS5 from your browser.

| Method | Path | What it does |
|---|---|---|
| GET | `/`, `/temperatura`, `/discos`, `/internet`, `/youtube` | pages |
| GET | `/api/estado` | settings, language, IP, version, database status |
| GET | `/api/fs?caminho=` | list a folder (file manager) |
| GET | `/api/escanear` | files in the root of each chosen folder, with size |
| POST | `/api/pastas`, `/api/idioma` | save the chosen folders / the language |
| POST | `/api/renomear` | rename one file (all safety checks on the server) |
| GET | `/base_titulos.tsv` | the title database kept on the PS5 |
| POST | `/api/atualizar-base` | download the title database again |
| GET | `/api/web?url=` | fetch a page from an allowed site (publisher lookup) |
| GET | `/icone/CODE?url=` | cover image, cached on the PS5 |
| GET / POST | `/api/cache` | lookup cache |
| POST | `/api/limpar-cache` | clear cache and covers |
| GET / POST | `/api/tarefas` | copy/move/delete queue: state / add |
| POST | `/api/tarefas/cancelar`, `/api/tarefas/limpar` | cancel a task / clear finished ones |
| POST | `/api/ativar` (`pasta`, `nome`) | ACTIVATE: copy a stored-only game to the ShadowMount folder with the most free space |
| GET | `/api/espaco` | free space of a folder |
| GET | `/api/termico` (`?historico=1`) | temperatures, fan, system info, chart history |
| POST | `/api/termico/limite`, `/api/termico/alerta` | fan target / alert temperature |
| GET | `/api/relogio` | PS5 clock: last check, sources, time zone |
| POST | `/api/relogio` (`auto=1|0`), `/api/relogio/conferir` | automatic clock check on/off / check (and fix) now |
| GET | `/api/discos` | mounted drives |
| GET / POST | `/api/velocidade` | drive test: state / start |
| POST | `/api/velocidade/cancelar` | cancel the drive test |
| GET | `/api/internet/servidores` | nearest test servers |
| GET / POST | `/api/internet` | internet test: state / start (`servidor=auto|cloudflare|host:port`) |
| POST | `/api/internet/cancelar` | cancel the internet test |
| POST | `/api/sair` | stop the payload |

### Safety notes

- Anyone on your local network can open the page, the same as an FTP server without a password.
- Outgoing HTTPS only goes to a fixed list of sites (title database, cover sites, speed test
  servers); speed test servers are allowed only after they come from the speedtest.net list.
- The fan setting is never above the console's own value, and goes back to automatic on any conflict
  or failure.
- The speed test uses public speedtest.net servers outside the official app, which their terms of use do
  not allow. Cloudflare is offered as an alternative.

## Status and known risks

First real-PS5 test (0.1) found that the Media icon was not created and the payload did not stay running;
0.2 changes the start-up to the ProsperoMgr/websrv approach above. Things to confirm on the next run:

- folder permissions (the payload switches to the full file system root);
- `sceHttp2` under parallel connections (internet test) and its default timeouts;
- `sysctl` values (CPU per core, RAM, uptime);
- the fan device needs kernel access; the console's original fan value is misread if another tool
  changed it before glibren started;
- the Media icon creation (see the notification and `glibren.log`).

Planned: a controller shortcut to open the temperature page during a game (needs injection into the
system UI, off by default, and it would stay off if another tool that hooks the controller is running).
Notes in [docs/IDEIAS.md](docs/IDEIAS.md); development log in [docs/PROJETO.md](docs/PROJETO.md).

## Credits

- [ps5-payload-dev/sdk](https://github.com/ps5-payload-dev/sdk) — the PS5 payload SDK (GPL-3.0).
- [andshrew/PlayStation-Titles](https://github.com/andshrew/PlayStation-Titles) — title database.
- [prosperopatches.com](https://prosperopatches.com), [orbispatches.com](https://orbispatches.com) — covers
  and publishers.
- Ideas from ProsperoMgr, onionHEN and the ftpsrv/websrv payloads (studied, no code copied).

## License

[GPL-3.0-or-later](LICENSE). Developed by **PristMC**.
