/* Game Library Renamer (payload PS5) - payloads de terceiros para teste (0.9.20).

Catalogo FIXO no codigo (payloads.c), so com payloads conferidos por nos: cada item tem a URL do asset da release no
GitHub, o tamanho e o SHA-256 fixados (baixados e calculados por quem publicou o glibren). Ativar = baixar pelo cliente
HTTPS do glibren (DNS robusto), recusar se o SHA-256 nao bater, guardar em /data/glibren/payloads/ e enviar ao elfldr
(127.0.0.1:9021), lendo a saida do payload pelo mesmo socket (o elfldr liga o stdout do payload a conexao). */
#pragma once

#include "http.h"

/* GET /api/payloads: {"ok","firmware","ocupado","itens":[...]} (leitura livre) */
void payloads_rota_estado(pedido_t *p);
/* POST /api/payloads/baixar e /api/payloads/ativar (id, reabrir): pareamento + X-GLR ja conferidos pelo api.c.
   Recusa o navegador do PS5 e outros programas do proprio PS5, menos o item de tela cheia aberto pelo navegador do PS5. */
void payloads_rota_acao(pedido_t *p, int ativar);
/* 1 = baixando ou ativando agora (a atualizacao do glibren espera). */
int payloads_ocupado(void);
