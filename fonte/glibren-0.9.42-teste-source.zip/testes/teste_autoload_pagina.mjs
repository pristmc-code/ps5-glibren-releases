// 0.9.41: pagina Payloads - chave "Carregar ao iniciar o glibren" (so nos itens que podem e estao instalados), avisos
// (kraken-mount .exfat, montadores exclusivos, regras do kstuff), cartao do kstuff ("Esta carregado?", aviso fixo,
// arquivo seu, instalado como) e "Instalar de arquivo" (lista com sugeridos e "mais nova"), em 360 e 1280: sem rolar de
// lado, botoes da mesma linha com a mesma largura, nada cortado. Chamado pelo testes/teste_autoload.sh.
//   node teste_autoload_pagina.mjs http://127.0.0.1:8971 <pasta do pacote playwright>
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const [base, pw] = process.argv.slice(2);
const { chromium } = await import(pathToFileURL(path.join(pw, 'index.mjs')).href);
let ok = 0, falhas = 0;
const confere = (nome, cond, info = '') => { if (cond) { ok++; console.log('OK   ' + nome); } else { falhas++; console.log('FALHA ' + nome + (info ? ': ' + info : '')); } };

let navegador;
for (const channel of ['msedge', 'chrome']) { try { navegador = await chromium.launch({ channel }); break; } catch { /* outro */ } }
if (!navegador) { console.log('FALHA nenhum navegador abriu'); console.log('=== pagina 0 ok, 1 falhas'); process.exit(1); }

const medir = pagina => pagina.evaluate(() => {
  const larguras = [...document.querySelectorAll('.botoes')].filter(b => b.offsetParent).map(b =>
    [...b.querySelectorAll('button')].filter(x => x.offsetParent).map(x => Math.round(x.getBoundingClientRect().width)));
  const cortados = [...document.querySelectorAll('button, .linha, .agora, .avisos, h2, .arq-item small, .arq-nome, summary')].filter(e => e.offsetParent &&
    (getComputedStyle(e).textOverflow === 'ellipsis' || e.scrollWidth > e.clientWidth + 1)).map(e => e.className + ':' + e.textContent.slice(0, 40));
  return { larguras, cortados, rola: document.scrollingElement.scrollWidth > innerWidth };
});

for (const tela of [{ w: 360, h: 780, nome: 'celular' }, { w: 1280, h: 800, nome: 'PC' }]) {
  const pagina = await navegador.newPage({ viewport: { width: tela.w, height: tela.h } });
  const n = s => `${s} (${tela.nome})`;
  await pagina.goto(base + '/payloads');
  await pagina.waitForFunction(() => document.querySelector('.item[data-id="kstuff"] .arq-seu')?.textContent, null, { timeout: 20000 }).catch(() => null);
  const card = id => `.item[data-id="${id}"]`;
  const vis = sel => pagina.isVisible(sel).catch(() => false);
  const txt = sel => pagina.$eval(sel, e => e.textContent).catch(() => '');
  confere(n('Dump Forge (instalado): chave visivel'), await vis(card('dump-forge') + ' .autoload .chk-autoload'));
  confere(n('chave: texto'), (await txt(card('dump-forge') + ' .autoload .chave')).includes('Carregar ao iniciar o glibren'));
  for (const id of ['prefbar', 'zhithemes', 'web-browser-fullscreen'])
    confere(n(`${id}: sem chave`), !(await pagina.$(card(id) + ' .autoload')));
  confere(n('kraken-mount: aviso .exfat'), (await txt(card('kraken-mount') + ' .autoload')).includes('não monta imagens .exfat') &&
    (await txt(card('kraken-mount') + ' .autoload')).includes('JobeesLair.exfat'));
  confere(n('kraken-mount: so um montador'), (await txt(card('kraken-mount') + ' .autoload')).includes('Só um montador'));
  confere(n('ShadowKraken: chave (instalado de arquivo)'), await vis(card('shadowkraken') + ' .autoload .chk-autoload'));
  const ks = await txt(card('kstuff'));
  confere(n('kstuff: aviso fixo'), ks.includes('kstuff mexe no kernel; use só um arquivo em que você confia; o glibren não verifica a origem'));
  confere(n('kstuff: esta carregado?'), /kstuff (ativo nesta sessão|não carregado)|Não deu para saber/.test(await txt(card('kstuff') + ' .agora')), await txt(card('kstuff') + ' .agora'));
  confere(n('kstuff: regras do autoinicio'), ks.includes('vem antes dos outros') && ks.includes('nunca duas vezes no mesmo boot'));
  confere(n('kstuff: arquivo seu + instalado como'), (await txt(card('kstuff') + ' .arq-seu')).includes('Kstuff-NG_v1.00.elf') &&
    (await txt(card('kstuff') + ' .arq-seu')).includes('instalado como kstuff-PristMC.elf'), await txt(card('kstuff') + ' .arq-seu'));
  confere(n('kstuff: sem botao Baixar'), !(await vis(card('kstuff') + ' .b-baixar')));
  // Instalar de arquivo: lista (sugeridos primeiro, mais nova)
  await pagina.click(card('kstuff') + ' .arq summary');
  await pagina.click(card('kstuff') + ' .b-arq-procurar');
  await pagina.waitForSelector(card('kstuff') + ' .arq-item', { timeout: 10000 }).catch(() => null);
  const itens = await pagina.$$eval(card('kstuff') + ' .arq-item', es => es.map(e => ({ n: e.querySelector('.arq-nome').textContent, s: e.querySelector('small').textContent, b: e.querySelector('button').textContent, d: e.querySelector('button').disabled })));
  confere(n('lista: 1o do payload manager, sugerido, ja instalado'), itens[0] && itens[0].n.endsWith('/pldmgr/payloads/Kstuff-NG_v1.00.elf') && itens[0].s.includes('payload manager') && itens[0].s.includes('sugerido') && itens[0].b === 'Já instalado' && itens[0].d, JSON.stringify(itens[0]));
  const nova = itens.find(i => i.n.endsWith('kstuff-v1.01.elf'));
  confere(n('lista: v1.01 mais nova, Atualizar a partir deste arquivo'), nova && nova.s.includes('mais nova que a instalada') && nova.b === 'Atualizar a partir deste arquivo' && !nova.d, JSON.stringify(nova));
  confere(n('lista: outros .elf tambem'), itens.some(i => i.n.endsWith('outro-payload.elf') && !i.s.includes('sugerido')));
  if (tela.nome === 'celular') {
    // revisao 0.9.41: Ativar do kstuff com o marcador deste boot = pergunta explicita. A pagina aberta em 127.0.0.1 e
    // "local" (o glibren recusa Ativar dela): o servidor responde por page.route como o glibren responderia ao celular.
    const pedidos = [];
    await pagina.route('**/api/payloads/ativar', async rota => {
      const corpo = rota.request().postData() || '';
      pedidos.push(corpo);
      if (!corpo.includes('confirmo_kstuff=1'))
        await rota.fulfill({ status: 409, contentType: 'application/json', body: JSON.stringify({ ok: false, chave: 'payload_kstuff_confirmar', erro: 'x', params: { nome: 'boot' } }) });
      else await rota.fulfill({ status: 200, contentType: 'application/json', body: '{"ok":true}' });
    });
    const dialogos = [];
    const tratar = async d => { dialogos.push(d.message()); await d.accept(); };
    pagina.on('dialog', tratar);
    await pagina.click(card('kstuff') + ' .b-ativar').catch(() => null);
    for (let k = 0; k < 50 && pedidos.length < 2; k++) await pagina.waitForTimeout(100);
    pagina.off('dialog', tratar);
    await pagina.unroute('**/api/payloads/ativar');
    confere(n('kstuff Ativar: pergunta explicita'), (dialogos[1] || '').includes('Tenho certeza de que o kstuff não está carregado'), JSON.stringify(dialogos));
    confere(n('kstuff Ativar: motivo (ja mandado neste boot)'), (dialogos[1] || '').includes('já mandou o kstuff neste boot'), dialogos[1] || '');
    confere(n('kstuff Ativar: 1o pedido sem confirmacao'), pedidos[0] !== undefined && !pedidos[0].includes('confirmo_kstuff'), JSON.stringify(pedidos));
    confere(n('kstuff Ativar: OK manda confirmo_kstuff=1'), (pedidos[1] || '').includes('confirmo_kstuff=1'), JSON.stringify(pedidos));
    confere(n('kstuff Ativar: sem reticencias'), !dialogos.some(d => d.includes('…')));
  }
  const m = await medir(pagina);
  confere(n('sem rolar de lado'), !m.rola);
  confere(n('botoes da mesma linha: mesma largura'), m.larguras.every(l => l.every(x => Math.abs(x - l[0]) <= 1)), JSON.stringify(m.larguras));
  confere(n('nada cortado'), m.cortados.length === 0, m.cortados.join(' | '));
  await pagina.close();
}
await navegador.close();
console.log(`=== pagina ${ok} ok, ${falhas} falhas`);
process.exit(falhas ? 1 : 0);
