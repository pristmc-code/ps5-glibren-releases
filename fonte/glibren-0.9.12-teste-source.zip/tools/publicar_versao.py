"""Prepara uma versao do glibren para o repositorio publico de versoes (pristmc-code/ps5-glibren-releases).

Uso:  python tools/publicar_versao.py PASTA_DO_REPO_PUBLICO "notas da versao" [--sem-testes] [--simular]
Depois: commit e push na pasta do repositorio publico.

Para em qualquer problema, antes de gravar qualquer coisa no repositorio publico:
1. o repositorio do payload tem de estar limpo (tudo commitado): o binario e o fonte publicados saem do mesmo HEAD;
2. compila do zero no WSL (compilar.sh clean + all), nunca reaproveita um build antigo;
3. roda todos os testes do PC (compilar.sh pc + testes/todos.sh), salvo --sem-testes;
4. confere o marcador exato "GLIBREN-VERSAO:<versao>\\n" no .elf e que a versao e maior que a ja publicada;
5. assina saida/glibren.elf com a chave privada Ed25519 (fica so neste PC, fora do repositorio) e confere a
   assinatura com a chave publica embutida no payload (src/chave_publica.h);
6. gera fonte/glibren-<versao>-source.zip do HEAD (git archive) e grava o commit no versao.json;
7. passa tudo pela checagem de privacidade (ps5/ferramentas/privacidade.py), que bloqueia.
Com --simular faz tudo numa pasta temporaria e nao toca no repositorio publico.
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

from cryptography.hazmat.primitives import serialization

CHAVE = os.path.join(os.path.expanduser("~"), ".glibren", "assinatura_ed25519.pem")
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PRIVACIDADE = os.path.join(os.path.dirname(RAIZ), "ferramentas", "privacidade.py")


def parar(msg):
    print(f"PARAR: {msg}")
    sys.exit(1)


def git(*args):
    return subprocess.run(["git", "-C", RAIZ, *args], capture_output=True, text=True, check=True).stdout


def caminho_wsl(p):
    p = os.path.abspath(p).replace("\\", "/")
    return f"/mnt/{p[0].lower()}{p[2:]}"


def wsl(script, *args):
    r = subprocess.run(["wsl", "-d", "Ubuntu-24.04", "-u", "root", "--", "bash", caminho_wsl(script), *args])
    if r.returncode:
        parar(f"{os.path.basename(script)} {' '.join(args)} falhou (saida {r.returncode})")


def numero_versao(v):
    """Igual ao numero_versao() do payload (atualizacao.c): so os numeros, ate 3 partes."""
    partes = re.findall(r"\d+", v.split("-")[0])[:3]
    n = 0
    for i in range(3):
        n = n * 1000 + (int(partes[i]) if i < len(partes) else 0)
    return n


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    sem_testes, simular = "--sem-testes" in sys.argv, "--simular" in sys.argv
    if len(args) < 2:
        print(__doc__)
        return 1
    destino, notas = args[0], args[1]
    if not os.path.exists(PRIVACIDADE):
        parar(f"falta {PRIVACIDADE}")

    # 1) repositorio limpo
    sujo = git("status", "--porcelain")
    if sujo.strip():
        parar("o repositorio do payload tem mudancas sem commit:\n" + sujo)
    commit = git("rev-parse", "HEAD").strip()
    versao = re.search(r'#define VERSAO "([^"]+)"', open(os.path.join(RAIZ, "src", "api.h"), encoding="utf-8").read()).group(1)
    publicada = os.path.join(destino, "versao.json")
    if os.path.exists(publicada):
        anterior = json.load(open(publicada, encoding="utf-8")).get("versao", "")
        if numero_versao(versao) <= numero_versao(anterior):
            if not simular:
                parar(f"a versao {versao} nao e maior que a publicada ({anterior})")
            print(f"AVISO (simulacao): a versao {versao} nao e maior que a publicada ({anterior}); publicar seria recusado")
    print(f"versao {versao}, commit {commit[:12]}")

    # 2) e 3) compilar do zero e testar
    compilar = os.path.join(RAIZ, "compilar.sh")
    for velho in ("glibren.elf", "glibren-pc"):   # um build que nao gerar nada nao deixa o antigo no lugar
        if os.path.exists(os.path.join(RAIZ, "saida", velho)):
            os.remove(os.path.join(RAIZ, "saida", velho))
    wsl(compilar, "clean")
    wsl(compilar, "all")
    if not sem_testes:
        wsl(compilar, "pc")
        wsl(os.path.join(RAIZ, "testes", "todos.sh"))
    if git("status", "--porcelain").strip():
        parar("a compilacao ou os testes mudaram arquivos do repositorio")

    # 4) marcador exato
    elf = open(os.path.join(RAIZ, "saida", "glibren.elf"), "rb").read()
    if f"GLIBREN-VERSAO:{versao}\n".encode() not in elf:
        parar(f"saida/glibren.elf nao tem o marcador da versao {versao}")

    # 5) assinatura
    chave = serialization.load_pem_private_key(open(CHAVE, "rb").read(), None)
    publica = chave.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    embutida = bytes(int(x, 16) for x in re.findall(r"0x([0-9a-f]{2})", open(os.path.join(RAIZ, "src", "chave_publica.h"), encoding="utf-8").read()))
    if publica != embutida:
        parar("a chave privada nao corresponde a chave publica embutida no payload")
    assinatura = chave.sign(elf)
    chave.public_key().verify(assinatura, elf)   # confere antes de publicar
    del chave

    # 6) arquivos numa pasta temporaria
    tmp = tempfile.mkdtemp(prefix="glibren-pub-")
    os.makedirs(os.path.join(tmp, "fonte"))
    open(os.path.join(tmp, "glibren.elf"), "wb").write(elf)
    open(os.path.join(tmp, "glibren.elf.sig"), "wb").write(assinatura)
    info = {"versao": versao, "notas": notas, "tamanho": len(elf), "sha256": hashlib.sha256(elf).hexdigest(), "commit": commit}
    with open(os.path.join(tmp, "versao.json"), "w", encoding="utf-8", newline="\n") as f:
        json.dump(info, f, ensure_ascii=False, indent=2)
        f.write("\n")
    zip_nome = f"glibren-{versao}-source.zip"
    if os.path.exists(os.path.join(destino, "fonte", zip_nome)):
        if not simular:
            parar(f"fonte/{zip_nome} ja existe no repositorio publico")
        print(f"AVISO (simulacao): fonte/{zip_nome} ja existe no repositorio publico; publicar seria recusado")
    git("archive", "--format=zip", "-o", os.path.join(tmp, "fonte", zip_nome), "HEAD")

    # 7) privacidade
    r = subprocess.run([sys.executable, PRIVACIDADE, os.path.join(tmp, "glibren.elf"), os.path.join(tmp, "versao.json"),
                        os.path.join(tmp, "fonte", zip_nome)])
    if r.returncode:
        shutil.rmtree(tmp)
        parar("a checagem de privacidade acusou algo (nada foi gravado)")

    if simular:
        print(f"SIMULACAO: arquivos em {tmp} (o repositorio publico nao foi tocado)")
        return 0
    os.makedirs(os.path.join(destino, "fonte"), exist_ok=True)
    for nome in ("glibren.elf", "glibren.elf.sig", "versao.json", os.path.join("fonte", zip_nome)):
        shutil.copyfile(os.path.join(tmp, nome), os.path.join(destino, nome))
    shutil.rmtree(tmp)
    print(f"versao {versao} pronta em {destino} ({len(elf)} bytes, sha256 {info['sha256'][:16]}..., commit {commit[:12]})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
