"""Inclui ou atualiza um app homebrew no catalogo assinado do repositorio publico de versoes
(pristmc-code/ps5-glibren-releases): apps.json + apps.json.sig.

O payload so aceita o catalogo se a assinatura Ed25519 do apps.json inteiro conferir com a chave publica embutida
(src/chave_publica.h); o zip baixado e conferido pelo tamanho e pelo SHA-256 que ficam no catalogo. O zip em si vai
como asset de uma release do GitHub (a url final e passada aqui); este script NAO publica nada: so grava os dois
arquivos na pasta indicada (depois: commit/push e a release, a mao).

Uso:
  python tools/publicar_app.py --repo PASTA_DO_REPO_PUBLICO --id ytps5 --titulo "YouTube (ytps5)" \\
      --title-id PPSA99350 --versao 1.2.3-glibren1 --zip PPSA99350.zip \\
      --url https://github.com/pristmc-code/ps5-glibren-releases/releases/download/ytps5-1.2.3-glibren1/PPSA99350.zip \\
      --preservar yt-token.json --busca glibren_busca.txt
Opcoes de teste: --chave ARQUIVO.pem (outra chave privada) e --teste (nao exige que a chave bata com a embutida).
"""
import argparse
import hashlib
import json
import os
import re
import sys
import zipfile

from cryptography.hazmat.primitives import serialization

CHAVE = os.path.join(os.path.expanduser("~"), ".glibren", "assinatura_ed25519.pem")
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OFICIAIS = {"PPSA01650", "PPSA01651", "PPSA01652"}   # app oficial do YouTube: porta do Y2JB, nunca no catalogo
HOSTS = ("https://github.com/", "https://raw.githubusercontent.com/", "https://release-assets.githubusercontent.com/",
         "https://objects.githubusercontent.com/")


def erro(msg):
    print("ERRO:", msg)
    sys.exit(1)


def conferir_zip(caminho, title_id):
    """Mesmas regras do payload: eboot.bin e sce_sys/param.json na raiz (ou numa pasta de topo unica), titleId igual."""
    with zipfile.ZipFile(caminho) as z:
        nomes = z.namelist()
        if len(nomes) > 65535:
            erro("zip com entradas demais (ZIP64 nao e aceito pelo payload)")
        prefixo = ""
        if "eboot.bin" not in nomes:
            topo = {n.split("/", 1)[0] for n in nomes}
            if len(topo) == 1 and all("/" in n or n.endswith("/") for n in nomes):
                prefixo = topo.pop() + "/"
        for n in nomes:
            partes = n.rstrip("/").split("/")
            if n.startswith("/") or "\\" in n or ":" in n or any(p in ("", ".", "..") for p in partes) or any(ord(c) < 32 for c in n):
                erro(f"nome perigoso no zip: {n!r} (o payload recusaria)")
        for i in z.infolist():
            if i.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):
                erro(f"{i.filename}: compressao {i.compress_type} (o payload so aceita stored e deflate)")
            if i.file_size >= 0xFFFFFFFF or i.compress_size >= 0xFFFFFFFF:
                erro(f"{i.filename}: grande demais (ZIP64)")
        if prefixo + "eboot.bin" not in nomes or prefixo + "sce_sys/param.json" not in nomes:
            erro("o zip precisa ter eboot.bin e sce_sys/param.json na raiz (ou numa pasta de topo unica)")
        param = json.loads(z.read(prefixo + "sce_sys/param.json").decode("utf-8-sig").rstrip("\0"))
        if param.get("titleId") != title_id:
            erro(f"titleId do param.json ({param.get('titleId')}) diferente de {title_id}")
        total = sum(i.file_size for i in z.infolist())
    return prefixo, total


def main():
    a = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    a.add_argument("--repo", required=True, help="pasta do repositorio publico de versoes")
    a.add_argument("--id", required=True)
    a.add_argument("--titulo", required=True)
    a.add_argument("--title-id", required=True)
    a.add_argument("--versao", required=True)
    a.add_argument("--zip", required=True)
    a.add_argument("--url", required=True)
    a.add_argument("--preservar", action="append", default=[], help="arquivo da pasta do app mantido ao atualizar (repetir)")
    a.add_argument("--busca", default="glibren_busca.txt")
    a.add_argument("--chave", default=CHAVE, help=argparse.SUPPRESS)
    a.add_argument("--teste", action="store_true", help=argparse.SUPPRESS)
    o = a.parse_args()

    if not re.fullmatch(r"[a-z0-9_-]{1,32}", o.id):
        erro("id: so a-z, 0-9, - e _ (ate 32)")
    if not re.fullmatch(r"[A-Z]{4}\d{5}", o.title_id) or o.title_id in OFICIAIS or o.title_id == "PMGL00001":
        erro("title_id invalido ou proibido")
    if not re.fullmatch(r"[A-Za-z0-9._-]{1,32}", o.versao):
        erro("versao: so letras, numeros, . - _ (ate 32)")
    if not 1 <= len(o.titulo) <= 96 or any(ord(c) < 32 for c in o.titulo):
        erro("titulo invalido")
    hosts = HOSTS + (("http://127.0.0.1:",) if o.teste else ())   # --teste: servidor local do testes/teste_apps.sh
    if not o.url.startswith(hosts) or len(o.url) > 1000 or not re.fullmatch(r"[A-Za-z0-9\-._~:/?#\[\]@!&*+,=%]+", o.url):
        erro("url fora dos hosts permitidos pelo payload ou com caracteres invalidos")
    for n in o.preservar + [o.busca]:
        if not re.fullmatch(r"[^/\\:\x00-\x1f]{1,63}", n) or n in (".", "..") or n.startswith(".") or n == "glibren_app.json":
            erro(f"nome invalido: {n!r} (so um nome de arquivo simples)")
    if len(o.preservar) > 8:
        erro("no maximo 8 arquivos em --preservar")

    prefixo, total = conferir_zip(o.zip, o.title_id)
    dados = open(o.zip, "rb").read()
    if not 0 < len(dados) <= 2000 * 1024 * 1024 or total > 2048 * 1024 * 1024:
        erro("zip grande demais para o payload")
    entrada = {"id": o.id, "titulo": o.titulo, "title_id": o.title_id, "versao": o.versao, "url": o.url,
               "tamanho": len(dados), "sha256": hashlib.sha256(dados).hexdigest(), "preservar": o.preservar,
               "busca": o.busca}

    chave = serialization.load_pem_private_key(open(o.chave, "rb").read(), None)
    publica = chave.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    embutida = bytes(int(x, 16) for x in re.findall(r"0x([0-9a-f]{2})", open(os.path.join(RAIZ, "src", "chave_publica.h"), encoding="utf-8").read()))
    if publica != embutida:
        if not o.teste:
            erro("a chave privada nao corresponde a chave publica embutida no payload")
        print("AVISO (--teste): chave diferente da embutida no payload")

    arq = os.path.join(o.repo, "apps.json")
    catalogo = {"apps": []}
    if os.path.exists(arq):
        catalogo = json.load(open(arq, encoding="utf-8"))
        sig = os.path.join(o.repo, "apps.json.sig")
        try:
            chave.public_key().verify(open(sig, "rb").read(), open(arq, "rb").read())
        except Exception:
            print("AVISO: o apps.json atual nao tinha assinatura valida com esta chave (sera assinado de novo)")
    apps = [x for x in catalogo.get("apps", []) if x.get("id") != o.id and x.get("title_id") != o.title_id]
    antigos = [x for x in catalogo.get("apps", []) if x.get("id") == o.id or x.get("title_id") == o.title_id]
    pos = catalogo.get("apps", []).index(antigos[0]) if antigos else len(apps)
    apps.insert(min(pos, len(apps)), entrada)
    catalogo["apps"] = apps
    texto = (json.dumps(catalogo, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    if len(texto) > 256 * 1024 or len(apps) > 16:
        erro("catalogo grande demais para o payload (256 KB / 16 apps)")
    assinatura = chave.sign(texto)
    chave.public_key().verify(assinatura, texto)   # confere antes de gravar
    os.makedirs(o.repo, exist_ok=True)
    open(arq + ".tmp", "wb").write(texto)
    open(arq + ".sig.tmp", "wb").write(assinatura)
    os.replace(arq + ".tmp", arq)
    os.replace(arq + ".sig.tmp", arq + ".sig")
    print(f"{o.id} {o.versao} ({'atualizado' if antigos else 'novo'}): {len(dados)} bytes, sha256 {entrada['sha256'][:16]}..., "
          f"{total} bytes descompactado{', pasta de topo ' + prefixo if prefixo else ''}; {len(apps)} app(s) em {arq}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
