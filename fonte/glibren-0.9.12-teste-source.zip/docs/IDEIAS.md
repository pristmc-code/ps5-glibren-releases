# Ideias e conhecimento para próximas funções do payload

Levantado em 03/11/2026 lendo projetos da cena PS5 (só leitura; nada copiado — vários são GPL-3.0).
Fontes principais: onionHEN (github.com/aydencharles/onionHEN, v0.9.0), OnionBuddies (plugins/SDK),
ProsperoMgr (github.com/notmaj0r/ProsperoMgr), CheatRunner (notmaj0r), drakmor/fan_target, ps5upload, Breeze.

## Pausar o jogo / abrir por cima do jogo
- O onionHEN **não pausa** o processo do jogo: o atalho abre as Configurações (`sceShellUIUtilLaunchByUri`
  com `pssettings:play?...function=debug_settings`) por cima; o jogo perde o foco e a maioria se pausa sozinha.
- Pausar de verdade (SIGSTOP/ptrace/mdbg "kick process" no PID do jogo) = risco alto (watchdog de GPU/áudio,
  PSN, travamento). Não fazer.
- Abrir nossa página por cima do jogo a partir do payload: `sceSystemServiceLaunchWebBrowser(url, NULL)`
  (precisa `sceUserServiceInitialize(0)`; exemplo `samples/browser` do SDK; o CheatRunner usa com jogo aberto).
  Alternativa a testar: `sceShellUIUtilLaunchByUri`.

## Atalho no controle durante o jogo
- Payload comum não lê o controle com jogo em primeiro plano (`scePadOpen` → 0x809b0081).
- Quem faz (etaHEN, onionHEN, CheatRunner) injeta código no **SceShellUI** (Mono) e faz detour em
  `Sce.PlayStation.Core.Input.GamePad.GetData`; segurar ~1 s; Create via `CaptureMenu.EventManager.OnShareButton` /
  `CaptureController.CaptureScreen`. Precisa authid 0x4801000000000013 + ptrace.
- Riscos: travar/reiniciar a interface; conflito com outros injetores (onionHEN recusa iniciar se achar
  "etaHEN Utility Daemon", "etaHEN Critical services", Yoncore.elf, kylin-core.elf, wmdw-jwm.elf, CheatRunner.elf).
- Caminho mais seguro: **virar plugin do onionHEN** (quem usa onionHEN) — ver abaixo. Usuário atual não usa HEN
  (usa ProsperoMgr), então para ele o atalho exigiria injeção própria, desligada por padrão, com detecção de conflito.

## Plugin do onionHEN (opcional)
- ELF com seção `.onion_plugin` (struct v1 128 bytes: abi 1, caps NOTIFY=1 IPC=2 PROCESS=4 INJECT=8 KERNEL=16
  UI=32, flags AUTO_START=1 LONG_RUNNING=2 STOP_SUPPORTED=4, plugin_id 4 letras+5 dígitos, version "N.NN", name);
  instalado em `/data/OnionHEN/plugins/<ID>.elf`. SDK: github.com/OnionBuddies/onionHEN-plugin-sdk (GPL-3.0).
- IPC: socket `/system_tmp/onionhen/ipc/plugin_service`, frame 'OPIC'; HELLO, PING, polling de eventos (9),
  UI REGISTER_BEGIN/CHUNK/COMMIT/ABORT/UNREGISTER/SET_VALUE (10–15). LOG/NOTIFY/CONFIG ainda NOT_SUPPORTED.
- UI: Page, Menu, Group, Label, Action, Toggle, List, ListItem, Input (bool/int/string). Sem gráfico; valores
  não atualizam com a página aberta (precisa reabrir).
- O atalho do onionHEN abre a raiz da Toolbox (alguns cliques até a página).

## Ventoinha (já implementado; detalhes)
- `/dev/icc_fan`, ioctl 0xC01C8F08 (ler) / 0xC01C8F07 (gravar) perfil de 28 bytes; byte 5 = alvo °C.
  Ler-mudar só o byte 5-gravar-conferir. O firmware desfaz logo depois (onionHEN issue #40): conferir a cada 2 s.
- Alvo do sistema varia por placa (91, 86, 77, 69 °C); nunca passar dele. Velocidade só em % (sem RPM).
- "Velocidade mínima" real: não há forma segura (0xC0068F05 "manual duty" sem modo manual confirmado; piso na
  tabela de calibração, só kernel).
- onionHEN regrava a cada 2 s quando ativo; ProsperoMgr a cada 15 s → quem grava por último ganha. Nosso payload
  detecta valor de outro programa e volta ao automático.

## Métricas que dá para acrescentar (risco baixo)
- CPU por núcleo: `sceKernelGetCpuUsage(Proc_Stats*, int*)` duas vezes + threads `SceIdleCpu%d`
  (`sceKernelGetThreadName`), diferença do tempo ocioso.
- RAM e VRAM: `get_page_table_stats(vm, type, &total, &free)` (export do libkernel). O "GPU %" do onionHEN é VRAM.
- Sensor `sceKernelGetSocSensorTemperature(0)` = SoC/GPU.
- IP: NetCtl.
- FPS: `/dev/dce` ioctl 0x80308217 + DMAP do AgcDriver do jogo — risco alto, depende do firmware.

## Outras ideias
- Sobreviver ao rest mode: refazer o `listen` se o `accept` falhar; detectar estado SUSPEND_ON_GOING (300).
- Autoload/gerenciador de payloads (ps5-unified-autoloader: `autoload.txt`, `@sync`, `!ms`; enviar ELF ao 9021).
- Galeria de capturas por HTTP (só leitura).
- Ícone/arte do jogo em execução na tela.
- Listar processos / fechar app (`sceLncUtilKillApp`) — risco médio.
- NTP (acertar relógio) — risco médio.
- Portas usadas por outros: 9020, 9021, 9023 (Kylin), 9048, 9088, 1337, 12800, 7070 (ProsperoMgr), 8080 (websrv).
