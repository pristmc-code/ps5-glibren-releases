/* Teste do leitor PFS/PFSC (src/fmt_pfs.c) no PC.
   Uso:
     teste_pfs ler <imagem> <caminho> <saida> [max]      pfs_ler -> grava o conteudo em <saida>
     teste_pfs interno <imagem.ffpfsc> <saida>           ffpfsc_abrir -> grava a imagem interna inteira em <saida>
     teste_pfs interno_ler <imagem.ffpfsc> <caminho> <saida>   pfs_ler sobre a imagem interna (interna = .ffpfs)
   Imprime "ret=<codigo> tam=<bytes> [nome=<interno>]". Codigo de saida 0 sempre que o programa rodou. */
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include "imagem.h"

/* buf_add simples (o util.c do payload puxa outras dependencias) */
void buf_add(buf_t *b, const void *dados, size_t n) {
  if(b->n + n + 1 > b->cap) {
    size_t cap = (b->n + n + 1) * 2;
    char *d = realloc(b->d, cap);
    if(!d) abort();
    b->d = d;
    b->cap = cap;
  }
  memcpy(b->d + b->n, dados, n);
  b->n += n;
  b->d[b->n] = 0;
}

static int gravar(const char *nome, const void *d, size_t n) {
  FILE *f = fopen(nome, "wb");
  if(!f) return -1;
  if(n && fwrite(d, 1, n, f) != n) { fclose(f); return -1; }
  return fclose(f);
}

static int abrir(const char *nome, dispositivo_t *d) {
  int fd = open(nome, O_RDONLY);
  struct stat st;
  if(fd < 0 || fstat(fd, &st)) { perror(nome); exit(2); }
  dispositivo_arquivo(d, fd, (uint64_t)st.st_size);
  return fd;
}

/* Le o dispositivo inteiro em pedacos de tamanhos variados (testa leituras que cruzam blocos e o cache). */
static int ler_tudo(dispositivo_t *d, const char *saida) {
  FILE *f = fopen(saida, "wb");
  if(!f) return -1;
  static const size_t tams[] = {1, 4095, 65536, 100000, 7, 300000, 65535};
  uint8_t *b = malloc(300000);
  uint64_t off = 0;
  int r = 0;
  for(int i = 0; off < d->tamanho; i++) {
    size_t m = tams[i % 7];
    if(m > d->tamanho - off) m = (size_t)(d->tamanho - off);
    if(d->ler(d, off, b, m)) { r = -1; break; }
    fwrite(b, 1, m, f);
    off += m;
  }
  /* leitura alem do fim tem de falhar */
  if(!r && d->ler(d, d->tamanho, b, 1) == 0) r = -2;
  /* releitura aleatoria de um trecho no comeco (bloco ja descartado do cache) */
  if(!r && d->tamanho > 16) {
    uint8_t x[16], y[16];
    if(d->ler(d, 0, x, 16) || d->ler(d, 0, y, 16) || memcmp(x, y, 16)) r = -3;
  }
  free(b);
  fclose(f);
  return r;
}

int main(int argc, char **argv) {
  if(argc < 4) {
    fprintf(stderr, "uso: ver o comentario do fonte\n");
    return 2;
  }
  dispositivo_t d;
  int fd = abrir(argv[2], &d);
  if(!strcmp(argv[1], "ler") && argc >= 5) {
    buf_t b = {0};
    size_t max = argc >= 6 ? (size_t)strtoull(argv[5], NULL, 0) : (size_t)64 << 20;
    int r = pfs_ler(&d, argv[3], &b, max);
    printf("ret=%d tam=%zu\n", r, b.n);
    if(r == IMG_OK && gravar(argv[4], b.d, b.n)) return 3;
    free(b.d);
  } else if(!strcmp(argv[1], "interno")) {
    dispositivo_t in;
    char nome[256];
    int r = ffpfsc_abrir(&d, &in, nome, sizeof nome);
    if(r == IMG_OK) {
      int l = ler_tudo(&in, argv[3]);
      printf("ret=%d tam=%llu nome=%s leitura=%d\n", r, (unsigned long long)in.tamanho, nome, l);
      if(in.fechar) in.fechar(&in);
    } else {
      printf("ret=%d tam=0\n", r);
    }
  } else if(!strcmp(argv[1], "interno_ler") && argc >= 5) {
    dispositivo_t in;
    char nome[256];
    int r = ffpfsc_abrir(&d, &in, nome, sizeof nome);
    if(r == IMG_OK) {
      buf_t b = {0};
      r = pfs_ler(&in, argv[3], &b, (size_t)64 << 20);
      printf("ret=%d tam=%zu nome=%s\n", r, b.n, nome);
      if(r == IMG_OK && gravar(argv[4], b.d, b.n)) return 3;
      free(b.d);
      if(in.fechar) in.fechar(&in);
    } else {
      printf("ret=%d tam=0 (ffpfsc_abrir)\n", r);
    }
  } else {
    fprintf(stderr, "comando invalido\n");
    return 2;
  }
  close(fd);
  return 0;
}
