#!/bin/bash
# Testa as protecoes da 0.9.12 na versao de PC: Host (G4), URL com "@" e porta estranha (R2), excluir/mover/copiar/
# renomear/ativar so nas pastas da lista (G5) e o alvo de fabrica da ventoinha guardado em arquivo (G6).
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_seguranca.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8781
U="http://127.0.0.1:$PORTA"
DADOS=/root/glr-dados-seg; A=/root/glr-seg/lista; F=/root/glr-seg/fora
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
codigo() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
rm -rf "$DADOS" /root/glr-seg; mkdir -p "$DADOS" "$A" "$F"
printf 'language = pt-BR\nfolder = %s/\n' "$A" > "$DADOS/config.ini"
head -c 1000 /dev/urandom > "$A/jogo.pkg"
head -c 1000 /dev/urandom > "$F/importante.db"
inicia() { "$BIN" -p $PORTA -d "$DADOS" > /tmp/glr-seg.log 2>&1 & PID=$!; sleep 1; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
GLR_TESTE_ALVO=69 inicia

echo "--- G4: Host"
confere "Host 127.0.0.1:porta"      "$(codigo $U/api/estado)" "200"
confere "Host localhost"            "$(codigo -H 'Host: localhost:8765' $U/api/estado)" "200"
confere "Host IP da rede"           "$(codigo -H 'Host: 192.168.0.50:8765' $U/api/estado)" "200"
confere "Host IPv6"                 "$(codigo -H 'Host: [::1]:8765' $U/api/estado)" "200"
confere "Host nome de site"         "$(codigo -H 'Host: ataque.example.com:8765' $U/api/estado)" "403"
confere "Host nome parecido"        "$(codigo -H 'Host: 127.0.0.1.nip.io' $U/)" "403"
confere "Host localhost.algo"       "$(codigo -H 'Host: localhost.example.com' $U/)" "403"
confere "Host porta estranha"       "$(codigo -H 'Host: 192.168.0.50:80x' $U/)" "403"
confere "Host estranho: POST"       "$(codigo -H 'X-GLR: 1' -H 'Host: ataque.example.com' -d tipo=excluir -d "pasta=$A" -d de=jogo.pkg $U/api/tarefas)" "403"
confere "Host estranho: nada apagado" "$(ls $A)" "jogo.pkg"
confere "Host recusado no diario"   "$(cat $DADOS/glibren.log)" 'pedido recusado: Host "ataque.example.com:8765"'
confere "/launch local continua"    "$(curl -s -H 'Content-Type: application/json' -d '{"title":"PPSA00001"}' $U/launch)" "fora_da_lista"

echo "--- R2: URL"
confere "/api/web com @"            "$(codigo "$U/api/web?url=https%3A%2F%2Fprosperopatches.com%3Ax%40127.0.0.1%2Fadmin")" "403"
confere "/api/web porta nao numero" "$(codigo "$U/api/web?url=https%3A%2F%2Fprosperopatches.com%3Ax%2Fadmin")" "403"
confere "/api/web outro host"       "$(codigo "$U/api/web?url=https%3A%2F%2Fprosperopatches.com.example.com%2F")" "403"
confere "/icone com @: nao baixa"   "$(codigo "$U/icone/PPSA01234?url=https%3A%2F%2Fcdn.prosperopatches.com%40127.0.0.1%2Fa.png")" "404"

echo "--- G5: so nas pastas da lista"
confere "excluir fora da lista"     "$(post -d tipo=excluir -d "pasta=$F" -d de=importante.db $U/api/tarefas)" '"fora_das_pastas":1'
confere "excluir de /etc"           "$(post -d tipo=excluir -d pasta=/etc -d de=hostname $U/api/tarefas)" '"fora_das_pastas":1'
confere "excluir subpasta da lista" "$(post -d tipo=excluir -d "pasta=$A/.." -d de=fora $U/api/tarefas)" '"criadas":0'
confere "copiar para fora"          "$(post -d tipo=copiar -d "destino=$F" -d "pasta=$A" -d de=jogo.pkg $U/api/tarefas)" '"fora_das_pastas":1'
confere "mover de fora para dentro" "$(post -d tipo=mover -d "destino=$A" -d "pasta=$F" -d de=importante.db $U/api/tarefas)" '"fora_das_pastas":1'
sleep 0.5
confere "fora intacto"              "$(ls $F)" "importante.db"
confere "dentro intacto"            "$(ls $A)" "jogo.pkg"
confere "renomear fora da lista"    "$(post -d "pasta=$F" -d de=importante.db -d para=x.db $U/api/renomear)" '"chave":"fora_das_pastas"'
confere "renomear na lista"         "$(post -d "pasta=$A/" -d de=jogo.pkg -d para=jogo2.pkg $U/api/renomear)" '"ok":true'
confere "ativar fora da lista"      "$(post -d "pasta=$F" -d nome=importante.db $U/api/ativar)" '"chave":"fora_das_pastas"'
confere "excluir na lista"          "$(post -d tipo=excluir -d "pasta=$A" -d de=jogo2.pkg $U/api/tarefas)" '"criadas":1'

echo "--- G6: alvo de fabrica da ventoinha"
confere "alvo lido com o limite desligado" "$(curl -s $U/api/termico)" '"alvo_sistema":69'
confere "alvo guardado"             "$(cat $DADOS/alvo_fabrica.txt)" "factory_target = 69"
confere "limite 60 aceito"          "$(post -d c=60 $U/api/termico/limite)" '"limite":60'
para
# o perfil ainda e o nosso (60), como depois de uma atualizacao do payload: o guardado vale
GLR_TESTE_ALVO=60 inicia
confere "depois de reiniciar: guardado" "$(curl -s $U/api/termico)" '"alvo_sistema":69'
confere "acima do de fabrica: recusado" "$(post -d c=85 $U/api/termico/limite)" "nao pode passar do valor do sistema (69 C)"
para

rm -rf "$DADOS" /root/glr-seg
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
