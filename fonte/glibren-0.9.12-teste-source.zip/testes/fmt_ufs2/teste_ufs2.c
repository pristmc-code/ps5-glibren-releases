/* Teste do leitor UFS2 (src/fmt_ufs2.c).
   Uso:
     teste_ufs2 <imagem> <caminho> [saida] [max]   le o arquivo; imprime "r=<codigo> n=<bytes>" e grava em saida
     teste_ufs2 fuzz <imagem> <iteracoes>          corrompe bytes aleatorios da imagem (em memoria) e chama o leitor;
                                                    so pode terminar sem travar e sem erro de memoria (ASan) */
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include "imagem.h"

/* Imagem com o comeco (regiao) copiado em memoria e corrompido; o resto e lido do arquivo. */
typedef struct {
  uint8_t *dados;
  size_t regiao;
  int fd;
} memoria_t;

static int ler_mem(dispositivo_t *d, uint64_t off, void *buf, size_t n) {
  memoria_t *m = d->ctx;
  if(off > d->tamanho || n > d->tamanho - off) return -1;
  uint8_t *p = buf;
  while(n && off < m->regiao) {
    size_t k = m->regiao - off < n ? m->regiao - off : n;
    memcpy(p, m->dados + off, k);
    p += k;
    off += k;
    n -= k;
  }
  if(n && pread(m->fd, p, n, (off_t)off) != (ssize_t)n) return -1;
  return 0;
}

static int fuzz(const char *img, int iter) {
  int fd = open(img, O_RDONLY);
  if(fd < 0) return 1;
  struct stat st;
  fstat(fd, &st);
  size_t tam = (size_t)st.st_size;
  /* Regiao corrompida: superbloco + grupo 0 (inodes, diretorios e os primeiros dados) no comeco da imagem. */
  size_t regiao = tam < 8 * 1024 * 1024 ? tam : 8 * 1024 * 1024;
  uint8_t *orig = malloc(regiao), *copia = malloc(regiao);
  if(!orig || !copia || pread(fd, orig, regiao, 0) != (ssize_t)regiao) return 1;
  static const char *caminhos[] = {"sce_sys/param.json", "sce_sys/icon0.png", "grande.bin",
                                   "muitos/arquivo_nome_bem_comprido_2999.txt", "a/b/c/d/e/fundo.txt"};
  srand(12345);
  int cont[4] = {0};
  for(int i = 0; i < iter; i++) {
    memcpy(copia, orig, regiao);
    int trocas = 1 + rand() % 16;
    for(int t = 0; t < trocas; t++) {
      size_t perto = regiao < 2 * 1024 * 1024 ? regiao : 2 * 1024 * 1024;   /* metade cai nos primeiros 2 MB */
      size_t off = (size_t)rand() % (rand() % 2 ? perto : regiao);
      if(rand() % 2) copia[off] = (uint8_t)rand();
      else copia[off] ^= (uint8_t)(1u << (rand() % 8));
    }
    uint64_t tam_dev = tam;
    if(i % 7 == 0) tam_dev = (uint64_t)rand() % tam;   /* imagem truncada */
    memoria_t m = {copia, regiao, fd};
    dispositivo_t d = {ler_mem, NULL, tam_dev, &m};
    buf_t b = {0};
    int r = ufs2_ler(&d, caminhos[i % 5], &b, 8 * 1024 * 1024);
    cont[-r < 4 && r <= 0 ? -r : 3]++;
    free(b.d);
  }
  printf("fuzz: %d iteracoes; OK=%d FORMATO=%d NAO_ACHOU=%d ERRO=%d\n", iter, cont[0], cont[1], cont[2], cont[3]);
  free(orig);
  free(copia);
  close(fd);
  return 0;
}

int main(int argc, char **argv) {
  if(argc >= 4 && !strcmp(argv[1], "fuzz")) return fuzz(argv[2], atoi(argv[3]));
  if(argc < 3) {
    fprintf(stderr, "uso: %s <imagem> <caminho> [saida] [max]\n", argv[0]);
    return 2;
  }
  size_t max = argc >= 5 ? (size_t)strtoull(argv[4], NULL, 10) : 64 * 1024 * 1024;
  int fd = open(argv[1], O_RDONLY);
  if(fd < 0) {
    printf("r=%d n=0\n", IMG_NAO_ACHOU);   /* imagem inexistente: o chamador real nem chega ao leitor */
    return 0;
  }
  struct stat st;
  fstat(fd, &st);
  dispositivo_t d;
  dispositivo_arquivo(&d, fd, (uint64_t)st.st_size);
  buf_t b = {0};
  int r = ufs2_ler(&d, argv[2], &b, max);
  printf("r=%d n=%zu\n", r, b.n);
  if(r == IMG_OK && argc >= 4) {
    FILE *f = fopen(argv[3], "wb");
    if(f) {
      fwrite(b.d, 1, b.n, f);
      fclose(f);
    }
  }
  free(b.d);
  close(fd);
  return 0;
}
