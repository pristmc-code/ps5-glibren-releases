#!/bin/bash
# Teste do leitor UFS2 (src/fmt_ufs2.c) com imagens REAIS geradas pelo makefs (NetBSD, pacote "makefs" do Ubuntu).
# Roda no Linux/WSL:  bash testes/fmt_ufs2/teste_ufs2.sh
# Precisa: clang-18, makefs (apt install makefs), python3.
set -u
cd "$(dirname "$0")/../.."
RAIZ=$(pwd)
TMP=$(mktemp -d /tmp/teste_ufs2.XXXXXX)
trap 'rm -rf "$TMP"' EXIT
FALHAS=0
ok()   { echo "  ok    $*"; }
erro() { echo "  FALHA $*"; FALHAS=$((FALHAS + 1)); }

echo "== compilando (normal e com -fsanitize=address,undefined)"
FONTES="testes/fmt_ufs2/teste_ufs2.c src/fmt_ufs2.c src/imagem.c src/util.c"
clang-18 -Wall -Werror -O2 -Isrc $FONTES -lpthread -o "$TMP/t" || exit 1
clang-18 -Wall -Werror -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=all -Isrc $FONTES -lpthread \
  -o "$TMP/t_asan" || exit 1

echo "== montando a arvore de arquivos"
A="$TMP/arvore"
mkdir -p "$A/sce_sys" "$A/muitos" "$A/a/b/c/d/e" "$A/Caixa"
python3 - "$A" <<'EOF'
import os, sys, random, json
a = sys.argv[1]
random.seed(7)
json.dump({"titleId": "PPSA01234", "contentId": "UP0000-PPSA01234_00-TESTEUFS2000000",
           "localizedParameters": {"defaultLanguage": "en-US", "en-US": {"titleName": "Teste UFS2 ção"}}},
          open(os.path.join(a, "sce_sys/param.json"), "w"), ensure_ascii=False)
# icon0.png de ~600 KB (aleatorio, so os bytes importam)
open(os.path.join(a, "sce_sys/icon0.png"), "wb").write(b"\x89PNG\r\n\x1a\n" + os.urandom(600 * 1024 - 8))
# 5 MB: com bsize 4K usa indireto duplo; com 32K/64K usa indireto simples
open(os.path.join(a, "grande.bin"), "wb").write(os.urandom(5 * 1024 * 1024 + 123))
# 3000 arquivos com nome comprido: diretorio com muitos blocos
for i in range(3000):
    open(os.path.join(a, "muitos", "arquivo_nome_bem_comprido_%04d.txt" % i), "w").write("conteudo %d\n" % i * (i % 5 + 1))
open(os.path.join(a, "a/b/c/d/e/fundo.txt"), "w").write("no fundo\n")
open(os.path.join(a, "Caixa/Abc.txt"), "w").write("maiusculo\n")
open(os.path.join(a, "Caixa/abc.txt"), "w").write("minusculo\n")
open(os.path.join(a, "Caixa/SoMaiusc.TXT"), "w").write("so existe em maiusculas\n")
open(os.path.join(a, "vazio.txt"), "w").close()
nome = "n" * 255
open(os.path.join(a, nome), "w").write("nome de 255\n")
open(os.path.join(a, "pequeno_frag.bin"), "wb").write(os.urandom(4096 * 3 + 100))   # termina em fragmentos
EOF

# confere: le "caminho" e compara byte a byte com o original
confere() {   # imagem caminho_na_imagem arquivo_original [bin]
  local bin=${4:-$TMP/t}
  local saida
  saida=$("$bin" "$1" "$2" "$TMP/saida" 2>&1)
  if [ "$saida" != "r=0 n=$(stat -c %s "$3")" ]; then erro "$(basename "$1") $2: $saida"; return; fi
  if cmp -s "$TMP/saida" "$3"; then ok "$(basename "$1") $2 ($(stat -c %s "$3") bytes, sha256 $(sha256sum < "$3" | cut -c1-12))"
  else erro "$(basename "$1") $2: conteudo diferente"; fi
  rm -f "$TMP/saida"
}
espera() {   # imagem caminho codigo [max]
  local saida
  saida=$("$TMP/t_asan" "$1" "$2" "" "${4:-67108864}" 2>&1 | head -1)
  case "$saida" in "r=$3 "*) ok "$(basename "$1") '$2' -> $3";; *) erro "$(basename "$1") '$2': esperado $3, veio $saida";; esac
}

# UFS2Tool (.NET, imita o newfs do FreeBSD: superbloco em 65536, igual ao mkufs2.sh do ShadowMountPlus).
# Opcional: UFS2TOOL=/caminho/UFS2Tool.dll (build: git clone https://github.com/SvenGDK/UFS2Tool &&
#   dotnet build UFS2Tool.csproj -c Release -o /tmp/ufs2tool_bin)
UFS2TOOL=${UFS2TOOL:-/tmp/ufs2tool_bin/UFS2Tool.dll}

# gerador bsize fsize tamanho_makefs -> imagens: makefs (superbloco em 8192) e UFS2Tool (65536)
LISTA=""
for LAYOUT in "65536 65536 260m" "32768 4096 64m" "4096 512 40m"; do
  set -- $LAYOUT
  LISTA="$LISTA makefs:$1:$2:$3"
  [ -f "$UFS2TOOL" ] && LISTA="$LISTA ufs2tool:$1:$2:0"
done
[ -f "$UFS2TOOL" ] || echo "AVISO: UFS2Tool nao encontrado em $UFS2TOOL; testando so com makefs (superbloco em 8192)"

for ITEM in $LISTA; do
  IFS=: read -r FERR BS FS TAM <<< "$ITEM"
  IMG="$TMP/jogo_${FERR}_b${BS}_f${FS}.ffpkg"
  rm -f "$IMG"
  echo "== $FERR UFS2 bsize=$BS fsize=$FS"
  if [ "$FERR" = makefs ]; then
    makefs -t ffs -B le -s "$TAM" -o version=2,bsize=$BS,fsize=$FS,minfree=0 "$IMG" "$A" > "$TMP/ger.log" 2>&1
  else   # mesmos parametros do mkufs2.sh do ShadowMountPlus
    SETOR=4096; [ $FS -lt 4096 ] && SETOR=$FS   # o UFS2Tool exige fsize >= setor
    dotnet "$UFS2TOOL" newfs -O 2 -b $BS -f $FS -m 0 -S $SETOR -D "$A" "$IMG" > "$TMP/ger.log" 2>&1
  fi
  [ -s "$IMG" ] || { erro "$FERR falhou: $(tail -3 "$TMP/ger.log")"; continue; }
  M=$(python3 - "$IMG" <<'PY'
import struct, sys
f = open(sys.argv[1], 'rb')
for loc in (65536, 262144, 8192):
    f.seek(loc); s = f.read(1376)
    if len(s) == 1376 and struct.unpack_from('<I', s, 1372)[0] == 0x19540119 and struct.unpack_from('<q', s, 1000)[0] in (0, loc):
        print(loc, *struct.unpack_from('<2i', s, 48)); break
else:
    print('sem superbloco')
PY
)
  echo "  superbloco (local bsize fsize): $M ($(stat -c %s "$IMG") bytes)"
  case "$M" in *" $BS $FS") ;; *) erro "superbloco inesperado";; esac
  for BIN in "$TMP/t" "$TMP/t_asan"; do
    confere "$IMG" sce_sys/param.json "$A/sce_sys/param.json" "$BIN"
    confere "$IMG" sce_sys/icon0.png "$A/sce_sys/icon0.png" "$BIN"
    confere "$IMG" /grande.bin "$A/grande.bin" "$BIN"
  done
  confere "$IMG" muitos/arquivo_nome_bem_comprido_0000.txt "$A/muitos/arquivo_nome_bem_comprido_0000.txt"
  confere "$IMG" muitos/arquivo_nome_bem_comprido_2999.txt "$A/muitos/arquivo_nome_bem_comprido_2999.txt"
  confere "$IMG" a/b/c/d/e/fundo.txt "$A/a/b/c/d/e/fundo.txt"
  confere "$IMG" Caixa/Abc.txt "$A/Caixa/Abc.txt"
  confere "$IMG" Caixa/abc.txt "$A/Caixa/abc.txt"
  confere "$IMG" CAIXA/somaiusc.txt "$A/Caixa/SoMaiusc.TXT"
  confere "$IMG" SCE_SYS/PARAM.JSON "$A/sce_sys/param.json"
  confere "$IMG" vazio.txt "$A/vazio.txt"
  confere "$IMG" "$(printf 'n%.0s' $(seq 255))" "$A/$(printf 'n%.0s' $(seq 255))"
  confere "$IMG" pequeno_frag.bin "$A/pequeno_frag.bin"
  espera "$IMG" sce_sys/nao_existe.json -2
  espera "$IMG" sce_sys -2                        # e diretorio, nao arquivo
  espera "$IMG" sce_sys/param.json/x -2           # arquivo no meio do caminho
  espera "$IMG" "" -2
  espera "$IMG" sce_sys/icon0.png -3 1000         # maior que max
  echo "== fuzz (bytes trocados + truncamento) com ASan"
  if "$TMP/t_asan" fuzz "$IMG" 3000 > "$TMP/fuzz.log" 2>&1; then ok "$(cat "$TMP/fuzz.log")"
  else erro "fuzz: $(tail -20 "$TMP/fuzz.log")"; fi
  for CORTE in 1000 65600 70000 200000 1000000; do
    head -c $CORTE "$IMG" > "$TMP/truncada.ffpkg"
    S=$("$TMP/t_asan" "$TMP/truncada.ffpkg" sce_sys/icon0.png 2>&1 | head -1)
    case "$S" in r=-1*|r=-2*|r=-3*) ok "truncada em $CORTE: $S";; *) erro "truncada em $CORTE: $S";; esac
  done
  rm -f "$IMG" "$TMP/truncada.ffpkg"
done

echo "== nao e UFS2"
head -c 300000 /dev/urandom > "$TMP/lixo.bin"
espera "$TMP/lixo.bin" sce_sys/param.json -1
: > "$TMP/vazio.bin"
espera "$TMP/vazio.bin" sce_sys/param.json -1
python3 -c "open('$TMP/so_magic.bin','wb').write(bytes(65536+1372)+b'\x19\x01\x54\x19'+bytes(10000))"
espera "$TMP/so_magic.bin" sce_sys/param.json -3   # magic certo, campos invalidos
espera "$TMP/nao_existe.ffpkg" sce_sys/param.json -2

echo
if [ $FALHAS -eq 0 ]; then echo "TODOS OS TESTES PASSARAM"; else echo "$FALHAS FALHA(S)"; exit 1; fi
