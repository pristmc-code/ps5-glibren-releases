#!/bin/bash
# Testa o relogio do PS5 pela internet na versao de PC (o relogio do WSL NAO muda: o do "PS5" e simulado).
# Dois servidores NTP de mentira e um HTTP de mentira dizem a hora real + o desvio escrito em $T/ntp1, $T/ntp2, $T/http
# (numero de segundos, "absurdo" = ano 1990, "mudo" = nao responde).
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_relogio.sh
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8793; P_NTP1=12391; P_NTP2=12392; P_HTTP=12393
U="http://127.0.0.1:$PORTA"
T=$(mktemp -d /tmp/glr-rel.XXXXXX); DADOS="$T/dados"
ok=0; falhou=0
confere() { if echo "$2" | grep -q -- "$3"; then echo "OK   $1"; ok=$((ok+1)); else echo "FALHOU $1 -> $2"; falhou=$((falhou+1)); fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then echo "FALHOU $1 -> $2"; falhou=$((falhou+1)); else echo "OK   $1"; ok=$((ok+1)); fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
campo() { python3 -c "import json,sys; d=json.load(sys.stdin)['relogio']; print($1)"; }
desvios() { echo "$1" > $T/ntp1; echo "$2" > $T/ntp2; echo "$3" > $T/http; }

python3 -I - $P_NTP1 $P_NTP2 $P_HTTP "$T" > /dev/null 2>&1 <<'EOF' &
import socket, struct, sys, threading, time, email.utils, http.server
p1, p2, ph, pasta = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
def desvio(nome):
    try: return open(pasta + "/" + nome).read().strip()
    except OSError: return "0"
def ntp(porta, nome):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.bind(("127.0.0.1", porta))
    while True:
        d, a = s.recvfrom(64)
        v = desvio(nome)
        if v == "mudo": continue
        agora = (631152000.0 if v == "absurdo" else time.time() + float(v)) + 2208988800
        ts = struct.pack("!II", int(agora) & 0xffffffff, int((agora % 1) * 2**32))
        s.sendto(bytes([0x24, 2, 6, 0xec]) + b"\0" * 20 + d[40:48] + ts + ts, a)
for porta, nome in ((p1, "ntp1"), (p2, "ntp2")):
    threading.Thread(target=ntp, args=(porta, nome), daemon=True).start()
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        v = desvio("http")
        if v == "mudo": self.close_connection = True; return
        t = 631152000.0 if v == "absurdo" else time.time() + float(v)
        self.send_response_only(200); self.send_header("Date", email.utils.formatdate(t, usegmt=True))
        self.send_header("Content-Length", "0"); self.end_headers()
    def log_message(self, *a): pass
http.server.ThreadingHTTPServer(("127.0.0.1", ph), H).serve_forever()
EOF
PID_SRV=$!
sleep 1

iniciar() {
  GLR_TESTE_RELOGIO_NTP="127.0.0.1:$P_NTP1,127.0.0.1:$P_NTP2" GLR_TESTE_RELOGIO_HTTP="http://127.0.0.1:$P_HTTP/" \
    GLR_TESTE_RELOGIO_ESPERA=1 GLR_TESTE_RELOGIO_DESVIO="${1:-0}" "$BIN" -p $PORTA -d "$DADOS" > $T/glr.log 2>&1 &
  PID=$!
  for i in $(seq 1 40); do curl -s $U/api/relogio > /dev/null && break; sleep 0.25; done
}
espera_conferir() { for i in $(seq 1 40); do q=$(curl -s $U/api/relogio | campo "d['quando']" 2>/dev/null); [ -n "$q" ] && [ "$q" != "0" ] && return; sleep 0.25; done; }
parar() { post -X POST $U/api/sair > /dev/null; wait $PID 2>/dev/null; }

echo "--- relogio certo ao iniciar"
desvios 0 0 0
iniciar 0
espera_conferir
R=$(curl -s $U/api/relogio)
confere "situacao certo"                 "$(echo "$R" | campo "d['situacao']")" "^certo$"
confere "tres fontes concordam"          "$(echo "$R" | campo "sum(f['concorda'] for f in d['fontes'])")" "^3$"
confere "automatico ligado"              "$(echo "$R" | campo "d['auto']")" "^True$"
confere "fuso informado"                 "$(echo "$R" | campo "d['fuso_min']")" "^-\?[0-9]"
confere "nenhum acerto"                  "$(echo "$R" | campo "d['ajustes']")" "^0$"

echo "--- PS5 atrasado 2 min: acerta"
desvios 120 120 120
R=$(post -X POST $U/api/relogio/conferir)
confere "ajustado"                       "$(echo "$R" | campo "d['situacao']")" "^ajustado$"
confere "diferenca -120 s"               "$(echo "$R" | campo "round(d['diferenca'])")" "^-120$"
confere "um acerto"                      "$(echo "$R" | campo "d['ajustes']")" "^1$"
confere "acerto no diario"               "$(grep 'relogio: acertado' $DADOS/glibren.log)" "estava 2 min atrasado"
R=$(post -X POST $U/api/relogio/conferir)
confere "depois do acerto: certo"        "$(echo "$R" | campo "d['situacao']")" "^certo$"

echo "--- abaixo do limite (20 s): nao mexe"
desvios 140 140 140
R=$(post -X POST $U/api/relogio/conferir)
confere "20 s: certo"                    "$(echo "$R" | campo "d['situacao']")" "^certo$"
confere "20 s: continua 1 acerto"        "$(echo "$R" | campo "d['ajustes']")" "^1$"
confere "20 s: diferenca informada"      "$(echo "$R" | campo "round(d['diferenca'])")" "^-20$"

echo "--- fontes discordando: nao mexe"
desvios 120 3720 7320
R=$(post -X POST $U/api/relogio/conferir)
confere "discordam"                      "$(echo "$R" | campo "d['situacao']")" "^fontes_discordam$"
confere "discordam: continua 1 acerto"   "$(echo "$R" | campo "d['ajustes']")" "^1$"
desvios 620 3720 7320
R=$(post -X POST $U/api/relogio/conferir)
confere "discordam (todas longe): nao acerta" "$(echo "$R" | campo "d['situacao']+' '+str(d['ajustes'])")" "^fontes_discordam 1$"

echo "--- maioria (2 de 3) com uma fora: acerta pela maioria"
desvios 620 620 9999
R=$(post -X POST $U/api/relogio/conferir)
confere "maioria: ajustado"              "$(echo "$R" | campo "d['situacao']")" "^ajustado$"
confere "maioria: 500 s"                 "$(echo "$R" | campo "round(d['diferenca'])")" "^-500$"
confere "a de fora marcada"              "$(echo "$R" | campo "[f['nome'] for f in d['fontes'] if f['ok'] and not f['concorda']]")" "teste HTTP"

echo "--- resposta absurda e fonte muda"
desvios absurdo 620 620
R=$(post -X POST $U/api/relogio/conferir)
confere "absurda ignorada: certo"        "$(echo "$R" | campo "d['situacao']")" "^certo$"
confere "absurda: erro informado"        "$(echo "$R" | campo "[f['erro'] for f in d['fontes'] if not f['ok']]")" "absurda"
desvios mudo mudo 2000
R=$(post -X POST $U/api/relogio/conferir)
confere "uma fonte so: nao acerta"       "$(echo "$R" | campo "d['situacao']+' '+str(d['ajustes'])")" "^poucas_fontes 2$"
desvios mudo mudo mudo
R=$(post -X POST $U/api/relogio/conferir)
confere "nenhuma fonte: sem internet"    "$(echo "$R" | campo "d['situacao']")" "^sem_internet$"
confere "falha no diario"                "$(grep -c 'relogio: sem_internet' $DADOS/glibren.log)" "^1$"
desvios absurdo absurdo absurdo
R=$(post -X POST $U/api/relogio/conferir)
confere "todas absurdas: nao acerta"     "$(echo "$R" | campo "d['situacao']+' '+str(d['ajustes'])")" "^sem_internet 2$"

echo "--- liga/desliga"
confere "sem X-GLR: 403"                 "$(curl -s -o /dev/null -w '%{http_code}' -d auto=0 $U/api/relogio)" "403"
confere "valor invalido: 400"            "$(post -s -o /dev/null -w '%{http_code}' -d auto=5 $U/api/relogio)" "400"
confere "desligar"                       "$(post -d auto=0 $U/api/relogio | campo "d['auto']")" "^False$"
confere "gravado no relogio.ini"         "$(cat $DADOS/relogio.ini)" "auto = off"
parar
desvios 3000 3000 3000
iniciar 0
sleep 3
R=$(curl -s $U/api/relogio)
confere "desligado depois de reabrir"    "$(echo "$R" | campo "d['auto']")" "^False$"
confere "desligado: nao conferiu sozinho" "$(echo "$R" | campo "d['situacao']")" "^nunca$"
confere "manual funciona desligado"      "$(post -X POST $U/api/relogio/conferir | campo "d['situacao']")" "^ajustado$"
confere "ligar de novo"                  "$(post -d auto=1 $U/api/relogio | campo "d['auto']")" "^True$"
parar

echo "--- PS5 adiantado 1 dia ao abrir (desvio simulado)"
desvios 0 0 0
iniciar 86400
espera_conferir
R=$(curl -s $U/api/relogio)
confere "1 dia adiantado: ajustado"      "$(echo "$R" | campo "d['situacao']+' '+str(round(d['diferenca']))")" "^ajustado 86400$"
confere "diario: 1 dia"                  "$(grep 'relogio: acertado' $DADOS/glibren.log | tail -1)" "1.0 h\|dias adiantado\|24.0 h adiantado"
parar

echo "--- fontes reais (internet: Cloudflare, NTP.br, Google, HTTPS)"
rm -rf "$DADOS"
GLR_TESTE_RELOGIO_ESPERA=1 "$BIN" -p $PORTA -d "$DADOS" > $T/glr.log 2>&1 &
PID=$!
for i in $(seq 1 120); do q=$(curl -s $U/api/relogio | campo "d['quando']" 2>/dev/null); [ -n "$q" ] && [ "$q" != "0" ] && break; sleep 0.5; done
R=$(curl -s $U/api/relogio)
confere "internet: relogio do PC certo"  "$(echo "$R" | campo "d['situacao']")" "^certo$"
confere "internet: 2+ fontes"            "$(echo "$R" | campo "sum(f['concorda'] for f in d['fontes']) >= 2")" "^True$"
echo "     fontes: $(echo "$R" | campo "'; '.join(f['nome']+(' %+.2f s' % f['diferenca'] if f['ok'] else ' '+f['erro']) for f in d['fontes'])")"
parar

kill $PID_SRV 2>/dev/null; wait $PID_SRV 2>/dev/null
rm -rf "$T"
echo "=== $ok ok, $falhou falharam"
[ $falhou -eq 0 ]
