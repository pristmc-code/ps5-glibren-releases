/* Teste do leitor exFAT (src/fmt_exfat.c).
   Uso: teste_exfat <imagem> <caminho> [max] [saida]
   Imprime "ret=<codigo> tam=<bytes> fnv=<hash>" e, se pedido, grava o conteudo lido em <saida>. */
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>

#include "imagem.h"

int main(int argc, char **argv) {
  if(argc < 3) {
    fprintf(stderr, "uso: %s imagem caminho [max] [saida]\n", argv[0]);
    return 2;
  }
  size_t max = argc > 3 ? (size_t)strtoull(argv[3], NULL, 10) : 64 * 1024 * 1024;
  int fd = open(argv[1], O_RDONLY);
  if(fd < 0) { perror("open"); return 2; }
  struct stat st;
  if(fstat(fd, &st)) { perror("fstat"); return 2; }
  dispositivo_t d;
  dispositivo_arquivo(&d, fd, (uint64_t)st.st_size);
  buf_t b = {0};
  int r = exfat_ler(&d, argv[2], &b, max);
  uint64_t h = 1469598103934665603ull;   /* FNV-1a 64 */
  for(size_t i = 0; i < b.n; i++) h = (h ^ (uint8_t)b.d[i]) * 1099511628211ull;
  printf("ret=%d tam=%zu fnv=%016llx\n", r, b.n, (unsigned long long)h);
  if(argc > 4) {
    FILE *f = fopen(argv[4], "wb");
    if(!f) { perror("fopen"); return 2; }
    if(b.n) fwrite(b.d, 1, b.n, f);
    fclose(f);
  }
  free(b.d);
  close(fd);
  return 0;
}
