#!/bin/bash
# Compila so fmt_pkg.c e fmt_param.c nos dois compiladores (PC e PS5), sem avisos.
set -e
cd "$(dirname "$0")/../.."
for f in fmt_pkg fmt_param; do
  clang-18 -Wall -Wextra -Werror -O2 -Isrc -c src/$f.c -o /tmp/${f}_pc.o
  /opt/ps5-payload-sdk/bin/prospero-clang -Wall -Wextra -Werror -O2 -Isrc -c src/$f.c -o /tmp/${f}_ps5.o
  echo "$f: ok (PC e PS5)"
done
