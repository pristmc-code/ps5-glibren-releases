/* Game Library Renamer (payload PS5) - testes de src/fmt_pkg.c e src/fmt_param.c (rodam no Linux/WSL).
   Uso: teste_fmt_pkg <pasta_gerada_pelo_gerar_pkg.sh> <pasta_dados> [param.json do SDK] [iteracoes_fuzz]
   Compilar com -fsanitize=address,undefined (ver teste_fmt_pkg.sh). */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "imagem.h"

static int g_falhas, g_testes;

#define CONFERE(cond, ...)                                  \
  do {                                                      \
    g_testes++;                                             \
    if(!(cond)) {                                           \
      g_falhas++;                                           \
      printf("FALHOU (linha %d): %s -- ", __LINE__, #cond); \
      printf(__VA_ARGS__);                                  \
      printf("\n");                                         \
    }                                                       \
  } while(0)

/* ---------- arquivos e dispositivo em memoria ---------- */

static unsigned char *ler_arquivo(const char *caminho, size_t *n) {
  FILE *f = fopen(caminho, "rb");
  if(!f) return NULL;
  fseek(f, 0, SEEK_END);
  long t = ftell(f);
  fseek(f, 0, SEEK_SET);
  unsigned char *d = malloc(t > 0 ? (size_t)t : 1);
  if(t > 0 && fread(d, 1, (size_t)t, f) != (size_t)t) {
    free(d);
    fclose(f);
    return NULL;
  }
  fclose(f);
  *n = (size_t)t;
  return d;
}

static unsigned char *ler_dados(const char *pasta, const char *nome, size_t *n) {
  char c[1024];
  snprintf(c, sizeof c, "%s/%s", pasta, nome);
  unsigned char *d = ler_arquivo(c, n);
  if(!d) {
    printf("ERRO: nao abriu %s\n", c);
    exit(2);
  }
  return d;
}

typedef struct {
  const unsigned char *d;
  size_t n;
} mem_t;

static int mem_ler(dispositivo_t *d, uint64_t off, void *buf, size_t n) {
  mem_t *m = d->ctx;
  if(off > m->n || n > m->n - off) return -1;   /* o dispositivo real tambem falha alem do fim */
  memcpy(buf, m->d + off, n);
  return 0;
}

static void dispositivo_mem(dispositivo_t *d, mem_t *m, const void *dados, size_t n) {
  m->d = dados;
  m->n = n;
  d->ler = mem_ler;
  d->fechar = NULL;
  d->tamanho = n;
  d->ctx = m;
}

static int pkg_mem(const void *dados, size_t n, uint32_t id, buf_t *saida, size_t max, char *cid) {
  dispositivo_t d;
  mem_t m;
  dispositivo_mem(&d, &m, dados, n);
  return pkg_ler(&d, id, saida, max, cid);
}

/* UTF-8 valido, terminado em \0 dentro de tam */
static int utf8_ok(const char *s, size_t tam) {
  const unsigned char *p = (const unsigned char *)s;
  if(!memchr(s, 0, tam)) return 0;
  while(*p) {
    int k = *p < 0x80 ? 1 : (*p & 0xE0) == 0xC0 ? 2 : (*p & 0xF0) == 0xE0 ? 3 : (*p & 0xF8) == 0xF0 ? 4 : 0;
    if(!k) return 0;
    for(int i = 1; i < k; i++)
      if((p[i] & 0xC0) != 0x80) return 0;
    p += k;
  }
  return 1;
}

static int info_ok(const info_jogo_t *i) {
  return utf8_ok(i->nome, sizeof i->nome) && memchr(i->title_id, 0, sizeof i->title_id) &&
         memchr(i->content_id, 0, sizeof i->content_id) && memchr(i->categoria, 0, sizeof i->categoria);
}

/* ---------- PKG ---------- */

static void w32be(unsigned char *p, uint32_t v) {
  p[0] = (unsigned char)(v >> 24);
  p[1] = (unsigned char)(v >> 16);
  p[2] = (unsigned char)(v >> 8);
  p[3] = (unsigned char)v;
}

static void w64le(unsigned char *p, uint64_t v) {
  for(int i = 0; i < 8; i++) p[i] = (unsigned char)(v >> (8 * i));
}

/* Envelope sintetico de PS5 (FIH ou LIH) com o CNT dentro, no deslocamento base. */
static unsigned char *envelope(const unsigned char *cnt, size_t n, int lih, size_t base, size_t *saida_n) {
  unsigned char *e = calloc(1, base + n);
  w32be(e, lih ? 0x7F4C4948u : 0x7F464948u);
  e[6] = lih ? 1 : 3;
  w64le(e + (lih ? 0x30 : 0x58), base);
  memcpy(e + base, cnt, n);
  *saida_n = base + n;
  return e;
}

/* CNT sintetico com uma entrada 0x2000 (param.json) e uma cifrada (0x1000) */
static unsigned char *cnt_sintetico(const unsigned char *json, size_t jn, size_t *saida_n) {
  size_t off_json = 0x1000, n = off_json + jn;
  unsigned char *c = calloc(1, n);
  w32be(c, 0x7F434E54u);
  w32be(c + 0x10, 2);
  w32be(c + 0x18, 0x200);
  memcpy(c + 0x40, "UP9000-PPSA01234_00-GLIBRENTESTE0002", 36);
  unsigned char *e = c + 0x200;
  w32be(e, 0x1000);
  w32be(e + 8, 0x80000000u);
  w32be(e + 0x10, 0x800);
  w32be(e + 0x14, 16);
  e += 32;
  w32be(e, 0x2000);
  w32be(e + 0x10, (uint32_t)off_json);
  w32be(e + 0x14, (uint32_t)jn);
  memcpy(c + off_json, json, jn);
  *saida_n = n;
  return c;
}

static void testar_pkg(const char *pasta, const char *dados) {
  char c[1024];
  size_t npkg, nsfo, npng;
  snprintf(c, sizeof c, "%s/UP9999-CUSA12345_00-GLIBRENTESTE0001.pkg", pasta);
  unsigned char *pkg = ler_arquivo(c, &npkg);
  if(!pkg) {
    printf("ERRO: sem %s (rode gerar_pkg.sh)\n", c);
    exit(2);
  }
  unsigned char *sfo = ler_dados(pasta, "proj/sce_sys/param.sfo", &nsfo);
  unsigned char *png = ler_dados(pasta, "proj/sce_sys/icon0.png", &npng);
  buf_t b = {0};
  char cid[48];
  int r;

  /* PKG real feito pelo PkgTool */
  r = pkg_mem(pkg, npkg, PKG_PARAM_SFO, &b, 1 << 20, cid);
  CONFERE(r == IMG_OK, "r=%d", r);
  CONFERE(strcmp(cid, "UP9999-CUSA12345_00-GLIBRENTESTE0001") == 0, "cid=%s", cid);
  /* o PkgBuilder reescreve o param.sfo (acrescenta chaves), entao confere o magic e o conteudo lido */
  CONFERE(b.n > 20 && memcmp(b.d, "\0PSF", 4) == 0, "param.sfo do pkg sem magic (%zu bytes)", b.n);
  size_t nsfo_pkg = b.n;
  info_jogo_t i;
  CONFERE(param_sfo_ler(b.d, b.n, "pt-BR", &i) == 0, "sfo do pkg");
  CONFERE(strcmp(i.nome, "Jogo de Teste – Edição Brasileira ☆") == 0, "nome=%s", i.nome);
  CONFERE(strcmp(i.title_id, "CUSA12345") == 0, "tid=%s", i.title_id);
  buf_free(&b);

  r = pkg_mem(pkg, npkg, PKG_ICON0, &b, 1 << 20, NULL);
  CONFERE(r == IMG_OK && b.n == npng && memcmp(b.d, png, npng) == 0, "icon0 r=%d n=%zu", r, b.n);
  buf_free(&b);

  r = pkg_mem(pkg, npkg, PKG_PARAM_JSON, &b, 1 << 20, cid);
  CONFERE(r == IMG_NAO_ACHOU && b.n == 0, "param.json num pkg de PS4: r=%d", r);
  CONFERE(cid[0] == 'U', "content_id preenchido mesmo sem a entrada");
  r = pkg_mem(pkg, npkg, 0x400, &b, 1 << 20, NULL);   /* license.dat: o PkgTool marca como cifrada */
  CONFERE(r == IMG_FORMATO && b.n == 0, "entrada cifrada: r=%d", r);
  r = pkg_mem(pkg, npkg, PKG_PARAM_SFO, &b, nsfo_pkg - 1, NULL);
  CONFERE(r == IMG_ERRO && b.n == 0, "maior que max: r=%d", r);
  r = pkg_mem(pkg, npkg, PKG_PARAM_SFO, &b, nsfo_pkg, NULL);
  CONFERE(r == IMG_OK && b.n == nsfo_pkg, "igual a max: r=%d", r);
  buf_free(&b);
  r = pkg_mem(sfo, nsfo, PKG_PARAM_SFO, &b, 1 << 20, NULL);
  CONFERE(r == IMG_FORMATO, "nao e pkg: r=%d", r);
  r = pkg_mem(pkg, 3, PKG_PARAM_SFO, &b, 1 << 20, NULL);
  CONFERE(r == IMG_FORMATO, "3 bytes: r=%d", r);
  r = pkg_mem(pkg, 0x100, PKG_PARAM_SFO, &b, 1 << 20, NULL);
  CONFERE(r == IMG_ERRO, "so cabecalho: r=%d", r);
  r = pkg_mem(pkg, 0x3000, PKG_PARAM_SFO, &b, 1 << 20, NULL);
  CONFERE(r == IMG_ERRO && b.n == 0, "cortado no meio: r=%d", r);

  /* dados mantidos quando ja havia coisa no buf */
  buf_add(&b, "ABC", 3);
  r = pkg_mem(pkg, npkg, PKG_ICON0, &b, 1 << 20, NULL);
  CONFERE(r == IMG_OK && b.n == 3 + npng && memcmp(b.d, "ABC", 3) == 0, "acrescenta no fim");
  buf_free(&b);

  /* envelopes de PS5 */
  for(int lih = 0; lih < 2; lih++) {
    size_t ne;
    unsigned char *e = envelope(pkg, npkg, lih, 0x1000, &ne);
    r = pkg_mem(e, ne, PKG_PARAM_SFO, &b, 1 << 20, cid);
    CONFERE(r == IMG_OK && b.n == nsfo_pkg && param_sfo_ler(b.d, b.n, "pt-BR", &i) == 0 &&
              strcmp(i.title_id, "CUSA12345") == 0,
            "%s r=%d", lih ? "LIH" : "FIH", r);
    CONFERE(strcmp(cid, "UP9999-CUSA12345_00-GLIBRENTESTE0001") == 0, "cid envelope=%s", cid);
    buf_free(&b);
    e[6] = 2;   /* versao errada */
    r = pkg_mem(e, ne, PKG_PARAM_SFO, &b, 1 << 20, NULL);
    CONFERE(r == IMG_FORMATO, "versao de envelope desconhecida: r=%d", r);
    e[6] = lih ? 1 : 3;
    w64le(e + (lih ? 0x30 : 0x58), ne);   /* base no fim */
    r = pkg_mem(e, ne, PKG_PARAM_SFO, &b, 1 << 20, NULL);
    CONFERE(r == IMG_ERRO, "base fora: r=%d", r);
    w64le(e + (lih ? 0x30 : 0x58), 0x800);   /* base sem CNT */
    r = pkg_mem(e, ne, PKG_PARAM_SFO, &b, 1 << 20, NULL);
    CONFERE(r == IMG_ERRO, "base sem CNT: r=%d", r);
    free(e);
  }

  /* CNT sintetico com param.json (PS5) */
  size_t nj, nc;
  unsigned char *json = ler_dados(dados, "param_ptbr.json", &nj);
  unsigned char *cnt = cnt_sintetico(json, nj, &nc);
  size_t ne;
  unsigned char *e = envelope(cnt, nc, 0, 0x2000, &ne);
  r = pkg_mem(e, ne, PKG_PARAM_JSON, &b, 1 << 20, cid);
  CONFERE(r == IMG_OK && b.n == nj, "param.json no envelope r=%d", r);
  CONFERE(r == IMG_OK && param_json_ler(b.d, b.n, "pt-BR", &i) == 0 && strcmp(i.nome, "Jogo de Teste") == 0,
          "param.json do pkg");
  buf_free(&b);
  r = pkg_mem(e, ne, PKG_PARAM_SFO, &b, 1 << 20, NULL);
  CONFERE(r == IMG_FORMATO, "sfo cifrado no sintetico: r=%d", r);
  free(e);
  free(cnt);
  free(json);

  /* fuzz: mexe em bytes do comeco (cabecalho, tabela, sfo e icone) e no tamanho */
  free(sfo);
  free(png);
  srand(12345);
  int it = 5000;
  const char *ev = getenv("FUZZ");
  if(ev) it = atoi(ev);
  size_t zona = npkg < 0x10000 ? npkg : 0x10000;
  unsigned char *orig = malloc(zona);
  memcpy(orig, pkg, zona);
  int contagem[4] = {0};
  for(int k = 0; k < it; k++) {
    int mudancas = 1 + rand() % 8;
    for(int m = 0; m < mudancas; m++) {
      size_t pos = (rand() % 4 == 0) ? (size_t)(rand() % 0x200) : (size_t)rand() % zona;
      pkg[pos] = (unsigned char)rand();
    }
    size_t tam = (rand() % 5 == 0) ? (size_t)rand() % (npkg + 1) : npkg;
    uint32_t ids[] = {PKG_PARAM_SFO, PKG_ICON0, PKG_PARAM_JSON, 0x400};
    r = pkg_mem(pkg, tam, ids[rand() % 4], &b, (size_t)(rand() % 2 ? 1 << 20 : 64), cid);
    contagem[-r < 4 && r <= 0 ? -r : 3]++;
    CONFERE(r <= 0 && r >= -3, "retorno estranho %d", r);
    CONFERE(memchr(cid, 0, sizeof cid) != NULL, "cid sem \\0");
    if(r == IMG_OK && b.n) {
      param_sfo_ler(b.d, b.n, "pt-BR", &i);
      CONFERE(info_ok(&i), "info invalida no fuzz do pkg");
    }
    buf_free(&b);
    if(k % 50 == 49) memcpy(pkg, orig, zona);   /* volta ao original de tempos em tempos */
  }
  printf("fuzz pkg: %d iteracoes (ok=%d formato=%d nao_achou=%d erro=%d)\n", it, contagem[0], contagem[1], contagem[2],
         contagem[3]);
  free(orig);
  free(pkg);
}

/* ---------- param.sfo ---------- */

static void testar_sfo(const char *pasta) {
  size_t n, n2;
  unsigned char *sfo = ler_dados(pasta, "proj/sce_sys/param.sfo", &n);
  info_jogo_t i;
  CONFERE(param_sfo_ler(sfo, n, "pt-BR", &i) == 0, "sfo pt-BR");
  CONFERE(strcmp(i.nome, "Jogo de Teste – Edição Brasileira ☆") == 0, "nome=%s", i.nome);
  CONFERE(strcmp(i.title_id, "CUSA12345") == 0, "tid=%s", i.title_id);
  CONFERE(strcmp(i.content_id, "UP9999-CUSA12345_00-GLIBRENTESTE0001") == 0, "cid=%s", i.content_id);
  CONFERE(strcmp(i.categoria, "gd") == 0, "cat=%s", i.categoria);
  CONFERE(param_sfo_ler(sfo, n, "PT-br", &i) == 0 && strcmp(i.nome, "Jogo de Teste – Edição Brasileira ☆") == 0,
          "idioma sem diferenciar maiusculas");
  CONFERE(param_sfo_ler(sfo, n, "en-US", &i) == 0 && strcmp(i.nome, "Jogo de Teste: Edicao Padrao") == 0, "en-US=%s",
          i.nome);
  CONFERE(param_sfo_ler(sfo, n, "fr-FR", &i) == 0 && strcmp(i.nome, "Jeu de test") == 0, "fr=%s", i.nome);
  CONFERE(param_sfo_ler(sfo, n, "pt-PT", &i) == 0 && strcmp(i.nome, "Jogo de Teste: Edicao Padrao") == 0, "pt-PT=%s",
          i.nome);
  CONFERE(param_sfo_ler(sfo, n, NULL, &i) == 0 && strcmp(i.nome, "Jogo de Teste: Edicao Padrao") == 0, "NULL");
  CONFERE(param_sfo_ler(sfo, n, "xx-YY", &i) == 0 && strcmp(i.nome, "Jogo de Teste: Edicao Padrao") == 0, "xx");

  /* SCEC */
  unsigned char *scec = calloc(1, 0x800 + n);
  memcpy(scec, "SCEC", 4);
  memcpy(scec + 0x800, sfo, n);
  CONFERE(param_sfo_ler(scec, 0x800 + n, "pt-BR", &i) == 0 && strcmp(i.title_id, "CUSA12345") == 0, "SCEC");
  CONFERE(param_sfo_ler(scec, 0x700, "pt-BR", &i) != 0, "SCEC curto");
  free(scec);

  /* sem TITLE_ID: vem do CONTENT_ID */
  unsigned char *s2 = ler_dados(pasta, "sem_title_id.sfo", &n2);
  CONFERE(param_sfo_ler(s2, n2, "pt-BR", &i) == 0 && strcmp(i.title_id, "CUSA12345") == 0, "derivado tid=%s",
          i.title_id);
  free(s2);

  CONFERE(param_sfo_ler(sfo, 19, "pt-BR", &i) != 0, "curto");
  CONFERE(param_sfo_ler("\0PSX", 4, "pt-BR", &i) != 0, "magic");

  /* fuzz */
  unsigned char *m = malloc(n);
  int it = 20000, oks = 0;
  const char *ev = getenv("FUZZ");
  if(ev) it = atoi(ev) * 4;
  srand(777);
  for(int k = 0; k < it; k++) {
    memcpy(m, sfo, n);
    int mud = 1 + rand() % 10;
    for(int q = 0; q < mud; q++) {
      size_t pos = rand() % 3 ? (size_t)rand() % (n < 0x120 ? n : 0x120) : (size_t)rand() % n;
      m[pos] = (unsigned char)(rand() % 3 ? rand() : (rand() % 2 ? 0xFF : 0));
    }
    size_t t = rand() % 4 == 0 ? (size_t)rand() % (n + 1) : n;
    unsigned char *c = malloc(t ? t : 1);   /* copia exata: o ASan acusa leitura alem de t */
    memcpy(c, m, t);
    if(param_sfo_ler(c, t, rand() % 2 ? "pt-BR" : "fr-FR", &i) == 0) oks++;
    CONFERE(info_ok(&i), "info invalida no fuzz do sfo");
    free(c);
  }
  printf("fuzz sfo: %d iteracoes (%d aceitos)\n", it, oks);
  free(m);
  free(sfo);
}

/* ---------- param.json ---------- */

static int json_arq(const char *dados, const char *nome, const char *idioma, info_jogo_t *i) {
  size_t n;
  unsigned char *d = ler_dados(dados, nome, &n);
  int r = param_json_ler((const char *)d, n, idioma, i);
  free(d);
  return r;
}

static int json_txt(const char *s, const char *idioma, info_jogo_t *i) {
  size_t n = strlen(s);
  char *c = malloc(n ? n : 1);   /* sem \0 no fim: o leitor nao pode depender dele */
  memcpy(c, s, n);
  int r = param_json_ler(c, n, idioma, i);
  free(c);
  return r;
}

static void testar_json(const char *dados, const char *sdk) {
  info_jogo_t i;
  if(sdk) {
    size_t n;
    unsigned char *d = ler_arquivo(sdk, &n);
    if(d) {
      CONFERE(param_json_ler((const char *)d, n, "pt-BR", &i) == 0, "sdk");
      CONFERE(strcmp(i.title_id, "FAKE02932") == 0 && strcmp(i.nome, "FAKE02932") == 0, "sdk tid=%s nome=%s",
              i.title_id, i.nome);
      free(d);
    } else {
      printf("aviso: sem %s (pulei o param.json do SDK)\n", sdk);
    }
  }
  CONFERE(json_arq(dados, "param_ptbr.json", "pt-BR", &i) == 0 && strcmp(i.nome, "Jogo de Teste") == 0, "pt-BR=%s",
          i.nome);
  CONFERE(strcmp(i.title_id, "PPSA01234") == 0 && strcmp(i.content_id, "UP9000-PPSA01234_00-GLIBRENTESTE0002") == 0,
          "tid=%s cid=%s", i.title_id, i.content_id);
  CONFERE(i.categoria[0] == 0, "categoria vazia no json");
  CONFERE(json_arq(dados, "param_ptbr.json", "ja-JP", &i) == 0 && strcmp(i.nome, "テストゲーム") == 0, "ja=%s", i.nome);
  /* fr-FR existe mas sem titleName -> defaultLanguage (en-GB, que vem DEPOIS dos idiomas) */
  CONFERE(json_arq(dados, "param_ptbr.json", "fr-FR", &i) == 0 && strcmp(i.nome, "Test Game (UK)") == 0, "fr=%s",
          i.nome);
  CONFERE(json_arq(dados, "param_ptbr.json", NULL, &i) == 0 && strcmp(i.nome, "Test Game (UK)") == 0, "NULL=%s",
          i.nome);
  CONFERE(json_arq(dados, "param_escapes.json", "pt-BR", &i) == 0, "escapes");
  CONFERE(strcmp(i.title_id, "PPSA05678") == 0, "title_id=%s", i.title_id);
  CONFERE(strcmp(i.nome, "Café 😀 \"aspas\" a/b \\ x y z ção \xEF\xBF\xBD \xEF\xBF\xBD" "fim") == 0, "nome=[%s]",
          i.nome);
  CONFERE(json_arq(dados, "param_truncado.json", "pt-BR", &i) != 0 && i.nome[0] == 0, "truncado");
  CONFERE(json_arq(dados, "param_virgula.json", "pt-BR", &i) != 0, "virgula sobrando");
  CONFERE(json_arq(dados, "param_controle.json", "pt-BR", &i) != 0, "tab cru em string");
  CONFERE(json_arq(dados, "param_lixo.json", "pt-BR", &i) != 0, "lixo no fim");
  CONFERE(json_arq(dados, "param_raiz.json", "pt-BR", &i) == 0 && strcmp(i.nome, "Nome na raiz") == 0 &&
            strcmp(i.title_id, "PPSA09999") == 0,
          "raiz nome=%s tid=%s", i.nome, i.title_id);
  CONFERE(json_arq(dados, "param_qualquer.json", "pt-BR", &i) == 0 && strcmp(i.nome, "Juego") == 0, "qualquer=%s",
          i.nome);
  CONFERE(json_txt("{\"titleId\":\"PPSA01234\",\"localizedParameters\":{\"pt-BR\":{\"titleName\":\"A\"},"
                   "\"en-US\":{\"titleName\":\"B\"}}}",
                   "es-ES", &i) == 0 &&
            strcmp(i.nome, "B") == 0,
          "en-US antes de qualquer: %s", i.nome);
  CONFERE(json_txt("\xEF\xBB\xBF{\"titleId\":\"PPSA01234\"}\n\0\0", NULL, &i) == 0, "BOM e NUL no fim");
  CONFERE(json_txt("", NULL, &i) != 0, "vazio");
  CONFERE(json_txt("[]", NULL, &i) != 0, "array na raiz");
  CONFERE(json_txt("{}", NULL, &i) != 0, "objeto vazio (sem nada util)");
  CONFERE(json_txt("{\"titleId\":\"PPSA0123\"}", NULL, &i) != 0 && i.title_id[0] == 0, "tid curto");
  CONFERE(json_txt("{\"titleId\":\"PPSA01234\",\"x\":\"\\ud83d\"}", NULL, &i) == 0, "substituto alto no fim");
  CONFERE(json_txt("{\"titleId\":\"PPSA01234\",\"x\":\"\\u12\"}", NULL, &i) != 0, "\\u curto");
  CONFERE(json_txt("{\"titleId\":\"PPSA01234\",\"x\":\"\\q\"}", NULL, &i) != 0, "escape invalido");
  CONFERE(json_txt("{\"titleId\":\"PPSA01234\",\"x\":01x}", NULL, &i) != 0, "numero ruim");
  CONFERE(json_txt("{\"titleId\":\"PPSA01234\",\"x\":tru}", NULL, &i) != 0, "literal ruim");
  /* UTF-8 invalido na entrada vira U+FFFD */
  CONFERE(json_txt("{\"titleId\":\"PPSA01234\",\"titleName\":\"a\xC3\x28\xF0\x9F\x98\"}", NULL, &i) == 0 &&
            utf8_ok(i.nome, sizeof i.nome) && strcmp(i.nome, "a\xEF\xBF\xBD(\xEF\xBF\xBD\xEF\xBF\xBD\xEF\xBF\xBD") == 0,
          "utf8 invalido: [%s]", i.nome);

  /* profundidade */
  {
    char *p = malloc(200000);
    size_t k = 0;
    k += (size_t)sprintf(p, "{\"titleId\":\"PPSA01234\",\"x\":");
    for(int q = 0; q < 50000; q++) p[k++] = '[';
    for(int q = 0; q < 50000; q++) p[k++] = ']';
    p[k++] = '}';
    p[k] = 0;
    CONFERE(param_json_ler(p, k, NULL, &i) != 0, "50000 colchetes (limite de profundidade)");
    k = (size_t)sprintf(p, "{\"titleId\":\"PPSA01234\",\"x\":");
    for(int q = 0; q < 20; q++) p[k++] = '[';
    for(int q = 0; q < 20; q++) p[k++] = ']';
    p[k++] = '}';
    CONFERE(param_json_ler(p, k, NULL, &i) == 0, "20 colchetes ok");
    free(p);
  }

  /* truncamento seguro do nome */
  {
    const char *pedacos[] = {"é", "😀", "a", "ção"};
    for(int q = 0; q < 4; q++) {
      char *p = malloc(10000);
      size_t k = (size_t)sprintf(p, "{\"titleId\":\"PPSA01234\",\"titleName\":\"");
      for(int r = 0; r < 300; r++) k += (size_t)sprintf(p + k, "%s", pedacos[q]);
      k += (size_t)sprintf(p + k, "\"}");
      CONFERE(param_json_ler(p, k, NULL, &i) == 0 && utf8_ok(i.nome, sizeof i.nome) && strlen(i.nome) >= 252 &&
                strlen(i.nome) <= 255,
              "truncamento %s: len=%zu", pedacos[q], strlen(i.nome));
      free(p);
    }
  }

  /* fuzz: mutacoes e truncamentos do json completo */
  size_t n;
  unsigned char *base = ler_dados(dados, "param_ptbr.json", &n);
  unsigned char *esc = NULL;
  size_t nesc;
  esc = ler_dados(dados, "param_escapes.json", &nesc);
  const char simbolos[] = "{}[]\",:\\u0123456789abcdefABCDEF \t\n-+.eE";
  int it = 20000, oks = 0;
  const char *ev = getenv("FUZZ");
  if(ev) it = atoi(ev) * 4;
  srand(4242);
  for(int k = 0; k < it; k++) {
    const unsigned char *src = k % 2 ? base : esc;
    size_t ns = k % 2 ? n : nesc;
    size_t t = rand() % 3 == 0 ? (size_t)rand() % (ns + 1) : ns;
    unsigned char *c = malloc(t ? t : 1);
    memcpy(c, src, t);
    int mud = rand() % 6;
    for(int q = 0; q < mud && t; q++) {
      size_t pos = (size_t)rand() % t;
      c[pos] = rand() % 2 ? (unsigned char)simbolos[rand() % (sizeof simbolos - 1)] : (unsigned char)rand();
    }
    if(param_json_ler((const char *)c, t, rand() % 2 ? "pt-BR" : "en-US", &i) == 0) oks++;
    CONFERE(info_ok(&i), "info invalida no fuzz do json");
    free(c);
  }
  printf("fuzz json: %d iteracoes (%d aceitos)\n", it, oks);
  /* bytes totalmente aleatorios */
  for(int k = 0; k < it / 4; k++) {
    size_t t = (size_t)rand() % 512;
    unsigned char *c = malloc(t ? t : 1);
    for(size_t q = 0; q < t; q++) c[q] = rand() % 2 ? (unsigned char)simbolos[rand() % (sizeof simbolos - 1)] : (unsigned char)rand();
    if(t) c[0] = '{';
    param_json_ler((const char *)c, t, "pt-BR", &i);
    CONFERE(info_ok(&i), "info invalida no fuzz aleatorio do json");
    param_sfo_ler(c, t, "pt-BR", &i);
    CONFERE(info_ok(&i), "info invalida no fuzz aleatorio do sfo");
    free(c);
  }
  free(base);
  free(esc);
}

int main(int argc, char **argv) {
  if(argc < 3) {
    printf("uso: %s <pasta_gerada> <pasta_dados> [param.json do SDK]\n", argv[0]);
    return 2;
  }
  testar_sfo(argv[1]);
  testar_json(argv[2], argc > 3 ? argv[3] : NULL);
  testar_pkg(argv[1], argv[2]);
  printf("%d verificacoes, %d falhas\n", g_testes, g_falhas);
  return g_falhas ? 1 : 0;
}
