#!/bin/bash
# Gera um param.sfo e um fake PKG de PS4 REAIS com o LibOrbisPkg (PkgTool.Core, .NET 8).
# Uso: gerar_pkg.sh <pasta_saida>   (precisa de: dotnet-sdk-8.0, git, python3)
# Saida: <pasta>/proj/sce_sys/param.sfo, <pasta>/proj/sce_sys/icon0.png, <pasta>/UP9999-CUSA12345_00-GLIBRENTESTE0001.pkg
set -e
SAIDA=${1:-/tmp/glibren_pkg}
LIBORBIS=${LIBORBIS:-$HOME/liborbis}
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1
if [ ! -d "$LIBORBIS" ]; then git clone --depth 1 https://github.com/OpenOrbis/LibOrbisPkg "$LIBORBIS"; fi
DLL=$LIBORBIS/PkgTool.Core/bin/Release/net8.0/PkgTool.Core.dll
[ -f "$DLL" ] || dotnet build "$LIBORBIS/PkgTool.Core/PkgTool.Core.csproj" -c Release >/dev/null
pkgtool() { dotnet "$DLL" "$@"; }

CID=UP9999-CUSA12345_00-GLIBRENTESTE0001
rm -rf "$SAIDA"; mkdir -p "$SAIDA/proj/sce_sys"
SFO=$SAIDA/proj/sce_sys/param.sfo
pkgtool sfo_new "$SFO"
pkgtool sfo_setentry "$SFO" APP_TYPE --type int --value 1 >/dev/null
pkgtool sfo_setentry "$SFO" APP_VER --type utf8 --maxsize 8 --value 01.00 >/dev/null
pkgtool sfo_setentry "$SFO" ATTRIBUTE --type int --value 0 >/dev/null
pkgtool sfo_setentry "$SFO" CATEGORY --type utf8 --maxsize 4 --value gd >/dev/null
pkgtool sfo_setentry "$SFO" CONTENT_ID --type utf8 --maxsize 48 --value $CID >/dev/null
pkgtool sfo_setentry "$SFO" DOWNLOAD_DATA_SIZE --type int --value 0 >/dev/null
pkgtool sfo_setentry "$SFO" SYSTEM_VER --type int --value 0 >/dev/null
pkgtool sfo_setentry "$SFO" TITLE --type utf8 --maxsize 128 --value "Jogo de Teste: Edicao Padrao" >/dev/null
pkgtool sfo_setentry "$SFO" TITLE_17 --type utf8 --maxsize 128 --value "Jogo de Teste – Edição Brasileira ☆" >/dev/null
pkgtool sfo_setentry "$SFO" TITLE_02 --type utf8 --maxsize 128 --value "Jeu de test" >/dev/null
pkgtool sfo_setentry "$SFO" TITLE_ID --type utf8 --maxsize 12 --value CUSA12345 >/dev/null
pkgtool sfo_setentry "$SFO" VERSION --type utf8 --maxsize 8 --value 01.00 >/dev/null
# segundo sfo, sem TITLE_ID (o leitor deve tirar do CONTENT_ID)
cp "$SFO" "$SAIDA/sem_title_id.sfo"
# PkgTool nao apaga entrada; renomeia a chave para algo que o leitor ignora
pkgtool sfo_setentry "$SAIDA/sem_title_id.sfo" TITLE_ID --name XITLE_ID >/dev/null

# icon0.png pequeno (PNG valido 8x8)
python3 -I - "$SAIDA/proj/sce_sys/icon0.png" <<'PY'
import struct, sys, zlib
w = h = 8
raw = b"".join(b"\x00" + b"".join(bytes([x * 30, y * 30, 200]) for x in range(w)) for y in range(h))
def chunk(t, d): return struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(raw)) + chunk(b'IEND', b'')
open(sys.argv[1], 'wb').write(png)
PY
printf 'eboot de teste' > "$SAIDA/proj/eboot.bin"

cat > "$SAIDA/proj/projeto.gp4" <<XML
<?xml version="1.0"?>
<psproject fmt="gp4" version="1000">
  <volume>
    <volume_type>pkg_ps4_app</volume_type>
    <volume_id>PS4VOLUME</volume_id>
    <volume_ts>2026-11-04 12:00:00</volume_ts>
    <package content_id="$CID" passcode="00000000000000000000000000000000" storage_type="digital50" app_type="full" c_date="2026-11-04" />
    <chunk_info chunk_count="1" scenario_count="1">
      <chunks><chunk id="0" layer_no="0" label="Chunk #0" /></chunks>
      <scenarios default_id="0"><scenario id="0" type="sp" initial_chunk_count="1" label="Scenario #0">0</scenario></scenarios>
    </chunk_info>
  </volume>
  <files img_no="0">
    <file targ_path="sce_sys/param.sfo" orig_path="sce_sys/param.sfo" />
    <file targ_path="sce_sys/icon0.png" orig_path="sce_sys/icon0.png" />
    <file targ_path="eboot.bin" orig_path="eboot.bin" />
  </files>
  <rootdir>
    <dir targ_name="sce_sys" />
  </rootdir>
</psproject>
XML
pkgtool pkg_build "$SAIDA/proj/projeto.gp4" "$SAIDA"
ls -la "$SAIDA"
