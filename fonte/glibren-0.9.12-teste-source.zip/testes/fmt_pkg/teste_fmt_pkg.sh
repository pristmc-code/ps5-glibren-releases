#!/bin/bash
# Testes do leitor de .pkg e dos leitores de param.json/param.sfo (rodar no WSL/Linux).
#   1. compila src/fmt_pkg.c e src/fmt_param.c para PC e PS5 sem avisos
#   2. gera param.sfo e fake PKG reais com o LibOrbisPkg (gerar_pkg.sh)
#   3. roda teste_fmt_pkg com -fsanitize=address,undefined (FUZZ=N muda as iteracoes; padrao 5000)
set -e
AQUI=$(cd "$(dirname "$0")" && pwd)
RAIZ=$(cd "$AQUI/../.." && pwd)
GERADO=${GERADO:-/tmp/glibren_pkg}
bash "$AQUI/compilar_fontes.sh"
[ -f "$GERADO/UP9999-CUSA12345_00-GLIBRENTESTE0001.pkg" ] || bash "$AQUI/gerar_pkg.sh" "$GERADO"
clang-18 -std=c11 -D_DEFAULT_SOURCE -Wall -Wextra -Werror -g -O1 -fsanitize=address,undefined -fno-sanitize-recover=all \
  -I"$RAIZ/src" "$AQUI/teste_fmt_pkg.c" "$RAIZ/src/fmt_pkg.c" "$RAIZ/src/fmt_param.c" "$RAIZ/src/util.c" \
  -o /tmp/teste_fmt_pkg
SDK=/opt/ps5-payload-sdk/samples/install_app/FAKE02932/sce_sys/param.json
/tmp/teste_fmt_pkg "$GERADO" "$AQUI/dados" "$SDK"
