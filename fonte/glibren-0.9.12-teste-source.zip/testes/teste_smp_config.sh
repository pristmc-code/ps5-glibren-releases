#!/bin/bash
# Testa a leitura da porta/IP da API do ShadowMountPlus no config.ini dele (formato v1 e v2), com sanitizers.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_smp_config.sh
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
T=$(mktemp -d /tmp/glr-smp.XXXXXX)
trap 'rm -rf "$T"' EXIT
cat > "$T/t.c" <<'C'
#include <stdio.h>
#include "smp_config.h"
int main(int argc, char **argv) {
  FILE *f = fopen(argv[1], "r");
  int porta = 10101;
  char ip[64] = "";
  if(f) { smp_config_ler(f, &porta, ip, sizeof ip); fclose(f); }
  printf("%d %s\n", porta, ip[0] ? ip : "-");
  return 0;
}
C
clang-18 -Wall -Werror -g -O1 -fsanitize=address,undefined -fno-sanitize-recover=all -I"$RAIZ/src" "$T/t.c" "$RAIZ/src/smp_config.c" -o "$T/t" || { echo "nao compilou"; exit 1; }
ok=0; falhou=0
confere() { if [ "$2" = "$3" ]; then echo "OK   $1"; ok=$((ok+1)); else echo "FALHOU $1 -> [$2] (esperado [$3])"; falhou=$((falhou+1)); fi; }
ler() { printf '%b' "$1" > "$T/c.ini"; "$T/t" "$T/c.ini"; }

confere "sem arquivo: padrao"            "$("$T/t" "$T/nao-existe")" "10101 -"
confere "v1: api_port"                   "$(ler 'scanpath=/data/homebrew\napi_port=12000\n')" "12000 -"
confere "v1: com espacos e bind"         "$(ler 'api_port = 12001\napi_bind_address = 192.168.0.10\n')" "12001 192.168.0.10"
confere "v2: [api] port e bind_address"  "$(ler '[config]\nversion = 2\n\n[api]\n# enabled = on\nbind_address = 127.0.0.1\nport = 12002\n')" "12002 127.0.0.1"
confere "v2: comentado nao vale"         "$(ler '[api]\n# port = 12003\n')" "10101 -"
confere "v2: port fora de [api] ignorado" "$(ler '[scan]\nport = 12004\n[smb:NAS]\nport = 445\n')" "10101 -"
confere "v2: [api] depois de outra secao" "$(ler '[general]\nport = 1\n[api]\nport = 12005\n[mount]\nport = 2\n')" "12005 -"
confere "v2: CRLF e comentario no fim"   "$(ler '[API]\r\nport = 12006 ; minha porta\r\n')" "12006 -"
confere "v2: valor entre aspas"          "$(ler '[api]\nbind_address = "10.0.0.5"\n')" "10101 10.0.0.5"
confere "porta invalida ignorada"        "$(ler '[api]\nport = 99999\nport = abc\n')" "10101 -"
confere "IP invalido ignorado"           "$(ler '[api]\nbind_address = 300.1.1.1\n')" "10101 -"
confere "0.0.0.0 lido (quem chama ignora)" "$(ler '[api]\nbind_address = 0.0.0.0\n')" "10101 0.0.0.0"
confere "api_port_x nao confunde"        "$(ler 'api_port_x = 5\n')" "10101 -"
echo "=== $ok ok, $falhou falharam"
[ $falhou -eq 0 ]
