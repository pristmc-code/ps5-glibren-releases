#!/bin/bash
# Sobe a versao de PC do payload no WSL com pastas de PS5 de mentira, para ver a tela no navegador do Windows
# (http://localhost:8765). Arquivos esparsos: nao ocupam disco.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/demo.sh        (para: ... demo.sh parar)
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
pkill -f "glr-pc -p" 2>/dev/null; pkill -f glibren-pc 2>/dev/null
sleep 1
[ "$1" = "parar" ] && exit 0

# As tres pastas ficam na memoria (tmpfs, 4 GB cada, como se fossem discos diferentes): os jogos grandes sao
# esparsos (nao ocupam nada) e copiar um deles da "sem espaco no destino" em vez de gravar no disco do PC.
for d in /data/homebrew /mnt/ext1/homebrew /mnt/usb0; do
  umount "$d" 2>/dev/null; rm -rf "$d"; mkdir -p "$d" && mount -t tmpfs -o size=4G tmpfs "$d"
done
mkdir -p /mnt/usb0/jogos
G=$((1024*1024*1024)); M=$((1024*1024))
truncate -s $((97*G))  "/data/homebrew/PPSA08329-app.pkg"
truncate -s $((38*G))  "/data/homebrew/CUSA07408 God of War.pkg"
truncate -s $((99*G))  "/data/homebrew/CUSA03041_RDR2.pkg"
truncate -s $((41*G))  "/data/homebrew/PPSA01417-app.ffpkg"
truncate -s $((33*G))  "/data/homebrew/Returnal PPSA01284.exfat.complete"   # marca de download terminado: extensao dupla
truncate -s $((12*G))  "/data/homebrew/PPSA01453-blackbox.exfat.part"
truncate -s $((812*M)) "/data/homebrew/God_of_War_Ragnarok-PPSA08329-patch-1.05.pkg"
truncate -s $((3*G))   "/data/homebrew/PPSA02343.zip"
truncate -s $((49*G))  "/mnt/ext1/homebrew/PPSA04609-elden.exfat"
truncate -s $((78*G))  "/mnt/ext1/homebrew/The_Last_of_Us_Part_II-CUSA10249-EU-PS4.pkg"
truncate -s $((64*G))  "/mnt/ext1/homebrew/CUSA00419.pkg"
truncate -s $((20*G))  "/mnt/ext1/homebrew/PPSA03524-gta.ffpkg"
# pequenos (de verdade) para testar copiar/mover para /mnt/usb0 sem ocupar disco
truncate -s $((1500*M)) "/data/homebrew/PPSA01476-gt7.pkg"
truncate -s $((900*M))  "/data/homebrew/CUSA00900-bloodborne.pkg"
truncate -s $((600*M))  "/data/homebrew/PPSA02343-astro.pkg"
truncate -s $((500*M))  "/data/homebrew/CUSA00552-tlou-remastered.pkg"

cp "$ORIGEM/saida/glibren-pc" /root/glr-pc
cd /root
GLR_DEMO_MBPS=${GLR_DEMO_MBPS:-120} nohup /root/glr-pc -p 8765 -d /root/glr-dados > /tmp/glr-demo.log 2>&1 &
sleep 1
cat /tmp/glr-demo.log
