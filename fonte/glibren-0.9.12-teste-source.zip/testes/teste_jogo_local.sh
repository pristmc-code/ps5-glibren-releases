#!/bin/bash
# Teste de ponta a ponta da leitura local (nome, codigo e icone de dentro do arquivo do jogo, sem internet):
# cria um jogo de mentira em .exfat, .ffpkg (UFS2) e .pkg (PS4), poe numa pasta da demo com nomes SEM o codigo
# e confere a resposta de /api/local e o icone guardado.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_jogo_local.sh      (com a demo rodando: testes/demo.sh)
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
T=$(mktemp -d /tmp/jogo_local.XXXXXX)
trap 'umount "$T/mnt" 2>/dev/null; rm -rf "$T"' EXIT
PASTA=/data/homebrew
URL=http://127.0.0.1:8765
ok=0; falhas=0
confere() { if [ "$2" = "$3" ]; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: esperado [$3], veio [$2]"; fi; }

# arvore do jogo (PS5): param.json com pt-BR e en-US + icone PNG de verdade
mkdir -p "$T/jogo/sce_sys"
cp "$ORIGEM/instalador/icon0.png" "$T/jogo/sce_sys/icon0.png"
cat > "$T/jogo/sce_sys/param.json" <<'EOF'
{"titleId":"PPSA01325","contentId":"UP9000-PPSA01325_00-ASTROSPLAYROOM00",
 "localizedParameters":{"defaultLanguage":"en-US","en-US":{"titleName":"ASTRO's PLAYROOM"},"pt-BR":{"titleName":"Sala de Jogos do ASTRO"}}}
EOF
dd if=/dev/urandom of="$T/jogo/eboot.bin" bs=1M count=3 status=none

# .exfat (como o mkexfat.sh do ShadowMountPlus)
truncate -s 64M "$T/a.exfat"; mkfs.exfat -c 64K "$T/a.exfat" >/dev/null
mkdir -p "$T/mnt"; mount -o loop "$T/a.exfat" "$T/mnt" && cp -r "$T/jogo/." "$T/mnt/" && umount "$T/mnt"
# .ffpkg (UFS2, blocos de 64K como o mkufs2.sh)
sed -i 's/PPSA01325/PPSA01326/; s/UP9000-PPSA01325/EP9000-PPSA01326/' "$T/jogo/sce_sys/param.json"
makefs -t ffs -B le -s 64m -o version=2,bsize=65536,fsize=65536,minfree=0 "$T/b.ffpkg" "$T/jogo" >/dev/null

# .ffpfs (PFS sem compressao) e .ffpfsc (exFAT comprimido dentro de um PFS) com o MkPFS, se instalado
MKPFS=${MKPFS:-/root/venv-mkpfs/bin/mkpfs}
sed -i 's/PPSA01326/PPSA01327/; s/EP9000-PPSA01326/JP9000-PPSA01327/' "$T/jogo/sce_sys/param.json"
[ -x "$MKPFS" ] && "$MKPFS" pack folder --raw --no-compress --version PS5 --inode-bits 32 "$T/jogo" "$T/c.ffpfs" >/dev/null 2>&1
sed -i 's/PPSA01327/PPSA01328/; s/JP9000-PPSA01327/HP9000-PPSA01328/' "$T/jogo/sce_sys/param.json"
[ -x "$MKPFS" ] && "$MKPFS" pack folder "$T/jogo" "$T/d.ffpfsc" >/dev/null 2>&1

rm -f "$PASTA"/teste_local_*
[ -f "$T/c.ffpfs" ] && cp "$T/c.ffpfs" "$PASTA/teste_local_quatro.ffpfs"
D=$(ls "$T"/d*.ffpfsc 2>/dev/null | head -1); [ -n "$D" ] && cp "$D" "$PASTA/teste_local_cinco.ffpfsc"
cp "$T/a.exfat" "$PASTA/teste_local_um.exfat"
cp "$T/b.ffpkg" "$PASTA/teste_local_dois.ffpkg"
PKG=$(ls /tmp/glibren_pkg/*.pkg 2>/dev/null | head -1)
[ -n "$PKG" ] && cp "$PKG" "$PASTA/teste_local_tres.pkg"
head -c 100000 /dev/urandom > "$PASTA/teste_local_lixo.exfat"
rm -f /root/glr-dados/icones/PPSA01325.* /root/glr-dados/icones/PPSA01326.* /root/glr-dados/icones/CUSA12345.*

campo() { python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('$1',''))"; }
pede() { curl -s "$URL/api/local?pasta=$(python3 -c 'import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1]))' "$PASTA")&nome=$1"; }

r=$(pede teste_local_um.exfat)
confere "exfat: codigo" "$(echo "$r" | campo title_id)" "PPSA01325"
confere "exfat: nome (en-US)" "$(echo "$r" | campo nome)" "ASTRO's PLAYROOM"
confere "exfat: formato" "$(echo "$r" | campo formato)" "exfat"
confere "exfat: icone" "$(echo "$r" | campo icone)" "True"
confere "exfat: icone igual" "$(cmp -s /root/glr-dados/icones/PPSA01325.png "$ORIGEM/instalador/icon0.png" && echo sim)" "sim"
confere "icone servido por /icone/" "$(curl -s -o /dev/null -w '%{http_code} %{content_type}' $URL/icone/PPSA01325)" "200 image/png"

r=$(pede teste_local_dois.ffpkg)
confere "ufs2: codigo" "$(echo "$r" | campo title_id)" "PPSA01326"
confere "ufs2: formato" "$(echo "$r" | campo formato)" "ufs2"
confere "ufs2: content_id" "$(echo "$r" | campo content_id)" "EP9000-PPSA01326_00-ASTROSPLAYROOM00"

if [ -n "$PKG" ]; then
  r=$(pede teste_local_tres.pkg)
  confere "pkg: codigo" "$(echo "$r" | campo title_id)" "CUSA12345"
  confere "pkg: formato" "$(echo "$r" | campo formato)" "pkg"
  confere "pkg: icone" "$(echo "$r" | campo icone)" "True"
fi

if [ -f "$PASTA/teste_local_quatro.ffpfs" ]; then
  r=$(pede teste_local_quatro.ffpfs)
  confere "pfs: codigo" "$(echo "$r" | campo title_id)" "PPSA01327"
  confere "pfs: formato" "$(echo "$r" | campo formato)" "pfs"
else echo "AVISO: sem MkPFS, .ffpfs nao testado"; fi
if [ -f "$PASTA/teste_local_cinco.ffpfsc" ]; then
  r=$(pede teste_local_cinco.ffpfsc)
  confere "ffpfsc: codigo" "$(echo "$r" | campo title_id)" "PPSA01328"
  confere "ffpfsc: formato" "$(echo "$r" | campo formato)" "exfat+c"
  confere "ffpfsc: icone" "$(echo "$r" | campo icone)" "True"
else echo "AVISO: sem MkPFS, .ffpfsc nao testado"; fi

confere "lixo: nao achou" "$(pede teste_local_lixo.exfat | campo achou)" "False"
confere "fora das pastas: recusado" "$(curl -s -o /dev/null -w '%{http_code}' "$URL/api/local?pasta=/etc&nome=passwd")" "400"
confere "caminho com ..: recusado" "$(curl -s -o /dev/null -w '%{http_code}' "$URL/api/local?pasta=$PASTA&nome=..")" "400"
# segunda vez: vem da memoria (rapido)
ini=$(date +%s%N); pede teste_local_dois.ffpkg >/dev/null; dur=$(( ($(date +%s%N)-ini)/1000000 ))
confere "segunda leitura rapida (<200 ms)" "$([ $dur -lt 200 ] && echo sim || echo "$dur ms")" "sim"

echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
