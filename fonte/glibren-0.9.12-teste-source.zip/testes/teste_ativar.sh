#!/bin/bash
# Testa o ATIVAR (POST /api/ativar): copia sozinho um jogo "so armazenado" para a pasta do ShadowMount com mais espaco.
# Usa discos de mentira em tmpfs (tamanho limitado, sem ocupar o disco do PC).
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_ativar.sh
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
DADOS=/root/glr-dados-ativar
PORTA=8798
U="http://127.0.0.1:$PORTA"
ok=0; falhou=0
confere() { if echo "$2" | grep -q -- "$3"; then echo "OK   $1"; ok=$((ok+1)); else echo "FALHOU $1 -> $2"; falhou=$((falhou+1)); fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
ativar() { post --data-urlencode "pasta=$1" --data-urlencode "nome=$2" $U/api/ativar; }
pastas() { local a=(); for p in "$@"; do a+=(--data-urlencode "pasta=$p"); done; post "${a[@]}" $U/api/pastas > /dev/null; }
monit() { local a=(); for p in "$@"; do a+=(--data-urlencode "pasta=$p"); done; [ $# -eq 0 ] && a=(-X POST); post "${a[@]}" $U/api/monitoradas; }
espera_fila() { for _ in $(seq 100); do curl -s $U/api/tarefas | grep -q '"estado":"\(fila\|rodando\)"' || return 0; sleep 0.2; done; }

B=/tmp/glr-ativar
desmontar() { for d in A B C; do umount "$B/$d" 2>/dev/null; done; }
desmontar
rm -rf "$B" "$DADOS"
mkdir -p "$B/guardado" "$B/A" "$B/B" "$B/C"
# A: 300 MB, B: 1,5 GB, C: 1 GB (tmpfs so ocupa o que for gravado)
mount -t tmpfs -o size=300m tmpfs "$B/A"
mount -t tmpfs -o size=1536m tmpfs "$B/B"
mount -t tmpfs -o size=1g tmpfs "$B/C"
head -c $((20*1024*1024)) /dev/urandom > "$B/guardado/PPSA01411-jogo.exfat"
head -c $((5*1024*1024)) /dev/urandom > "$B/guardado/PPSA02222-outro.ffpkg"
head -c $((5*1024*1024)) /dev/urandom > "$B/guardado/PPSA03333-repetido.ffpkg"
head -c 100 /dev/zero > "$B/C/PPSA03333-repetido.ffpkg"
truncate -s 900M "$B/guardado/PPSA04444-grande.ffpkg"   # esparso: nao ocupa disco, mas pede 900 MB + 512 MB

GLR_DEMO_MBPS=200 "$BIN" -p $PORTA -d "$DADOS" > /tmp/glr-ativar.log 2>&1 &
PID=$!
sleep 1

pastas "$B/guardado/" "$B/A/" "$B/B/" "$B/C/"
confere "sem pasta marcada"       "$(ativar "$B/guardado/" PPSA01411-jogo.exfat)" '"chave":"ativar_sem_pasta"'
confere "sem X-GLR recusado"      "$(curl -s -o /dev/null -w '%{http_code}' --data-urlencode "pasta=$B/guardado/" --data-urlencode 'nome=x' $U/api/ativar)" '403'
monit "$B/A/" > /dev/null
confere "sem espaco (A 300 MB)"   "$(ativar "$B/guardado/" PPSA01411-jogo.exfat)" '"chave":"ativar_sem_espaco"'
confere "sem espaco diz quanto"   "$(ativar "$B/guardado/" PPSA01411-jogo.exfat)" '"precisa":'$((20*1024*1024 + 512*1024*1024))
confere "nada copiado para A"     "$(ls "$B/A" | wc -l)" '^0$'
monit "$B/A/" "$B/B/" "$B/C/" > /dev/null
R="$(ativar "$B/guardado/" PPSA01411-jogo.exfat)"
confere "ativa: ok"               "$R" '"ok":true'
confere "ativa: escolhe B (mais livre)" "$R" "\"destino\":\"$B/B/\""
confere "ativa: tarefa de copiar" "$(curl -s $U/api/tarefas)" '"tipo":"copiar"'
confere "na fila / ja ativo de novo" "$(ativar "$B/guardado/" PPSA01411-jogo.exfat)" '"chave":"ativar_\(na_fila\|ja_ativo\)"'
espera_fila
confere "copiado para B"          "$(cmp "$B/guardado/PPSA01411-jogo.exfat" "$B/B/PPSA01411-jogo.exfat" && echo igual)" 'igual'
confere "original continua"       "$(ls "$B/guardado/PPSA01411-jogo.exfat")" 'PPSA01411-jogo.exfat'
confere "depois de copiar: ja ativo" "$(ativar "$B/guardado/" PPSA01411-jogo.exfat)" '"chave":"ativar_ja_ativo"'
confere "mesmo nome em C: nunca sobrescreve" "$(ativar "$B/guardado/" PPSA03333-repetido.ffpkg)" '"chave":"ativar_ja_ativo"'
confere "C intacto"               "$(stat -c %s "$B/C/PPSA03333-repetido.ffpkg")" '^100$'
confere "jogo em pasta ativa"     "$(ativar "$B/B/" PPSA01411-jogo.exfat)" '"chave":"ativar_ja_ativo"'
confere "arquivo inexistente"     "$(ativar "$B/guardado/" nao-existe.exfat)" '"chave":"ativar_origem"'
confere "nome invalido"           "$(ativar "$B/guardado/" ../x)" '"chave":"ativar_origem"'
# grande: 900 MB + margem so cabe em B (1,5 GB, ~1,48 GB livres); a copia vai a 200 MB/s (GLR_DEMO_MBPS)
R="$(ativar "$B/guardado/" PPSA04444-grande.ffpkg)"
confere "grande: so B tem espaco" "$R" "\"destino\":\"$B/B/\""
# com o grande prometido para B, o proximo vai para C (B fica com menos livre que C)
confere "reserva da fila conta"   "$(ativar "$B/guardado/" PPSA02222-outro.ffpkg)" "\"destino\":\"$B/C/\""
espera_fila
confere "diario registra escolha" "$(curl -s $U/diario)" 'ativar: PPSA01411-jogo.exfat de'
# disco desligado: pasta marcada que sumiu nao trava o ativar
umount "$B/A"; rmdir "$B/A"
head -c 1024 /dev/urandom > "$B/guardado/PPSA05555-pequeno.ffpkg"
R="$(ativar "$B/guardado/" PPSA05555-pequeno.ffpkg)"
confere "pasta sumida e ignorada" "$R" '"ok":true'
espera_fila

kill $PID 2>/dev/null; wait $PID 2>/dev/null
desmontar
rm -rf "$B" "$DADOS"
echo "=== $ok ok, $falhou falharam"
[ $falhou -eq 0 ]
