#!/bin/bash
# Testa a atualizacao do proprio payload na versao de PC (0.9.12: R1, R3, R4, R10): servidor local no lugar do GitHub
# (GLR_TESTE_BASE), chave de TESTE gerada na hora (GLR_TESTE_CHAVE - so no build de PC) e um elfldr de mentira
# (GLR_TESTE_ELFLDR) para a versao gravada que assume ao iniciar.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_atualizacao.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
T=$(mktemp -d /tmp/glr-atual.XXXXXX)
PORTA=8782; PORTA_SRV=8783; PORTA_ELFLDR=8784
U="http://127.0.0.1:$PORTA"
BASE="http://127.0.0.1:$PORTA_SRV/"
DADOS=/root/glr-dados-atual; SRV="$T/srv"; A=/root/glr-atual-pasta
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
rm -rf "$DADOS" "$A"; mkdir -p "$SRV" "$DADOS" "$A"
VERSAO=$(grep -o '#define VERSAO "[^"]*"' "$ORIGEM/src/api.h" | cut -d'"' -f2)

python3 -I - "$T" <<'EOF'
import sys
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
k = Ed25519PrivateKey.generate()
open(sys.argv[1] + "/chave.pem", "wb").write(k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
open(sys.argv[1] + "/chave.hex", "w").write(k.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex())
EOF
CHAVE_HEX=$(cat "$T/chave.hex")
# $1 = arquivo .elf, $2 = versao no marcador (assinado com a chave de teste, .sig ao lado)
fazer_elf() { python3 -I - "$T/chave.pem" "$1" "$2" <<'EOF'
import sys, os
from cryptography.hazmat.primitives import serialization
k = serialization.load_pem_private_key(open(sys.argv[1], "rb").read(), None)
d = os.urandom(5000) + b"GLIBREN-VERSAO:" + sys.argv[3].encode() + b"\n" + os.urandom(5000)
open(sys.argv[2], "wb").write(d)
open(sys.argv[2] + ".sig", "wb").write(k.sign(d))
EOF
}
anunciar() { printf '{"versao": "%s", "notas": "teste"}\n' "$1" > "$SRV/versao.json"; }
estado() { curl -s "$U/api/atualizacao$1"; }
espera_fim() { for i in $(seq 1 60); do estado '' | grep -q '"rodando":false' && return; sleep 0.25; done; }

(cd "$SRV" && exec python3 -m http.server $PORTA_SRV --bind 127.0.0.1) > "$T/srv.log" 2>&1 &
PID_SRV=$!
printf 'language = pt-BR\nfolder = %s/\n' "$A" > "$DADOS/config.ini"
inicia() { GLR_TESTE_BASE="$BASE" GLR_TESTE_CHAVE="$CHAVE_HEX" "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1; }
anunciar 9.9.9; fazer_elf "$SRV/glibren.elf" 9.9.5
inicia

echo "--- R1: versao anunciada x marcador do .elf baixado"
confere "anuncio mais novo aparece"        "$(estado '?verificar=1')" '"nova":"9.9.9"'
confere "atualizar iniciou"                "$(post -X POST $U/api/atualizar)" '"ok":true'
espera_fim
confere "marcador diferente: recusado"     "$(estado '')" 'a versao baixada (9.9.5) nao e a anunciada (9.9.9): atualizacao recusada'
confere "recusado: nada gravado"           "$(ls $DADOS | grep -c 'glibren.elf')" "^0$"
anunciar 0.0.1
confere "anuncio mais velho nao aparece"   "$(estado '?verificar=1')" '"nova":""'
confere "anuncio mais velho: nao atualiza" "$(post -X POST $U/api/atualizar)" 'nenhuma versao nova'
anunciar "$VERSAO"
confere "anuncio igual nao aparece"        "$(estado '?verificar=1')" '"nova":""'

echo "--- R4: recusa com tarefa na fila"
anunciar 9.9.9; fazer_elf "$SRV/glibren.elf" 9.9.9
estado '?verificar=1' > /dev/null
truncate -s $((3*1024*1024*1024)) "$A/grande.pkg"; mkdir -p /root/glr-atual-destino
printf 'language = pt-BR\nfolder = %s/\nfolder = /root/glr-atual-destino/\n' "$A" > "$DADOS/config.ini"
kill $PID; wait $PID 2>/dev/null; inicia; estado '?verificar=1' > /dev/null
post -d tipo=copiar -d destino=/root/glr-atual-destino -d pasta=$A -d de=grande.pkg $U/api/tarefas > /dev/null
confere "com copia na fila: recusado"      "$(post -X POST $U/api/atualizar)" 'ha tarefas de copiar, mover ou excluir na fila'
post -X POST $U/api/tarefas/cancelar-todas > /dev/null
for i in $(seq 1 40); do curl -s $U/api/tarefas | grep -q '"estado":"\(fila\|rodando\)"' || break; sleep 0.25; done
confere "cancelar todas: nada rodando"     "$(curl -s $U/api/tarefas)" '"estado":"cancelada"'
rm -f "$A/grande.pkg"; rm -rf /root/glr-atual-destino

echo "--- R1/R10: versao certa e gravada"
confere "atualizar iniciou"                "$(post -X POST $U/api/atualizar)" '"ok":true'
espera_fim
confere "gravada sem erro"                 "$(estado '')" '"fase":"reiniciando","erro":""'
confere "elf gravado igual ao baixado"     "$(cmp "$SRV/glibren.elf" "$DADOS/glibren.elf" && cmp "$SRV/glibren.elf.sig" "$DADOS/glibren.elf.sig" && echo igual)" "igual"
confere "sem .part"                        "$(ls $DADOS | grep -c '\.part')" "^0$"
kill $PID; wait $PID 2>/dev/null

echo "--- R3: a versao gravada nao responde na porta"
# elfldr de mentira: recebe o .elf; modo "responde" sobe um servidor na porta do payload dizendo a versao gravada
cat > "$T/elfldr.py" <<'EOF'
import socket, sys, http.server, threading, time
porta_elfldr, porta, modo, versao = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3], sys.argv[4]
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); s.bind(("127.0.0.1", porta_elfldr)); s.listen(1)
c, _ = s.accept(); n = 0
while True:
    d = c.recv(65536)
    if not d: break
    n += len(d)
c.close(); print("recebeu", n, flush=True)
if modo == "responde":
    class H(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            b = ('{"ok":true,"versao":"%s"}' % versao).encode()
            self.send_response(200); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
        def log_message(self, *a): pass
    srv = http.server.HTTPServer(("127.0.0.1", porta), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    time.sleep(8)
EOF
inicia_elfldr() {   # $1 modo
  python3 -I "$T/elfldr.py" $PORTA_ELFLDR $PORTA "$1" 9.9.9 > "$T/elfldr.log" 2>&1 & PID_EL=$!; sleep 0.5
  GLR_TESTE_ELFLDR=$PORTA_ELFLDR GLR_TESTE_ESPERA_NOVA=3 GLR_TESTE_CHAVE="$CHAVE_HEX" "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!
}
: > "$DADOS/glibren.log"
inicia_elfldr calado; sleep 6
confere "nao respondeu: esta segue rodando" "$(curl -s $U/api/estado)" "\"versao\":\"$VERSAO\""
confere "nao respondeu: elfldr recebeu"     "$(cat $T/elfldr.log)" "recebeu 10[0-9]*"
confere "nao respondeu: virou .ruim"        "$(ls $DADOS | tr '\n' ' ')" "glibren.elf.ruim glibren.elf.sig.ruim"
confere "nao respondeu: .elf saiu"          "$(ls $DADOS/glibren.elf 2>&1)" "No such"
confere "nao respondeu: diario"             "$(cat $DADOS/glibren.log)" "a 9.9.9 gravada nao respondeu na porta $PORTA em 3 s - virou"
kill $PID $PID_EL 2>/dev/null; wait $PID $PID_EL 2>/dev/null

mv "$DADOS/glibren.elf.ruim" "$DADOS/glibren.elf"; mv "$DADOS/glibren.elf.sig.ruim" "$DADOS/glibren.elf.sig"
: > "$DADOS/glibren.log"
inicia_elfldr responde; sleep 4
confere "respondeu: esta copia saiu"        "$(kill -0 $PID 2>&1)" "No such process"
confere "respondeu: diario"                 "$(cat $DADOS/glibren.log)" "a 9.9.9 respondeu na porta $PORTA; esta copia ($VERSAO) sai"
confere "respondeu: tentativa contada"      "$(cat $DADOS/tentativas_atualizacao)" "^9.9.9 1$"
confere "respondeu: .elf continua"          "$(ls $DADOS/glibren.elf)" "glibren.elf"
kill $PID_EL 2>/dev/null; wait $PID $PID_EL 2>/dev/null

echo "9.9.9 3" > "$DADOS/tentativas_atualizacao"; : > "$DADOS/glibren.log"
inicia_elfldr calado; sleep 1.5
confere "3 tentativas: virou .ruim sem passar" "$(cat $DADOS/glibren.log)" "subiu e caiu (ou nao subiu) varias vezes seguidas - virou"
confere "3 tentativas: nao chamou o elfldr" "$(cat $T/elfldr.log)" "^$"
confere "3 tentativas: zerou o contador"    "$(ls $DADOS/tentativas_atualizacao 2>&1)" "No such"
confere "3 tentativas: segue rodando"       "$(curl -s $U/api/estado)" "\"versao\":\"$VERSAO\""
kill $PID $PID_EL 2>/dev/null; wait $PID $PID_EL 2>/dev/null

kill $PID_SRV 2>/dev/null; wait 2>/dev/null
rm -rf "$T" "$A" "$DADOS"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
