"""Compara a regra de nome do JavaScript da tela do payload com a do app de PC (Python) em toda a base.

    python payload/testes/comparar_nomes.py base_titulos.tsv
Precisa do node no PATH.
"""
import csv
import json
import re
import subprocess
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(RAIZ))
from base_titulos import PLATAFORMAS, REGIOES  # noqa: E402
from consulta_ps5 import nome_para_arquivo, normalizar  # noqa: E402

tsv = Path(sys.argv[1])
html = (RAIZ / "payload" / "web" / "index.html").read_text(encoding="utf-8")
js = "\n".join(re.findall(r"<script>(.*?)</script>", html, re.S))


def trecho(inicio: str) -> str:
    """Pega uma declaracao do JS (de 'inicio' ate a linha que fecha no nivel 0)."""
    i = js.index(inicio)
    fim = js.index("\n}\n", i) if inicio.startswith("function") else js.index(";\n", i)
    return js[i:fim + 2]


codigo_js = "\n".join([
    trecho("const normalizar"), trecho("const LETRAS_ESPECIAIS"), trecho("function nomeParaArquivo"), trecho("function lerTsv"),
    """
const REGIOES = %s, PLATAFORMAS = %s;
const texto = require("fs").readFileSync(process.argv[2], "utf8");
const [cab, ...linhas] = lerTsv(texto);
const col = Object.fromEntries(cab.map((n, i) => [n, i]));
const mapa = new Map();
for (const c of linhas) {
  const tid = (c[col.titleId] || "").trim(), codigo = normalizar(tid.slice(0, 9));
  if (codigo.length === 9 && (!mapa.has(codigo) || tid.endsWith("_00"))) mapa.set(codigo, c);
}
const saida = {};
for (const [codigo, c] of mapa) {
  const nome = (c[col.name] || "").trim();
  if (!nome) continue;
  saida[codigo] = nomeParaArquivo(nome, codigo, REGIOES[(c[col.region] || " ")[0]] || "", PLATAFORMAS[codigo.slice(0, 4)] || "");
}
process.stdout.write(JSON.stringify(saida));
""" % (json.dumps(REGIOES), json.dumps(PLATAFORMAS))])

arq_js = Path(__file__).with_name("_comparar.js")
arq_js.write_text(codigo_js, encoding="utf-8")
resultado_js = json.loads(subprocess.run(["node", str(arq_js), str(tsv)], capture_output=True, text=True,
                                         encoding="utf-8", check=True).stdout)
arq_js.unlink()

titulos = {}
with open(tsv, encoding="utf-8", newline="") as arq:
    for linha in csv.DictReader(arq, delimiter="\t"):
        title_id = (linha.get("titleId") or "").strip()
        codigo = normalizar(title_id[:9])
        if len(codigo) == 9 and (codigo not in titulos or title_id.endswith("_00")):
            titulos[codigo] = linha
resultado_py = {}
for codigo, linha in titulos.items():
    nome = (linha.get("name") or "").strip()
    if nome:
        resultado_py[codigo] = nome_para_arquivo(nome, codigo, REGIOES.get((linha.get("region") or " ")[0], ""),
                                                 PLATAFORMAS.get(codigo[:4], ""))

diferentes = [c for c in resultado_py if resultado_js.get(c) != resultado_py[c]]
so_py = set(resultado_py) - set(resultado_js)
so_js = set(resultado_js) - set(resultado_py)
print(f"Python: {len(resultado_py)} titulos | JavaScript: {len(resultado_js)} titulos")
print(f"nomes diferentes: {len(diferentes)} | so no Python: {len(so_py)} | so no JavaScript: {len(so_js)}")
for c in diferentes[:15]:
    print(f"  {c}\n    py: {resultado_py[c]}\n    js: {resultado_js.get(c)}")
sys.exit(1 if diferentes or so_py or so_js else 0)
