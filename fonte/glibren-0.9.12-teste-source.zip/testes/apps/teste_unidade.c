/* Testes de unidade do instalador de apps: SHA-256 (vetores do NIST), CRC-32, nomes seguros e o leitor de ZIP.
     teste_unidade sha                         -> vetores (sai 1 se algum falhar)
     teste_unidade zip ARQUIVO DESTINO [MAX]   -> abre e extrai; imprime "OK entradas bytes" ou "ERRO codigo msg"
   Compilado por teste_unidade.sh com -fsanitize=address,undefined. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "miniz_cfg.h"
#include "sha256.h"
#include "zip.h"

static int falhas;

static void confere(const char *nome, int ok) {
  printf("%s %s\n", ok ? "OK   " : "FALHA", nome);
  if(!ok) falhas++;
}

static void sha(const char *nome, const void *dados, size_t n, size_t pedaco, const char *esperado) {
  sha256_t s;
  uint8_t r[32];
  char hex[65];
  sha256_iniciar(&s);
  for(size_t i = 0; i < n; i += pedaco) sha256_atualizar(&s, (const char *)dados + i, n - i < pedaco ? n - i : pedaco);
  sha256_final(&s, r);
  sha256_hex(r, hex);
  confere(nome, !strcmp(hex, esperado));
}

static int vetores(void) {
  const char *m448 = "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq";
  const char *m896 = "abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmnoijklmnopjklmnopqklmnopqrlmnopqrsmnopqrstnopqrstu";
  sha("sha256 vazio", "", 0, 1, "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
  sha("sha256 abc", "abc", 3, 3, "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
  sha("sha256 448 bits", m448, strlen(m448), 64, "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1");
  sha("sha256 448 bits (1 byte por vez)", m448, strlen(m448), 1, "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1");
  sha("sha256 896 bits", m896, strlen(m896), 7, "cf5b16a778af8380036ce59e7b0492370b249b11e8f07a51afac45037afee9d1");
  char *milhao = malloc(1000000);
  memset(milhao, 'a', 1000000);
  sha("sha256 um milhao de a", milhao, 1000000, 4093, "cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0");
  free(milhao);
  confere("crc32 123456789 = cbf43926", mz_crc32(MZ_CRC32_INIT, (const unsigned char *)"123456789", 9) == 0xcbf43926);
  confere("crc32 em dois pedacos",
          mz_crc32(mz_crc32(MZ_CRC32_INIT, (const unsigned char *)"1234", 4), (const unsigned char *)"56789", 5) == 0xcbf43926);
  const char *bons[] = {"eboot.bin", "sce_sys/param.json", "a/b/c", "a\xc3\xa7\xc3\xa3o/x", "..a", "a..", ".hidden"};
  const char *ruins[] = {"", "/etc/x", "../x", "a/../x", "a/..", "./x", "a//b", "a\\b", "c:x", "a\x01" "b", "a/", "\x7f"};
  for(size_t i = 0; i < sizeof bons / sizeof *bons; i++) confere(bons[i], zip_nome_seguro(bons[i]));
  for(size_t i = 0; i < sizeof ruins / sizeof *ruins; i++) {
    char n[64];
    snprintf(n, sizeof n, "recusa nome [%s]", ruins[i]);
    confere(n, !zip_nome_seguro(ruins[i]));
  }
  printf("=== %d falha(s)\n", falhas);
  return falhas != 0;
}

int main(int argc, char *argv[]) {
  if(argc >= 2 && !strcmp(argv[1], "sha")) return vetores();
  if(argc < 4 || strcmp(argv[1], "zip")) {
    fprintf(stderr, "uso: %s sha | zip ARQUIVO DESTINO [MAX]\n", argv[0]);
    return 2;
  }
  zip_t z;
  char erro[300] = "", topo[ZIP_MAX_NOME];
  uint64_t max = argc > 4 ? strtoull(argv[4], NULL, 10) : 2048ull * 1024 * 1024;
  int r = zip_abrir(&z, argv[2], max, erro, sizeof erro);
  if(!r) {
    if(!zip_achar(&z, "eboot.bin") && zip_pasta_topo(&z, topo, sizeof topo)) {
      printf("TOPO %s\n", topo);
      zip_tirar_pasta_topo(&z, topo);
    }
    const zip_entrada_t *e = zip_achar(&z, "sce_sys/param.json");
    if(e) {
      buf_t b = {0};
      int r2 = zip_ler(&z, e, &b, 65536, erro, sizeof erro);
      printf("PARAM %d %zu\n", r2, b.n);
      buf_free(&b);
    }
    r = zip_extrair(&z, argv[3], NULL, NULL, erro, sizeof erro);
  }
  if(r) printf("ERRO %d %s\n", r, erro);
  else printf("OK %u %llu\n", z.n, (unsigned long long)z.total);
  zip_fechar(&z);
  return 0;
}
