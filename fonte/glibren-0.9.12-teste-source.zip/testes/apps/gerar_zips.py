"""Gera os zips de teste (bons e maliciosos) para teste_unidade.sh.  Uso: python3 -I gerar_zips.py PASTA"""
import os
import random
import struct
import sys
import warnings
import zipfile

warnings.simplefilter("ignore")   # zipfile avisa do nome repetido (de proposito)
d = sys.argv[1]
os.makedirs(d, exist_ok=True)
r = random.Random(42)


def P(n):
    return os.path.join(d, n)


# arvore de referencia (para comparar com o que foi extraido)
arvore = {
    "eboot.bin": bytes(r.getrandbits(8) for _ in range(300000)),
    "sce_sys/param.json": b'{"titleId":"PPSA99350","localizedParameters":{"defaultLanguage":"en-US","en-US":{"titleName":"Teste"}}}',
    "texto.txt": b"linha de texto repetida\n" * 200000,   # deflate de verdade (~4.8 MB)
    "vazio": b"",
    "pasta/sub/x.bin": os.urandom(70000),
    "ação/日本.txt": "conteúdo".encode(),
}
ref = P("ref")
for nome, dados in arvore.items():
    caminho = os.path.join(ref, nome)
    os.makedirs(os.path.dirname(caminho), exist_ok=True)
    open(caminho, "wb").write(dados)
os.makedirs(os.path.join(ref, "pasta_vazia"), exist_ok=True)


def bom(nome, prefixo=""):
    with zipfile.ZipFile(P(nome), "w") as z:
        if prefixo:
            z.writestr(zipfile.ZipInfo(prefixo), b"")
        z.writestr(zipfile.ZipInfo(prefixo + "pasta_vazia/"), b"")
        for n, dados in arvore.items():
            metodo = zipfile.ZIP_STORED if n in ("eboot.bin", "vazio") else zipfile.ZIP_DEFLATED
            z.writestr(prefixo + n, dados, compress_type=metodo)


bom("bom.zip")
bom("topo.zip", "PPSA99991/")


def um(nome, arq, dados=b"x", metodo=zipfile.ZIP_DEFLATED, **attrs):
    with zipfile.ZipFile(P(nome), "w") as z:
        z.writestr("eboot.bin", b"e")
        i = zipfile.ZipInfo(arq)
        i.compress_type = metodo
        for k, v in attrs.items():
            setattr(i, k, v)
        z.writestr(i, dados)


um("dotdot.zip", "../x")
um("dotdot2.zip", "a/../../x")
um("absoluto.zip", "/etc/x")
um("barra.zip", "a\\b")
um("controle.zip", "a\x01b")
um("link.zip", "lnk", b"/etc/passwd", zipfile.ZIP_STORED, create_system=3, external_attr=(0o120777 << 16))
um("bzip2.zip", "b.txt", b"abc" * 100, zipfile.ZIP_BZIP2)
with zipfile.ZipFile(P("duplicado.zip"), "w") as z:
    z.writestr("eboot.bin", b"1")
    z.writestr("eboot.bin", b"2")
with zipfile.ZipFile(P("pasta_e_arquivo.zip"), "w") as z:
    z.writestr("a", b"1")
    z.writestr("a/b", b"2")

# ZIP64: mais de 65535 entradas (o python grava o EOCD64)
with zipfile.ZipFile(P("zip64.zip"), "w") as z:
    for i in range(65600):
        z.writestr("f%d" % i, b"")


def achar(b, sig):
    i = 0
    while True:
        i = b.find(sig, i)
        if i < 0:
            return
        yield i
        i += 4


def remendar(origem, destino, fn):
    b = bytearray(open(P(origem), "rb").read())
    fn(b)
    open(P(destino), "wb").write(b)


with zipfile.ZipFile(P("simples.zip"), "w") as z:
    z.writestr("eboot.bin", b"conteudo do eboot" * 100, compress_type=zipfile.ZIP_DEFLATED)


def crc_errado(b):
    for i in list(achar(b, b"PK\x01\x02")):
        b[i + 16] ^= 0xFF
    for i in list(achar(b, b"PK\x03\x04")):
        b[i + 14] ^= 0xFF


def zip64_campo(b):
    for i in list(achar(b, b"PK\x01\x02")):
        b[i + 20:i + 24] = b"\xff\xff\xff\xff"


def cifrado(b):
    for i in list(achar(b, b"PK\x01\x02")):
        b[i + 8] |= 1


def mentira(b):
    for i in list(achar(b, b"PK\x01\x02")):
        b[i + 24:i + 28] = struct.pack("<I", 1000)


def estragar(b):
    i = next(achar(b, b"PK\x03\x04"))
    n = struct.unpack("<H", b[i + 26:i + 28])[0] + struct.unpack("<H", b[i + 28:i + 30])[0]
    for k in range(i + 30 + n, i + 30 + n + 40):
        b[k] = 0xFF


remendar("simples.zip", "crc.zip", crc_errado)
remendar("simples.zip", "zip64_campo.zip", zip64_campo)
remendar("simples.zip", "cifrado.zip", cifrado)
inteiro = open(P("bom.zip"), "rb").read()
open(P("truncado.zip"), "wb").write(inteiro[: len(inteiro) // 2])
open(P("truncado_fim.zip"), "wb").write(inteiro[:-10])
open(P("lixo.zip"), "wb").write(os.urandom(5000))

# bomba 1: razao de compressao absurda (50 MB de zeros)
with zipfile.ZipFile(P("bomba_razao.zip"), "w") as z:
    z.writestr("eboot.bin", b"\0" * (50 * 1024 * 1024), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
# bomba 2: tamanho declarado pequeno (1000 no diretorio central), mas os dados inflam 10 MB
with zipfile.ZipFile(P("bomba_mentira.zip"), "w") as z:
    z.writestr("eboot.bin", b"\0" * (10 * 1024 * 1024), compress_type=zipfile.ZIP_DEFLATED)
remendar("bomba_mentira.zip", "bomba_mentira.zip", mentira)
# deflate invalido
with zipfile.ZipFile(P("deflate_ruim.zip"), "w") as z:
    z.writestr("eboot.bin", os.urandom(20000), compress_type=zipfile.ZIP_DEFLATED)
remendar("deflate_ruim.zip", "deflate_ruim.zip", estragar)
print("ok")
