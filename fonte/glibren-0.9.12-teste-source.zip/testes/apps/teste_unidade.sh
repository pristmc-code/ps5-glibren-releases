#!/bin/bash
# Testes de unidade do instalador de apps (SHA-256, CRC-32, leitor de ZIP com zips bons e maliciosos), com
# -fsanitize=address,undefined.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/apps/teste_unidade.sh
set -u
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
T=$(mktemp -d /tmp/glr-unid.XXXXXX)
trap 'rm -rf "$T"' EXIT
cd "$RAIZ"
clang-18 -Wall -Werror -g -O1 -fsanitize=address,undefined -fno-sanitize-recover=all -Isrc \
  testes/apps/teste_unidade.c src/zip.c src/sha256.c src/miniz_impl.c src/util.c -o "$T/t" || { echo "nao compilou"; exit 1; }
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }

"$T/t" sha || falhas=$((falhas+1))
python3 -I testes/apps/gerar_zips.py "$T/z" >/dev/null || { echo "nao gerou os zips"; exit 1; }
z() { rm -rf "$T/out"; mkdir -p "$T/out"; "$T/t" zip "$T/z/$1" "$T/out" ${2:-} 2>&1; }

r=$(z bom.zip)
confere "zip bom: extraiu (stored+deflate, pastas, vazio, UTF-8)" "$r" "^OK 7 "
confere "zip bom: param.json lido"           "$r" "PARAM 0 "
confere "zip bom: arquivos iguais ao original" "$(diff -r "$T/z/ref" "$T/out" && echo iguais)" "iguais"
r=$(z topo.zip)
confere "pasta de topo: detectada"           "$r" "TOPO PPSA99991"
confere "pasta de topo: extraiu sem ela"     "$(diff -r "$T/z/ref" "$T/out" && echo iguais)" "iguais"
confere "limite total"                       "$(z bom.zip 1000)" "ERRO -6 "
confere "../x recusado"                      "$(z dotdot.zip)" "ERRO -4 "
confere "a/../../x recusado"                 "$(z dotdot2.zip)" "ERRO -4 "
confere "absoluto recusado"                  "$(z absoluto.zip)" "ERRO -4 "
confere "barra invertida recusada"           "$(z barra.zip)" "ERRO -4 "
confere "caractere de controle recusado"     "$(z controle.zip)" "ERRO -4 "
confere "nome repetido recusado"             "$(z duplicado.zip)" "ERRO -4 "
confere "arquivo e pasta com o mesmo nome"   "$(z pasta_e_arquivo.zip)" "ERRO -9 "
confere "link simbolico recusado"            "$(z link.zip)" "ERRO -10 "
confere "bzip2 recusado"                     "$(z bzip2.zip)" "ERRO -5 "
confere "cifrado recusado"                   "$(z cifrado.zip)" "ERRO -5 "
confere "ZIP64 (EOCD64) recusado"            "$(z zip64.zip)" "ERRO -3 "
confere "ZIP64 (campo 0xffffffff) recusado"  "$(z zip64_campo.zip)" "ERRO -3 "
confere "CRC errado recusado"                "$(z crc.zip)" "ERRO -8 "
confere "truncado recusado"                  "$(z truncado.zip)" "ERRO -2 "
confere "truncado no fim recusado"           "$(z truncado_fim.zip)" "ERRO -2 "
confere "lixo recusado"                      "$(z lixo.zip)" "ERRO -2 "
confere "bomba (razao) recusada"             "$(z bomba_razao.zip)" "ERRO -6 "
confere "bomba (tamanho mentiroso) recusada" "$(z bomba_mentira.zip)" "ERRO -7 "
confere "deflate invalido recusado"          "$(z deflate_ruim.zip)" "ERRO -7 "
confere "nada gravado fora do destino"       "$(ls /etc/x "$T/x" "$T/z/x" 2>&1 | grep -c 'No such')" "3"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
