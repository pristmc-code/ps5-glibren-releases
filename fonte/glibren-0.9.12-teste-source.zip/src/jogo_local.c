/* Game Library Renamer (payload PS5) - nome, Title ID e icone lidos de DENTRO do arquivo do jogo (sem internet).

Formatos (leitores em fmt_*.c, ver imagem.h): .pkg, .exfat, .ffpkg (UFS2), .ffpfs (PFS) e .ffpfsc (PFS com imagem
interna comprimida). A extensao so decide a ordem de tentativa: cada leitor confere o proprio magic, entao um arquivo
com extensao trocada tambem e reconhecido. Imagem cifrada (PFS de PKG oficial) nao da para ler: a tela continua com a
base de titulos e a internet.

O resultado fica guardado na memoria por caminho + tamanho + data de modificacao (ler as pastas de novo nao reabre
os arquivos). O icone vai para a pasta de icones (icones/<TITLEID>.png), a mesma das capas baixadas da internet.
*/
#include "jogo_local.h"

#include <ctype.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <unistd.h>

#include "imagem.h"
#include "plataforma.h"

#define MAX_PARAM (1024 * 1024)
#define MAX_ICONE (2 * 1024 * 1024)
#define MAX_GUARDADOS 1024
/* nome do arquivo final no idioma do nome que o app usa (a base de titulos e em ingles) */
#define IDIOMA_NOME "en-US"

typedef struct {
  char caminho[1300];
  long long tamanho, data;
  int achou;
  info_jogo_t info;
  char formato[12];
} guardado_t;

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static guardado_t *g_guardados;
static int g_n, g_proximo;

typedef int (*ler_fn)(dispositivo_t *, const char *, buf_t *, size_t);

/* Le param (json, senao sfo) e o icone de uma imagem com sistema de arquivos. */
static int ler_imagem(dispositivo_t *d, ler_fn ler, info_jogo_t *info, buf_t *icone) {
  buf_t p = {0};
  int ok = -1;
  if(ler(d, "sce_sys/param.json", &p, MAX_PARAM) == IMG_OK) ok = param_json_ler(p.d, p.n, IDIOMA_NOME, info);
  p.n = 0;
  if(ok && ler(d, "sce_sys/param.sfo", &p, MAX_PARAM) == IMG_OK) ok = param_sfo_ler(p.d, p.n, IDIOMA_NOME, info);
  buf_free(&p);
  if(!ok && ler(d, "sce_sys/icon0.png", icone, MAX_ICONE) != IMG_OK) icone->n = 0;
  return ok;
}

static int ler_pkg(dispositivo_t *d, info_jogo_t *info, buf_t *icone) {
  buf_t p = {0};
  char content_id[48] = "";
  int ok = -1;
  if(pkg_ler(d, PKG_PARAM_JSON, &p, MAX_PARAM, content_id) == IMG_OK) ok = param_json_ler(p.d, p.n, IDIOMA_NOME, info);
  p.n = 0;
  if(ok && pkg_ler(d, PKG_PARAM_SFO, &p, MAX_PARAM, content_id) == IMG_OK) ok = param_sfo_ler(p.d, p.n, IDIOMA_NOME, info);
  buf_free(&p);
  if(!ok && !info->content_id[0]) snprintf(info->content_id, sizeof info->content_id, "%s", content_id);
  if(!ok && pkg_ler(d, PKG_ICON0, icone, MAX_ICONE, NULL) != IMG_OK) icone->n = 0;
  return ok;
}

static int termina(const char *s, const char *fim) {
  size_t a = strlen(s), b = strlen(fim);
  return a >= b && !strcasecmp(s + a - b, fim);
}

/* Tenta os leitores na ordem sugerida pela extensao; devolve 0 e o formato que funcionou. */
static int ler_dispositivo(dispositivo_t *d, const char *nome, info_jogo_t *info, buf_t *icone, char *formato, int nivel) {
  static const struct {
    const char *ext, *formato;
    ler_fn ler;
  } FS[] = {{".exfat", "exfat", exfat_ler}, {".ffpkg", "ufs2", ufs2_ler}, {".ufs2", "ufs2", ufs2_ler},
            {".ffpfs", "pfs", pfs_ler}, {".dat", "pfs", pfs_ler}};
  int n = sizeof FS / sizeof *FS;
  /* primeiro o leitor da extensao, depois os outros (cada um recusa rapido o que nao e dele) */
  for(int volta = 0; volta < 2; volta++) {
    if(termina(nome, ".pkg") == !volta && !ler_pkg(d, info, icone)) {
      strcpy(formato, "pkg");
      return 0;
    }
    for(int i = 0; i < n; i++) {
      if(termina(nome, FS[i].ext) == !volta && !ler_imagem(d, FS[i].ler, info, icone)) {
        strcpy(formato, FS[i].formato);
        return 0;
      }
    }
  }
  /* .ffpfsc: imagem interna comprimida dentro de um PFS */
  if(!nivel) {
    dispositivo_t interno;
    char nome_interno[256];
    if(ffpfsc_abrir(d, &interno, nome_interno, sizeof nome_interno) == IMG_OK) {
      int r = ler_dispositivo(&interno, nome_interno, info, icone, formato, 1);
      if(interno.fechar) interno.fechar(&interno);
      if(!r) {
        strcat(formato, "+c");
        return 0;
      }
    }
  }
  return -1;
}

static void gravar_icone(const char *pasta_icones, const char *title_id, const buf_t *icone) {
  char arquivo[700], tmp[710];
  struct stat st;
  if(!icone->n || icone->n < 8 || memcmp(icone->d, "\x89PNG\r\n\x1a\n", 8)) return;
  snprintf(arquivo, sizeof arquivo, "%s/%s.png", pasta_icones, title_id);
  if(!stat(arquivo, &st)) return;   /* ja guardado (este ou baixado antes) */
  mkdir_p(pasta_icones);
  snprintf(tmp, sizeof tmp, "%s.tmp", arquivo);
  FILE *f = fopen(tmp, "wb");
  int ok = f && fwrite(icone->d, 1, icone->n, f) == icone->n;
  if(f && fclose(f)) ok = 0;
  if(!ok || rename(tmp, arquivo)) unlink(tmp);
}

int jogo_local(const char *caminho, const char *pasta_icones, info_jogo_t *info, char *formato, size_t tam_formato) {
  struct stat st;
  memset(info, 0, sizeof *info);
  if(stat(caminho, &st) || !S_ISREG(st.st_mode)) return -1;
  long long data = (long long)st.st_mtime;

  pthread_mutex_lock(&g_trava);
  for(int i = 0; i < g_n; i++) {
    guardado_t *g = &g_guardados[i];
    if(g->tamanho == (long long)st.st_size && g->data == data && !strcmp(g->caminho, caminho)) {
      int achou = g->achou;
      *info = g->info;
      snprintf(formato, tam_formato, "%s", g->formato);
      pthread_mutex_unlock(&g_trava);
      return achou ? 0 : -1;
    }
  }
  pthread_mutex_unlock(&g_trava);

  int fd = open(caminho, O_RDONLY);
  if(fd < 0) return -1;
  dispositivo_t d;
  dispositivo_arquivo(&d, fd, (uint64_t)st.st_size);
  buf_t icone = {0};
  char fmt[12] = "";
  const char *nome = strrchr(caminho, '/');
  int r = ler_dispositivo(&d, nome ? nome + 1 : caminho, info, &icone, fmt, 0);
  close(fd);
  if(!r && !info->title_id[0]) r = -1;   /* sem Title ID nao serve para renomear */
  if(!r) gravar_icone(pasta_icones, info->title_id, &icone);
  else memset(info, 0, sizeof *info);
  buf_free(&icone);
  if(!r) diario("jogo local: %s (%s) em %s", info->title_id, fmt, caminho);
  snprintf(formato, tam_formato, "%s", fmt);

  pthread_mutex_lock(&g_trava);
  if(!g_guardados) g_guardados = calloc(MAX_GUARDADOS, sizeof *g_guardados);
  if(g_guardados) {
    guardado_t *g = &g_guardados[g_n < MAX_GUARDADOS ? g_n++ : (g_proximo++ % MAX_GUARDADOS)];
    snprintf(g->caminho, sizeof g->caminho, "%s", caminho);
    g->tamanho = (long long)st.st_size;
    g->data = data;
    g->achou = !r;
    g->info = *info;
    snprintf(g->formato, sizeof g->formato, "%s", fmt);
  }
  pthread_mutex_unlock(&g_trava);
  return r;
}
