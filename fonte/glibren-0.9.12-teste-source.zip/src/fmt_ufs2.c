/* Game Library Renamer (payload PS5) - leitor UFS2 (.ffpkg), somente leitura. Ver imagem.h.

Formato (FreeBSD sys/ufs/ffs/fs.h e sys/ufs/ufs/dinode.h, dir.h; tudo little-endian):
  Superbloco: no byte 65536 (newfs do FreeBSD, usado pelo ShadowMountPlus e pelo UFS2Tool); tambem tentamos 262144
    e 8192 (o makefs do NetBSD/Ubuntu grava o UFS2 em 8192). fs_magic = 0x19540119 no offset 1372; fs_sblockloc
    (i64 @1000) tem que ser o proprio local (ou 0), senao e uma copia. Campos usados: iblkno @16, ncg @44,
    bsize @48, fsize @52, frag @56, fragshift @96, inopb @120, ipg @184, fpg @188.
  Enderecos de bloco sao em FRAGMENTOS (byte = endereco * fsize). Um bloco tem frag = bsize/fsize fragmentos.
  Inode ino: grupo c = ino / ipg; fsba = fpg*c + iblkno + (((ino % ipg) / inopb) << fragshift);
    byte = fsba*fsize + (ino % inopb) * 256. Raiz = inode 2.
  Dinode UFS2 (256 bytes): mode u16 @0 (S_IFMT 0170000: 040000 dir, 0100000 arquivo), size u64 @16,
    db[12] u64 @112 (blocos diretos), ib[3] u64 @208 (indireto simples, duplo, triplo; NINDIR = bsize/8 por bloco).
    Endereco 0 = buraco (le como zeros). O ultimo bloco de um arquivo pequeno (< 12 blocos) pode ser so alguns
    fragmentos: lemos apenas os bytes ate o size, entao nao precisa tratar a parte.
  Diretorio: pedacos de 512 bytes (DIRBLKSIZ); struct direct = ino u32, reclen u16, type u8, namlen u8, nome.
    Entrada com ino 0 = livre. UFS diferencia maiusculas: procuramos o nome exato e, se nao achar, aceitamos o
    primeiro igual sem diferenciar maiusculas.
Imagens do ShadowMountPlus (mkufs2.sh): newfs -O 2 -b 65536 -f 65536 (bsize = fsize = 64 KiB).
Fontes: FreeBSD sys/ufs, ps5-dump-forge (crate ufs2), ShadowMountPlus. Ver ps5-conhecimento/05-formatos-de-jogos.md.
*/
#include "imagem.h"

#include <stdlib.h>
#include <string.h>

#define UFS2_MAGIC 0x19540119u
#define SB_TAM 1376                      /* le o superbloco ate o fs_magic (inclusive) */
#define DINODE_TAM 256
#define NDADDR 12
#define NIADDR 3
#define DIRBLK 512
#define RAIZ_INO 2
#define MAX_PARTES 64                    /* componentes no caminho */
#define MAX_DIR (64ull * 1024 * 1024)    /* nao varre mais que isso de um diretorio */

#define IFMT 0170000
#define IFDIR 0040000
#define IFREG 0100000

typedef struct {
  dispositivo_t *d;
  uint32_t bsize, fsize, fragshift, inopb, ipg, fpg, ncg, iblkno;
  uint32_t nindir, nindir_shift;
} ufs_t;

typedef struct {
  uint16_t mode;
  uint64_t size;
  uint64_t db[NDADDR];
  uint64_t ib[NIADDR];
} dinode_t;

static uint32_t le32(const uint8_t *p) {
  return (uint32_t)p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24;
}

static uint64_t le64(const uint8_t *p) {
  return (uint64_t)le32(p) | (uint64_t)le32(p + 4) << 32;
}

static int potencia2(uint32_t v) {
  return v && !(v & (v - 1));
}

static uint32_t log2_32(uint32_t v) {
  uint32_t r = 0;
  while(v > 1) {
    v >>= 1;
    r++;
  }
  return r;
}

/* Le n bytes no byte off, conferindo os limites da imagem. 0 = ok. */
static int ler(ufs_t *fs, uint64_t off, void *buf, size_t n) {
  if(off > fs->d->tamanho || n > fs->d->tamanho - off) return -1;
  return fs->d->ler(fs->d, off, buf, n);
}

/* Procura e valida o superbloco. IMG_OK, IMG_FORMATO ou IMG_ERRO (magic certo mas campos invalidos). */
static int abrir_fs(dispositivo_t *d, ufs_t *fs) {
  static const uint64_t locais[] = {65536, 262144, 8192};
  uint8_t sb[SB_TAM];
  int achou_magic = 0;
  for(size_t i = 0; i < sizeof locais / sizeof locais[0]; i++) {
    if(locais[i] > d->tamanho || SB_TAM > d->tamanho - locais[i]) continue;
    if(d->ler(d, locais[i], sb, SB_TAM) != 0) continue;
    if(le32(sb + 1372) != UFS2_MAGIC) continue;
    achou_magic = 1;
    /* fs_sblockloc (@1000) diz onde fica o superbloco principal; uma copia em outro lugar e ignorada (como o
       FreeBSD faz). 0 = imagem antiga sem o campo: aceita. */
    uint64_t sblockloc = le64(sb + 1000);
    if(sblockloc && sblockloc != locais[i]) continue;
    memset(fs, 0, sizeof *fs);
    fs->d = d;
    fs->iblkno = le32(sb + 16);
    fs->ncg = le32(sb + 44);
    fs->bsize = le32(sb + 48);
    fs->fsize = le32(sb + 52);
    uint32_t frag = le32(sb + 56);
    fs->fragshift = le32(sb + 96);
    fs->inopb = le32(sb + 120);
    fs->ipg = le32(sb + 184);
    fs->fpg = le32(sb + 188);
    /* Limites do FreeBSD: bsize 4K..64K (MAXBSIZE), fsize >= 512, ate 8 fragmentos por bloco. */
    if(!potencia2(fs->bsize) || fs->bsize < 4096 || fs->bsize > 65536) continue;
    if(!potencia2(fs->fsize) || fs->fsize < 512 || fs->fsize > fs->bsize) continue;
    if(fs->bsize / fs->fsize > 8 || frag != fs->bsize / fs->fsize) continue;
    if(fs->fragshift != log2_32(frag)) continue;
    if(fs->inopb != fs->bsize / DINODE_TAM) continue;
    if(!fs->ipg || !fs->fpg || !fs->ncg || fs->iblkno >= fs->fpg) continue;
    if((uint64_t)fs->ipg * fs->ncg > 0xFFFFFFFFull) continue;
    fs->nindir = fs->bsize / 8;
    fs->nindir_shift = log2_32(fs->nindir);
    return IMG_OK;
  }
  return achou_magic ? IMG_ERRO : IMG_FORMATO;
}

static int ler_inode(ufs_t *fs, uint32_t ino, dinode_t *di) {
  if(ino < RAIZ_INO || (uint64_t)ino >= (uint64_t)fs->ipg * fs->ncg) return -1;
  uint64_t c = ino / fs->ipg, resto = ino % fs->ipg;
  uint64_t fsba = (uint64_t)fs->fpg * c + fs->iblkno + ((resto / fs->inopb) << fs->fragshift);
  uint64_t off = fsba * fs->fsize + (uint64_t)(ino % fs->inopb) * DINODE_TAM;   /* fsba < 2^61: sem estouro */
  uint8_t b[DINODE_TAM];
  if(ler(fs, off, b, sizeof b) != 0) return -1;
  di->mode = (uint16_t)(b[0] | b[1] << 8);
  di->size = le64(b + 16);
  for(int i = 0; i < NDADDR; i++) di->db[i] = le64(b + 112 + 8 * i);
  for(int i = 0; i < NIADDR; i++) di->ib[i] = le64(b + 208 + 8 * i);
  return 0;
}

/* Converte endereco em fragmentos para byte, conferindo estouro. */
static int frag_para_byte(ufs_t *fs, uint64_t frag, uint64_t *off) {
  if(frag > fs->d->tamanho / fs->fsize) return -1;
  *off = frag * fs->fsize;
  return 0;
}

/* Endereco (em fragmentos) do bloco logico lbn; 0 = buraco. 0 = ok, -1 = erro. */
static int mapear(ufs_t *fs, const dinode_t *di, uint64_t lbn, uint64_t *addr) {
  if(lbn < NDADDR) {
    *addr = di->db[lbn];
    return 0;
  }
  lbn -= NDADDR;
  uint64_t alcance = fs->nindir;   /* blocos cobertos pelo nivel atual */
  int nivel = 0;
  while(lbn >= alcance) {
    lbn -= alcance;
    if(++nivel >= NIADDR) return -1;
    alcance <<= fs->nindir_shift;   /* nindir <= 8192: 8192^3 = 2^39, sem estouro */
  }
  uint64_t a = di->ib[nivel];
  for(int n = nivel; n >= 0; n--) {
    if(!a) break;   /* buraco em qualquer nivel */
    uint64_t idx = (lbn >> (fs->nindir_shift * (uint32_t)n)) & (fs->nindir - 1);
    uint64_t off;
    uint8_t p[8];
    if(frag_para_byte(fs, a, &off) != 0 || ler(fs, off + idx * 8, p, 8) != 0) return -1;
    a = le64(p);
  }
  *addr = a;
  return 0;
}

/* Le n bytes do bloco logico lbn (n <= bsize) em buf. */
static int ler_bloco(ufs_t *fs, const dinode_t *di, uint64_t lbn, uint8_t *buf, size_t n) {
  uint64_t addr, off;
  if(mapear(fs, di, lbn, &addr) != 0) return -1;
  if(!addr) {
    memset(buf, 0, n);
    return 0;
  }
  if(frag_para_byte(fs, addr, &off) != 0) return -1;
  return ler(fs, off, buf, n);
}

static int igual_sem_caixa(const char *a, const uint8_t *b, size_t n) {
  for(size_t i = 0; i < n; i++) {
    unsigned char x = (unsigned char)a[i], y = b[i];
    if(x >= 'A' && x <= 'Z') x = (unsigned char)(x + 32);
    if(y >= 'A' && y <= 'Z') y = (unsigned char)(y + 32);
    if(x != y) return 0;
  }
  return 1;
}

/* Procura "nome" (tam n) no diretorio di. Devolve o inode, 0 se nao achou, -1 em erro. */
static int64_t procurar(ufs_t *fs, const dinode_t *di, const char *nome, size_t n, uint8_t *bloco) {
  uint64_t tam = di->size < MAX_DIR ? di->size : MAX_DIR;
  int64_t aproximado = 0;
  for(uint64_t lbn = 0; lbn * fs->bsize < tam; lbn++) {
    uint64_t resta = tam - lbn * fs->bsize;
    size_t len = resta < fs->bsize ? (size_t)resta : fs->bsize;
    if(ler_bloco(fs, di, lbn, bloco, len) != 0) return -1;
    for(size_t pedaco = 0; pedaco + DIRBLK <= len; pedaco += DIRBLK) {
      for(size_t p = 0; p + 8 <= DIRBLK;) {
        const uint8_t *e = bloco + pedaco + p;
        uint32_t ino = le32(e);
        uint16_t reclen = (uint16_t)(e[4] | e[5] << 8);
        uint8_t namlen = e[7];
        if(reclen < 8 || (reclen & 3) || reclen > DIRBLK - p || (size_t)namlen + 8 > reclen) break;   /* pedaco ruim */
        if(ino && namlen == n) {
          if(!memcmp(e + 8, nome, n)) return ino;
          if(!aproximado && igual_sem_caixa(nome, e + 8, n)) aproximado = ino;
        }
        p += reclen;
      }
    }
  }
  return aproximado;
}

int ufs2_ler(dispositivo_t *d, const char *caminho, buf_t *saida, size_t max) {
  ufs_t fs;
  int r = abrir_fs(d, &fs);
  if(r != IMG_OK) return r;
  if(!caminho) return IMG_NAO_ACHOU;

  uint8_t *bloco = malloc(fs.bsize);
  if(!bloco) return IMG_ERRO;
  size_t n0 = saida->n;
  dinode_t di;
  r = IMG_ERRO;
  if(ler_inode(&fs, RAIZ_INO, &di) != 0) goto fim;

  /* Desce pelo caminho, componente por componente. */
  const char *p = caminho;
  for(int partes = 0;; partes++) {
    while(*p == '/') p++;
    if(!*p) break;
    const char *f = p;
    while(*f && *f != '/') f++;
    size_t n = (size_t)(f - p);
    if(partes >= MAX_PARTES || n > 255 || (di.mode & IFMT) != IFDIR) {
      r = IMG_NAO_ACHOU;
      goto fim;
    }
    int64_t ino = procurar(&fs, &di, p, n, bloco);
    if(ino < 0) goto fim;
    if(ino == 0) {
      r = IMG_NAO_ACHOU;
      goto fim;
    }
    if(ler_inode(&fs, (uint32_t)ino, &di) != 0) goto fim;
    p = f;
  }
  if((di.mode & IFMT) != IFREG) {
    r = IMG_NAO_ACHOU;
    goto fim;
  }
  if(di.size > max) goto fim;

  /* Copia o conteudo, bloco a bloco (o ultimo pode ser parcial / fragmentos). */
  for(uint64_t lbn = 0; lbn * fs.bsize < di.size; lbn++) {
    uint64_t resta = di.size - lbn * fs.bsize;
    size_t len = resta < fs.bsize ? (size_t)resta : fs.bsize;
    if(ler_bloco(&fs, &di, lbn, bloco, len) != 0) goto fim;
    buf_add(saida, bloco, len);
  }
  r = IMG_OK;

fim:
  if(r != IMG_OK && saida->n > n0) {
    saida->n = n0;
    saida->d[n0] = 0;
  }
  free(bloco);
  return r;
}
