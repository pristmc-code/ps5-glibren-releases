/* Game Library Renamer (payload PS5) - instalador/atualizador de apps homebrew (catalogo assinado) e botao YouTube. */
#pragma once

#include <stddef.h>
#include "util.h"

/* {"ok","catalogo","erro","apps":[...],"trabalho":{...}}; forcar = baixa o catalogo agora (senao, a cada 15 min). */
void apps_json(buf_t *json, int forcar);
/* Baixa, confere e instala o app "id" do catalogo numa thread (um trabalho por vez). 0 = iniciou. */
int apps_instalar(const char *id, char *msg, size_t tam);
/* 1 se uma instalacao ou desinstalacao esta em andamento (a atualizacao do payload espera). */
int apps_ocupado(void);
/* Texto de diagnostico: hora do PS5 e o final do log do app (ytps5: yt.log, so com o app aberto). */
void apps_log(const char *id, buf_t *b);
/* Desinstala o app "id" do catalogo numa thread (o ShadowMountPlus tira o icone; a pasta e apagada). 0 = iniciou. */
int apps_desinstalar(const char *id, char *msg, size_t tam);
/* Jobe (PPSA99471) instalada e com <dados>/tube/jobe-tube.txt: grava tube/abrir.txt (busca e "voltar=PMGL00001") e
   abre a Jobe, que toca o YouTube dentro dela - vale para as duas funcoes abaixo; senao, como antes.
   Grava a busca no app de YouTube instalado (ytps5, depois YouTube Max'd) e abre o app. 0 = ok (json recebe a
   resposta); senao chave/msg explicam (chave "sem_app_youtube" = nenhum instalado). */
int apps_youtube(const char *busca, buf_t *json, char *chave, size_t tam_chave, char *msg, size_t tam_msg);
/* Acao "YouTube" da janela Apps: abre a Jobe (acima) ou o YouTube Max'd (PPSA99991) na busca. busca pode ser vazia. Grava
   glibren_busca.txt com 2 linhas (busca e "voltar=PMGL00001"). Erro: chave "sem_maxd" = nem Jobe nem Max'd. */
int apps_youtube_maxd(const char *busca, buf_t *json, char *chave, size_t tam_chave, char *msg, size_t tam_msg);
