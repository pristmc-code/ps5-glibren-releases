/* Game Library Renamer (payload PS5) - temperaturas, ventoinha e alerta.
   Uma thread le os sensores a cada 2 s o tempo todo (inclusive com um jogo aberto). */
#pragma once

#include "util.h"

void termico_iniciar(void);
void termico_json(buf_t *b, int com_historico);
/* Temperatura em que a ventoinha acelera (50..85) ou 0 = automatico do sistema. Devolve 0 ou -1 (erro em msg). */
int termico_definir_limite(int celsius, char *msg, size_t tam);
/* Notificacao no PS5 quando a mais quente passar de celsius (0 = desligado). */
int termico_definir_alerta(int celsius);
