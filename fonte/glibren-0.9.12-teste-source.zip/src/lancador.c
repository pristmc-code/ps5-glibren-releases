/* Game Library Renamer (payload PS5) - abrir apps sem atropelar outro app aberto.

Logs reais (Jobe, 11/11/2026): sceLncUtilLaunchApp com outro app em primeiro plano falha (0x80940011 / 0x80940031)
e e suspeito de derrubar o console. Regra: nunca lancar um titulo enquanto outro app de jogo esta aberto.

- "App aberto": sceLncUtilGetAppId(titulo) >= 0 (mesma checagem do companion da Jobe, native/companion_daemon.c).
- "App de jogo aberto": algum titulo instalado (/user/appmeta/<TID> ou /data/homebrew/<TID>) aberto, menos o icone
  do glibren (PMGL00001): esse e so um deeplink que abre a pagina no navegador do sistema; o navegador e app do
  sistema (NPXS...), fora dessas pastas, entao a pagina do glibren aberta nao conta como app de jogo.
- Pedido pendente (POST /launch com "from"): mesmo contrato do /switch do payload de fundo da Jobe - espera o
  "from" fechar (ate 2 min), espera ~15 s e lanca com ate 4 tentativas (pausas 5/10/20 s), tudo no diario. Um pedido
  novo substitui o pendente. Uma thread so, criada no primeiro pedido.

No PC (testes): GLR_TESTE_ABERTOS = arquivo com os titulos "abertos" (separados por espaco/linha) e
GLR_TESTE_SEGUNDO_MS = duracao de um "segundo" das esperas (padrao 1000).
*/
#include "lancador.h"

#include <dirent.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "plataforma.h"
#include "util.h"

#define ESPERA_FROM_S 120
#define ESPERA_ANTES_S 15
#define SEP " \t\r\n"

#ifdef __PROSPERO__
int sceLncUtilGetAppId(const char *title_id) __attribute__((weak));
#endif

int titulo_valido(const char *tid) {
  if(!tid || strlen(tid) != 9) return 0;
  for(int i = 0; i < 9; i++) {
    char c = tid[i];
    if(i < 4 ? !(c >= 'A' && c <= 'Z') : !(c >= '0' && c <= '9')) return 0;
  }
  return 1;
}

#ifndef __PROSPERO__
/* Lista de titulos "abertos" do teste (arquivo de GLR_TESTE_ABERTOS). 0 = leu. */
static int abertos_teste(char *saida, size_t tam) {
  const char *arq = getenv("GLR_TESTE_ABERTOS");
  saida[0] = 0;
  if(!arq || !*arq) return 0;
  FILE *f = fopen(arq, "r");
  if(!f) return 0;
  size_t n = fread(saida, 1, tam - 1, f);
  saida[n] = 0;
  fclose(f);
  return 0;
}
#endif

int app_aberto(const char *tid) {
  if(!titulo_valido(tid)) return 0;
#ifdef __PROSPERO__
  if(!sceLncUtilGetAppId) return -1;
  return sceLncUtilGetAppId(tid) >= 0;
#else
  char lista[4096];
  abertos_teste(lista, sizeof lista);
  for(char *sv = NULL, *p = strtok_r(lista, SEP, &sv); p; p = strtok_r(NULL, SEP, &sv))
    if(!strcmp(p, tid)) return 1;
  return 0;
#endif
}

#ifdef __PROSPERO__
/* Primeiro titulo aberto da pasta (cada subpasta com nome de titulo). 1 = achou, 0 = nenhum. */
static int aberto_na_pasta(const char *pasta, char *tid, size_t tam) {
  DIR *d = opendir(pasta);
  if(!d) return 0;
  struct dirent *e;
  int achou = 0;
  while(!achou && (e = readdir(d))) {
    if(!titulo_valido(e->d_name) || !strcmp(e->d_name, GLIBREN_TITLE_ID)) continue;
    if(app_aberto(e->d_name) == 1) {
      snprintf(tid, tam, "%s", e->d_name);
      achou = 1;
    }
  }
  closedir(d);
  return achou;
}
#endif

int app_de_jogo_aberto(char *tid, size_t tam) {
  tid[0] = 0;
#ifdef __PROSPERO__
  if(!sceLncUtilGetAppId) return -1;
  return aberto_na_pasta("/user/appmeta", tid, tam) || aberto_na_pasta("/data/homebrew", tid, tam);
#else
  char lista[4096];
  abertos_teste(lista, sizeof lista);
  for(char *sv = NULL, *p = strtok_r(lista, SEP, &sv); p; p = strtok_r(NULL, SEP, &sv)) {
    if(titulo_valido(p) && strcmp(p, GLIBREN_TITLE_ID)) {
      snprintf(tid, tam, "%s", p);
      return 1;
    }
  }
  return 0;
#endif
}

/* ------------------------------------------------------------------ pedido pendente */

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t g_sinal = PTHREAD_COND_INITIALIZER;
static char g_to[16], g_from[16];
static const char *g_estado = "nenhum";
static unsigned g_geracao;
static int g_tem_pedido, g_thread;

static unsigned geracao(void) {
  pthread_mutex_lock(&g_trava);
  unsigned g = g_geracao;
  pthread_mutex_unlock(&g_trava);
  return g;
}

/* Muda o estado so se o pedido ainda for o atual. */
static void estado(unsigned g, const char *e) {
  pthread_mutex_lock(&g_trava);
  if(g == g_geracao) g_estado = e;
  pthread_mutex_unlock(&g_trava);
}

static long ms_por_segundo(void) {
#ifndef __PROSPERO__
  const char *s = getenv("GLR_TESTE_SEGUNDO_MS");
  if(s && atol(s) > 0) return atol(s);
#endif
  return 1000;
}

/* Espera "segundos"; volta 1 se chegou um pedido novo no meio (este foi substituido). */
static int esperar(long segundos, unsigned g) {
  long total = segundos * ms_por_segundo();
  long passo = total < 50 ? total : 50;
  for(long feito = 0; feito < total; feito += passo) {
    if(geracao() != g) return 1;
    usleep(passo * 1000);
  }
  return geracao() != g;
}

static void executar(const char *to, const char *from, unsigned g) {
  static const int PAUSAS[] = {0, 5, 10, 20};
  diario("launch: pedido para abrir %s%s%s", to, from[0] ? " depois que fechar " : "", from);
  if(from[0]) {
    long s = 0;
    while(app_aberto(from) == 1) {
      if(s >= ESPERA_FROM_S) {
        diario("launch: %s nao fechou em %d s - desistiu de abrir %s", from, ESPERA_FROM_S, to);
        estado(g, "desistiu");
        return;
      }
      if(esperar(1, g)) return;
      s++;
    }
    diario("launch: %s fechou (%ld s); abrindo %s em %d s", from, s, to, ESPERA_ANTES_S);
  }
  estado(g, "aguardando");
  if(esperar(ESPERA_ANTES_S, g)) return;
  estado(g, "lancando");
  for(int i = 0; i < 4; i++) {
    if(i && esperar(PAUSAS[i], g)) return;
    if(app_aberto(to) == 1) {
      diario("launch: %s ja esta aberto", to);
      estado(g, "aberto");
      return;
    }
    char outro[16];
    int aberto = app_de_jogo_aberto(outro, sizeof outro);
    if(aberto < 0) {   /* R7: sem como saber se ha app aberto, nao lanca */
      diario("launch: tentativa %d: nao deu para saber se ha app aberto - nao lancou %s", i + 1, to);
      continue;
    }
    if(aberto == 1 && strcmp(outro, to)) {
      diario("launch: tentativa %d: %s esta aberto - nao lancou %s", i + 1, outro, to);
      continue;
    }
    int r = abrir_app(to);
    diario("launch: tentativa %d de abrir %s -> 0x%08x", i + 1, to, (unsigned)r);
    if(!r) {
      estado(g, "aberto");
      return;
    }
  }
  diario("launch: desistiu de abrir %s depois de 4 tentativas", to);
  estado(g, "falhou");
}

static void *trabalhador(void *arg) {
  (void)arg;
  for(;;) {
    pthread_mutex_lock(&g_trava);
    while(!g_tem_pedido) pthread_cond_wait(&g_sinal, &g_trava);
    char to[16], from[16];
    snprintf(to, sizeof to, "%s", g_to);
    snprintf(from, sizeof from, "%s", g_from);
    unsigned g = g_geracao;
    g_tem_pedido = 0;
    pthread_mutex_unlock(&g_trava);
    executar(to, from, g);
  }
  return NULL;
}

int lancador_pedir(const char *to, const char *from) {
  if(!titulo_valido(to) || (from && *from && !titulo_valido(from))) return -1;
  pthread_mutex_lock(&g_trava);
  if(g_tem_pedido || (strcmp(g_estado, "nenhum") && strcmp(g_estado, "aberto") && strcmp(g_estado, "desistiu") &&
                      strcmp(g_estado, "falhou")))
    diario("launch: pedido anterior (%s) substituido", g_to);
  snprintf(g_to, sizeof g_to, "%s", to);
  snprintf(g_from, sizeof g_from, "%s", from ? from : "");
  g_geracao++;
  g_tem_pedido = 1;
  g_estado = "esperando";
  int r = 0;
  if(!g_thread) {
    if(criar_thread(trabalhador, NULL, NULL)) r = -1;
    else g_thread = 1;
  }
  pthread_cond_signal(&g_sinal);
  pthread_mutex_unlock(&g_trava);
  return r;
}

const char *lancador_estado(void) {
  pthread_mutex_lock(&g_trava);
  const char *e = g_estado;
  pthread_mutex_unlock(&g_trava);
  return e;
}
