/* Game Library Renamer (payload PS5) - configuracao unica do miniz (terceiros/miniz.c, MIT): so o inflate (tinfl) e o
   mz_crc32. O miniz e compilado uma vez so, em miniz_impl.c; os outros fontes incluem este arquivo (que traz o
   miniz.h) para usar tinfl_* (fmt_pfs.c: blocos PFSC; zip.c: entradas deflate) e mz_crc32 (zip.c). */
#pragma once

#define MINIZ_NO_STDIO
#define MINIZ_NO_TIME
#define MINIZ_NO_ARCHIVE_APIS
#define MINIZ_NO_ARCHIVE_WRITING_APIS
#define MINIZ_NO_DEFLATE_APIS
#define MINIZ_NO_ZLIB_APIS
#define MINIZ_NO_ZLIB_COMPATIBLE_NAMES
#ifndef NDEBUG
#define NDEBUG   /* sem assert() do miniz: um assert derrubaria o payload */
#endif

/* codigo de terceiros: sem os avisos do nosso -Werror */
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Weverything"
#include "terceiros/miniz.h"
#pragma clang diagnostic pop
