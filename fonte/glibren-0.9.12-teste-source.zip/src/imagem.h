/* Game Library Renamer (payload PS5) - leitura de arquivos DENTRO de imagens e pacotes de jogos, sem montar e sem
   internet (so leitura): nome, Title ID e icone a partir de sce_sys/param.json, param.sfo e icon0.png.
   Formatos: .pkg (PS4/PS5), .exfat (exFAT), .ffpkg (UFS2), .ffpfs (PFS) e .ffpfsc (PFS com imagem interna em PFSC/zlib).
   Referencias (codigo aberto): ShadowMountPlus, ps5-dump-forge, LibOrbisPkg, MkPFS, FreeBSD sys/ufs, spec exFAT.
   Detalhes dos formatos: ps5-conhecimento/05-formatos-de-jogos.md. */
#pragma once

#include <stddef.h>
#include <stdint.h>

#include "util.h"

/* Algo de onde se le bytes por deslocamento: o arquivo da imagem ou uma imagem interna (ex.: a de dentro do .ffpfsc). */
typedef struct dispositivo {
  int (*ler)(struct dispositivo *d, uint64_t off, void *buf, size_t n);   /* 0 = leu os n bytes; -1 = erro/fim */
  void (*fechar)(struct dispositivo *d);                                   /* pode ser NULL */
  uint64_t tamanho;
  void *ctx;
} dispositivo_t;

/* Codigos de retorno dos leitores */
#define IMG_OK 0
#define IMG_FORMATO (-1)    /* nao e esse formato (magic errado) ou formato nao suportado (ex.: PFS cifrado) */
#define IMG_NAO_ACHOU (-2)  /* formato certo, mas o arquivo pedido nao existe */
#define IMG_ERRO (-3)       /* erro de leitura, estrutura corrompida ou arquivo maior que o limite */

/* Arquivo aberto (pread). O fd continua sendo do chamador. imagem.c */
void dispositivo_arquivo(dispositivo_t *d, int fd, uint64_t tamanho);

/* Le o arquivo "caminho" (relativo a raiz do jogo, ex.: "sce_sys/param.json") de dentro da imagem, ate max bytes,
   acrescentando em saida. Cada leitor confere o proprio magic primeiro (devolve IMG_FORMATO se nao for o dele). */
int exfat_ler(dispositivo_t *d, const char *caminho, buf_t *saida, size_t max);   /* fmt_exfat.c */
int ufs2_ler(dispositivo_t *d, const char *caminho, buf_t *saida, size_t max);    /* fmt_ufs2.c */
int pfs_ler(dispositivo_t *d, const char *caminho, buf_t *saida, size_t max);     /* fmt_pfs.c (raiz = "uroot";
                                                                                      arquivo com flag comprimido: descompacta o PFSC) */

/* .ffpfsc: abre o PFS externo, acha o unico arquivo do uroot (pfs_image.dat, *.ffpfs, *.exfat, *.ffpkg, *.ufs2) e
   devolve em "interno" um dispositivo que le essa imagem ja descompactada (blocos PFSC inflados sob demanda, com cache).
   nome_interno recebe o nome do arquivo (para escolher o leitor). Fechar com interno->fechar. fmt_pfs.c */
int ffpfsc_abrir(dispositivo_t *externo, dispositivo_t *interno, char *nome_interno, size_t tam_nome);

/* Pacote .pkg: le a entrada de id "id" da tabela do cabecalho (0x1000 param.sfo, 0x1200 icon0.png, 0x2000 param.json).
   Aceita CNT (PS4, 0x7F434E54) e os envelopes de PS5 que o ShadowMountPlus aceita. Entrada cifrada: IMG_FORMATO.
   content_id (opcional, >= 48 bytes) recebe o Content ID do cabecalho. fmt_pkg.c */
#define PKG_PARAM_SFO 0x1000
#define PKG_ICON0 0x1200
#define PKG_PARAM_JSON 0x2000
int pkg_ler(dispositivo_t *d, uint32_t id, buf_t *saida, size_t max, char *content_id);

/* Dados do jogo tirados do param.json (PS5) ou param.sfo (PS4). fmt_param.c */
typedef struct {
  char title_id[16];     /* "PPSA01234" */
  char content_id[48];
  char nome[256];        /* no idioma pedido; senao o padrao do jogo; senao en-US; senao qualquer um (UTF-8) */
  char categoria[8];     /* param.sfo: gd/gp/ac...; param.json: "" */
} info_jogo_t;

/* idioma: codigo do PS5, ex.: "pt-BR", "en-US", "es-419" (o param.sfo usa TITLE_XX pelo numero do idioma). 0 = ok. */
int param_json_ler(const char *dados, size_t n, const char *idioma, info_jogo_t *info);
int param_sfo_ler(const void *dados, size_t n, const char *idioma, info_jogo_t *info);
