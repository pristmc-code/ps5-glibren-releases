/* Game Library Renamer (payload PS5) - fila de tarefas: copiar, mover e excluir arquivos.
   Uma tarefa por vez, numa thread propria (continua com a tela fechada). */
#pragma once

#include "util.h"

typedef enum { TAR_COPIAR, TAR_MOVER, TAR_EXCLUIR } tarefa_tipo_t;

/* Sufixo do arquivo parcial de uma copia (so nosso: as sobras sao apagadas ao iniciar). */
#define SUFIXO_PARCIAL ".glr-part"

/* Recusas de tarefas_adicionar (a tela mostra o motivo de cada uma). */
#define TAR_R_INVALIDO -1
#define TAR_R_FILA_CHEIA -2
#define TAR_R_EM_DOWNLOAD -3

void tarefas_iniciar(void);   /* apaga as sobras de copias interrompidas e sobe o trabalhador */
/* Poe na fila. destino: pasta (ignorada no excluir); para: nome no destino ("" = mesmo nome).
   Devolve o id (> 0) ou um TAR_R_* (< 0). */
int tarefas_adicionar(tarefa_tipo_t tipo, const char *pasta, const char *nome, const char *destino, const char *para);
int tarefas_cancelar(int id);      /* 0 = ok, -1 = nao achou ou ja terminou */
int tarefas_cancelar_todas(void);  /* cancela tudo que esta na fila ou rodando; devolve quantas */
/* 1 se pasta/nome ja esta na fila ou rodando (qualquer tipo). */
int tarefas_tem(const char *pasta, const char *nome);
/* 1 se alguma copia ou movimentacao esta na fila ou rodando (ex.: o botao Ler do SSD USB espera). */
int tarefas_copiando(void);
/* Quantas tarefas (copiar, mover ou excluir) estao na fila ou rodando (a atualizacao do payload espera). */
int tarefas_ativas(void);
/* Bytes que as copias/movimentos na fila ou rodando ainda vao gravar em destino (espaco ja prometido). */
long long tarefas_reservado(const char *destino);
void tarefas_limpar_terminadas(void);
void tarefas_json(buf_t *b);       /* {"ok":true,"tarefas":[...]} */
