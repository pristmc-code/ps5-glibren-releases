/* Game Library Renamer (payload PS5) - leitor de ZIP minimo (so leitura). Ver zip.h.

Formato (APPNOTE da PKWARE), tudo little-endian:
  EOCD (fim do arquivo, depois so o comentario): 0x06054b50, disco u16, disco do CD u16, entradas no disco u16,
    entradas u16, tamanho do CD u32, inicio do CD u32, tamanho do comentario u16. Valores 0xFFFF/0xFFFFFFFF ou o
    localizador ZIP64 (0x07064b50) logo antes = ZIP64 (recusado).
  Diretorio central (CD), uma entrada por arquivo: 0x02014b50, feito-por u16 (byte alto 3 = Unix), versao u16,
    flags u16 (bit 0 = cifrado), metodo u16, hora/data, crc u32, comprimido u32, tamanho u32, nome u16, extra u16,
    comentario u16, disco u16, atributos internos u16, externos u32 (Unix: modo nos 16 bits altos), local u32, nome.
  Cabecalho local: 0x04034b50 ... nome u16 em +26, extra u16 em +28; os dados vem logo depois. Os tamanhos e o CRC
    usados sao os do CD (o local pode ter zero quando o bit 3 - descritor de dados - esta ligado).
*/
#include "zip.h"

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include "miniz_cfg.h"

#define SIG_EOCD 0x06054b50u
#define SIG_ZIP64_LOC 0x07064b50u
#define SIG_CD 0x02014b50u
#define SIG_LOCAL 0x04034b50u
#define MAX_CD (32u * 1024 * 1024)
#define BLOCO (64 * 1024)

static uint16_t le16(const uint8_t *p) {
  return (uint16_t)(p[0] | p[1] << 8);
}

static uint32_t le32(const uint8_t *p) {
  return (uint32_t)p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24;
}

static int falha(int codigo, char *erro, size_t tam, const char *fmt, const char *det) {
  if(erro && tam) snprintf(erro, tam, fmt, det ? det : "");
  return codigo;
}

static int ler_em(int fd, uint64_t off, void *buf, size_t n) {
  for(size_t lidos = 0; lidos < n;) {
    ssize_t r = pread(fd, (char *)buf + lidos, n - lidos, (off_t)(off + lidos));
    if(r <= 0) return -1;
    lidos += (size_t)r;
  }
  return 0;
}

int zip_nome_seguro(const char *nome) {
  size_t n = strlen(nome);
  if(!n || n >= ZIP_MAX_NOME || nome[0] == '/') return 0;
  for(const unsigned char *p = (const unsigned char *)nome; *p; p++) {
    if(*p < 0x20 || *p == 0x7f || *p == '\\' || *p == ':') return 0;
  }
  /* nenhum componente vazio, "." ou ".." */
  for(const char *p = nome;;) {
    size_t c = strcspn(p, "/");
    if(!c || (c == 1 && p[0] == '.') || (c == 2 && p[0] == '.' && p[1] == '.')) return 0;
    if(!p[c]) break;
    p += c + 1;
  }
  return 1;
}

static int comparar_nomes(const void *a, const void *b) {
  return strcmp((*(const zip_entrada_t *const *)a)->nome, (*(const zip_entrada_t *const *)b)->nome);
}

void zip_fechar(zip_t *z) {
  if(z->e) {
    for(uint32_t i = 0; i < z->n; i++) free(z->e[i].nome_zip);
    free(z->e);
  }
  if(z->fd >= 0) close(z->fd);
  memset(z, 0, sizeof *z);
  z->fd = -1;
}

int zip_abrir(zip_t *z, const char *arquivo, uint64_t max_total, char *erro, size_t tam_erro) {
  memset(z, 0, sizeof *z);
  z->fd = open(arquivo, O_RDONLY);
  if(z->fd < 0) return falha(ZIP_E_ABRIR, erro, tam_erro, "nao abriu o zip (%s)", strerror(errno));
  struct stat st;
  if(fstat(z->fd, &st) || !S_ISREG(st.st_mode)) {
    zip_fechar(z);
    return falha(ZIP_E_ABRIR, erro, tam_erro, "zip invalido%s", NULL);
  }
  z->tamanho_arquivo = (uint64_t)st.st_size;
  int r = ZIP_E_FORMATO;
  uint8_t *cauda = NULL, *cd = NULL;
  zip_entrada_t **ordem = NULL;
  if(z->tamanho_arquivo < 22) {
    falha(r, erro, tam_erro, "arquivo pequeno demais para ser zip%s", NULL);
    goto fim;
  }

  /* EOCD: procura de tras para frente nos ultimos 22 + 65535 bytes */
  size_t n_cauda = z->tamanho_arquivo < 22 + 65535 ? (size_t)z->tamanho_arquivo : 22 + 65535;
  uint64_t ini_cauda = z->tamanho_arquivo - n_cauda;
  if(!(cauda = malloc(n_cauda))) {
    r = falha(ZIP_E_MEMORIA, erro, tam_erro, "sem memoria%s", NULL);
    goto fim;
  }
  if(ler_em(z->fd, ini_cauda, cauda, n_cauda)) {
    r = falha(ZIP_E_ABRIR, erro, tam_erro, "erro de leitura%s", NULL);
    goto fim;
  }
  long pos = -1;
  for(long i = (long)n_cauda - 22; i >= 0; i--) {
    if(le32(cauda + i) == SIG_EOCD && (size_t)i + 22 + le16(cauda + i + 20) == n_cauda) {
      pos = i;
      break;
    }
  }
  if(pos < 0) {
    falha(r, erro, tam_erro, "fim do zip nao encontrado (arquivo truncado ou nao e zip)%s", NULL);
    goto fim;
  }
  const uint8_t *e = cauda + pos;
  uint64_t eocd = ini_cauda + (uint64_t)pos;
  uint16_t disco = le16(e + 4), disco_cd = le16(e + 6), n_disco = le16(e + 8), n_total = le16(e + 10);
  uint32_t tam_cd = le32(e + 12), off_cd = le32(e + 16);
  int loc64 = 0;
  if(eocd >= 20) {
    uint8_t l[4];
    loc64 = !ler_em(z->fd, eocd - 20, l, 4) && le32(l) == SIG_ZIP64_LOC;
  }
  if(loc64 || n_total == 0xffff || n_disco == 0xffff || tam_cd == 0xffffffffu || off_cd == 0xffffffffu) {
    r = falha(ZIP_E_ZIP64, erro, tam_erro, "zip no formato ZIP64 (nao suportado)%s", NULL);
    goto fim;
  }
  if(disco || disco_cd || n_disco != n_total) {
    falha(r, erro, tam_erro, "zip dividido em varios volumes (nao suportado)%s", NULL);
    goto fim;
  }
  if((uint64_t)off_cd + tam_cd > eocd || tam_cd > MAX_CD || (uint64_t)n_total * 46 > tam_cd) {
    falha(r, erro, tam_erro, "diretorio do zip fora do arquivo (corrompido ou truncado)%s", NULL);
    goto fim;
  }
  z->inicio_cd = off_cd;
  if(!(cd = malloc(tam_cd ? tam_cd : 1)) || !(z->e = calloc(n_total ? n_total : 1, sizeof *z->e))) {
    r = falha(ZIP_E_MEMORIA, erro, tam_erro, "sem memoria%s", NULL);
    goto fim;
  }
  if(ler_em(z->fd, off_cd, cd, tam_cd)) {
    r = falha(ZIP_E_ABRIR, erro, tam_erro, "erro de leitura%s", NULL);
    goto fim;
  }

  size_t p = 0;
  for(uint32_t i = 0; i < n_total; i++) {
    if(p + 46 > tam_cd || le32(cd + p) != SIG_CD) {
      falha(r, erro, tam_erro, "diretorio do zip corrompido%s", NULL);
      goto fim;
    }
    const uint8_t *c = cd + p;
    uint16_t feito = le16(c + 4), flags = le16(c + 8), metodo = le16(c + 10), n_nome = le16(c + 28), n_extra = le16(c + 30),
             n_coment = le16(c + 32), disco_ini = le16(c + 34);
    uint32_t crc = le32(c + 16), comp = le32(c + 20), tam = le32(c + 24), externos = le32(c + 38), local = le32(c + 42);
    if(p + 46 + n_nome + n_extra + n_coment > tam_cd) {
      falha(r, erro, tam_erro, "diretorio do zip corrompido%s", NULL);
      goto fim;
    }
    if(comp == 0xffffffffu || tam == 0xffffffffu || local == 0xffffffffu || disco_ini == 0xffff) {
      r = falha(ZIP_E_ZIP64, erro, tam_erro, "zip no formato ZIP64 (nao suportado)%s", NULL);
      goto fim;
    }
    char nome[ZIP_MAX_NOME + 1];
    if(!n_nome || n_nome > ZIP_MAX_NOME || memchr(c + 46, 0, n_nome)) {
      r = falha(ZIP_E_NOME, erro, tam_erro, "nome de arquivo invalido no zip%s", NULL);
      goto fim;
    }
    memcpy(nome, c + 46, n_nome);
    nome[n_nome] = 0;
    zip_entrada_t *en = &z->e[z->n];
    en->pasta = nome[n_nome - 1] == '/';
    if(en->pasta) nome[n_nome - 1] = 0;
    if(!zip_nome_seguro(nome)) {
      r = falha(ZIP_E_NOME, erro, tam_erro, "nome perigoso no zip: %.200s", nome);
      goto fim;
    }
    if((feito >> 8) == 3 && ((externos >> 16) & 0170000) == 0120000) {
      r = falha(ZIP_E_LINK, erro, tam_erro, "link simbolico no zip: %.200s", nome);
      goto fim;
    }
    if(flags & 0x41) {
      r = falha(ZIP_E_METODO, erro, tam_erro, "arquivo cifrado no zip: %.200s", nome);
      goto fim;
    }
    if((metodo != 0 && metodo != 8) || (metodo == 0 && comp != tam) || (en->pasta && tam)) {
      r = falha(ZIP_E_METODO, erro, tam_erro, "metodo de compressao nao suportado: %.200s", nome);
      goto fim;
    }
    if(tam > 1024 * 1024 && (uint64_t)comp * ZIP_MAX_RAZAO < tam) {
      r = falha(ZIP_E_LIMITE, erro, tam_erro, "razao de compressao absurda (bomba?): %.200s", nome);
      goto fim;
    }
    if((uint64_t)local + 30 + comp > off_cd) {
      falha(r, erro, tam_erro, "dados fora do arquivo (zip truncado?): %.200s", nome);
      goto fim;
    }
    z->total += tam;
    if(z->total > max_total) {
      r = falha(ZIP_E_LIMITE, erro, tam_erro, "conteudo do zip grande demais%s", NULL);
      goto fim;
    }
    if(!(en->nome = en->nome_zip = strdup(nome))) {
      r = falha(ZIP_E_MEMORIA, erro, tam_erro, "sem memoria%s", NULL);
      goto fim;
    }
    en->metodo = metodo;
    en->crc = crc;
    en->comp = comp;
    en->tam = tam;
    en->off_local = local;
    z->n++;
    p += 46 + (size_t)n_nome + n_extra + n_coment;
  }

  /* nomes repetidos (inclusive "a" e "a/" - pasta e arquivo com o mesmo nome) */
  if(z->n > 1) {
    if(!(ordem = malloc(z->n * sizeof *ordem))) {
      r = falha(ZIP_E_MEMORIA, erro, tam_erro, "sem memoria%s", NULL);
      goto fim;
    }
    for(uint32_t i = 0; i < z->n; i++) ordem[i] = &z->e[i];
    qsort(ordem, z->n, sizeof *ordem, comparar_nomes);
    for(uint32_t i = 1; i < z->n; i++) {
      if(!strcmp(ordem[i]->nome, ordem[i - 1]->nome) && !(ordem[i]->pasta && ordem[i - 1]->pasta)) {
        r = falha(ZIP_E_NOME, erro, tam_erro, "nome repetido no zip: %.200s", ordem[i]->nome);
        goto fim;
      }
    }
  }
  r = ZIP_OK;
fim:
  free(cauda);
  free(cd);
  free(ordem);
  if(r) zip_fechar(z);
  return r;
}

int zip_pasta_topo(const zip_t *z, char *saida, size_t tam) {
  if(!z->n) return 0;
  const char *primeiro = z->e[0].nome;
  size_t n = strcspn(primeiro, "/");
  for(uint32_t i = 0; i < z->n; i++) {
    const zip_entrada_t *e = &z->e[i];
    int dentro = !strncmp(e->nome, primeiro, n) && e->nome[n] == '/';
    int e_ela = e->pasta && strlen(e->nome) == n && !strncmp(e->nome, primeiro, n);
    if(!dentro && !e_ela) return 0;
  }
  if(n + 1 > tam) return 0;
  memcpy(saida, primeiro, n);
  saida[n] = 0;
  return 1;
}

void zip_tirar_pasta_topo(zip_t *z, const char *pasta) {
  size_t n = strlen(pasta);
  uint32_t k = 0;
  for(uint32_t i = 0; i < z->n; i++) {
    zip_entrada_t e = z->e[i];
    if(strncmp(e.nome, pasta, n) || e.nome[n] != '/') {   /* a propria pasta de topo */
      free(e.nome_zip);
      continue;
    }
    e.nome += n + 1;
    z->e[k++] = e;
  }
  z->n = k;
}

const zip_entrada_t *zip_achar(const zip_t *z, const char *nome) {
  for(uint32_t i = 0; i < z->n; i++) {
    if(!strcmp(z->e[i].nome, nome)) return &z->e[i];
  }
  return NULL;
}

/* Recebe os bytes descomprimidos de uma entrada; 0 = continuar. */
typedef int (*destino_t)(const void *dados, size_t n, void *ctx);

/* Descomprime uma entrada para "destino", conferindo tamanho e CRC. */
static int extrair_entrada(zip_t *z, const zip_entrada_t *e, destino_t destino, void *ctx, char *erro, size_t tam_erro) {
  uint8_t l[30];
  if(ler_em(z->fd, e->off_local, l, sizeof l) || le32(l) != SIG_LOCAL)
    return falha(ZIP_E_FORMATO, erro, tam_erro, "cabecalho local invalido: %.200s", e->nome);
  uint16_t n_nome = le16(l + 26), n_extra = le16(l + 28);
  size_t n_esperado = strlen(e->nome_zip);
  char nome_local[ZIP_MAX_NOME + 1];
  if(n_nome < n_esperado || n_nome > n_esperado + 1 || ler_em(z->fd, e->off_local + 30, nome_local, n_nome) ||
     memcmp(nome_local, e->nome_zip, n_esperado))
    return falha(ZIP_E_FORMATO, erro, tam_erro, "nome do cabecalho local diferente: %.200s", e->nome);
  uint64_t dados = e->off_local + 30 + n_nome + n_extra;
  if(dados + e->comp > z->inicio_cd) return falha(ZIP_E_FORMATO, erro, tam_erro, "dados fora do arquivo: %.200s", e->nome);

  int r = ZIP_OK;
  uint32_t crc = (uint32_t)MZ_CRC32_INIT;
  uint64_t feitos = 0, restante = e->comp;
  uint8_t *entrada = malloc(BLOCO), *saida = NULL;
  tinfl_decompressor *dec = NULL;
  if(!entrada) return falha(ZIP_E_MEMORIA, erro, tam_erro, "sem memoria%s", NULL);

  if(e->metodo == 0) {
    while(restante) {
      size_t n = restante < BLOCO ? (size_t)restante : BLOCO;
      if(ler_em(z->fd, dados, entrada, n)) {
        r = falha(ZIP_E_ABRIR, erro, tam_erro, "erro de leitura: %.200s", e->nome);
        goto fim;
      }
      crc = (uint32_t)mz_crc32(crc, entrada, n);
      if(destino(entrada, n, ctx)) {
        r = falha(ZIP_E_GRAVAR, erro, tam_erro, "nao gravou: %.200s", e->nome);
        goto fim;
      }
      dados += n;
      restante -= n;
      feitos += n;
    }
  } else {
    /* deflate em fluxo: entrada em blocos de 64 KB, saida num dicionario circular de 32 KB */
    if(!(saida = malloc(TINFL_LZ_DICT_SIZE)) || !(dec = malloc(sizeof *dec))) {
      r = falha(ZIP_E_MEMORIA, erro, tam_erro, "sem memoria%s", NULL);
      goto fim;
    }
    tinfl_init(dec);
    size_t na_entrada = 0, pos_entrada = 0, pos_saida = 0;
    int parado = 0;
    for(;;) {
      if(!na_entrada && restante) {
        size_t n = restante < BLOCO ? (size_t)restante : BLOCO;
        if(ler_em(z->fd, dados, entrada, n)) {
          r = falha(ZIP_E_ABRIR, erro, tam_erro, "erro de leitura: %.200s", e->nome);
          goto fim;
        }
        dados += n;
        restante -= n;
        pos_entrada = 0;
        na_entrada = n;
      }
      size_t n_ent = na_entrada, n_sai = TINFL_LZ_DICT_SIZE - pos_saida;
      tinfl_status st = tinfl_decompress(dec, entrada + pos_entrada, &n_ent, saida, saida + pos_saida, &n_sai,
                                         restante ? TINFL_FLAG_HAS_MORE_INPUT : 0);
      pos_entrada += n_ent;
      na_entrada -= n_ent;
      if(n_sai) {
        feitos += n_sai;
        if(feitos > e->tam) {   /* infla alem do declarado: bomba ou zip adulterado */
          r = falha(ZIP_E_DADOS, erro, tam_erro, "dados maiores que o tamanho declarado: %.200s", e->nome);
          goto fim;
        }
        crc = (uint32_t)mz_crc32(crc, saida + pos_saida, n_sai);
        if(destino(saida + pos_saida, n_sai, ctx)) {
          r = falha(ZIP_E_GRAVAR, erro, tam_erro, "nao gravou: %.200s", e->nome);
          goto fim;
        }
        pos_saida = (pos_saida + n_sai) & (TINFL_LZ_DICT_SIZE - 1);
      }
      if(st == TINFL_STATUS_DONE) break;
      parado = (!n_ent && !n_sai) ? parado + 1 : 0;
      if(st < 0 || parado > 2 || (st == TINFL_STATUS_NEEDS_MORE_INPUT && !na_entrada && !restante)) {
        r = falha(ZIP_E_DADOS, erro, tam_erro, "dados comprimidos invalidos ou truncados: %.200s", e->nome);
        goto fim;
      }
    }
  }
  if(feitos != e->tam) r = falha(ZIP_E_DADOS, erro, tam_erro, "tamanho diferente do declarado: %.200s", e->nome);
  else if(crc != e->crc) r = falha(ZIP_E_CRC, erro, tam_erro, "CRC-32 nao confere: %.200s", e->nome);
fim:
  free(entrada);
  free(saida);
  free(dec);
  return r;
}

typedef struct {
  buf_t *b;
  size_t max;
} para_buf_t;

static int gravar_buf(const void *dados, size_t n, void *ctx) {
  para_buf_t *p = ctx;
  if(p->b->n + n > p->max) return -1;
  buf_add(p->b, dados, n);
  return 0;
}

int zip_ler(zip_t *z, const zip_entrada_t *e, buf_t *saida, size_t max, char *erro, size_t tam_erro) {
  if(e->pasta) return falha(ZIP_E_FORMATO, erro, tam_erro, "e uma pasta: %.200s", e->nome);
  if(e->tam > max) return falha(ZIP_E_LIMITE, erro, tam_erro, "arquivo grande demais: %.200s", e->nome);
  para_buf_t p = {saida, max};
  return extrair_entrada(z, e, gravar_buf, &p, erro, tam_erro);
}

typedef struct {
  int fd;
  uint64_t *feitos, total;
  zip_progresso_t progresso;
  void *ctx;
} para_arquivo_t;

static int gravar_arquivo(const void *dados, size_t n, void *ctx) {
  para_arquivo_t *p = ctx;
  for(size_t gravados = 0; gravados < n;) {
    ssize_t r = write(p->fd, (const char *)dados + gravados, n - gravados);
    if(r <= 0) return -1;
    gravados += (size_t)r;
  }
  *p->feitos += n;
  if(p->progresso) p->progresso(*p->feitos, p->total, p->ctx);
  return 0;
}

/* Cria a pasta (ja existir e ok, se for pasta de verdade e nao um link). */
static int criar_pasta(const char *caminho) {
  if(!mkdir(caminho, 0755)) return 0;
  struct stat st;
  return errno == EEXIST && !lstat(caminho, &st) && S_ISDIR(st.st_mode) ? 0 : -1;
}

int zip_extrair(zip_t *z, const char *destino, zip_progresso_t progresso, void *ctx, char *erro, size_t tam_erro) {
  uint64_t feitos = 0;
  char caminho[1200];
  for(uint32_t i = 0; i < z->n; i++) {
    const zip_entrada_t *e = &z->e[i];
    int n = snprintf(caminho, sizeof caminho, "%s/%s", destino, e->nome);
    if(n < 0 || (size_t)n >= sizeof caminho) return falha(ZIP_E_NOME, erro, tam_erro, "caminho longo demais: %.200s", e->nome);
    /* pastas do caminho, uma a uma */
    size_t base = strlen(destino) + 1;
    for(char *b = caminho + base; (b = strchr(b, '/')); b++) {
      *b = 0;
      int r = criar_pasta(caminho);
      *b = '/';
      if(r) return falha(ZIP_E_GRAVAR, erro, tam_erro, "nao criou a pasta de %.200s", e->nome);
    }
    if(e->pasta) {
      if(criar_pasta(caminho)) return falha(ZIP_E_GRAVAR, erro, tam_erro, "nao criou a pasta %.200s", e->nome);
      continue;
    }
    int fd = open(caminho, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644);
    if(fd < 0) return falha(ZIP_E_GRAVAR, erro, tam_erro, "nao criou o arquivo %.200s", e->nome);
    para_arquivo_t p = {fd, &feitos, z->total, progresso, ctx};
    int r = extrair_entrada(z, e, gravar_arquivo, &p, erro, tam_erro);
    if(close(fd) && !r) r = falha(ZIP_E_GRAVAR, erro, tam_erro, "nao gravou %.200s", e->nome);
    if(r) return r;
  }
  return ZIP_OK;
}
