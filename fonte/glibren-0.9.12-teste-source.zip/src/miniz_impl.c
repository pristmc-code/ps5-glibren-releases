/* Game Library Renamer (payload PS5) - o miniz (terceiros/miniz.c, MIT) compilado uma unica vez, com a configuracao
   de miniz_cfg.h (so inflate e crc32). Usado por fmt_pfs.c e zip.c. */
#include "miniz_cfg.h"

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Weverything"
#include "terceiros/miniz.c"
#pragma clang diagnostic pop
