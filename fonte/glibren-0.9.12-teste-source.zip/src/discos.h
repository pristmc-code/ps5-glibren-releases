/* Game Library Renamer (payload PS5) - discos montados e teste de velocidade (gravacao e leitura). */
#pragma once

#include "util.h"

void discos_listar(buf_t *json);
/* Apaga arquivos de teste que tenham sobrado (PS5 desligado no meio de um teste). Chamar ao iniciar. */
void discos_limpar_sobras(void);
/* Inicia o teste numa thread. 0 = iniciou, -1 = caminho invalido/ja tem teste rodando (msg). */
int discos_testar(const char *caminho, int tamanho_mb, char *msg, size_t tam);
void discos_cancelar(void);
int discos_testando(void);   /* 1 se um teste de velocidade esta rodando */
void discos_estado(buf_t *json);
