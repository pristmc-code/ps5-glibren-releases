/* Game Library Renamer (payload PS5) - fila de tarefas: copiar, mover e excluir arquivos.

Seguranca:
- nunca sobrescreve: se o destino ja existe, a tarefa falha;
- a copia vai para "<nome>.glr-part" e so ganha o nome final no fim (copia interrompida nunca parece completa). O
  sufixo e so nosso: uma sobra de copia interrompida (queda, payload parado) e apagada ao iniciar e ao tentar de novo,
  sem nunca tocar no ".part" de outro programa;
- os dados vao para o disco (fsync) a cada 256 MB e no fim, antes do rename: mover entre discos so apaga a origem
  depois disso (uma gaveta USB que cai logo depois do "Movido" nao leva o jogo junto);
- antes de copiar confere o espaco livre no destino;
- mover no mesmo disco e so um rename (instantaneo); entre discos copia e so apaga a origem se o tamanho bate;
- excluir so apaga arquivo comum (nunca pasta);
- arquivo em download (sufixo temporario ou controle ao lado, como no renomear) nao e copiado, movido nem excluido.
*/
#include "tarefas.h"

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#include "arquivos.h"
#include "config.h"
#include "plataforma.h"

#define MAX_TAREFAS 200
#define BLOCO (8 * 1024 * 1024)
#define SYNC_BYTES (256LL * 1024 * 1024)   /* fsync a cada 256 MB gravados */

typedef enum { EST_FILA, EST_RODANDO, EST_FEITA, EST_ERRO, EST_CANCELADA } estado_t;

typedef struct {
  int id;
  tarefa_tipo_t tipo;
  estado_t estado;
  char pasta[1024], nome[256], destino[1024], para[256];
  long long total, feito;
  double inicio, fim, velocidade;   /* velocidade: bytes/s (media movel) */
  char erro[256];
  volatile int cancelar;
} tarefa_t;

static tarefa_t *g_tarefas[MAX_TAREFAS];   /* cada uma alocada: limpar a lista nao move a que esta rodando */
static int g_qtd, g_proximo_id = 1;
static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t g_sinal = PTHREAD_COND_INITIALIZER;

static double agora(void) {
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec / 1e6;
}

static void juntar(char *saida, size_t tam, const char *pasta, const char *nome) {
  size_t n = strlen(pasta);
  snprintf(saida, tam, "%s%s%s", pasta, (n && pasta[n - 1] == '/') ? "" : "/", nome);
}

static const char *TIPOS[] = {"copiar", "mover", "excluir"};
static const char *ESTADOS[] = {"fila", "rodando", "feita", "erro", "cancelada"};

/* ------------------------------------------------------------------ execucao */

/* Copia origem -> destino (via SUFIXO_PARCIAL). Devolve 0 ou -1 (t->erro preenchido). */
static int copiar_arquivo(tarefa_t *t, const char *origem, const char *destino) {
  char parcial[1400];
  snprintf(parcial, sizeof parcial, "%s" SUFIXO_PARCIAL, destino);
  struct stat st;
  /* so existe uma copia por vez (um trabalhador): um parcial nosso que ja esta la e sobra de uma copia interrompida */
  if(!lstat(parcial, &st) && S_ISREG(st.st_mode)) {
    if(unlink(parcial)) {
      snprintf(t->erro, sizeof t->erro, "sobra de copia anterior que nao saiu: %s", strerror(errno));
      return -1;
    }
    diario("tarefas: apagada a sobra de uma copia interrompida: %s", parcial);
  }
  int in = open(origem, O_RDONLY);
  if(in < 0) {
    snprintf(t->erro, sizeof t->erro, "nao abriu a origem: %s", strerror(errno));
    return -1;
  }
  int out = open(parcial, O_WRONLY | O_CREAT | O_EXCL, 0666);
  if(out < 0) {
    snprintf(t->erro, sizeof t->erro, "nao criou o arquivo no destino: %s", strerror(errno));
    close(in);
    return -1;
  }
  char *buf = malloc(BLOCO);
  int r = 0;
  if(!buf) {
    r = -1;
    snprintf(t->erro, sizeof t->erro, "sem memoria para copiar");
  }
  double marca = agora();
  long long feito_marca = 0, desde_sync = 0;
  while(buf) {
    if(t->cancelar) {
      r = -1;
      snprintf(t->erro, sizeof t->erro, "cancelada");
      break;
    }
    ssize_t n = read(in, buf, BLOCO);
    if(n < 0 && errno == EINTR) continue;
    if(n < 0) {
      r = -1;
      snprintf(t->erro, sizeof t->erro, "erro de leitura: %s", strerror(errno));
      break;
    }
    if(n == 0) break;
    for(ssize_t w = 0; w < n;) {
      ssize_t k = write(out, buf + w, n - w);
      if(k < 0 && errno == EINTR) continue;
      if(k <= 0) {
        r = -1;
        snprintf(t->erro, sizeof t->erro, "erro de gravacao: %s", errno == ENOSPC ? "disco cheio" : strerror(errno));
        break;
      }
      w += k;
    }
    if(r) break;
    desde_sync += n;
    if(desde_sync >= SYNC_BYTES) {   /* o que ja foi gravado vai para o disco; um erro aqui aparece agora, nao no fim */
      desde_sync = 0;
      if(fsync(out)) {
        r = -1;
        snprintf(t->erro, sizeof t->erro, "erro de gravacao no disco: %s", strerror(errno));
        break;
      }
    }
#ifndef __PROSPERO__
    /* So no PC (demo): GLR_DEMO_MBPS limita a velocidade para dar para ver o painel de atividade. */
    static int limite = -1;
    if(limite < 0) limite = getenv("GLR_DEMO_MBPS") ? atoi(getenv("GLR_DEMO_MBPS")) : 0;
    if(limite > 0) usleep((useconds_t)((double)n / (limite * 1048576.0) * 1e6));
#endif
    pthread_mutex_lock(&g_trava);
    t->feito += n;
    double d = agora() - marca;
    if(d >= 1.0) {   /* velocidade a cada ~1 s, suavizada */
      double v = (t->feito - feito_marca) / d;
      t->velocidade = t->velocidade > 0 ? t->velocidade * 0.6 + v * 0.4 : v;
      marca = agora();
      feito_marca = t->feito;
    }
    pthread_mutex_unlock(&g_trava);
  }
  free(buf);
  close(in);
  if(!r && fsync(out)) {   /* tudo no disco antes do rename (e, no mover, antes de apagar a origem) */
    r = -1;
    snprintf(t->erro, sizeof t->erro, "erro de gravacao no disco: %s", strerror(errno));
  }
  if(close(out) && !r) {
    r = -1;
    snprintf(t->erro, sizeof t->erro, "erro ao fechar o destino: %s", strerror(errno));
  }
  if(!r && (lstat(parcial, &st) || st.st_size != t->total)) {
    r = -1;
    snprintf(t->erro, sizeof t->erro, "tamanho da copia nao confere");
  }
  if(!r && !lstat(destino, &st)) {   /* apareceu algo com o nome final durante a copia */
    r = -1;
    snprintf(t->erro, sizeof t->erro, "ja existe '%s' no destino", t->para[0] ? t->para : t->nome);
  }
  if(!r && rename(parcial, destino)) {
    r = -1;
    snprintf(t->erro, sizeof t->erro, "nao renomeou o arquivo parcial: %s", strerror(errno));
  }
  if(r) unlink(parcial);
  return r;
}

/* Arquivo de download que ainda nao pode ser mexido. Copiar/mover: qualquer download (um parcial nao serve para
   nada no destino). Excluir: so o que foi gravado nos ultimos 15 min (baixando agora); o parcial parado de um download
   abandonado continua podendo ser apagado. */
static int download_bloqueia(tarefa_tipo_t tipo, const char *pasta, const char *nome) {
  if(!em_download(pasta, nome)) return 0;
  if(tipo != TAR_EXCLUIR) return 1;
  char completo[1400];
  struct stat st;
  juntar(completo, sizeof completo, pasta, nome);
  return !lstat(completo, &st) && time(NULL) - st.st_mtime < 15 * 60;
}

static void marcar_feito(tarefa_t *t) {
  pthread_mutex_lock(&g_trava);
  t->feito = t->total;
  pthread_mutex_unlock(&g_trava);
}

/* Executa e devolve o estado final. Quem grava o estado e o trabalhador, com a trava: enquanto a tarefa estiver
   "rodando" ninguem a tira da lista (remover_terminadas so libera as terminadas). */
static estado_t executar(tarefa_t *t) {
  char origem[1400], destino[1400];
  struct stat st, st_dest;
  juntar(origem, sizeof origem, t->pasta, t->nome);

  if(lstat(origem, &st) || !S_ISREG(st.st_mode)) {
    snprintf(t->erro, sizeof t->erro, "'%s' nao existe mais", t->nome);
    return EST_ERRO;
  }
  pthread_mutex_lock(&g_trava);
  t->total = st.st_size;
  pthread_mutex_unlock(&g_trava);
  /* pode ter comecado a baixar depois de entrar na fila */
  if(download_bloqueia(t->tipo, t->pasta, t->nome)) {
    snprintf(t->erro, sizeof t->erro, "'%s' esta sendo baixado", t->nome);
    return EST_ERRO;
  }

  if(t->tipo == TAR_EXCLUIR) {
    if(unlink(origem)) {
      snprintf(t->erro, sizeof t->erro, "nao excluiu: %s", strerror(errno));
      return EST_ERRO;
    }
    marcar_feito(t);
    return EST_FEITA;
  }

  juntar(destino, sizeof destino, t->destino, t->para[0] ? t->para : t->nome);
  if(stat(t->destino, &st_dest) || !S_ISDIR(st_dest.st_mode)) {
    snprintf(t->erro, sizeof t->erro, "a pasta de destino nao existe");
    return EST_ERRO;
  }
  if(!lstat(destino, &st_dest)) {
    snprintf(t->erro, sizeof t->erro, "ja existe '%s' no destino", t->para[0] ? t->para : t->nome);
    return EST_ERRO;
  }

  /* mover no mesmo disco: so muda o caminho */
  struct stat pasta_dest;
  if(t->tipo == TAR_MOVER && !stat(t->destino, &pasta_dest) && pasta_dest.st_dev == st.st_dev) {
    if(rename(origem, destino)) {
      snprintf(t->erro, sizeof t->erro, "nao moveu: %s", strerror(errno));
      return EST_ERRO;
    }
    marcar_feito(t);
    return EST_FEITA;
  }

  struct statvfs vfs;
  if(!statvfs(t->destino, &vfs) && (long long)vfs.f_bavail * (long long)vfs.f_frsize < t->total) {
    snprintf(t->erro, sizeof t->erro, "sem espaco no destino");
    return EST_ERRO;
  }

  if(copiar_arquivo(t, origem, destino)) return t->cancelar ? EST_CANCELADA : EST_ERRO;
  if(t->tipo == TAR_MOVER && unlink(origem)) {
    snprintf(t->erro, sizeof t->erro, "copiou, mas nao apagou a origem: %s", strerror(errno));
    return EST_ERRO;
  }
  return EST_FEITA;
}

static void *trabalhador(void *arg) {
  (void)arg;
  int feitas = 0, erros = 0;
  for(;;) {
    pthread_mutex_lock(&g_trava);
    tarefa_t *t = NULL;
    for(int i = 0; i < g_qtd && !t; i++) {
      if(g_tarefas[i]->estado == EST_FILA) t = g_tarefas[i];
    }
    if(!t) {
      /* fila vazia: avisa na tela do PS5 o resultado do lote */
      if(feitas || erros) {
        if(erros) notificar("Game Library Renamer: %d tarefa(s) concluida(s), %d com erro", feitas, erros);
        else notificar("Game Library Renamer: %d tarefa(s) concluida(s)", feitas);
        feitas = erros = 0;
      }
      pthread_cond_wait(&g_sinal, &g_trava);
      pthread_mutex_unlock(&g_trava);
      continue;
    }
    t->estado = EST_RODANDO;
    t->inicio = agora();
    pthread_mutex_unlock(&g_trava);

    estado_t final = executar(t);

    pthread_mutex_lock(&g_trava);   /* estado e fim juntos: so depois disto a tarefa pode sair da lista */
    t->estado = final;
    t->fim = agora();
    if(final == EST_FEITA) feitas++;
    else if(final == EST_ERRO) erros++;
    pthread_mutex_unlock(&g_trava);
  }
  return NULL;
}

/* ------------------------------------------------------------------ fila */

/* Sobras de copias interrompidas (console desligado, payload parado ou atualizado no meio): apagadas ao iniciar,
   na raiz de cada pasta da lista. So o nosso sufixo; o ".part" de outros programas nunca e tocado. */
static void limpar_sobras(void) {
  char pastas[MAX_PASTAS][1024], completo[1400];
  int qtd = config_ler(pastas, NULL);
  size_t s = strlen(SUFIXO_PARCIAL);
  for(int i = 0; i < qtd; i++) {
    DIR *d = opendir(pastas[i]);
    struct dirent *e;
    while(d && (e = readdir(d))) {
      size_t n = strlen(e->d_name);
      if(n <= s || strcmp(e->d_name + n - s, SUFIXO_PARCIAL)) continue;
      juntar(completo, sizeof completo, pastas[i], e->d_name);
      struct stat st;
      if(!lstat(completo, &st) && S_ISREG(st.st_mode) && !unlink(completo))
        diario("tarefas: apagada a sobra de uma copia interrompida: %s", completo);
    }
    if(d) closedir(d);
  }
}

void tarefas_iniciar(void) {
  limpar_sobras();
  criar_thread(trabalhador, NULL, NULL);
}

/* Tira da lista as terminadas (todas, ou so as mais antigas ate sobrar espaco). Chamar com a trava. */
static void remover_terminadas(int todas) {
  int j = 0, removidas = 0;
  for(int i = 0; i < g_qtd; i++) {
    tarefa_t *t = g_tarefas[i];
    if(t->estado >= EST_FEITA && (todas || removidas < 20)) {
      free(t);
      removidas++;
      continue;
    }
    g_tarefas[j++] = t;
  }
  g_qtd = j;
}

int tarefas_adicionar(tarefa_tipo_t tipo, const char *pasta, const char *nome, const char *destino, const char *para) {
  if(!caminho_valido(pasta) || !nome_valido(nome)) return TAR_R_INVALIDO;
  if(tipo != TAR_EXCLUIR && (!caminho_valido(destino) || (*para && !nome_valido(para)))) return TAR_R_INVALIDO;
  if(download_bloqueia(tipo, pasta, nome)) return TAR_R_EM_DOWNLOAD;
  pthread_mutex_lock(&g_trava);
  if(g_qtd >= MAX_TAREFAS) remover_terminadas(0);
  tarefa_t *t = g_qtd < MAX_TAREFAS ? calloc(1, sizeof *t) : NULL;
  if(!t) {
    pthread_mutex_unlock(&g_trava);
    return TAR_R_FILA_CHEIA;
  }
  g_tarefas[g_qtd++] = t;
  t->id = g_proximo_id++;
  t->tipo = tipo;
  t->estado = EST_FILA;
  snprintf(t->pasta, sizeof t->pasta, "%s", pasta);
  snprintf(t->nome, sizeof t->nome, "%s", nome);
  snprintf(t->destino, sizeof t->destino, "%s", tipo == TAR_EXCLUIR ? "" : destino);
  snprintf(t->para, sizeof t->para, "%s", (tipo == TAR_EXCLUIR || !strcmp(para, nome)) ? "" : para);
  /* tamanho ja na fila, para a tela mostrar o total do lote */
  char origem[1400];
  struct stat st;
  juntar(origem, sizeof origem, pasta, nome);
  if(!lstat(origem, &st)) t->total = st.st_size;
  int id = t->id;
  pthread_cond_signal(&g_sinal);
  pthread_mutex_unlock(&g_trava);
  return id;
}

int tarefas_cancelar(int id) {
  int r = -1;
  pthread_mutex_lock(&g_trava);
  for(int i = 0; i < g_qtd; i++) {
    tarefa_t *t = g_tarefas[i];
    if(t->id != id) continue;
    if(t->estado == EST_FILA) {
      t->estado = EST_CANCELADA;
      r = 0;
    } else if(t->estado == EST_RODANDO) {
      t->cancelar = 1;
      r = 0;
    }
  }
  pthread_mutex_unlock(&g_trava);
  return r;
}

int tarefas_cancelar_todas(void) {
  int n = 0;
  pthread_mutex_lock(&g_trava);
  for(int i = 0; i < g_qtd; i++) {
    tarefa_t *t = g_tarefas[i];
    if(t->estado == EST_FILA) {
      t->estado = EST_CANCELADA;
      n++;
    } else if(t->estado == EST_RODANDO) {
      t->cancelar = 1;
      n++;
    }
  }
  pthread_mutex_unlock(&g_trava);
  return n;
}

int tarefas_tem(const char *pasta, const char *nome) {
  int r = 0;
  pthread_mutex_lock(&g_trava);
  for(int i = 0; i < g_qtd && !r; i++) {
    tarefa_t *t = g_tarefas[i];
    r = t->estado <= EST_RODANDO && !strcmp(t->pasta, pasta) && !strcmp(t->nome, nome);
  }
  pthread_mutex_unlock(&g_trava);
  return r;
}

int tarefas_copiando(void) {
  int r = 0;
  pthread_mutex_lock(&g_trava);
  for(int i = 0; i < g_qtd && !r; i++) r = g_tarefas[i]->estado <= EST_RODANDO && g_tarefas[i]->tipo != TAR_EXCLUIR;
  pthread_mutex_unlock(&g_trava);
  return r;
}

int tarefas_ativas(void) {
  int n = 0;
  pthread_mutex_lock(&g_trava);
  for(int i = 0; i < g_qtd; i++) n += g_tarefas[i]->estado <= EST_RODANDO;
  pthread_mutex_unlock(&g_trava);
  return n;
}

long long tarefas_reservado(const char *destino) {
  long long soma = 0;
  pthread_mutex_lock(&g_trava);
  for(int i = 0; i < g_qtd; i++) {
    tarefa_t *t = g_tarefas[i];
    if(t->estado <= EST_RODANDO && t->tipo != TAR_EXCLUIR && !strcmp(t->destino, destino) && t->total > t->feito)
      soma += t->total - t->feito;
  }
  pthread_mutex_unlock(&g_trava);
  return soma;
}

void tarefas_limpar_terminadas(void) {
  pthread_mutex_lock(&g_trava);
  remover_terminadas(1);
  pthread_mutex_unlock(&g_trava);
}

void tarefas_json(buf_t *b) {
  pthread_mutex_lock(&g_trava);
  double t0 = agora();
  buf_str(b, "{\"ok\":true,\"tarefas\":[");
  for(int i = 0; i < g_qtd; i++) {
    tarefa_t *t = g_tarefas[i];
    buf_fmt(b, "%s{\"id\":%d,\"tipo\":\"%s\",\"estado\":\"%s\",\"pasta\":", i ? "," : "", t->id, TIPOS[t->tipo], ESTADOS[t->estado]);
    buf_json(b, t->pasta);
    buf_str(b, ",\"nome\":");
    buf_json(b, t->nome);
    buf_str(b, ",\"destino\":");
    buf_json(b, t->destino);
    buf_str(b, ",\"para\":");
    buf_json(b, t->para);
    double duracao = t->estado == EST_RODANDO ? t0 - t->inicio : (t->fim > t->inicio ? t->fim - t->inicio : 0);
    buf_fmt(b, ",\"total\":%lld,\"feito\":%lld,\"velocidade\":%.0f,\"duracao\":%.1f,\"erro\":", t->total, t->feito,
            t->velocidade, duracao);
    buf_json(b, t->erro);
    buf_str(b, "}");
  }
  buf_str(b, "]}");
  pthread_mutex_unlock(&g_trava);
}
