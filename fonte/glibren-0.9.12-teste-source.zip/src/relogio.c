/* Game Library Renamer (payload PS5) - relogio do PS5 pela internet.

Por que: sem a PSN (DNS da Sony bloqueado, comum no PS5 desbloqueado) o PS5 nunca acerta a hora sozinho e o relogio
vai adiantando/atrasando; o YouTube e os sites HTTPS reclamam. O que vale e a hora UTC: o fuso (Configuracoes >
Sistema > Data e hora) continua o que o usuario escolheu no PS5 - aqui so lemos o fuso para mostrar.

Fontes (cada uma vale um voto; e preciso maioria e pelo menos duas concordando a menos de 3 s):
  - NTP (UDP 123) pelo IP, sem depender de DNS: Cloudflare, NTP.br e Google (um voto por provedor; tenta os IPs
    de cada um em ordem). IPs conferidos em 10/11/2026.
  - cabecalho Date de https://speed.cloudflare.com (reserva: raw.githubusercontent.com), precisao de ~1 s.
Acerto (so no PS5): como os payloads abertos ps5-time-sync (uzergit) e PS5-Sync-Clock (Zubastic): authid de sistema
por um instante, clock_settime nos dominios do RTC 17 (rede/NP) e 16 (usuario), settimeofday (no FreeBSD tambem grava
o RTC: fica certo depois de reiniciar - confirmado no PS5 pelo ps5-time-sync) e volta o authid de antes.
No PC (teste) nada muda no relogio do sistema: o "relogio do PS5" e simulado (hora real + GLR_TESTE_RELOGIO_DESVIO).
*/
#include "relogio.h"

#include <arpa/inet.h>
#include <errno.h>
#include <math.h>
#include <netinet/in.h>
#include <pthread.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#include "config.h"
#include "https.h"
#include "plataforma.h"

#ifdef __PROSPERO__
#include <ps5/kernel.h>
#define AUTHID_SISTEMA 0x4800000000010003ULL   /* o kernel pede este authid para gravar os dominios 16/17 */
int sceKernelConvertUtcToLocaltime(time_t, time_t *, void *, unsigned long *) __attribute__((weak));
#endif

#define LIMITE_S 30              /* diferenca a partir da qual acerta */
#define CONCORDA_S 3.0           /* duas fontes "concordam" se a diferenca entre elas for menor que isso */
#define INTERVALO_S (6 * 3600)   /* conferencia periodica */
#define REPETIR_S (10 * 60)      /* sem internet / fontes discordando: tenta de novo antes */
/* R5 (0.9.12): falhas seguidas dobram a espera (10, 20, 40 min...) ate INTERVALO_S; o aviso de "nao acertou" sai
   so na primeira falha seguida (antes saia a cada 10 min, sem fim, se o PS5 recusasse o acerto). */
#define ESPERA_INICIO_S 20       /* a rede ainda esta subindo logo depois de carregar o payload */
#define ESPERA_ACORDAR_S 20      /* depois do modo de repouso */
#define ANO_2025 1735689600.0    /* resposta fora de 2025..2040 = absurda, ignorada */
#define ANO_2040 2208988800.0
#define NTP_EPOCA 2208988800.0   /* 1900 -> 1970 */
#define MAX_FONTES 6

typedef struct {
  char nome[40];
  int ok, concorda;
  double desvio;   /* hora certa - relogio do PS5, em segundos */
  char erro[64];
} fonte_t;

static const struct {
  const char *nome;
  const char *ips[4];
} NTP[] = {
  {"Cloudflare (NTP)", {"162.159.200.1", "162.159.200.123", NULL}},
  {"NTP.br (NTP)", {"200.160.7.186", "201.49.148.135", "200.20.186.76", NULL}},
  {"Google (NTP)", {"216.239.35.0", "216.239.35.4", "216.239.35.8", NULL}},
};
static const char *URL_DATA[] = {"https://speed.cloudflare.com/__down?bytes=0", "https://raw.githubusercontent.com/", NULL};

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;            /* estado abaixo */
static pthread_mutex_t g_trava_conferir = PTHREAD_MUTEX_INITIALIZER;   /* uma conferencia por vez */
static int g_auto = 1, g_conferindo, g_ajustes;
static char g_situacao[24] = "nunca", g_detalhe[300];
static double g_quando, g_diferenca, g_ultimo_ajuste, g_ultimo_ajuste_dif;
static fonte_t g_fontes[MAX_FONTES];
static int g_qtd_fontes;
static volatile sig_atomic_t g_acordou;
static int g_espera_inicio = ESPERA_INICIO_S;
static int g_falhas_acerto;   /* acertos seguidos que falharam (aviso so no primeiro) */
static int g_falhas_seguidas; /* conferencias seguidas sem "certo"/"ajustado" (espera maior) */

#ifndef __PROSPERO__
static double g_simulado;   /* PC: relogio do "PS5" = hora real + g_simulado */
#endif

/* Relogio do PS5 (UTC), em segundos. */
static double agora(void) {
  struct timeval tv;
  gettimeofday(&tv, NULL);
  double t = tv.tv_sec + tv.tv_usec / 1e6;
#ifndef __PROSPERO__
  t += g_simulado;
#endif
  return t;
}

static double monotonico(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return ts.tv_sec + ts.tv_nsec / 1e9;
}

/* ------------------------------------------------------------------ fontes */

static double ntp_ler(const uint8_t *p) {
  uint32_t s = (uint32_t)p[0] << 24 | (uint32_t)p[1] << 16 | (uint32_t)p[2] << 8 | p[3];
  uint32_t f = (uint32_t)p[4] << 24 | (uint32_t)p[5] << 16 | (uint32_t)p[6] << 8 | p[7];
  if(!s && !f) return 0;
  double seg = s;
  if(seg < NTP_EPOCA) seg += 4294967296.0;   /* era seguinte (depois de 2036) */
  return seg - NTP_EPOCA + f / 4294967296.0;
}

static void ntp_gravar(uint8_t *p, double unix_s) {
  double t = unix_s + NTP_EPOCA;
  uint32_t s = (uint32_t)fmod(t, 4294967296.0);
  uint32_t f = (uint32_t)((t - floor(t)) * 4294967296.0);
  for(int i = 0; i < 4; i++) p[i] = (uint8_t)(s >> (24 - 8 * i)), p[4 + i] = (uint8_t)(f >> (24 - 8 * i));
}

static int sensato(double unix_s) {
  return unix_s > ANO_2025 && unix_s < ANO_2040;
}

/* Uma consulta SNTP (RFC 4330). 0 = ok (desvio = hora do servidor - relogio do PS5). */
static int ntp_perguntar(const char *ip, int porta, double *desvio, char *erro, size_t tam) {
  erro[0] = 0;
  struct sockaddr_in end = {0};
  end.sin_family = AF_INET;
  end.sin_port = htons((unsigned short)porta);
  if(inet_pton(AF_INET, ip, &end.sin_addr) != 1) {
    snprintf(erro, tam, "IP invalido");
    return -1;
  }
  int fd = socket(AF_INET, SOCK_DGRAM, 0);
  if(fd < 0) {
    snprintf(erro, tam, "socket: errno %d", errno);
    return -1;
  }
  struct timeval espera = {2, 0};
  setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &espera, sizeof espera);
  setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &espera, sizeof espera);
  uint8_t pedido[48] = {0x23}, resposta[128];   /* versao 4, modo cliente */
  double t1 = agora();
  ntp_gravar(pedido + 40, t1);   /* volta no campo "originate": confere que a resposta e deste pedido */
  ssize_t n = -1;
  if(sendto(fd, pedido, sizeof pedido, 0, (struct sockaddr *)&end, sizeof end) == (ssize_t)sizeof pedido)
    n = recv(fd, resposta, sizeof resposta, 0);
  double t4 = agora();
  int e = errno;
  close(fd);
  if(n < 48) {
    snprintf(erro, tam, n < 0 ? "sem resposta (errno %d)" : "resposta curta", e);
    return -1;
  }
  if((resposta[0] & 7) != 4 || resposta[1] == 0 || resposta[1] > 15 || memcmp(resposta + 24, pedido + 40, 8)) {
    snprintf(erro, tam, "resposta invalida (modo %d, stratum %d)", resposta[0] & 7, resposta[1]);
    return -1;
  }
  double t2 = ntp_ler(resposta + 32), t3 = ntp_ler(resposta + 40);
  double atraso = (t4 - t1) - (t3 - t2);
  if(!sensato(t3) || !sensato(t2)) {
    snprintf(erro, tam, "hora absurda do servidor");
    return -1;
  }
  if(atraso < -0.5 || atraso > 3) {
    snprintf(erro, tam, "atraso %.1f s", atraso);
    return -1;
  }
  *desvio = ((t2 - t1) + (t3 - t4)) / 2;
  return 0;
}

/* "Tue, 10 Nov 2026 11:22:33 GMT" -> segundos UNIX (sem depender de timegm/strptime). */
static int data_http(const char *s, double *saida) {
  static const char *MESES = "JanFebMarAprMayJunJulAugSepOctNovDec";
  char mes[4] = "";
  int dia, ano, h, m, seg;
  const char *v = strchr(s, ',');
  if(sscanf(v ? v + 1 : s, " %d %3s %d %d:%d:%d", &dia, mes, &ano, &h, &m, &seg) != 6) return -1;
  const char *p = strstr(MESES, mes);
  if(!p || strlen(mes) != 3 || (p - MESES) % 3) return -1;
  int mm = (int)(p - MESES) / 3 + 1;
  if(dia < 1 || dia > 31 || h > 23 || m > 59 || seg > 60) return -1;
  /* dias desde 1970-01-01 (algoritmo days_from_civil) */
  int y = ano - (mm <= 2);
  int era = (y >= 0 ? y : y - 399) / 400;
  int yoe = y - era * 400;
  int doy = (153 * (mm + (mm > 2 ? -3 : 9)) + 2) / 5 + dia - 1;
  int doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
  long long dias = (long long)era * 146097 + doe - 719468;
  *saida = (double)dias * 86400 + h * 3600 + m * 60 + seg;
  return 0;
}

/* Cabecalho Date de um site HTTPS. 0 = ok. */
static int http_perguntar(const char *url, double *desvio, char *erro, size_t tam) {
  char data[80];
  erro[0] = 0;
  double t1 = agora();
  int status = https_data(url, data, sizeof data);
  double t2 = agora();
  double servidor;
  if(status <= 0 || !data[0]) {
    snprintf(erro, tam, "sem resposta (%d)", status);
    return -1;
  }
  if(data_http(data, &servidor) || !sensato(servidor)) {
    snprintf(erro, tam, "Date invalido");
    return -1;
  }
  if(t2 - t1 > 8) {
    snprintf(erro, tam, "lento demais (%.0f s)", t2 - t1);
    return -1;
  }
  /* o Date sai junto com a resposta (fim do pedido; o comeco gasta tempo com DNS e TLS) e corta os segundos:
     em media o servidor estava meio segundo depois */
  *desvio = servidor + 0.5 - t2;
  return 0;
}

static int juntar_fontes(fonte_t *f) {
  int n = 0;
  const char *teste_ntp = getenv("GLR_TESTE_RELOGIO_NTP"), *teste_http = getenv("GLR_TESTE_RELOGIO_HTTP");
#ifdef __PROSPERO__
  teste_ntp = teste_http = NULL;
#endif
  if(teste_ntp && *teste_ntp) {
    /* PC: "ip:porta[,ip:porta]" - cada um vale um voto */
    char lista[256];
    snprintf(lista, sizeof lista, "%s", teste_ntp);
    for(char *item = strtok(lista, ","); item && n < MAX_FONTES - 1; item = strtok(NULL, ",")) {
      char *dois = strchr(item, ':');
      memset(&f[n], 0, sizeof f[n]);
      snprintf(f[n].nome, sizeof f[n].nome, "teste NTP %s", dois ? dois + 1 : "?");
      if(dois) *dois = 0;
      f[n].ok = !ntp_perguntar(item, dois ? atoi(dois + 1) : 123, &f[n].desvio, f[n].erro, sizeof f[n].erro);
      n++;
    }
  } else {
    for(size_t p = 0; p < sizeof NTP / sizeof *NTP; p++) {
      memset(&f[n], 0, sizeof f[n]);
      snprintf(f[n].nome, sizeof f[n].nome, "%s", NTP[p].nome);
      for(int i = 0; NTP[p].ips[i] && !f[n].ok; i++)
        f[n].ok = !ntp_perguntar(NTP[p].ips[i], 123, &f[n].desvio, f[n].erro, sizeof f[n].erro);
      n++;
    }
  }
  memset(&f[n], 0, sizeof f[n]);
  if(teste_http && *teste_http) {
    snprintf(f[n].nome, sizeof f[n].nome, "teste HTTP");
    f[n].ok = !http_perguntar(teste_http, &f[n].desvio, f[n].erro, sizeof f[n].erro);
  } else {
    snprintf(f[n].nome, sizeof f[n].nome, "Cloudflare (HTTPS)");
    for(int i = 0; URL_DATA[i] && !f[n].ok; i++) f[n].ok = !http_perguntar(URL_DATA[i], &f[n].desvio, f[n].erro, sizeof f[n].erro);
  }
  return n + 1;
}

/* ------------------------------------------------------------------ acerto */

/* Grava a hora (UTC). 0 = o relogio ficou certo. det recebe o passo a passo para o diario. */
static int gravar_hora(double desvio, char *det, size_t tam) {
#ifdef __PROSPERO__
  double alvo = agora() + desvio;
  struct timespec ts = {(time_t)floor(alvo), (long)((alvo - floor(alvo)) * 1e9)};
  struct timeval tv = {ts.tv_sec, (long)(ts.tv_nsec / 1000)};
  struct timespec d16 = {0}, d17 = {0};
  int g16 = clock_gettime(16, &d16), g17 = clock_gettime(17, &d17);
  pid_t pid = getpid();
  uint64_t antes = kernel_get_ucred_authid(pid);
  int ra = kernel_set_ucred_authid(pid, AUTHID_SISTEMA);
  errno = 0;
  int r17 = clock_settime(17, &ts), e17 = errno;
  errno = 0;
  int r16 = clock_settime(16, &ts), e16 = errno;
  errno = 0;
  int rs = settimeofday(&tv, NULL), es = errno, r0 = 0, e0 = 0;
  if(rs) {
    errno = 0;
    r0 = clock_settime(CLOCK_REALTIME, &ts);
    e0 = errno;
  }
  int rv = kernel_set_ucred_authid(pid, antes);
  snprintf(det, tam,
           "antes: dominio16 %s%lld, dominio17 %s%lld; authid %d (volta %d); clock_settime(17) %d errno %d; "
           "clock_settime(16) %d errno %d; settimeofday %d errno %d%s",
           g16 ? "erro " : "", (long long)d16.tv_sec, g17 ? "erro " : "", (long long)d17.tv_sec, ra, rv, r17, e17, r16, e16,
           rs, es, rs ? (r0 ? "; clock_settime(0) falhou" : "; clock_settime(0) ok") : "");
  (void)e0;
  return (rs && r0) ? -1 : 0;
#else
  g_simulado += desvio;
  snprintf(det, tam, "PC: simulado (o relogio do sistema nao muda)");
  return 0;
#endif
}

static int fuso_minutos(void) {
  time_t utc = time(NULL);
#ifdef __PROSPERO__
  time_t local = 0;
  unsigned char st[64] = {0};
  unsigned long dst = 0;
  if(sceKernelConvertUtcToLocaltime && !sceKernelConvertUtcToLocaltime(utc, &local, st, &dst))
    return (int)((long long)local - (long long)utc) / 60;
  return -100000;
#else
  struct tm tm;
  localtime_r(&utc, &tm);
  return (int)(tm.tm_gmtoff / 60);
#endif
}

static void texto_dif(char *s, size_t tam, double dif) {
  double a = fabs(dif);
  const char *lado = dif > 0 ? "adiantado" : "atrasado";
  if(a < 120) snprintf(s, tam, "%.0f s %s", a, lado);
  else if(a < 7200) snprintf(s, tam, "%.0f min %s", a / 60, lado);
  else if(a < 172800) snprintf(s, tam, "%.1f h %s", a / 3600, lado);
  else snprintf(s, tam, "%.0f dias %s", a / 86400, lado);
}

/* Confere e acerta se precisar. Devolve 0 (certo ou acertado) ou -1 (sem fontes suficientes / falhou). */
static int conferir(void) {
  pthread_mutex_lock(&g_trava_conferir);
  pthread_mutex_lock(&g_trava);
  g_conferindo = 1;
  pthread_mutex_unlock(&g_trava);

  fonte_t f[MAX_FONTES];
  int n = juntar_fontes(f), validas = 0, melhor = -1, votos = 0;
  for(int i = 0; i < n; i++) validas += f[i].ok;
  /* a fonte com mais fontes perto dela (empate: a primeira - NTP vem antes do HTTP) */
  for(int i = 0; i < n; i++) {
    if(!f[i].ok) continue;
    int c = 0;
    for(int j = 0; j < n; j++) c += f[j].ok && fabs(f[j].desvio - f[i].desvio) < CONCORDA_S;
    if(c > votos) votos = c, melhor = i;
  }
  double soma = 0, soma_ntp = 0;
  int qtd_ntp = 0;
  for(int i = 0; i < n; i++) {
    f[i].concorda = melhor >= 0 && f[i].ok && fabs(f[i].desvio - f[melhor].desvio) < CONCORDA_S;
    if(f[i].concorda) {
      soma += f[i].desvio;
      if(strstr(f[i].nome, "NTP")) soma_ntp += f[i].desvio, qtd_ntp++;
    }
  }
  char situacao[24], det[300] = "", dif_txt[40];
  double desvio = votos ? (qtd_ntp ? soma_ntp / qtd_ntp : soma / votos) : 0;
  int r = -1;
  if(!validas) snprintf(situacao, sizeof situacao, "sem_internet");
  else if(votos < 2) snprintf(situacao, sizeof situacao, validas == 1 ? "poucas_fontes" : "fontes_discordam");
  else if(votos * 2 <= validas) snprintf(situacao, sizeof situacao, "fontes_discordam");
  else if(fabs(desvio) <= LIMITE_S) {
    snprintf(situacao, sizeof situacao, "certo");
    r = 0;
  } else {
    texto_dif(dif_txt, sizeof dif_txt, -desvio);
    r = gravar_hora(desvio, det, sizeof det);
    if(!r) {
      /* confere de novo com o primeiro provedor NTP que concordou (no PC o simulado ja zerou a diferenca) */
      for(size_t p = 0; p < sizeof NTP / sizeof *NTP; p++) {
        int achou = 0;
        for(int i = 0; i < n; i++) achou |= f[i].concorda && !strcmp(f[i].nome, NTP[p].nome);
        if(!achou) continue;
        double sobra = 0;
        char e[64];
        int ok = 0;
        for(int k = 0; NTP[p].ips[k] && !ok; k++) ok = !ntp_perguntar(NTP[p].ips[k], 123, &sobra, e, sizeof e);
        size_t k = strlen(det);
        if(ok) snprintf(det + k, sizeof det - k, "; depois: diferenca %.1f s (%s)", -sobra, NTP[p].nome);
        if(ok && fabs(sobra) > 5) r = -1;
        break;
      }
    }
    snprintf(situacao, sizeof situacao, r ? "falhou" : "ajustado");
    diario("relogio: %s - estava %s (%.1f s); %s", r ? "NAO acertou" : "acertado", dif_txt, -desvio, det);
    if(!r) {
      g_falhas_acerto = 0;
      notificar("Relogio do PS5 acertado (estava %s)", dif_txt);
    } else if(g_falhas_acerto++ == 0) {
      notificar("Relogio do PS5: nao foi possivel acertar (veja o diario)");
    } else {
      diario("relogio: %d falhas seguidas no acerto (aviso so na primeira)", g_falhas_acerto);
    }
  }
  char resumo[300] = "";
  size_t k = 0;
  for(int i = 0; i < n && k < sizeof resumo - 1; i++)
    k += snprintf(resumo + k, sizeof resumo - k, "%s%s %s", i ? "; " : "", f[i].nome,
                  f[i].ok ? (f[i].concorda ? "ok" : "DISCORDA") : f[i].erro);
  if(strcmp(situacao, "certo") && strcmp(situacao, "ajustado")) diario("relogio: %s (%s)", situacao, resumo);
  else if(!strcmp(situacao, "certo")) diario("relogio: certo (diferenca %.1f s; %d fontes concordam)", -desvio, votos);

  pthread_mutex_lock(&g_trava);
  snprintf(g_situacao, sizeof g_situacao, "%s", situacao);
  snprintf(g_detalhe, sizeof g_detalhe, "%s", det[0] ? det : resumo);
  memcpy(g_fontes, f, sizeof(fonte_t) * (size_t)n);
  g_qtd_fontes = n;
  g_quando = agora();
  g_diferenca = votos >= 2 ? -desvio : 0;
  if(!strcmp(situacao, "ajustado")) {
    g_ajustes++;
    g_ultimo_ajuste = g_quando;
    g_ultimo_ajuste_dif = -desvio;
  }
  g_conferindo = 0;
  pthread_mutex_unlock(&g_trava);
  pthread_mutex_unlock(&g_trava_conferir);
  return r;
}

/* ------------------------------------------------------------------ configuracao e thread */

static void arquivo(char *s, size_t tam) {
  snprintf(s, tam, "%s/relogio.ini", g_pasta_dados);
}

int relogio_definir_auto(int ligado) {
  char nome[600];
  arquivo(nome, sizeof nome);
  FILE *f = fopen(nome, "w");
  if(!f) return -1;
  fprintf(f, "; Game Library Renamer: relogio do PS5 pela internet\nauto = %s\n", ligado ? "on" : "off");
  if(fclose(f)) return -1;
  pthread_mutex_lock(&g_trava);
  g_auto = ligado;
  pthread_mutex_unlock(&g_trava);
  diario("relogio: conferencia automatica %s", ligado ? "ligada" : "desligada");
  return 0;
}

static void ler_auto(void) {
  char nome[600], linha[128];
  arquivo(nome, sizeof nome);
  FILE *f = fopen(nome, "r");
  if(!f) return;
  while(fgets(linha, sizeof linha, f)) {
    char v[16];
    if(sscanf(linha, " auto = %15s", v) == 1) g_auto = strcasecmp(v, "off") && strcmp(v, "0");
  }
  fclose(f);
}

void relogio_acordou(void) {
  g_acordou = 1;
}

void relogio_conferir_agora(void) {
  conferir();
}

static void *laco(void *x) {
  (void)x;
  double proxima = monotonico() + g_espera_inicio;
  for(;;) {
    sleep(1);
    if(g_acordou) {
      g_acordou = 0;
      proxima = monotonico() + ESPERA_ACORDAR_S;
    }
    if(monotonico() < proxima) continue;
    pthread_mutex_lock(&g_trava);
    int ligado = g_auto;
    pthread_mutex_unlock(&g_trava);
    if(!ligado) {
      proxima = monotonico() + 60;
      continue;
    }
    long espera = INTERVALO_S;
    if(conferir()) {
      espera = REPETIR_S;
      for(int i = 0; i < g_falhas_seguidas && espera < INTERVALO_S; i++) espera *= 2;
      if(espera > INTERVALO_S) espera = INTERVALO_S;
      g_falhas_seguidas++;
    } else {
      g_falhas_seguidas = 0;
    }
    proxima = monotonico() + espera;
  }
  return NULL;
}

void relogio_iniciar(void) {
  ler_auto();
#ifndef __PROSPERO__
  const char *d = getenv("GLR_TESTE_RELOGIO_DESVIO"), *e = getenv("GLR_TESTE_RELOGIO_ESPERA");
  if(d && *d) g_simulado = atof(d);
  if(e && *e) g_espera_inicio = atoi(e);
#endif
  diario("relogio: fuso do PS5 %+d min; conferencia automatica %s", fuso_minutos(), g_auto ? "ligada" : "desligada");
  criar_thread(laco, NULL, NULL);
}

void relogio_json(buf_t *b) {
  pthread_mutex_lock(&g_trava);
  buf_fmt(b, "\"relogio\":{\"auto\":%s,\"conferindo\":%s,\"situacao\":", g_auto ? "true" : "false", g_conferindo ? "true" : "false");
  buf_json(b, g_situacao);
  buf_fmt(b, ",\"quando\":%.0f,\"diferenca\":%.1f,\"limite\":%d,\"ajustes\":%d,\"ultimo_ajuste\":%.0f,\"ultimo_ajuste_dif\":%.1f,"
          "\"agora\":%.0f,\"fuso_min\":%d,\"pc\":%s,\"detalhe\":",
          g_quando, g_diferenca, LIMITE_S, g_ajustes, g_ultimo_ajuste, g_ultimo_ajuste_dif, agora(), fuso_minutos(),
#ifdef __PROSPERO__
          "false"
#else
          "true"
#endif
  );
  buf_json(b, g_detalhe);
  buf_str(b, ",\"fontes\":[");
  for(int i = 0; i < g_qtd_fontes; i++) {
    buf_fmt(b, "%s{\"nome\":", i ? "," : "");
    buf_json(b, g_fontes[i].nome);
    buf_fmt(b, ",\"ok\":%s,\"concorda\":%s,\"diferenca\":%.2f,\"erro\":", g_fontes[i].ok ? "true" : "false",
            g_fontes[i].concorda ? "true" : "false", g_fontes[i].ok ? -g_fontes[i].desvio : 0);
    buf_json(b, g_fontes[i].erro);
    buf_str(b, "}");
  }
  buf_str(b, "]}");
  pthread_mutex_unlock(&g_trava);
}
