/* Game Library Renamer (payload PS5) - confere a assinatura Ed25519 das atualizacoes (TweetNaCl, dominio publico). */
#include "assinatura.h"

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* TweetNaCl e codigo de terceiros: compila sem os avisos do nosso -Werror. */
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Weverything"
#include "terceiros/tweetnacl.c"
#pragma clang diagnostic pop

#include "chave_publica.h"

/* So para gerar chaves (nunca usado aqui: o payload apenas confere assinaturas). */
void randombytes(u8 *x, u64 n) {
  memset(x, 0, n);
}

/* Chave usada na conferencia. So no PC e so nos testes (GLR_TESTE_CHAVE = 64 hex): uma chave publica de teste no
   lugar da embutida, para testar catalogos assinados sem a chave privada de verdade. Nunca no build do PS5. */
static const u8 *chave(void) {
#ifndef __PROSPERO__
  static u8 teste[32];
  const char *h = getenv("GLR_TESTE_CHAVE");
  if(h && strlen(h) == 64) {
    int ok = 1;
    for(int i = 0; i < 32 && ok; i++) {
      unsigned v;
      ok = sscanf(h + i * 2, "%2x", &v) == 1;
      teste[i] = (u8)v;
    }
    if(ok) return teste;
  }
#endif
  return CHAVE_PUBLICA;
}

int assinatura_valida(const void *dados, size_t n, const unsigned char assinatura[64]) {
  /* crypto_sign_open espera assinatura + mensagem juntas */
  u8 *sm = malloc(n + 64), *m = malloc(n + 64);
  int ok = 0;
  if(sm && m) {
    memcpy(sm, assinatura, 64);
    memcpy(sm + 64, dados, n);
    u64 mlen = 0;
    ok = crypto_sign_open(m, &mlen, sm, n + 64, chave()) == 0 && mlen == n;
  }
  free(sm);
  free(m);
  return ok;
}
