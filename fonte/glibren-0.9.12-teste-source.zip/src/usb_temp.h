/* Game Library Renamer (payload PS5) - temperatura do SSD NVMe ligado por gaveta USB (teste).
   So le quando o usuario pede (botao na pagina Temperatura). Comandos de leitura apenas: INQUIRY, LOG SENSE e, so em
   gaveta Realtek, o repasse NVMe do RTL9210 (Identify + log SMART). Guarda o ultimo resultado e escreve no diario. */
#pragma once

#include "util.h"

typedef enum { USB_TEMP_OK, USB_TEMP_COPIANDO, USB_TEMP_TESTANDO, USB_TEMP_LENDO } usb_temp_r;

/* Le agora (alguns segundos no maximo) e guarda o resultado. Recusa (sem mandar nenhum comando ao disco) com copia ou
   movimentacao na fila, teste de disco rodando ou outra leitura em andamento. */
usb_temp_r usb_temp_ler(void);
/* "copiando", "testando", "lendo" ou "" (ok) */
const char *usb_temp_motivo(usb_temp_r r);
/* "usb_temp":{...} (sem chaves em volta) com o ultimo resultado */
void usb_temp_json(buf_t *b);
