/* Game Library Renamer (payload PS5) - discos montados e teste de velocidade.

Teste: grava um arquivo temporario (".glr-teste-velocidade.tmp") na raiz do disco em blocos de 4 MB, com fsync no
fim (mede a gravacao de verdade, nao so o cache), e depois le de volta tentando nao usar o cache (O_DIRECT; se o
disco nao aceitar, le normal e avisa que a leitura pode ter vindo da memoria). O arquivo e apagado no fim, mesmo
cancelando. Um teste por vez; os resultados ficam guardados para comparar os discos.
*/
#include "discos.h"

#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#ifdef __PROSPERO__
#include <sys/mount.h>
#include <sys/param.h>
#else
#include <mntent.h>
#endif

#include "config.h"

#define BLOCO (4 * 1024 * 1024)
#define NOME_TESTE ".glr-teste-velocidade.tmp"
#define MAX_RESULTADOS 32

typedef struct {
  char caminho[256];
  int tamanho_mb;
  double gravacao, leitura;     /* MB/s */
  int leitura_cache;            /* 1 = leitura pode ter vindo do cache */
  time_t quando;
} resultado_t;

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static int g_rodando;
static volatile int g_cancelar;
static char g_caminho[256], g_fase[16] = "", g_erro[200];
static long long g_total, g_feito;
static double g_velocidade, g_inicio_fase;
static resultado_t g_res[MAX_RESULTADOS];
static int g_qtd_res;

static double agora(void) {
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec / 1e6;
}

/* ------------------------------------------------------------------ discos montados */

/* So os discos de jogos/arquivos do usuario. tipo: "interno", "estendido", "usb". */
static const char *tipo_disco(const char *ponto) {
  if(!strcmp(ponto, "/data")) return "interno";
  if(!strncmp(ponto, "/mnt/ext", 8) && ponto[8] >= '0' && ponto[8] <= '9' && !ponto[9]) return "estendido";
  if(!strncmp(ponto, "/mnt/usb", 8) && ponto[8] >= '0' && ponto[8] <= '9' && !ponto[9]) return "usb";
#ifndef __PROSPERO__
  /* PC (demo): as pastas de teste montadas em tmpfs */
  if(!strcmp(ponto, "/data/homebrew")) return "interno";
  if(!strcmp(ponto, "/mnt/ext1/homebrew")) return "estendido";
#endif
  return NULL;
}

static void disco_json(buf_t *b, int *primeiro, const char *ponto, const char *fs) {
  const char *tipo = tipo_disco(ponto);
  struct statvfs v;
  if(!tipo || statvfs(ponto, &v)) return;
  buf_str(b, *primeiro ? "{\"caminho\":" : ",{\"caminho\":");
  *primeiro = 0;
  buf_json(b, ponto);
  buf_str(b, ",\"tipo\":");
  buf_json(b, tipo);
  buf_str(b, ",\"fs\":");
  buf_json(b, fs);
  buf_fmt(b, ",\"total\":%lld,\"livre\":%lld,\"gravavel\":%s}", (long long)v.f_blocks * (long long)v.f_frsize,
          (long long)v.f_bavail * (long long)v.f_frsize, access(ponto, W_OK) ? "false" : "true");
}

/* Chama "fn" com o ponto de montagem de cada disco do usuario. */
static void cada_disco(void (*fn)(const char *ponto)) {
#ifdef __PROSPERO__
  int n = getfsstat(NULL, 0, MNT_NOWAIT);
  struct statfs *lista = n > 0 ? calloc(n, sizeof *lista) : NULL;
  if(!lista) return;
  n = getfsstat(lista, n * sizeof *lista, MNT_NOWAIT);
  for(int i = 0; i < n; i++) {
    if(tipo_disco(lista[i].f_mntonname)) fn(lista[i].f_mntonname);
  }
  free(lista);
#else
  FILE *f = setmntent("/proc/mounts", "r");
  struct mntent *m;
  while(f && (m = getmntent(f))) {
    if(tipo_disco(m->mnt_dir)) fn(m->mnt_dir);
  }
  if(f) endmntent(f);
#endif
}

static void apagar_sobra(const char *ponto) {
  char arquivo[700];
  snprintf(arquivo, sizeof arquivo, "%s/%s", strcmp(ponto, "/data") ? ponto : g_pasta_dados, NOME_TESTE);
  if(!unlink(arquivo)) printf("teste de velocidade: sobra apagada em %s\n", arquivo);
}

void discos_limpar_sobras(void) {
  cada_disco(apagar_sobra);
}

void discos_listar(buf_t *b) {
  int primeiro = 1;
  buf_str(b, "{\"ok\":true,\"discos\":[");
#ifdef __PROSPERO__
  int n = getfsstat(NULL, 0, MNT_NOWAIT);
  struct statfs *lista = n > 0 ? calloc(n, sizeof *lista) : NULL;
  if(lista) {
    n = getfsstat(lista, n * sizeof *lista, MNT_NOWAIT);
    for(int i = 0; i < n; i++) disco_json(b, &primeiro, lista[i].f_mntonname, lista[i].f_fstypename);
    free(lista);
  }
#else
  FILE *f = setmntent("/proc/mounts", "r");
  struct mntent *m;
  while(f && (m = getmntent(f))) disco_json(b, &primeiro, m->mnt_dir, m->mnt_type);
  if(f) endmntent(f);
#endif
  buf_str(b, "]}");
}

/* ------------------------------------------------------------------ teste */

static void marcar(const char *fase, long long total) {
  pthread_mutex_lock(&g_trava);
  snprintf(g_fase, sizeof g_fase, "%s", fase);
  g_total = total;
  g_feito = 0;
  g_velocidade = 0;
  g_inicio_fase = agora();
  pthread_mutex_unlock(&g_trava);
}

static void avancou(long long n) {
#ifndef __PROSPERO__
  /* So no PC (demo): GLR_DEMO_MBPS limita a velocidade para dar para ver o teste andando. */
  static int limite = -1;
  if(limite < 0) limite = getenv("GLR_DEMO_MBPS") ? atoi(getenv("GLR_DEMO_MBPS")) : 0;
  if(limite > 0) usleep((useconds_t)((double)n / (limite * 1048576.0) * 1e6));
#endif
  pthread_mutex_lock(&g_trava);
  g_feito += n;
  double d = agora() - g_inicio_fase;
  if(d > 0.2) g_velocidade = g_feito / d / 1048576.0;
  pthread_mutex_unlock(&g_trava);
}

static void falhou(const char *fmt, const char *detalhe) {
  pthread_mutex_lock(&g_trava);
  snprintf(g_erro, sizeof g_erro, fmt, detalhe);
  pthread_mutex_unlock(&g_trava);
}

static void *testar(void *arg) {
  int tamanho_mb = (int)(long)arg;
  char arquivo[700];
  /* no SSD interno grava na pasta do app (mesmo disco que /data) */
  snprintf(arquivo, sizeof arquivo, "%s/%s", strcmp(g_caminho, "/data") ? g_caminho : g_pasta_dados, NOME_TESTE);
  long long total = (long long)tamanho_mb * 1048576;
  double gravacao = 0, leitura = 0;
  int cache = 0;
  char *buf = NULL;
  if(posix_memalign((void **)&buf, 4096, BLOCO)) buf = NULL;   /* O_DIRECT exige memoria alinhada */
  if(!buf) {
    falhou("sem memoria%s", "");
    goto fim;
  }
  for(int i = 0; i < BLOCO; i++) buf[i] = (char)(i * 131 + 7);   /* dados que nao comprimem a toa */

  /* gravacao */
  marcar("gravando", total);
  int fd = open(arquivo, O_WRONLY | O_CREAT | O_TRUNC, 0644);
  if(fd < 0) {
    falhou("nao conseguiu gravar no disco: %s", strerror(errno));
    goto fim;
  }
  double t0 = agora();
  for(long long feito = 0; feito < total && !g_cancelar;) {
    ssize_t w = write(fd, buf, BLOCO);
    if(w <= 0) {
      falhou("erro de gravacao: %s", errno == ENOSPC ? "disco cheio" : strerror(errno));
      break;
    }
    feito += w;
    avancou(w);
  }
  fsync(fd);
  gravacao = total / (agora() - t0) / 1048576.0;
  close(fd);
  if(g_cancelar || g_erro[0]) goto fim;

  /* leitura (tentando passar por fora do cache) */
  marcar("lendo", total);
#ifdef O_DIRECT
  fd = open(arquivo, O_RDONLY | O_DIRECT);
  if(fd < 0)
#endif
  {
    cache = 1;
    fd = open(arquivo, O_RDONLY);
#ifdef POSIX_FADV_DONTNEED
    if(fd >= 0 && !posix_fadvise(fd, 0, 0, POSIX_FADV_DONTNEED)) cache = 0;
#endif
  }
  if(fd < 0) {
    falhou("nao conseguiu ler: %s", strerror(errno));
    goto fim;
  }
  t0 = agora();
  long long lido = 0;
  while(lido < total && !g_cancelar) {
    ssize_t r = read(fd, buf, BLOCO);
    if(r < 0 && errno == EINVAL && !cache) {
      /* o disco nao aceitou leitura direta: le normal (pode vir do cache) */
      close(fd);
      fd = open(arquivo, O_RDONLY);
      cache = 1;
      lseek(fd, lido, SEEK_SET);
      continue;
    }
    if(r <= 0) break;
    lido += r;
    avancou(r);
  }
  leitura = lido / (agora() - t0) / 1048576.0;
  close(fd);
  if(g_cancelar) goto fim;

  pthread_mutex_lock(&g_trava);
  if(g_qtd_res == MAX_RESULTADOS) memmove(g_res, g_res + 1, sizeof *g_res * --g_qtd_res);
  resultado_t *res = &g_res[g_qtd_res++];
  snprintf(res->caminho, sizeof res->caminho, "%s", g_caminho);
  res->tamanho_mb = tamanho_mb;
  res->gravacao = gravacao;
  res->leitura = leitura;
  res->leitura_cache = cache;
  res->quando = time(NULL);
  pthread_mutex_unlock(&g_trava);

fim:
  unlink(arquivo);
  free(buf);
  pthread_mutex_lock(&g_trava);
  if(g_cancelar && !g_erro[0]) snprintf(g_erro, sizeof g_erro, "cancelado");
  g_fase[0] = 0;
  g_rodando = 0;
  pthread_mutex_unlock(&g_trava);
  return NULL;
}

int discos_testar(const char *caminho, int tamanho_mb, char *msg, size_t tam) {
  struct statvfs v;
  if(!caminho_valido(caminho) || !tipo_disco(caminho) || statvfs(caminho, &v)) {
    snprintf(msg, tam, "disco invalido");
    return -1;
  }
  /* arquivo grande o bastante para o cache do PS5 (16 GB de RAM) pesar pouco no resultado */
  if(tamanho_mb != 1024 && tamanho_mb != 2048 && tamanho_mb != 4096 && tamanho_mb != 8192) tamanho_mb = 4096;
  if((long long)v.f_bavail * (long long)v.f_frsize < (long long)tamanho_mb * 1048576 + 256LL * 1048576) {
    snprintf(msg, tam, "sem espaco livre para o teste");
    return -1;
  }
  pthread_mutex_lock(&g_trava);
  if(g_rodando) {
    pthread_mutex_unlock(&g_trava);
    snprintf(msg, tam, "ja tem um teste rodando");
    return -1;
  }
  g_rodando = 1;
  g_cancelar = 0;
  g_erro[0] = 0;
  snprintf(g_caminho, sizeof g_caminho, "%s", caminho);
  pthread_mutex_unlock(&g_trava);
  if(criar_thread(testar, (void *)(long)tamanho_mb, NULL)) {
    g_rodando = 0;
    snprintf(msg, tam, "nao iniciou o teste");
    return -1;
  }
  return 0;
}

void discos_cancelar(void) {
  g_cancelar = 1;
}

int discos_testando(void) {
  pthread_mutex_lock(&g_trava);
  int r = g_rodando;
  pthread_mutex_unlock(&g_trava);
  return r;
}

void discos_estado(buf_t *b) {
  pthread_mutex_lock(&g_trava);
  buf_fmt(b, "{\"ok\":true,\"rodando\":%s,\"caminho\":", g_rodando ? "true" : "false");
  buf_json(b, g_caminho);
  buf_str(b, ",\"fase\":");
  buf_json(b, g_fase);
  buf_fmt(b, ",\"total\":%lld,\"feito\":%lld,\"velocidade\":%.1f,\"erro\":", g_total, g_feito, g_velocidade);
  buf_json(b, g_erro);
  buf_str(b, ",\"resultados\":[");
  for(int i = 0; i < g_qtd_res; i++) {
    resultado_t *r = &g_res[i];
    buf_str(b, i ? ",{\"caminho\":" : "{\"caminho\":");
    buf_json(b, r->caminho);
    buf_fmt(b, ",\"tamanho_mb\":%d,\"gravacao\":%.1f,\"leitura\":%.1f,\"leitura_cache\":%s,\"quando\":%lld}", r->tamanho_mb,
            r->gravacao, r->leitura, r->leitura_cache ? "true" : "false", (long long)r->quando);
  }
  buf_str(b, "]}");
  pthread_mutex_unlock(&g_trava);
}
