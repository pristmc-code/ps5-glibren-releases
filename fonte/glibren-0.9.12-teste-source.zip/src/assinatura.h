/* Game Library Renamer (payload PS5) - confere a assinatura Ed25519 das atualizacoes. */
#pragma once

#include <stddef.h>

/* 1 se a assinatura (64 bytes) confere com os dados e a chave publica embutida no payload. */
int assinatura_valida(const void *dados, size_t n, const unsigned char assinatura[64]);
