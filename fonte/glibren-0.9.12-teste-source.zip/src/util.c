/* Game Library Renamer (payload PS5) - utilitarios. */
#include "util.h"

#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

void buf_add(buf_t *b, const void *dados, size_t n) {
  if(b->n + n + 1 > b->cap) {
    size_t cap = b->cap ? b->cap : 1024;
    while(cap < b->n + n + 1) cap *= 2;
    char *novo = realloc(b->d, cap);
    if(!novo) abort();
    b->d = novo;
    b->cap = cap;
  }
  memcpy(b->d + b->n, dados, n);
  b->n += n;
  b->d[b->n] = 0;
}

void buf_str(buf_t *b, const char *s) {
  buf_add(b, s, strlen(s));
}

void buf_fmt(buf_t *b, const char *fmt, ...) {
  char tmp[1024];
  va_list args;
  va_start(args, fmt);
  int n = vsnprintf(tmp, sizeof tmp, fmt, args);
  va_end(args);
  if(n < 0) return;
  if((size_t)n < sizeof tmp) {
    buf_add(b, tmp, n);
    return;
  }
  char *grande = malloc(n + 1);
  if(!grande) abort();
  va_start(args, fmt);
  vsnprintf(grande, n + 1, fmt, args);
  va_end(args);
  buf_add(b, grande, n);
  free(grande);
}

void buf_json(buf_t *b, const char *s) {
  buf_add(b, "\"", 1);
  for(const unsigned char *p = (const unsigned char *)s; *p; p++) {
    switch(*p) {
    case '"': buf_add(b, "\\\"", 2); break;
    case '\\': buf_add(b, "\\\\", 2); break;
    case '\n': buf_add(b, "\\n", 2); break;
    case '\r': buf_add(b, "\\r", 2); break;
    case '\t': buf_add(b, "\\t", 2); break;
    default:
      if(*p < 0x20) buf_fmt(b, "\\u%04x", *p);
      else buf_add(b, p, 1);
    }
  }
  buf_add(b, "\"", 1);
}

void buf_free(buf_t *b) {
  free(b->d);
  b->d = NULL;
  b->n = b->cap = 0;
}

static int hex(int c) {
  if(c >= '0' && c <= '9') return c - '0';
  if(c >= 'a' && c <= 'f') return c - 'a' + 10;
  if(c >= 'A' && c <= 'F') return c - 'A' + 10;
  return -1;
}

int param(const char *qs, const char *nome, int ocorrencia, char *saida, size_t tam) {
  size_t tam_nome = strlen(nome);
  const char *p = qs;
  while(p && *p) {
    const char *fim = strchr(p, '&');
    size_t len = fim ? (size_t)(fim - p) : strlen(p);
    if(len > tam_nome && p[tam_nome] == '=' && !strncmp(p, nome, tam_nome) && ocorrencia-- == 0) {
      size_t o = 0;
      for(size_t i = tam_nome + 1; i < len && o + 1 < tam; i++) {
        if(p[i] == '+') saida[o++] = ' ';
        else if(p[i] == '%' && i + 2 < len && hex(p[i + 1]) >= 0 && hex(p[i + 2]) >= 0) {
          saida[o++] = (char)(hex(p[i + 1]) * 16 + hex(p[i + 2]));
          i += 2;
        } else saida[o++] = p[i];
      }
      saida[o] = 0;
      return 1;
    }
    p = fim ? fim + 1 : NULL;
  }
  return 0;
}

int caminho_valido(const char *caminho) {
  if(caminho[0] != '/' || strstr(caminho, "//") || strchr(caminho, '\\')) return 0;
  for(const char *p = caminho; *p; p++) {
    if((unsigned char)*p < 0x20) return 0;
  }
  /* nenhum componente "." ou ".." */
  const char *p = caminho;
  while(*p) {
    while(*p == '/') p++;
    const char *fim = strchr(p, '/');
    size_t len = fim ? (size_t)(fim - p) : strlen(p);
    if((len == 1 && p[0] == '.') || (len == 2 && p[0] == '.' && p[1] == '.')) return 0;
    p += len;
  }
  return strlen(caminho) < 1024;
}

int nome_valido(const char *nome) {
  if(!*nome || !strcmp(nome, ".") || !strcmp(nome, "..")) return 0;
  for(const char *p = nome; *p; p++) {
    if(*p == '/' || *p == '\\' || (unsigned char)*p < 0x20) return 0;
  }
  return strlen(nome) < 256;
}

int mkdir_p(const char *caminho) {
  char tmp[1024];
  snprintf(tmp, sizeof tmp, "%s", caminho);
  for(char *p = tmp + 1; *p; p++) {
    if(*p == '/') {
      *p = 0;
      if(mkdir(tmp, 0777) && errno != EEXIST) return -1;
      *p = '/';
    }
  }
  if(mkdir(tmp, 0777) && errno != EEXIST) return -1;
  return 0;
}

int criar_thread(void *(*fn)(void *), void *arg, pthread_t *t) {
  pthread_t local;
  pthread_attr_t attr;
  pthread_attr_init(&attr);
  pthread_attr_setstacksize(&attr, 1024 * 1024);
  if(!t) pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
  int r = pthread_create(t ? t : &local, &attr, fn, arg);
  pthread_attr_destroy(&attr);
  return r;
}
