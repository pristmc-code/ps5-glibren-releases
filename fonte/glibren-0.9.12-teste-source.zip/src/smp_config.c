/* Game Library Renamer (payload PS5) - endereco da API do ShadowMountPlus no config.ini dele.

Formato antigo (v1, sem secoes):   api_port = 10101   /   api_bind_address = 0.0.0.0
Formato novo (v2, commit 48e0f93 de 04/11/2026; o SMP converte sozinho e guarda o antigo em config-v1-backup/):
  [api]
  port = 10101
  bind_address = 0.0.0.0
No v2 "port" e "bind_address" so valem dentro da secao [api] (outras secoes, como [smb:NAS], tem campos parecidos).
*/
#include "smp_config.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

/* Valor de "chave = valor" (aceita aspas e comentario no fim). Devolve 1 se a linha e dessa chave. */
static int valor_de(const char *linha, const char *chave, char *saida, size_t tam) {
  while(*linha == ' ' || *linha == '\t') linha++;
  size_t n = strlen(chave);
  if(strncasecmp(linha, chave, n)) return 0;
  linha += n;
  while(*linha == ' ' || *linha == '\t') linha++;
  if(*linha != '=') return 0;
  linha++;
  while(*linha == ' ' || *linha == '\t') linha++;
  char fim = 0;
  if(*linha == '"') fim = *linha++;
  size_t i = 0;
  while(*linha && i + 1 < tam) {
    if(fim ? *linha == fim : (*linha == ';' || *linha == '#' || *linha == '\r' || *linha == '\n')) break;
    saida[i++] = *linha++;
  }
  while(i && (saida[i - 1] == ' ' || saida[i - 1] == '\t')) i--;
  saida[i] = 0;
  return 1;
}

static int porta_valida(const char *s) {
  if(!*s) return 0;
  for(const char *c = s; *c; c++) {
    if(!isdigit((unsigned char)*c)) return 0;
  }
  long v = strtol(s, NULL, 10);
  return v > 0 && v < 65536 ? (int)v : 0;
}

static int ip_valido(const char *s) {
  int partes = 0, digitos = 0, valor = 0;
  for(const char *c = s;; c++) {
    if(isdigit((unsigned char)*c)) {
      valor = valor * 10 + (*c - '0');
      if(++digitos > 3 || valor > 255) return 0;
    } else if(*c == '.' || !*c) {
      if(!digitos) return 0;
      partes++;
      digitos = valor = 0;
      if(!*c) break;
    } else {
      return 0;
    }
  }
  return partes == 4;
}

void smp_config_ler(FILE *f, int *porta, char *ip, size_t tam_ip) {
  char linha[512], valor[128];
  int secao_api = 0;
  while(fgets(linha, sizeof linha, f)) {
    const char *l = linha;
    while(*l == ' ' || *l == '\t') l++;
    if(*l == '[') {
      secao_api = !strncasecmp(l, "[api]", 5);
      continue;
    }
    if((valor_de(l, "api_port", valor, sizeof valor) || (secao_api && valor_de(l, "port", valor, sizeof valor))) &&
       porta_valida(valor)) {
      *porta = porta_valida(valor);
    } else if((valor_de(l, "api_bind_address", valor, sizeof valor) ||
               (secao_api && valor_de(l, "bind_address", valor, sizeof valor))) &&
              ip_valido(valor)) {
      snprintf(ip, tam_ip, "%s", valor);
    }
  }
}
