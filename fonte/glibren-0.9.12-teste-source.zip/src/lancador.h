/* Game Library Renamer (payload PS5) - abrir apps sem atropelar outro app aberto.

Regra (logs reais da Jobe): lancar um titulo com outro app de jogo aberto falha (0x80940011 / 0x80940031) e e
suspeito de derrubar o console. Entao nada e lancado enquanto houver app de jogo aberto. */
#pragma once

#include <stddef.h>

/* Titulo no formato XXXX00000 (4 letras maiusculas + 5 digitos). */
int titulo_valido(const char *tid);
/* 1 = o titulo esta aberto (sceLncUtilGetAppId >= 0), 0 = nao, -1 = nao deu para saber. */
int app_aberto(const char *tid);
/* Algum app de jogo aberto (titulo instalado em /user/appmeta ou /data/homebrew, menos o icone do glibren, que e
   so a pagina no navegador)? 1 = sim (tid recebe o titulo), 0 = nao, -1 = nao deu para saber. */
int app_de_jogo_aberto(char *tid, size_t tam);
/* Pedido pendente: espera "from" fechar (ate 2 min), espera ~15 s e abre "to" com ate 4 tentativas (pausas 5/10/20 s),
   cada resultado no diario. Um pedido novo substitui o pendente. 0 = aceito. */
int lancador_pedir(const char *to, const char *from);
/* Estado do pedido pendente, para diagnostico e testes: "nenhum", "esperando", "aguardando", "lancando",
   "aberto", "desistiu", "falhou" ou "substituido". */
const char *lancador_estado(void);
