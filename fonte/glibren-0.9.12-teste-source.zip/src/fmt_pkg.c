/* Game Library Renamer (payload PS5) - leitor de pacotes .pkg (so leitura, sem chaves). Ver imagem.h.

Formato CNT do PS4 (big-endian), conferido no LibOrbisPkg (PKG/PkgReader.cs, Entry.cs) e no ShadowMountPlus
(src/sm_pkg.c):
  0x00 magic 0x7F434E54 ("\x7FCNT")
  0x10 entry_count (u32)          0x18 entry_table_offset (u32, a partir do inicio do CNT)
  0x40 content_id (char[0x30], ex.: "UP0000-CUSA12345_00-XXXXXXXXXXXXXXXX", 36 caracteres)
Entrada da tabela (32 bytes): +0 id, +4 filename_offset, +8 flags1 (bit 31 = cifrada), +0xC flags2,
  +0x10 data_offset (u32, a partir do inicio do CNT), +0x14 data_size (u32), +0x18 reservado.
Envelopes de PS5 que o ShadowMountPlus aceita (o CNT fica dentro, num deslocamento "base"):
  "FIH" 0x7F464948: versao (u16 LE em 0x06) = 3, base = u64 LE em 0x58
  "LIH" 0x7F4C4948: versao (u16 LE em 0x06) = 1, base = u64 LE em 0x30
  Os deslocamentos da tabela e dos dados do CNT interno sao relativos a base (igual ao sm_pkg.c).
O param.sfo e o icon0.png de fPKG ficam em claro; entrada com o bit de cifra ligado devolve IMG_FORMATO. */
#include <stdlib.h>
#include <string.h>

#include "imagem.h"

#define MAGIC_CNT 0x7F434E54u
#define MAGIC_FIH 0x7F464948u
#define MAGIC_LIH 0x7F4C4948u
#define TAM_CABECALHO 0xA0u
#define TAM_ENTRADA 0x20u
#define MAX_ENTRADAS 1024u    /* o ShadowMountPlus usa o mesmo limite */
#define LOTE_ENTRADAS 32u
#define FLAG_CIFRADA 0x80000000u
#define TAM_PEDACO (64u * 1024u)

static uint32_t be32(const uint8_t *p) {
  return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3];
}

static uint16_t le16(const uint8_t *p) {
  return (uint16_t)(p[0] | (p[1] << 8));
}

static uint64_t le64(const uint8_t *p) {
  uint64_t v = 0;
  for(int i = 7; i >= 0; i--) v = (v << 8) | p[i];
  return v;
}

/* Copia o Content ID do cabecalho (ate 36 caracteres, so letras, digitos, '-' e '_'); invalido = "". */
static void copiar_content_id(const uint8_t *cab, char *saida) {
  size_t n = 0;
  saida[0] = 0;
  while(n < 36 && cab[0x40 + n]) {
    uint8_t c = cab[0x40 + n];
    int ok = (c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == '-' || c == '_';
    if(!ok) return;
    n++;
  }
  memcpy(saida, cab + 0x40, n);
  saida[n] = 0;
}

/* Copia [off, off+tam) do dispositivo para o fim de saida, em pedacos. Em erro desfaz o que acrescentou. */
static int copiar_dados(dispositivo_t *d, uint64_t off, uint32_t tam, buf_t *saida) {
  if(tam == 0) return IMG_OK;
  size_t pedaco = tam < TAM_PEDACO ? tam : TAM_PEDACO;
  uint8_t *tmp = malloc(pedaco);
  if(!tmp) return IMG_ERRO;
  size_t antes = saida->n;
  uint32_t feito = 0;
  int r = IMG_OK;
  while(feito < tam) {
    size_t n = tam - feito < pedaco ? tam - feito : pedaco;
    if(d->ler(d, off + feito, tmp, n) != 0) {
      r = IMG_ERRO;
      break;
    }
    buf_add(saida, tmp, n);
    feito += (uint32_t)n;
  }
  free(tmp);
  if(r != IMG_OK && saida->d) {
    saida->n = antes;
    saida->d[antes] = 0;
  }
  return r;
}

int pkg_ler(dispositivo_t *d, uint32_t id, buf_t *saida, size_t max, char *content_id) {
  uint8_t cab[TAM_CABECALHO];
  if(content_id) content_id[0] = 0;
  if(!d || !d->ler || !saida || d->tamanho < 4) return IMG_FORMATO;
  if(d->ler(d, 0, cab, 4) != 0) return IMG_ERRO;
  uint32_t magic = be32(cab);
  if(magic != MAGIC_CNT && magic != MAGIC_FIH && magic != MAGIC_LIH) return IMG_FORMATO;
  if(d->tamanho < TAM_CABECALHO || d->ler(d, 0, cab, sizeof cab) != 0) return IMG_ERRO;

  /* Envelope de PS5: acha o CNT interno */
  uint64_t base = 0;
  if(magic != MAGIC_CNT) {
    uint16_t versao = le16(cab + 6);
    if(versao != (magic == MAGIC_LIH ? 1 : 3)) return IMG_FORMATO;   /* variante que o SMP tambem recusa */
    base = le64(cab + (magic == MAGIC_LIH ? 0x30 : 0x58));
    if(base < TAM_CABECALHO || base > d->tamanho || d->tamanho - base < TAM_CABECALHO) return IMG_ERRO;
    if(d->ler(d, base, cab, sizeof cab) != 0) return IMG_ERRO;
    if(be32(cab) != MAGIC_CNT) return IMG_ERRO;
  }
  uint64_t tam_cnt = d->tamanho - base;   /* tudo do CNT tem de caber aqui */

  if(content_id) copiar_content_id(cab, content_id);

  uint32_t qtd = be32(cab + 0x10), tabela = be32(cab + 0x18);
  if(qtd > MAX_ENTRADAS || tabela > tam_cnt || (uint64_t)qtd > (tam_cnt - tabela) / TAM_ENTRADA) return IMG_ERRO;

  uint8_t lote[LOTE_ENTRADAS * TAM_ENTRADA];
  for(uint32_t i = 0; i < qtd; i++) {
    if(i % LOTE_ENTRADAS == 0) {
      uint32_t n = qtd - i < LOTE_ENTRADAS ? qtd - i : LOTE_ENTRADAS;
      if(d->ler(d, base + tabela + (uint64_t)i * TAM_ENTRADA, lote, (size_t)n * TAM_ENTRADA) != 0) return IMG_ERRO;
    }
    const uint8_t *e = lote + (i % LOTE_ENTRADAS) * TAM_ENTRADA;
    if(be32(e) != id) continue;
    if(be32(e + 8) & FLAG_CIFRADA) return IMG_FORMATO;
    uint32_t off = be32(e + 0x10), tam = be32(e + 0x14);
    if(off > tam_cnt || tam > tam_cnt - off) return IMG_ERRO;
    if(tam > max) return IMG_ERRO;
    return copiar_dados(d, base + off, tam, saida);
  }
  return IMG_NAO_ACHOU;
}
