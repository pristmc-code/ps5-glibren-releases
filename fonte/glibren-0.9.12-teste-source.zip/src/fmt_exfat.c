/* Game Library Renamer (payload PS5) - leitor exFAT somente-leitura (imagens .exfat com o jogo na raiz). Ver imagem.h.

Formato (tudo little-endian; spec Microsoft "exFAT file system specification"):
  Boot sector (setor 0):
    3     "EXFAT   "
    0x50  FatOffset (setores)          0x54  FatLength (setores)
    0x58  ClusterHeapOffset (setores)  0x5C  ClusterCount
    0x60  FirstClusterOfRootDirectory  0x6A  VolumeFlags (bit0 = ActiveFat: 1 = usa a segunda FAT)
    0x6C  BytesPerSectorShift (9..12)  0x6D  SectorsPerClusterShift (cluster <= 32 MB)
    0x6E  NumberOfFats (1 ou 2)        0x1FE 0x55 0xAA
  Cluster N (2 .. ClusterCount+1) comeca em ClusterHeapOffset*bps + (N-2)*tam_cluster.
  FAT: u32 por cluster em FatOffset*bps + 4N; 0xFFFFFFFF = fim da cadeia, 0xFFFFFFF7 = cluster ruim.
  Diretorio = sequencia de entradas de 32 bytes. Tipo 0x00 = fim do diretorio; bit7 = em uso (sem ele = apagada).
  Um arquivo/pasta e um "conjunto" de entradas:
    0x85 File:   +1 SecondaryCount (2..18), +2 SetChecksum (u16), +4 FileAttributes (0x10 = diretorio)
    0xC0 Stream: +1 flags (bit0 AllocationPossible, bit1 NoFatChain = clusters contiguos, sem olhar a FAT),
                 +3 NameLength (em caracteres UTF-16), +8 ValidDataLength (u64), +0x14 FirstCluster (u32),
                 +0x18 DataLength (u64)
    0xC1 Name:   15 caracteres UTF-16LE a partir de +2 (quantos forem precisos para NameLength)
    0xE0.. (secundarias "benignas" de fabricante) podem vir depois e entram no SecondaryCount.
  SetChecksum: soma rotacionada de 16 bits sobre todos os bytes do conjunto, menos os bytes 2 e 3 da primeira entrada.
  A raiz nao tem tamanho registrado: segue sempre a cadeia da FAT ate 0xFFFFFFFF. As outras pastas e os arquivos
  usam DataLength e, se NoFatChain, sao contiguos; senao seguem a FAT. Bytes alem de ValidDataLength valem zero.
  Nomes nao diferenciam maiusculas (aqui: so ASCII; a comparacao completa usaria a tabela up-case do volume).

Fontes: spec exFAT da Microsoft, ps5-dump-forge (crates/ps5-dump-forge-exfat), ShadowMountPlus (mkexfat.sh, cluster
de 64 KB), ps5-conhecimento/05-formatos-de-jogos.md.

Robustez: todo offset/tamanho e validado; cadeias limitadas (pasta ate 256 MB, cadeia nunca maior que ClusterCount),
leitura so do necessario (boot sector, blocos de 4 KB de FAT e de diretorio, e o arquivo pedido). */
#include "imagem.h"

#include <stdlib.h>
#include <string.h>

#define TAM_BLOCO 4096                       /* leitura de FAT e de diretorio */
#define TAM_LEITURA (64 * 1024)              /* leitura do arquivo pedido */
#define MAX_PASTA (256ull * 1024 * 1024)     /* limite da spec para um diretorio */
#define MAX_PARTES 32                        /* partes no caminho */
#define MAX_NOME 255                         /* caracteres UTF-16 de um nome */
#define FIM_CADEIA 0xFFFFFFFFu
#define ATTR_DIR 0x10

typedef struct {
  dispositivo_t *d;
  uint32_t cl_shift;          /* log2 do tamanho do cluster em bytes */
  uint64_t fat_off, fat_bytes;
  uint64_t heap_off;
  uint32_t n_clusters;
  uint32_t raiz;
  uint8_t fat_cache[TAM_BLOCO];
  uint64_t fat_cache_rel;     /* deslocamento (relativo ao inicio da FAT) do bloco em cache */
  size_t fat_cache_n;         /* 0 = vazio */
} exfat_t;

/* Leitura sequencial de uma cadeia de clusters (pasta ou arquivo) */
typedef struct {
  uint32_t atual;             /* cluster atual */
  int contiguo;               /* NoFatChain */
  int ate_fim_cadeia;         /* raiz: termina quando a FAT disser fim (tamanho e so um teto) */
  int fim;
  uint64_t tamanho, pos, passos;
} fluxo_t;

typedef struct {
  fluxo_t f;
  uint8_t buf[TAM_BLOCO];
  size_t n, i;
} pasta_t;

/* O que interessa de uma entrada encontrada */
typedef struct {
  uint16_t attrs;
  int contiguo;
  uint32_t primeiro;
  uint64_t tamanho, valido;
} achado_t;

typedef struct {
  exfat_t fs;
  pasta_t pasta;
  uint8_t dados[TAM_LEITURA];
} trabalho_t;

static uint16_t le16(const uint8_t *p) { return (uint16_t)(p[0] | (p[1] << 8)); }
static uint32_t le32(const uint8_t *p) {
  return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}
static uint64_t le64(const uint8_t *p) { return (uint64_t)le32(p) | ((uint64_t)le32(p + 4) << 32); }

static int ler(exfat_t *fs, uint64_t off, void *buf, size_t n) {
  if(off > fs->d->tamanho || n > fs->d->tamanho - off) return -1;
  return fs->d->ler(fs->d, off, buf, n);
}

static int cluster_valido(const exfat_t *fs, uint32_t c) {
  return c >= 2 && (uint64_t)c <= (uint64_t)fs->n_clusters + 1;
}

/* Proximo cluster da cadeia pela FAT (com cache de um bloco). 0 = ok. */
static int fat_proximo(exfat_t *fs, uint32_t c, uint32_t *prox) {
  uint64_t rel = (uint64_t)c * 4;
  if(rel + 4 > fs->fat_bytes) return -1;
  uint64_t bloco = rel & ~(uint64_t)(TAM_BLOCO - 1);
  if(!fs->fat_cache_n || fs->fat_cache_rel != bloco) {
    uint64_t n = fs->fat_bytes - bloco;
    if(n > TAM_BLOCO) n = TAM_BLOCO;
    fs->fat_cache_n = 0;
    if(ler(fs, fs->fat_off + bloco, fs->fat_cache, (size_t)n)) return -1;
    fs->fat_cache_rel = bloco;
    fs->fat_cache_n = (size_t)n;
  }
  *prox = le32(fs->fat_cache + (rel - bloco));
  return 0;
}

static void fluxo_iniciar(fluxo_t *f, uint32_t primeiro, int contiguo, uint64_t tamanho, int ate_fim_cadeia) {
  memset(f, 0, sizeof *f);
  f->atual = primeiro;
  f->contiguo = contiguo;
  f->tamanho = tamanho;
  f->ate_fim_cadeia = ate_fim_cadeia;
}

/* Le ate n bytes da cadeia, na sequencia. *lidos < n so no fim do fluxo. IMG_OK ou IMG_ERRO. */
static int fluxo_ler(exfat_t *fs, fluxo_t *f, uint8_t *buf, size_t n, size_t *lidos) {
  uint64_t tam_cl = (uint64_t)1 << fs->cl_shift;
  *lidos = 0;
  while(n > 0 && f->pos < f->tamanho && !f->fim) {
    if(!cluster_valido(fs, f->atual)) return IMG_ERRO;
    uint64_t dentro = f->pos & (tam_cl - 1);
    uint64_t parte = tam_cl - dentro;
    if(parte > n) parte = n;
    if(parte > f->tamanho - f->pos) parte = f->tamanho - f->pos;
    uint64_t off = fs->heap_off + ((uint64_t)(f->atual - 2) << fs->cl_shift) + dentro;
    if(ler(fs, off, buf, (size_t)parte)) return IMG_ERRO;
    buf += parte;
    n -= (size_t)parte;
    *lidos += (size_t)parte;
    f->pos += parte;
    if((f->pos & (tam_cl - 1)) == 0 && f->pos < f->tamanho) {
      /* acabou o cluster e ainda falta: passa para o proximo */
      if(++f->passos > fs->n_clusters) return IMG_ERRO;   /* cadeia circular */
      uint32_t prox;
      if(f->contiguo) {
        prox = f->atual + 1;
      } else {
        if(fat_proximo(fs, f->atual, &prox)) return IMG_ERRO;
        if(prox == FIM_CADEIA) {
          if(!f->ate_fim_cadeia) return IMG_ERRO;   /* cadeia menor que o tamanho registrado */
          f->fim = 1;
          break;
        }
      }
      if(!cluster_valido(fs, prox)) return IMG_ERRO;
      f->atual = prox;
    }
  }
  return IMG_OK;
}

/* Proxima entrada de 32 bytes da pasta. *e = NULL no fim. */
static int pasta_proxima(exfat_t *fs, pasta_t *p, const uint8_t **e) {
  if(p->i + 32 > p->n) {
    size_t lidos;
    int r = fluxo_ler(fs, &p->f, p->buf, sizeof p->buf, &lidos);
    if(r != IMG_OK) return r;
    p->n = lidos;
    p->i = 0;
    if(lidos < 32) {
      *e = NULL;
      return IMG_OK;
    }
  }
  *e = p->buf + p->i;
  p->i += 32;
  return IMG_OK;
}

static uint16_t soma_conjunto(const uint8_t *s, size_t n) {
  uint16_t soma = 0;
  for(size_t i = 0; i < n; i++) {
    if(i == 2 || i == 3) continue;
    soma = (uint16_t)(((soma & 1) ? 0x8000 : 0) + (soma >> 1) + s[i]);
  }
  return soma;
}

static uint16_t minuscula(uint16_t c) { return (c >= 'A' && c <= 'Z') ? (uint16_t)(c + 32) : c; }

/* Confere um conjunto completo (0x85 + secundarias). 1 = e o nome procurado (preenche a). */
static int conjunto_confere(const uint8_t *s, int qtd, const uint16_t *nome, size_t tam_nome, achado_t *a) {
  if(soma_conjunto(s, (size_t)qtd * 32) != le16(s + 2)) return 0;
  const uint8_t *st = s + 32;
  if(st[0] != 0xC0) return 0;
  size_t tam = st[3];
  if(tam == 0 || tam != tam_nome) return 0;
  int precisa = (int)((tam + 14) / 15);
  if(precisa > qtd - 2) return 0;
  size_t k = 0;
  for(int j = 0; j < precisa; j++) {
    const uint8_t *nm = s + (size_t)(2 + j) * 32;
    if(nm[0] != 0xC1) return 0;
    for(int c = 0; c < 15 && k < tam; c++, k++)
      if(minuscula(le16(nm + 2 + c * 2)) != minuscula(nome[k])) return 0;
  }
  a->attrs = le16(s + 4);
  a->contiguo = (st[1] & 2) != 0;
  a->primeiro = le32(st + 0x14);
  a->tamanho = le64(st + 0x18);
  a->valido = le64(st + 8);
  if(!(st[1] & 1)) a->tamanho = a->valido = 0;   /* sem alocacao */
  return 1;
}

/* Procura "nome" na pasta ja iniciada em p. IMG_OK / IMG_NAO_ACHOU / IMG_ERRO. */
static int pasta_buscar(exfat_t *fs, pasta_t *p, const uint16_t *nome, size_t tam_nome, achado_t *a) {
  uint8_t conj[19 * 32];
  int qtd = 0, esperado = 0;
  for(;;) {
    const uint8_t *e;
    int r = pasta_proxima(fs, p, &e);
    if(r != IMG_OK) return r;
    if(!e || e[0] == 0x00) return IMG_NAO_ACHOU;
    if(esperado) {
      if(e[0] >= 0xC0) {   /* secundaria em uso */
        memcpy(conj + (size_t)qtd * 32, e, 32);
        if(++qtd == esperado) {
          if(conjunto_confere(conj, qtd, nome, tam_nome, a)) return IMG_OK;
          esperado = 0;
        }
        continue;
      }
      esperado = 0;   /* conjunto interrompido: descarta e trata esta entrada como nova */
    }
    if(e[0] == 0x85 && e[1] >= 2 && e[1] <= 18) {
      memcpy(conj, e, 32);
      qtd = 1;
      esperado = e[1] + 1;
    }
  }
}

/* Converte uma parte do caminho (UTF-8, n bytes) para UTF-16. Devolve o tamanho ou -1. */
static int utf8_para_16(const char *s, size_t n, uint16_t *out, size_t max) {
  size_t k = 0;
  for(size_t i = 0; i < n;) {
    uint8_t c = (uint8_t)s[i];
    uint32_t cp;
    int extra;
    if(c < 0x80) { cp = c; extra = 0; }
    else if((c & 0xE0) == 0xC0) { cp = c & 0x1F; extra = 1; }
    else if((c & 0xF0) == 0xE0) { cp = c & 0x0F; extra = 2; }
    else if((c & 0xF8) == 0xF0) { cp = c & 0x07; extra = 3; }
    else return -1;
    if(i + 1 + (size_t)extra > n) return -1;
    for(int j = 1; j <= extra; j++) {
      uint8_t b = (uint8_t)s[i + j];
      if((b & 0xC0) != 0x80) return -1;
      cp = (cp << 6) | (b & 0x3F);
    }
    i += 1 + (size_t)extra;
    if(cp > 0x10FFFF || (cp >= 0xD800 && cp <= 0xDFFF)) return -1;
    if(cp >= 0x10000) {
      if(k + 2 > max) return -1;
      cp -= 0x10000;
      out[k++] = (uint16_t)(0xD800 + (cp >> 10));
      out[k++] = (uint16_t)(0xDC00 + (cp & 0x3FF));
    } else {
      if(k + 1 > max) return -1;
      out[k++] = (uint16_t)cp;
    }
  }
  return (int)k;
}

/* Le o boot sector e preenche fs. IMG_OK / IMG_FORMATO / IMG_ERRO. */
static int montar(exfat_t *fs, dispositivo_t *d) {
  uint8_t bs[512];
  memset(fs, 0, sizeof *fs);
  fs->d = d;
  if(d->tamanho < sizeof bs) return IMG_FORMATO;
  if(d->ler(d, 0, bs, sizeof bs)) return IMG_ERRO;
  if(memcmp(bs + 3, "EXFAT   ", 8) != 0) return IMG_FORMATO;
  if(bs[510] != 0x55 || bs[511] != 0xAA) return IMG_ERRO;
  uint32_t bps_shift = bs[0x6C], spc_shift = bs[0x6D], n_fats = bs[0x6E];
  if(bps_shift < 9 || bps_shift > 12 || spc_shift > 25 - bps_shift) return IMG_ERRO;
  if(n_fats != 1 && n_fats != 2) return IMG_ERRO;
  uint64_t fat_off = le32(bs + 0x50), fat_len = le32(bs + 0x54), heap = le32(bs + 0x58);
  fs->n_clusters = le32(bs + 0x5C);
  fs->raiz = le32(bs + 0x60);
  if(fs->n_clusters == 0 || fs->n_clusters > 0xFFFFFFF5u || fat_len == 0) return IMG_ERRO;
  if((le16(bs + 0x6A) & 1) && n_fats == 2) fat_off += fat_len;   /* ActiveFat = segunda FAT */
  fs->cl_shift = bps_shift + spc_shift;
  fs->fat_off = fat_off << bps_shift;
  fs->fat_bytes = fat_len << bps_shift;
  fs->heap_off = heap << bps_shift;
  if(fs->fat_bytes < ((uint64_t)fs->n_clusters + 2) * 4) return IMG_ERRO;
  if(!cluster_valido(fs, fs->raiz)) return IMG_ERRO;
  return IMG_OK;
}

static int ler_caminho(trabalho_t *t, const char *caminho, buf_t *saida, size_t max) {
  exfat_t *fs = &t->fs;
  pasta_t *p = &t->pasta;
  uint16_t nome[MAX_NOME];
  achado_t a;
  int partes = 0;

  /* comeca na raiz: segue a FAT, no maximo 256 MB */
  fluxo_iniciar(&p->f, fs->raiz, 0, MAX_PASTA, 1);
  p->n = p->i = 0;

  const char *s = caminho;
  for(;;) {
    while(*s == '/') s++;
    if(!*s) return IMG_NAO_ACHOU;   /* caminho vazio ou terminado em "/" */
    const char *fim = s;
    while(*fim && *fim != '/') fim++;
    if(++partes > MAX_PARTES) return IMG_NAO_ACHOU;
    int tam = utf8_para_16(s, (size_t)(fim - s), nome, MAX_NOME);
    if(tam <= 0) return IMG_NAO_ACHOU;
    int r = pasta_buscar(fs, p, nome, (size_t)tam, &a);
    if(r != IMG_OK) return r;
    s = fim;
    while(*s == '/') s++;
    if(!*s) break;   /* ultima parte: o arquivo */
    if(!(a.attrs & ATTR_DIR)) return IMG_NAO_ACHOU;
    if(a.tamanho == 0) return IMG_NAO_ACHOU;   /* pasta vazia */
    if(a.tamanho > MAX_PASTA || !cluster_valido(fs, a.primeiro)) return IMG_ERRO;
    fluxo_iniciar(&p->f, a.primeiro, a.contiguo, a.tamanho, 0);
    p->n = p->i = 0;
  }

  if(a.attrs & ATTR_DIR) return IMG_NAO_ACHOU;
  if(a.tamanho > max) return IMG_ERRO;
  uint64_t valido = a.valido < a.tamanho ? a.valido : a.tamanho;
  if(a.tamanho > 0 && !cluster_valido(fs, a.primeiro)) return IMG_ERRO;

  fluxo_t f;
  fluxo_iniciar(&f, a.primeiro, a.contiguo, valido, 0);
  while(f.pos < valido) {
    size_t lidos;
    int r = fluxo_ler(fs, &f, t->dados, sizeof t->dados, &lidos);
    if(r != IMG_OK) return r;
    if(lidos == 0) return IMG_ERRO;
    buf_add(saida, t->dados, lidos);
  }
  /* alem do ValidDataLength: zeros */
  memset(t->dados, 0, sizeof t->dados);
  for(uint64_t resto = a.tamanho - valido; resto > 0;) {
    size_t n = resto > sizeof t->dados ? sizeof t->dados : (size_t)resto;
    buf_add(saida, t->dados, n);
    resto -= n;
  }
  return IMG_OK;
}

int exfat_ler(dispositivo_t *d, const char *caminho, buf_t *saida, size_t max) {
  if(!d || !d->ler || !caminho || !saida) return IMG_ERRO;
  trabalho_t *t = malloc(sizeof *t);
  if(!t) return IMG_ERRO;
  size_t n_antes = saida->n;
  int r = montar(&t->fs, d);
  if(r == IMG_OK) r = ler_caminho(t, caminho, saida, max);
  if(r != IMG_OK && saida->n != n_antes) {   /* erro no meio: desfaz o que acrescentou */
    saida->n = n_antes;
    saida->d[n_antes] = 0;
  }
  free(t);
  return r;
}
