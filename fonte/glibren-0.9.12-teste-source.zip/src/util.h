/* Game Library Renamer (payload PS5) - utilitarios: buffer dinamico, JSON e parametros de URL. */
#pragma once

#include <stddef.h>

typedef struct {
  char *d;
  size_t n, cap;
} buf_t;

void buf_add(buf_t *b, const void *dados, size_t n);
void buf_str(buf_t *b, const char *s);
void buf_fmt(buf_t *b, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
void buf_json(buf_t *b, const char *s);   /* string JSON com aspas e escapes */
void buf_free(buf_t *b);

/* Le o parametro "nome" (n-esima ocorrencia, a partir de 0) de uma query/form urlencoded.
   Devolve 1 se achou (saida decodificada e terminada em \0), 0 se nao. */
int param(const char *qs, const char *nome, int ocorrencia, char *saida, size_t tam);

/* Caminho absoluto, sem "..", sem barras duplas no meio; aceita "/" sozinho. */
int caminho_valido(const char *caminho);

/* Nome de arquivo simples (sem / nem \, nao e "." nem ".."). */
int nome_valido(const char *nome);

int mkdir_p(const char *caminho);

/* Thread com pilha de 1 MB (a pilha padrao do PS5 pode ser pequena para os buffers das conexoes).
   t = NULL: thread destacada (ninguem espera por ela). Devolve 0 se criou. */
#include <pthread.h>
int criar_thread(void *(*fn)(void *), void *arg, pthread_t *t);
