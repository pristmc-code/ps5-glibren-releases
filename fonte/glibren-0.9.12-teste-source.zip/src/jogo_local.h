/* Game Library Renamer (payload PS5) - nome, Title ID e icone de dentro do arquivo do jogo. Ver jogo_local.c. */
#pragma once

#include <stddef.h>

#include "imagem.h"

/* 0 = achou (info preenchido; icone gravado em pasta_icones/<TITLEID>.png se ainda nao existia); -1 = nao deu. */
int jogo_local(const char *caminho, const char *pasta_icones, info_jogo_t *info, char *formato, size_t tam_formato);
