/* Game Library Renamer (payload PS5) - uso de CPU (total e por nucleo), memoria, IP e tempo ligado.
   Uma thread mede a cada 2 s; quem pede so le o ultimo valor. Se o sistema nao informar algo, vem -1. */
#pragma once

#include "util.h"

void sistema_iniciar(void);
void sistema_json(buf_t *b);   /* "sistema":{...} (sem chaves em volta) */
