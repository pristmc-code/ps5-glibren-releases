/* Game Library Renamer (payload PS5) - leitura do param.json (PS5) e do param.sfo (PS4). Ver imagem.h.

param.json: JSON comum. Interessam titleId (ou title_id), contentId, titleName na raiz e
  "localizedParameters": {"defaultLanguage": "en-US", "en-US": {"titleName": "..."}, "pt-BR": {...}}.
  Parser proprio e pequeno (sem biblioteca): valida o documento inteiro (JSON estrito, profundidade limitada),
  decodifica escapes \" \\ \/ \b \f \n \r \t \uXXXX (pares substitutos viram um caractere UTF-8).
  Nome: idioma pedido -> defaultLanguage -> en-US -> primeiro idioma com titleName -> titleName da raiz.
  Codigos de idioma comparados sem diferenciar maiusculas.

param.sfo (little-endian; LibOrbisPkg SFO/ParamSfo.cs e ShadowMountPlus parse_sfo):
  "\0PSF", 0x08 key_table, 0x0C data_table, 0x10 count; itens de 16 bytes a partir de 0x14:
  key_off (u16), fmt (u16: 0x0004 utf8 sem NUL, 0x0204 utf8 com NUL, 0x0404 int32), len, max_len, data_off.
  Arquivo comecando com "SCEC": o SFO real esta em +0x800.
  Nome: TITLE_XX do idioma pedido -> TITLE (padrao do jogo).

Strings de saida: sempre terminadas em \0, truncadas sem cortar caractere UTF-8; bytes UTF-8 invalidos,
\u0000 e substitutos soltos viram U+FFFD; caracteres de controle (\n, \t...) viram espaco.
Title ID: 4 letras A-Z + 5 digitos; senao tira do Content ID ("UP0000-CUSA12345_00-...", posicoes 7..15). */
#include <string.h>

#include "imagem.h"

#define MAX_PROFUNDIDADE 32

/* ---------- utilitarios comuns ---------- */

/* Escritor de UTF-8 com limite: quando o proximo caractere nao cabe, para de escrever (nao corta no meio). */
typedef struct {
  char *s;
  size_t tam, n;
  int cheio;
} saida_t;

static void saida_ini(saida_t *o, char *s, size_t tam) {
  o->s = s;
  o->tam = tam;
  o->n = 0;
  o->cheio = tam == 0;
  if(tam) s[0] = 0;
}

static void saida_cp(saida_t *o, uint32_t cp) {
  char b[4];
  size_t k;
  if(cp < 0x20 || cp == 0x7F) cp = ' ';                          /* controle -> espaco */
  if(cp > 0x10FFFF || (cp >= 0xD800 && cp <= 0xDFFF)) cp = 0xFFFD;
  if(cp < 0x80) {
    b[0] = (char)cp;
    k = 1;
  } else if(cp < 0x800) {
    b[0] = (char)(0xC0 | (cp >> 6));
    b[1] = (char)(0x80 | (cp & 0x3F));
    k = 2;
  } else if(cp < 0x10000) {
    b[0] = (char)(0xE0 | (cp >> 12));
    b[1] = (char)(0x80 | ((cp >> 6) & 0x3F));
    b[2] = (char)(0x80 | (cp & 0x3F));
    k = 3;
  } else {
    b[0] = (char)(0xF0 | (cp >> 18));
    b[1] = (char)(0x80 | ((cp >> 12) & 0x3F));
    b[2] = (char)(0x80 | ((cp >> 6) & 0x3F));
    b[3] = (char)(0x80 | (cp & 0x3F));
    k = 4;
  }
  if(o->cheio || o->n + k + 1 > o->tam) {
    o->cheio = 1;
    return;
  }
  memcpy(o->s + o->n, b, k);
  o->n += k;
  o->s[o->n] = 0;
}

/* Decodifica um caractere UTF-8 de p (ate fim). Invalido: devolve 0xFFFD e avanca 1 byte. */
static uint32_t utf8_proximo(const uint8_t **pp, const uint8_t *fim) {
  const uint8_t *p = *pp;
  uint8_t c = *p;
  uint32_t cp, minimo;
  size_t k;
  if(c < 0x80) {
    *pp = p + 1;
    return c;
  }
  if(c >= 0xC2 && c <= 0xDF) { k = 2; cp = c & 0x1F; minimo = 0x80; }
  else if(c >= 0xE0 && c <= 0xEF) { k = 3; cp = c & 0x0F; minimo = 0x800; }
  else if(c >= 0xF0 && c <= 0xF4) { k = 4; cp = c & 0x07; minimo = 0x10000; }
  else { *pp = p + 1; return 0xFFFD; }
  if((size_t)(fim - p) < k) { *pp = p + 1; return 0xFFFD; }
  for(size_t i = 1; i < k; i++) {
    if((p[i] & 0xC0) != 0x80) { *pp = p + 1; return 0xFFFD; }
    cp = (cp << 6) | (p[i] & 0x3F);
  }
  if(cp < minimo || cp > 0x10FFFF || (cp >= 0xD800 && cp <= 0xDFFF)) { *pp = p + 1; return 0xFFFD; }
  *pp = p + k;
  return cp;
}

static int title_id_valido(const char *t) {
  for(int i = 0; i < 4; i++)
    if(t[i] < 'A' || t[i] > 'Z') return 0;
  for(int i = 4; i < 9; i++)
    if(t[i] < '0' || t[i] > '9') return 0;
  return t[9] == 0;
}

static int content_id_valido(const char *c) {
  size_t n = 0;
  for(; c[n]; n++) {
    char x = c[n];
    if(!((x >= '0' && x <= '9') || (x >= 'A' && x <= 'Z') || (x >= 'a' && x <= 'z') || x == '-' || x == '_'))
      return 0;
  }
  return n > 0 && n < sizeof(((info_jogo_t *)0)->content_id);
}

/* Title ID das posicoes 7..15 do Content ID ("UP0000-CUSA12345_00-..."). */
static void title_id_do_content_id(info_jogo_t *info) {
  const char *c = info->content_id;
  if(strlen(c) < 17 || c[6] != '-' || c[16] != '_') return;
  char t[10];
  memcpy(t, c + 7, 9);
  t[9] = 0;
  if(title_id_valido(t)) memcpy(info->title_id, t, 10);
}

/* Fecha os campos: valida title_id e content_id, deriva o title_id se preciso. */
static void finalizar(info_jogo_t *info) {
  if(!content_id_valido(info->content_id)) info->content_id[0] = 0;
  if(!title_id_valido(info->title_id)) info->title_id[0] = 0;
  if(!info->title_id[0]) title_id_do_content_id(info);
}

static int igual_sem_caixa(const char *a, const char *b) {
  for(;; a++, b++) {
    char x = *a, y = *b;
    if(x >= 'A' && x <= 'Z') x = (char)(x - 'A' + 'a');
    if(y >= 'A' && y <= 'Z') y = (char)(y - 'A' + 'a');
    if(x != y) return 0;
    if(!x) return 1;
  }
}

/* ---------- param.json ---------- */

typedef struct {
  const char *p, *fim;
} json_t;

static void pular_espacos(json_t *j) {
  while(j->p < j->fim && (*j->p == ' ' || *j->p == '\t' || *j->p == '\n' || *j->p == '\r')) j->p++;
}

static int hex4(const char *p, uint32_t *v) {
  *v = 0;
  for(int i = 0; i < 4; i++) {
    char c = p[i];
    uint32_t x;
    if(c >= '0' && c <= '9') x = (uint32_t)(c - '0');
    else if(c >= 'a' && c <= 'f') x = (uint32_t)(c - 'a' + 10);
    else if(c >= 'A' && c <= 'F') x = (uint32_t)(c - 'A' + 10);
    else return 0;
    *v = (*v << 4) | x;
  }
  return 1;
}

/* Le uma string JSON (j->p no '"'). o pode ser NULL (so pula). 0 = ok. */
static int json_string(json_t *j, saida_t *o) {
  if(j->p >= j->fim || *j->p != '"') return -1;
  j->p++;
  while(j->p < j->fim) {
    uint8_t c = (uint8_t)*j->p;
    if(c == '"') {
      j->p++;
      return 0;
    }
    if(c < 0x20) return -1;   /* controle cru dentro de string: JSON invalido */
    if(c != '\\') {
      const uint8_t *u = (const uint8_t *)j->p;
      uint32_t cp = utf8_proximo(&u, (const uint8_t *)j->fim);
      j->p = (const char *)u;
      if(o) saida_cp(o, cp);
      continue;
    }
    if(j->fim - j->p < 2) return -1;
    char e = j->p[1];
    j->p += 2;
    uint32_t cp;
    switch(e) {
    case '"': cp = '"'; break;
    case '\\': cp = '\\'; break;
    case '/': cp = '/'; break;
    case 'b': cp = '\b'; break;
    case 'f': cp = '\f'; break;
    case 'n': cp = '\n'; break;
    case 'r': cp = '\r'; break;
    case 't': cp = '\t'; break;
    case 'u':
      if(j->fim - j->p < 4 || !hex4(j->p, &cp)) return -1;
      j->p += 4;
      if(cp >= 0xD800 && cp <= 0xDBFF) {
        /* par substituto: precisa do \uDC00..\uDFFF logo depois */
        uint32_t baixo;
        if(j->fim - j->p >= 6 && j->p[0] == '\\' && j->p[1] == 'u' && hex4(j->p + 2, &baixo) && baixo >= 0xDC00 &&
           baixo <= 0xDFFF) {
          j->p += 6;
          cp = 0x10000 + ((cp - 0xD800) << 10) + (baixo - 0xDC00);
        } else {
          cp = 0xFFFD;
        }
      } else if((cp >= 0xDC00 && cp <= 0xDFFF) || cp == 0) {
        cp = 0xFFFD;
      }
      break;
    default: return -1;
    }
    if(o) saida_cp(o, cp);
  }
  return -1;   /* acabou sem fechar aspas */
}

/* Le uma chave curta. Chave maior que o buffer vira "" (nunca casa por engano). */
static int json_chave(json_t *j, char *k, size_t tam) {
  saida_t o;
  saida_ini(&o, k, tam);
  if(json_string(j, &o) != 0) return -1;
  if(o.cheio) k[0] = 0;
  pular_espacos(j);
  if(j->p >= j->fim || *j->p != ':') return -1;
  j->p++;
  pular_espacos(j);
  return 0;
}

static int json_literal(json_t *j, const char *lit) {
  size_t n = strlen(lit);
  if((size_t)(j->fim - j->p) < n || memcmp(j->p, lit, n) != 0) return -1;
  j->p += n;
  return 0;
}

static int json_numero(json_t *j) {
  const char *ini = j->p;
  if(j->p < j->fim && *j->p == '-') j->p++;
  const char *dig = j->p;
  while(j->p < j->fim && *j->p >= '0' && *j->p <= '9') j->p++;
  if(j->p == dig) return -1;
  if(j->p < j->fim && *j->p == '.') {
    j->p++;
    dig = j->p;
    while(j->p < j->fim && *j->p >= '0' && *j->p <= '9') j->p++;
    if(j->p == dig) return -1;
  }
  if(j->p < j->fim && (*j->p == 'e' || *j->p == 'E')) {
    j->p++;
    if(j->p < j->fim && (*j->p == '+' || *j->p == '-')) j->p++;
    dig = j->p;
    while(j->p < j->fim && *j->p >= '0' && *j->p <= '9') j->p++;
    if(j->p == dig) return -1;
  }
  return j->p > ini ? 0 : -1;
}

/* Pula um valor qualquer (j->p no inicio do valor, sem espacos antes). 0 = ok. */
static int json_pular(json_t *j, int prof) {
  if(prof > MAX_PROFUNDIDADE || j->p >= j->fim) return -1;
  char c = *j->p;
  if(c == '"') return json_string(j, NULL);
  if(c == 't') return json_literal(j, "true");
  if(c == 'f') return json_literal(j, "false");
  if(c == 'n') return json_literal(j, "null");
  if(c == '-' || (c >= '0' && c <= '9')) return json_numero(j);
  if(c != '{' && c != '[') return -1;
  char fecha = c == '{' ? '}' : ']';
  j->p++;
  pular_espacos(j);
  if(j->p < j->fim && *j->p == fecha) {
    j->p++;
    return 0;
  }
  for(;;) {
    if(c == '{') {
      char k[2];
      if(json_chave(j, k, sizeof k) != 0) return -1;
    }
    if(json_pular(j, prof + 1) != 0) return -1;
    pular_espacos(j);
    if(j->p >= j->fim) return -1;
    if(*j->p == ',') {
      j->p++;
      pular_espacos(j);
      continue;
    }
    if(*j->p != fecha) return -1;
    j->p++;
    return 0;
  }
}

/* Percorre um objeto (j->p no '{'), chamando fn(chave) com j->p no valor; fn deve consumir o valor. */
typedef int (*json_campo_fn)(json_t *j, const char *chave, void *ctx, int prof);

static int json_objeto(json_t *j, json_campo_fn fn, void *ctx, int prof) {
  if(prof > MAX_PROFUNDIDADE || j->p >= j->fim || *j->p != '{') return -1;
  j->p++;
  pular_espacos(j);
  if(j->p < j->fim && *j->p == '}') {
    j->p++;
    return 0;
  }
  for(;;) {
    char k[64];
    if(json_chave(j, k, sizeof k) != 0) return -1;
    if(fn(j, k, ctx, prof) != 0) return -1;
    pular_espacos(j);
    if(j->p >= j->fim) return -1;
    if(*j->p == ',') {
      j->p++;
      pular_espacos(j);
      continue;
    }
    if(*j->p != '}') return -1;
    j->p++;
    return 0;
  }
}

/* Le o valor como string se for string (para dest), senao pula. */
static int json_valor_texto(json_t *j, char *dest, size_t tam, int prof) {
  if(j->p < j->fim && *j->p == '"') {
    saida_t o;
    saida_ini(&o, dest, tam);
    return json_string(j, &o);
  }
  return json_pular(j, prof + 1);
}

typedef struct {
  const char *idioma;
  char padrao[64];          /* defaultLanguage */
  char nome_pedido[256], nome_padrao[256], nome_en[256], nome_qualquer[256], nome_raiz[256];
  char title_id[16], title_id2[16], content_id[64];
  int passada;              /* localizedParameters: 1 = so defaultLanguage; 2 = nomes */
  char tmp[256];
} json_ctx_t;

/* Dentro de "<idioma>": {...}: so o titleName */
static int campo_idioma(json_t *j, const char *chave, void *ctx, int prof) {
  json_ctx_t *c = ctx;
  if(strcmp(chave, "titleName") == 0) return json_valor_texto(j, c->tmp, sizeof c->tmp, prof);
  return json_pular(j, prof + 1);
}

static int campo_localizado(json_t *j, const char *chave, void *ctx, int prof) {
  json_ctx_t *c = ctx;
  if(strcmp(chave, "defaultLanguage") == 0) {
    if(c->passada == 1) return json_valor_texto(j, c->padrao, sizeof c->padrao, prof);
    return json_pular(j, prof + 1);
  }
  if(c->passada != 2 || !chave[0] || j->p >= j->fim || *j->p != '{') return json_pular(j, prof + 1);
  c->tmp[0] = 0;
  if(json_objeto(j, campo_idioma, c, prof + 1) != 0) return -1;
  if(!c->tmp[0]) return 0;
  if(c->idioma && !c->nome_pedido[0] && igual_sem_caixa(chave, c->idioma)) memcpy(c->nome_pedido, c->tmp, 256);
  if(c->padrao[0] && !c->nome_padrao[0] && igual_sem_caixa(chave, c->padrao)) memcpy(c->nome_padrao, c->tmp, 256);
  if(!c->nome_en[0] && igual_sem_caixa(chave, "en-US")) memcpy(c->nome_en, c->tmp, 256);
  if(!c->nome_qualquer[0]) memcpy(c->nome_qualquer, c->tmp, 256);
  return 0;
}

static int campo_raiz(json_t *j, const char *chave, void *ctx, int prof) {
  json_ctx_t *c = ctx;
  if(strcmp(chave, "titleId") == 0) return json_valor_texto(j, c->title_id, sizeof c->title_id, prof);
  if(strcmp(chave, "title_id") == 0) return json_valor_texto(j, c->title_id2, sizeof c->title_id2, prof);
  if(strcmp(chave, "contentId") == 0) return json_valor_texto(j, c->content_id, sizeof c->content_id, prof);
  if(strcmp(chave, "titleName") == 0) return json_valor_texto(j, c->nome_raiz, sizeof c->nome_raiz, prof);
  if(strcmp(chave, "localizedParameters") == 0 && j->p < j->fim && *j->p == '{') {
    /* duas passadas: o defaultLanguage pode vir depois dos idiomas */
    const char *ini = j->p;
    c->passada = 1;
    if(json_objeto(j, campo_localizado, c, prof + 1) != 0) return -1;
    j->p = ini;
    c->passada = 2;
    return json_objeto(j, campo_localizado, c, prof + 1);
  }
  return json_pular(j, prof + 1);
}

static void copiar(char *dest, size_t tam, const char *orig) {
  size_t n = strlen(orig);
  if(n >= tam) return;   /* nao cabe inteiro: ignora (campos de tamanho fixo) */
  memcpy(dest, orig, n + 1);
}

int param_json_ler(const char *dados, size_t n, const char *idioma, info_jogo_t *info) {
  if(!info) return -1;
  memset(info, 0, sizeof *info);
  if(!dados) return -1;
  /* aceita BOM UTF-8 no inicio e NULs/espacos no fim */
  if(n >= 3 && (uint8_t)dados[0] == 0xEF && (uint8_t)dados[1] == 0xBB && (uint8_t)dados[2] == 0xBF) {
    dados += 3;
    n -= 3;
  }
  while(n && dados[n - 1] == 0) n--;
  json_t j = {dados, dados + n};
  json_ctx_t c;
  memset(&c, 0, sizeof c);
  c.idioma = idioma && idioma[0] ? idioma : NULL;
  pular_espacos(&j);
  if(json_objeto(&j, campo_raiz, &c, 0) != 0) return -1;
  pular_espacos(&j);
  if(j.p != j.fim) return -1;   /* lixo depois do objeto */

  copiar(info->title_id, sizeof info->title_id, title_id_valido(c.title_id) ? c.title_id : c.title_id2);
  copiar(info->content_id, sizeof info->content_id, c.content_id);
  const char *nome = c.nome_pedido[0]   ? c.nome_pedido
                     : c.nome_padrao[0] ? c.nome_padrao
                     : c.nome_en[0]     ? c.nome_en
                     : c.nome_qualquer[0] ? c.nome_qualquer
                                          : c.nome_raiz;
  memcpy(info->nome, nome, sizeof info->nome);
  info->nome[sizeof info->nome - 1] = 0;
  finalizar(info);
  return info->title_id[0] || info->nome[0] ? 0 : -1;
}

/* ---------- param.sfo ---------- */

/* Codigo de idioma do PS5 -> numero do TITLE_XX do param.sfo.
   Numeros = enum OrbisSystemParamLanguage do OpenOrbis (include/orbis/_types/sys_service.h), conferido em 04/11/2026. */
static const struct {
  const char *codigo;
  int num;
} g_idiomas[] = {
  {"ja-JP", 0},  {"en-US", 1},  {"fr-FR", 2},  {"es-ES", 3},  {"de-DE", 4},  {"it-IT", 5},
  {"nl-NL", 6},  {"pt-PT", 7},  {"ru-RU", 8},  {"ko-KR", 9},  {"zh-Hant", 10}, {"zh-TW", 10},
  {"zh-Hans", 11}, {"zh-CN", 11}, {"fi-FI", 12}, {"sv-SE", 13}, {"da-DK", 14}, {"no-NO", 15},
  {"nb-NO", 15}, {"pl-PL", 16}, {"pt-BR", 17}, {"en-GB", 18}, {"tr-TR", 19}, {"es-419", 20},
  {"es-LA", 20}, {"ar-AE", 21}, {"fr-CA", 22}, {"cs-CZ", 23}, {"hu-HU", 24}, {"el-GR", 25},
  {"ro-RO", 26}, {"th-TH", 27}, {"vi-VN", 28}, {"id-ID", 29},
};

static int numero_idioma(const char *idioma) {
  if(!idioma) return -1;
  for(size_t i = 0; i < sizeof g_idiomas / sizeof g_idiomas[0]; i++)
    if(igual_sem_caixa(idioma, g_idiomas[i].codigo)) return g_idiomas[i].num;
  return -1;
}

static uint32_t le32(const uint8_t *p) {
  return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

/* Copia o valor texto do SFO (ate NUL ou len) como UTF-8 saneado. */
static void sfo_texto(const uint8_t *v, size_t len, char *dest, size_t tam) {
  saida_t o;
  saida_ini(&o, dest, tam);
  const uint8_t *fim = v;
  while((size_t)(fim - v) < len && *fim) fim++;
  while(v < fim && !o.cheio) saida_cp(&o, utf8_proximo(&v, fim));
}

int param_sfo_ler(const void *dados, size_t n, const char *idioma, info_jogo_t *info) {
  if(!info) return -1;
  memset(info, 0, sizeof *info);
  const uint8_t *d = dados;
  if(!d) return -1;
  if(n >= 4 && memcmp(d, "SCEC", 4) == 0) {
    if(n < 0x800) return -1;
    d += 0x800;
    n -= 0x800;
  }
  if(n < 20 || memcmp(d, "\0PSF", 4) != 0) return -1;
  uint32_t chaves = le32(d + 8), valores = le32(d + 12), qtd = le32(d + 16);
  if(chaves >= n || valores > n || qtd > (n - 20) / 16) return -1;

  int num = numero_idioma(idioma);
  char nome_idioma[256] = "", nome[256] = "", title_id[16] = "", content_id[64] = "", categoria[8] = "";
  for(uint32_t i = 0; i < qtd; i++) {
    const uint8_t *e = d + 20 + (size_t)i * 16;
    uint16_t fmt = (uint16_t)(e[2] | (e[3] << 8));
    size_t pos_chave = (size_t)chaves + (uint16_t)(e[0] | (e[1] << 8));
    size_t pos_valor = (size_t)valores + le32(e + 12);
    uint32_t len = le32(e + 4);
    if(fmt != 0x0004 && fmt != 0x0204) continue;
    if(pos_chave >= n || pos_valor > n || len > n - pos_valor) continue;
    const uint8_t *k = d + pos_chave;
    const uint8_t *kfim = memchr(k, 0, n - pos_chave);
    if(!kfim) continue;
    size_t klen = (size_t)(kfim - k);
    const uint8_t *v = d + pos_valor;
    if(klen == 5 && memcmp(k, "TITLE", 5) == 0) {
      sfo_texto(v, len, nome, sizeof nome);
    } else if(klen == 8 && k[6] >= '0' && k[6] <= '9' && k[7] >= '0' && k[7] <= '9' && memcmp(k, "TITLE_", 6) == 0) {
      /* TITLE_XX (cuidado: "TITLE_ID" tambem tem 8 letras, mas nao tem digitos) */
      if((k[6] - '0') * 10 + (k[7] - '0') == num) sfo_texto(v, len, nome_idioma, sizeof nome_idioma);
    } else if(klen == 8 && memcmp(k, "TITLE_ID", 8) == 0) {
      sfo_texto(v, len, title_id, sizeof title_id);
    } else if(klen == 10 && memcmp(k, "CONTENT_ID", 10) == 0) {
      sfo_texto(v, len, content_id, sizeof content_id);
    } else if(klen == 8 && memcmp(k, "CATEGORY", 8) == 0) {
      sfo_texto(v, len, categoria, sizeof categoria);
    }
  }
  copiar(info->title_id, sizeof info->title_id, title_id);
  copiar(info->content_id, sizeof info->content_id, content_id);
  copiar(info->categoria, sizeof info->categoria, categoria);
  memcpy(info->nome, nome_idioma[0] ? nome_idioma : nome, sizeof info->nome);
  finalizar(info);
  return info->title_id[0] || info->nome[0] ? 0 : -1;
}
