/* Game Library Renamer (payload PS5) - teste de velocidade da internet do PS5 (servidores do speedtest.net perto do PS5 ou Cloudflare). */
#pragma once

#include "util.h"

/* servidor: "auto" (ou vazio), "cloudflare" ou o host:porta de um item de internet_servidores. 0 = iniciou */
int internet_testar(const char *servidor, char *msg, size_t tam);
/* Servidores mais proximos do PS5 (lista do speedtest.net, guardada por 30 min). */
void internet_servidores(buf_t *json);
void internet_cancelar(void);
void internet_estado(buf_t *json);
