/* Game Library Renamer - payload para PS5.

Sobe um servidor web no PS5 (porta 8765). A tela abre no navegador do PC, do celular ou do proprio
PS5 em http://IP-DO-PS5:8765. Uso: enviar o .elf para o elfldr (porta 9021).
Opcoes (teste no PC): -p PORTA  -d PASTA_DE_DADOS
*/
#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#include "api.h"
#include "atualizacao.h"
#include "config.h"
#include "http.h"
#include "https.h"
#include "plataforma.h"
#include "relogio.h"
#include "tarefas.h"
#include "termico.h"
#include "sistema.h"
#include "discos.h"

#ifdef __PROSPERO__
#define PASTA_DADOS "/data/GameLibraryRenamer"
#else
#define PASTA_DADOS "./dados"
#endif

/* Outra copia ja esta rodando na porta (ex.: versao antiga): pede para ela sair. */
static void encerrar_copia_anterior(int porta) {
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  struct sockaddr_in end = {0};
  end.sin_family = AF_INET;
  end.sin_port = htons(porta);
  end.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  if(fd >= 0 && !connect(fd, (struct sockaddr *)&end, sizeof end)) {
    const char *pedido = "POST /api/sair HTTP/1.1\r\nHost: 127.0.0.1\r\nX-GLR: 1\r\nContent-Length: 0\r\n\r\n";
    send(fd, pedido, strlen(pedido), 0);
    char resposta[256];
    while(recv(fd, resposta, sizeof resposta, 0) > 0) {}
  }
  if(fd >= 0) close(fd);
}

/* O PS5 manda SIGCONT ao sair do modo de repouso: a rede volta e a porta precisa ser reaberta. */
static void ao_voltar_do_repouso(int sinal) {
  (void)sinal;
  servidor_reabrir();
  relogio_acordou();   /* o relogio pode ter andado errado no repouso: confere logo */
}

int main(int argc, char *argv[]) {
  const char *pasta_dados = PASTA_DADOS;
  int c;
  while((c = getopt(argc, argv, "p:d:")) != -1) {
    if(c == 'p') g_porta = atoi(optarg);
    else if(c == 'd') pasta_dados = optarg;
  }
  plataforma_iniciar(pasta_dados);   /* permissoes, nome do processo, copias antigas, diario */
  config_iniciar(pasta_dados);
  if(atualizacao_ao_iniciar()) return EXIT_SUCCESS;   /* o autoloader mandou a versao antiga: a gravada assume */
  https_iniciar();
  api_atualizar_base(0);
  tarefas_iniciar();
  termico_iniciar();
  sistema_iniciar();
  relogio_iniciar();
  discos_limpar_sobras();
  signal(SIGCONT, ao_voltar_do_repouso);
  plataforma_instalar_icone(g_porta);
  diario("servidor na porta %d", g_porta);

  for(int tentativa = 0; tentativa < 10; tentativa++) {
    char ip[64] = "IP-DO-PS5";
    meu_ip(ip, sizeof ip);
    /* servidor_rodar so volta em erro (ou ao sair pela tela) */
    if(tentativa == 0) notificar("Game Library Renamer: abra http://%s:%d", ip, g_porta);
    if(!servidor_rodar(g_porta, api_tratar)) {
      diario("encerrado pela tela (Sair)");
      return EXIT_SUCCESS;
    }
    diario("porta %d: %s", g_porta, strerror(errno));
    if(errno != EADDRINUSE) break;
    encerrar_copia_anterior(g_porta);
    sleep(1);
  }
  notificar("Game Library Renamer: nao foi possivel usar a porta %d", g_porta);
  diario("desistiu: porta %d ocupada", g_porta);
  return EXIT_FAILURE;
}
