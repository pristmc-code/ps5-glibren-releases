/* Game Library Renamer (payload PS5) - SHA-256 (FIPS 180-4), implementacao propria e pequena, em fluxo: confere os
   downloads grandes (zips dos apps) sem guardar o arquivo inteiro na memoria. */
#pragma once

#include <stddef.h>
#include <stdint.h>

typedef struct {
  uint32_t h[8];
  uint64_t total;   /* bytes recebidos */
  uint8_t bloco[64];
  size_t n;         /* bytes pendentes em bloco */
} sha256_t;

void sha256_iniciar(sha256_t *s);
void sha256_atualizar(sha256_t *s, const void *dados, size_t n);
void sha256_final(sha256_t *s, uint8_t resumo[32]);
/* resumo em hexadecimal minusculo (65 bytes com o \0) */
void sha256_hex(const uint8_t resumo[32], char saida[65]);
