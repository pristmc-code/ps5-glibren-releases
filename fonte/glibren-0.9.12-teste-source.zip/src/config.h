/* Game Library Renamer (payload PS5) - configuracao (idioma e pastas), gravada no PS5. */
#pragma once

#include "util.h"

#define MAX_PASTAS 32
#define MAX_OCULTOS 512   /* arquivos ocultos da lista de jogos */
#define TAM_OCULTO 300

extern char g_pasta_dados[512];   /* /data/GameLibraryRenamer no PS5 */

void config_iniciar(const char *pasta_dados);
/* Copia as pastas e o idioma atuais (thread-safe). Devolve a quantidade de pastas. */
int config_ler(char pastas[MAX_PASTAS][1024], char idioma[16]);
/* Grava; pastas NULL mantem as atuais, idioma NULL mantem o atual. Devolve 0 ou -1. */
int config_gravar(char (*pastas)[1024], int qtd, const char *idioma);
/* Pastas da lista monitoradas pelo ShadowMount (substitui todas). -1 se alguma nao estiver na lista. */
int config_gravar_monitoradas(char (*pastas)[1024], int qtd);
/* Copia as pastas monitoradas pelo ShadowMount (ate max) e devolve quantas sao. */
int config_monitoradas(char (*pastas)[1024], int max);
/* Nomes de arquivo ocultos da lista de jogos (substitui todos). -1 se algum nome for invalido. */
int config_gravar_ocultos(char (*nomes)[TAM_OCULTO], int qtd);
/* Arquivos .complete que o usuario mandou mostrar (substitui todos). -1 se algum nome nao for um .complete valido. */
int config_gravar_mostrados(char (*nomes)[TAM_OCULTO], int qtd);
/* 1 se a pasta e uma das pastas da lista (igual, ignorando as barras do fim). Excluir, mover, copiar e renomear so
   agem nelas (decisao do usuario em 12/11/2026: o processo e root fora da jaula). */
int config_pasta_permitida(const char *pasta);
void config_json(buf_t *b);   /* "idioma":"..","pastas":[..],"monitoradas":[..],"ocultos":[..],"mostrados":[..] (sem chaves em volta) */
