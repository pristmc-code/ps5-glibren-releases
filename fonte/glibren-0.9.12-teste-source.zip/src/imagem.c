/* Game Library Renamer (payload PS5) - dispositivo de leitura sobre um arquivo aberto. Ver imagem.h. */
#include "imagem.h"

#include <unistd.h>

static int ler_arquivo(dispositivo_t *d, uint64_t off, void *buf, size_t n) {
  int fd = (int)(intptr_t)d->ctx;
  if(off > d->tamanho || n > d->tamanho - off) return -1;
  for(size_t lidos = 0; lidos < n;) {
    ssize_t r = pread(fd, (char *)buf + lidos, n - lidos, (off_t)(off + lidos));
    if(r <= 0) return -1;
    lidos += (size_t)r;
  }
  return 0;
}

void dispositivo_arquivo(dispositivo_t *d, int fd, uint64_t tamanho) {
  d->ler = ler_arquivo;
  d->fechar = NULL;
  d->tamanho = tamanho;
  d->ctx = (void *)(intptr_t)fd;
}
