/* Game Library Renamer (payload PS5) - endereco da API do ShadowMountPlus no config.ini dele (formatos v1 e v2). */
#pragma once

#include <stddef.h>
#include <stdio.h>

/* Le o config.ini do ShadowMountPlus. So muda porta/ip quando acha um valor valido (porta 1..65535, IPv4). */
void smp_config_ler(FILE *f, int *porta, char *ip, size_t tam_ip);
