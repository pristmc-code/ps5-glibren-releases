/* Game Library Renamer (payload PS5) - gerenciador de arquivos, leitura das pastas e renomear. */
#include "arquivos.h"

#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <unistd.h>

#include "config.h"

typedef struct {
  char nome[256];
  int pasta;
  long long tamanho;
} item_t;

static int comparar(const void *a, const void *b) {
  const item_t *x = a, *y = b;
  if(x->pasta != y->pasta) return y->pasta - x->pasta;
  return strcasecmp(x->nome, y->nome);
}

static void juntar(char *saida, size_t tam, const char *pasta, const char *nome) {
  size_t n = strlen(pasta);
  snprintf(saida, tam, "%s%s%s", pasta, (n && pasta[n - 1] == '/') ? "" : "/", nome);
}

int arquivos_listar(const char *caminho, buf_t *json) {
  DIR *d = opendir(caminho);
  if(!d) return errno ? errno : ENOENT;
  size_t qtd = 0, cap = 64;
  item_t *itens = malloc(cap * sizeof *itens);
  struct dirent *e;
  char completo[1300];
  struct stat st;
  while((e = readdir(d))) {
    if(!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
    juntar(completo, sizeof completo, caminho, e->d_name);
    if(stat(completo, &st)) continue;   /* link quebrado etc. */
    if(!S_ISDIR(st.st_mode) && !S_ISREG(st.st_mode)) continue;
    if(qtd == cap) itens = realloc(itens, (cap *= 2) * sizeof *itens);
    snprintf(itens[qtd].nome, sizeof itens[qtd].nome, "%s", e->d_name);
    itens[qtd].pasta = S_ISDIR(st.st_mode);
    itens[qtd].tamanho = S_ISREG(st.st_mode) ? (long long)st.st_size : 0;
    qtd++;
  }
  closedir(d);
  qsort(itens, qtd, sizeof *itens, comparar);

  buf_str(json, "{\"ok\":true,\"caminho\":");
  buf_json(json, caminho);
  buf_str(json, ",\"itens\":[");
  for(size_t i = 0; i < qtd; i++) {
    buf_str(json, i ? ",{\"nome\":" : "{\"nome\":");
    buf_json(json, itens[i].nome);
    if(itens[i].pasta) buf_str(json, ",\"tipo\":\"pasta\"}");
    else buf_fmt(json, ",\"tipo\":\"arquivo\",\"tamanho\":%lld}", itens[i].tamanho);
  }
  buf_str(json, "]}");
  free(itens);
  return 0;
}

void arquivos_escanear(buf_t *json) {
  char pastas[MAX_PASTAS][1024];
  int qtd = config_ler(pastas, NULL);
  buf_t itens = {0};
  int primeiro = 1;

  buf_str(json, "{\"ok\":true,\"situacao\":[");
  for(int i = 0; i < qtd; i++) {
    int existe = 0, n = 0;
    struct stat st;
    DIR *d = NULL;
    if(!stat(pastas[i], &st) && S_ISDIR(st.st_mode)) {
      existe = 1;
      d = opendir(pastas[i]);
    }
    if(d) {
      struct dirent *e;
      char completo[1300];
      while((e = readdir(d))) {
        juntar(completo, sizeof completo, pastas[i], e->d_name);
        if(stat(completo, &st) || !S_ISREG(st.st_mode)) continue;   /* so arquivos (pastas ficam fora) */
        buf_str(&itens, primeiro ? "{\"pasta\":" : ",{\"pasta\":");
        primeiro = 0;
        buf_json(&itens, pastas[i]);
        buf_str(&itens, ",\"nome\":");
        buf_json(&itens, e->d_name);
        buf_fmt(&itens, ",\"tipo\":\"arquivo\",\"tamanho\":%lld}", (long long)st.st_size);
        n++;
      }
      closedir(d);
    }
    buf_str(json, i ? ",{\"pasta\":" : "{\"pasta\":");
    buf_json(json, pastas[i]);
    buf_fmt(json, ",\"existe\":%s,\"qtd\":%d,\"erro\":\"\"}", existe ? "true" : "false", n);
  }
  buf_str(json, "],\"pastas\":[");
  for(int i = 0; i < qtd; i++) {
    if(i) buf_str(json, ",");
    buf_json(json, pastas[i]);
  }
  buf_str(json, "],\"itens\":[");
  if(itens.n) buf_add(json, itens.d, itens.n);
  buf_str(json, "]}");
  buf_free(&itens);
}

/* Downloads em andamento: lojas, navegadores e clientes torrent gravam o arquivo com uma terminacao
   temporaria (ex.: BlackBox "jogo.exfat.part") e so tiram no fim. Mesma lista do app de PC (ftp_ps5.py). */
static const char *SUFIXOS_DOWNLOAD[] = {
  ".glr-part" /* copia em andamento do proprio payload (tarefas.c) */, ".part", ".partial", ".crdownload", ".download", ".opdownload", ".fdmdownload", ".tmp", ".temp",
  ".incomplete", ".filepart", ".dtapart", ".!qb", ".!ut", ".!bt", ".bc!", ".az!", ".!sync", ".xltd",
  ".td", ".aria2", NULL};
static const char *CONTROLES_AO_LADO[] = {".aria2", ".part", ".partial", ".tmp", NULL};

static int termina_com(const char *s, const char *fim) {
  size_t a = strlen(s), b = strlen(fim);
  return a >= b && !strcasecmp(s + a - b, fim);
}

int em_download(const char *pasta, const char *nome) {
  for(int i = 0; SUFIXOS_DOWNLOAD[i]; i++) {
    if(termina_com(nome, SUFIXOS_DOWNLOAD[i])) return 1;
  }
  /* .part1, .part2... (JDownloader); temporarios do Syncthing e de editores */
  const char *p = strrchr(nome, '.');
  if(p && !strncasecmp(p, ".part", 5) && p[5]) {
    const char *q = p + 5;
    while(*q >= '0' && *q <= '9') q++;
    if(!*q) return 1;
  }
  if(!strncasecmp(nome, ".syncthing.", 11) || nome[0] == '~') return 1;
  /* o downloader grava direto no nome final e deixa o controle ao lado (aria2: x.exfat + x.exfat.aria2) */
  char completo[1400];
  struct stat st;
  for(int i = 0; CONTROLES_AO_LADO[i]; i++) {
    char outro[300];
    snprintf(outro, sizeof outro, "%s%s", nome, CONTROLES_AO_LADO[i]);
    juntar(completo, sizeof completo, pasta, outro);
    if(!lstat(completo, &st)) return 1;
  }
  return 0;
}

ren_t arquivos_renomear(const char *pasta, const char *de, const char *para, long long tamanho) {
  if(!caminho_valido(pasta) || !nome_valido(de) || !nome_valido(para)) return REN_INVALIDO;
  char origem[1300], destino[1300];
  struct stat st;
  juntar(origem, sizeof origem, pasta, de);
  juntar(destino, sizeof destino, pasta, para);
  struct stat st_origem;
  if(lstat(origem, &st_origem) || !S_ISREG(st_origem.st_mode)) return REN_ORIGEM_SUMIU;
  /* rename() sobrescreve o destino: confere antes para nunca apagar nada. No exFAT (HD externo) o nome
     nao diferencia maiusculas: "jogo.pkg" -> "Jogo.pkg" acha o proprio arquivo, e ai pode. */
  if(!lstat(destino, &st)) {
    if(st.st_dev != st_origem.st_dev || st.st_ino != st_origem.st_ino) return REN_DESTINO_EXISTE;
  } else if(errno != ENOENT) return REN_DESTINO_EXISTE;
  if(em_download(pasta, de) || (tamanho >= 0 && st_origem.st_size != tamanho)) return REN_EM_DOWNLOAD;
  if(rename(origem, destino)) return REN_FALHOU;
  return REN_OK;
}

const char *ren_chave(ren_t r) {
  switch(r) {
  case REN_OK: return "";
  case REN_INVALIDO: return "nome_invalido";
  case REN_ORIGEM_SUMIU: return "origem_sumiu";
  case REN_DESTINO_EXISTE: return "destino_existe";
  case REN_EM_DOWNLOAD: return "em_download";
  default: return "falha_renomear";
  }
}
