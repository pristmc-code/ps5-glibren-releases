/* Game Library Renamer (payload PS5) - leitor de ZIP minimo (so leitura), para instalar os apps homebrew.

Le o diretorio central (EOCD sem ZIP64), aceita os metodos 0 (stored) e 8 (deflate, pelo tinfl do miniz, em fluxo)
e confere o CRC-32 de cada arquivo. Recusa: ZIP64, multi-volume, cifrado, nomes com "..", absolutos, "\", ":" ou
caracteres de controle, links simbolicos, entradas repetidas, tamanho total acima do limite, razao de compressao
absurda e dados que inflam alem do tamanho declarado (bomba de descompressao). Nada e carregado inteiro na memoria. */
#pragma once

#include <stddef.h>
#include <stdint.h>

#include "util.h"

/* Codigos de erro (negativos; o diario mostra em hex) */
#define ZIP_OK 0
#define ZIP_E_ABRIR (-1)       /* arquivo nao abre / erro de leitura */
#define ZIP_E_FORMATO (-2)     /* nao e zip, estrutura corrompida ou truncada */
#define ZIP_E_ZIP64 (-3)       /* ZIP64 (nao suportado) */
#define ZIP_E_NOME (-4)        /* nome perigoso (.., absoluto, \, controle) ou repetido */
#define ZIP_E_METODO (-5)      /* metodo de compressao nao suportado ou entrada cifrada */
#define ZIP_E_LIMITE (-6)      /* tamanho total acima do limite, entradas demais ou razao de compressao absurda */
#define ZIP_E_DADOS (-7)       /* deflate invalido, tamanho diferente do declarado */
#define ZIP_E_CRC (-8)         /* CRC-32 nao confere */
#define ZIP_E_GRAVAR (-9)      /* nao conseguiu criar pasta/arquivo no destino */
#define ZIP_E_LINK (-10)       /* entrada e link simbolico */
#define ZIP_E_MEMORIA (-11)

#define ZIP_MAX_ENTRADAS 65535
#define ZIP_MAX_NOME 512
#define ZIP_MAX_RAZAO 1000   /* tamanho / comprimido acima disso (em arquivos de mais de 1 MB) e recusado */

typedef struct {
  char *nome;          /* como no zip, sem barra no fim para pastas (sem a pasta de topo, se removida) */
  char *nome_zip;      /* nome completo como esta no zip (o nome aponta para dentro dele) */
  int pasta;
  unsigned metodo;     /* 0 ou 8 */
  uint32_t crc;
  uint64_t comp, tam;  /* comprimido / descomprimido */
  uint64_t off_local;  /* cabecalho local */
} zip_entrada_t;

typedef struct {
  int fd;
  uint64_t tamanho_arquivo, inicio_cd;
  uint32_t n;
  zip_entrada_t *e;
  uint64_t total;      /* soma dos tamanhos descomprimidos */
} zip_t;

/* Abre e confere o diretorio central inteiro (nomes, metodos, limites). max_total: limite da soma dos tamanhos
   descomprimidos. erro (opcional) recebe a explicacao. Devolve ZIP_OK ou um ZIP_E_*. */
int zip_abrir(zip_t *z, const char *arquivo, uint64_t max_total, char *erro, size_t tam_erro);
void zip_fechar(zip_t *z);
/* Zip com tudo dentro de uma unica pasta de topo (ex.: "PPSA99991/eboot.bin"): devolve 1 e o nome dela em saida.
   0 = ha arquivos na raiz ou mais de uma pasta de topo. */
int zip_pasta_topo(const zip_t *z, char *saida, size_t tam);
/* Tira a pasta de topo de todos os nomes (a entrada da propria pasta some). So depois de zip_pasta_topo. */
void zip_tirar_pasta_topo(zip_t *z, const char *pasta);
/* Entrada pelo nome exato (ex.: "sce_sys/param.json"), ou NULL. */
const zip_entrada_t *zip_achar(const zip_t *z, const char *nome);
/* Le uma entrada (arquivo) para a memoria, ate max bytes, conferindo o CRC. */
int zip_ler(zip_t *z, const zip_entrada_t *e, buf_t *saida, size_t max, char *erro, size_t tam_erro);

/* Progresso da extracao (bytes descomprimidos gravados ate agora, de z->total). */
typedef void (*zip_progresso_t)(uint64_t feitos, uint64_t total, void *ctx);
/* Extrai tudo dentro de "destino" (pasta que ja existe e esta vazia). Arquivos novos (O_EXCL, sem seguir links).
   Se falhar no meio, o que ja foi extraido fica (o chamador apaga a pasta). */
int zip_extrair(zip_t *z, const char *destino, zip_progresso_t progresso, void *ctx, char *erro, size_t tam_erro);

/* Nome de entrada seguro? (usado tambem nos testes) 1 = sim */
int zip_nome_seguro(const char *nome);
