/* Game Library Renamer (payload PS5) - relogio do PS5 pela internet.
   Uma thread confere a hora ao iniciar, a cada 6 h e logo depois de voltar do modo de repouso: pergunta a servidores
   NTP (Cloudflare, NTP.br, Google, pelo IP) e le o cabecalho Date de um site HTTPS. Se pelo menos duas fontes
   concordarem e o relogio estiver errado alem do limite, acerta a hora UTC do PS5 (o fuso continua o do PS5). */
#pragma once

#include "util.h"

void relogio_iniciar(void);
/* Chamada pelo sinal SIGCONT (volta do repouso): so marca; a thread confere uns segundos depois. */
void relogio_acordou(void);
/* Liga/desliga a conferencia automatica (grava em <dados>/relogio.ini). */
int relogio_definir_auto(int ligado);
/* Confere agora (e acerta se precisar, mesmo com o automatico desligado). Espera terminar (em geral poucos segundos; ate ~30 s se
   varios servidores nao responderem). */
void relogio_conferir_agora(void);
/* "relogio":{...} (sem chaves em volta) */
void relogio_json(buf_t *b);
