package com.pristmc.glibrencontrole;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.DisplayCutout;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebBackForwardList;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.window.OnBackInvokedDispatcher;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * glibren Controle: abre em tela cheia a pagina do payload glibren do PS5 (http://IP-DO-PS5:8765/), sem navegador.
 *
 * A pagina vem do proprio payload no PS5; este app so guarda o IP, procura o PS5 na rede e mostra telas locais
 * (assets) para configurar e para quando o PS5 nao responde. Derivado do Jobe Controle (PristMC).
 */
public class MainActivity extends Activity {

    static final int PORTA_PADRAO = 8765;
    static final String TAG = "glibrenControle";

    private WebView web;
    private FrameLayout raiz;
    private View telaCheia;
    private WebChromeClient.CustomViewCallback saidaTelaCheia;
    private SharedPreferences prefs;
    private volatile boolean procurando = false;
    private boolean falhou = false;
    private boolean limparHistorico = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("glibren", MODE_PRIVATE);

        web = new WebView(this);
        web.setBackgroundColor(0xFF0A0E16);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setUserAgentString(s.getUserAgentString() + " glibrenControle/" + versao());
        web.addJavascriptInterface(new Ponte(), "GlibrenApp");
        web.setWebChromeClient(new WebChromeClient() {
            // Botao de tela cheia da pagina (requestFullscreen) ou de um video: a view cobre a tela ate sair.
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (telaCheia != null) { callback.onCustomViewHidden(); return; }
                telaCheia = view;
                saidaTelaCheia = callback;
                raiz.addView(view, new FrameLayout.LayoutParams(-1, -1));
                web.setVisibility(View.GONE);
                imersivo();
            }

            @Override
            public void onHideCustomView() {
                sairTelaCheia();
            }
        });
        web.setWebViewClient(new WebViewClient() {
            // Link para fora do PS5 (YouTube, sites) abre no app/navegador do celular, nao dentro desta tela.
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                if (!req.isForMainFrame()) return false;
                Uri u = req.getUrl();
                String esquema = u.getScheme() == null ? "" : u.getScheme();
                if (esquema.equals("file") || esquema.equals("javascript") || esquema.equals("about")) return false;
                if (esquema.equals("http") && ip().equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u).addCategory(Intent.CATEGORY_BROWSABLE));
                } catch (ActivityNotFoundException e) {
                    Log.w(TAG, "nenhum app abre " + u);
                }
                return true;
            }

            // HTTP sem criptografia so para a rede local (ver res/xml/network_security_config.xml).
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if ("http".equals(u.getScheme()) && !ipLocal(u.getHost())) {
                    Log.w(TAG, "HTTP fora da rede local bloqueado: " + u.getHost());
                    return new WebResourceResponse("text/plain", "utf-8", 403, "Bloqueado", null,
                            new ByteArrayInputStream(new byte[0]));
                }
                return null;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                falhou = false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (limparHistorico && url != null && url.startsWith("http")) {
                    limparHistorico = false;
                    web.clearHistory();
                }
                // Tela acesa so com a pagina do PS5 carregada; nas telas locais o celular apaga normalmente.
                if (url != null && url.startsWith("http") && !falhou) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                Log.w(TAG, "erro " + err.getErrorCode() + " " + err.getDescription() + " (principal: " + req.isForMainFrame() + ")");
                if (req.isForMainFrame() && !req.getUrl().toString().startsWith("file:")) {
                    falhou = true;
                    abrirSemResposta();
                }
            }
        });

        raiz = new FrameLayout(this);
        raiz.setBackgroundColor(0xFF0A0E16);
        raiz.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(raiz);
        // Tela cheia: as barras do sistema ficam escondidas; so afasta do recorte da camera e do teclado.
        raiz.setOnApplyWindowInsetsListener((v, insets) -> {
            int esq = 0, cima = 0, dir = 0, baixo = 0;
            if (Build.VERSION.SDK_INT >= 28) {
                DisplayCutout dc = insets.getDisplayCutout();
                if (dc != null) {
                    esq = dc.getSafeInsetLeft();
                    cima = dc.getSafeInsetTop();
                    dir = dc.getSafeInsetRight();
                    baixo = dc.getSafeInsetBottom();
                }
            }
            if (Build.VERSION.SDK_INT >= 30) {
                baixo = Math.max(baixo, insets.getInsets(WindowInsets.Type.ime()).bottom);
            }
            v.setPadding(esq, cima, dir, baixo);
            return WindowInsets.CONSUMED;
        });
        imersivo();
        raiz.requestApplyInsets();

        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::voltar);
        }
        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else abrirInicio();
    }

    // Modo imersivo "sticky": barras de status e de navegacao escondidas; um gesto na borda mostra por um instante.
    @SuppressWarnings("deprecation")
    private void imersivo() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean comFoco) {
        super.onWindowFocusChanged(comFoco);
        if (comFoco) imersivo();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        imersivo();
    }

    @Override
    protected void onPause() {
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        voltar();
    }

    private void sairTelaCheia() {
        if (telaCheia == null) return;
        raiz.removeView(telaCheia);
        telaCheia = null;
        web.setVisibility(View.VISIBLE);
        if (saidaTelaCheia != null) saidaTelaCheia.onCustomViewHidden();
        saidaTelaCheia = null;
        imersivo();
    }

    // Voltar: sai da tela cheia da pagina/video; na pagina do PS5 volta no historico; na configuracao com IP
    // salvo volta para o PS5; no comeco pergunta se sai (com a opcao de trocar o IP).
    private void voltar() {
        if (telaCheia != null) { sairTelaCheia(); return; }
        String url = web.getUrl();
        if (url != null && url.contains("config.html") && !ip().isEmpty()) { abrirPs5(); return; }
        if (url != null && url.startsWith("http") && anteriorEhDoPs5()) { web.goBack(); return; }
        perguntarSair();
    }

    private boolean anteriorEhDoPs5() {
        WebBackForwardList h = web.copyBackForwardList();
        int i = h.getCurrentIndex();
        if (i <= 0) return false;
        String ant = h.getItemAtIndex(i - 1).getUrl();
        return ant != null && ant.startsWith("http");
    }

    private void perguntarSair() {
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Sair do glibren Controle?")
                .setPositiveButton("Sair", (d, w) -> finish())
                .setNeutralButton("Trocar IP", (d, w) -> abrirConfig())
                .setNegativeButton("Ficar", null)
                .show();
    }

    private String ip() { return prefs.getString("ip", ""); }
    private int porta() { return prefs.getInt("porta", PORTA_PADRAO); }

    private String versao() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Exception e) { return "?"; }
    }

    private void abrirInicio() {
        if (ip().isEmpty()) abrirConfig();
        else abrirPs5();
    }

    private void abrirPs5() {
        limparHistorico = true;
        web.loadUrl("http://" + ip() + ":" + porta() + "/");
    }

    private void abrirConfig() {
        web.loadUrl("file:///android_asset/config.html");
    }

    private void abrirSemResposta() {
        web.loadUrl("file:///android_asset/sem-resposta.html");
    }

    private void js(String codigo) {
        runOnUiThread(() -> web.evaluateJavascript(codigo, null));
    }

    /** IPv4 de rede local (privada, link-local ou o proprio aparelho). */
    static boolean ipLocal(String host) {
        if (host == null) return false;
        String[] p = host.split("\\.");
        if (p.length != 4) return false;
        int[] n = new int[4];
        try {
            for (int i = 0; i < 4; i++) {
                n[i] = Integer.parseInt(p[i]);
                if (n[i] < 0 || n[i] > 255 || !p[i].matches("\\d{1,3}")) return false;
            }
        } catch (NumberFormatException e) {
            return false;
        }
        return n[0] == 10 || n[0] == 127
                || (n[0] == 192 && n[1] == 168)
                || (n[0] == 172 && n[1] >= 16 && n[1] <= 31)
                || (n[0] == 169 && n[1] == 254);
    }

    // O endereco IPv4 do celular na rede atual (Wi-Fi), para procurar o PS5 na mesma faixa.
    private String ipDoCelular() {
        try {
            ConnectivityManager cm = getSystemService(ConnectivityManager.class);
            Network rede = cm.getActiveNetwork();
            LinkProperties lp = rede == null ? null : cm.getLinkProperties(rede);
            if (lp == null) return null;
            for (LinkAddress la : lp.getLinkAddresses()) {
                if (la.getAddress() instanceof Inet4Address && !la.getAddress().isLoopbackAddress()) return la.getAddress().getHostAddress();
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    // Confere se o endereco e mesmo o payload glibren: GET /api/estado responde JSON com "pasta_dados".
    static boolean ehGlibren(String ip, int porta, int tempo) {
        if (!ipLocal(ip)) return false;
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL("http://" + ip + ":" + porta + "/api/estado").openConnection();
            c.setConnectTimeout(tempo);
            c.setReadTimeout(tempo * 2);
            if (c.getResponseCode() != 200) return false;
            InputStream in = c.getInputStream();
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            byte[] b = new byte[4096];
            int n;
            while ((n = in.read(b)) > 0 && buf.size() < 1 << 20) buf.write(b, 0, n);
            return new JSONObject(buf.toString("UTF-8")).has("pasta_dados");
        } catch (Exception e) {
            return false;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    static boolean portaAberta(String ip, int porta, int tempo) {
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(ip, porta), tempo);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** O que as telas locais (config.html, sem-resposta.html) podem pedir ao app. */
    class Ponte {
        @JavascriptInterface
        public String salvo() {
            try {
                return new JSONObject().put("ip", ip()).put("porta", porta()).put("celular", String.valueOf(ipDoCelular())).put("versao", versao()).toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public boolean salvar(String ip, int porta) {
            String limpo = ip == null ? "" : ip.trim();
            if (!ipLocal(limpo)) return false;
            prefs.edit().putString("ip", limpo).putInt("porta", porta > 0 && porta < 65536 ? porta : PORTA_PADRAO).apply();
            runOnUiThread(MainActivity.this::abrirPs5);
            return true;
        }

        // Testa um IP e responde em GlibrenTeste(ok).
        @JavascriptInterface
        public void testar(String ip, int porta) {
            new Thread(() -> {
                boolean ok = ehGlibren(ip.trim(), porta, 2500);
                js("GlibrenTeste(" + ok + ")");
            }).start();
        }

        // Procura a porta em toda a faixa /24 do celular; responde em GlibrenProgresso(n) e GlibrenAchados([...]).
        @JavascriptInterface
        public void procurar(int porta) {
            if (procurando) return;
            procurando = true;
            new Thread(() -> {
                List<String> achados = Collections.synchronizedList(new ArrayList<>());
                try {
                    String meu = ipDoCelular();
                    if (meu == null || !ipLocal(meu)) {
                        js("GlibrenAchados(null)");
                        return;
                    }
                    String base = meu.substring(0, meu.lastIndexOf('.') + 1);
                    ExecutorService pool = Executors.newFixedThreadPool(48);
                    final int[] feitos = {0};
                    for (int i = 1; i < 255; i++) {
                        final String alvo = base + i;
                        pool.execute(() -> {
                            if (!alvo.equals(meu) && portaAberta(alvo, porta, 400) && ehGlibren(alvo, porta, 1500)) achados.add(alvo);
                            synchronized (feitos) {
                                feitos[0]++;
                                if (feitos[0] % 16 == 0) js("GlibrenProgresso(" + feitos[0] * 100 / 254 + ")");
                            }
                        });
                    }
                    pool.shutdown();
                    pool.awaitTermination(60, TimeUnit.SECONDS);
                    js("GlibrenAchados(" + new JSONArray(achados) + ")");
                } catch (Exception e) {
                    js("GlibrenAchados([])");
                } finally {
                    procurando = false;
                }
            }).start();
        }

        @JavascriptInterface
        public void tentarDeNovo() {
            runOnUiThread(MainActivity.this::abrirPs5);
        }

        @JavascriptInterface
        public void configurar() {
            runOnUiThread(MainActivity.this::abrirConfig);
        }
    }
}
