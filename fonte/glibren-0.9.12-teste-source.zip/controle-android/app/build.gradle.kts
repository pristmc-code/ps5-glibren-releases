plugins {
    id("com.android.application")
}

android {
    namespace = "com.pristmc.glibrencontrole"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.pristmc.glibrencontrole"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "0.1-teste"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
