plugins {
    id("com.android.application") version "8.13.2" apply false
}

// Compilacao fora do Google Drive (a sincronizacao trava os arquivos temporarios do build).
val pastaBuild = File(System.getenv("LOCALAPPDATA") ?: rootDir.path, "glibrenControle-android")
allprojects {
    layout.buildDirectory.set(File(pastaBuild, if (this == rootProject) "raiz" else name))
}
