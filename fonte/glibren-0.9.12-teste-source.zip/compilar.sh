#!/bin/bash
# Compila o payload no WSL fora do Google Drive (a sincronizacao atrapalha os arquivos do build)
# e copia o resultado de volta para payload/saida/.
#   wsl -d Ubuntu-24.04 -u root -- bash compilar.sh [alvo do make: all | pc | clean]
set -e
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD=/root/glr-payload
mkdir -p "$BUILD" "$ORIGEM/saida"
rsync -a --delete --exclude saida --exclude build --exclude '*.elf' --exclude 'glibren-pc' \
  --exclude dados "$ORIGEM/" "$BUILD/"
cd "$BUILD"
make PS5_PAYLOAD_SDK=/opt/ps5-payload-sdk "${@:-all}"
for f in glibren.elf glibren-pc; do
  [ -f "$f" ] && cp "$f" "$ORIGEM/saida/"
done
ls -l "$ORIGEM/saida/"
