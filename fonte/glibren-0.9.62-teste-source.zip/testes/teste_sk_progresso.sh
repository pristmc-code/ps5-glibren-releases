#!/bin/bash
# Testa o "Preparando jogos" do ShadowKraken (0.9.61) na versao de PC: GET /api/sk/progresso.
# Fonte A: rota /api/v1/fpkg/progress de um ShadowKraken falso (GET como a Dev.37, so POST, ativo e parado). Fonte B: debug.log de
# exemplo (formato da Dev.36: [FPKG], [PULSE], NOTIFY e NOTIFY(progress)) com lote novo, jogo adiado, conferencia,
# extracao, aviso em portugues, ShadowKraken calado no meio e log maior que 256 KB. Hora do PS5 fixa por arquivo.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_sk_progresso.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8974; PORTA_SK=18974
L="http://127.0.0.1:$PORTA"
T=/root/glr-skprog; DADOS=$T/dados; R=$T/raiz; SKC=$T/sk-config.ini; LOG=$R/data/shadowmount/debug.log; AGORA=$T/agora
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$(echo "$2" | head -c 900)] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
prog() { curl -s "$L/api/sk/progresso"; }
campo() { python3 -I -c 'import json,sys; d=json.loads(sys.argv[1]); v=eval(sys.argv[2],{"d":d}); print(json.dumps(v,ensure_ascii=False))' "$1" "$2"; }

pkill -f "sk_falso_prog.py $PORTA_SK" 2>/dev/null
rm -rf "$T"; mkdir -p "$DADOS" "$T/sk" "$R/data/shadowmount" "$R/data/homebrew"
printf '[general]\ndebug = on\n[api]\nport = 10101\nbind_address = 0.0.0.0\n' > "$SKC"
truncate -s 3221225472 "$R/data/homebrew/Smurfs.pkg"
truncate -s 4294967296 "$R/data/homebrew/Shock.pkg"
truncate -s 1000000 "$R/data/homebrew/A.pkg"

# ShadowKraken falso: /api/v1/fpkg/progress do arquivo progress.json; modo "get" (so GET, como a Dev.37), "post" (GET
# da 404), "404" (nao tem a rota). O resto da 404.
cat > "$T/sk_falso_prog.py" <<'FIM'
import http.server, sys
pasta = sys.argv[2]
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def responde(self, metodo):
        n = int(self.headers.get("Content-Length") or 0)
        if n: self.rfile.read(n)
        modo = open(pasta + "/modo").read().strip()
        open(pasta + "/pedidos", "a").write(metodo + " " + self.path + "\n")
        if self.path != "/api/v1/fpkg/progress" or modo == "404" or (modo == "get" and metodo == "POST") or (modo == "post" and metodo == "GET"):
            corpo, st = b'{"status":2,"error":"unknown API route"}', 404
        else:
            corpo, st = open(pasta + "/progress.json", "rb").read(), 200
        self.send_response(st); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(corpo))); self.end_headers(); self.wfile.write(corpo)
    def do_GET(self): self.responde("GET")
    def do_POST(self): self.responde("POST")
http.server.ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1])), H).serve_forever()
FIM

GLR_TESTE_SMP_PORTA=$PORTA_SK GLR_TESTE_SMP_CONFIG="$SKC" GLR_TESTE_SK_RAIZ="$R" GLR_TESTE_SK_AGORA="$AGORA" GLR_TESTE_SONDA_S=0 \
  GLR_TESTE_GH="http://127.0.0.1:9" GLR_TESTE_BASE="http://127.0.0.1:9/" GLR_TESTE_SEM_REMOVIDOS=1 \
  "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!
sleep 1

echo "--- sem ShadowKraken e sem log"
P=$(prog)
confere "fonte nenhuma"                     "$P" '"ok":true,"fonte":"nenhuma","ativo":false'
confere "fila vazia"                        "$P" '"fila":\[\]}'

echo "--- log (Dev.36): lote de 3, adiado, conferindo"
cat > "$LOG" <<'FIM'
[12:00:00] NOTIFY: ShadowKraken v1.00-Dev.36-pristmc
[12:01:00]   [FPKG] preparing cache: Velho Jogo (PPSA00009) from /data/homebrew/Velho.pkg
[12:01:00] NOTIFY: Preparing game 1 of 1: Velho Jogo
[12:01:30]   [FPKG] cache preparation done: Velho Jogo (PPSA00009), 1000 bytes in 2 files
[12:05:00]   [FPKG] preparing cache: The Smurfs – Dreams (PPSA21607) from /data/homebrew/Smurfs.pkg
[12:05:00]   [FPKG] building cache: The Smurfs – Dreams (PPSA21607)
[12:05:00] NOTIFY: Preparing game 1 of 3: The Smurfs – Dreams
Step 1 of 2: extracting the game files...
[12:05:10]   [PULSE] cache=build: extract files=57 bytes=254461080 (+180667289 in 10 s) file=decrypted/prx/libfmod.prx hashed=0 MB ampr=- log_lock=free maxrss=75280 KB
[12:05:23] NOTIFY: Preparing game 1 of 3: The Smurfs – Dreams
Step 2 of 2: checking the package (about 20 s)...
[12:05:26] NOTIFY(progress): Preparing game 1 of 3: The Smurfs – Dreams | Checking the package: 50%
[12:05:45]   [FPKG] cache preparation done: The Smurfs – Dreams (PPSA21607), 292317340 bytes in 64 files
[12:05:46] NOTIFY(progress): Preparing game 1 of 3: The Smurfs – Dreams | Checking the package: 100%
[12:06:00]   [FPKG] preparing cache: Hades (PPSA03355) from /data/homebrew/Hades.pkg
[12:06:00]   [FPKG] cache preparation stopped: Hades (PPSA03355), 0 bytes in 0 files
[12:06:00]   [FPKG] candidate preparation postponed: Hades (PPSA03355): Device busy
[12:06:10]   [FPKG] preparing cache: System Shock (PPSA06389) from /data/homebrew/Shock.pkg
[12:06:10]   [FPKG] building cache: System Shock (PPSA06389)
[12:06:10] NOTIFY: Preparing game 2 of 3: System Shock
Step 1 of 2: extracting the game files...
[12:06:20]   [PULSE] cache=build: sha256 of the whole .pkg files=27 bytes=208450419 (+155825011 in 10 s) file=sce_sys/pic2.dds hashed=181 MB ampr=- log_lock=free maxrss=75280 KB
[12:06:22] NOTIFY(progress): Preparing game 2 of 3: System Shock | Checking the package: 42%
FIM
cp "$LOG" "$T/log1"
echo 12:06:25 > "$AGORA"
P=$(prog)
confere "fonte log, ativo"                  "$P" '"fonte":"log","ativo":true,"sem_noticia":false,"etapa":"conferir"'
confere "jogo 2 de 3"                       "$P" '"titulo":"System Shock","title_id":"PPSA06389","pkg_bytes":4294967296,"jogo":2,"jogos":3'
confere "conferido pelo %"                  "$P" '"conferido":1803886224,"conferir_total":4294967296,"pct":42'
confere "tempos"                            "$P" '"decorrido":15,"lote_decorrido":85,"idade":3,"faltam":1,"faltam_bytes":-1'
confere "fila: 3 (lote novo sem o velho)"   "$(campo "$P" '[f["title_id"]+":"+f["estado"] for f in d["fila"]]')" '\["PPSA21607:done", "PPSA03355:postponed", "PPSA06389:preparing"\]'
confere "pronto: duracao, bytes, ha"        "$(campo "$P" 'd["fila"][0]')" '"pkg_bytes": 3221225472, "segundos": 45, "bytes": 292317340, "arquivos": 64, "ha": 40'
confere "titulo com travessao"              "$P" '"titulo":"The Smurfs – Dreams"'
confere "adiado sem .pkg"                   "$(campo "$P" 'd["fila"][1]["pkg_bytes"]')" '^-1$'

echo "--- log: calado no meio"
echo 12:09:00 > "$AGORA"
P=$(prog)
confere "parou: inativo e sem noticia"      "$P" '"ativo":false,"sem_noticia":true,"etapa":""'
confere "parou: estado parado"              "$(campo "$P" '[f["estado"] for f in d["fila"]]')" '"parado"\]'
confere "parou: ha"                         "$(campo "$P" 'd["fila"][2]["ha"]')" '^158$'
confere "parou: sem jogo N de M nem lote"   "$P" '"jogo":0,"jogos":0,.*"lote_decorrido":0,'

echo "--- log maior que 256 KB (comeco cortado no meio de uma linha)"
python3 -I -c 'import sys; open(sys.argv[1],"w").write("x" * 1000 + "\n" + ("[11:00:00] linha qualquer " + "y" * 70 + "\n") * 4000)' "$LOG"
cat "$T/log1" >> "$LOG"
echo 12:06:25 > "$AGORA"
P=$(prog)
confere "grande: mesmo resultado"           "$P" '"jogo":2,"jogos":3,"arquivos":27,"bytes":208450419'
confere "grande: tamanho"                   "$(stat -c%s "$LOG")" '^3[0-9][0-9][0-9][0-9][0-9]$'

echo "--- log: extracao sem avisos (modo silencioso) e aviso em portugues"
cat > "$LOG" <<'FIM'
[07:40:00]   [FPKG] preparing cache: Outro (PPSA22222) from /data/homebrew/Outro.pkg
[07:40:20]   [FPKG] cache preparation done: Outro (PPSA22222), 10 bytes in 1 files
[08:00:00]   [FPKG] preparing cache: Jogo A (PPSA11111) from /data/homebrew/A.pkg
[08:00:10]   [PULSE] cache=build: extract files=5 bytes=1048576 (+1048576 in 10 s) file=eboot.bin hashed=0 MB ampr=- log_lock=free maxrss=1 KB
FIM
echo 08:00:12 > "$AGORA"
P=$(prog)
confere "extrair"                           "$P" '"ativo":true,"sem_noticia":false,"etapa":"extrair","fase":"build: extract","titulo":"Jogo A"'
confere "extrair: numeros"                  "$P" '"pkg_bytes":1000000,"jogo":0,"jogos":0,"arquivos":5,"bytes":1048576,"arquivo":"eboot.bin"'
confere "extrair: sem %"                    "$P" '"pct":-1'
confere "20 min depois = lote novo"         "$(campo "$P" '[f["title_id"] for f in d["fila"]]')" '^\["PPSA11111"\]$'
printf '[08:00:11] NOTIFY: Preparando o jogo 1 de 2: Jogo A\nEtapa 2 de 2: conferindo o pacote (cerca de 5 s)...\n' >> "$LOG"
P=$(prog)
confere "pt: etapa 2 de 2 = conferir"       "$P" '"etapa":"conferir"'
confere "pt: jogo 1 de 2"                   "$P" '"jogo":1,"jogos":2'
confere "pt: falta 1"                       "$P" '"faltam":1'
printf '[08:00:30]   [FPKG] cache build failed: title=PPSA11111 source=/data/homebrew/A.pkg status=5 x\n[08:00:30]   [FPKG] cache preparation stopped: Jogo A (PPSA11111), 1048576 bytes in 5 files\n[08:00:30]   [FPKG] candidate preparation failed: Jogo A (PPSA11111): Input/output error\n' >> "$LOG"
echo 08:00:40 > "$AGORA"
P=$(prog)
confere "falhou: inativo"                   "$P" '"ativo":false,"sem_noticia":false'
confere "falhou: estado"                    "$(campo "$P" 'd["fila"][0]')" '"estado": "failed".*"segundos": 30.*"ha": 10'

echo "--- API (Dev.37): GET, formato real (status, barras escapadas)"
echo get > "$T/sk/modo"; : > "$T/sk/pedidos"
cat > "$T/sk/progress.json" <<'FIM'
{"status":0,"active":true,"phase":"build: sha256 of the whole .pkg","title":"System Shock","title_id":"PPSA06389","source":"\/data\/homebrew\/Shock.pkg","pkg_bytes":4294967296,"game_index":2,"game_count":3,"files":27,"bytes":208450419,"file":"sce_sys\/pic2.dds","hashed":2147483648,"hash_total":4294967296,"started_unix":1000,"now_unix":1030,"batch_started_unix":900,"queue":[{"title_id":"PPSA21607","title":"The Smurfs","pkg_bytes":3221225472,"state":"done","seconds":45,"bytes":292317340,"files":64},{"title_id":"PPSA06389","title":"System Shock","pkg_bytes":4294967296,"state":"preparing","seconds":30,"bytes":0,"files":0},{"title_id":"PPSA01552","title":"DIRT 5","pkg_bytes":56670883859,"state":"pending","seconds":0,"bytes":0,"files":0}]}
FIM
(exec python3 -I "$T/sk_falso_prog.py" $PORTA_SK "$T/sk") >> "$T/sk.log" 2>&1 &
sleep 0.5
P=$(prog)
confere "api: fonte e etapa"                "$P" '"fonte":"api","ativo":true,"sem_noticia":false,"etapa":"conferir"'
confere "api: jogo"                         "$P" '"titulo":"System Shock","title_id":"PPSA06389","pkg_bytes":4294967296,"jogo":2,"jogos":3,"arquivos":27,"bytes":208450419,"arquivo":"sce_sys/pic2.dds"'
confere "api: conferencia 50%"              "$P" '"conferido":2147483648,"conferir_total":4294967296,"pct":50'
confere "api: tempos e o que falta"         "$P" '"decorrido":30,"lote_decorrido":130,"idade":0,"faltam":1,"faltam_bytes":56670883859'
confere "api: fila"                         "$(campo "$P" '[f["title_id"]+":"+f["estado"]+":"+str(f["segundos"]) for f in d["fila"]]')" '\["PPSA21607:done:45", "PPSA06389:preparing:30", "PPSA01552:pending:0"\]'
confere "api: pediu por GET"                "$(cat $T/sk/pedidos)" '^GET /api/v1/fpkg/progress$'
nao_tem "api: nao leu o log"                "$P" '"fonte":"log"'

echo "--- API: so POST"
echo post > "$T/sk/modo"; : > "$T/sk/pedidos"
P=$(prog)
confere "post: fonte api"                   "$P" '"fonte":"api","ativo":true'
confere "post: GET e depois POST"           "$(cat $T/sk/pedidos | tr '\n' '|')" '^GET /api/v1/fpkg/progress|POST /api/v1/fpkg/progress|$'

echo "--- API: parado"
echo get > "$T/sk/modo"
printf '{"status":0,"active":false,"phase":null,"title":"","title_id":"","game_index":0,"game_count":0,"files":0,"bytes":0,"hashed":0,"hash_total":0,"now_unix":2000,"started_unix":0,"batch_started_unix":900,"queue":[{"title_id":"PPSA21607","title":"The Smurfs","pkg_bytes":3221225472,"state":"done","seconds":45,"bytes":292317340,"files":64}]}' > "$T/sk/progress.json"
P=$(prog)
confere "api parado"                        "$P" '"fonte":"api","ativo":false,"sem_noticia":false,"etapa":"","fase":"","titulo":""'
confere "api parado: ultimo lote"           "$(campo "$P" 'len(d["fila"])')" '^1$'

echo "--- API sem a rota (Dev.36): volta ao log"
echo 404 > "$T/sk/modo"
P=$(prog)
confere "404: fonte log"                    "$P" '"fonte":"log"'
confere "404: rota de leitura sem X-GLR"    "$(curl -s -o /dev/null -w '%{http_code}' $L/api/sk/progresso)" '^200$'

kill $PID 2>/dev/null; pkill -f "sk_falso_prog.py $PORTA_SK" 2>/dev/null; wait 2>/dev/null
echo "=== teste_sk_progresso: $ok ok, $falhas falhas"
[ $falhas -eq 0 ]
