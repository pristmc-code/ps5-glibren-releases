/* Game Library Renamer (payload PS5) - CoreDumps do CoreDump Dumper (0.9.59).

O CoreDump Dumper (jamesst20/PS5-CoreDump-Dumper, MIT; o glibren o ativa pela pagina Payloads) guarda cada travamento
de jogo em /data/ps5-coredump-dumper/<TitleID>_<hora>/ antes de o PS5 apagar: o dump (.prosperodmp), captura de tela,
video curto, coredump_info.json, _manifest.txt (escrito por ultimo) e _klog.txt. O glibren lista essas pastas, manda
uma delas inteira para o repositorio privado de diagnosticos (a mesma chave do "Enviar diagnostico") e apaga.

Envio: pristmc-code/ps5-diagnosticos/coredump/<pasta>_<AAAAMMDD-HHMMSS>/, os arquivos como estao (binarios, SEM a
higienizacao do diagnostico: o repositorio e privado e o Claude confere antes de repassar a alguem). Arquivo maior que
4 MiB vai em partes <nome>.parte001, .parte002... (cada PUT da API leva o pedaco em base64). Por ultimo _glibren.txt:
"arquivo bytes sha256 partes" de cada um, para remontar e conferir. Limite: 768 MiB por pasta (o repositorio e git).

Rotas (api.c):
  GET  /api/coredump                {ok, pasta, rodando, dumps:[{nome,titulo,hora,arquivos,bytes,pronto,enviado}], envio:{...}}
  POST /api/coredump/enviar  nome=  (pareamento + X-GLR)  400 cd_nome/cd_sem_chave, 404 cd_nao_achou, 409 cd_ocupado/
                                                          cd_incompleto, 413 cd_grande
  POST /api/coredump/apagar  nome=  (pareamento + X-GLR)  400 cd_nome, 404 cd_nao_achou, 409 cd_ocupado, 500 cd_apagar
  POST /api/coredump/travar         (pareamento + X-GLR)  0.9.60: GET /crash no ampr-emu-ng de depuracao (127.0.0.1:9090)
                                                          derruba o jogo congelado; 409 cd_sem_dumper/cd_sem_ampr/cd_nao_travou
No PC (testes): GLR_TESTE_COREDUMPS no lugar de /data/ps5-coredump-dumper; GLR_TESTE_AMPR_PORTA no lugar da 9090. */
#pragma once

#include "http.h"
#include "util.h"

#define COREDUMP_PROCESSO "coredump-dump.elf"   /* nome que o CoreDump Dumper da a si mesmo (src/config.h do autor) */

void coredump_json(buf_t *b);
void coredump_rota_estado(pedido_t *p);
void coredump_rota_enviar(pedido_t *p);
void coredump_rota_apagar(pedido_t *p);
void coredump_rota_travar(pedido_t *p);
