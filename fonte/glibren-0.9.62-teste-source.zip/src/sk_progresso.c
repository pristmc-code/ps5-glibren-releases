/* Game Library Renamer (payload PS5) - 0.9.61: "Preparando jogos" do ShadowKraken (ver sk_progresso.h). */
#include "sk_progresso.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>

#include "apps.h"
#include "json_min.h"
#include "util.h"

#define FILA_MAX 64
#define LOG_FIM (256 * 1024)
#define SEM_NOTICIA_S 90   /* o pulso do ShadowKraken sai a cada 10 s enquanto ele prepara; 90 s calado = parou */
#define DIA 86400L

typedef struct {
  char id[16], titulo[160], estado[12];   /* pending|preparing|done|failed|postponed|parado */
  long long pkg, bytes;
  unsigned arquivos;
  long ini, fim;        /* log: segundos do dia; -1 = sem */
  long segundos, ha;    /* duracao; segundos desde o fim (-1 = nao sabe) */
} jogo_t;

typedef struct {
  const char *fonte;
  int ativo, sem_noticia, jogo, jogos, pct, faltam;
  char fase[64], arquivo[256];
  long long bytes, conferido, conferir_total, faltam_bytes;
  unsigned arquivos;
  long decorrido, lote_decorrido, idade;
  int atual;            /* indice do jogo sendo preparado em fila (-1 = nenhum) */
  jogo_t fila[FILA_MAX];
  int nf;
} prog_t;

/* ------------------------------------------------------------------ comum */

#ifndef __PROSPERO__
static const char *raiz_fs(void) {
  const char *r = getenv("GLR_TESTE_SK_RAIZ");
  return r && *r ? r : "";
}
#else
static const char *raiz_fs(void) { return ""; }
#endif

static long long tamanho_pkg(const char *c) {
  char l[1200];
  struct stat st;
  snprintf(l, sizeof l, "%s%s", raiz_fs(), c);
  return !stat(l, &st) ? (long long)st.st_size : -1;
}

/* fase do ShadowKraken em palavra simples para a pagina */
static const char *etapa_de(const char *fase, int ativo) {
  if(!ativo) return "";
  if(!fase[0]) return "preparar";
  if(!strcmp(fase, "open .pkg")) return "abrir";
  if(!strcmp(fase, "read .pkg tables")) return "tabelas";
  if(!strcmp(fase, "recover old cache")) return "recuperar";
  if(!strncmp(fase, "build: sha256", 13)) return "conferir";
  if(!strncmp(fase, "build:", 6)) return "extrair";
  return "preparar";
}

static void prog_json(buf_t *b, prog_t *g) {
  const jogo_t *a = g->atual >= 0 ? &g->fila[g->atual] : NULL;
  const char *etapa = etapa_de(g->fase, g->ativo);
  buf_fmt(b, "{\"ok\":true,\"fonte\":\"%s\",\"ativo\":%s,\"sem_noticia\":%s,\"etapa\":\"%s\",\"fase\":", g->fonte,
          g->ativo ? "true" : "false", g->sem_noticia ? "true" : "false", etapa);
  buf_json(b, g->fase);
  buf_str(b, ",\"titulo\":");
  buf_json(b, a ? a->titulo : "");
  buf_str(b, ",\"title_id\":");
  buf_json(b, a ? a->id : "");
  buf_fmt(b, ",\"pkg_bytes\":%lld,\"jogo\":%d,\"jogos\":%d,\"arquivos\":%u,\"bytes\":%lld,\"arquivo\":", a ? a->pkg : -1,
          g->jogo, g->jogos, g->arquivos, g->bytes);
  buf_json(b, g->arquivo);
  buf_fmt(b, ",\"conferido\":%lld,\"conferir_total\":%lld,\"pct\":%d,\"decorrido\":%ld,\"lote_decorrido\":%ld,"
             "\"idade\":%ld,\"faltam\":%d,\"faltam_bytes\":%lld,\"fila\":[",
          g->conferido, g->conferir_total, g->pct, g->decorrido, g->lote_decorrido, g->idade, g->faltam, g->faltam_bytes);
  for(int i = 0; i < g->nf; i++) {
    const jogo_t *j = &g->fila[i];
    buf_str(b, i ? ",{\"title_id\":" : "{\"title_id\":");
    buf_json(b, j->id);
    buf_str(b, ",\"titulo\":");
    buf_json(b, j->titulo);
    buf_fmt(b, ",\"estado\":\"%s\",\"pkg_bytes\":%lld,\"segundos\":%ld,\"bytes\":%lld,\"arquivos\":%u,\"ha\":%ld}",
            j->estado, j->pkg, j->segundos, j->bytes, j->arquivos, j->ha);
  }
  buf_str(b, "]}");
}

static void prog_zerar(prog_t *g) {
  memset(g, 0, sizeof *g);
  g->atual = -1;
  g->pct = -1;
  g->faltam_bytes = -1;
  g->conferir_total = -1;
}

/* ------------------------------------------------------------------ fonte A: API do ShadowKraken (Dev.37+) */

static long long num(const js_t *o, const char *k) {
  js_t v;
  return js_campo(o, k, &v) ? (long long)js_num(&v) : 0;
}

static void texto(const js_t *o, const char *k, char *s, size_t tam) {
  js_t v;
  s[0] = 0;
  if(js_campo(o, k, &v) && *v.p == '"' && js_string(&v, s, tam)) s[0] = 0;
}

static int pegar_fila(const js_t *item, void *ctx) {
  prog_t *g = ctx;
  if(g->nf >= FILA_MAX) return 0;
  jogo_t *j = &g->fila[g->nf];
  memset(j, 0, sizeof *j);
  texto(item, "title_id", j->id, sizeof j->id);
  texto(item, "title", j->titulo, sizeof j->titulo);
  texto(item, "state", j->estado, sizeof j->estado);
  if(!j->estado[0]) snprintf(j->estado, sizeof j->estado, "pending");
  js_t v;
  j->pkg = js_campo(item, "pkg_bytes", &v) ? (long long)js_num(&v) : -1;
  j->segundos = (long)num(item, "seconds");
  j->bytes = num(item, "bytes");
  j->arquivos = (unsigned)num(item, "files");
  j->ha = -1;
  g->nf++;
  return 1;
}

/* 1 = a rota respondeu e g foi preenchido */
static int pela_api(prog_t *g) {
  buf_t r = {0};
  int st = apps_smp_get("/api/v1/fpkg/progress", &r, 2);   /* Dev.37: GET */
  if(st == 404 || st == 405) {   /* por garantia, o jeito das outras rotas JSON dele */
    buf_free(&r);
    st = apps_smp_pedir("/api/v1/fpkg/progress", "{}", &r, 2);
  }
  if(st != 200 || !r.d) {
    buf_free(&r);
    return 0;
  }
  buf_add(&r, "", 1);
  js_t o = {r.d, r.d + r.n - 1}, v;
  js_esp(&o);
  if(*o.p != '{' || !js_campo(&o, "active", &v)) {
    buf_free(&r);
    return 0;
  }
  g->fonte = "api";
  g->ativo = js_verdade(&v);
  texto(&o, "phase", g->fase, sizeof g->fase);
  texto(&o, "file", g->arquivo, sizeof g->arquivo);
  g->jogo = (int)num(&o, "game_index");
  g->jogos = (int)num(&o, "game_count");
  g->arquivos = (unsigned)num(&o, "files");
  g->bytes = num(&o, "bytes");
  g->conferido = num(&o, "hashed");
  g->conferir_total = num(&o, "hash_total");
  long long agora = num(&o, "now_unix"), ini = num(&o, "started_unix"), lote = num(&o, "batch_started_unix");
  g->decorrido = agora && ini && agora >= ini ? (long)(agora - ini) : 0;
  g->lote_decorrido = agora && lote && agora >= lote ? (long)(agora - lote) : 0;
  if(js_campo(&o, "queue", &v) && *v.p == '[') js_cada(&v, pegar_fila, g);
  g->faltam_bytes = 0;
  for(int i = 0; i < g->nf; i++) {
    if(!strcmp(g->fila[i].estado, "pending")) {
      g->faltam++;
      if(g->fila[i].pkg > 0) g->faltam_bytes += g->fila[i].pkg;
    }
  }
  if(g->ativo) {
    char id[16], tit[160];
    texto(&o, "title_id", id, sizeof id);
    texto(&o, "title", tit, sizeof tit);
    for(int i = 0; i < g->nf && g->atual < 0; i++)
      if(!strcmp(g->fila[i].id, id)) g->atual = i;
    if(g->atual < 0 && g->nf < FILA_MAX) {   /* a fila nao trouxe o atual: entra no fim */
      jogo_t *j = &g->fila[g->nf];
      memset(j, 0, sizeof *j);
      snprintf(j->id, sizeof j->id, "%s", id);
      snprintf(j->titulo, sizeof j->titulo, "%s", tit);
      snprintf(j->estado, sizeof j->estado, "preparing");
      j->ha = -1;
      g->atual = g->nf++;
    }
    if(g->atual >= 0) {
      jogo_t *j = &g->fila[g->atual];
      if(js_campo(&o, "pkg_bytes", &v)) j->pkg = (long long)js_num(&v);
      if(!j->titulo[0]) snprintf(j->titulo, sizeof j->titulo, "%s", tit);
    }
    if(!strncmp(g->fase, "build: sha256", 13) && g->conferir_total > 0) {
      long long p = g->conferido * 100 / g->conferir_total;
      g->pct = p > 100 ? 100 : (int)p;
    }
  } else {
    g->fase[0] = 0;
  }
  buf_free(&r);
  return 1;
}

/* ------------------------------------------------------------------ fonte B: debug.log (Dev.36 e antes) */

static long dif(long de, long ate) { return ((ate - de) % DIA + DIA) % DIA; }

/* "[HH:MM:SS] " no comeco da linha: segundos do dia; -1 = linha sem hora (continuacao de um aviso) */
static long hora(const char *l) {
  if(l[0] != '[' || !isdigit((unsigned char)l[1]) || !isdigit((unsigned char)l[2]) || l[3] != ':' || l[6] != ':' ||
     l[9] != ']')
    return -1;
  return (long)atoi(l + 1) * 3600 + atoi(l + 4) * 60 + atoi(l + 7);
}

static long agora_do_dia(void) {
#ifndef __PROSPERO__
  const char *h = getenv("GLR_TESTE_SK_AGORA");   /* nos testes: "HH:MM:SS" ou um arquivo com a hora */
  char lida[16] = "";
  if(h && *h == '/') {
    FILE *f = fopen(h, "r");
    if(f) {
      if(!fgets(lida, sizeof lida, f)) lida[0] = 0;
      fclose(f);
    }
    lida[8] = 0;
    h = lida;
  }
  if(h && strlen(h) == 8) return (long)atoi(h) * 3600 + atoi(h + 3) * 60 + atoi(h + 6);
#endif
  time_t t = time(NULL);
  struct tm tm;
  localtime_r(&t, &tm);
  return (long)tm.tm_hour * 3600 + tm.tm_min * 60 + tm.tm_sec;
}

/* "(PPSA01552)" na linha: copia o ID e devolve onde comeca o "(" (NULL = nao achou) */
static const char *achar_id(const char *s, char *id, size_t tam) {
  for(const char *c = strchr(s, '('); c; c = strchr(c + 1, '(')) {
    int i = 1;
    while(isupper((unsigned char)c[i]) && i <= 4) i++;
    int letras = i - 1;
    while(isdigit((unsigned char)c[i]) && i <= 10) i++;
    if(letras == 4 && i - 1 - letras == 5 && c[i] == ')') {
      snprintf(id, tam, "%.9s", c + 1);
      return c;
    }
  }
  return NULL;
}

/* "N <palavra> M" (game 1 of 3, jogo 1 de 3): 1 = achou */
static int n_de_m(const char *s, int *n, int *m) {
  for(const char *c = s; *c; c++) {
    if(!isdigit((unsigned char)*c) || (c > s && isdigit((unsigned char)c[-1]))) continue;
    char *e;
    long a = strtol(c, &e, 10);
    if(*e != ' ') continue;
    const char *w = e + 1;
    while(isalpha((unsigned char)*w)) w++;
    if(w == e + 1 || *w != ' ' || !isdigit((unsigned char)w[1])) continue;
    long b = strtol(w + 1, &e, 10);
    if(a < 1 || b < a || b > 9999) continue;
    *n = (int)a;
    *m = (int)b;
    return 1;
  }
  return 0;
}

static int achar_jogo(prog_t *g, const char *id) {
  for(int i = g->nf - 1; i >= 0; i--)
    if(!strcmp(g->fila[i].id, id)) return i;
  return -1;
}

static void estado(jogo_t *j, const char *e) { snprintf(j->estado, sizeof j->estado, "%s", e); }

/* tira os jogos antes de i (comeco de um lote novo) */
static void novo_lote(prog_t *g, int i) {
  if(i <= 0) return;
  memmove(g->fila, g->fila + i, (size_t)(g->nf - i) * sizeof *g->fila);
  g->nf -= i;
  if(g->atual >= 0) g->atual -= i;
}

static void linha_log(prog_t *g, const char *l, long t, int continuacao, long *ultimo) {
  jogo_t *a = g->atual >= 0 ? &g->fila[g->atual] : NULL;
  const char *p;
  char id[16];
  if(continuacao) {   /* segunda linha de um aviso: "Step 1 of 2" / "Etapa 2 de 2" */
    int n, m;
    if(a && n_de_m(l, &n, &m) && m == 2) {
      if(n == 2) snprintf(g->fase, sizeof g->fase, "build: sha256 of the whole .pkg");
      else if(strncmp(g->fase, "build:", 6)) snprintf(g->fase, sizeof g->fase, "build: extract");
      *ultimo = t;
    }
    return;
  }
  if((p = strstr(l, "[FPKG] preparing cache: "))) {
    p += 24;
    const char *de = strstr(p, " from /"), *par = achar_id(p, id, sizeof id);
    if(!par) return;
    if(a && !strcmp(a->estado, "preparing")) estado(a, "parado");   /* comecou outro sem fim: o anterior parou */
    /* sem aviso "jogo 1 de M" (modo silencioso): mais de 10 min parado entre dois jogos = lote novo */
    if(!a && g->nf && g->fila[g->nf - 1].fim >= 0 && dif(g->fila[g->nf - 1].fim, t) > 600) novo_lote(g, g->nf);
    int i = achar_jogo(g, id);
    if(i < 0) {
      if(g->nf == FILA_MAX) novo_lote(g, 1);
      i = g->nf++;
    }
    jogo_t *j = &g->fila[i];
    memset(j, 0, sizeof *j);
    snprintf(j->id, sizeof j->id, "%s", id);
    int n = (int)(par - p);
    while(n > 0 && p[n - 1] == ' ') n--;
    snprintf(j->titulo, sizeof j->titulo, "%.*s", n, p);
    estado(j, "preparing");
    j->pkg = de ? tamanho_pkg(de + 6) : -1;
    j->ini = t;
    j->fim = -1;
    j->ha = -1;
    g->atual = i;
    snprintf(g->fase, sizeof g->fase, "open .pkg");
    g->arquivo[0] = 0;
    g->bytes = g->conferido = 0;
    g->arquivos = 0;
    g->pct = -1;
    *ultimo = t;
    return;
  }
  if((p = strstr(l, "NOTIFY(progress): "))) {
    if(!a || strcmp(a->estado, "preparing")) return;
    int n, m;
    const char *barra = strchr(p, '|');
    if(n_de_m(p, &n, &m) && (!barra || strstr(p, " ") < barra)) {
      g->jogo = n;
      g->jogos = m;
    }
    const char *pc = strrchr(p, '%');
    if(pc) {
      const char *c = pc;
      while(c > p && isdigit((unsigned char)c[-1])) c--;
      if(c < pc) g->pct = atoi(c);
    }
    snprintf(g->fase, sizeof g->fase, "build: sha256 of the whole .pkg");
    *ultimo = t;
    return;
  }
  if((p = strstr(l, "NOTIFY: "))) {
    int n, m;
    if(!a || strcmp(a->estado, "preparing") || !n_de_m(p, &n, &m) || !strstr(p, a->titulo[0] ? a->titulo : "\x01"))
      return;
    g->jogo = n;
    g->jogos = m;
    if(n == 1 && g->atual > 0) novo_lote(g, g->atual);   /* jogo 1 de M: lote novo */
    *ultimo = t;
    return;
  }
  if((p = strstr(l, "[PULSE] cache="))) {
    if(!a || strcmp(a->estado, "preparing")) return;
    p += 14;
    const char *f = strstr(p, " files=");
    if(!f || (f - p == 1 && *p == '-')) return;
    snprintf(g->fase, sizeof g->fase, "%.*s", (int)(f - p), p);
    g->arquivos = (unsigned)strtoul(f + 7, NULL, 10);
    const char *b = strstr(f, " bytes=");
    if(b) g->bytes = strtoll(b + 7, NULL, 10);
    const char *ar = strstr(f, " file="), *h = strstr(f, " hashed=");
    if(ar && h && h > ar) snprintf(g->arquivo, sizeof g->arquivo, "%.*s", (int)(h - ar - 6), ar + 6);
    if(!strcmp(g->arquivo, "-")) g->arquivo[0] = 0;
    if(h) {
      long long mb = strtoll(h + 8, NULL, 10);
      if(mb << 20 > g->conferido) g->conferido = mb << 20;
    }
    *ultimo = t;
    return;
  }
  int fim_ok = 0;
  if((p = strstr(l, "[FPKG] cache preparation done: ")) || (p = strstr(l, "[FPKG] cache preparation stopped: "))) {
    fim_ok = strstr(l, "preparation done: ") != NULL;
    if(!achar_id(p, id, sizeof id)) return;
    int i = achar_jogo(g, id);
    if(i < 0) return;
    jogo_t *j = &g->fila[i];
    estado(j, fim_ok ? "done" : "failed");
    j->fim = t;
    const char *v = strstr(p, "), ");
    if(v) {
      j->bytes = strtoll(v + 3, NULL, 10);
      const char *in = strstr(v, " bytes in ");
      if(in) j->arquivos = (unsigned)strtoul(in + 10, NULL, 10);
    }
    if(i == g->atual) g->atual = -1;
    return;
  }
  const char *e = NULL;
  if((p = strstr(l, "[FPKG] candidate preparation postponed: "))) e = "postponed";
  else if((p = strstr(l, "[FPKG] candidate preparation failed: "))) e = "failed";
  if(e) {
    if(!achar_id(p, id, sizeof id)) return;
    int i = achar_jogo(g, id);
    if(i < 0) return;
    estado(&g->fila[i], e);
    if(g->fila[i].fim < 0) g->fila[i].fim = t;
    if(i == g->atual) g->atual = -1;
    return;
  }
  if((p = strstr(l, "[FPKG] cache build failed: title="))) {
    snprintf(id, sizeof id, "%.9s", p + 33);
    int i = achar_jogo(g, id);
    if(i >= 0) estado(&g->fila[i], "failed");
  }
}

/* 1 = havia log (g preenchido, mesmo sem nada preparado) */
static int pelo_log(prog_t *g) {
  char cam[600];
  snprintf(cam, sizeof cam, "%s/data/shadowmount/debug.log", raiz_fs());
  FILE *f = fopen(cam, "rb");
  if(!f) return 0;
  char *d = malloc(LOG_FIM + 1);
  if(!d) {
    fclose(f);
    return 0;
  }
  long ini = 0;
  if(!fseek(f, 0, SEEK_END)) {
    long tam = ftell(f);
    ini = tam > LOG_FIM ? tam - LOG_FIM : 0;
  }
  fseek(f, ini, SEEK_SET);
  size_t n = fread(d, 1, LOG_FIM, f);
  fclose(f);
  d[n] = 0;
  g->fonte = "log";
  char *l = d;
  if(ini > 0) {   /* a primeira linha veio pela metade */
    char *q = strchr(l, '\n');
    l = q ? q + 1 : d + n;
  }
  long ultima = -1, ultimo = -1;
  while(*l) {
    char *q = strchr(l, '\n');
    if(q) *q = 0;
    size_t k = strlen(l);
    if(k && l[k - 1] == '\r') l[k - 1] = 0;
    long t = hora(l);
    if(t >= 0) {
      ultima = t;
      linha_log(g, l + 11, t, 0, &ultimo);
    } else if(ultima >= 0 && *l) {
      linha_log(g, l, ultima, 1, &ultimo);
    }
    if(!q) break;
    l = q + 1;
  }
  free(d);

  long agora = agora_do_dia();
  long lote_ini = -1;
  for(int i = 0; i < g->nf; i++) {
    jogo_t *j = &g->fila[i];
    if(lote_ini < 0 && j->ini >= 0) lote_ini = j->ini;
    if(j->fim >= 0 && j->ini >= 0) j->segundos = dif(j->ini, j->fim);
    j->ha = j->fim >= 0 ? dif(j->fim, agora) : -1;
  }
  if(g->atual >= 0) {
    jogo_t *a = &g->fila[g->atual];
    g->idade = dif(ultimo >= 0 ? ultimo : a->ini, agora);
    if(g->idade > SEM_NOTICIA_S) {   /* o ShadowKraken calou no meio (caiu ou foi fechado) */
      g->sem_noticia = 1;
      estado(a, "parado");
      a->segundos = dif(a->ini, ultimo >= 0 ? ultimo : a->ini);
      a->ha = g->idade;
      g->atual = -1;
    } else {
      g->ativo = 1;
      a->segundos = g->decorrido = dif(a->ini, agora);
      g->conferir_total = a->pkg;
      if(g->pct >= 0 && a->pkg > 0 && g->conferido < a->pkg / 100 * g->pct) g->conferido = a->pkg / 100 * g->pct;
      if(g->jogos > g->jogo) g->faltam = g->jogos - g->jogo;
    }
  }
  if(!g->ativo) {
    g->fase[0] = g->arquivo[0] = 0;
    g->pct = -1;
    g->bytes = g->conferido = 0;
    g->arquivos = 0;
    g->conferir_total = -1;
    g->jogo = g->jogos = 0;
  }
  if(lote_ini >= 0 && g->ativo) g->lote_decorrido = dif(lote_ini, agora);
  return 1;
}

/* ------------------------------------------------------------------ rota */

void sk_progresso_rota(pedido_t *p) {
  prog_t *g = calloc(1, sizeof *g);
  if(!g) {
    responder_erro(p, 500, "sem_memoria", "sem memoria", NULL);
    return;
  }
  prog_zerar(g);
  if(!pela_api(g)) {
    prog_zerar(g);
    if(!pelo_log(g)) {
      prog_zerar(g);
      g->fonte = "nenhuma";
    }
  }
  buf_t b = {0};
  prog_json(&b, g);
  responder_json(p, 200, &b);
  buf_free(&b);
  free(g);
}
