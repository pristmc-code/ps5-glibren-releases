/* Game Library Renamer (payload PS5) - 0.9.61: "Preparando jogos" do ShadowKraken (o que ele esta fazendo com os .pkg).

Quando entram .pkg novos, o ShadowKraken prepara um cache de cada um (extrai os arquivos e confere o .pkg inteiro) e no
PS5 so aparecem os avisos. Aqui o glibren mostra o andamento: jogo N de M, etapa, arquivos/bytes, porcentagem da
conferencia, a fila e o ultimo lote.

Duas fontes, na ordem:
- A: a rota /api/v1/fpkg/progress da API do ShadowKraken (Dev.37+; endereco do config.ini dele, como sk_pastas.c).
  GET (Dev.37); se der 404/405, POST {} como as outras rotas JSON dele.
- B: o fim (256 KB) de /data/shadowmount/debug.log, para as versoes sem a rota (Dev.36 e antes). Linhas usadas:
  "[FPKG] preparing cache: <titulo> (<ID>) from <caminho>", "[PULSE] cache=<fase> files=N bytes=N ... file=<f>
  hashed=N MB", "NOTIFY: ... N of M: <titulo>" (ou "N de M"), "NOTIFY(progress): ... | ...: N%", "[FPKG] cache
  preparation done|stopped: ...", "candidate preparation postponed|failed: ...", "cache build failed: title=<ID>".
  So ha log com o debug do ShadowKraken ligado. Horas do log (HH:MM:SS) comparadas com a hora do PS5.

GET /api/sk/progresso devolve um JSON unico para as duas: {"ok","fonte":"api"|"log"|"nenhuma","ativo","etapa",...}. */
#pragma once

#include "http.h"

/* GET /api/sk/progresso (leitura: PS5, celular e PC) */
void sk_progresso_rota(pedido_t *p);
