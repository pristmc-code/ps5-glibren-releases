// 0.9.33/0.9.34: pagina Payloads - itens acompanhados pelo GitHub (instalada x disponivel, experimental, voltar), "rodando
// agora" e o cartao do ShadowMount+/Procurar atualizacoes, em 360 e 1280 px: sem rolar de lado, botoes da mesma linha
// com a mesma largura, nenhum texto cortado. Roda no Node do Windows com o Playwright do cache do npx, chamado pelo
// testes/teste_payloads_gh.sh com o glibren-pc e os servicos falsos no ar.
//   node teste_payloads_pagina.mjs http://127.0.0.1:8931 <pasta do pacote playwright>
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const [base, pw] = process.argv.slice(2);
const { chromium } = await import(pathToFileURL(path.join(pw, 'index.mjs')).href);
let ok = 0, falhas = 0;
const confere = (nome, cond, info = '') => { if (cond) { ok++; console.log('OK   ' + nome); } else { falhas++; console.log('FALHA ' + nome + (info ? ': ' + info : '')); } };

let navegador;
for (const channel of ['msedge', 'chrome']) { try { navegador = await chromium.launch({ channel }); break; } catch { /* outro */ } }
if (!navegador) { console.log('FALHA nenhum navegador abriu'); console.log('=== pagina 0 ok, 1 falhas'); process.exit(1); }

for (const tela of [{ w: 360, h: 780, nome: 'celular' }, { w: 1280, h: 800, nome: 'PC' }]) {
  const pagina = await navegador.newPage({ viewport: { width: tela.w, height: tela.h } });
  const n = s => `${s} (${tela.nome})`;
  await pagina.goto(base + '/payloads');
  await pagina.waitForFunction(() => document.querySelectorAll('#lista .item').length === 6 &&
    /v0\.5\.7/.test(document.querySelector('.item[data-id="dump-forge"] .versoes')?.textContent || ''), null, { timeout: 30000 });
  const txt = sel => pagina.$eval(sel, e => e.textContent).catch(() => '');
  const df = '.item[data-id="dump-forge"]', kr = '.item[data-id="kraken-mount"]', sk = '.item[data-id="shadowkraken"]';
  confere(n('dump-forge: instalada x GitHub'), /Instalada: v0\.5\.6/.test(await txt(df + ' .versoes')) && /No GitHub: v0\.5\.7/.test(await txt(df + ' .versoes')), await txt(df + ' .versoes'));
  confere(n('dump-forge: botao Atualizar'), (await txt(df + ' .b-baixar')).includes('Atualizar para v0.5.7'), await txt(df + ' .b-baixar'));
  confere(n('dump-forge: voltar para v0.5.7'), (await txt(df + ' .b-voltar')).includes('Voltar para v0.5.7') && await pagina.isVisible(df + ' .b-voltar'));
  confere(n('dump-forge: rodando agora'), (await txt(df + ' .agora')).includes('Rodando agora (v0.5.6)'), await txt(df + ' .agora'));
  confere(n('shadowkraken: experimental'), await pagina.isVisible(sk + ' .exp'));
  // 0.9.34: ShadowKraken removido do GitHub (guardado: fica para Ativar/Remover) e kraken-mount com 404
  confere(n('shadowkraken: sem atualizacoes'), (await txt(sk + ' .b-baixar')).includes('Sem atualizações'), await txt(sk + ' .b-baixar'));
  confere(n('shadowkraken: nota removido'), (await txt(sk + ' .gh-erro')).includes('Repositório removido do GitHub em 17/11/2026; sem atualizações.'), await txt(sk + ' .gh-erro'));
  confere(n('shadowkraken: Remover'), await pagina.isVisible(sk + ' .b-remover') && (await txt(sk + ' .b-remover')).includes('Remover do glibren'));
  confere(n('shadowkraken: Ativar'), await pagina.isVisible(sk + ' .b-ativar'));
  confere(n('kraken: repositorio indisponivel'), (await txt(kr + ' .gh-erro')).includes('Repositório indisponível no GitHub'), await txt(kr + ' .gh-erro'));
  confere(n('BlueV: rodando agora'), (await txt('.item[data-id="bluev"] .agora')).includes('Rodando agora'), await txt('.item[data-id="bluev"] .agora'));
  confere(n('kraken: sem Remover'), !(await pagina.isVisible(kr + ' .b-remover')));
  confere(n('kraken: esperando o SMP'), /Rodando agora \(v0\.2\.1\) \(esperando ShadowMount\+ parar\)/.test(await txt(kr + ' .agora')), await txt(kr + ' .agora'));
  confere(n('kraken: nao carregado some'), !(await txt('.item[data-id="prefbar"] .agora')).includes('Rodando'));
  confere(n('cartao: ShadowMount+ rodando'), (await txt('#ghSmp')).includes('ShadowMount+ rodando agora (v1.7beta12)'), await txt('#ghSmp'));
  confere(n('cartao: botao Procurar'), (await txt('#ghProcurar')).includes('Procurar atualizações') || (await txt('#ghProcurar')).includes('Procurando'), await txt('#ghProcurar'));
  const medidas = await pagina.evaluate(() => {
    const larguras = [...document.querySelectorAll('.botoes')].filter(b => b.offsetParent).map(b =>
      [...b.querySelectorAll('button')].filter(x => x.offsetParent).map(x => Math.round(x.getBoundingClientRect().width)));
    const cortados = [...document.querySelectorAll('button, .versoes, .agora, .linha, h2')].filter(e => e.offsetParent &&
      (getComputedStyle(e).textOverflow === 'ellipsis' || e.scrollWidth > e.clientWidth + 1)).map(e => e.className + ':' + e.textContent.slice(0, 30));
    return { larguras, cortados, rola: document.scrollingElement.scrollWidth > innerWidth };
  });
  confere(n('sem rolar de lado'), !medidas.rola);
  confere(n('botoes da mesma linha: mesma largura'), medidas.larguras.every(l => l.every(x => Math.abs(x - l[0]) <= 1)), JSON.stringify(medidas.larguras));
  confere(n('nenhum texto cortado'), medidas.cortados.length === 0, medidas.cortados.join(' | '));
  await pagina.close();
}
await navegador.close();
console.log(`=== pagina ${ok} ok, ${falhas} falhas`);
process.exit(falhas ? 1 : 0);
