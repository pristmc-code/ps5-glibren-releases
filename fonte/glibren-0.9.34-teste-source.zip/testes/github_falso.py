# 0.9.33: servicos falsos para os testes dos payloads acompanhados pelo GitHub (teste_payloads_gh.sh).
#   python3 -I github_falso.py gh <porta> <pasta>      API do GitHub + downloads
#   python3 -I github_falso.py kraken <porta> <pasta>  kraken-mount (GET /api/state)
#   python3 -I github_falso.py bluev <porta> <pasta>   BlueV (GET /api/status = <pasta>/bluev.json)
#   python3 -I github_falso.py smp <porta> <pasta>     ShadowMount+/ShadowKraken (POST /api/v1/version)
# gh: <pasta>/releases.json = {"dono/repo": [release, ...]} (mais nova primeiro, formato da API: tag_name, prerelease,
# draft, published_at, body, assets[{name,size,digest}]); /repos/<r>/releases/latest = a primeira sem draft nem
# prerelease; /repos/<r>/releases = a lista; /repos/<r> = 200. 0.9.34: repos em <pasta>/sumidos (um por linha) = 404 em tudo. <pasta>/modo_api: "ok" ou "403"/"429" (limite). Cada pedido a API vai
# para <pasta>/hits. Downloads: /dl/<repo>/releases/download/<tag>/<asset> = <pasta>/arquivos/<tag>/<asset>.
# kraken: <pasta>/kraken.json (corpo do /api/state; sem arquivo = porta fechada nao da: responde 503).
# smp: <pasta>/smp_versao (texto; sem arquivo = 503).
import http.server, json, os, sys, urllib.parse

papel, porta, pasta = sys.argv[1], int(sys.argv[2]), sys.argv[3]


def ler(nome, padrao=None):
    try:
        with open(os.path.join(pasta, nome), encoding="utf-8") as f:
            return f.read()
    except OSError:
        return padrao


class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def enviar(self, status, corpo, tipo="application/json"):
        if isinstance(corpo, str):
            corpo = corpo.encode()
        self.send_response(status)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(corpo)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(corpo)

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        if papel == "bluev":   # 0.9.34: BlueV (GET /api/status; <pasta>/bluev.json, sem arquivo = 503)
            k = ler("bluev.json")
            return self.enviar(200, k) if k is not None and u.path == "/api/status" else self.enviar(503, "{}")
        if papel == "kraken":
            k = ler("kraken.json")
            return self.enviar(200, k) if k is not None and u.path == "/api/state" else self.enviar(503, "{}")
        if papel != "gh":
            return self.enviar(404, "{}")
        if u.path.startswith("/dl/"):
            partes = u.path.split("/")   # /dl/dono/repo/releases/download/tag/asset
            if len(partes) == 8 and partes[4] == "releases" and partes[5] == "download":
                arq = os.path.join(pasta, "arquivos", partes[6], partes[7])
                if os.path.isfile(arq):
                    with open(arq, "rb") as f:
                        return self.enviar(200, f.read(), "application/octet-stream")
            return self.enviar(404, "Not Found", "text/plain")
        with open(os.path.join(pasta, "hits"), "a") as f:
            f.write(u.path + ("?" + u.query if u.query else "") + "\n")
        modo = (ler("modo_api", "ok") or "ok").strip()
        if modo in ("403", "429"):
            return self.enviar(int(modo), '{"message":"API rate limit exceeded"}')
        rels = json.loads(ler("releases.json", "{}"))
        p = u.path.split("/")   # /repos/dono/repo[/releases[/latest]]
        sumidos = (ler("sumidos", "") or "").split()
        if len(p) >= 4 and p[1] == "repos" and p[2] + "/" + p[3] in sumidos:
            return self.enviar(404, '{"message":"Not Found"}')   # 0.9.34: repositorio removido/privado
        if len(p) == 4 and p[1] == "repos":
            return self.enviar(200, json.dumps({"full_name": p[2] + "/" + p[3]}))
        if len(p) < 5 or p[1] != "repos" or p[4] != "releases":
            return self.enviar(404, '{"message":"Not Found"}')
        lista = rels.get(p[2] + "/" + p[3], [])
        if len(p) == 6 and p[5] == "latest":
            for r in lista:
                if not r.get("draft") and not r.get("prerelease"):
                    return self.enviar(200, json.dumps(r))
            return self.enviar(404, '{"message":"Not Found"}')
        return self.enviar(200, json.dumps(lista[:5]))

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        self.rfile.read(n)
        if papel == "smp" and self.path == "/api/v1/version":
            v = ler("smp_versao")
            if v is None:
                return self.enviar(503, "{}")
            return self.enviar(200, json.dumps({"status": 0, "api_version": 1, "shadowmount_version": v.strip(), "capabilities": ["web_ui"]}))
        return self.enviar(404, "{}")


http.server.ThreadingHTTPServer(("127.0.0.1", porta), H).serve_forever()
