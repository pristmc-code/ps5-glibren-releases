/* Game Library Renamer (payload PS5) - gerenciador de arquivos, leitura das pastas e renomear. */
#pragma once

#include "util.h"

/* Lista uma pasta (pastas primeiro, depois arquivos, por nome). Devolve 0 ou errno. */
int arquivos_listar(const char *caminho, buf_t *json);
/* Le a raiz de cada pasta configurada: arquivos comuns (com tamanho) e pastas de jogo (tipo "pasta", sem tamanho). */
void arquivos_escanear(buf_t *json);
/* 1 = pasta com eboot.bin e sce_sys/param.json ou sce_sys/param.sfo (pasta de jogo do ShadowMount+). */
int arquivos_pasta_de_jogo(const char *caminho);

/* Erros do renomear: chave para a tela (traduzida la). */
typedef enum { REN_OK, REN_INVALIDO, REN_ORIGEM_SUMIU, REN_DESTINO_EXISTE, REN_EM_DOWNLOAD, REN_FALHOU } ren_t;
ren_t arquivos_renomear(const char *pasta, const char *de, const char *para, long long tamanho);
const char *ren_chave(ren_t r);

int em_download(const char *pasta, const char *nome);
