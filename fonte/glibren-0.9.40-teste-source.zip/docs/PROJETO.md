# Game Library Renamer — payload PS5 (ELF)

Notas de desenvolvimento (em portugues). A documentacao de uso esta no [README](../README.md).

Estado (03/11/2026): **versao 0.1-teste pronta para o primeiro teste no PS5**. Repositorio privado.
Testado so no PC (WSL, versao Linux do mesmo codigo): testes da API e da fila de tarefas ok, telas no
navegador do PC e num celular Android emulado, regra de nome JS = Python nos 71.345 titulos.
**Ainda nao rodou num PS5 real.**

## Funcoes adicionadas depois da 0.1 (03/11/2026)

- Tela tambem pelo PC e celular (http://IP-DO-PS5:8765), com layouts proprios para TV, PC e celular.
- Copiar / mover / excluir em lote (`src/tarefas.c`): fila com thread propria, `.part` ate terminar, confere
  espaco livre, nunca sobrescreve (ignora o que ja existe no destino), mover no mesmo disco = rename(),
  renomear junto e opcao do usuario (desligado), exclusao com aviso visivel por 3 s, le as pastas de novo no fim.
- Temperatura e ventoinha (`src/termico.c`, `src/sistema.c`, `web/temperatura.html`): CPU, SoC, SSD M.2,
  ventoinha %, grafico de 8 min, vista BASICO/AVANCADO (CPU por nucleo, RAM, IP, tempo ligado), alerta por
  notificacao, controle do alvo da ventoinha (50-85 °C, nunca acima do valor do sistema; reaplica a cada 2 s;
  recua para o automatico em conflito com outro programa ou apos 5 falhas).
- Teste de velocidade dos discos (`src/discos.c`, `web/discos.html`): SSD interno, armazenamento estendido e
  USB; 1/2/4/8 GB; arquivo temporario apagado no fim e sobras limpas ao iniciar.
- Teste de internet (`src/internet.c`, `web/internet.html`): ping/jitter (tempo de conexao TCP), download e
  upload com 4 conexoes; servidores proximos da lista publica do speedtest.net (pedida pelo PS5, segue a regiao)
  ou Cloudflare; automatico escolhe pelo menor ping e cai para a Cloudflare se falhar.
- Servidor reabre a porta depois do modo de repouso; fechamento gradual das conexoes (esperar o navegador
  fechar evita perder os ultimos bytes em redes lentas).
- Paginas param de consultar o PS5 quando a aba fica em segundo plano.
- Licenca: GPL-3.0-or-later (como o SDK).

## 0.2-teste (03/11/2026 noite): resultado do 1o teste no PS5 real e correcoes

Teste da 0.1 no PS5: o glibren-install.elf **nao criou o icone** e o payload **nao ficou rodando** (as vezes a
tela abria pelo celular e logo depois "o PS5 nao respondeu"). Comparado com o ProsperoMgr e o websrv (que
funcionam), a 0.2 passa a:
- elevar as permissoes do proprio processo antes de tudo (uid 0, rootdir/jaildir, authid 0x4801000000000013,
  caps e attrs) - sem o authid o PS5 recusa registrar o icone;
- nomear o processo `glibren.elf` (thr_set_name) e matar copias antigas com esse nome (lista kinfo_proc);
- `sceUserServiceInitialize`; ignorar SIGPIPE/SIGHUP e SO_NOSIGPIPE em cada conexao;
- threads com pilha de 1 MB (as conexoes usam buffers de 64 KB na pilha);
- reabrir a porta no SIGCONT (volta do repouso);
- diario em `/data/GameLibraryRenamer/glibren.log` + aviso na tela se cair (sinal fatal);
- **o proprio payload cria o icone** (metodo do ProsperoMgr: o tile aponta para a porta do proprio payload,
  127.0.0.1:8765), registrando a pasta /user/app/PMGL00001 como o websrv faz (sceAppInstUtilAppInstallTitleDir).
  O ProsperoMgr instala um PKG feito com as ferramentas oficiais da Sony - nao usamos isso.
  O icone so funciona com o payload rodando (igual ao ProsperoMgr). glibren-install.elf foi removido.
- Removido todo acesso a loja da Sony (capa de reserva da PS Store).

## 0.3-teste (03/11/2026): internet no PS5

No teste da 0.2 o payload rodou mas nao acessou a internet. A 0.3 troca a sceHttp2 pela sceHttp (como o ProsperoMgr):
contexto novo por pedido, DNS proprio (DNS do PS5 e reserva em 8.8.8.8/1.1.1.1; conecta pelo IP com Host e,
se o site recusar, pelo nome; lembra o que funcionou), tempo limite de 20 s, redirecionamentos seguidos aqui,
sceNetCtlInit depois de elevar as permissoes. **A verificacao do certificado continua ligada** (o ProsperoMgr
desliga; nao fizemos isso). Cada falha vai para o diario, que agora abre em http://IP-DO-PS5:8765/diario.

## 0.4-teste (03/11/2026): CPU/memoria, grafico e icone em Midia

- Memoria e nucleos nao apareciam no PS5. O ProsperoMgr nao mostra isso; o ps5-web-manager usa os mesmos sysctl.
  A 0.4 pergunta o tamanho do kern.cp_times antes (o kernel pode responder com espaco para mais CPUs que as
  existentes; ignora as zeradas), le os numeros com 4 ou 8 bytes, tenta hw.physmem/realmem/usermem e
  v_free+v_inactive+v_cache, CLOCK_UPTIME como reserva do tempo ligado, e registra no diario o sysctl que falhar.
- Grafico de temperatura pequeno no rodape no navegador do PS5 (WebKit nao estica svg com flex): agora fica numa
  area de tamanho proprio com o svg em posicao absoluta.
- Icone aparecia em Jogos: param.json com "applicationCategoryType": 65536 (o tile do ProsperoMgr usa esse valor);
  o payload reinstala o icone sozinho porque o conteudo mudou.
- Tela grande demais no PS5: o navegador do PS5 mostra uma area menor que a TV. O ProsperoMgr nao amplia nada no
  PS5 (so tira efeitos pesados). A 0.4 usa no PS5 os mesmos tamanhos do PC e tira o zoom de 1,25-1,3.
- Pagina Jogos: o texto explicativo vai para baixo dos botoes (largura toda), sem apertar o titulo.
- Botao de tela cheia aparecia no PS5 (o display do botao vencia o atributo hidden): regra [hidden] geral.

## 0.5-teste (03/11/2026): internet, CPU/memoria, botao parar

- Diario do teste 0.4: rede e DNS ok; toda conexao segura falhava (0x8095f00b/0x8095f010 pelo IP, 0x8095f00c pelo
  nome). O JobeesLair liga o SNI do sceHttps (opcao 0x80): "sem ele nenhum pedido a Cloudflare ou ao GitHub passa da
  negociacao". A 0.5 liga o SNI, tenta pelo nome com a verificacao do certificado ligada e, se a parte segura ainda
  falhar, passa a aceitar o certificado sem verificar (como o ProsperoMgr) - autorizado pelo usuario; o diario avisa.
- CPU/memoria: o PS5 nao tem kern.cp_times nem vm.stats/hw.physmem (errno 2; o PS5_DevTools confirma). Agora:
  CPU por nucleo pelo tempo das threads ociosas ("idle: cpuN"/"SceIdleCpuN") na lista de processos (kinfo_proc com
  threads); memoria = soma da residente de todos os processos sobre 16 GB, mostrada com "≈". Se nao achar as threads
  ociosas, o diario lista os nomes das threads do kernel.
- Botao "⏻ Parar payload" (era "Sair") com confirmacao.
- Teste de internet no PC/PS5 com o arranjo lado a lado (medidor menor a esquerda).

## 0.7-teste (04/11/2026): nome e icone de dentro do arquivo do jogo (sem internet)

- Leitores so-leitura (src/imagem.h, fmt_*.c): .pkg (CNT do PS4 e envelopes FIH/LIH de PS5), .exfat, .ffpkg (UFS2),
  .ffpfs (PFS) e .ffpfsc (PFS com imagem interna em PFSC/zlib - miniz 3.0.2, MIT, em src/terceiros). Leem
  sce_sys/param.json (ou param.sfo) e icon0.png. src/jogo_local.c escolhe o leitor (a extensao so define a ordem;
  cada leitor confere o magic), guarda o resultado na memoria e grava o icone em icones/<TID>.png. Rota
  /api/local?pasta=&nome= (so pastas configuradas); a pagina consulta antes da base e da internet. Arquivo sem o
  codigo no nome passa a ser reconhecido. PFS cifrado (PKG oficial) nao da para ler: fica com a base/internet.
- Testes: testes/fmt_{exfat,ufs2,pfs,pkg}/ (imagens reais geradas com mkfs.exfat, makefs/UFS2Tool, MkPFS e PkgTool)
  e testes/teste_jogo_local.sh (de ponta a ponta, com a demo rodando).
- Botao de versao sempre visivel (clicar procura versao nova). CPU: so o uso total, pela lista de processos sem
  threads (a lista com threads da errno 2 no PS5). Capas: Accept-Encoding identity, diario de cada icone e pagina,
  teste de WebP do navegador (/api/navegador).
- Detalhes dos formatos e o que deu certo/errado: base de conhecimento ps5-conhecimento/ (fora deste repositorio).

## Apps homebrew com um clique e botao YouTube no PS5 (04/11/2026, ainda sem versao publicada)

- Catalogo assinado no repo publico de versoes: `apps.json` + `apps.json.sig` (Ed25519 do JSON inteiro, mesma chave
  do payload). Formato: `{"apps":[{"id","titulo","title_id","versao","url","tamanho","sha256","preservar":[...],"busca"}]}`.
  Gerado por `tools/publicar_app.py` (confere o zip como o payload, mantem os outros apps, assina). Apps previstos:
  ytps5 PPSA99350 (preservar yt-token.json) e youtube-maxd PPSA99991 (zip com pasta de topo `PPSA99991/`; dados em
  /data/youtube-maxd, preservar vazio). O app oficial (PPSA01650/1/2, porta do Y2JB) e recusado no catalogo e no botao.
- `src/apps.c`: GET /api/apps (catalogo + estado + trabalho) e POST /api/apps/instalar (thread, um por vez):
  baixando (https_baixar em fluxo para /data/GameLibraryRenamer/apps/<id>.zip.part, SHA-256 calculado junto) ->
  conferindo (tamanho, sha, zip, eboot.bin + sce_sys/param.json, titleId) -> extraindo (<TID>.glibren_novo) ->
  instalando (copia "preservar", grava glibren_app.json, troca por rename com restauracao) -> pronto/erro.
- `src/zip.c` (leitor proprio: EOCD sem ZIP64, stored/deflate em fluxo com janela de 32 KB, CRC-32, recusa nomes
  perigosos, links, cifrados, repetidos, bombas), `src/sha256.c`, miniz agora compilado so em `src/miniz_impl.c`.
- POST /api/youtube: grava a busca (1 linha UTF-8, ate 200 bytes, .tmp + rename) em /data/homebrew/<TID>/<busca> e
  abre o app (sceSystemServiceLaunchApp com prototipo weak; nunca KillApp). Pagina: chip "Apps" no topo e o botao
  YouTube volta a aparecer no PS5 (PC/celular continuam abrindo o YouTube na web).
- https: hosts github.com, release-assets.githubusercontent.com e objects.githubusercontent.com (assets das releases;
  /api/web continua sem acesso a nada do GitHub). Testes no PC: GLR_TESTE_BASE / GLR_TESTE_CHAVE / GLR_TESTE_HOMEBREW
  (so no build de PC). `testes/apps/teste_unidade.sh` (26) e `testes/teste_apps.sh` (48).

## 0.6-teste (04/11/2026): atualizacao pelo proprio PS5

- Repositorio PUBLICO pristmc-code/ps5-glibren-releases (decisao do usuario): glibren.elf + glibren.elf.sig +
  versao.json + fonte/glibren-VERSAO-source.zip (codigo de cada versao: o SDK e GPL-3, entao binario publico exige
  o codigo junto). O payload le versao.json, baixa o .elf e a assinatura, confere com a chave publica Ed25519
  embutida (src/chave_publica.h; TweetNaCl em src/terceiros), grava /data/GameLibraryRenamer/glibren.elf e envia ao
  elfldr 127.0.0.1:9021. Arquivo adulterado ou de outra chave e recusado (testado).
- Publicar uma versao: mudar VERSAO em src/api.h, compilar, commit no repo privado, `git archive` do codigo para
  versoes-publicas/fonte/, `python tools/publicar_versao.py ../versoes-publicas "notas"` (assina com a chave privada
  em ~/.glibren/assinatura_ed25519.pem - NUNCA no repositorio), commit/push no repo publico e release no GitHub.
- Player do YouTube nao toca no navegador do PS5: link escondido no PS5.

## Icone na aba Midia (0.1 - substituido pela 0.2 acima)

A tela e para usar **no proprio PS5**, por um icone na aba Midia (como outros payloads), que abre por
cima do app da loja que esta baixando (app comum fecharia o outro). Tambem abre pelo PC e celular.
Como funciona (mesmo esquema do instalador do ftpsrv, `install-ps5.c`):
- `glibren-install.elf` (enviado uma vez) cria `/user/app/PMGL00001/` com `payload.elf`,
  `iniciar.html`, `sce_sys/icon0.png` (512x512) e `sce_sys/param.json` (`deeplinkUri`
  `http://127.0.0.1:8080/fs/user/app/PMGL00001/iniciar.html`) e registra o titulo
  (sceAppInstUtilAppInstallTitleDir pelo NID Wudg3Xe3heE; reserva sceAppInstUtilAppInstallAll).
- O icone abre `iniciar.html` **pelo websrv (porta 8080)**: se o payload ja responde em 8765, vai para a tela;
  se nao, chama `/elfldr?elf=file://user/app/PMGL00001/payload.elf` do websrv e espera ate 30 s.
- Depende do websrv rodando (o icone do ftpsrv tambem depende).
- Tela no PS5: html.ps5 (user agent "PlayStation") com zoom 1.3, foco para o controle, confirmacao do
  "Renomear todos" dentro da pagina (confirm() pode nao funcionar no app de midia), sem botao Loja (sites da
  Sony nao abrem no PS5 desbloqueado) e sem YouTube (abriria o app).

## Como usar (teste)

1. Compilar: na pasta do projeto, `wsl -d Ubuntu-24.04 -u root -- bash compilar.sh all pc`
   -> `saida/glibren.elf` (PS5) e `glibren-pc` (Linux, teste).
2. Enviar `glibren-install.elf` para o PS5 (elfldr, porta 9021) uma vez: aparece o icone
   "Game Library Renamer" na aba Midia (notificacao confirma).
3. Abrir pelo icone (com o websrv ativo). Tambem funciona de outro aparelho em http://IP-DO-PS5:8765.
4. Dados no PS5: `/data/GameLibraryRenamer/` (config.ini, base_titulos.tsv, cache_consultas.json, icones/).

Testes no PC: `testes/teste_api.sh` (API, 31 casos), `testes/comparar_nomes.py base_titulos.tsv` (regra de nome),
`testes/demo.sh` (sobe a demo em http://localhost:8765 com pastas de mentira; `demo.sh parar`).

## 0.9.40-teste (18/11/2026): area extra que o jogo nao tem, pelo MemDBG (cheats) + MemDBG na pagina Payloads
Pedido e autorizacao do dono (18/11): usar o MemDBG (seregonwar/MemDBG, GPL-3) para as cheats que precisam de uma area
extra que nao existe no jogo (Easy Score e 10x Score do Terminator 2D, PPSA25872 01.002.000: areas em +0x7FD17000 e
+0x7FD17032, a mesma pagina), que na 0.9.34 mostravam "use o onionHEN para ela".
- **Limite mantido**: na 0.9.33 o filtro de seguranca barrou o glibren criar a area sozinho (ptrace + injecao de syscall
  no jogo) e decidimos NAO contornar. Continua valendo: o glibren nao tem ptrace, injecao de syscall, mmap no jogo nem
  code cave propria. O caminho e ser **cliente** do protocolo documentado do MemDBG, um payload aberto separado que a
  pessoa carrega. `teste_cheats.sh` confere que `cheats.c` continua sem ptrace/mdbg/mmap/mprotect e que `memdbg.c` so usa
  socket no 127.0.0.1 (nem kernel_*, nem syscall, nem /proc; no PS5, `memdbg.o` sem esses simbolos).
- `src/memdbg.c`/`memdbg.h` (novo): cliente do protocolo MDBG (docs/protocol.md e
  include/memdbg/core/memdbg_protocol.h do MemDBG, conferidos no espelho local de 12/11, feature level 4, wire v1).
  Comandos usados: HELLO 0x0001 (corpo SES1 com papel TOOL e sessao; resposta V3 de 112 bytes: versao, capacidades,
  feature level, version_full; exige nome "MemDBG"), PING 0x0002, GOODBYE 0x0003, PROCESS_PROTECT 0x0108,
  PROCESS_ALLOC 0x0109 (flags bit 0 = honrar a dica), PROCESS_FREE 0x010A, MEMORY_READ 0x0200 (so o sub-quadro cru
  0x00; pedacos de 2 KB, abaixo do limite de compressao de 4 KB) e MEMORY_WRITE 0x0201. Capacidades exigidas: bits 2
  (read), 3 (write) e 23 (alloc); bit 22 (protect) opcional. Cuidados do MemDBG (acceptor.c): 8 conexoes por minuto por
  endereco e uma notificacao "MemDBG 127.0.0.1 connected" a cada HELLO novo -> "rodando agora" com cache de 20 s
  (`GLR_TESTE_MEMDBG_CACHE_S`), HELLO so na 1a vez e a cada 10 min (PING nas outras) e uma conexao so por ligar/desligar.
  Porta 9020 (`GLR_TESTE_MEMDBG_PORTA` no PC).
- `src/cheats.c`: area extra com pagina inexistente (`cave_ok` = `area_extra_criar`) + chave "Area extra (teste)" ligada:
  com o MemDBG rodando e anunciando reservar/ler/gravar, a cheat pode ligar (`"memdbg":true` na cheat; trecho com
  `"criar":true` conta como desligado, nao como erro); sem o MemDBG continua `area_extra_criar`; rodando sem a
  capacidade = `reserva_sem_suporte`. Ligar (`reservar_areas`): junta as areas proximas, pede ALLOC r-w alinhado a
  16 KB com a dica = endereco da cheat e depois PROTECT r-w-x (como o onionHEN faz mmap + mprotect; sem PROTECT anunciado,
  ALLOC r-w-x direto); se a reserva nao cobrir o endereco EXATO (os saltos do arquivo sao relativos a ele), FREE e
  tenta alinhado a 4 KB; senao recusa (`cheats_memdbg`, motivo `reserva_outro_endereco`). No PS5 confere pelo proprio
  glibren (so leitura do vm_map) que a area ficou executavel (`reserva_sem_exec`). A escrita na area vai pelo
  MEMORY_WRITE (pagina nova sem memoria fisica: o caminho DMAP do glibren nao serve), com leitura de volta (kernel e,
  se falhar, MEMORY_READ); os saltos continuam pelo kernel, como antes. As reservas vao no aplicadas.json (`"memdbg":
  [{"endereco","tamanho"}]`) ANTES de gravar no jogo. Desligar: tira os saltos, devolve os zeros (se o MemDBG fechou,
  segue mesmo assim: sem os saltos nada usa a area), espera 200 ms e da FREE. Outra cheat com area na mesma reserva
  usa a que ja existe; ao desligar a dona a reserva passa para ela. Jogo fechou = a reserva some com o processo.
  Recusas do MemDBG (status `MEMDBG_ERR_*`) = `cheats_memdbg` com `motivo`/`status`, nada gravado e o que ja tinha sido
  reservado e liberado. `GET /api/cheats` (com a chave ligada) traz `memdbg: {rodando, versao, nivel, reserva, porta}`.
- `src/payloads.c`: item novo `memdbg` (seregonwar/MemDBG, asset `MemDBG-ps5.elf`, release normal "nightly-AAAAMMDD-
  g<commit>" com digest; 12/11: nightly-20261112-g6e31144, 1.256.544 bytes, sha256 d2d8565c7c83b1d1...e383cbb), uma_vez
  (a 2a copia nao abriria a 9020), "rodando agora" pelo HELLO (versao + `rodando_nivel` = feature level; nightly: vale o
  commit "g<hash>" da tag contra a versao "0.2.0-nightly.N.g<hash>"). Textos pt/en/es: ferramenta de depuracao aberta
  na rede sem senha (TCP 9020 e 744, UDP 9022 e 9023), carregar so quando for usar, nao testado por nos no PS5 Pro 12.00.
- Portas do MemDBG x setup do dono (Y2JB + ShadowMount+ + elfldr 9021, glibren 8765, Jobe/bg-downloader 34200/34201,
  tube 34210, BlueV 7733, ZhiThemes 4444, Dump Forge 8095, SMP 10101, kraken-mount 8097): **nenhum conflito**. A 744 e a
  porta classica do ps5debug/ps5debug-NG (e do depurador do etaHEN): nao carregar junto (o MemDBG continua na 9020 se a
  744 estiver ocupada). A base ps5-conhecimento nao tinha nenhuma dessas portas; registrado em ps5-conhecimento/06-distribuicao-atualizacao-licenca.md.
- Paginas: Cheats (`m_criar` = "Carregue o MemDBG (pagina Payloads) ou use o onionHEN para esta cheat.", linha "area
  extra criada pelo MemDBG (teste)", motivos e erros `cheats_memdbg`, pt/en/es) e Payloads ("Rodando agora (vX,
  protocolo nivel 4)").
- Testes: `testes/memdbg_falso.py` (servidor MDBG falso: HELLO V3, PING, GOODBYE, ALLOC, PROTECT, FREE, READ, WRITE;
  modos ok/sem_alloc/alloc_recusa/outro_endereco/protect_recusa; a memoria das reservas fica nele). `teste_cheats.sh`:
  sem MemDBG, HELLO/PING, ligar (ALLOC na dica de 16 KB, PROTECT rwx, area pelo WRITE, salto pelo kernel, registro),
  area vizinha na mesma reserva, desligar (passa a reserva, FREE no ultimo), SIGTERM, SIGKILL + retomada, MemDBG fechado,
  ALLOC/PROTECT recusados, outro endereco (16 KB e 4 KB, nada sobra), sem a capacidade, textos. `teste_payloads_gh.sh`:
  nightly, instalar, ativar, rodando/versao/nivel, outra commit = versao diferente; pagina em 360 e 1280 px.
- ❓ PS5 real: se o MemDBG do 12.00 honra a dica do ALLOC (o PAL dele faz mmap sem MAP_FIXED; se a faixa estiver livre o
  kernel costuma usar a dica) e se o PROTECT para rwx passa. Se nao, a pagina diz "reservou a area em outro endereco"
  e nada e gravado.

## 0.9.39-teste (18/11/2026): limite de consultas ao GitHub sem tela contraditoria
- Defeito: no limite proprio do glibren (30 consultas/hora ao GitHub, `GH_MAX_POR_HORA`) o `/api/payloads` ficava
  com `gh.disponivel` = null e `gh.erro` = "limite", mas `atualizar` e `pode_instalar` continuavam true: a pagina
  mostrava "Atualizar para vX" sem a linha "No GitHub".
- Correcao na origem (`src/payloads.c`): `gh_res` guarda so a ultima resposta que vale o cache (ok, sem asset, varios
  assets, sem release, 404) e o erro de uma tentativa sem resposta (limite, rede, HTTP, JSON) vai para `gh_falha`.
  `disponivel`, `atualizar` e `pode_instalar` vem todos da ultima resposta boa; `"cache": true` quando ela e de antes
  de uma tentativa que falhou (data = `consultado_em`). `pode_instalar` nunca sai true sem `disponivel`.
- `gh_livre_em()` (`src/github_rel.c`) e o campo `gh_livre_em` no JSON: quando o glibren volta a perguntar (pausa de
  403/429 ou o mais antigo dos 30 pedidos da hora completando 1 h). Instalar sem resposta boa guardada: "limite de
  consultas ao GitHub: tente de novo em N min".
- Pagina: com cache, "No GitHub: vX" + "Dados de HH:MM; limite de consultas ao GitHub, tente de novo em N min." (outros
  erros: "Dados de HH:MM. <erro>"); sem cache, o botao vira "⏳ Limite do GitHub: N min" (desabilitado) e a nota diz
  "Limite de consultas ao GitHub: tente de novo em N min.". Textos pt/en/es, sem reticencias.
- Testes: `teste_payloads_gh.sh` gasta os 30 pedidos com o GitHub falso (kraken-mount respondendo 500 =
  `<pasta>/falhando` no `github_falso.py`) e confere o JSON (dump-forge com cache, kraken-mount sem nada), a instalacao
  pelo cache (sem pedido novo) e a pagina em 360 e 1280 px (`teste_payloads_pagina.mjs ... limite`).

## 0.9.38-teste (18/11/2026): versao mais nova tambem dos jogos de PS4 (consulta pelo celular/PC)
- Mudanca de escopo autorizada pelo dono (18/11): o celular (Jobe Controle 0.4-teste) e o app de PC (1.3) consultam
  tambem os jogos de PS4 (CUSA). O PS5 continua sem falar com a Sony; o GET /api/versoes ja listava os CUSA (sem
  versionJsonUri): o cliente monta o endereco `https://gs-sec.ww.np.dl.playstation.net/plo/np/<CUSA>/<HMAC-SHA256 de
  "np_"+CUSA>/<CUSA>-ver.xml` (chave publica do andshrew/PS4-Updates-Python, credito ao gist de Zer0xFF). Mesmo
  certificado raiz SCEI DNAS Root 05 (*.ww.np.dl.playstation.net), HTTPS com a raiz fixada.
- Pagina: para CUSA o firmware e "pede firmware de PS4 X.YY" (so referencia; o PS5 roda PS4 pela compatibilidade) e
  nunca fica vermelho. Textos pt/en/es. `teste_versoes.sh` + pagina com um resultado de PS4.

## 0.9.37-teste (18/11/2026): versao de cada jogo e "existe versao mais nova na Sony" (consulta pelo celular/PC)
Pedido e autorizacao do dono (18/11). Regra fixa mantida: **o PS5 nunca fala com a Sony**. Quem consulta e o celular (APK
Jobe Controle 0.4-teste, tela "Versoes dos jogos") ou o app de PC (Game Library Renamer 1.3, "Consultar atualizacoes na
Sony"); o payload so le os param e guarda o resultado.
- `fmt_param.c`: `info_jogo_t` ganhou `versao` (PS5 `contentVersion`; PS4 a maior entre `VERSION` e `APP_VER`, como a
  pagina Cheats), `fw_minimo` (PS5 `requiredSystemSoftwareVersion` em texto "0x0450000000000000" ou numero; PS4
  `SYSTEM_VER`, inteiro fmt 0x0404; BCD dos 32 bits de cima -> "4.50"; `param_fw_texto`) e `version_uri` (PS5
  `versionJsonUri`, so `https://sgst.prod.dl.playstation.net/` + `[A-Za-z0-9/._-]`, sem `..`, ate 199). `/api/local`
  devolve `versao` e `fw_local`.
- `src/versoes.c` (novo): `GET /api/versoes` (leitura livre) = `{fw_console, jogos:[{titleId, nome, plataforma,
  versao_local, fw_local, versionJsonUri (so PS5), caminho}], resultados:[...]}`; jogos = imagens
  (.pkg/.exfat/.ffpkg/.ffpfs/.ffpfsc/.ufs2) e pastas de jogo das pastas da lista, sem downloads em andamento e sem pastas
  dentro de `<disco>/BACKUP` (jogo_local, com o cache dele). `?resultados=1` = sem reler as pastas (a pagina usa).
  `POST /api/versoes` (X-GLR + pareamento, na lista `rota_protegida`): corpo JSON `{"resultados":[{titleId,
  versao_nova, fw_exigido, tamanho, consultado_em (segundos UTC; ausente = agora), erro, outra_versao, outro_fw}]}`;
  valida titleId (4 letras + 5 digitos), versao (digitos e pontos) e firmware ("14.20"); item invalido conta em
  `recusados`; o mesmo titleId troca o anterior. Guardado em `<dados>/versoes.json` (`/data/GameLibraryRenamer`; .tmp +
  rename; ate 3000). Firmware do console = `payloads_firmware` (kernel_get_fw_version; PC: `GLR_TESTE_FW`).
- Pagina: abaixo da pasta, "Versao 01.000.002 · pede firmware 10.40"; com resultado mais novo que a versao local
  "⬆ Existe 02.000.003 (pede firmware 14.20)" (+ "tambem X (pede firmware Y)" quando o 2o pacote, de pre-download, e
  diferente), em vermelho com "Firmware maior que o deste PS5 (12.00)" quando passa o firmware do console; resultado igual
  = "✓ Em dia com a Sony"; sempre "consultado em DD/MM HH:MM". Sem dado: so a versao local. Original no BACKUP nao conta.
  Filtro "⬆ Com atualizacao" na barra de filtros (so aparece com algum resultado). Textos pt/en/es.
- Nenhum host da Sony nas listas `HOSTS` (https.c) e `ROBUSTOS` (dns_resolver.c, que ja recusa playstation.net);
  versoes.c nao abre conexao. Conferido em teste.
- Testes no PC: `testes/teste_versoes.sh` (+ `gerar_sfo.py`, `teste_versoes_pagina.mjs` em 360x780, 780x360 e 1280x800).

## 0.9.36-teste (18/11/2026): o original vai para <disco>/BACKUP/<jogo>/ depois de converter
- `src/backup.c` (novo): conversao pronta ("feito" no Dump Forge) e saida conferida (existe; arquivo > 0 bytes; pasta de
  jogo com eboot.bin + sce_sys) = o original vai para `<disco>/BACKUP/<jogo>/` por `rename` (mesmo disco; EXDEV = falha,
  nada copiado). `<disco>` = /data, /mnt/usbN ou /mnt/extN (outro lugar = "disco desconhecido", o original fica). Vale
  para imagens, .pkg, pastas de jogo e compactados; RAR em volumes vai inteiro (`x.partN.rar`; `x.rar` + `x.r00`..`x.z99`).
  Falhou no meio: os volumes ja movidos voltam.
- Compativel com a Jobe (app/state/exfat-convert.js e app/native/bg_convert.c da glibren.73): nome da pasta = titulo seguro
  (safeFolderName: tira `\x00-\x1f / \ : * ? " < > |`, junta espacos, sem ponto/espaco nas pontas, ate 96; vazio =
  "Jogo"; nunca `_temp`, a pasta de extracao que a Jobe limpa); ja usada = " (2)".." (99)"; marcador `.jobe-backup.json` =
  `{"titleId","platform","format","source":"glibren"}` (format: exfat/ffpkg/ffpfs/ffpfsc/pkg/rar/7z/zip; pasta = "").
  O titulo e o Title ID saem de dentro da conversao (jogo_local; o original pode ser um compactado); senao o nome do
  original sem extensao e o PPSA/CUSA dele.
- ShadowMount+/ShadowKraken (`apps_smp_pedir`, API 127.0.0.1:10101 do config.ini dele): antes de mover imagem/pasta/.pkg,
  `POST /api/v1/games`; o original na lista e montado = `POST /api/v1/games/unmount {title_id}` (o SMP recusa com o jogo
  aberto: `game_active`) e so entao o rename. Recusou, imagem presa sem jogo (`/api/v1/images` mapped/mounted), lista
  ilegivel ou processo `shadowmountplus.elf` rodando sem a API responder = "adiado": o original fica e a tela avisa "mova
  depois" com o botao "Mover agora" (`POST /api/conversao/backup {id}`, mesmas conferencias; vale tambem com a chave
  desligada). Sem o SMP rodando, move. Depois de mover (ou de desmontar e falhar), `POST /api/v1/scan
  {"reset_attempts":false}`: a conversao nova monta no lugar. zip/7z/rar nao sao montados: nao pergunta.
- Por que o SMP nao monta o BACKUP (conferido em /root/forks/shadowkraken, 1.00-Dev.4): raizes padrao `<disco>/homebrew`,
  `<disco>/etaHEN/games` e a raiz dos externos (sm_paths.h); `DEFAULT_SCAN_DEPTH 1u`, `MAX_SCAN_DEPTH 2u` (sm_limits.h);
  `sm_scan_tree_walk` so chama on_directory na pasta do ultimo nivel e so ve imagens como arquivo dentro de pastas que
  percorre. Da raiz: `BACKUP` (1) nao tem eboot.bin; `BACKUP/<jogo>` (2, so com scan_depth 2) tambem nao (o original
  fica DENTRO dela); `BACKUP/<jogo>/<original>` (3) nunca e visitado. /data nao e raiz de varredura. Risco que fica: um
  `scanpath` personalizado apontando para dentro do BACKUP (configuracao do usuario no SMP).
- `conversao.c`: estado do original por conversao (`backup`: esperando, movendo, movido, adiado, falhou, desligado +
  `bk_chave`/`bk_detalhe`/`bk_pasta` no `GET /api/conversao`); um trabalho so move, um por vez, fora da trava; outra
  conversao do mesmo original ainda rodando = espera; a 2a conversao do mesmo original ja movido fica "movido" (mesma
  pasta). Vigia: com a pagina fechada, consulta o Dump Forge a cada 5 s enquanto houver conversao andando (testes:
  `GLR_TESTE_CONV_VIGIA_S`, 0 = sem). "Limpar terminadas" nao tira as que ainda vao mover.
- Opcao `convert_backup` (config.ini; sem a linha = on, `off` desliga), na janela Conversoes: "Mover o original para
  BACKUP depois de converter" (`POST /api/conversao/mover {ligado}`); vale a da hora em que a conversao termina.
- `json_min.c` (novo): o leitor JSON do conversao.c separado, agora com `\uXXXX` em UTF-8 (caminhos com acento do SMP).
- Lista: pasta da lista dentro de `<disco>/BACKUP` = itens com `"backup":true` (escanear) e a linha "original guardado no
  BACKUP: nao e um jogo a mais" (nao renomeia).
- Testes no PC: `testes/teste_conversao_backup.sh` (73 casos: imagem com a pagina fechada, imagem->pasta com nome de
  dentro, pasta, RAR .partN e .rNN, nome ja usado, marcador, falha/cancelada/saida vazia nao movem, montado com jogo
  aberto -> adiado -> Mover agora, montado sem jogo aberto, jogo nao montado com a imagem anexada, imagem presa, chave desligada, disco desconhecido, duas
  conversoes do mesmo original, SMP mudo, compactado com SMP mudo, rotas protegidas, marca na lista) com
  `testes/smp_falso.py` (games/images/unmount/scan, `\/` e `\uXXXX` como o json-c) e o `dumpforge_falso.py` criando a
  saida (`<pasta>/cria`); `GLR_TESTE_RAIZES`; teste_conversao.sh + pagina 360/1280 (chave ligada por padrao, grava,
  "Mover agora" largura inteira, motivo na tela, sem rolar de lado).

## 0.9.35-teste (18/11/2026): ZhiThemes na pagina Payloads + atalho para o GitHub em cada item
- Item novo ZhiThemes (itsRealZhi/ZhiThemes, GPL-3.0, autor Zhi; temas na tela inicial real do PS5). So tem pre-release
  (v0.1.0-alpha): `gh_pre = 1`; padrao `ZhiThemes.elf` (o `ZhiThemes-themes.zip` da release fica de fora; o texto do item
  manda pegar na release); max 24 MB; firmwares do autor 9.00 a 13.60 (`9.xx ... 13.xx`).
- `shellui = 1`: injeta um modulo na SceShellUI (so na memoria; grava so em /data/ZhiThemes/), entao bloqueia/fica
  bloqueado pela tela cheia do navegador e pelo PrefBar na mesma sessao. `uma_vez = 0`: mandar de novo troca a copia que
  esta rodando sem reiniciar (o payload novo pede `POST /quit` ao modulo velho e mata o vigia antigo; main.cpp do autor).
- Sonda `SONDA_ZHITHEMES`: `GET 127.0.0.1:4444/version` (texto, sem efeito colateral; theme_web.cpp do autor) responde
  `zhithemes <versao> (build ...) ...` = rodando, com a versao (2a palavra). Um tema do OnionHEN responde `onionhen ...` e
  nao conta. O editor na 4444 escuta em todas as interfaces e nao tem senha (avisado no item). Parar: nao ha rota
  segura para isso (o `POST /quit` tira o tema mas o vigia continua); o texto manda reiniciar o PS5 sem mandar o payload
  (volta ao normal) ou escolher "PS5 default" no editor/Opcoes para desligar so o tema.
- `web/payloads.html`: cada item com repositorio no GitHub ganha o atalho "Pagina do projeto no GitHub (dono/repo)"
  (`a.gh-pag`, nova aba, `rel=noopener`), como o ps5-payload-manager; repositorio removido (ShadowKraken) fica sem.
- Testes no PC: `GLR_TESTE_ZHITHEMES_PORTA`; `github_falso.py` com papel `zhithemes` (`<pasta>/zhithemes_versao`);
  `teste_payloads_gh.sh` (pre-release, so o .elf, instalar, ativar, rodando com a versao, tema do OnionHEN nao conta,
  bloqueia o PrefBar, ativar de novo = troca) + pagina 360/1280 (rodando com versao, link do GitHub em cada item).

## 0.9.34-teste (17/11/2026): repositorio 404 + ShadowKraken removido + BlueV + motivo "criar area" nas cheats
- `github_rel.c`: `GH_REPO_SUMIU` (-8). Lista de releases 404/410/451 = sumiu; `/releases/latest` 404 pergunta
  `/repos/<r>` (1 pedido a mais, so nesse caso): 404 = sumiu, senao "sem release".
- `payloads.c`: repo sumido vale como resposta definitiva com cache de 24 h (`GH_CACHE_SUMIU_S`; o botao ainda pode
  forcar, 1x/min); `gh.erro = "repo_indisponivel"`. Campo `removido_em` no item (ShadowKraken = "17/11/2026"): nao
  consulta nem instala; sem nada guardado o item sai do JSON; guardado fica com Ativar/Voltar e o botao novo
  "Remover do glibren" (`POST /api/payloads/remover`, pareado + X-GLR: apaga .elf/.info/.anterior.*/.ativado; nao fecha
  o que esta rodando). "Rodando agora" do ShadowKraken continua pela API do SMP.
- Item novo BlueV (0xZ3n0x/BlueV, GPL-3.0, asset `bluev.elf`, o `.sha256` da release nao casa; max 16 MB; uma_vez).
  Sonda `SONDA_BLUEV`: GET 127.0.0.1:7733/api/status com "state" = rodando (a API nao tem versao).
- `cheats.c`: `cave_ok` com pagina inexistente (`prot_memoria` < 0) = `area_extra_criar` (pagina: `m_criar`, "Esta cheat
  precisa criar uma area nova no jogo; o glibren nao faz isso. Use o onionHEN para ela."); leitura que falha numa area
  que existe continua `area_extra_ilegivel` (texto novo: "existe, mas a leitura dela falhou"). Nada de criar area.
- Testes no PC: `GLR_TESTE_SEM_REMOVIDOS=1` (instalar o SK antes), `GLR_TESTE_GH_CACHE_S` (cache de 1 h/botao em
  segundos), `GLR_TESTE_BLUEV_PORTA`; `github_falso.py` com `<pasta>/sumidos`, `/repos/<r>` e papel `bluev`.

## 0.9.33-teste (16/11/2026): payloads acompanhados pelo GitHub + "rodando agora" + versao na notificacao
Pedido do dono: instalar e ATUALIZAR payloads que o ps5-payload-manager nao atualiza (Dump Forge, kraken-mount,
ShadowKraken); mostrar se cada payload ja esta carregado; versao na notificacao de inicio.
- `src/github_rel.c` (novo): `gh_consultar` (GET api.github.com/repos/<r>/releases/latest, ou `/releases?per_page=5` e a
  1a sem rascunho para quem aceita pre-release), leitor JSON minimo (tag_name, prerelease, draft, published_at, assets
  name/size/digest), asset UNICO que casa com o padrao (`*`), digest "sha256:<64 hex>". Limite proprio 30 pedidos/h
  (anel) e pausa de 30 min depois de 403/429 (`gh_bloqueado_ate`). `api.github.com` entrou na lista de hosts do https.c
  (so GET, sem token). PC: `GLR_TESTE_GH` (API e downloads no servidor falso).
- `src/payloads.c`: `item_t` ganhou `sonda`, `gh_repo/gh_padrao/gh_pre/gh_max`, `aviso_smp`. Itens dump-forge (antes fixo
  v0.5.6), kraken-mount e shadowkraken (pre-release); tambem web-browser-fullscreen (padrao
  `web-browser-fullscreen-*.elf`: tira o "restore"; a release "test" e pre-release) e prefbar (`*.elf`: o nome muda a
  cada versao, 1 .elf por release), antes fixos; o que tinham de especial continua (tela cheia pelo navegador do PS5 +
  reabrir; prefbar.conf). Tabela `LEGADOS`: arquivo antigo com o SHA fixo de antes vira a versao instalada. Arquivos em /data/glibren/payloads: `<id>.elf` + `<id>.info`
  (versao/sha256/tamanho/asset), `<id>.anterior.elf/.info`. `instalar_gh`: consulta se o cache tem mais de 1 h, recusa sem
  digest/grande/sem asset/varios assets, baixa para `.tmp` (limite = tamanho do asset), confere o SHA-256 com o digest,
  guarda a atual (conferida) como anterior e faz rename. `voltar`: confere a anterior pelo SHA dela e troca as duas.
  Migracao: o `ps5-dump-forge-0.5.6-ps5.elf` da 0.9.30 vira a v0.5.6 instalada se bater com o SHA fixo de antes.
  Rotas: POST /api/payloads/procurar (forcar=0 ao abrir a pagina: so cache > 1 h; forcar=1 = botao, 1x/min por item;
  numa thread, com "consultando" marcado antes), POST /api/payloads/voltar (mesmas regras do baixar). Ativar
  kraken-mount/ShadowKraken exige `confirmo=1` (409 `payload_confirmar_smp`), nunca derruba o SMP.
  "Rodando agora" (cache 8 s; PC `GLR_TESTE_SONDA_S`): Dump Forge `GET :8095/api/session` (version); kraken-mount
  `GET :8097/api/state` (ULTIMA "version" e "waiting": o serde_json ordena as chaves); ShadowKraken/SMP
  `apps_smp_versao` (POST /api/v1/version, endereco do config.ini do SMP) + processo `shadowmountplus.elf`
  (`plataforma_processo_rodando`, ki_tdname). Os dois usam o MESMO nome de processo e a mesma API; versao com "-Dev" =
  ShadowKraken. O ShadowKraken, ao subir, manda SIGTERM na copia que estiver rodando (SMP ou ele) e fica no lugar.
  JSON: `gh{...}`, `rodando`, `rodando_versao`, `rodando_obs`, `versao_diferente`, `aviso_smp`, `total`; topo `smp{}` e
  `gh_bloqueado_ate`. `.ativado` so guarda o pid da ShellUI nos itens `shellui`.
- `web/payloads.html`: cartao do topo (ShadowMount+ rodando? + "Procurar atualizacoes" + ultima consulta/limite);
  por item: Instalada x No GitHub, selo EXPERIMENTAL, Instalar/Atualizar/Atualizado, "Voltar para vX", linha "Rodando
  agora (vX)" / "Nao carregado agora" / versao diferente; confirmacao do SMP. pt-BR/en/es.
- `src/main.c`: notificacao "Game Library Renamer <VERSAO>
abra http://IP:8765" (tambem na copia nova depois de atualizar).
- Testes: `testes/teste_payloads_gh.sh` (GitHub falso `testes/github_falso.py` + kraken/SMP falsos + Dump Forge falso +
  elfldr falso) e `testes/teste_payloads_pagina.mjs` (360 e 1280 px). Adiado: lista local de repositorios do dono.
- 🖥️ so PC.


## 0.9.32-teste (16/11/2026): cheats de area extra em pagina "--x" ligam
Pedido do dono (16/11/2026): as cheats com area extra em pagina so execucao ("--x", Terminator 2D) devem ligar, como
no onionHEN. No PS5 o codigo do eboot e execute-only (XOM); o glibren le e grava pelo kernel (copyout/copyin = mdbg ou
DMAP), que ignora a protecao de usuario.
- `src/cheats.c` (`cave_ok`): com a chave "Area extra (teste)" ligada, pagina com PROT_X sem PROT_L e aceita se a
  leitura pelo kernel dos bytes da area funcionar e der exatamente zeros (senao `area_extra_ilegivel` /
  `area_extra_nao_zerada`); `area_extra_nao_exec` e `area_extra_fora` continuam. `area_extra_sem_leitura` nao sai mais.
  Ordem (area, depois salto; desligar ao contrario), leitura de volta e desfazer: iguais. Nada de criar area.
  Teste no PC: `GLR_TESTE_CHEATS_FALHAR_LER=<endereco>` faz a leitura falhar.
- `web/cheats.html`: linha "area extra so execucao (--x): liga e desliga gravando pelo kernel, como o onionHEN
  (teste)" (pt-BR/en/es) nas cheats que usam area "--x" e podem ligar.
- Testes: `teste_cheats.sh` (--x com zeros liga, grava a area antes, desliga e volta aos zeros; --x ilegivel recusa).

## 0.9.31-teste (16/11/2026): pastas de jogo e compactados na lista + nivel no "Outro formato"
Pedido do dono (16/11/2026): a lista mostra tambem pastas de jogo e compactados para entrarem no Converter; no "Outro
formato", escolher o nivel depois do formato.
- `src/arquivos.c`: `/api/escanear` devolve tambem pastas de jogo (`"tipo":"pasta"`, sem tamanho) = pasta com
  `eboot.bin` e `sce_sys/param.json` (PS5) ou `sce_sys/param.sfo` (PS4), a regra do ShadowMount+ para pasta;
  `arquivos_pasta_de_jogo()` novo. Outras pastas continuam fora.
- `src/jogo_local.c`: `/api/local` le nome/Title ID/icone de dentro da pasta de jogo (leitor `pasta_ler`, formato
  "pasta"); guardado pela data/tamanho do param.
- `src/conversao.c`: origem pasta so se for pasta de jogo; RAR em volumes so o `.part1.rar` (saida sem ".part1");
  `.part2.rar` em diante = origem_invalida.
- `web/index.html`: compactados .zip/.7z/.rar entram na lista (so o 1o volume; .r00/.z01/.7z.001 e os outros tipos
  continuam fora); caixas "pasta" e "zip/7z/rar" no filtro por formato. Pasta de jogo e compactado: nunca renomeiam
  (motivo na linha: "so Converter e Ocultar"), sem botao Ativar, ficam fora de Copiar/Mover/Excluir (contador so dos
  arquivos, botao desligado com dica e aviso de quantos ficaram de fora). Para pasta o servidor tambem recusa (renomear
  e copiar/mover/excluir so aceitam arquivo comum). "Outro formato": formato com nivel (zstd, LZ4, zlib, Kraken) abre a
  escolha do nivel (avancado, "Padrao (recomendado)" primeiro; no formato padrao vem o nivel da opcao geral) com
  "Converter para <formato>" e "Voltar" lado a lado; formato sem nivel converte direto. Textos pt-BR/en/es.
- Testes: `teste_conversao.sh` (lista com pastas/compactados, /api/local de pasta, renomear/excluir pasta recusados,
  origem pasta PS4, rar 1o/2o volume, 7z com zstd) e `teste_conversao_pagina.mjs` (caixas pasta/compactado, so o 1o
  volume, motivos, botoes de lote, escolha do nivel com 2 botoes da mesma largura, converter com zstd 19, 360/1280 px).

## 0.9.30-teste (16/11/2026): converter formato pelo Dump Forge
Pedido do dono (16/11/2026): opcao geral de conversao (formato padrao), filtro por tipo, selecionar e Converter com a
pergunta de 3 escolhas; usar os metodos de compressao mais novos. Motor decidido pelo dono: ps5-dump-forge (quer3q,
GPL-3.0) rodando no PS5, API local em 127.0.0.1:8095 (contrato lido na tag v0.5.6: `POST /api/start_job
{"request": ConvertRequest}`, `GET /api/jobs`, `POST /api/cancel_job`, `GET /api/session`). Nenhum codigo Rust copiado.
- `src/conversao.c` (novo): GET /api/conversao (estado, leitura livre), POST /api/conversao (formato, nivel, pasta[],
  de[]), /cancelar, /limpar, /padrao (pareamento + X-GLR). Formatos: exfat, ffpkg, ffpfs, ffpfsc, pkg, pasta,
  pasta_zstd, pasta_lz4, exfat_zstd, ffpkg_zstd, ffpfs_zstd, ffpfsc_zstd (ids combinados com a Jobe). Nivel opcional
  (vazio = padrao do Dump Forge): Kraken fast/balanced/smallest/stored, zstd 1-22, zlib 0-9 (.ffpfsc), LZ4 0/3-12.
  Saida ao lado da origem; delete_source sempre falso; recusa mesmo formato, destino existente ou em uso, fora das
  pastas, origem que o Dump Forge nao aceita. Estado pelo /api/jobs (leitor JSON minimo); trabalho que some = "perdido".
  O glibren nao pede varredura ao ShadowMount+ (nao faz isso em lugar nenhum; o SMP acha as imagens novas sozinho).
- `src/config.c`: `convert_format` / `convert_level` no config.ini; `conv_formato`/`conv_nivel` no /api/estado.
- `src/payloads.c`: item "dump-forge" (v0.5.6, ps5-dump-forge-0.5.6-ps5.elf, 18.549.840 B, sha256 f0415aab...,
  baixado e conferido em 16/11/2026); "rodando" = a porta 8095 responde.
- `web/index.html`: caixas de formato ffpkg/ffpfs/ffpfsc no filtro (quebram a linha no celular), botao "🔁 Converter
  (n)" (sem marcados vira "🔁 Conversoes" e abre a janela da opcao geral/andamento), pergunta com 3 botoes da mesma
  largura lado a lado, lista "Outro formato" com uma linha de ganho/perda. Textos pt-BR/en/es.
- Testes: `testes/teste_conversao.sh` + `testes/dumpforge_falso.py` (ok/erro/recusa/cancelar/ausente/fechou no meio,
  niveis, recusas, opcao geral, item Payloads) e `testes/teste_conversao_pagina.mjs` (Playwright do Windows: filtro,
  dialogo, larguras, sem rolar de lado em 360 px e 1280 px).

## 0.9.29-teste (15/11/2026): botao Internet (navegar)
Pedido do dono (15/11/2026): um botao para abrir um navegador completo e navegar na internet.
- `src/payloads.c`: destino fixo `internet` (porta -1 = endereco inteiro) -> https://www.google.com/ pelo
  POST /api/navegador/abrir (mesmas regras: pareado, nao no navegador do PS5, recusa com jogo aberto, volta a tela
  inicial antes). Continua sem URL vinda do pedido.
- `web/index.html`: 4o botao "🌍 Internet (Google)" no dialogo (grade 2x2, mesma largura) e atalho "🌍 Navegar" na
  tela principal so no navegador do PS5 (que nao tem barra de endereco). Textos pt-BR/en/es.
- `testes/teste_navegador.sh`: destino internet (28 ok).

## 0.9.28-teste (15/11/2026): ordem padrao "renomear primeiro"
Pedido do dono (14/11/2026): sem ordenacao escolhida, o que precisa renomear fica em cima.
- `web/index.html` (renderizarFtp): ordem padrao em 3 grupos, cada um na ordem das pastas: (0) pronto, conflito,
  falhou ao renomear; (1) neutro (patch, sem codigo, baixando), consultando, nao encontrado; (2) nome ja certo, em
  ordem alfabetica (como antes). Ordenacao escolhida (Nome/Tamanho/Extensao) continua mandando; a ordem segue
  parada depois do Ler pastas. Mesma regra no app de PC 1.2.

## 0.9.26-teste (13/11/2026): cheats .xml com escrita, padroes e resumo certo com area "--x"
Bug do PS5 real (dono, 13/11/2026, Terminator 2D com "Area extra (teste)" ligada): Easy Score e 10x Score mostravam
"area extra: --x" (pagina so execucao) e o resumo dizia "cheats: 5 podem ligar, 0 ainda nao".
- **Resumo e linha da cheat**: `cave_ok` agora exige leitura (PROT_L) antes de execucao; sem leitura =
  `area_extra_sem_leitura` (conta em `nao_suportadas`). A pagina mostra na propria linha "nao da para ligar: a area do
  jogo e so execucao (--x)" (outra protecao sem leitura: "nao tem leitura (...)"), pt-BR/en/es, quebra linha sem
  reticencias, e o interruptor fica desativado.
- **.xml (Illusion) com escrita**: `xml_resolver` resolve os trechos na hora (endereco direto = base + offset; `mask` =
  padrao achado EXATAMENTE uma vez + Offset; ambiguo/ausente/sem faixas seguem "nao suportada"). `mask_jump32` como o
  onionHEN (Value na area achada pelo Target, jmp de volta logo depois, jmp E9 + NOPs no lugar do padrao), so com a
  opcao da area extra ligada e se a area passar nas mesmas regras da area extra (existe, r-x, dentro do modulo) e
  estiver zerada nos bytes gravados (`area_extra_nao_zerada`, `_ausente`, `_ambigua`, `salto_longe`). Obs.: os 11
  `mask_jump32` reais do Illusion usam Target de NOPs (90) ou texto, entao ficam "nao suportada" por essa regra.
- Ligar o .xml: le e guarda os ORIGINAIS (memoria + `aplicadas.json` com `"fonte":"xml"`, off = original), grava, le
  de volta; desligar exige os bytes atuais = on e devolve os originais conferindo. Mesmo motor da Fase 1 (g_trava_mem,
  desfaz parcial, restaura ao fechar, recusa com pid/app mudado, recusa sobreposicao). Cheat .xml ligada pelo glibren
  continua "suportada" mesmo se o padrao sumir (o desligar usa os enderecos guardados).
- **Testes** (`testes/teste_cheats.sh`): .xml com padrao unico + endereco direto liga/desliga com a memoria identica e
  os originais em `aplicadas.json`; ambiguo/ausente recusados; sobreposicao; pid mudado = perdida (nada gravado nos
  dois jogos); restaurado ao fechar; mask_jump32 recusado com a opcao off e com area invalida; pagina `--x` do alvo
  (`mprotect(PROT_EXEC)`) = `area_extra_sem_leitura`, resumo bate com os estados, nada gravado; simbolos seguem sem
  ptrace/mmap/mprotect.

## 0.9.25-teste (13/11/2026): chave "Area extra (teste)" na pagina Cheats
Pedido do dono: ligar o modo de teste da area extra (code cave) pelo celular, sem editar o `config.ini` no PC.
- **Rota** `POST /api/cheats/area-extra` com `{"ligado":true|false}` (ou `ligado=1|0`): pareamento + X-GLR
  (`rota_protegida`), recusada no navegador do PS5 e de 127.0.0.1 (`cheats_so_celular`, 403), como ligar/desligar.
  Grava `cheats_area_extra = on` (ou tira a linha) pelo mesmo `gravar_arquivo()` atomico do `config.c` (arquivo .tmp +
  fsync + rename; se falhar, o valor antigo volta: `cheats_config`). Vale na hora, sem reiniciar. O `GET /api/cheats`
  ja informava o estado em `area_extra_teste`.
- **Desligar com cheat de area extra ligada: RECUSADO** (`cheats_area_extra_em_uso`, `params.nomes` e `qtd`), em vez
  de desligar as cheats sozinho. Motivo: uma chave de configuracao nunca escreve na memoria do jogo; desligar varias
  cheats de uma vez pode parar no meio (dependencias, bytes mudados) e deixar um estado que a pessoa nao viu. A pessoa
  desliga cada cheat (vendo o resultado) e depois a chave. Contam as ligadas pelo glibren com trecho de "off" todo zero
  ou que saltam para a area extra de outra (`ndep`); cheats perdidas (jogo fechou/mudou) saem antes (`ap_conferir`).
  Tudo sob `g_trava_mem`: nenhuma cheat liga entre a conferencia e a gravacao.
- **Pagina** (`web/cheats.html`): no fim da lista (rola junto com ela, nao tira altura), cartao "⚗️ Area extra
  (teste)" com interruptor da mesma largura dos outros e o aviso "Deixa ligar cheats que usam uma area vazia do proprio
  jogo. So funciona se o trecho aparecer como r-x. Salve o jogo antes." (pt-BR, en, es). Com o modo ligado, o `prot`
  de cada area extra aparece na linha da cheat ("area extra: r-x") e no detalhe de cada trecho; o motivo quando nao da
  continua (`area_extra_nao_exec`, `_ilegivel`, `_fora`). Conferido em 360x780, 412x915, 780x360, 1280x800 e 1540x700
  (sem rolagem da pagina, sem rolagem lateral, interruptores com a mesma largura).
- **Testes** (`testes/teste_cheats.sh`, 273 ok): rota sem token 401, sem X-GLR 403, 127.0.0.1 e PS5 403, corpo ruim
  400, recusas nao gravam, liga/desliga persistem no `config.ini` depois de reiniciar, desligar com "Cave executavel" e
  "Usa a cave" ligadas e recusado com os dois nomes (config e memoria do jogo intactas) e, sem cheats, desliga.

## 0.9.24-teste (13/11/2026): atualizacao pelo commit fixo (cache do raw do GitHub) e abrir o navegador do PS5 pelo celular
Bug visto no PS5 real (dono, 13/11/2026): atualizar para a 0.9.23 pelo botao da versao deu "a versao baixada
(0.9.22-teste) nao e a anunciada (0.9.23-teste)". O CDN do `raw.githubusercontent.com` guarda cada arquivo do `main`
em cache separadamente por alguns minutos; logo depois de duas publicacoes seguidas (0.9.22 e 0.9.23) o `versao.json`
ja vinha novo e o `glibren.elf` ainda velho. A conferencia do marcador recusou (certo); minutos depois o servidor
ficou consistente.
- **Updater** (`src/atualizacao.c`): o `versao.json` agora traz `commit` = commit do repositorio PUBLICO que contem o
  `.elf` e a `.sig` daquela versao (antes era o commit do fonte, que virou `commit_fonte`). O PS5 baixa de
  `raw.githubusercontent.com/pristmc-code/ps5-glibren-releases/<commit>/glibren.elf` (+ `.sig`), endereco imutavel.
  Mesmo host, entao a lista de sites permitidos e o DNS robusto valem igual; o commit so entra no endereco se for
  exatamente 40 hex minusculos. Sem `commit` valido, ou se o endereco fixo falhar (rede/404/divergencia), usa o `main`
  como antes. Ordem da conferencia: tamanho e sha256 anunciados -> assinatura -> marcador. Pelo `main`, se algo nao
  bate, tenta de novo uma vez depois de 8 s. Mensagem nova: "o servidor de versoes ainda esta se atualizando (veio a X,
  anunciada a Y): tente de novo em alguns minutos" (traduzida na pagina). Assinatura invalida no commit fixo recusa
  na hora (arquivo imutavel: nao e cache).
- **Publicacao** (`tools/publicar_versao.py`): faz DOIS commits no repositorio publico: (a) `.elf`, `.sig` e zip do
  fonte, conferindo com `git show` que o commit tem os bytes novos; (b) `versao.json` com `commit` = hash de (a). O
  `versao.json` nunca aponta para um commit com o `.elf` velho. `--titulo`/`--rodape` para as mensagens; os testes
  rodam com `flock /tmp/ps5-testes.lock`. O push continua manual (os dois commits vao juntos).
- **Abrir no navegador do PS5** (pedido do dono: o PS5 nao tem o app de navegador na tela, so abre pelo icone do
  glibren na aba Midia): (1) na tela principal aberta no navegador do PS5, atalhos "🌐 Jobe web"
  (`http://127.0.0.1:34201/app`) e "🧪 Jobe /teste" na barra de cima (escondidos fora do PS5); (2) no celular, em Apps,
  "🌐 Abrir no navegador do PS5" com Jobe web / Jobe /teste / glibren (tres botoes da mesma largura). Rota
  `POST /api/navegador/abrir` (`destino` = `jobe`, `jobe_teste`, `glibren`, `glibren_payloads`; lista FIXA em
  `src/payloads.c`, nada de URL vinda do pedido), pareamento + X-GLR (`rota_protegida`), recusa o navegador do PS5 e
  127.0.0.1 (`navegador_so_celular`), recusa com jogo/app aberto (`navegador_jogo_aberto`) e um pedido por vez junto
  com os payloads de teste (`payload_ocupado`). Mesmo mecanismo do item de tela cheia: tela inicial
  (`pshomeui:navigateToHome`), 1 s, `sceSystemServiceLaunchWebBrowser`. ❓ no PS5. Teste novo `teste_navegador.sh` (26).
- **Quem esta na 0.9.23 ou antes** ainda usa o updater antigo (so `main`): se aparecer "nao e a anunciada", basta
  tentar de novo depois de alguns minutos, quando o cache do GitHub se resolve. Da 0.9.24 em diante nao acontece.
- **Testes**: `teste_atualizacao.sh` +commit fixo com `main` velho (atualiza pelo commit, nem toca no main), commit
  404 cai no main, sem commit com sha diferente (2 tentativas + mensagem clara + nada gravado), cache que se resolve
  antes da 2a tentativa, commit invalido ignorado.

## 0.9.23-teste (13/11/2026): cheats Fase 2 (.shn, .mc4, .xml), diagnostico mais robusto, tela cheia confirmada no 12.00
Liberada pelo teste da Fase 1 no PS5 real (dono, 13/11/2026: "Cheats funcionou perfeitamente", ligar/desligar pelo
celular no PS5 PRO 12.00 = ✅). A Fase 2 e 🖥️ so PC / ❓ no PS5. Detalhes e decisoes em `ps5/ESTUDO-cheats-onionhen.md`
(secao "Fase 2").
- **Cheats Fase 2** (`src/cheats.c`, `src/config.c`, `src/main.c`, `web/cheats.html`): parsers proprios de XML,
  Base64 e AES-256-CBC (so decifrar) para `.shn` e `.mc4`; `.xml` do Illusion so leitura (`mask`/`mask_jump32` com
  busca unica do padrao nas faixas do modulo: achado 0 ou 2+ vezes = nao suportada); catalogo guarda `json/`, `shn/`
  e `mc4/`; prioridade json > shn > mc4 > xml e repetidos em outro formato saem (`ignorados`); `.shn`/`.mc4` ligam e
  desligam com o mesmo motor da 0.9.18; `<StartUP>` e saltos rel32 para a area extra de outra cheat viram
  dependencias; area extra so a que ja existe, em pagina executavel, com `cheats_area_extra = on` (padrao off; nunca
  cria area). `glibren-pc --teste-cheat` e `testes/cheats_reais.py` (todos os arquivos reais, 0 divergencias).
- **Diagnostico** (achados do 1o diagnostico real, `ps5/ANALISE-DIAGNOSTICO-2026-11-13.md`): (a) o sha256 PUBLICO do
  `payloads.json` saia como `[segredo]` pela regra 6 (token solto hex 32+). Excecao nova: hex de 40/64 digitos logo
  depois de `sha256`/`sha1`/`sha`/`commit` (com `:`/`=`/espaco, com ou sem aspas) fica; a regra 1 (segredos
  conhecidos, ex.: hash de aparelho pareado) continua vencendo. (b) o envio parava no 1o PUT que falhava (a Jobe teve
  HTTP 0 em 1 de 10). Agora cada PUT tenta ate 3 vezes (rede/HTTP 0, 408, 429, 5xx; espera 1 s e 2 s); o arquivo que
  nao subir vai para `faltaram` e o envio segue; 401/403/404 ou 2 arquivos seguidos sem subir param a rodada (o resto
  tambem falta). `GET /api/diagnostico` ganha `faltaram`; a pagina mostra "Subiram X de Y; faltaram: ..."; diario
  `diagnostico: N nova(s) tentativa(s)` e `...; faltaram: ...`.
- **Tela cheia do navegador** (`src/payloads.c`): o dono testou a v0.1b no PS5 Pro 12.00 em 13/11/2026 ("funcionou
  perfeito e desativou quando reiniciei"). Item ganha `confirmados` = "12.00" e `confirmado_em` = "PS5 Pro, 13/11/2026";
  o JSON ganha `confirmado_no_seu` e o 12.00 conta como `testado_no_seu`. A pagina mostra "testado (confirmado por nos
  no PS5 Pro, 13/11/2026)" em vez de "nao testado no seu firmware". O PrefBar continua so na faixa do autor.
- **Testes**: `teste_cheats.sh` com a Fase 2; `teste_diagnostico.sh` +hashes publicos, hash solto, segredo conhecido
  com nome publico, GitHub instavel (502 na 1a tentativa de cada arquivo), um arquivo com 500 e sem internet;
  `teste_payloads.sh` +12.00 confirmado.

## 0.9.22-teste (13/11/2026): PrefBar nos payloads de teste e numeros novos (MHz, RAM/VRAM, nucleos, 1% low)
Pedido do dono ("os 2"), a partir de `ps5/ANALISE-PrefBar.md`. Nada testado no PS5 (🖥️ so PC).
- **PrefBar** (X1NONs, GPL-3.0) no catalogo fixo de `src/payloads.c`: v0.3.0, `Prefbar_V0.3.0.elf`, 964.272 B, sha256
  `e4379590115ef87b2f0310b502321d7da30783536d939bfb1c4c0e511972af30` (baixado e calculado por nos = digest do GitHub).
  Firmwares do autor "7.xx ... 13.xx" (a lista aceita `NN.xx`; `faixa_do_autor` no JSON: a tela diz "na faixa que o
  autor diz suportar, sem teste confirmado", nunca "testado"). Avisos fixos: ~2 min depois de ligar; nao usar junto com
  a tela cheia; nao testado no PS5 Pro 12.00. Desfazer: reiniciar o PS5 (apagar /data/prefbar limpa).
- **Ativar fora do jogo** (decisao): continua pareamento + X-GLR e recusa com jogo aberto. O README do PrefBar carrega
  o ELF e DEPOIS abre o jogo; o controlador espera o jogo (3 amostras) e a ShellUI estavel (10 amostras) antes de
  injetar. Ativar com o jogo aberto arrisca fechar o jogo sem salvar se a ShellUI travar. O PrefBar fica rodando e
  nao escreve nada quando da certo: `espera_s` = 4 s (so pega um erro do elfldr); sem "Result=" = ativado.
- **Exclusao mutua** (`shellui` = 1 nos dois itens): ativar um com o outro ativo nesta sessao = 409
  `payload_conflito`; PrefBar 2 vezes = 409 `payload_ja_ativo` (`uma_vez`). `.ativado` agora grava "hora pid_ShellUI";
  vale so se a hora e depois de `kern.boottime` (PS5; antes: relogio monotonico) e o pid da `SceShellUI` (KERN_PROC_PROC,
  ki_comm) e o mesmo. PrefBar iniciado por fora: arquivos de estado em /data/prefbar (controller.log, injector.log,
  status.txt, status.kv, debug.log) com data depois do boot = estado "rodando" e bloqueia a tela cheia. `ps5tela.js`
  mostra a mensagem do conflito.
- **Configuracao do PrefBar** (`src/prefbar.c`, `GET/POST /api/prefbar/conf`, POST em `rota_protegida`): 26 chaves com
  as faixas do `config_apply_value` da v0.3.0 (bool 0/1; overlay_x 0..1800, overlay_y 0..1000, overlay_font 10..96;
  opcoes exatas; cor `#RRGGBB`; overlay_corner 0 ou 2). Um valor ruim recusa o pedido inteiro (400) sem gravar; chave
  desconhecida tambem; controle/quebra de linha no valor = pedido invalido. Grava: le o arquivo (ate 64 KiB, nunca link),
  troca TODAS as ocorrencias das chaves editadas (no PrefBar a ultima vence), acrescenta as que faltam sob "# glibren",
  mantem comentarios/secoes/chaves desconhecidas; `.tmp` com O_EXCL|O_NOFOLLOW, fsync, rename, fsync da pasta. Aponta
  valores invalidos do arquivo e linha > 255 caracteres (o PrefBar recusa o arquivo inteiro). Tela: "⚙ Configurar a
  barra" no cartao do PrefBar (opcoes de cada linha com a mesma largura, sugestao do README, Desfazer, Gravar).
- **Numeros novos** (`src/desempenho.c`, ideia do PrefBar, codigo proprio): `sceKernelGetCpuFrequency` (Hz),
  `sceKernelGetSocClock` (dominio 20 = GPU MHz), `get_page_table_stats(1,1)` RAM e `(1,2)` VRAM em MB,
  `sceKernelGetCpuUsage` + `sceKernelGetThreadName` ("SceIdleCpuN", procurados ate 3 vezes) = uso por nucleo. Weak;
  sem o simbolo, procura por nome e por NID (`nid_encode`) em libkernel_sys.sprx/libkernel.sprx; diario
  `desempenho: funcoes: ...=fraco|nome|nid|ausente`. Todas pelo `sce_com_prazo` (800 ms); faixa invalida segura o ultimo
  bom 5 rodadas (10 s) e some. So le com pedido de /api/termico ou /api/fps nos ultimos 15 s (thread do sistema, 2 s).
  `sistema.nucleos` usa o uso por nucleo novo quando ha (`nucleos_fonte: "sce"`); RAM da Temperatura sem "≈" quando ha.
  JSON: `"desempenho":{"cpu_mhz","gpu_mhz","ram_mb":[usada,total]|-1,"vram_mb":...,"cpu","nucleos":[]}` em
  /api/termico e /api/fps.
- **1% low e pior quadro** (`src/fps.c`): entre as leituras de 250 ms o contador do /dev/dce e lido a cada ~2 ms;
  tempo de quadro = tempo desde a ultima mudanca / quadros andados; janela de 1000 quadros; 1% low = 1000 / media do 1%
  mais lento; buraco > 20 ms entre leituras zera (nao vira quadro lento falso); jogo novo zera. JSON `low1`, `pior_ms`,
  `quadros`. Teste no PC com `GLR_TESTE_FPS_PAUSA_MS` (contador parado a cada 3 s).
- **Telas**: Temperatura AVANCADO ganha uma linha CPU MHz | GPU MHz | VRAM (blocos iguais, somem sem leitura); FPS ganha
  2a linha da grade (1% low | pior quadro | CPU uso) e um cartao acima do grafico (CPU MHz | GPU MHz | RAM | VRAM +
  barras por nucleo; 2 por linha no celular estreito). Medido com Playwright (360x780, 412x915, 780x360, 1280x800 e
  1540x700 com UA do PS5; pt-BR/en/es): sem rolar de lado, fileiras com a mesma largura, nada com reticencias.
- **Testes**: `teste_payloads.sh` +PrefBar (sha errado, exclusao mutua, ShellUI reiniciada, rodando por fora, asset real
  na internet) = 103; `teste_desempenho.sh` novo (80: funcoes ausentes, VRAM absurda, watchdog, sem pedido nao le, 1% low,
  prefbar.conf validado e atomico).

## 0.9.21-teste (13/11/2026): Enviar diagnostico para o GitHub
Pedido do dono: mandar o diagnostico do glibren pelo celular, como a Jobe faz desde a .44 (modelo: `app/native/bg_diag.c`
da Jobe, reescrito em `src/diagnostico.c`).
- **Chave**: fine-grained PAT so de `pristmc-code/ps5-diagnosticos` (Contents read/write). Ordem: a colada no glibren
  (`/data/glibren/diag/token`, 0600, pasta 0700, gravada com O_EXCL + rename) e, sem ela, a da Jobe
  (`/data/JobeesLair/diag/token`, so leitura; "Remover" nunca apaga a da Jobe). GET `/api/diagnostico` devolve so
  `configurada`, `origem` (glibren/jobe), `final` (4 ultimos) e `propria`. A chave nunca vai para o diario; no PC o
  curl recebe os cabecalhos pela entrada (`-H @-`), nada com a chave em disco.
- **Rotas**: `POST /api/diagnostico/chave` (chave=...), `/chave/remover` e `/enviar` em `rota_protegida`
  (pareamento + X-GLR); `GET /api/diagnostico/zip` livre (como o `/diario`). Erros: 400 `diag_sem_chave` /
  `diag_chave_invalida`, 409 `diag_ocupado`; estado `failed` com `no-key|network|unauthorized|forbidden|no-repo|http|nothing|memory`.
- **Arquivos** (ultimos ~2 MB cada): glibren.log, config.ini (linhas `paired` viram `[aparelho pareado]`), info.json
  (versao, firmware, hora, de quem e a chave, pareamento, lista), termico.json, payloads.json (`payloads_json`),
  cheats.json, cheats-aplicadas.json, discos.json, /data/web-browser-fullscreen.ini.
- **Higienizacao**: lista unica no topo de `src/diagnostico.c` (mesmas regras da Jobe + `x-glr-token`, `paired`,
  `chave`, `senha`, `codigo`): segredos conhecidos (as duas chaves, hashes dos pareados), URLs sem consulta/fragmento
  e sem usuario:senha (hosts de links temporarios sem caminho), Bearer/Basic, nome=valor secreto (cookie/authorization
  levam a linha), e-mails, tokens soltos (github_pat_, UUID, 32+ letras e digitos).
- **Envio**: `https_github_put` (https.c), host fixo `api.github.com` (fora da lista geral; adicionado ao DNS robusto),
  sem seguir redirecionamento, `PUT /repos/pristmc-code/ps5-diagnosticos/contents/glibren/<pasta>/<arquivo>`, base64,
  committer PristMC noreply, branch main. Mesma regra de certificado do resto do glibren: no processo elevado o PS5
  recusa toda cadeia publica, entao vale o modo "sem verificar" (chave de escopo minimo; decisao a confirmar com o dono).
  Uma rodada por vez; mesma pasta no mesmo segundo ganha `-2`, `-3`...
- **Reserva**: `.zip` "stored" montado na memoria (CRC do miniz).
- **Tela**: `web/diagnostico.html` (pt-BR/en/es, pareamento igual as outras paginas), botao no painel Apps (4 botoes:
  2+2 no celular em pe) e link no rodape. Medido com Playwright: 360x780, 412x915, 780x360, 1280x800 e 1540x700 (UA do
  PS5), nos 3 idiomas: sem rolar de lado nem de cima a baixo, botoes da mesma largura, nada com reticencias.
- **Testes**: `testes/teste_diagnostico.sh` (95 casos, GitHub falso em 127.0.0.1), no `todos.sh`.

## 0.9.20-teste (13/11/2026): payloads de teste e tela cheia no navegador do PS5
Pedido do dono: ativar payloads de terceiros para teste com um toque pelo celular, comecando pelo
ps5-web-browser-fullscreen (pesquisa em `ps5/PESQUISA-navegador-ps5-tela-cheia.md`), num padrao que sirva para outros.
- **Catalogo fixo** (`src/payloads.c`, `ITENS[]`): id, nome, autor, licenca, repositorio, tag, URL do asset, tamanho,
  **SHA-256 fixado**, firmwares testados em console, descricao/como desfazer/aviso em pt-BR/en/es, `espera_s` e
  `navegador`. Primeiro item: `web-browser-fullscreen` v0.1b (owendswang, GPL-3.0-or-later),
  `web-browser-fullscreen-v0.1b.elf` 463.848 bytes, sha256 `520977607a22ecdf51c8d8b75360486026e0bd8780ded8026c3456fac7997a97`
  (baixado e calculado em 13/11/2026; igual ao digest que o GitHub mostra). O restore do autor NAO entra (no 11.60
  derrubou o ShellUI): desfazer = reiniciar o PS5. Sem porta propria; precisa so do elfldr 9021.
- **Ativar** (`POST /api/payloads/ativar`, `id` [+ `reabrir=/caminho`]) e **baixar** (`/api/payloads/baixar`): em
  `rota_protegida` (pareamento) + X-GLR. Id fora da lista = 404 `payload_fora_da_lista`. Navegador do PS5 e outros
  programas do proprio PS5 (127.0.0.1, isentos do pareamento) = 403 `payload_so_celular`, **menos** o item `navegador`
  (tela cheia) pedido pelo navegador do PS5: e o unico que faz sentido ali e e o gesto de quem esta com o controle na
  frente da TV (mesma confianca da isencao do 127.0.0.1); os outros ficam atras do pareamento, como as cheats.
  Jogo/app aberto (`app_de_jogo_aberto`) = 409 `payload_jogo_aberto` (se o ShellUI cair, o jogo fecha sem salvar).
  Um trabalho por vez (409 `payload_ocupado`); a atualizacao do glibren espera (`payloads_ocupado`).
- **Fluxo**: baixa por `https_baixar` (DNS robusto: github.com -> release-assets.githubusercontent.com) em `.part`
  com O_EXCL, limite = tamanho fixado, SHA-256 em fluxo; nao bate = apaga e recusa. Guarda em
  `/data/glibren/payloads/`. Antes de enviar le o arquivo de novo e confere o SHA-256 (guardado adulterado = baixa
  de novo; se o servidor tambem nao bater, nada e enviado). Item `navegador` (modelo do PS5 Web File Manager,
  `filemgr.c change_browser_layout`): 250 ms, tela inicial (`libSceShellUIUtil.sprx` por `sceKernelLoadStartModule` +
  `kernel_dynlib_dlsym` -> `sceShellUIUtilLaunchByUri("pshomeui:navigateToHome?bootCondition=psButton")`), 1 s, envia
  ao elfldr, espera o resultado, reabre o navegador em `http://127.0.0.1:8765<reabrir>`
  (`sceSystemServiceLaunchWebBrowser`, weak) mesmo se falhar.
- **Resultado do payload**: o elfldr faz dup do socket como stdin/stdout/stderr do payload (`elfldr.c elfldr_exec`),
  entao o glibren envia, faz `shutdown(SHUT_WR)` e le ate o fim (ate `espera_s` = 30 s). O fullscreen escreve
  `Result=N; ...` (0 ok, 2 ok sem gravar o INI, 1 falha) e `Notification: ...`; `[elfldr.elf] Error...` = recusado.
  Sem linha `Result=` e sem erro = "ativado" com aviso no diario (payloads que nao escrevem nada).
- **Status** (`GET /api/payloads`): nao_baixado, pronto (guardado e SHA-256 ok, com cache por tamanho/data),
  baixando/conferindo/home/aplicando/reabrindo, ativado (hora em `<id>.ativado`; so vale se depois de o PS5 ligar,
  pelo relogio monotonico), erro (motivo); `testado_no_seu` pelo `kernel_get_fw_version()` ("12.00" -> false);
  `saida` = resumo da saida do payload. Diario: linhas `payloads:`.
- **Telas**: pagina `/payloads` (atalho "🧪 Payloads de teste" na janela Apps, os 3 botoes com a mesma largura): aviso
  de risco, cartao por item (descricao, firmwares + "nao testado no seu firmware", como desfazer, estado, saida, Baixar e
  Ativar com a mesma largura, detalhes com repositorio e SHA-256), "Depois, abrir o glibren no navegador do PS5" (celular),
  pareamento igual as outras paginas. Cabe sem rolar de lado em 360x780, 412x915, 780x360, 1280x800, 1540x700 e
  1232x560 (PS5 com zoom 125%), em pt-BR/en/es; 360x780, 412x915, 1280x800 e 1540x700 sem rolar nada; 780x360 rola
  ~50-60 px por dentro, com estado e botoes no alto (texto explicativo embaixo).
- **⛶ no navegador do PS5** (`web/ps5tela.js`, rota `/ps5tela.js`, incluido em index, discos, temperatura, internet,
  telacheia e payloads): so com UA PlayStation; liga o botao de tela cheia que ja existia (`#btnTelaCheia`/`#telaCheia`,
  antes escondido no PS5), janela "Tela cheia no PS5" (aviso de risco, Aplicar/Cancelar) e `POST /api/payloads/ativar`
  com `reabrir` = a pagina atual. Em 1920x1080 (patch ativo) o botao some. `/teste-tela-cheia` ganhou o botao 7.
- Testes: `testes/teste_payloads.sh` (no `todos.sh`): catalogo/status, fora da lista, 401 sem pareamento, 403 local,
  400 reabrir invalido, jogo aberto, SHA-256 errado, tamanho errado, pareado -> baixar -> ativar com elfldr falso
  (arquivo recebido = servidor; saida no status; tela inicial e reabrir no diario), status depois de reabrir o
  glibren e antes do boot, navegador do PS5, falha do payload, recusa do elfldr, arquivo adulterado, elfldr fora do ar
  e, com internet, o SHA-256 e o tamanho do asset real.
- ❓ Nada testado no PS5. ❓ 12.00 so tem perfil "offline" no payload.

## 0.9.19-teste (13/11/2026): telas sem texto cortado e botoes da mesma largura
So interface (web/*.html); nenhuma mudanca no C alem da versao.
- **Nada com reticencias** (varredura de `text-overflow: ellipsis` em todas as paginas): texto maior que a linha
  quebra e o cartao cresce. Temperatura (relogio, SSD USB, destaque, nomes dos blocos, titulo, IP/ligado), Discos
  (aviso deitado), tela principal (resumo da lista, painel de atividade, destino do YouTube), Cheats e FPS (titulo,
  rotulos, codigo do jogo, estado, nomes dos blocos). Unica excecao: o `<select>` de servidor da Internet (um select
  nativo nao quebra linha). Seletor de idioma da tela principal com nomes curtos ate 420 px (PT (BR), EN, ES): o
  navegador cortava "Português (" em 360 px.
- **Mesma largura na mesma fileira**: chips da tela principal no PC/PS5 numa grade de colunas iguais (`#chipsNav`,
  `ajustarChips()` mede o maior chip, ve quantos cabem e divide igual entre as linhas: 1280 px = 4 + 4; PS5 1920 = 5
  numa linha; o chip de tela cheia ganhou o nome); Ler/Escolher/Ocultar pastas; BASICO/AVANCADO e Aplicar/Automatico
  (Temperatura); botoes da pagina de teste do YouTube. Celular continua so com os icones (46 px).
- **Temperatura AVANCADO** cabe sem rolar: 360x780 (antes 921 px de conteudo em 780; 989 com textos longos), 780x360
  (antes 367) e 1280x800 (antes 959-977). Celular: CPU e RAM com titulo e numero na mesma linha ("RAM" curto), maximo
  ao lado do numero nos blocos, nucleos mais baixos, IP e tempo ligado numa linha (reserva "12d 23h 59min");
  em pe a ventoinha ficou em 2 linhas (titulo + regua + valor; Aplicar/Automatico + modo) e o Ler do SSD USB foi para
  a linha do texto; texto do relogio em 12 px (o comum "Certo (2 s adiantado) · conferido as 12:25 · fuso UTC-03:00"
  cabe nas 2 linhas reservadas, em pt-BR/en/es). PC/PS5: o cartao avancado vai para cima do grafico (coluna da direita).
  Limite conhecido: em 360x780 no AVANCADO, com o relogio em 4 linhas (servidores discordam + fuso errado) e falha no
  SSD USB ao mesmo tempo, ainda passa ~31 px; 360x640 (baixo demais) segue rolando por dentro.
- Lista da tela principal: a linha filtros/resumo/botoes quebra numa janela de PC estreita (1000 px passava 143 px).
- YouTube (teste): uma coluna no celular (499 px em 360). FPS deitado em espanhol: o cabecalho desce de linha (o tela
  cheia saia da tela). Cheats: chips de estado dos trechos com largura minima 7,4em ("DESACTIVADA" passava da caixa).
- Conferido com Playwright em 360x780, 412x915, 780x360 e 1280x800 (e 360x640, 412x860, 860x330, 1280x860, 1920x1080
  com user agent do PS5), em pt-BR, en e es: `main.scrollWidth` = largura, nenhum elemento com `scrollWidth >
  clientWidth` (fora a area de toque invisivel de 40 px e as listas com rolagem propria), chips/atalhos iguais.

## 0.9.18-teste (13/11/2026): Cheats Fase 1 (ligar e desligar)
Leitura (Fase 0) confirmada no PS5 PRO fw 12.00 em 13/11/2026 (Terminator 2D PPSA25872 v01.002.000: 5 trechos batem).
- **Os "5 de 9"**: o arquivo real tem 7 trechos (5 normais + 2 code caves com `off` zerado, que no PS5 deram para ler:
  zeros). A 0.9.17 contava as caves lidas em `lidos` E em `caves` (5+2+2 = 9). Agora as areas extras nao entram nos
  conferiveis; o resumo diz quantos trechos ha de cada tipo e cada cheat mostra o estado verdadeiro (Easy Score e 10x
  Score aparecem como "Nao suportada ainda: area extra", nao mais como "Desligada").
- **Escrita** (`src/cheats.c`): `kernel_proc_copyin` do SDK (mdbg e, se falhar, page walk + DMAP), sempre com leitura de
  volta. Leitura e escrita em pedacos que nao cruzam pagina de 4 KB (o laco DMAP do SDK v0.45 usa `plen > len` e copiaria
  bytes a mais quando o trecho cruza pagina). Regras: ligar exige todos os trechos = `off`; originais em memoria e em
  `/data/glibren/cheats/aplicadas.json` ANTES de gravar; grava em ordem e desfaz se um falhar; desligar exige `on` e
  restaura os originais (= `off`); pid/app id mudou = "perdidas", nada gravado; ao fechar (`/api/sair`, SIGTERM)
  restaura se o jogo for o mesmo; depois de SIGKILL a nova copia retoma a lista (mesmo pid/app). Cheat sobreposta a
  outra ligada e recusada. Nao suportadas: area extra, `section != 0`, `absolute`, sem `off`, outro processo. Mutex
  unico para leitura e escrita. Diario `cheats: ligou/desligou <nome> em <TID>` + linha por trecho.
- **Rotas**: `POST /api/cheats/ligar` e `/desligar` em `rota_protegida` (pareamento) + X-GLR; 403 para o navegador do PS5
  e para 127.0.0.1 (o pareamento deixa o local passar; aqui nao).
- **SIGTERM** (`main.c`): para o servidor e o main restaura as cheats (alarme de 10 s); no desligamento pedido pelo
  glibren sai na hora como antes (`plataforma_desligando()`).
- **Pagina**: interruptor por cheat (Ligando…/Desligando…, Ligada, Desligada, Erro com motivo, Nao suportada), confirmacao
  na primeira vez da sessao, aviso "Salve o jogo antes", sem o selo "so leitura", resumo por tipo, aviso de perdidas.
  Mesma largura nos interruptores; nada com reticencias; cabe em 360x780, 412x915, 780x360 e 1280x800.
- Testes: `teste_cheats.sh` 169 (tambem com ASan+UBSan); todos.sh 16 suites OK.

## 0.9.17-teste (12/11/2026): pagina de Cheats (Fase 0, so leitura) e Temperatura cabendo em 360x780
Merge da branch `cheats` (commits 981e3e7, d4c5332, 0615564; estudo em `ps5/ESTUDO-cheats-onionhen.md`).
- **Cheats, Fase 0** (`src/cheats.c`, `web/cheats.html`): GET `/cheats` e `/api/cheats` livres e recusadas (403) no
  navegador do PS5; mostra o jogo aberto, a versao, as cheats .json do catalogo HEN-Cheats-Collection
  (`/data/glibren/cheats/json/`) e de `/data/OnionHEN/cheats/`, e LE os bytes atuais de cada trecho
  (`kernel_proc_copyout` do SDK). Nenhuma escrita na memoria do jogo: o teste confere que o `cheats.o` do PS5 so importa
  a leitura (sem copyin/mdbg/ptrace/mprotect).
- **`POST /api/cheats/catalogo` exige o pareamento** (entrou em `rota_protegida`): troca a pasta
  `/data/glibren/cheats/json` inteira e baixa ~14 MB, o mesmo tipo de acao de `/api/atualizar`. 127.0.0.1 isento (mas a
  rota ja recusa o navegador do PS5). A pagina usa o mesmo `glrPost` + janela de pareamento das outras paginas.
- `codeload.github.com` na lista do DNS robusto (`dns_resolver.c`) e na lista de hosts do `https.c`.
- Atalhos: chip 🎯 Cheats na tela principal (so fora do PS5) e atalho "🎯 Cheats" na pagina de FPS (o jogo aberto);
  Temperatura, Discos e Internet ficaram sem (ja tem FPS, que leva ao jogo; um 5o atalho apertaria a Temperatura em
  360 px). Internet passou a ter os atalhos de mesma largura (igual Discos/Temperatura). Icones da tela principal no
  celular com a mesma largura (46 px). FPS deitado: atalhos mais justos para o titulo nao sumir com 5 atalhos.
- **Temperatura**: em 360x780 com o cartao "SSD na gaveta USB" passava ~55 px (rolava em pe). Agora cabe: cartoes
  um pouco mais baixos, relogio em 2 linhas (titulo + modo; texto + Conferir), titulo da pagina numa linha so, grafico
  com no minimo 76 px; os textos do relogio e do SSD USB quebram a linha em vez de cortar com reticencias. PC 1280x800
  tambem passava ~70 px: mais compacto quando a altura e <= 900 px; consumo do chip e relogio quebram a linha no PC.
- Testes: todos.sh 16 suites (novas linhas: pareamento +2, dns +1; teste_cheats 70).

## 0.9.16-teste (12/11/2026): pareamento, ejetar USB, consumo do chip, watchdog, primeiro plano e DNS robusto
Itens 1 a 5 da secao C de `ps5/ANALISE-TOPICOS-E-PS5-Suite.md` (o dono aprovou "implementar todas as ideias") e a
correcao da pagina de FPS em 360 px. Tudo reescrito (nada copiado); creditos no README.
- **Ejetar USB** (`src/discos.c` `discos_ejetar`, `POST /api/discos/ejetar` caminho [+ forcar=1]; ideia do
  yibinsimon/ps5-usb-manager, GPL-3.0): so `/mnt/usb<1-2 digitos>` (lista positiva) e nunca a lista fixa de protegidos
  (`/`, `/data`, `/user`, `/system*`, `/mnt/ext*`, `/dev`, `/preinst`, `/mnt/sandbox`...); recusa com tarefa na fila
  (`tarefas_ativas`) ou teste de velocidade (`discos_testando`). `sync()` -> desmonta as nullfs cuja origem e o disco ->
  `unmount(ponto, 0)`. EBUSY: lista quem tem arquivo aberto no disco (`KERN_PROC_PROC` + `KERN_PROC_FILEDESC`,
  `kinfo_file.kf_path`), sem encerrar nada; `MNT_FORCE` so com forcar=1 (a pagina pede uma 2a confirmacao com o aviso
  do risco). Chaves: ejetar_protegido, ejetar_tarefas, ejetar_teste, ejetar_andamento, ejetar_nao_montado,
  ejetar_ocupado (ocupantes, listas_lidas, vistas, pode_forcar), ejetar_falhou. Diario: linhas `ejetar:`. Pagina
  Discos: botao "⏏ Ejetar" ao lado do Testar (so USB), janela "em uso" com a lista e "Forcar..." -> "Sim, forcar".
  No PC: bind no lugar de nullfs, `/proc/<pid>/fd` e `MNT_DETACH` no lugar do `MNT_FORCE`.
- **Watchdog** (`src/sce_prazo.c`, `sce_com_prazo()`): thread destacada (256 KB) com prazo; entrada e saida copiadas
  (a pilha de quem chama pode sumir); estourou = "presa" (nao e chamada de novo ate voltar); voltou atrasada = volta a
  valer; 3o estouro = fora ate reiniciar. Passam por ele: temperatura (CPU, SoC canais 0/2 e o botao Ler canais 0..15),
  ventoinha, consumo, `sceLncUtilGetAppId` (app aberto e a varredura de apps abertos numa thread so) e
  `sceSystemServiceGetAppIdOfRunningBigApp`/`GetAppTitleId` (FPS e primeiro plano). Presa = -1/"nao deu para saber"
  (o lancador nao lanca: R7). `/api/termico` traz `"watchdog":{chamadas,estouros,mortas}`. Sem sigsetjmp (decisao:
  nao mexer no tratador de sinais que grava a queda).
- **Consumo do chip** (`termico.c`): `sceKernelGetSocPowerConsumption` (weak, libkernel_sys) com buffer de 512 bytes
  (ela escreve 0x70 = 8 trilhos {mW,mV,mA}); mostra a **soma** dos mW (como o PS5-Suite); fora de 1..400 W ou sem a
  funcao = -1 e a linha some. JSON `potencia_w` e `potencia_trilhos_mw`; diario `potencia: trilhos mW ...` na 1a
  leitura. Pagina Temperatura: "⚡ Consumo do chip: N W" embaixo do maximo da sessao; ate 380 px vai para o fim da
  linha da ventoinha (nao aumenta a altura).
- **Pareamento** (`src/pareamento.c`; modelo ps5-hass-payload, GPL-3.0): leitura livre; `/api/tarefas`,
  `/api/renomear`, `/api/ativar`, `/api/atualizar`, `/api/apps/instalar|desinstalar`, `/api/discos/ejetar`,
  `/api/youtube`, `/api/youtube/maxd`, `/api/energia` e `/api/sair` pedem `X-GLR-Token` valido (401
  `parear_necessario`); 127.0.0.1 isento. `POST /api/parear/pedir` -> codigo de 6 digitos (2 min) so na notificacao
  da TV (nunca no diario, que e de leitura livre); `POST /api/parear` (codigo, nome) -> token de 32 bytes; 5 erros
  descartam o codigo e bloqueiam 30 s, 1, 2, 4... ate 15 min; um codigo novo a cada 10 s no maximo; comparacoes em tempo
  constante. config.ini: `pairing = on|off` e `paired = <sha256 do token> <quando> <nome>` (ate 8; o token mesmo fica
  so no localStorage). `POST /api/parear/esquecer` apaga todos. Paginas: `glrPost()` (index e discos) manda o token e,
  com 401, abre a janela "Parear este aparelho" e repete o pedido uma vez. Conferido quem chama a 8765: o app de PC
  (game-library-renamer) usa FTP e servidor proprio; a Jobe (jobe-simultaneos, so lido) nao chama a 8765 (arquivos +
  /switch dela); o Max'd usa `/launch` local; o APK glibren Controle e WebView com DomStorage. Ninguem quebra; mesmo
  assim `pairing = off` fica documentado no README.
- **Primeiro plano** (`src/primeiro_plano.c`; ideia do ps-game-state-lib, MIT): le `kern.msgbuf` (sysctlbyname),
  ultima `SetControllerFocus(appId)` (0x7 = tela do sistema) e `VideoOut: shared (pid=, appId=)`. `/launch` com from:
  depois que o from fecha, com sinal espera o foco sair do appId antigo (+3 s), no maximo 15 s; sem sinal, os 15 s fixos
  de antes (diario diz qual). Regra de nunca abrir por cima de outro app mantida. `GET /api/primeiro-plano`
  (diagnostico) e botao "Diagnostico do primeiro plano" no painel ℹ️ da pagina de FPS; o FPS usa o titulo com o foco
  quando ha sinal (`"fonte":"primeiro_plano"`).
- **DNS robusto** (`src/dns_resolver.c`, `src/dns_ca.h`; ideia do ps5-patchdl `patchdl_dns.c`, GPL-3.0+; nada do
  `patchdl_resolve.c`): so raw.githubusercontent.com, github.com, release-assets/objects.githubusercontent.com,
  prosperopatches/orbispatches (+cdn); trava extra para nomes da Sony. UDP (1.1.1.1, 8.8.8.8, 9.9.9.9) -> TCP
  (1.1.1.1, 8.8.8.8) -> DoH (cloudflare-dns.com em 1.1.1.1, dns.google em 8.8.8.8, raizes embutidas). Resposta so com
  enderecos privados/loopback e recusada. Cache 600 s/20 s, positivos em `dns_cache.txt`. No PS5 entra no lugar do
  DNS proprio de antes (quando o pedido pelo nome falha e o https.c conecta pelo IP com Host - o equivalente possivel
  ao CURLOPT_RESOLVE na sceHttp); o DoH tenta `sceHttpsLoadCert` com as raizes e, se o certificado falhar, so segue
  sem verificar quando o glibren ja esta no modo autorizado. No PC, `--resolve host:443:IP` no curl quando o DNS do
  sistema falha. `GET /api/dns?host=`. O tube-service ficou de fora (outro agente).
- **FPS em 360 px**: a linha de atalhos passava 13 px e rolava de lado. Pedido do dono no meio do trabalho: **atalhos
  com a mesma largura** (grade: 2 linhas de 2 no celular estreito, uma linha nos outros; deitado/PC todos com a largura
  do maior), sem cortar texto. Aplicado em FPS, Discos e Temperatura (o ⛶ fica numa coluna propria, fora da conta). "← JOGOS"
  sempre primeiro. Botoes Ejetar/Testar com a mesma largura.
- Testes novos: `teste_pareamento.sh` (50), `teste_watchdog.sh` (21), `teste_primeiro_plano.sh` (20),
  `teste_ejetar.sh` (28, tmpfs em /mnt/usb7 no WSL), `teste_dns.sh` (24, servidores falsos em `testes/dns_falso.py`;
  o ultimo caso usa o DoH de verdade com as raizes embutidas quando ha internet). Todos no `todos.sh`.
- Telas conferidas na demo (360x780, 412x915, 780x360, 1280x800, pt-BR e es): sem rolar de lado; janelas de pareamento
  e de ejetar. Pendente antigo (nao desta versao): Temperatura em 360x780 com o cartao "SSD na gaveta USB" visivel
  passa ~40 px da altura (o grafico fica embaixo), igual a 0.9.15.
- ❓ Nada testado no PS5.

## 0.9.15-teste (12/11/2026): pagina de FPS com capa e nome do jogo em destaque
Pedido do dono (print no celular, 417 px): aproveitar melhor a tela, nome do jogo em destaque e visivel, com foto.
- **Defeito do nome errado** ("O PS5 nao resp..." no lugar do nome): nao era a API. A pagina ficou aberta com a demo do
  PC parada (o console tinha centenas de `ERR_CONNECTION_REFUSED` em `/api/fps`) e, depois de 8 s sem resposta, o
  script da 0.9.14 escrevia o aviso "O PS5 nao respondeu" **no lugar do nome do jogo** (cortado numa linha) e deixava os
  numeros antigos na tela como se fossem atuais. Agora o nome nunca e trocado: a falta de resposta aparece na linha de
  estado embaixo do FPS ("O PS5 nao respondeu: numeros parados"), o ponto fica vermelho e numeros e grafico ficam
  apagados ate voltar. Erro do servidor (errno) tambem vai para essa linha, nao para o lugar do nome.
- `web/fps.html` refeita: no topo, cartao do jogo com a **capa** (`/icone/<CODIGO>`, pedida so quando o jogo muda;
  sem capa, um desenho no lugar: 🎮 jogo, 📺 tela do PS5/menu, ❔ desconhecido, ⏳ ligando) e o **nome grande em ate 2
  linhas** com altura fixa (fonte menor acima de 34 letras), codigo embaixo. Depois o FPS bem grande (largura
  reservada) com a linha de estado (altura fixa), media/minimo/tempo e o **grafico com todo o resto da altura**.
  Texto do teste e diagnostico ("contador: ioctl...", "simulado no PC") foram para o botao ℹ️ (painel por cima, fecha
  no ✕, tocando fora ou Esc). Atalhos numa linha so (rolam de lado em 360 px). Deitado: capa + nome, FPS (ocupa o meio)
  e numeros a esquerda, grafico a direita. PC: igual, com capa ate 168 px e numero ate 160 px.
- `src/api.c`: `/icone/<CODIGO>` tambem serve a capa do proprio jogo instalado (`/user/appmeta/<CODIGO>/icon0.png`;
  no PC, `GLR_TESTE_APPMETA`) quando ela ainda nao esta guardada em `icones/` - sem internet. A biblioteca tambem ganha.
- Mantido: pagina e API recusadas no navegador do PS5, leitura so com a pagina aberta, pt-BR/en/es, "← JOGOS" primeiro.
- Conferido na demo (jogo simulado PPSA01284 com nome longo e capa no appmeta): 360x780, 412x915, 780x360 e 1280x800
  com `main.scrollWidth` = largura e `scrollHeight` = altura (sem rolar); menu sem jogo (sem capa quebrada); painel ℹ️;
  queda da demo com a pagina aberta (nome fica, aviso na linha de estado). `testes/teste_fps.sh`: 45 casos (capa pelo
  appmeta, 404 sem capa, codigo invalido, pagina usa `/icone/` e nao poe o aviso no lugar do nome).
- ❓ Nao testado no PS5: conferir se a capa aparece (icon0.png do appmeta) e o nome no idioma.

## 0.9.14-teste (12/11/2026): FPS do jogo aberto (teste, so no celular/PC)
Fase A do estudo `ps5/ESTUDO-fps-monitor-panel.md` (decisoes do dono: so celular/PC, le so com a pagina aberta, so
jogos de PS5, nada da Fase B nem do gancho de PS4).
- `src/fps.c` (codigo proprio; tecnica do PHU Games Tools / onionHEN, vista no fps-monitor-panel de rawalakshay,
  GPL-3.0, `source/libonion_fps/source/fps_dce.cpp`): `open("/dev/dce", O_RDWR)` + `ioctl(0x80308217)` so de leitura
  (arg de 0x30 bytes, contador u64 em saida+8); se der EINVAL, tenta `0xFFFFFFFF80308217` e lembra qual valeu. Nada
  e desenhado na tela do PS5, nada e injetado (nem na SceShellUI nem no jogo), nenhuma memoria do jogo e lida.
- Sob demanda: o primeiro `GET /api/fps` cria uma thread que le o contador a cada 250 ms; cada pedido renova o prazo;
  sem pedidos por 10 s ela fecha o `/dev/dce`, grava o resumo no diario e sai. A pagina consulta a cada 1 s e para de
  consultar com a aba escondida.
- Numeros: FPS agora = ritmo dos ultimos 2 s; um ponto por segundo no historico (5 min, para o grafico); media,
  minimo e maximo da sessao so de jogo de PS5 (zera ao trocar de jogo ou religar a leitura). Valores fora de 0..240 sao
  descartados.
- Jogo aberto: `sceSystemServiceGetAppIdOfRunningBigApp` + `sceSystemServiceGetAppTitleId` (weak; sem elas,
  `app_de_jogo_aberto()`), a cada 2 s. CUSA = PS4: sem medicao (nem abre o `/dev/dce`). Sem jogo (ou NPXS/PMGL00001):
  "Tela do PS5", o numero aparece mas nao entra na media. Nome pelo `param.json` (`/user/appmeta/<TID>/`,
  `/user/app/<TID>/sce_sys/`, `/system_ex/app/<TID>/sce_sys/`), no idioma da pagina.
- Erros: open que falha (EPERM/EACCES/ENOENT/ENXIO/ENODEV = desiste nesta leitura) ou ioctl que falha aparecem na
  pagina com o errno; EBADF reabre. Diario (linhas `fps:`): leitura ligada/parada (com resumo media/min/max), jogo
  aberto, qual numero do ioctl respondeu e o contador inicial, primeira falha de cada tipo.
- `GET /fps` (pagina) e `GET /api/fps[?historico=1]`: recusados (403) quando o User-Agent tem "PlayStation" - o
  navegador do PS5 nem liga a leitura. `pedido_t` ganhou `agente` (User-Agent). O Host continua conferido antes.
- `web/fps.html`: pt-BR/en/es, "← JOGOS" primeiro, selo TESTE no titulo, numero grande com espaco reservado (nada
  pula), media/minimo/tempo, grafico com linhas de 30 e 60, nota do teste e detalhe (numero do ioctl, errno,
  "simulado no PC"). Tres layouts: celular em pe (tudo numa tela, grafico com o que sobra), deitado (2 colunas) e
  PC (2 colunas). Atalho "🎮 FPS" na pagina principal, Temperatura, Discos e Internet, escondido no PS5
  (`html.ps5 .nao-ps5`).
- Testes: `testes/teste_fps.sh` (39 casos: recusa pelo User-Agent do PS5 sem ligar a leitura, Host, pagina, FPS
  simulado 60 e 30, menu sem media, jogo com nome no idioma, PS4 sem medicao, troca de jogo, erro errno 13 na tela e
  no diario, para sozinha sem pedidos e volta no proximo pedido); entrou no `todos.sh`. Pagina conferida na demo em
  360x780 e 780x360 (`main.scrollWidth` = largura, sem rolagem, numero e nome sem pular a cada 1 s); atalho novo
  conferido nas outras paginas em 360x780, 640x360, 780x360 e 1280x800.
- ❓ Nao testado no PS5. O que testar (PS5 Pro, fw 12.00), abrindo http://IP-DO-PS5:8765/fps no celular:
  1. Abre o `/dev/dce`? Qual numero respondeu (detalhe "contador: ioctl normal/estendido") ou qual errno?
  2. Menu do PS5 sem jogo: quanto mostra (esperado ~60; com a TV em 120 Hz, ~120)?
  3. Jogo de PS5 travado em 30 (modo fidelidade) deve mostrar ~30; em 60 (modo desempenho) ~60. **Se os dois
     mostrarem 60, o contador e da TV (vblank) e esta tecnica nao serve sozinha.**
  4. Jogo em segundo plano (botao PS, menu por cima): o que aparece (o contador e da tela, nao do jogo)?
  5. Jogo de PS4: deve aparecer "Sem medicao em jogos de PS4".
  6. A leitura para sozinha: fechar a pagina, esperar 10 s e ver no `/diario` a linha `fps: leitura parada`.
  7. Nenhuma queda de FPS no jogo com a pagina aberta; repouso e volta; abrir `/fps` no navegador do PS5 deve dar a
     mensagem "so para o celular ou o PC".

## 0.9.13-teste (12/11/2026): interface (parte do glibren da Etapa 5)
- Botoes que nao somem (W6): a lista de tarefas (Atividade), a tabela de jogos, a pagina Discos e a pagina Internet
  atualizam os elementos no lugar (cada um preso a uma chave: id da tarefa, pasta+nome do arquivo, caminho do disco);
  so o que mudou e refeito. O Cancelar nao e mais recriado a cada 250/700/1000 ms entre apertar e soltar, e o foco do
  controle fica. Os botoes da linha (Renomear, Ocultar, ATIVAR) voltam a valer quando a acao termina.
- Lista com centenas de jogos: redesenho agrupado (no maximo um a cada ~150 ms enquanto os jogos sao consultados;
  antes, um por jogo) e so as linhas que mudaram sao refeitas. Medido na demo com 600 itens: 111 ms na primeira
  montagem, 38 ms num redesenho sem mudanca.
- "Cancelar todas" na Atividade (aparece com 2 ou mais tarefas ativas, embaixo da lista, com confirmacao):
  `POST /api/tarefas/cancelar-todas`.
- Confirmacoes abrem com o foco em Cancelar (W13): Parar payload, Renomear todos, Atualizar, Desinstalar, Cancelar
  todas.
- Erros do servidor traduzidos (W15): tabela de mensagens fixas (portugues sem acento -> pt/en/es, com as partes que
  variam) na pagina principal (atualizacao, apps, tarefas, energia, pastas), Discos, Internet e Temperatura (ventoinha).
  O que nao esta na tabela aparece como veio.
- Toque (W16): no celular (ate 760 px de largura ou 500 de altura), todo botao/link tem uma area de toque invisivel de
  pelo menos 40x40 px (o desenho nao muda, nada pula); caixinhas com 24 px e a celula inteira marca/desmarca; `select`
  com 16 px (sem zoom no iPhone) e 40 px de altura em pe (32 px deitado na Temperatura, para o grafico caber).
- Temperatura deitado (W14): cartao do SSD USB em duas linhas baixas e os detalhes abertos numa caixa por cima, embaixo
  da tela, com rolagem propria; colunas dos nucleos mais baixas; atalhos do topo sem quebrar linha. Conferido em
  640x360, 740x360 e 780x360 (Basico e Avancado, com e sem detalhes): nada sai da tela, sem rolagem.
- Temperatura (pedido do dono): o bloco "Ventoinha" da grade saiu (era repetido); a ventoinha fica so no destaque do
  topo, com a barra. A grade tem 3 blocos (CPU, SoC, SSD M.2) na largura toda. Conferido em 360x780, 640/740/780x360 e
  1280x800.
- Conferido na demo: `main.scrollWidth` <= largura em 360x780 e 780x360 nas quatro paginas.
- Pendente: lixeira/desfazer na exclusao (nao feito: exige mover para uma pasta por disco, limpeza por idade/espaco e
  restaurar com conflito de nome - fica para uma versao propria); acessibilidade (role/aria). O seletor de idioma no
  topo fica estreito no celular deitado (ja era assim).

## 0.9.12-teste (12/11/2026): atualizacao e rede (Etapa 3 do plano de acao)
Correcoes da revisao de 12/11 (`ps5/REVISAO-PROJETO-2026-11-12.md`, IDs entre parenteses):
- Atualizacao sem volta para tras (R1): depois da assinatura, o marcador `GLIBREN-VERSAO:` do .elf baixado tem de ser
  igual ao anunciado no `versao.json` (que nao e assinado) e maior que a versao em execucao; senao, recusa com o motivo.
  Catalogo de apps: "atualizar" so quando a versao do catalogo e MAIOR que a instalada (comparacao numero a numero:
  `2.0-glibren10` > `2.0-glibren1`); instalar uma versao mais antiga que a instalada e recusado. App sem
  `glibren_app.json` (instalado fora do glibren) continua oferecendo "atualizar", como antes.
- Versao gravada que nao sobe (R3): a copia que passa a vez troca o proprio nome de processo (`glibren-espera`, para a
  nova nao encerra-la), envia ao elfldr e espera ate 60 s a nova responder em `/api/estado` com a versao gravada. Sem
  resposta: `glibren.elf` e `.sig` viram `.ruim`, a copia presa (se houver) e encerrada e esta segue rodando, com
  notificacao. Tentativas em `tentativas_atualizacao` ("versao n"): a nova que fica de pe 3 min zera; na 3a vez seguida
  (sobe e cai logo depois) vira `.ruim` sem passar. A trava `passou_a_vez` das versoes antigas ainda e apagada pela
  nova; achada por uma copia mais velha que a gravada, conta como tentativa. **So vale quando a copia que o autoloader
  manda ja e 0.9.12 ou mais nova** (a 0.9.11 e anteriores passam a vez e saem na hora).
- Atualizar com trabalho em andamento (R4): recusado com tarefa de copiar/mover/excluir na fila (`tarefas_ativas`),
  teste de velocidade de disco ou instalacao de app; conferido ao pedir e de novo depois do download. Instalar e
  desinstalar app recusam com o app aberto (`app_aberto`).
- `fsync` no .elf e na .sig da atualizacao antes de trocar (R10).
- URL (R2): `@` recusado em qualquer lugar; depois do host so fim, `/`, `?`, `#` ou `:` + digitos. Vale a cada salto de
  redirecionamento (a conferencia roda em todo salto).
- Speedtest (R8): os servidores da lista do speedtest.net ficam numa lista propria, aceita so pelo teste de internet
  (`https_fluxo`); nome sem letra (IP literal) e recusado na lista e na tela.
- `/api/web` responde `text/plain` (W4): o HTML dos sites de patches nunca roda na origem do glibren; a pagina ja lia
  o texto. `youtube.html` (W5): so mensagens da origem exata do player (youtube-nocookie.com / youtube.com) e da
  propria moldura; textos entram como texto (sem HTML).
- Host (G4): toda rota recusa (403) Host que nao seja IP literal (IPv4 ou [IPv6]), `localhost` ou vazio, com ou sem
  porta; uma linha no diario por minuto no maximo. Protege contra DNS rebinding sem quebrar o acesso pelo IP (PC,
  celular), o 127.0.0.1 do PS5 e o `/launch`.
- Pastas (G5, decisao do usuario): excluir, mover, copiar, renomear e ATIVAR so com origem (e destino) que seja uma
  das pastas da lista (mesmo criterio da `/api/local`, ignorando a barra do fim). Recusa vem como
  `motivos.fora_das_pastas` / chave `fora_das_pastas`.
- Relogio (R5): notificacao de "nao acertou" so na primeira falha seguida; falhas seguidas dobram a espera
  (10, 20, 40 min... ate 6 h).
- Ventoinha (G6): alvo de fabrica guardado em `alvo_fabrica.txt` na primeira leitura com o limite desligado e usado nas
  sessoes seguintes; enquanto nao houver arquivo, tenta de novo a cada minuto. Limitacao: se o perfil ainda tiver um
  limite nosso de uma sessao anterior (limite desligado logo antes de atualizar, sem jogo/menu no meio), esse valor
  pode ser guardado como "de fabrica" (fica mais restritivo, nunca mais permissivo); apagar o arquivo resolve.
- R7: quando nao da para saber se ha app aberto (funcao do sistema ausente), nada e lancado (`/launch`, YouTube e o
  lancador pendente); antes liberava.
- `POST /api/tarefas/cancelar-todas` (a tela usa na 0.9.13).
- Testes: `teste_seguranca.sh` (32 casos: Host, URL, pastas, alvo da ventoinha) e `teste_atualizacao.sh` (26 casos:
  marcador diferente, anuncio velho/igual, recusa com tarefa, gravacao certa, nova que nao responde vira `.ruim`, nova
  que responde, 3 tentativas), mais 8 casos no `teste_apps.sh` (versao mais antiga, app aberto) e o `teste_tarefas.sh`
  com as pastas na lista. Os dois novos e o `teste_tarefas.sh` tambem rodaram com AddressSanitizer sem erro.
- Nao testado no PS5. Pedido: atualizar de 0.9.11 para 0.9.12 pelo botao; abrir pelo IP no celular e pelo icone.

## 0.9.11-teste (12/11/2026): pagina Temperatura cortada no celular
- Desde a 0.9.8 a pagina Temperatura saia da tela no celular em pe (temperatura e ventoinha cortadas): a nota do cartao
  "SSD na gaveta USB" e uma linha so (nowrap, 94 caracteres) e, numa coluna de grade, o cartao alargava a coluna
  inteira (min-width automatico = largura do conteudo): 596 px numa tela de 360. Correcao: `.card { min-width: 0 }`.
- Celular deitado: o cartao do SSD USB vai para a coluna da esquerda, embaixo dos blocos (no meio ele tirava todo o
  espaco do grafico).
- Conferido na demo: 360x780, 412x915 (basico, avancado e detalhes abertos), 780x360; Discos e Internet sem mudanca.

## 0.9.10-teste (12/11/2026): perda de dados e o botao Ler (Etapa 1 do plano de acao)
Correcoes da revisao de 12/11 (`ps5/REVISAO-PROJETO-2026-11-12.md`, IDs entre parenteses):
- Copiar/mover (G1): `fsync` a cada 256 MB e no fim, antes do rename; mover entre discos so apaga a origem depois.
- Fila (G3): `executar()` devolve o estado final e o trabalhador grava estado + fim com a trava; uma tarefa so sai da
  lista (`remover_terminadas`) depois disso. Antes, 250 exclusoes num pedido podiam liberar tarefas em uso.
- Parcial proprio `.glr-part` (G10): sobra de copia interrompida e apagada ao iniciar (raiz das pastas da lista) e ao
  tentar de novo; o `.part` de outros programas nunca e tocado. `.glr-part` conta como download em andamento.
- Downloads (W3): copiar e mover recusam arquivo em download (`em_download`, como o renomear); excluir recusa so o que
  foi gravado nos ultimos 15 min (o parcial parado de um download abandonado ainda pode ser apagado). Conferido ao por
  na fila e de novo ao executar.
- Recusas com motivo (W7): `POST /api/tarefas` devolve `motivos` {mesma_pasta, em_download, fila_cheia, invalido}; a
  pagina mostra cada um e so limpa a selecao quando nada foi recusado.
- `config.ini` e `temperatura.txt` (G11): `fflush` + `fsync` antes do rename (o `temperatura.txt` passou a usar `.tmp`).
- Botao Ler (G2, G7, G8, G9): o comando de fabricante 0xE4 so vai a gaveta que se identifica como Realtek no INQUIRY
  (decisao do usuario: sem "tentar mesmo assim"); recusa com copia/movimentacao na fila ou teste de disco
  (`"recusado":"copiando"|"testando"|"lendo"`, nenhum comando ao disco); uma leitura por vez, sem segurar a trava
  durante os comandos; o que deu certo no pass* nao e repetido no da*; cada leitura comeca do zero; resultado no diario.
- Pagina (W1, W2, W10): a lista e relida depois de excluir/mover (mesmo quando acaba antes da proxima consulta); a
  selecao perde o que saiu da tela (filtro, busca ou pasta), entao copiar/mover/excluir agem so no que esta a vista;
  a busca ignora pontuacao dos dois lados e procura tambem no nome da base (`info.nome`); a janela de exclusao marca
  com ⏳ os arquivos de download.
- Testes: `teste_tarefas.sh` com 13 casos novos (sobra ao iniciar e ao copiar, `.part` alheio intocado, recusas com
  motivo, download, controle ao lado, botao Ler com copia, dois lotes de 250 exclusoes); passou tambem com
  AddressSanitizer (sem erro de memoria).

## 0.9.9-teste (12/11/2026): mais tentativas para o SSD USB e canais 0..15
- Antes do repasse do RTL9210, tenta tambem o LOG SENSE pagina 0x0D (temperatura, padrao SCSI), o mesmo metodo do
  ps5upload/elf-arsenal (CAMIOCOMMAND em /dev/daN aberto so para leitura); o resultado diz qual metodo deu certo.
- Lista os canais 0..15 de `sceKernelGetSocSensorTemperature` (antes 0..7).
- Pesquisa (12/11): o canal 2 e o slot de expansao M.2 "na maioria das revisoes" (ProsperoMgr, elf-arsenal, ps5upload,
  ps5-new-overlay); vazio le ~0. Nenhum projeto le o SSD interno de fabrica. Probes de outros projetos: canais 0..63
  respondem com valores parecidos com o SoC (34-38 C no fw 12.70, 49-54 C no 13.60), 64 = -49 fixo, 65+ = erro
  0x80020016. Nada documentado para o PS5 Pro.

## 0.9.8-teste (12/11/2026): temperatura do SSD na gaveta USB (teste)
- Cartao "SSD na gaveta USB (teste)" na pagina Temperatura, botao Ler (`POST /api/usb-temperatura`; `GET` devolve o
  ultimo resultado). So le quando o usuario pede. `src/usb_temp.c`: lista as montagens /mnt/usb* e /mnt/ext* (de onde
  vem cada uma), os aparelhos de disco em /dev, e tenta em cada /dev/pass* e /dev/da* (sem particao), pelo CAM do
  FreeBSD (ioctl CAMIOCOMMAND): INQUIRY; depois o repasse NVMe do Realtek RTL9210 (comando SCSI de fabricante 0xE4,
  como o smartmontools "sntrealtek"): Identify (modelo) e log SMART pagina 2 (bytes 1-2 = temperatura em kelvin).
  Tudo so leitura; o da* e aberto so para leitura.
- Mesmo botao le os canais 0..7 de `sceKernelGetSocSensorTemperature` (hoje so 0 = SoC e 2 = M.2 sao conhecidos),
  para descobrir se existe canal do SSD interno separado do slot de expansao.
- Resultado completo em "Detalhes (para enviar)" e no log (linhas `ssd usb:`). No PC o resultado e simulado.
- ❓ Nao testado no PS5: nao se sabe se o payload enxerga /dev/pass* ou se o CCB do PS5 tem o mesmo tamanho.

## 0.9.7-teste (11/11/2026): busca de jogo por nome ou codigo
- Campo "Buscar jogo (nome ou codigo)" no topo da barra Ordenar/Filtros (linha inteira; no celular, a primeira). Filtra
  a lista na hora (150 ms depois de digitar), dentro do filtro escolhido (Encontrados/Todos...), junto com os outros
  filtros; o contador mostra "N de M". Procura no nome do arquivo, no nome certo (o novo), no codigo (PPSA/CUSA) e no
  nome da base; todas as palavras precisam aparecer; sem diferenca de acento e maiuscula; "_", "-" e "." contam como
  espaco. So na pagina (web/index.html); pt-BR, en, es.

## 0.9.6-teste (11/11/2026): YouTube na Jobe
- Os dois botoes YouTube (caixa da janela Apps e o de cada jogo) abrem a Jobe (PPSA99471) quando ela esta instalada
  (/data/homebrew/PPSA99471, /user/app ou /user/appmeta) e anuncia a capacidade em
  `/data/JobeesLair/tube/jobe-tube.txt` (gravado pela Jobe, linha `api=1`). O glibren grava
  `/data/JobeesLair/tube/abrir.txt` (UTF-8, .tmp + rename, cria a pasta se faltar, 0666): linha 1 = busca (ate 200
  bytes sem partir caractere; vazia so na caixa da janela Apps), linha 2 = `voltar=PMGL00001`, sem 
 no fim; e abre
  a Jobe com as mesmas regras (nunca por cima de app de jogo aberto: `app_aberto`, nada gravado). A Jobe volta ao
  glibren sozinha (/switch do payload dela).
- Sem a Jobe com capacidade: como na 0.9.5 (ytps5 / Max'd); sem nenhum: aviso de instalar.
- `/api/apps` ganha `youtube_destino` ("jobe", "maxd" ou ""); a linha embaixo da busca diz "Abre na Jobe" / "Abre no
  YouTube Max'd" (pt-BR, en, es). Teste no PC: `GLR_TESTE_JOBE` = pasta no lugar de /data/JobeesLair
  (`testes/teste_apps.sh`, 23 casos novos).

## 0.9.5-teste (11/11/2026): YouTube Max'd com volta ao glibren
- Janela Apps: botao "YouTube" abre o YouTube Max'd (PPSA99991) na busca digitada (ou vazia); glibren_busca.txt
  ganha a 2a linha `voltar=PMGL00001`, e o Max'd (1.6.0-glibren3 ou mais nova) mostra "Voltar ao glibren".
- Nunca lanca por cima de outro app: com um app de jogo aberto (ex.: Jobe) os botoes YouTube recusam com aviso
  (`app_aberto`); a pagina no navegador do PS5 nao conta (`src/lancador.c`).
- `POST 127.0.0.1:8765/launch` {"title","from"} (so local, lista fechada de titulos): responde na hora, espera o
  `from` fechar, ~15 s, e reabre com ate 4 tentativas; `GET /api/launch` mostra o estado.
- O catalogo assinado (apps.json) passa a oferecer o Max'd 1.6.0-glibren3. APK glibren Controle nao mudou.

## 0.9.4-teste (10/11/2026): botao ATIVAR
- Jogo "so armazenado" (com codigo no nome, fora das pastas do ShadowMount, sem copia ativa de outro arquivo do
  mesmo jogo, sem nada na fila para ele; patch/backport, oculto e download em andamento ficam sem) ganha o botao
  ATIVAR ao lado do selo. Tocar: o PS5 escolhe o destino e copia (o original fica); a linha troca o botao pelo selo
  "Ativando" que ja existia (mesma altura) e o painel Atividade mostra a copia.
- `POST /api/ativar` (`src/api.c` rota_ativar): destino = entre as pastas marcadas (fora a de origem) que existem
  (disco ligado), a de mais espaco livre depois do que a fila ja prometeu para ela (`tarefas_reservado`); precisa
  caber o arquivo + 512 MB de folga. Mesmo nome ja numa pasta do ShadowMount = "ja ativo" (nunca sobrescreve).
  Erros com chave: ativar_sem_pasta, ativar_sem_espaco (precisa/maior em bytes), ativar_ja_ativo, ativar_na_fila,
  ativar_origem, ativar_sem_disco. Diario: `ativar: <nome> de <pasta> para <destino> (precisa ..., livre ...)`.
- O APK glibren Controle so abre a pagina do PS5: nao mudou. `testes/teste_ativar.sh` (21 casos, discos tmpfs).

## 0.9.3-teste (10/11/2026): relogio do PS5 pela internet e config v2 do ShadowMountPlus

- **Relogio** (`src/relogio.c`): o aviso "relogio do PS5 X diferente" da janela Apps (os apps de YouTube nao
  conectam com a hora errada) agora se resolve sozinho. Uma thread confere ao iniciar (20 s depois), a cada 6 h e
  20 s depois de voltar do repouso (SIGCONT); a janela Apps tambem pede uma conferencia quando ve diferenca > 10 min.
  - Fontes, um voto cada: NTP (SNTP v4, UDP 123) pelo IP - Cloudflare 162.159.200.1/.123, NTP.br a/b/d.st1
    (200.160.7.186, 201.49.148.135, 200.20.186.76), Google 216.239.35.0/.4/.8 - e o cabecalho Date de
    https://speed.cloudflare.com/__down?bytes=0 (reserva raw.githubusercontent.com; `https_data` em https.c).
    Resposta fora de 2025..2040, stratum 0/16, originate diferente ou atraso > 3 s e ignorada.
  - Regra: maioria das fontes validas e pelo menos 2 concordando a menos de 3 s; acerta se a diferenca passar de
    30 s. Fontes discordando, uma so ou nenhuma: nao mexe e tenta de novo em 10 min.
  - Acerto no PS5 (receita dos payloads abertos uzergit/ps5-time-sync e Zubastic/PS5-Sync-Clock): authid
    0x4800000000010003 por um instante, `clock_settime` nos dominios 17 (rede/NP) e 16 (usuario), `settimeofday`
    (reserva `clock_settime(CLOCK_REALTIME)`), volta o authid. Depois confere com um NTP de novo. Tudo no diario
    (valores antes, retorno e errno de cada chamada). So a hora UTC muda; o fuso e o do PS5
    (`sceKernelConvertUtcToLocaltime`, mostrado na pagina; em pt-BR avisa se nao for UTC-03:00).
  - Pagina Temperatura: cartao Relogio (Acertar sozinho / Desligado, Conferir, ultimo resultado numa linha so).
    `GET /api/relogio`, `POST /api/relogio auto=1|0` (grava `<dados>/relogio.ini`), `POST /api/relogio/conferir`.
  - PC: o relogio do sistema nunca muda; o do "PS5" e simulado (`GLR_TESTE_RELOGIO_DESVIO`), fontes de teste
    `GLR_TESTE_RELOGIO_NTP=ip:porta,...` e `GLR_TESTE_RELOGIO_HTTP=url`. `testes/teste_relogio.sh` (37 casos).
- **ShadowMountPlus config v2** (`src/smp_config.c`): a porta/IP da API sao lidos do formato antigo
  (`api_port`/`api_bind_address`) e do novo (`[api]` com `port`/`bind_address`, so dentro da secao).
  `testes/teste_smp_config.sh` (13 casos, com sanitizers).

## 0.9.2-teste (09/11/2026): filtro do ShadowMount e mostrar arquivos .complete

- Filtro "🎮 ShadowMount" na barra (ao lado de PS4/PS5/exFAT/pkg), so com alguma pasta marcada como do ShadowMount;
  combina com os outros filtros e o contador como os grupos que ja existiam (dentro do grupo OU, entre grupos E).
  **Decisao**: "Ativos" = arquivo numa pasta do ShadowMount (com ou sem codigo no nome); "So armazenados" = fora
  dessas pastas e sem copia ativa (sem codigo no nome conta como armazenado). "Tem copia ativa" nao entra em nenhum
  dos dois (e uma copia guardada de algo que ja esta ativo); download em andamento tambem nao.
- Arquivos `.complete` continuam ocultos sozinhos, mas agora tem botao Mostrar (na linha e em lote). A escolha fica
  no PS5: lista `show = nome` no config.ini, gravada por `POST /api/mostrados` (lista inteira, como /api/ocultos;
  so aceita nomes terminados em .complete, mesmos limites de /api/ocultos: 512 nomes, 299 bytes, sem "/"), e
  `"mostrados"` em /api/estado. Ocultar um .complete mostrado so o tira de `show` (volta ao oculto automatico, nao
  vai para `hide`). Testes: teste_api com 8 casos novos.

## 0.8.3-teste (04/11/2026 noite): diagnostico dos apps de YouTube

- Teste da 0.8.2 no PS5: os apps abrem, mas **nenhum acha video** (inicio vazio e busca vazia, sem mensagem).
  Zips iguais aos oficiais (so o eboot.bin muda). Suspeita principal: relogio do PS5 errado - o ytps5 usa curl com
  CURLOPT_CAINFO=/system/common/cert/CA_LIST.cer, e certificado "ainda nao valido"/"expirado" derruba tudo.
- Janela Apps: compara a hora do PS5 (campo "agora" em /api/apps) com a de quem esta vendo (celular/PC) e avisa
  acima de 10 min. Botao "Ver log do app" -> /app-log?id=ytps5: hora do PS5 + final do yt.log do ytps5
  (/mnt/sandbox/PPSA99350_000/download0/hui/dev/yt.log, so com o app aberto). Max'd nao grava log em arquivo.

## 0.8.2-teste (04/11/2026 noite): apps nao abriam, atualizacao nao ficava, desinstalar, .exfat.complete

- **Apps nao abriam** (ytps5 e YouTube Max'd, nem pelo icone nem pelo botao YouTube): o instalador extraia com
  0644/0755 e o PS5 so abre app com tudo **0777** (como chega por FTP); senao "Nao e possivel iniciar o jogo ou
  app" (CE-107750-0, criacao do processo da EACCES). Fonte: comentarios do autoatualizador do proprio ytps5
  (`tooling/self-update-helper/updater.cpp` e `archive.cpp`). Agora: tudo 0777 + dono 0 antes de colocar no lugar;
  apps instalados pela 0.8/0.8.1 sao reparados ao abrir a janela Apps e antes do botao YouTube abrir o app.
- **Desinstalar** na janela Apps: `POST /api/v1/games/uninstall` na API do ShadowMountPlus (127.0.0.1:10101,
  porta/IP lidos de /data/shadowmount/config.ini) e depois apaga /data/homebrew/<TID>. App aberto (game_active):
  nao apaga nada. ShadowMountPlus com outro erro: apaga a pasta e pede de novo (pasta ausente = ele sincroniza).
  Sem a API: apaga e avisa que o icone some na proxima busca dele ou ao reiniciar.
- **Atualizacao voltava para a versao antiga** ao abrir o payload de novo: o autoloader/PC manda sempre o mesmo
  .elf antigo; a versao nova so ficava em /data/GameLibraryRenamer/glibren.elf. Agora a atualizacao grava tambem o
  .sig, e ao iniciar o payload confere esse arquivo: assinatura valida e versao (marcador `GLIBREN-VERSAO:`) mais
  nova -> envia ao elfldr e sai. Trava `passou_a_vez` evita repetir se a nova nao subir. Vale a partir da 0.8.2:
  quem esta na 0.8.1 precisa trocar uma vez o .elf do autoloader.
- **`.exfat.complete`**: extensao dupla preservada no nome novo; renomeado pelo metodo antigo (codigo no nome +
  base/site), sem leitura de dentro do arquivo.
- **Ordem da lista**: primeiro o que precisa renomear (ordem das pastas); tudo com nome certo (ao conectar ou
  renomeado agora) embaixo, em ordem alfabetica.
- Testes: teste_apps 72/72 (permissoes, reparo, desinstalar com ShadowMountPlus falso: ok/app aberto/ocupado/sem
  API, versao gravada assumindo ao iniciar), teste_api 31/31, teste_tarefas 20/20, teste_jogo_local 18/18.

## Objetivo

Um payload `.elf` que roda no proprio PS5 (enviado pelo elfldr, porta 9021) e faz o mesmo que o app de PC,
sem FTP:

- abre um servidor web no PS5 (porta **8765**); a tela e a mesma pagina do app, aberta no navegador do PC,
  do celular ou do proprio PS5 em `http://IP-DO-PS5:8765`;
- **gerenciador de arquivos**: navegar pelas pastas do PS5 e escolher quais entram na lista de pastas
  (substitui a parte de FTP/IP/porta/usuario/senha/INI);
- o resto igual ao app atual: le a raiz das pastas escolhidas so quando a tela abre ou o usuario clica
  para atualizar (decisao do usuario: "igual hoje", sem vigiar nem renomear sozinho), mostra nome, capa,
  tamanho, novo nome, filtros, Renomear / Renomear todos, idiomas pt-BR/en/es, Loja/YouTube.

Decisoes do usuario (03/11/2026): app de PC e Android ficam como estao por enquanto; monitoramento
"igual hoje"; compilacao com **WSL** (instalado pelo usuario, faltava reiniciar o PC).

## Como e feito um payload (pesquisa)

- SDK: https://github.com/ps5-payload-dev/sdk (v0.45, 21/10/2026). So compila em Linux/macOS
  (clang-18 + lld-18). Instalacao: baixar `ps5-payload-sdk.zip` da release e descompactar em
  `/opt/ps5-payload-sdk`; `export PS5_PAYLOAD_SDK=/opt/ps5-payload-sdk`.
- Makefile: `include $(PS5_PAYLOAD_SDK)/toolchain/prospero.mk`; `$(CC) $(CFLAGS) -o x.elf ...`;
  envio: `$(PS5_DEPLOY) -h $(PS5_HOST) -p 9021 x.elf` (ou `nc -q0 IP 9021 < x.elf`).
- Libc estilo FreeBSD: sockets, pthread, `opendir/readdir/stat/rename`, `getifaddrs` (o ftpsrv usa
  para descobrir o IP e mostrar na notificacao).
- Notificacao na tela do PS5: `sceKernelSendNotificationRequest(0, &req, sizeof req, 0)` com struct
  `{ char useless1[45]; char message[3075]; }` (igual ao ftpsrv `notify.c`).
- Permissoes: o ftpsrv chama `kernel_set_ucred_authid(getpid(), 0x4801000000000013L)`; o exemplo
  `list_files` troca o rootdir (`kernel_set_proc_rootdir(pid, kernel_get_root_vnode())`) para ver o
  sistema de arquivos inteiro. Confirmar no PS5 qual dos dois e preciso para ler /data e /mnt/ext1.
- HTTPS a partir do payload: bibliotecas do proprio PS5 (`sceNetInit`, `sceSslInit`, `sceHttp2Init`,
  `sceHttp2CreateTemplate`, `sceHttp2CreateRequestWithURL`, `sceHttp2SendRequest`,
  `sceHttp2GetStatusCode`, `sceHttp2ReadData`) — exemplo `samples/http2_get` do SDK.
- Uma copia so: o ftpsrv procura outro processo com o mesmo nome (`sysctl` + `SYS_thr_set_name`) e mata
  antes de subir. Fazer igual.
- Portas ja usadas por outros payloads: 2121 (ftpsrv), 8080 (websrv), 9021 (elfldr), 1337 (etaHEN FTP).

## Arquitetura proposta

O payload em C fica **fino**; a logica que ja existe em Python vai para o JavaScript da pagina
(roda no navegador de quem abre a tela). Assim o C fica pequeno e facil de manter.

| Parte | Onde roda | O que faz |
|---|---|---|
| Servidor HTTP | payload (C) | serve a pagina embutida no ELF e a API JSON |
| Gerenciador de arquivos | payload (C) | `GET /api/fs?caminho=` lista pastas e arquivos (nome, tipo, tamanho) |
| Pastas e idioma | payload (C) | arquivo de config em `/data/GameLibraryRenamer/` |
| Leitura das pastas | payload (C) | `GET /api/escanear`: arquivos da raiz de cada pasta, com tamanho |
| Regras (compactado, patch, download em andamento, codigo no nome) | pagina (JS) | portadas de `ftp_ps5.py` |
| Renomear | payload (C) | `POST /api/renomear` com as mesmas travas: origem existe, destino nao existe, nome seguro, nao e download em andamento, tamanho nao mudou |
| Base de titulos (All_Titles.tsv, ~6 MB) | payload baixa (HTTPS) e guarda no PS5; a pagina carrega e consulta | atualiza 1x por dia |
| Nome novo (`nome_para_arquivo`) e limite do ShadowMountPlus | pagina (JS) | portado de `consulta_ps5.py` |
| Publisher, icone (prosperopatches/orbispatches/PS Store) | payload busca por HTTPS, so nesses sites (lista fixa) | icones guardados no PS5 |
| Loja / YouTube | pagina | links normais, abrem no navegador de quem esta usando |

Teste sem PS5: o mesmo codigo C compila para Linux (WSL) com `Makefile.pc`; a parte de HTTPS usa
`curl` no lugar da sceHttp2 e as "pastas do PS5" sao pastas de teste no WSL.

## Estrutura

```
README.md          documentacao de uso (ingles)
Makefile           build PS5 (make) e Linux/WSL para teste (make pc); paginas embutidas com xxd + gzip
compilar.sh        compila no WSL fora do Google Drive e copia para saida/
src/               servidor HTTP, API, arquivos, tarefas, termico, sistema, discos, internet, https, config
web/               paginas (index, temperatura, discos, internet, youtube) e icone
instalador/        glibren-install.elf: icone na aba Midia (PMGL00001)
testes/            demo, testes da API e da fila, comparacao da regra de nome
docs/              estas notas, ideias e capturas de tela
```

## Feito na 0.1-teste

- `src/http.c` servidor HTTP (thread por conexao); `src/api.c` rotas; `src/arquivos.c` gerenciador de arquivos,
  leitura das pastas e renomear (travas: nome seguro, origem existe, destino nao existe — exFAT: mesma inode pode,
  download em andamento, tamanho mudou); `src/config.c` config.ini (language + folder=); `src/https.c` sceHttp2
  no PS5 / curl no PC, so hosts da lista fixa; `src/plataforma.c` notificacao, IP, rootdir; `src/main.c`
  (segunda copia pede /api/sair para a antiga e assume a porta).
- `web/index.html`: copia da tela do PC sem FTP; gerenciador de arquivos (modal), POST como formulario + cabecalho
  X-GLR (bloqueia outros sites), consulta (base TSV lida pela tela, site via /api/web, cache no PS5 via /api/cache),
  icones via /icone/CODIGO?url=&url2= (site, reserva PS Store; falha = 5 min sem tentar), links Loja/YouTube abrem
  em aba nova. Sem lookbehind no JS (navegador do PS5 pode ser antigo). Aba Consulta manual removida (pedido do usuario).

## Pendencias / riscos

- Seguranca: qualquer aparelho da rede local pode abrir a pagina e renomear (como o FTP sem senha hoje).
  Avaliar um PIN opcional.
- Testar no PS5 real: permissoes de pasta (rootdir), HTTPS (sceHttp2: assinatura do Init com 4 conexoes,
  sem tempo limite configurado — funcoes sceHttp2Set*TimeOut existem mas sem assinatura documentada; downloads
  do PS5 estao serializados por um mutex), notificacao, navegador do PS5 (JS moderno: ??=, ?., \p{M}).

## Ambiente (feito em 03/11/2026)

WSL com Ubuntu-24.04 (instalado com `wsl --install -d Ubuntu-24.04 --no-launch`, usado como root, sem usuario
criado); clang-18, lld-18, make, curl, xxd, rsync; SDK v0.45 em /opt/ps5-payload-sdk. Do Git Bash, chamar o
wsl com `MSYS_NO_PATHCONV=1` (senao o caminho /mnt/... vira C:/Program Files/Git/mnt/...).

## Proximos passos

1. Usuario testa o `.elf` no PS5 e relata (notificacao, endereco, pastas, base, icones, renomear).
2. Ajustar o que falhar no PS5 (provavel: permissoes/rootdir, sceHttp2).
3. Depois: tempo limite no sceHttp2, PIN opcional, atalho no controle durante o jogo (ver IDEIAS.md),
   servir a base de titulos compactada, publicar (so com ordem).
