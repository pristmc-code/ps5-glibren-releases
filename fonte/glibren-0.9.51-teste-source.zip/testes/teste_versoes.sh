#!/bin/bash
# 0.9.37: versao de cada jogo e resultados da consulta a Sony feita pelo celular/PC (src/versoes.c), na versao de PC.
# 0.9.38: resultado de PS4 (CUSA, consultado pelo celular/PC no servidor do PS4) tambem guardado e mostrado.
# Casos: versao/firmware/versionJsonUri lidos do param.json (PS5) e do param.sfo (PS4), endereco fora do servidor da Sony
# ignorado, PS4 sem endereco, /api/local com versao, GET /api/versoes (jogos + firmware do console + resultados),
# POST /api/versoes (X-GLR + pareamento; valida titleId/versao/firmware; troca o do mesmo jogo), arquivo versoes.json
# (sobrevive a reabrir), ?resultados=1 sem reler as pastas, e a regra fixa: o PS5 nunca fala com a Sony (nenhum host da
# Sony nas listas do https.c/dns_resolver.c; versoes.c nao usa https). No fim, a pagina (Playwright do Windows, se houver).
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_versoes.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8921
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R="http://$IP:$PORTA"
T=/root/glr-versoes; DADOS=$T/dados; H=$T/homebrew
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
codigo() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
post() { curl -s -H 'X-GLR: 1' -H 'Content-Type: application/json' --data-binary "$1" $L/api/versoes; }
jogo() { curl -s $L/api/versoes | python3 -I -c '
import json, sys
d = json.load(sys.stdin)
j = [x for x in d["jogos"] if x["caminho"].endswith("/" + sys.argv[1])]
print(json.dumps(j[0], ensure_ascii=False, separators=(",", ":")) if j else "")' "$1"; }
liga() { GLR_TESTE_FW=12.00 GLR_TESTE_RAIZES="$T" "$BIN" -p $PORTA -d "$DADOS" >> "$T/glr.log" 2>&1 & PID=$!; sleep 1; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }

rm -rf "$T"; mkdir -p "$DADOS" "$H" "$T/BACKUP/x"
printf 'language = pt-BR\nfolder = %s/\nfolder = %s/\n' "$H" "$T/BACKUP/x" > "$DADOS/config.ini"
pasta_ps5() {   # pasta nome tid versao fw uri
  mkdir -p "$H/$1/sce_sys"; echo elf > "$H/$1/eboot.bin"
  printf '{"titleId":"%s","contentVersion":"%s","requiredSystemSoftwareVersion":%s,"versionJsonUri":"%s","localizedParameters":{"defaultLanguage":"en-US","en-US":{"titleName":"%s"}}}' \
    "$2" "$3" "$4" "$5" "$1" > "$H/$1/sce_sys/param.json"
}
URI_SAROS="https://sgst.prod.dl.playstation.net/sgst/prod/00/np/PPSA07632_00/0f5e1a2b-3c4d-4e5f-8a9b-0c1d2e3f4a5b-version.xml"
pasta_ps5 Saros PPSA07632 01.000.002 '"0x1040000000000000"' "$URI_SAROS"
pasta_ps5 EmDia PPSA01111 01.000.010 '"0x0450000000000000"' "https://sgst.prod.dl.playstation.net/sgst/prod/00/np/PPSA01111_00/abc-version.xml"
pasta_ps5 Malicioso PPSA02222 01.000.000 '"0x0700000000000000"' "http://evil.example/x-version.xml"
pasta_ps5 Numero PPSA03333 02.001.000 335544320 "https://sgst.prod.dl.playstation.net/../etc/passwd"
mkdir -p "$H/Ps4Jogo/sce_sys"; echo elf > "$H/Ps4Jogo/eboot.bin"
python3 -I "$ORIGEM/testes/gerar_sfo.py" "$H/Ps4Jogo/sce_sys/param.sfo" TITLE_ID=CUSA06666 "TITLE=Jogo PS4" CATEGORY=gd APP_VER=01.05 VERSION=01.00 SYSTEM_VER=0x05050000
mkdir -p "$H/NaoJogo"; echo x > "$H/NaoJogo/leia.txt"
mkdir -p "$T/BACKUP/x/Velho/sce_sys"; echo elf > "$T/BACKUP/x/Velho/eboot.bin"; cp "$H/Saros/sce_sys/param.json" "$T/BACKUP/x/Velho/sce_sys/"
liga

echo "--- lista de jogos com a versao local"
J=$(jogo Saros)
confere "PS5: titleId"                     "$J" '"titleId":"PPSA07632"'
confere "PS5: versao local"                "$J" '"versao_local":"01.000.002"'
confere "PS5: firmware minimo 10.40"       "$J" '"fw_local":"10.40"'
confere "PS5: versionJsonUri"              "$J" "\"versionJsonUri\":\"$URI_SAROS\""
confere "PS5: plataforma"                  "$J" '"plataforma":"PS5"'
confere "firmware 4.50"                    "$(jogo EmDia)" '"fw_local":"4.50"'
J=$(jogo Malicioso)
confere "endereco de fora: jogo listado"   "$J" '"titleId":"PPSA02222"'
nao_tem "endereco de fora: sem versionJsonUri" "$J" 'versionJsonUri'
J=$(jogo Numero)
confere "firmware em numero (0x14000000)"  "$J" '"fw_local":"14.00"'
nao_tem "endereco com ..: recusado"        "$J" 'versionJsonUri'
J=$(jogo Ps4Jogo)
confere "PS4: maior entre APP_VER e VERSION" "$J" '"versao_local":"01.05"'
confere "PS4: SYSTEM_VER 5.05"             "$J" '"fw_local":"5.05"'
confere "PS4: plataforma"                  "$J" '"plataforma":"PS4"'
nao_tem "PS4: sem versionJsonUri"          "$J" 'versionJsonUri'
TODOS=$(curl -s $L/api/versoes)
nao_tem "pasta sem jogo fora"              "$TODOS" 'NaoJogo'
nao_tem "pasta no BACKUP fora"             "$TODOS" 'Velho'
confere "firmware do console"              "$TODOS" '"fw_console":"12.00"'
confere "sem resultados ainda"             "$TODOS" '"resultados":\[\]'
confere "/api/local com versao"            "$(curl -s "$L/api/local?pasta=$H&nome=Saros")" '"versao":"01.000.002","fw_local":"10.40"'

echo "--- gravar resultados (so pareado)"
CORPO='{"resultados":[{"titleId":"PPSA07632","versao_nova":"02.000.003","fw_exigido":"14.20","tamanho":123456789,"consultado_em":1795000000,"outra_versao":"02.000.002","outro_fw":"13.00"},{"titleId":"PPSA01111","versao_nova":"01.000.010","fw_exigido":"4.50","consultado_em":1795000000},{"titleId":"PPSA09999","erro":"HTTP 403","consultado_em":1795000000},{"titleId":"ppsa1","versao_nova":"1.0"},{"titleId":"PPSA04444","versao_nova":"1.0<b>"},{"titleId":"PPSA05555","versao_nova":"01.000.000","fw_exigido":"14.2x"},{"titleId":"PPSA06666"}]}'
confere "sem X-GLR: 403"                   "$(codigo -H 'Content-Type: application/json' --data-binary "$CORPO" $L/api/versoes)" "403"
confere "de outro aparelho sem par: 401"   "$(codigo -H 'X-GLR: 1' --data-binary "$CORPO" $R/api/versoes)" "401"
confere "corpo sem resultados: 400"        "$(codigo -H 'X-GLR: 1' --data-binary '{}' $L/api/versoes)" "400"
confere "JSON quebrado: 400"               "$(codigo -H 'X-GLR: 1' --data-binary '{"resultados":[{"titleId":' $L/api/versoes)" "400"
confere "gravou 3, recusou 4"              "$(post "$CORPO")" '"gravados":3,"recusados":4'
R1=$(curl -s "$L/api/versoes?resultados=1")
nao_tem "?resultados=1 sem jogos"          "$R1" '"jogos"'
confere "resultado guardado"               "$R1" '"titleId":"PPSA07632","versao_nova":"02.000.003","fw_exigido":"14.20","outra_versao":"02.000.002","outro_fw":"13.00","tamanho":123456789,"consultado_em":1795000000'
confere "erro guardado"                    "$R1" '"titleId":"PPSA09999","consultado_em":1795000000,"erro":"HTTP 403"'
nao_tem "versao com <b> recusada"          "$R1" 'PPSA04444'
confere "arquivo versoes.json"             "$(cat $DADOS/versoes.json)" '"PPSA07632"'
confere "troca o do mesmo jogo"            "$(post '{"resultados":[{"titleId":"PPSA01111","versao_nova":"01.000.011","fw_exigido":"5.00"}]}')" '"gravados":1'
R1=$(curl -s "$L/api/versoes?resultados=1")
confere "trocado (sem consultado_em = agora)" "$R1" '"titleId":"PPSA01111","versao_nova":"01.000.011","fw_exigido":"5.00","consultado_em":1[0-9]\{9\}'
confere "um por jogo"                      "$(echo "$R1" | grep -o 'PPSA01111' | wc -l)" '^1$'
post '{"resultados":[{"titleId":"PPSA01111","versao_nova":"01.000.010","fw_exigido":"4.50","consultado_em":1795000000}]}' > /dev/null
confere "0.9.38: resultado de PS4 (CUSA)"   "$(post '{"resultados":[{"titleId":"CUSA06666","versao_nova":"01.06","fw_exigido":"5.50","tamanho":2560491520,"consultado_em":1795000000}]}')" '"gravados":1'
para; liga
confere "reaberto: resultados continuam"   "$(curl -s "$L/api/versoes?resultados=1")" '"titleId":"PPSA07632","versao_nova":"02.000.003"'
confere "diario"                           "$(cat $T/glr.log $DADOS/glibren.log 2>/dev/null)" 'versoes: 3 resultado'

echo "--- o PS5 nunca fala com a Sony"
HOSTS=$(sed -n '/static const char \*HOSTS\[\]/,/NULL};/p' "$ORIGEM/src/https.c")
ROBUSTOS=$(sed -n '/ROBUSTOS\[\] = {/,/NULL};/p' "$ORIGEM/src/dns_resolver.c")
confere "lista do https.c lida"            "$HOSTS" 'api.github.com'
nao_tem "https.c: nenhum host da Sony"     "$HOSTS" 'playstation\|sony\|psn\|scea'
confere "lista do dns_resolver.c lida"     "$ROBUSTOS" 'api.github.com'
nao_tem "dns_resolver.c: nenhum host da Sony" "$ROBUSTOS" 'playstation\|sony\|psn\|scea'
confere "DNS do payload recusa o servidor de versoes" "$(curl -s "$L/api/dns?host=sgst.prod.dl.playstation.net")" '"fonte":"fora_da_lista"'
nao_tem "versoes.c sem https"              "$(grep -n 'https\|socket\|connect(' "$ORIGEM/src/versoes.c" | grep -v '^[0-9]*:\s*\(/\*\|\*\)')" 'https_\|socket(\|connect('
confere "versionJsonUri so em leitura/lista" "$(grep -l 'version_uri' "$ORIGEM"/src/*.c | xargs -n1 basename | sort | tr '\n' ' ')" '^fmt_param.c versoes.c $'
confere "/api/web recusa o host da Sony"   "$(codigo "$L/api/web?url=https://sgst.prod.dl.playstation.net/sgst/prod/00/np/PPSA07632_00/x-version.xml")" "403"
nao_tem "diario sem pedido a Sony"         "$(cat $T/glr.log $DADOS/glibren.log 2>/dev/null)" 'sgst\.prod'

para

# Pagina no Chromium/Edge do Windows, se houver
NODE_WIN="/mnt/c/Program Files/nodejs/node.exe"
LAD=$(cmd.exe /c 'echo %LOCALAPPDATA%' 2>/dev/null | tr -d '\r')
PW=""; [ -n "$LAD" ] && PW=$(ls -d "$(wslpath "$LAD")"/npm-cache/_npx/*/node_modules/playwright 2>/dev/null | head -1)
if [ -x "$NODE_WIN" ] && [ -n "$PW" ]; then
  liga
  SAIDA=$("$NODE_WIN" "$(wslpath -w "$ORIGEM/testes/teste_versoes_pagina.mjs")" "$L" "$(wslpath -w "$PW")" 2>&1)
  echo "$SAIDA"
  ok=$((ok + $(echo "$SAIDA" | grep -c '^OK '))); falhas=$((falhas + $(echo "$SAIDA" | grep -c '^FALHA')))
  echo "$SAIDA" | grep -q '^=== pagina' || { falhas=$((falhas+1)); echo "FALHA pagina: o script nao terminou"; }
  para
else
  echo "PULADO: teste da pagina (sem node.exe ou Playwright no Windows)"
fi
echo "=== $ok ok, $falhas falhas"
[ $falhas -eq 0 ]
