"""Gera um param.sfo de PS4 pequeno para os testes (formato em src/fmt_param.c).
   python3 gerar_sfo.py <saida> TITLE_ID=CUSA06666 TITLE=Nome APP_VER=01.05 VERSION=01.00 SYSTEM_VER=0x05050000
Valores com SYSTEM_VER (ou qualquer chave terminada em _VER que comece com 0x) viram inteiro de 32 bits (fmt 0x0404);
os outros, texto UTF-8 com NUL (fmt 0x0204)."""
import struct
import sys


def gerar(itens):
    itens = sorted(itens.items())
    chaves = b""
    dados = b""
    tabela = b""
    for k, v in itens:
        off_k = len(chaves)
        chaves += k.encode() + b"\0"
        if k == "SYSTEM_VER" or (isinstance(v, str) and v.startswith("0x")):
            valor = struct.pack("<I", int(v, 16))
            fmt, tam, maximo = 0x0404, 4, 4
        else:
            valor = v.encode() + b"\0"
            fmt, tam = 0x0204, len(valor)
            maximo = (tam + 3) // 4 * 4
            valor = valor.ljust(maximo, b"\0")
        tabela += struct.pack("<HHIII", off_k, fmt, tam, maximo, len(dados))
        dados += valor
    while len(chaves) % 4:
        chaves += b"\0"
    inicio_chaves = 0x14 + len(tabela)
    inicio_dados = inicio_chaves + len(chaves)
    cab = b"\0PSF" + struct.pack("<IIII", 0x101, inicio_chaves, inicio_dados, len(itens))
    return cab + tabela + chaves + dados


if __name__ == "__main__":
    pares = dict(a.split("=", 1) for a in sys.argv[2:])
    open(sys.argv[1], "wb").write(gerar(pares))
