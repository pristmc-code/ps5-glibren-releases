#!/bin/bash
# 0.9.41: instalar .pkg pelo Dump Forge (POST /api/conversao/instalar) na versao de PC, com o Dump Forge FALSO
# (testes/dumpforge_falso.py, modo de instalacao em <df>/modo_inst). Casos: Dump Forge ausente (503 dumpforge_fora),
# pareamento/X-GLR, recusas (nao e .pkg, cabecalho errado, nao existe, fora das pastas, ja na fila), pedido igual ao
# installRequest() do Dump Forge v0.5.6 (install = caminho; source/output vazios; nada de delete_source), PS4 x PS5 pelo
# cabecalho, um por vez (fila "espera" no glibren; o Dump Forge falso anota sobreposicao), aceito ("feito"), recusado com
# codigo conhecido e desconhecido, recusa no start_job, cancelar na fila do glibren e no Dump Forge, Dump Forge que fecha
# ("perdido"), o .pkg nunca sai do lugar, firmware no estado. No fim, se houver Node + Playwright no Windows, roda
# testes/teste_instalacao_pagina.mjs (botao Instalar, pergunta e janela em 360 e 1280).
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_instalacao.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8961; PORTA_DF=8962
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R="http://$IP:$PORTA"
T=/root/glr-instalacao; DADOS=$T/dados; A=$T/lista
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$(echo "$2" | head -c 700)] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
codigo() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
estado() { curl -s "$L/api/conversao"; }
pedidos_inst() { grep -c '"install"' "$T/df/pedidos.jsonl" 2>/dev/null || echo 0; }
# o item de instalacao do .pkg (pelo nome), como JSON de uma linha
item() { estado | python3 -c "import json,sys; d=json.load(sys.stdin); print(json.dumps([i for i in d['itens'] if i['instalar'] and i['origem'].endswith('/$1')][0]))"; }
# consulta o estado ate o item chegar no estado pedido (cada consulta anda um passo no Dump Forge falso)
espera() { espera_re "$1" "\"estado\": \"$2\""; }
espera_re() { local v=""; for _ in $(seq 1 40); do v=$(item "$1" 2>/dev/null); echo "$v" | grep -q -- "$2" && break; sleep 0.1; done; echo "$v"; }
liga_df() { (exec python3 -I "$ORIGEM/testes/dumpforge_falso.py" $PORTA_DF "$T/df") >> "$T/df.log" 2>&1 & PID_DF=$!; for _ in $(seq 1 50); do curl -s -o /dev/null "http://127.0.0.1:$PORTA_DF/api/session" && break; sleep 0.1; done; }
para_df() { kill $PID_DF 2>/dev/null; wait $PID_DF 2>/dev/null; }
pkg() { python3 - "$1" "$2" "$3" <<'EOF'
import sys
caminho, magia, tam = sys.argv[1], sys.argv[2].encode(), int(sys.argv[3])
dados = bytearray(b"\x7f" + magia + b"\0" * (tam - 1 - len(magia)))
open(caminho, "wb").write(dados)
EOF
}

rm -rf "$T"; mkdir -p "$DADOS" "$A" "$T/df"
printf 'language = pt-BR\nfolder = %s/\n' "$A" > "$DADOS/config.ini"
pkg "$A/Jogo5-PPSA01234.pkg" FIH 8192
pkg "$A/Jogo4-CUSA00001.pkg" CNT 4096
pkg "$A/Patch5-PPSA01234.pkg" LIH 2048
printf 'nao e pkg' > "$A/Falso.pkg"
echo dados > "$A/Img-PPSA05555.exfat"
echo ok > "$T/df/modo"; echo ok > "$T/df/modo_inst"
GLR_TESTE_SONDA_S=0 GLR_TESTE_CONV_VIGIA_S=0 GLR_TESTE_FW=12.00 GLR_TESTE_DUMPFORGE_PORTA=$PORTA_DF "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!
for _ in $(seq 1 50); do curl -s -o /dev/null "$L/api/conversao" && break; sleep 0.1; done

echo "--- Dump Forge ausente"
confere "sem Dump Forge: chave"            "$(post -d "pasta=$A/" -d de=Jogo5-PPSA01234.pkg $L/api/conversao/instalar)" '"chave":"dumpforge_fora"'
confere "sem Dump Forge: 503"              "$(codigo -H 'X-GLR: 1' -d "pasta=$A/" -d de=Jogo5-PPSA01234.pkg $L/api/conversao/instalar)" "503"
confere "estado: firmware do PS5"          "$(estado)" '"firmware":"12.00"'

liga_df
echo "--- pareamento e X-GLR"
confere "rede sem pareamento: 401"         "$(codigo -H 'X-GLR: 1' -d "pasta=$A/" -d de=Jogo5-PPSA01234.pkg $R/api/conversao/instalar)" "401"
confere "sem X-GLR: 403"                   "$(codigo -d "pasta=$A/" -d de=Jogo5-PPSA01234.pkg $L/api/conversao/instalar)" "403"

echo "--- recusas e dois na fila (um por vez)"
echo lento > "$T/df/modo_inst"
R1=$(post -d "pasta=$A/" -d de=Jogo5-PPSA01234.pkg -d "pasta=$A/" -d de=Jogo4-CUSA00001.pkg -d "pasta=$A/" -d de=Falso.pkg \
  -d "pasta=$A/" -d de=Img-PPSA05555.exfat -d "pasta=$A/" -d de=nao-existe.pkg -d "pasta=/etc/" -d de=passwd -d "pasta=$A/" -d de=../x.pkg \
  $L/api/conversao/instalar)
confere "2 na fila"                        "$R1" '"criadas":2'
confere "cabecalho errado: nao_pkg"        "$R1" '"nome":"Falso.pkg","motivo":"nao_pkg"'
confere ".exfat: nao_pkg"                  "$R1" '"nome":"Img-PPSA05555.exfat","motivo":"nao_pkg"'
confere "nao existe"                       "$R1" '"nome":"nao-existe.pkg","motivo":"nao_existe"'
confere "fora das pastas"                  "$R1" '"nome":"passwd","motivo":"fora_das_pastas"'
confere "nome invalido"                    "$R1" '"nome":"../x.pkg","motivo":"invalido"'
confere "so 1 pedido ao Dump Forge"        "$(pedidos_inst)" "^1$"
P=$(tail -1 "$T/df/pedidos.jsonl")
confere "pedido: install = o .pkg"         "$P" "\"install\": \"$A/Jogo5-PPSA01234.pkg\""
confere "pedido: source/output vazios"     "$P" '"source": "", "format": "folder", "output": ""'
nao_tem "pedido: sem delete_source"        "$P" 'delete_source'
E1=$(item Jogo5-PPSA01234.pkg); E2=$(item Jogo4-CUSA00001.pkg)
confere "PS5 pelo cabecalho (FIH)"         "$E1" '"plataforma": "PS5"'
confere "PS4 pelo cabecalho (CNT)"         "$E2" '"plataforma": "PS4"'
confere "2o espera a vez"                  "$E2" '"estado": "espera"'
confere "2o sem job ainda"                 "$E2" '"job": 0'
confere "ja na fila: recusado"             "$(post -d "pasta=$A/" -d de=Jogo4-CUSA00001.pkg $L/api/conversao/instalar)" '"criadas":0.*"motivo":"ja_instalando"'
E1=$(espera_re Jogo5-PPSA01234.pkg '"etapa": "install"')
confere "1o entregando (etapa install)"    "$E1" '"etapa": "install", "feitos": 4096, "total": 8192'

echo "--- cancelar: na fila do glibren e no Dump Forge"
ID2=$(echo "$E2" | python3 -c "import json,sys; print(json.load(sys.stdin)['id'])")
ID1=$(echo "$E1" | python3 -c "import json,sys; print(json.load(sys.stdin)['id'])")
J1=$(echo "$E1" | python3 -c "import json,sys; print(json.load(sys.stdin)['job'])")
confere "cancelar o da fila"               "$(post -d id=$ID2 $L/api/conversao/cancelar)" '"ok":true'
confere "da fila: cancelado sem Dump Forge" "$(item Jogo4-CUSA00001.pkg)" '"estado": "cancelado"'
nao_tem "Dump Forge nao recebeu cancel"    "$(cat $T/df/cancelados 2>/dev/null)" "x"
confere "cancelar o que esta no Dump Forge" "$(post -d id=$ID1 $L/api/conversao/cancelar)" '"ok":true'
confere "Dump Forge recebeu o cancel"      "$(cat $T/df/cancelados)" "^$J1$"
confere "cancelado (texto do Dump Forge)"  "$(espera Jogo5-PPSA01234.pkg cancelado)" '"erro": "cancelled; if the PS5 still lists the download'
post -d x=1 $L/api/conversao/limpar > /dev/null

echo "--- aceito: entregue ao instalador, um por vez"
echo ok > "$T/df/modo_inst"
rm -f "$T/df/sobreposto"
post -d "pasta=$A/" -d de=Jogo5-PPSA01234.pkg -d "pasta=$A/" -d de=Jogo4-CUSA00001.pkg -d "pasta=$A/" -d de=Patch5-PPSA01234.pkg $L/api/conversao/instalar > /dev/null
E1=$(espera Jogo5-PPSA01234.pkg feito)
confere "1o entregue"                      "$E1" '"estado": "feito"'
confere "1o: bytes servidos"               "$E1" '"bytes": 8192'
confere "1o: sem BACKUP"                   "$E1" '"backup": ""'
E2=$(espera Jogo4-CUSA00001.pkg feito)
confere "2o entregue depois"               "$E2" '"estado": "feito"'
E3=$(espera Patch5-PPSA01234.pkg feito)
confere "atualizacao de PS5 (LIH)"         "$E3" '"plataforma": "PS5".*"estado": "feito"'
confere "nunca dois ao mesmo tempo"        "$(cat $T/df/sobreposto 2>/dev/null || echo nenhum)" "^nenhum$"
confere "o .pkg continua la"               "$(ls $A)" 'Jogo5-PPSA01234.pkg'
confere "o .pkg igual (8192 bytes)"        "$(stat -c %s $A/Jogo5-PPSA01234.pkg)" "^8192$"
nao_tem "nenhuma pasta BACKUP"             "$(ls $T $A)" 'BACKUP'
confere "diario: entregue"                 "$(cat $DADOS/glibren.log)" 'instalacao: [0-9]* entregue ao instalador do PS5'

echo "--- recusado com codigo"
post -d x=1 $L/api/conversao/limpar > /dev/null
echo codigo > "$T/df/modo_inst"
post -d "pasta=$A/" -d de=Jogo5-PPSA01234.pkg $L/api/conversao/instalar > /dev/null
E1=$(espera Jogo5-PPSA01234.pkg erro)
confere "codigo conhecido"                 "$E1" '"codigo": "0x80A30002"'
confere "texto do Dump Forge"              "$E1" 'not enough free space'
echo desconhecido > "$T/df/modo_inst"
post -d x=1 $L/api/conversao/limpar > /dev/null
post -d "pasta=$A/" -d de=Jogo4-CUSA00001.pkg $L/api/conversao/instalar > /dev/null
confere "codigo desconhecido"              "$(espera Jogo4-CUSA00001.pkg erro)" '"codigo": "0x80B2FFFF"'
echo recusa > "$T/df/modo_inst"
post -d x=1 $L/api/conversao/limpar > /dev/null
R1=$(post -d "pasta=$A/" -d de=Jogo5-PPSA01234.pkg -d "pasta=$A/" -d de=Jogo4-CUSA00001.pkg $L/api/conversao/instalar)
confere "recusa no start_job: criadas"     "$R1" '"criadas":2'
confere "recusa no start_job: erro"        "$(item Jogo5-PPSA01234.pkg)" '"estado": "erro".*not a folder or a regular file'
confere "recusa: o proximo vai logo"       "$(item Jogo4-CUSA00001.pkg)" '"estado": "erro"'

echo "--- conversao e instalacao juntas na lista"
echo ok > "$T/df/modo"; echo lento > "$T/df/modo_inst"
post -d x=1 $L/api/conversao/limpar > /dev/null
post -d formato=ffpkg -d "pasta=$A/" -d de=Img-PPSA05555.exfat $L/api/conversao > /dev/null
post -d "pasta=$A/" -d de=Jogo5-PPSA01234.pkg $L/api/conversao/instalar > /dev/null
E=$(estado)
confere "lista com os dois"                "$E" '"instalar":false.*"instalar":true\|"instalar":true.*"instalar":false'
confere "conversao: id do glibren"         "$E" '"id":[0-9]*,"job":[0-9]*,"instalar":false'

echo "--- Dump Forge fecha no meio"
para_df
estado > /dev/null; estado > /dev/null   # 0.9.41 (revisao): so a 3a consulta seguida sem resposta declara o Dump Forge fechado
E1=$(item Jogo5-PPSA01234.pkg)
confere "perdido"                          "$E1" '"estado": "perdido"'
confere "perdido: texto"                   "$E1" 'a instalacao parou'
liga_df
kill $PID 2>/dev/null; wait $PID 2>/dev/null

# Pagina (botao Instalar, pergunta, janela) no Chromium/Edge do Windows, se houver
NODE_WIN="/mnt/c/Program Files/nodejs/node.exe"
LAD=$(cmd.exe /c 'echo %LOCALAPPDATA%' 2>/dev/null | tr -d '\r')
PW=""; [ -n "$LAD" ] && PW=$(ls -d "$(wslpath "$LAD")"/npm-cache/_npx/*/node_modules/playwright 2>/dev/null | head -1)
if [ -x "$NODE_WIN" ] && [ -n "$PW" ]; then
  echo ok > "$T/df/modo_inst"
  GLR_TESTE_SONDA_S=0 GLR_TESTE_CONV_VIGIA_S=0 GLR_TESTE_FW=12.00 GLR_TESTE_DUMPFORGE_PORTA=$PORTA_DF "$BIN" -p $PORTA -d "$DADOS" > "$T/glr2.log" 2>&1 & PID=$!
  for _ in $(seq 1 50); do curl -s -o /dev/null "$L/api/conversao" && break; sleep 0.1; done
  # um recusado com codigo antes, para a janela mostrar o codigo traduzido
  echo codigo > "$T/df/modo_inst"
  post -d "pasta=$A/" -d de=Patch5-PPSA01234.pkg $L/api/conversao/instalar > /dev/null
  espera Patch5-PPSA01234.pkg erro > /dev/null
  echo ok > "$T/df/modo_inst"
  SAIDA=$("$NODE_WIN" "$(wslpath -w "$ORIGEM/testes/teste_instalacao_pagina.mjs")" "http://127.0.0.1:$PORTA" "$(wslpath -w "$PW")" 2>&1)
  echo "$SAIDA"
  ok=$((ok + $(echo "$SAIDA" | grep -c '^OK '))); falhas=$((falhas + $(echo "$SAIDA" | grep -c '^FALHA')))
  echo "$SAIDA" | grep -q '^=== pagina' || { falhas=$((falhas+1)); echo "FALHA pagina: o script nao terminou"; }
  kill $PID 2>/dev/null; wait $PID 2>/dev/null
else
  echo "PULADO: teste da pagina (sem node.exe ou Playwright no Windows)"
fi
para_df
echo "=== $ok ok, $falhas falhas"
[ $falhas -eq 0 ]
