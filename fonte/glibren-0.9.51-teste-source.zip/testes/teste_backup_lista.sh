#!/bin/bash
# 0.9.49/0.9.50: pasta de backup do glibren em minusculo (<disco>/backup), originais soltos nela, e a lista um nivel
# abaixo (src/backup.c backup_arrumar, src/arquivos.c, src/config.c), na versao de PC. Discos de mentira por
# GLR_TESTE_RAIZES; ShadowMount+ falso (testes/smp_falso.py). 0.9.50 (decisao do usuario): <disco>/BACKUP e da Jobe e o
# glibren NAO renomeia, move nem apaga nada dela por conta propria. Casos:
#   D1 so BACKUP, com conteudo da Jobe e do glibren antigo (subpasta com marcador "source":"glibren"): tudo intacto ao
#      iniciar; a lista mostra o primeiro nivel e um nivel abaixo (com "raiz" e "backup":true), contagem da pasta;
#      acoes PEDIDAS pelo usuario valem: mover de volta para a pasta de jogos e excluir (a subpasta vazia e o marcador
#      saem), renomear; caminhos recusados; config.ini intacto;
#   D2 BACKUP e backup lado a lado: nada passa de uma para a outra; em backup, a subpasta do glibren sobe;
#   D3 so backup: subpasta do glibren sobe (arquivo e pasta de jogo) e some; subpasta da Jobe, sem marcador ou com
#      outra coisa dentro ficam; _temp intacta;
#   D4 "folder = .../backup/" na lista com so BACKUP no disco: a lista passa a usar a grafia que existe;
#   D5 jogo montado pelo ShadowMount+ a partir de backup: as subpastas ficam para depois.
# Disco que nao diferencia caixa (exFAT): nao simulado aqui.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_backup_lista.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8941; PORTA_SMP=8942
L="http://127.0.0.1:$PORTA"
T=/root/glr-bklista; DADOS=$T/dados; D1=$T/d1; D2=$T/d2; D3=$T/d3; D4=$T/d4; D5=$T/d5
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
existe() { if [ -e "$2" ]; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: nao existe $2"; fi; }
sumiu() { if [ -e "$2" ]; then falhas=$((falhas+1)); echo "FALHA $1: ainda existe $2"; else ok=$((ok+1)); echo "OK   $1"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
espera() { for _ in $(seq 1 80); do curl -s $L/api/tarefas | grep -q '"estado":"\(fila\|rodando\)"' || return; sleep 0.25; done; }
ultima() { curl -s $L/api/tarefas | python3 -I -c 'import json,sys; t=json.load(sys.stdin)["tarefas"]; print(json.dumps(max(t, key=lambda x: x["id"]), ensure_ascii=False))'; }
tarefa() { post --data-urlencode "tipo=$1" --data-urlencode "pasta=$2" --data-urlencode "de=$3" --data-urlencode "destino=${4:-}" $L/api/tarefas; }
itens() { curl -s $L/api/escanear | python3 -I -c '
import json, sys
for i in json.load(sys.stdin)["itens"]:
    print(json.dumps(i, ensure_ascii=False, sort_keys=True))'; }
marca() { printf '{"titleId":"%s","platform":"ps5","format":"exfat","source":"%s"}' "$2" "$3" > "$1/.jobe-backup.json"; }
jogo() { mkdir -p "$1/sce_sys"; echo elf > "$1/eboot.bin"; printf '{"titleId":"%s"}' "$2" > "$1/sce_sys/param.json"; }

pkill -f "smp_falso.py $PORTA_SMP" 2>/dev/null
rm -rf "$T"; mkdir -p "$DADOS" "$T/smp" $D1/homebrew $D2/homebrew $D3/homebrew $D4/homebrew $D5/homebrew
# D1: so BACKUP (da Jobe), com subpasta antiga do glibren, subpasta da Jobe, sem marcador e um solto
mkdir -p "$D1/BACKUP/Hades" "$D1/BACKUP/DaJobe" "$D1/BACKUP/SemMarca" "$D1/BACKUP/_temp"
echo hades > "$D1/BACKUP/Hades/Hades-PPSA03355-US-PS5.exfat"; marca "$D1/BACKUP/Hades" PPSA03355 glibren
echo solto > "$D1/BACKUP/Solto-PPSA00001.exfat"
echo jobe > "$D1/BACKUP/DaJobe/x-PPSA00002.pkg"; marca "$D1/BACKUP/DaJobe" PPSA00002 jobe
echo sem > "$D1/BACKUP/SemMarca/y-PPSA00003.exfat"
# D2: as duas lado a lado
mkdir -p "$D2/BACKUP/DaJobe2" "$D2/backup/Meu"
echo jobe-a > "$D2/BACKUP/a-PPSA00010.exfat"; echo jobe-b > "$D2/BACKUP/DaJobe2/b-PPSA00011.pkg"; marca "$D2/BACKUP/DaJobe2" PPSA00011 jobe
echo meu-a > "$D2/backup/a-PPSA00010.exfat"; echo meu-c > "$D2/backup/Meu/c-PPSA00012.exfat"; marca "$D2/backup/Meu" PPSA00012 glibren
# D3: so backup
mkdir -p "$D3/backup/Jogo" "$D3/backup/Pasta" "$D3/backup/DaJobe3" "$D3/backup/SemMarca3" "$D3/backup/Misto/notas" "$D3/backup/_temp"
echo tres > "$D3/backup/Jogo/c-PPSA00020.exfat"; marca "$D3/backup/Jogo" PPSA00020 glibren
jogo "$D3/backup/Pasta/PastaJogo-PPSA05555" PPSA05555; marca "$D3/backup/Pasta" PPSA05555 glibren
echo jobe3 > "$D3/backup/DaJobe3/d-PPSA00021.pkg"; marca "$D3/backup/DaJobe3" PPSA00021 jobe
echo sem3 > "$D3/backup/SemMarca3/e-PPSA00022.exfat"
echo misto > "$D3/backup/Misto/z-PPSA00004.exfat"; echo nota > "$D3/backup/Misto/notas/leia.txt"; marca "$D3/backup/Misto" PPSA00004 glibren
# D4: so BACKUP no disco, "backup" na lista
mkdir -p "$D4/BACKUP"; echo quatro > "$D4/BACKUP/n-PPSA00030.exfat"
# D5: jogo montado a partir de backup
mkdir -p "$D5/backup/Preso"; echo montado > "$D5/backup/m-PPSA00040.exfat"; echo preso > "$D5/backup/Preso/p-PPSA00041.exfat"; marca "$D5/backup/Preso" PPSA00041 glibren
printf 'language = pt-BR\nfolder = %s/\nfolder = %s/\nfolder = %s/\nfolder = %s/\nfolder = %s/\nfolder = %s/\nfolder = %s/\n' \
  "$D1/homebrew" "$D1/BACKUP" "$D2/BACKUP" "$D2/backup" "$D3/backup" "$D4/backup" "$D5/backup" > "$DADOS/config.ini"
python3 -I -c 'import json,sys; json.dump({"games":[{"path":sys.argv[1],"title_id":"PPSA00040","mounted":True}],"images":[]}, open(sys.argv[2],"w"))' \
  "$D5/backup/m-PPSA00040.exfat" "$T/smp/estado.json"
(exec python3 -I "$ORIGEM/testes/smp_falso.py" $PORTA_SMP "$T/smp") >> "$T/smp.log" 2>&1 &
sleep 0.5
GLR_TESTE_SONDA_S=0 GLR_TESTE_SMP_PORTA=$PORTA_SMP GLR_TESTE_PROCESSOS="shadowmountplus.elf" GLR_TESTE_CONV_VIGIA_S=0 \
  GLR_TESTE_RAIZES="$D1:$D2:$D3:$D4:$D5" "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!
for _ in $(seq 1 40); do grep -q "subpastas de $D5/backup ficam para depois" "$DADOS/glibren.log" 2>/dev/null && break; sleep 0.25; done
sleep 0.5
LOG=$(cat "$DADOS/glibren.log")

echo "--- D1: BACKUP e da Jobe: nada muda ao iniciar"
confere "D1: pasta com o mesmo nome"        "$(ls "$D1" | tr '\n' ' ')" '^BACKUP homebrew $'
existe "D1: subpasta antiga do glibren fica" "$D1/BACKUP/Hades/Hades-PPSA03355-US-PS5.exfat"
existe "D1: marcador antigo fica"           "$D1/BACKUP/Hades/.jobe-backup.json"
existe "D1: subpasta da Jobe fica"          "$D1/BACKUP/DaJobe/x-PPSA00002.pkg"
existe "D1: _temp intacta"                  "$D1/BACKUP/_temp"
nao_tem "D1: nada no diario sobre o BACKUP" "$LOG" "$D1/BACKUP"
confere "D1: config.ini intacto"            "$(cat $DADOS/config.ini)" "^folder = $D1/BACKUP/\$"

echo "--- D1: lista (primeiro nivel + um nivel abaixo)"
I=$(itens)
confere "lista: solto"                      "$I" "\"backup\": true, \"nome\": \"Solto-PPSA00001.exfat\", \"pasta\": \"$D1/BACKUP/\""
confere "lista: um nivel abaixo (glibren antigo)" "$I" "\"backup\": true, \"nome\": \"Hades-PPSA03355-US-PS5.exfat\", \"pasta\": \"$D1/BACKUP/Hades/\", \"raiz\": \"$D1/BACKUP/\""
confere "lista: um nivel abaixo (Jobe)"     "$I" "\"nome\": \"x-PPSA00002.pkg\", \"pasta\": \"$D1/BACKUP/DaJobe/\", \"raiz\": \"$D1/BACKUP/\""
confere "lista: um nivel abaixo (sem marca)" "$I" "\"nome\": \"y-PPSA00003.exfat\", \"pasta\": \"$D1/BACKUP/SemMarca/\", \"raiz\": \"$D1/BACKUP/\""
nao_tem "lista: marcador nao e item"        "$I" 'jobe-backup'
confere "contagem da pasta"                 "$(curl -s $L/api/escanear)" "{\"pasta\":\"$D1/BACKUP/\",\"existe\":true,\"qtd\":4,"

echo "--- D1: acoes pedidas pelo usuario valem (mover de volta, excluir, renomear) e as recusas"
confere "mover de volta: na fila"           "$(tarefa mover "$D1/BACKUP/Hades/" Hades-PPSA03355-US-PS5.exfat "$D1/homebrew")" '"criadas":1'
espera
confere "mover de volta: feita"             "$(ultima)" '"tipo": "mover", "estado": "feita"'
existe "mover de volta: chegou"             "$D1/homebrew/Hades-PPSA03355-US-PS5.exfat"
sumiu  "mover de volta: subpasta e marcador sairam" "$D1/BACKUP/Hades"
tarefa excluir "$D1/BACKUP/SemMarca/" y-PPSA00003.exfat > /dev/null; espera
confere "excluir: feita"                    "$(ultima)" '"tipo": "excluir", "estado": "feita"'
sumiu  "excluir: subpasta vazia saiu"       "$D1/BACKUP/SemMarca"
confere "renomear na subpasta"              "$(post --data-urlencode "pasta=$D1/BACKUP/DaJobe/" -d de=x-PPSA00002.pkg -d para=Xis-PPSA00002.pkg $L/api/renomear)" '"ok":true'
existe "renomear: nome novo"                "$D1/BACKUP/DaJobe/Xis-PPSA00002.pkg"
existe "renomear: subpasta e marcador ficam" "$D1/BACKUP/DaJobe/.jobe-backup.json"
confere "subpasta fora do backup: recusada" "$(tarefa excluir "$D1/homebrew/sub/" x)" '"criadas":0.*"fora_das_pastas":1'
confere "caminho com ..: recusado"          "$(tarefa excluir "$D1/BACKUP/DaJobe/../../homebrew" Hades-PPSA03355-US-PS5.exfat)" '"criadas":0'
confere "destino continua so pasta da lista" "$(tarefa mover "$D1/homebrew" Hades-PPSA03355-US-PS5.exfat "$D1/BACKUP/DaJobe/")" '"criadas":0'
existe "recusas: nada saiu do lugar"        "$D1/homebrew/Hades-PPSA03355-US-PS5.exfat"

echo "--- D2: BACKUP (Jobe) e backup (glibren) lado a lado"
confere "D2: as duas pastas"                "$(ls "$D2" | tr '\n' ' ')" '^BACKUP backup homebrew $'
confere "D2: BACKUP intacto (solto)"        "$(cat "$D2/BACKUP/a-PPSA00010.exfat" 2>&1)" '^jobe-a$'
existe "D2: BACKUP intacto (subpasta)"      "$D2/BACKUP/DaJobe2/b-PPSA00011.pkg"
confere "D2: backup nao recebeu nada"       "$(cat "$D2/backup/a-PPSA00010.exfat" 2>&1)" '^meu-a$'
sumiu  "D2: nada da Jobe em backup"         "$D2/backup/DaJobe2"
existe "D2: subpasta do glibren subiu"      "$D2/backup/c-PPSA00012.exfat"
sumiu  "D2: subpasta do glibren saiu"       "$D2/backup/Meu"
nao_tem "D2: nada no diario sobre o BACKUP" "$LOG" "$D2/BACKUP"
confere "D2: config.ini com as duas"        "$(grep -c "^folder = $D2/" $DADOS/config.ini)" '^2$'

echo "--- D3: so backup: subpastas do glibren sobem; o resto fica"
existe "D3: arquivo subiu"                  "$D3/backup/c-PPSA00020.exfat"
sumiu  "D3: subpasta saiu"                  "$D3/backup/Jogo"
existe "D3: pasta de jogo subiu"            "$D3/backup/PastaJogo-PPSA05555/eboot.bin"
sumiu  "D3: subpasta Pasta saiu"            "$D3/backup/Pasta"
existe "D3: da Jobe fica"                   "$D3/backup/DaJobe3/d-PPSA00021.pkg"
existe "D3: marcador da Jobe fica"          "$D3/backup/DaJobe3/.jobe-backup.json"
existe "D3: sem marcador fica"              "$D3/backup/SemMarca3/e-PPSA00022.exfat"
existe "D3: com outra coisa dentro fica"    "$D3/backup/Misto/z-PPSA00004.exfat"
existe "D3: _temp intacta"                  "$D3/backup/_temp"
confere "D3: diario item a item"            "$LOG" "arrumacao: $D3/backup/Jogo/c-PPSA00020.exfat -> $D3/backup/c-PPSA00020.exfat"
confere "D3: diario da duvida"              "$LOG" "arrumacao: $D3/backup/Misto fica como esta"
confere "D3: lista o que subiu"             "$I" "\"nome\": \"c-PPSA00020.exfat\", \"pasta\": \"$D3/backup/\""
confere "D3: lista a pasta de jogo"         "$I" "\"nome\": \"PastaJogo-PPSA05555\", \"pasta\": \"$D3/backup/\", \"tipo\": \"pasta\""
confere "D3: lista um nivel abaixo"         "$I" "\"nome\": \"z-PPSA00004.exfat\", \"pasta\": \"$D3/backup/Misto/\", \"raiz\": \"$D3/backup/\""
nao_tem "D3: dois niveis abaixo nao"        "$I" 'leia.txt'
confere "D3: dois niveis abaixo: recusado"  "$(tarefa excluir "$D3/backup/Misto/notas/" leia.txt)" '"criadas":0.*"fora_das_pastas":1'
confere "D3: pasta de jogo nao e subpasta"  "$(tarefa excluir "$D3/backup/PastaJogo-PPSA05555/" eboot.bin)" '"criadas":0.*"fora_das_pastas":1'
existe "D3: pasta de jogo intacta"          "$D3/backup/PastaJogo-PPSA05555/eboot.bin"

echo "--- D4: pasta da lista em outra caixa: usa a que existe (so a lista; a pasta nao muda)"
confere "D4: so BACKUP no disco"            "$(ls "$D4" | tr '\n' ' ')" '^BACKUP homebrew $'
confere "D4: a lista mostra o arquivo"      "$I" "\"nome\": \"n-PPSA00030.exfat\", \"pasta\": \"$D4/BACKUP/\""
confere "D4: config.ini com a grafia real"  "$(cat $DADOS/config.ini)" "^folder = $D4/BACKUP/\$"
confere "D4: diario da grafia"              "$(cat $DADOS/glibren.log)" "config: pasta da lista $D4/backup/ nao existe; usando $D4/BACKUP/"

echo "--- D5: jogo montado a partir de backup = subpastas ficam para depois"
existe "D5: subpasta intacta"               "$D5/backup/Preso/p-PPSA00041.exfat"
confere "D5: diario"                        "$LOG" "arrumacao: subpastas de $D5/backup ficam para depois (ha jogo montado a partir dali"

kill $PID 2>/dev/null; wait $PID 2>/dev/null
pkill -f "smp_falso.py $PORTA_SMP" 2>/dev/null
echo "=== $ok ok, $falhas falhas"
[ $falhas -eq 0 ]
