#!/usr/bin/env python3
"""0.9.40: MemDBG FALSO para os testes do glibren no PC (so o subconjunto do protocolo MDBG que o glibren usa).

Formato tirado de docs/protocol.md e include/memdbg/core/memdbg_protocol.h do MemDBG (seregonwar/MemDBG, GPL-3):
pedido = magic u32 "MDBG" (0x4742444d), version u16 (1), command u16, request_id u32, length u32 + corpo;
resposta = magic, version, command, request_id, status i32, length u32 + corpo. Tudo little-endian.
Comandos: HELLO 0x0001 (resposta V3 de 112 bytes), PING 0x0002, GOODBYE 0x0003, PROCESS_PROTECT 0x0108,
PROCESS_ALLOC 0x0109, PROCESS_FREE 0x010A, MEMORY_READ 0x0200 (sub-quadro 0x00 + bytes), MEMORY_WRITE 0x0201.
Outro comando = MEMDBG_ERR_PROTOCOL (-5), como o MemDBG.

A "memoria" das areas reservadas fica aqui (dicionario), nao no processo de teste: o glibren grava e le essas areas
pelo MemDBG. Uso: memdbg_falso.py PORTA PASTA
  PASTA/modo (opcional): ok | sem_alloc (HELLO sem a capacidade de reservar) | alloc_recusa (PROCESS_ALLOC = -3)
                         | outro_endereco (reserva 1 MB acima da dica) | protect_recusa (PROCESS_PROTECT = -8)
  PASTA/log: uma linha por comando; PASTA/regioes.json: {"0x...": {"tam": N, "prot": P, "hex": "..."}}
  PASTA/pronto: criado quando escuta."""
import json
import os
import socket
import struct
import sys
import threading

MAGIC = 0x4742444D
PORTA, PASTA = int(sys.argv[1]), sys.argv[2]
CAPS_TODAS = (1 << 0) | (1 << 1) | (1 << 2) | (1 << 3) | (1 << 8) | (1 << 12) | (1 << 22) | (1 << 23)
trava = threading.Lock()
regioes = {}   # endereco -> [tam, prot, bytearray]


def modo():
    try:
        return open(os.path.join(PASTA, "modo")).read().strip() or "ok"
    except OSError:
        return "ok"


def log(txt):
    with open(os.path.join(PASTA, "log"), "a") as f:
        f.write(txt + "\n")


def salvar():
    d = {hex(a): {"tam": r[0], "prot": r[1], "hex": bytes(r[2]).hex().upper()} for a, r in regioes.items()}
    tmp = os.path.join(PASTA, "regioes.json.tmp")
    with open(tmp, "w") as f:
        json.dump(d, f)
    os.replace(tmp, os.path.join(PASTA, "regioes.json"))


def achar(end, n):
    for a, r in regioes.items():
        if a <= end and end + n <= a + r[0]:
            return a, r
    return None, None


def receber(c, n):
    b = b""
    while len(b) < n:
        d = c.recv(n - len(b))
        if not d:
            raise EOFError
        b += d
    return b


def hello():
    caps = CAPS_TODAS & ~(1 << 23) if modo() == "sem_alloc" else CAPS_TODAS
    try:
        vf = open(os.path.join(PASTA, "versao")).read().strip()
    except OSError:
        vf = "0.2.0-nightly.321.g6e31144"
    corpo = struct.pack("<HHIHH16s16sHHQQ48s", 1, 100, caps, PORTA, 9023, vf[:15].encode(), b"MemDBG", 4, 0,
                        0x1234, 99, vf.encode()[:47])
    assert len(corpo) == 112
    return 0, corpo


def tratar(cmd, corpo):
    m = modo()
    if cmd == 0x0001:
        log("HELLO" + (" sessao" if len(corpo) == 16 and struct.unpack_from("<I", corpo)[0] == 0x31534553 else ""))
        return hello()
    if cmd == 0x0002:
        log("PING")
        return 0, b""
    if cmd == 0x0003:
        log("GOODBYE")
        return 0, b""
    if cmd == 0x0109:   # PROCESS_ALLOC
        if len(corpo) != 32:
            return -5, b""
        pid, prot, dica, tam, flags, _ = struct.unpack("<iIQQII", corpo)
        log(f"ALLOC pid={pid} dica={dica:#x} tam={tam:#x} prot={prot} flags={flags}")
        if m == "alloc_recusa":
            return -3, b""
        end = dica + (0x100000 if m == "outro_endereco" else 0)
        regioes[end] = [tam, prot, bytearray(tam)]
        salvar()
        return 0, struct.pack("<QQ", end, tam)
    if cmd == 0x0108:   # PROCESS_PROTECT
        pid, prot, end, tam = struct.unpack("<iIQQ", corpo)
        log(f"PROTECT pid={pid} end={end:#x} tam={tam:#x} prot={prot}")
        if m == "protect_recusa":
            return -8, b""
        a, r = achar(end, tam)
        if r is None:
            return -7, b""
        velha = r[1]
        r[1] = prot
        salvar()
        return 0, struct.pack("<II", velha, prot)
    if cmd == 0x010A:   # PROCESS_FREE
        pid, _, end, tam = struct.unpack("<iIQQ", corpo)
        log(f"FREE pid={pid} end={end:#x} tam={tam:#x}")
        if end in regioes and regioes[end][0] == tam:
            del regioes[end]
            salvar()
            return 0, b""
        return -7, b""
    if cmd == 0x0200:   # MEMORY_READ
        pid, end, n = struct.unpack("<iQI", corpo)
        log(f"READ pid={pid} end={end:#x} n={n}")
        a, r = achar(end, n)
        if r is None:
            return -3, b""
        return 0, b"\x00" + bytes(r[2][end - a:end - a + n])
    if cmd == 0x0201:   # MEMORY_WRITE
        pid, end, n = struct.unpack_from("<iQI", corpo)
        dados = corpo[16:]
        log(f"WRITE pid={pid} end={end:#x} n={n} {dados.hex().upper()}")
        a, r = achar(end, n)
        if r is None or len(dados) != n:
            return -3, b""
        r[2][end - a:end - a + n] = dados
        salvar()
        return 0, struct.pack("<I", n)
    log(f"CMD {cmd:#06x} desconhecido")
    return -5, b""


def cliente(c):
    try:
        while True:
            cab = receber(c, 16)
            mg, ver, cmd, rid, n = struct.unpack("<IHHII", cab)
            if mg != MAGIC or ver != 1 or n > (1 << 20):
                c.sendall(struct.pack("<IHHIiI", MAGIC, 1, cmd, rid, -5, 0))
                break
            corpo = receber(c, n) if n else b""
            with trava:
                st, resp = tratar(cmd, corpo)
            c.sendall(struct.pack("<IHHIiI", MAGIC, 1, cmd, rid, st, len(resp)) + resp)
            if cmd == 0x0003:
                break
    except (EOFError, OSError):
        pass
    finally:
        c.close()


s = socket.socket()
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("127.0.0.1", PORTA))
s.listen(16)
open(os.path.join(PASTA, "pronto"), "w").close()
while True:
    c, _ = s.accept()
    threading.Thread(target=cliente, args=(c,), daemon=True).start()
