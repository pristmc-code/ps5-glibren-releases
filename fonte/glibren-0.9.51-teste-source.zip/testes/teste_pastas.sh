#!/bin/bash
# 0.9.48: excluir e mover PASTA DE JOGO pela fila de tarefas (src/tarefas.c), na versao de PC, com o ShadowMount+ falso
# (testes/smp_falso.py). Casos: excluir pasta com subpastas (some inteira, diario com arquivos e bytes), link simbolico
# para fora (o link sai, o alvo fica intacto), pasta que nao e jogo (recusa, nada apagado), caminho com ".." (recusa),
# jogo montado pelo ShadowMount+ (recusa), ShadowMount+ rodando sem responder (recusa), mover no mesmo disco (rename),
# mover para outro disco (recusa: ainda nao vale), destino que ja existe (recusa), copiar pasta (recusa),
# GET /api/pasta-info (arquivos, bytes, em uso) e sem X-GLR (403).
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_pastas.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8931; PORTA_SMP=8932
L="http://127.0.0.1:$PORTA"
T=/root/glr-pastas; DADOS=$T/dados; A=$T/a; B=$T/b; FORA=$T/fora; C=/dev/shm/glr-pastas-c   # C = outro disco (tmpfs)
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
existe() { if [ -e "$2" ]; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: nao existe $2"; fi; }
sumiu() { if [ -e "$2" ] || [ -L "$2" ]; then falhas=$((falhas+1)); echo "FALHA $1: ainda existe $2"; else ok=$((ok+1)); echo "OK   $1"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
espera() { for _ in $(seq 1 80); do curl -s $L/api/tarefas | grep -q '"estado":"\(fila\|rodando\)"' || return; sleep 0.25; done; }
ultima() { curl -s $L/api/tarefas | python3 -I -c 'import json,sys; t=json.load(sys.stdin)["tarefas"]; print(json.dumps(max(t, key=lambda x: x["id"]), ensure_ascii=False))'; }
tarefa() { post --data-urlencode "tipo=$1" --data-urlencode "pasta=$2" --data-urlencode "de=$3" --data-urlencode "destino=${4:-}" $L/api/tarefas; }
jogo() {  # pasta de jogo de mentira: eboot.bin + sce_sys/param.json + subpastas
  mkdir -p "$1/sce_sys" "$1/dados/nivel1/nivel2"
  printf 'elf-de-mentira' > "$1/eboot.bin"
  printf '{"titleId":"%s"}' "$2" > "$1/sce_sys/param.json"
  printf '1234567890' > "$1/dados/a.bin"; printf '12345' > "$1/dados/nivel1/b.bin"; printf '123' > "$1/dados/nivel1/nivel2/c.bin"
}
smp_estado() { python3 -I -c 'import json,sys; json.dump(json.loads(sys.argv[1]), open(sys.argv[2], "w", encoding="utf-8"), ensure_ascii=False)' "$1" "$T/smp/estado.json"; }

pkill -f "smp_falso.py $PORTA_SMP" 2>/dev/null
rm -rf "$T" "$C"; mkdir -p "$DADOS" "$A" "$B" "$FORA" "$C" "$T/smp"
printf 'language = pt-BR\nfolder = %s/\nfolder = %s/\nfolder = %s/\n' "$A" "$B" "$C" > "$DADOS/config.ini"
jogo "$A/Apaga-PPSA01111" PPSA01111
jogo "$A/Link-PPSA02222" PPSA02222
jogo "$A/Montado-PPSA03333" PPSA03333
jogo "$A/Move-PPSA04444" PPSA04444
jogo "$A/Disco-PPSA05555" PPSA05555
jogo "$A/Existe-PPSA06666" PPSA06666; mkdir -p "$B/Existe-PPSA06666"
jogo "$A/Copia-PPSA07777" PPSA07777
jogo "$A/Mudo-PPSA08888" PPSA08888
mkdir -p "$A/NaoJogo/sub"; echo x > "$A/NaoJogo/sub/arquivo.txt"
# alvos fora da pasta de jogo: arquivo e pasta; os links para eles ficam DENTRO da pasta de jogo
mkdir -p "$FORA/pasta-alvo"; echo precioso > "$FORA/alvo.txt"; echo tambem > "$FORA/pasta-alvo/dentro.txt"
ln -s "$FORA/alvo.txt" "$A/Link-PPSA02222/dados/link-arquivo"
ln -s "$FORA/pasta-alvo" "$A/Link-PPSA02222/dados/link-pasta"
smp_estado "{\"games\":[{\"path\":\"$A/Montado-PPSA03333\",\"title_id\":\"PPSA03333\",\"mounted\":true}],\"images\":[]}"
(exec python3 -I "$ORIGEM/testes/smp_falso.py" $PORTA_SMP "$T/smp") >> "$T/smp.log" 2>&1 &
sleep 0.5
GLR_TESTE_SONDA_S=0 GLR_TESTE_SMP_PORTA=$PORTA_SMP GLR_TESTE_PROCESSOS="shadowmountplus.elf" GLR_TESTE_CONV_VIGIA_S=0 \
  "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!
sleep 1

echo "--- GET /api/pasta-info"
I=$(curl -s "$L/api/pasta-info?pasta=$A/&nome=Apaga-PPSA01111")
confere "info: arquivos e bytes"            "$I" '"ok":true,"arquivos":5,"bytes":5[0-9],'
confere "info: livre"                       "$I" '"em_uso":false'
confere "info: montado"                     "$(curl -s "$L/api/pasta-info?pasta=$A/&nome=Montado-PPSA03333")" '"em_uso":true,"motivo":"montado"'
confere "info: nao e jogo (404)"            "$(curl -s -o /dev/null -w '%{http_code}' "$L/api/pasta-info?pasta=$A/&nome=NaoJogo")" "404"
confere "info: fora das pastas (400)"       "$(curl -s -o /dev/null -w '%{http_code}' "$L/api/pasta-info?pasta=$FORA/&nome=pasta-alvo")" "400"
confere "info: nome com .. (400)"           "$(curl -s -o /dev/null -w '%{http_code}' "$L/api/pasta-info?pasta=$A/&nome=..")" "400"

echo "--- excluir pasta de jogo com subpastas"
confere "excluir sem X-GLR: 403"            "$(curl -s -o /dev/null -w '%{http_code}' -d "tipo=excluir&pasta=$A&de=Apaga-PPSA01111" $L/api/tarefas)" "403"
existe "sem X-GLR: nada apagado"            "$A/Apaga-PPSA01111/eboot.bin"
confere "excluir: na fila"                  "$(tarefa excluir "$A" Apaga-PPSA01111)" '"criadas":1'
espera
confere "excluir: feita"                    "$(ultima)" '"tipo": "excluir", "estado": "feita"'
sumiu  "excluir: a pasta saiu inteira"      "$A/Apaga-PPSA01111"
confere "diario: arquivos e bytes"          "$(cat $DADOS/glibren.log)" 'pasta de jogo excluida: .*Apaga-PPSA01111 (5 arquivos, 5[0-9] bytes apagados)'

echo "--- link simbolico para fora: o link sai, o alvo fica"
tarefa excluir "$A" Link-PPSA02222 > /dev/null; espera
confere "link: feita"                       "$(ultima)" '"estado": "feita"'
sumiu  "link: a pasta de jogo saiu"         "$A/Link-PPSA02222"
confere "link: arquivo-alvo intacto"        "$(cat "$FORA/alvo.txt" 2>&1)" '^precioso$'
confere "link: pasta-alvo intacta"          "$(cat "$FORA/pasta-alvo/dentro.txt" 2>&1)" '^tambem$'

echo "--- recusas do excluir"
tarefa excluir "$A" NaoJogo > /dev/null; espera
confere "nao e jogo: erro"                  "$(ultima)" '"estado": "erro".*nao e uma pasta de jogo'
existe "nao e jogo: nada apagado"           "$A/NaoJogo/sub/arquivo.txt"
confere "nome com ..: recusado"             "$(tarefa excluir "$A" '../a')" '"criadas":0'
confere "pasta com ..: recusada"            "$(tarefa excluir "$A/../a" Montado-PPSA03333)" '"criadas":0'
confere "fora das pastas: recusada"         "$(tarefa excluir "$FORA" pasta-alvo)" '"criadas":0.*"fora_das_pastas":1'
existe "fora das pastas: intacta"           "$FORA/pasta-alvo/dentro.txt"
tarefa excluir "$A" Montado-PPSA03333 > /dev/null; espera
confere "montado: erro"                     "$(ultima)" '"estado": "erro".*montado ou aberto'
existe "montado: nada apagado"              "$A/Montado-PPSA03333/dados/nivel1/nivel2/c.bin"

echo "--- mover pasta de jogo"
confere "mover (mesmo disco): na fila"      "$(tarefa mover "$A" Move-PPSA04444 "$B")" '"criadas":1'
espera
confere "mover: feita"                      "$(ultima)" '"tipo": "mover", "estado": "feita"'
sumiu  "mover: saiu da origem"              "$A/Move-PPSA04444"
existe "mover: chegou inteira"              "$B/Move-PPSA04444/dados/nivel1/nivel2/c.bin"
confere "diario: movida"                    "$(cat $DADOS/glibren.log)" 'pasta de jogo movida: .*Move-PPSA04444 -> .*/b/Move-PPSA04444 (5 arquivos'
tarefa mover "$A" Disco-PPSA05555 "$C" > /dev/null; espera
confere "outro disco: erro claro"           "$(ultima)" '"estado": "erro".*outro disco ainda nao vale'
existe "outro disco: origem intacta"        "$A/Disco-PPSA05555/dados/a.bin"
sumiu  "outro disco: nada no destino"       "$C/Disco-PPSA05555"
tarefa mover "$A" Existe-PPSA06666 "$B" > /dev/null; espera
confere "destino existe: erro"              "$(ultima)" '"estado": "erro".*ja existe'
existe "destino existe: origem intacta"     "$A/Existe-PPSA06666/eboot.bin"
tarefa mover "$A" Montado-PPSA03333 "$B" > /dev/null; espera
confere "mover montado: erro"               "$(ultima)" '"estado": "erro".*montado ou aberto'
existe "mover montado: fica"                "$A/Montado-PPSA03333/eboot.bin"
tarefa copiar "$A" Copia-PPSA07777 "$B" > /dev/null; espera
confere "copiar pasta: erro"                "$(ultima)" '"estado": "erro".*copiar nao vale para pasta de jogo'
sumiu  "copiar pasta: nada no destino"      "$B/Copia-PPSA07777"

echo "--- ShadowMount+ rodando sem responder: recusa"
pkill -f "smp_falso.py $PORTA_SMP" 2>/dev/null; sleep 0.5
tarefa excluir "$A" Mudo-PPSA08888 > /dev/null; espera
confere "SMP mudo: erro"                    "$(ultima)" '"estado": "erro".*nao respondeu'
existe "SMP mudo: nada apagado"             "$A/Mudo-PPSA08888/eboot.bin"

kill $PID 2>/dev/null; wait $PID 2>/dev/null
rm -rf "$C"
echo "=== $ok ok, $falhas falhas"
[ $falhas -eq 0 ]
