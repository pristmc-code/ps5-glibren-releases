#!/bin/bash
# Revisao da 0.9.41 (antes de publicar): um teste para cada correcao, na versao de PC, com os falsos de sempre (elfldr,
# Dump Forge, ShadowMount+/ShadowKraken pelo github_falso.py smp) e a sonda do kstuff lida de um arquivo (GLR_TESTE_KSTUFF;
# cada execucao da sonda deixa uma linha em <arquivo>.exec).
#   1  lista de conversoes/instalacoes cheia (32 ativos): recusa "fila_cheia", nada orfao no Dump Forge, nenhum ativo sai
#   2a Ativar do kstuff: marcador deste boot ou sonda "desconhecido" = 409 payload_kstuff_confirmar; com confirmo_kstuff=1
#      vai; sonda "carregado" = payload_ja_ativo mesmo confirmado
#   2b carregar ao iniciar: confere de novo (sonda/marcador) depois de pegar a vez e logo antes do envio
#   2c marcador "v2 id boottime uptime": acerto de relogio e repouso nao invalidam; uptime menor ou id diferente = boot
#      novo; marcador antigo; Ativar sem elfldr nao apaga um marcador que ja valia
#   3  sonda do kstuff: nada executado sem o kstuff instalado ou com os bytes do getpid diferentes; busca uma vez so
#      (pthread_once, diario uma vez); "desconhecido" nao fica em cache
#   4  carregar ao iniciar espera a porta 9021 antes de ler o arquivo; SHA-256 uma vez; marcador gravado uma vez
#   5  Dump Forge que nao responde: so na 3a consulta seguida vira "perdido"; a "espera" (job 0) nunca vira perdido
#   6  .pkg que uma conversao ainda gera: instalar recusado "em_uso"
#   7  ShadowKraken sem o marcador de versao recusado; o proprio glibren recusado em qualquer item (lista, instalar, Ativar)
#   8  busca de arquivos: SHA-256 so dos sugeridos; uma busca por vez (409 payload_busca_ocupada)
#   9  o mesmo .pkg pedido 10 vezes ao mesmo tempo: entra uma vez so
#   10 pagina Payloads sem reticencias; SHA-256 completo ou "inicio do SHA-256"
#   11 .info com "origem=" comprida: o resto da linha nunca vira outra chave
#   12 comentario de payloads_rota_autoload (payloads.h) com a lista certa
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_revisao_0941.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8951; PEL=8952; PDF=8953; PSMP=8954
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R="http://$IP:$PORTA"
T=/root/glr-revisao0941; DADOS=$T/dados; PAY=$DADOS/payloads; GH=$T/gh; A=$T/lista
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$(echo "$2" | head -c 700)] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
estado() { curl -s "$L/api/payloads"; }
campo() { estado | python3 -c "import json,sys; d=json.load(sys.stdin); i=[x for x in d['itens'] if x['id']=='$1'][0]; v=eval('i'+sys.argv[1]); print(json.dumps(v) if not isinstance(v,str) else v)" "$2"; }
recebidos() { [ -f $T/el/recebidos ] && wc -l < $T/el/recebidos || echo 0; }
ks_recebidos() { grep -c kstuff $T/el/recebidos 2>/dev/null || echo 0; }
execs() { [ -f $T/el/kstuff_estado.exec ] && wc -l < $T/el/kstuff_estado.exec || echo 0; }
espera_res() { local v=""; for _ in $(seq 1 ${2:-150}); do v=$(campo "$1" "['autoload_res']" 2>/dev/null); case "$v" in carregado|ja_rodando|erro|boot) break;; esac; sleep 0.2; done; echo "$v"; }
espera_livre() { for _ in $(seq 1 150); do estado | grep -q '"ocupado":false' && return; sleep 0.1; done; }
espera_http() { for _ in $(seq 1 150); do curl -s -o /dev/null -m 2 "$1" && return 0; sleep 0.1; done; echo "AVISO: $1 nao respondeu"; }
liga_el() { mkdir -p $T/el; rm -f $T/el/elfldr.pronto; (exec python3 -I "$ORIGEM/testes/elfldr_falso.py" $PEL $T/el) >> $T/el.log 2>&1 & PID_EL=$!; for _ in $(seq 1 50); do [ -e $T/el/elfldr.pronto ] && break; sleep 0.1; done; }
para_el() { kill $PID_EL 2>/dev/null; wait $PID_EL 2>/dev/null; }
liga_df() { mkdir -p $T/df; (exec python3 -I "$ORIGEM/testes/dumpforge_falso.py" $PDF $T/df) >> $T/df.log 2>&1 & PID_DF=$!; espera_http "http://127.0.0.1:$PDF/api/session"; }
para_df() { kill $PID_DF 2>/dev/null; wait $PID_DF 2>/dev/null; }
config() { printf 'language = pt-BR\nfolder = %s/\n%s' "$A" "${1:+payload_autoload = $1
}" > "$DADOS/config.ini"; }
inicia() {
  GLR_TESTE_ELFLDR=$PEL GLR_TESTE_SONDA_S=${SONDA:-0} GLR_TESTE_DUMPFORGE_PORTA=$PDF GLR_TESTE_SMP_PORTA=$PSMP GLR_TESTE_KRAKEN_PORTA=8959 \
  GLR_TESTE_BLUEV_PORTA=8958 GLR_TESTE_ZHITHEMES_PORTA=8957 GLR_TESTE_MEMDBG_PORTA=8956 GLR_TESTE_MEMDBG_CACHE_S=0 GLR_TESTE_GH=http://127.0.0.1:8955 \
  GLR_TESTE_KSTUFF=$T/el/kstuff_estado GLR_TESTE_BOOT=${BOOT:-1800000000} GLR_TESTE_UPTIME=${UPT:-1000} GLR_TESTE_BOOT_ID=${BOOTID:-} \
  GLR_TESTE_KSTUFF_BYTES=${BYTES:-} GLR_TESTE_BUSCA_ESPERA_MS=${BUSCA_MS:-0} GLR_TESTE_CONV_VIGIA_S=0 \
  GLR_TESTE_AUTOLOAD_ESPERA_S=${ESPERA:-20} GLR_TESTE_KSTUFF_ESPERA_S=${KSESP:-3} GLR_TESTE_PLDMGR=$T/pldmgr GLR_TESTE_ARQ_RAIZES=$T/usb0 \
  GLR_TESTE_FW=12.00 "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; espera_http "$L/nada"; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
parear() {
  local n0=$(grep -c 'pareamento [0-9]\{6\}' "$T/glr.log") C=""
  post -X POST $R/api/parear/pedir > /dev/null
  for _ in $(seq 1 100); do [ "$(grep -c 'pareamento [0-9]\{6\}' "$T/glr.log")" -gt "$n0" ] && break; sleep 0.1; done
  C=$(grep -o 'pareamento [0-9]\{6\}' "$T/glr.log" | tail -1 | awk '{print $2}')
  TOKEN=$(post -d codigo=$C -d nome=teste $R/api/parear | grep -o '"token":"[0-9a-f]*"' | cut -d'"' -f4)
}
P() { post -H "X-GLR-Token: $TOKEN" "$@"; }
elf() { python3 - "$@" <<'EOF'
import sys
caminho, texto, tam = sys.argv[1], sys.argv[2].encode().decode('unicode_escape').encode('latin-1'), int(sys.argv[3])
d = b"\x7fELF" + b"\0" * 60 + texto + b"\0"
d += bytes((i * 7) % 251 for i in range(max(0, tam - len(d))))
open(caminho, "wb").write(d)
EOF
}
instala_gh() { elf "$PAY/$1.elf" "$2" 3000; printf 'versao=%s\nsha256=%s\ntamanho=%s\nasset=%s.elf\n' "$3" "$(sha256sum $PAY/$1.elf | cut -d' ' -f1)" "$(stat -c %s $PAY/$1.elf)" "$1" > "$PAY/$1.info"; }
pkg() { python3 - "$1" "$2" "$3" <<'EOF'
import sys
caminho, magia, tam = sys.argv[1], sys.argv[2].encode(), int(sys.argv[3])
open(caminho, "wb").write(bytearray(b"\x7f" + magia + b"\0" * (tam - 1 - len(magia))))
EOF
}
ks() { echo "$1" > $T/el/kstuff_estado; }
# N copias do comando ao mesmo tempo; espera so elas (o "wait" sozinho esperaria tambem o glibren e os falsos)
juntos() { local n=$1 ps=(); shift; for _ in $(seq 1 $n); do "$@" > /dev/null & ps+=($!); done; wait "${ps[@]}"; }
marcador() { cat $PAY/kstuff.boot 2>/dev/null || echo "(sem)"; }

rm -rf "$T"; mkdir -p "$DADOS" "$PAY" "$GH" "$A" "$T/pldmgr/payloads" "$T/usb0/sub" "$T/el" "$T/df"
elf "$T/pldmgr/payloads/Kstuff-NG_v1.00.elf" "KSTUFF-FALSO Kstuff-NG v1.00" 4096
elf "$T/usb0/sub/shadowkraken-1.00-Dev.7-pristmc.elf" "ShadowKraken 1.00-Dev.7-pristmc" 5000
elf "$T/usb0/shadowkraken-sem-marcador.elf" "ShadowKraken sem versao" 5000
elf "$T/usb0/kstuff-glibren.elf" 'GLIBREN-VERSAO:0.9.41-teste\n' 4000
elf "$T/usb0/outro-payload.elf" "OUTRO" 2048
config ""
liga_el

echo "--- 12: comentario do payloads.h"
H=$(grep -A6 'POST /api/payloads/autoload' "$ORIGEM/src/payloads.h")
confere "autoload: lista os montadores e o kstuff" "$H" "kraken-mount ou ShadowKraken"
confere "autoload: kstuff"                 "$H" "kstuff"
nao_tem "autoload: sem o texto antigo"     "$H" "so Dump Forge, BlueV e MemDBG"

echo "--- 3: sonda do kstuff so com o kstuff instalado"
ks ativo
inicia; parear
for _ in 1 2 3; do estado > /dev/null; done
confere "sem arquivo: carregado vazio"     "$(campo kstuff "['carregado']")" "^$"
confere "sem arquivo: nada executado"      "$(execs)" "^0$"
nao_tem "sem arquivo: diario sem sonda"    "$(cat $DADOS/glibren.log)" "kstuff: sonda"
P -d id=kstuff -d caminho=$T/pldmgr/payloads/Kstuff-NG_v1.00.elf $R/api/payloads/arquivo > /dev/null
confere "instalado: sonda roda (sim)"      "$(campo kstuff "['carregado']")" "^sim$"
confere "instalado: executou"              "$(execs)" "^[1-9]"
juntos 8 estado
confere "busca do endereco uma vez so"     "$(grep -c 'kstuff: sonda pronta' $DADOS/glibren.log)" "^1$"
para

echo "--- 3: bytes do getpid diferentes = desconhecido, nada executado"
E0=$(execs)
BYTES=48c7c0150000004989ca0f05 inicia
juntos 6 estado
confere "bytes errados: desconhecido"      "$(campo kstuff "['carregado']")" "^desconhecido$"
confere "bytes errados: nada executado"    "$(execs)" "^$E0$"
confere "bytes errados: diario uma vez"    "$(grep -c 'nao tem os bytes esperados' $DADOS/glibren.log)" "^1$"
para

echo "--- 3: desconhecido nao fica em cache"
SONDA=30 inicia
ks talvez
confere "talvez: desconhecido"             "$(campo kstuff "['carregado']")" "^desconhecido$"
ks nao
confere "logo depois: nao (sem o cache)"   "$(campo kstuff "['carregado']")" "^nao$"
para

echo "--- 11: .info com origem comprida"
SHA_K=$(sha256sum $PAY/kstuff-PristMC.elf | cut -d' ' -f1)
python3 - "$PAY/kstuff.info" "$SHA_K" <<'EOF'
import sys
destino, sha = sys.argv[1], sys.argv[2]
o255 = "/" + "a" * 247 + "sha256=" + "0" * 64            # no buffer antigo (256) o pedaco "sha256=000..." virava chave
o1500 = "/" + "b" * 1100 + "versao=hackeado" + "c" * 300   # maior que 1 KB: a linha inteira e descartada
open(destino, "w").write("versao=1.00\nsha256=%s\ntamanho=4096\nasset=Kstuff-NG_v1.00.elf\norigem=%s\norigem=%s\n" % (sha, o255, o1500))
EOF
inicia
confere "sha256 certo (nao o da origem)"   "$(campo kstuff "['arquivo_seu']['sha256']")" "^$SHA_K$"
confere "versao certa (nao a da linha longa)" "$(campo kstuff "['arquivo_seu']['versao']")" "^1.00$"
confere "origem lida (cortada em 299)"     "$(campo kstuff "['arquivo_seu']['origem']" | tr -d '\n' | wc -c)" "^299$"
para

echo "--- 2a: Ativar do kstuff"
ks nao; rm -f $PAY/kstuff.boot; inicia; parear
confere "sonda nao, sem marcador: vai"     "$(P -d id=kstuff $R/api/payloads/ativar)" '"ok":true'
espera_livre
confere "enviado 1"                        "$(ks_recebidos)" "^1$"
confere "marcador gravado (v2)"            "$(marcador)" "^v2 0 1800000000 1000$"
R1=$(P -d id=kstuff $R/api/payloads/ativar)
confere "marcador deste boot: confirmar"   "$R1" '"chave":"payload_kstuff_confirmar".*"nome":"boot"'
espera_livre
confere "sem confirmar: nada enviado"      "$(ks_recebidos)" "^1$"
confere "confirmado: vai"                  "$(P -d id=kstuff -d confirmo_kstuff=1 $R/api/payloads/ativar)" '"ok":true'
espera_livre
confere "confirmado: enviado 2"            "$(ks_recebidos)" "^2$"
confere "diario: confirmou"                "$(cat $DADOS/glibren.log)" "o usuario confirmou que ele nao esta carregado"
rm -f $PAY/kstuff.boot; ks talvez
confere "desconhecido: confirmar"          "$(P -d id=kstuff $R/api/payloads/ativar)" '"chave":"payload_kstuff_confirmar".*"nome":"desconhecido"'
ks ativo
confere "carregado: recusado mesmo confirmado" "$(P -d id=kstuff -d confirmo_kstuff=1 $R/api/payloads/ativar)" '"chave":"payload_ja_ativo"'
espera_livre
confere "nada mais enviado"                "$(ks_recebidos)" "^2$"

echo "--- 2c: Ativar sem elfldr nao apaga um marcador que ja valia"
ks nao; P -d id=kstuff -d confirmo_kstuff=1 $R/api/payloads/ativar > /dev/null; espera_livre   # marcador deste boot
M0=$(marcador); para_el
confere "sem elfldr, confirmado: aceito"   "$(P -d id=kstuff -d confirmo_kstuff=1 $R/api/payloads/ativar)" '"ok":true'
espera_livre
confere "sem elfldr: erro na pagina"       "$(campo kstuff "['erro']")" "elfldr (porta 9021) nao respondeu"
confere "marcador anterior intacto"        "$(marcador)" "^$M0$"
rm -f $PAY/kstuff.boot
P -d id=kstuff $R/api/payloads/ativar > /dev/null; espera_livre
confere "o que esta chamada gravou sai"    "$(marcador)" "^(sem)$"
para; liga_el

echo "--- 2c: marcador v2 (relogio acertado, repouso, boot novo, formato antigo)"
N0=$(ks_recebidos); ks nao; touch $T/el/ks_vira; rm -f $PAY/kstuff.boot
config "kstuff"; BOOT=1800000000 UPT=1000 inicia
confere "boot 1: carregado"                "$(espera_res kstuff)" "^carregado$"
para; ks nao
BOOT=1800000300 UPT=1200 inicia
confere "relogio +300 s: mesmo boot"       "$(espera_res kstuff)" "^boot$"
para
BOOT=1800000000 UPT=50 inicia
confere "uptime menor: boot novo"          "$(espera_res kstuff)" "^carregado$"
para; ks nao; rm -f $PAY/kstuff.boot
BOOTID=ab12 BOOT=1800000000 UPT=1000 inicia; espera_res kstuff > /dev/null; para; ks nao
confere "marcador com o id"                "$(marcador)" "^v2 ab12 1800000000 1000$"
BOOTID=ab12 BOOT=1800009000 UPT=1100 inicia
confere "repouso (boottime +9000 s), mesmo id: mesmo boot" "$(espera_res kstuff)" "^boot$"
para
BOOTID=cd34 BOOT=1800000000 UPT=1100 inicia
confere "id diferente: boot novo"          "$(espera_res kstuff)" "^carregado$"
para; ks nao
echo 1800000000 > $PAY/kstuff.boot
BOOT=1800000003 inicia
confere "formato antigo +-5 s: mesmo boot" "$(espera_res kstuff)" "^boot$"
para
confere "cargas: 4 nesta secao"            "$(( $(ks_recebidos) - N0 ))" "^4$"
rm -f $T/el/ks_vira

echo "--- 4 e 2b: espera a porta 9021 antes de ler; confere de novo antes de enviar"
para_el; rm -f $T/el/elfldr.pronto
instala_gh dump-forge "DUMP-FORGE-FALSO" v0.5.6
config "dump-forge"; N0=$(recebidos); inicia
sleep 2.5
confere "sem elfldr: esperando"            "$(campo dump-forge "['autoload_res']")" "^esperando$"
nao_tem "sem elfldr: arquivo nem lido"     "$(cat $DADOS/glibren.log)" "dump-forge: ao iniciar: conferindo"
liga_df; liga_el
confere "Dump Forge subiu na espera: ja rodando" "$(espera_res dump-forge)" "^ja_rodando$"
confere "nada enviado"                     "$(recebidos)" "^$N0$"
para; para_df
para_el; rm -f $PAY/kstuff.boot; ks nao
config "kstuff"; BOOT=1800050000 inicia
sleep 2; ks ativo; liga_el
confere "kstuff ativo na espera: ja rodando" "$(espera_res kstuff)" "^ja_rodando$"
confere "kstuff: nada enviado"             "$(recebidos)" "^$N0$"
confere "kstuff: sem marcador"             "$(marcador)" "^(sem)$"
para; para_el; ks nao
BOOT=1800060000 inicia
sleep 2; printf 'v2 0 1800060000 1000\n' > $PAY/kstuff.boot; liga_el
confere "marcador na espera: boot"         "$(espera_res kstuff)" "^boot$"
confere "marcador: nada enviado"           "$(recebidos)" "^$N0$"
para; para_el; rm -f $PAY/kstuff.boot
config "dump-forge kstuff"; touch $T/el/ks_vira; L0=$(wc -l < $DADOS/glibren.log); BOOT=1800070000 inicia
sleep 3; liga_el
confere "atrasado: kstuff carregado"       "$(espera_res kstuff)" "^carregado$"
confere "atrasado: Dump Forge carregado"   "$(espera_res dump-forge)" "^carregado$"
DIA=$(tail -n +$((L0+1)) $DADOS/glibren.log)
confere "SHA-256 do Dump Forge uma vez"    "$(echo "$DIA" | grep -c 'dump-forge: ao iniciar: conferindo')" "^1$"
confere "SHA-256 do kstuff uma vez"        "$(echo "$DIA" | grep -c 'kstuff: ao iniciar: conferindo')" "^1$"
confere "marcador gravado uma vez"         "$(echo "$DIA" | grep -c 'kstuff: marcador do boot gravado')" "^1$"
nao_tem "marcador nunca apagado"           "$DIA" "marcador do boot apagado"
confere "ordem: kstuff antes do Dump Forge" "$(tail -2 $T/el/recebidos | head -1)" "kstuff$"
para; rm -f $T/el/ks_vira; config ""

echo "--- 7: ShadowKraken sem marcador e o proprio glibren"
inicia; parear
confere "SK sem marcador: recusado"        "$(P -d id=shadowkraken -d caminho=$T/usb0/shadowkraken-sem-marcador.elf $R/api/payloads/arquivo)" "sem o marcador de versao do ShadowKraken"
confere "SK com marcador: aceito"          "$(P -d id=shadowkraken -d caminho=$T/usb0/sub/shadowkraken-1.00-Dev.7-pristmc.elf $R/api/payloads/arquivo)" '"versao":"1.00-Dev.7-pristmc"'
confere "glibren no kstuff: recusado"      "$(P -d id=kstuff -d caminho=$T/usb0/kstuff-glibren.elf $R/api/payloads/arquivo)" "e o proprio glibren"
confere "glibren no SK: recusado"          "$(cp $T/usb0/kstuff-glibren.elf $T/usb0/shadowkraken-glibren.elf; P -d id=shadowkraken -d caminho=$T/usb0/shadowkraken-glibren.elf $R/api/payloads/arquivo)" "e o proprio glibren"
LISTA=$(curl -s "$L/api/payloads/arquivos?id=kstuff")
confere "lista: glibren invalido"          "$LISTA" 'kstuff-glibren.elf",[^}]*"estado":"invalido","erro":"este arquivo e o proprio glibren'
instala_gh bluev 'GLIBREN-VERSAO:0.9.40-teste\n' v1.0
N0=$(recebidos)
P -d id=bluev $R/api/payloads/ativar > /dev/null; espera_livre
confere "Ativar de um glibren: erro"       "$(campo bluev "['erro']")" "e o proprio glibren"
confere "Ativar de um glibren: nada enviado" "$(recebidos)" "^$N0$"
rm -f $PAY/bluev.*

echo "--- 8: SHA-256 so dos sugeridos"
LISTA=$(curl -s "$L/api/payloads/arquivos?id=shadowkraken")
confere "sugerido: com SHA-256"            "$LISTA" 'Dev.7-pristmc.elf",[^}]*"sugerido":true,"versao":"1.00-Dev.7-pristmc","sha256":"[0-9a-f]\{64\}"'
confere "outro: sem SHA, nao_conferido"    "$LISTA" 'outro-payload.elf",[^}]*"sugerido":false,"versao":"","sha256":"","estado":"nao_conferido"'
para
BUSCA_MS=1500 inicia
(curl -s "$L/api/payloads/arquivos?id=kstuff" > $T/busca1.json) & B1=$!
sleep 0.4
confere "2a busca junto: ocupada"          "$(curl -s "$L/api/payloads/arquivos?id=kstuff")" '"chave":"payload_busca_ocupada"'
wait $B1
confere "1a busca: terminou bem"           "$(cat $T/busca1.json)" '"ok":true'
confere "depois: livre"                    "$(curl -s "$L/api/payloads/arquivos?id=kstuff")" '"ok":true'
para

echo "--- 10: pagina sem reticencias"
inicia
PG=$(curl -s "$L/payloads")
confere "pagina servida"                   "$PG" "arq_escolher"   # 0.9.44: a lista antiga (arq_sha_ini) saiu
nao_tem "sem reticencias"                  "$PG" "…"
nao_tem "sem SHA cortado com reticencias"  "$PG" 'slice(0, 16) + "'
confere "SHA completo no Instalado"        "$PG" 's: r.sha256 || ""'
confere "pergunta explicita do kstuff"     "$PG" "Tenho certeza de que o kstuff não está carregado"
para

echo "--- conversoes e instalacoes (Dump Forge falso)"
liga_df; echo lento > $T/df/modo_inst; echo lento > $T/df/modo
for k in $(seq -w 1 34); do pkg "$A/Jogo$k-PPSA000$k.pkg" FIH 2048; done
echo dados > "$A/Img-PPSA05555.exfat"
inicia
J() { curl -s "$L/api/conversao"; }
conta() { J | python3 -c "import json,sys; d=json.load(sys.stdin); print(sum(1 for i in d['itens'] if $1))"; }

echo "--- 9: o mesmo .pkg 10 vezes ao mesmo tempo"
juntos 10 post -d "pasta=$A/" -d de=Jogo01-PPSA00001.pkg $L/api/conversao/instalar
confere "entrou uma vez so"                "$(conta "i['origem'].endswith('Jogo01-PPSA00001.pkg')")" "^1$"

echo "--- 6: .pkg que uma conversao ainda gera"
confere "conversao para .pkg pedida"       "$(post -d formato=pkg -d "pasta=$A/" -d de=Img-PPSA05555.exfat $L/api/conversao)" '"criadas":1'
confere "instalar o .pkg em geracao: em_uso" "$(post -d "pasta=$A/" -d de=Img-PPSA05555.pkg $L/api/conversao/instalar)" '"criadas":0.*"motivo":"em_uso"'

echo "--- 1: lista cheia (32 ativos)"
ARGS=(); for k in $(seq -w 2 31); do ARGS+=(-d "pasta=$A/" -d "de=Jogo$k-PPSA000$k.pkg"); done
confere "30 entram (2 ja estavam)"         "$(post "${ARGS[@]}" $L/api/conversao/instalar)" '"criadas":30'
confere "32 ativos"                        "$(conta "i['estado'] not in ('feito','erro','cancelado','perdido')")" "^32$"
PED0=$(grep -c . $T/df/pedidos.jsonl)
R1=$(post -d "pasta=$A/" -d de=Jogo32-PPSA00032.pkg -d "pasta=$A/" -d de=Jogo33-PPSA00033.pkg $L/api/conversao/instalar)
confere "33o: fila_cheia"                  "$R1" '"criadas":0.*"motivo":"fila_cheia".*"motivo":"fila_cheia"'
confere "conversao com a lista cheia: fila_cheia" "$(post -d formato=ffpkg -d "pasta=$A/" -d de=Img-PPSA05555.exfat $L/api/conversao)" '"criadas":0.*"motivo":"fila_cheia"'
confere "Dump Forge nao recebeu nada novo" "$(grep -c . $T/df/pedidos.jsonl)" "^$PED0$"
confere "nenhum ativo saiu"                "$(conta "i['estado'] not in ('feito','erro','cancelado','perdido')")" "^32$"
ID=$(J | python3 -c "import json,sys; print([i['id'] for i in json.load(sys.stdin)['itens'] if i['origem'].endswith('Jogo31-PPSA00031.pkg')][0])")
post -d id=$ID $L/api/conversao/cancelar > /dev/null
confere "com um cancelado: entra no lugar" "$(post -d "pasta=$A/" -d de=Jogo32-PPSA00032.pkg $L/api/conversao/instalar)" '"criadas":1'
confere "ainda 32 ativos"                  "$(conta "i['estado'] not in ('feito','erro','cancelado','perdido')")" "^32$"
confere "o cancelado saiu da lista"        "$(conta "i['origem'].endswith('Jogo31-PPSA00031.pkg')")" "^0$"

echo "--- 5: Dump Forge que nao responde"
J > /dev/null; J > /dev/null
para_df
E=$(J); confere "1a falha: nada perdido"   "$(echo "$E" | grep -c perdido)" "^0$"
E=$(J); confere "2a falha: nada perdido"   "$(echo "$E" | grep -c perdido)" "^0$"
J > /dev/null
confere "3a falha: os do Dump Forge perdidos" "$(conta "i['estado']=='perdido' and i['job']>0")" "^[1-9]"
confere "a espera (job 0) nunca perdida"   "$(conta "i['estado']=='perdido' and i['job']==0")" "^0$"
confere "a espera continua na fila"        "$(conta "i['estado']=='espera'")" "^[1-9]"
liga_df
J > /dev/null; sleep 0.3; J > /dev/null
confere "Dump Forge de volta: a proxima vai" "$(conta "i['instalar'] and i['estado'] in ('fila','rodando')")" "^1$"
para; para_df; para_el
echo "=== $ok ok, $falhas falhas"
[ $falhas -eq 0 ]
