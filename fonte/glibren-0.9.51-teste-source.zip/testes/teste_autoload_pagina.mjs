// 0.9.41: pagina Payloads - chave "Carregar ao iniciar o glibren" (so nos itens que podem e estao instalados), avisos
// (kraken-mount .exfat, montadores exclusivos, regras do kstuff), cartao do kstuff ("Esta carregado?", aviso fixo,
// arquivo seu, instalado como) e "Instalar de arquivo" (0.9.44: janela de pastas com atalhos, so .elf, sugeridos em
// verde, instalar fecha a janela), em 360 e 1280: sem rolar de
// lado, botoes da mesma linha com a mesma largura, nada cortado. Chamado pelo testes/teste_autoload.sh.
//   node teste_autoload_pagina.mjs http://127.0.0.1:8971 <pasta do pacote playwright>
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const [base, pw, fotos] = process.argv.slice(2);   // fotos: pasta para a imagem da janela de pastas (opcional)
const { chromium } = await import(pathToFileURL(path.join(pw, 'index.mjs')).href);
let ok = 0, falhas = 0;
const confere = (nome, cond, info = '') => { if (cond) { ok++; console.log('OK   ' + nome); } else { falhas++; console.log('FALHA ' + nome + (info ? ': ' + info : '')); } };

let navegador;
for (const channel of ['msedge', 'chrome']) { try { navegador = await chromium.launch({ channel }); break; } catch { /* outro */ } }
if (!navegador) { console.log('FALHA nenhum navegador abriu'); console.log('=== pagina 0 ok, 1 falhas'); process.exit(1); }

const medir = pagina => pagina.evaluate(() => {
  const larguras = [...document.querySelectorAll('.botoes')].filter(b => b.offsetParent).map(b =>
    [...b.querySelectorAll('button')].filter(x => x.offsetParent).map(x => Math.round(x.getBoundingClientRect().width)));
  const cortados = [...document.querySelectorAll('button, .linha, .agora, .avisos, h2, .arq-item small, .arq-nome, summary')].filter(e => e.offsetParent &&
    (getComputedStyle(e).textOverflow === 'ellipsis' || e.scrollWidth > e.clientWidth + 1)).map(e => e.className + ':' + e.textContent.slice(0, 40));
  return { larguras, cortados, rola: document.scrollingElement.scrollWidth > innerWidth };
});

for (const tela of [{ w: 360, h: 780, nome: 'celular' }, { w: 1280, h: 800, nome: 'PC' }]) {
  const pagina = await navegador.newPage({ viewport: { width: tela.w, height: tela.h } });
  const n = s => `${s} (${tela.nome})`;
  await pagina.goto(base + '/payloads');
  await pagina.waitForFunction(() => document.querySelector('.item[data-id="kstuff"] .arq-seu')?.textContent, null, { timeout: 20000 }).catch(() => null);
  const card = id => `.item[data-id="${id}"]`;
  const vis = sel => pagina.isVisible(sel).catch(() => false);
  const txt = sel => pagina.$eval(sel, e => e.textContent).catch(() => '');
  confere(n('Dump Forge (instalado): chave visivel'), await vis(card('dump-forge') + ' .autoload .chk-autoload'));
  confere(n('chave: texto'), (await txt(card('dump-forge') + ' .autoload .chave')).includes('Carregar ao iniciar o glibren'));
  for (const id of ['prefbar', 'zhithemes', 'web-browser-fullscreen'])
    confere(n(`${id}: sem chave`), !(await pagina.$(card(id) + ' .autoload')));
  confere(n('kraken-mount: aviso .exfat'), (await txt(card('kraken-mount') + ' .autoload')).includes('não monta imagens .exfat') &&
    (await txt(card('kraken-mount') + ' .autoload')).includes('JobeesLair.exfat'));
  confere(n('kraken-mount: so um montador'), (await txt(card('kraken-mount') + ' .autoload')).includes('Só um montador'));
  confere(n('ShadowKraken: chave (instalado de arquivo)'), await vis(card('shadowkraken') + ' .autoload .chk-autoload'));
  const ks = await txt(card('kstuff'));
  confere(n('kstuff: aviso fixo'), ks.includes('kstuff mexe no kernel; use só um arquivo em que você confia; o glibren não verifica a origem'));
  confere(n('kstuff: esta carregado?'), /kstuff (ativo nesta sessão|não carregado)|Não deu para saber/.test(await txt(card('kstuff') + ' .agora')), await txt(card('kstuff') + ' .agora'));
  confere(n('kstuff: regras do autoinicio'), ks.includes('vem antes dos outros') && ks.includes('nunca duas vezes no mesmo boot'));
  confere(n('kstuff: arquivo seu + instalado como'), (await txt(card('kstuff') + ' .arq-seu')).includes('Kstuff-NG_v1.00.elf') &&
    (await txt(card('kstuff') + ' .arq-seu')).includes('instalado como kstuff-PristMC.elf'), await txt(card('kstuff') + ' .arq-seu'));
  confere(n('kstuff: sem botao Baixar'), !(await vis(card('kstuff') + ' .b-baixar')));
  // 0.9.44: Instalar de arquivo = janela de pastas (atalhos do glibren, so pastas e .elf, sugeridos em verde)
  await pagina.click(card('kstuff') + ' .arq summary');
  await pagina.evaluate(() => { try { localStorage.removeItem('glrArqPasta'); } catch { /* sem armazenamento */ } });   // a pasta guardada vale entre as telas
  await pagina.click(card('kstuff') + ' .b-arq-escolher');
  const lista = () => pagina.$$eval('#arqPastas .ger-item', es => es.map(e => ({ t: e.textContent, sug: e.classList.contains('sug'), elf: !!e.dataset.elf, pasta: !!e.dataset.caminho })));
  const espera = async parte => { for (let k = 0; k < 50; k++) { if ((await lista()).some(i => i.t.includes(parte))) return; await pagina.waitForTimeout(100); } };
  await espera('Kstuff-NG_v1.00.elf');
  confere(n('janela aberta'), await vis('#arqJanela.aberto') && (await txt('#arqTit')) === 'Escolha o .elf para kstuff (arquivo seu)', await txt('#arqTit'));
  const atalhos = await pagina.$$eval('#arqAtalhos button', es => es.map(e => e.textContent));
  confere(n('atalhos: payload manager primeiro + discos'), atalhos[0] === '📁 Payload manager' && atalhos.length === 3 && atalhos[1].endsWith('/usb0') && atalhos[2].endsWith('/data'), JSON.stringify(atalhos));
  confere(n('comeca na pasta do payload manager'), (await txt('#arqTrilha')).endsWith('pldmgr/payloads'), await txt('#arqTrilha'));
  let l = await lista();
  confere(n('payload manager: os 2 .elf, o kstuff em verde'), l.length === 2 && l.find(i => i.t.includes('Kstuff-NG_v1.00.elf'))?.sug && !l.find(i => i.t.includes('outro-payload.elf'))?.sug, JSON.stringify(l));
  await pagina.click('#arqAtalhos button:nth-child(2)');
  await espera('kstuff-v1.01.elf');
  l = await lista();
  confere(n('usb0: pasta sub + .elf, kstuff em verde'), l[0]?.pasta && l[0].t.includes('sub') && l.find(i => i.t.includes('kstuff-v1.01.elf'))?.sug, JSON.stringify(l));
  await pagina.click('#arqPastas [data-caminho$="/sub"]');
  await espera('Dev.8');
  l = await lista();
  confere(n('sub: os ShadowKraken, sem verde (nao e kstuff)'), l.length === 2 && l.every(i => i.elf && !i.sug), JSON.stringify(l));
  if (fotos) await pagina.screenshot({ path: path.join(fotos, `arquivo-${tela.w}.png`) });
  confere(n('trilha: volta pelas pastas'), (await pagina.$$eval('#arqTrilha button', es => es.map(e => e.textContent))).slice(-2).join('/') === 'usb0/sub');
  const mj = await medir(pagina);
  const caixa = await pagina.$eval('.arq-caixa', e => { const r = e.getBoundingClientRect(); return r.left >= 0 && r.right <= innerWidth && r.top >= 0 && r.bottom <= innerHeight; });
  confere(n('janela: cabe na tela'), caixa && !mj.rola);
  confere(n('janela: nada cortado, botoes iguais'), mj.cortados.length === 0 && mj.larguras.every(x => x.every(y => Math.abs(y - x[0]) <= 1)), mj.cortados.join(' | ') + JSON.stringify(mj.larguras));
  // tocar num .elf: pergunta e instala; deu certo = a janela fecha (servidor respondido por page.route: a pagina aberta em
  // 127.0.0.1 e "local" e o glibren recusaria)
  await pagina.click('#arqTrilha button:nth-last-child(3)');   // volta para usb0
  await espera('kstuff-v1.01.elf');
  const perguntas = [], enviados = [];
  const aceita = async d => { perguntas.push(d.message()); await d.accept(); };
  pagina.on('dialog', aceita);
  await pagina.route('**/api/payloads/arquivo', async rota => { enviados.push(rota.request().postData() || '');
    await rota.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ ok: true, versao: '1.01', nome: 'kstuff-v1.01.elf', fonte: 'disco', tamanho: 4200, sha256: 'ab12' }) }); });
  await pagina.click('#arqPastas [data-elf$="kstuff-v1.01.elf"]');
  for (let k = 0; k < 50 && (await vis('#arqJanela.aberto')); k++) await pagina.waitForTimeout(100);
  pagina.off('dialog', aceita);
  await pagina.unroute('**/api/payloads/arquivo');
  confere(n('elf: pergunta com o caminho'), (perguntas[0] || '').includes('/usb0/kstuff-v1.01.elf') && (perguntas[0] || '').includes('kstuff (arquivo seu)'), JSON.stringify(perguntas));
  confere(n('elf: manda id e caminho'), (enviados[0] || '').includes('id=kstuff') && decodeURIComponent(enviados[0] || '').includes('/usb0/kstuff-v1.01.elf'), JSON.stringify(enviados));
  confere(n('instalou: janela fecha e avisa'), !(await vis('#arqJanela.aberto')) && (await txt('#msg')).includes('Instalado: kstuff-v1.01.elf'), await txt('#msg'));
  // 0.9.45: "Enviar deste celular/PC": o .elf escolhido no aparelho vai inteiro no corpo (id e nome na query)
  confere(n('enviar: botao ao lado do Escolher'), (await txt(card('kstuff') + ' .b-arq-enviar')) === '📤 Enviar deste celular/PC', await txt(card('kstuff') + ' .b-arq-enviar'));
  const envios = [], perguntasEnv = [];
  const aceitaEnv = async d => { perguntasEnv.push(d.message()); await d.accept(); };
  pagina.on('dialog', aceitaEnv);
  await pagina.route('**/api/payloads/enviar**', async rota => { const q = rota.request(); envios.push({ url: q.url(), tam: (q.postDataBuffer() || Buffer.alloc(0)).length, x: q.headers()['x-glr'] });
    await rota.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ ok: true, versao: '1.02', nome: 'kstuff-celular.elf', fonte: 'celular', tamanho: 3000, sha256: 'cd34' }) }); });
  const corpo = Buffer.concat([Buffer.from('\x7fELF'), Buffer.alloc(2996, 7)]);
  await pagina.setInputFiles(card('kstuff') + ' .arq-env-input', { name: 'kstuff-celular.elf', mimeType: 'application/octet-stream', buffer: corpo });
  for (let k = 0; k < 50 && !(await txt('#msg')).includes('Instalado: kstuff-celular.elf'); k++) await pagina.waitForTimeout(100);
  const msgOk = await txt('#msg');
  await pagina.setInputFiles(card('kstuff') + ' .arq-env-input', { name: 'kstuff.bin', mimeType: 'application/octet-stream', buffer: corpo });
  await pagina.waitForTimeout(200);
  const msgNome = await txt('#msg');
  pagina.off('dialog', aceitaEnv);
  await pagina.unroute('**/api/payloads/enviar**');
  confere(n('enviar: pergunta antes'), (perguntasEnv[0] || '').includes('Enviar kstuff-celular.elf') && (perguntasEnv[0] || '').includes('kstuff (arquivo seu)'), JSON.stringify(perguntasEnv));
  confere(n('enviar: id, nome e o arquivo inteiro'), envios.length === 1 && envios[0].url.includes('id=kstuff') && envios[0].url.includes('nome=kstuff-celular.elf') && envios[0].tam === 3000 && envios[0].x === '1', JSON.stringify(envios));
  confere(n('enviar: avisa instalado'), msgOk.startsWith('Instalado: kstuff-celular.elf'), msgOk);
  confere(n('enviar: sem .elf nem pergunta'), msgNome === 'Escolha um arquivo .elf.' && perguntasEnv.length === 1, msgNome);
  if (tela.nome === 'celular') {
    // revisao 0.9.41: Ativar do kstuff com o marcador deste boot = pergunta explicita. A pagina aberta em 127.0.0.1 e
    // "local" (o glibren recusa Ativar dela): o servidor responde por page.route como o glibren responderia ao celular.
    const pedidos = [];
    await pagina.route('**/api/payloads/ativar', async rota => {
      const corpo = rota.request().postData() || '';
      pedidos.push(corpo);
      if (!corpo.includes('confirmo_kstuff=1'))
        await rota.fulfill({ status: 409, contentType: 'application/json', body: JSON.stringify({ ok: false, chave: 'payload_kstuff_confirmar', erro: 'x', params: { nome: 'boot' } }) });
      else await rota.fulfill({ status: 200, contentType: 'application/json', body: '{"ok":true}' });
    });
    const dialogos = [];
    const tratar = async d => { dialogos.push(d.message()); await d.accept(); };
    pagina.on('dialog', tratar);
    await pagina.click(card('kstuff') + ' .b-ativar').catch(() => null);
    for (let k = 0; k < 50 && pedidos.length < 2; k++) await pagina.waitForTimeout(100);
    pagina.off('dialog', tratar);
    await pagina.unroute('**/api/payloads/ativar');
    confere(n('kstuff Ativar: pergunta explicita'), (dialogos[1] || '').includes('Tenho certeza de que o kstuff não está carregado'), JSON.stringify(dialogos));
    confere(n('kstuff Ativar: motivo (ja mandado neste boot)'), (dialogos[1] || '').includes('já mandou o kstuff neste boot'), dialogos[1] || '');
    confere(n('kstuff Ativar: 1o pedido sem confirmacao'), pedidos[0] !== undefined && !pedidos[0].includes('confirmo_kstuff'), JSON.stringify(pedidos));
    confere(n('kstuff Ativar: OK manda confirmo_kstuff=1'), (pedidos[1] || '').includes('confirmo_kstuff=1'), JSON.stringify(pedidos));
    confere(n('kstuff Ativar: sem reticencias'), !dialogos.some(d => d.includes('…')));
  }
  const m = await medir(pagina);
  confere(n('sem rolar de lado'), !m.rola);
  confere(n('botoes da mesma linha: mesma largura'), m.larguras.every(l => l.every(x => Math.abs(x - l[0]) <= 1)), JSON.stringify(m.larguras));
  confere(n('nada cortado'), m.cortados.length === 0, m.cortados.join(' | '));
  await pagina.close();
}
await navegador.close();
console.log(`=== pagina ${ok} ok, ${falhas} falhas`);
process.exit(falhas ? 1 : 0);
