// 0.9.41: pagina principal - botao Instalar (so .pkg) ao lado do Converter, pergunta de instalacao (instalar x rodar sem
// instalar, espaco, firmware, FPKG de PS5 acima do 11.60 / kstuff) e a janela Tarefas do Dump Forge (entregue, codigo
// traduzido). Telas 360x780 e 1280x800: sem reticencias, botoes lado a lado com a mesma largura, sem rolar de lado.
// Chamado pelo testes/teste_instalacao.sh com o glibren-pc e o Dump Forge falso no ar.
//   node teste_instalacao_pagina.mjs http://127.0.0.1:8961 <pasta do pacote playwright>
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const [base, pw] = process.argv.slice(2);
const { chromium } = await import(pathToFileURL(path.join(pw, 'index.mjs')).href);
let ok = 0, falhas = 0;
const confere = (nome, cond, info = '') => { if (cond) { ok++; console.log('OK   ' + nome); } else { falhas++; console.log('FALHA ' + nome + (info ? ': ' + info : '')); } };

let navegador;
for (const channel of ['msedge', 'chrome']) { try { navegador = await chromium.launch({ channel }); break; } catch { /* outro */ } }
if (!navegador) { console.log('FALHA nenhum navegador abriu'); console.log('=== pagina 0 ok, 1 falhas'); process.exit(1); }

const caixas = (pagina, sel) => pagina.$$eval(sel, bs => bs.filter(b => b.offsetParent).map(b => { const r = b.getBoundingClientRect(); return [Math.round(r.width), Math.round(r.top)]; }));
const ladoALado = c => c.length >= 2 && new Set(c.map(x => x[0])).size === 1 && new Set(c.map(x => x[1])).size === 1 && c[0][0] > 0;

for (const tela of [{ w: 360, h: 780, nome: 'celular' }, { w: 1280, h: 800, nome: 'PC' }]) {
  const pagina = await navegador.newPage({ viewport: { width: tela.w, height: tela.h } });
  const n = s => `${s} (${tela.nome})`;
  const semRolagem = () => pagina.evaluate(() => document.scrollingElement.scrollWidth <= innerWidth);
  const reticencias = () => pagina.$$eval('.acoes-lote button:not(#btnTopo), #instalacao button, #janelaConv button', bs => bs.filter(b => b.offsetParent && (getComputedStyle(b).textOverflow === 'ellipsis' || b.scrollWidth > b.clientWidth + 1)).map(b => b.id || b.textContent));
  await pagina.goto(base + '/');
  await pagina.click('#btnConectar');
  await pagina.waitForSelector('#corpoFtp .sel-item', { timeout: 20000 });
  await pagina.click('#filtrosFtp [data-filtro="todos"]');
  // nada marcado: Instalar (0) desligado, Converter vira "Tarefas do Dump Forge"
  const vazio = await pagina.evaluate(() => [document.getElementById('btnInstalar').disabled, document.getElementById('btnInstalar').textContent, document.getElementById('btnConverter').textContent]);
  confere(n('sem marcados: Instalar (0) desligado'), vazio[0] && vazio[1].includes('(0)'), JSON.stringify(vazio));
  confere(n('sem marcados: Tarefas do Dump Forge'), vazio[2].includes('Tarefas do Dump Forge'), vazio[2]);
  if (tela.nome === 'celular') {
    const cv = await caixas(pagina, '#btnConverter, #btnInstalar');
    confere(n('Converter e Instalar lado a lado, mesma largura'), cv.length === 2 && ladoALado(cv), JSON.stringify(cv));
  } else {
    confere(n('Converter e Instalar visiveis'), await pagina.isVisible('#btnConverter') && await pagina.isVisible('#btnInstalar'));
  }
  confere(n('barra: sem rolar de lado'), await semRolagem());
  // marca tudo: Instalar conta so os .pkg
  await pagina.$eval('#selTodos', c => { if (!c.checked) c.click(); });
  const pkgs = await pagina.$$eval('#corpoFtp .arq:not(.novo)', ds => ds.filter(d => /\.pkg$/i.test(d.textContent)).length);
  const rot = await pagina.textContent('#btnInstalar');
  confere(n('Instalar (n) so com os .pkg'), rot.includes(`(${pkgs})`) && pkgs >= 3 && !(await pagina.isDisabled('#btnInstalar')), rot + ' / ' + pkgs);
  confere(n('barra marcada: sem reticencias'), (await reticencias()).length === 0, JSON.stringify(await reticencias()));
  await pagina.click('#btnInstalar');
  await pagina.waitForSelector('#instalacao.aberto');
  const txt = await pagina.textContent('#instalacao');
  confere(n('pergunta: titulo com a quantidade'), (await pagina.textContent('#inTitulo')).includes(`Instalar ${pkgs} pacote`), await pagina.textContent('#inTitulo'));
  confere(n('pergunta: instalar x rodar sem instalar'), txt.includes('Rodar sem instalar') && txt.includes('ShadowKraken'));
  confere(n('pergunta: espaco e o .pkg fica'), txt.includes('espaço livre') && txt.includes('nunca é apagado nem movido'));
  confere(n('pergunta: firmware do PS5'), txt.includes('Firmware deste PS5: 12.00'), txt.slice(0, 400));
  const av = await pagina.$eval('#inAvisoPs5', d => ({ vis: !d.hidden, tx: d.textContent, alto: d.classList.contains('alto') }));
  confere(n('pergunta: FPKG de PS5 acima do 11.60 = kstuff'), av.vis && av.alto && av.tx.includes('11.60') && av.tx.includes('kstuff') && av.tx.includes('A53'), JSON.stringify(av));
  confere(n('pergunta: PS4 instala normalmente'), await pagina.isVisible('#inAvisoPs4'));
  confere(n('pergunta: os outros marcados ficam de fora'), (await pagina.textContent('#inFora')).includes('não são .pkg'));
  confere(n('pergunta: entregar nao e instalar'), txt.includes('notificações'));
  const bi = await caixas(pagina, '#instalacao .cv-botoes button');
  confere(n('pergunta: 2 botoes lado a lado, mesma largura'), bi.length === 2 && ladoALado(bi), JSON.stringify(bi));
  confere(n('pergunta: sem reticencias'), (await reticencias()).length === 0, JSON.stringify(await reticencias()));
  confere(n('pergunta: sem rolar de lado'), await semRolagem());
  if (tela.nome === 'celular') {
    await pagina.click('#inCancelar');
    confere(n('cancelar fecha'), !(await pagina.isVisible('#instalacao')));
    await pagina.$eval('#btnConverter', b => { if (b.textContent.includes('Converter')) document.getElementById('selTodos').click(); });
    await pagina.$eval('#btnConverter', b => b.click());
  } else {
    await pagina.click('#inConfirmar');
  }
  await pagina.waitForSelector('#janelaConv.aberto', { timeout: 8000 });
  confere(n('janela: Tarefas do Dump Forge'), (await pagina.textContent('#janelaConv h2')).includes('Tarefas do Dump Forge'));
  // o recusado com codigo (feito pelo .sh antes): codigo traduzido + lembrete do kstuff (PS5 no 12.00)
  await pagina.waitForFunction(() => document.querySelector('#convLista').textContent.includes('0x80A30002'), null, { timeout: 10000 }).catch(() => null);
  const lista = await pagina.textContent('#convLista');
  confere(n('janela: codigo traduzido'), lista.includes('O PS5 recusou (0x80A30002): falta espaço livre no PS5'), lista.slice(0, 500));
  confere(n('janela: lembrete do kstuff (PS5, 12.00)'), lista.includes('kstuff que tenha suporte a FPKG (A53)'), lista.slice(0, 500));
  if (tela.nome === 'PC') {
    await pagina.waitForFunction(() => document.querySelector('#convLista').textContent.includes('Enviado ao instalador do PS5'), null, { timeout: 20000 }).catch(() => null);
    const l2 = await pagina.textContent('#convLista');
    confere(n('janela: entregue = acompanhe nas notificacoes'), l2.includes('Enviado ao instalador do PS5; acompanhe nas notificações do PS5.'), l2.slice(0, 600));
    confere(n('janela: destino = instalador do PS5'), l2.includes('→ instalador do PS5'));
  }
  confere(n('janela: sem reticencias'), (await reticencias()).length === 0, JSON.stringify(await reticencias()));
  confere(n('janela: sem rolar de lado'), await semRolagem());
  const bj = await caixas(pagina, '#janelaConv > .ger-caixa > .cv-botoes button');
  confere(n('janela: botoes lado a lado, mesma largura'), ladoALado(bj), JSON.stringify(bj));
  await pagina.close();
}
await navegador.close();
console.log(`=== pagina ${ok} ok, ${falhas} falhas`);
process.exit(falhas ? 1 : 0);
