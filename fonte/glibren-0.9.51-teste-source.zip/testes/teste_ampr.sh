#!/bin/bash
# Testa o build de teste do ampr-emu-ng no ShadowKraken (0.9.51) na versao de PC: GET /api/ampr, envio pelo celular/PC
# (POST /api/ampr/enviar), escolha num disco (POST /api/ampr/arquivo), voltar ao embutido (POST /api/ampr/embutido),
# recusas (PS5/127.0.0.1, nao-ampr, nao-ELF, grande demais, fora dos discos, jogo aberto), [emulators] path do
# config.ini do ShadowKraken, e as copias do /data/ampr_emu_trace.txt (parado ha 2 s, title ID no nome, so as 5 mais
# novas). /data = $T/montador (GLR_TESTE_MONTADOR, o mesmo do diagnostico).
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_ampr.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8971
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R="http://$IP:$PORTA"
T=/root/glr-ampr; DADOS=$T/dados; A=$T/lista; M=$T/montador; D=$T/disco
RT=$M/shadowmount/emus/ampr-emu-ng/libSceAmpr.sprx
UA_PS5='Mozilla/5.0 (PlayStation; PlayStation 5/12.00) AppleWebKit/605.1.15 (KHTML, like Gecko)'
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$(echo "$2" | head -c 600)] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
TOKEN=""
post() { curl -s -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" "$@"; }
codigo() { curl -s -o /dev/null -w '%{http_code}' -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" "$@"; }
estado() { curl -s "$L/api/ampr"; }
enviar() { post --data-binary "@$1" "$R/api/ampr/enviar?nome=$2"; }
rm -rf "$T"; mkdir -p "$DADOS" "$A" "$M/shadowmount" "$D/pasta"
printf 'language = pt-BR\nfolder = %s/\n' "$A" > "$DADOS/config.ini"

# runtimes de mentira: magia SELF + "ampr-emu-ng X.Y.Z"; o de depuracao tem o caminho do trace e o commit
python3 -I - "$T" <<'EOF'
import os, sys
t = sys.argv[1]
def grava(nome, corpo, tam=200000, magia=b"\x4f\x15\x3d\x1d"):
    d = magia + b"\0" * 1000 + corpo
    d += b"\0" * (tam - len(d))
    open(os.path.join(t, nome), "wb").write(d)
grava("release.sprx", b"xx ampr-emu-ng 0.5.0\0")
grava("debug.sprx", b"ampr-emu-ng 0.5.0\0/data/ampr_emu_trace.txt\0elMmapdup/download0/0.5.0lz4pkgplain-fs 5a8cca6startok\0", 300000)
grava("sem-marcador.sprx", b"isto nao e o runtime\0")
grava("nao-elf.sprx", b"ampr-emu-ng 0.5.0\0", magia=b"PK\3\4")
grava("pequeno.sprx", b"ampr-emu-ng 0.5.0\0", tam=10000)
grava("grande.sprx", b"ampr-emu-ng 0.5.0\0", tam=9 * 1024 * 1024)
EOF
cp "$T/debug.sprx" "$D/pasta/ampr-pr113-debug.sprx"
cp "$T/grande.sprx" "$D/pasta/grande.sprx"
SHA_REL=$(sha256sum "$T/release.sprx" | cut -d' ' -f1); SHA_DBG=$(sha256sum "$T/debug.sprx" | cut -d' ' -f1)

inicia() {
  GLR_TESTE_MONTADOR="$M" GLR_TESTE_ARQ_RAIZES="$D" GLR_TESTE_ABERTOS="$T/abertos" GLR_TESTE_AMPR_VIGIA_MS=200 GLR_TESTE_AMPR_PARADO_S=2 \
    "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
inicia
# pareia o "celular" (as rotas de troca so pelo celular/PC pareado)
curl -s -H 'X-GLR: 1' -X POST $R/api/parear/pedir > /dev/null
C=$(grep -o 'pareamento [0-9]\{6\}' "$T/glr.log" | tail -1 | awk '{print $2}')
TOKEN=$(curl -s -H 'X-GLR: 1' -d codigo=$C -d nome=Teste $R/api/parear | python3 -c 'import json,sys; print(json.load(sys.stdin)["token"])')
confere "pareado"                           "$TOKEN" "^[0-9a-f]\{64\}$"

echo "--- estado inicial"
E=$(estado)
confere "sem arquivo de teste"              "$E" '"teste":null'
confere "sem anterior"                      "$E" '"anterior":null'
confere "sem traces"                        "$E" '"traces":0,"ultimo_trace":null'
confere "pasta padrao dos emuladores"       "$E" "\"pasta_emus\":\"$M/shadowmount/emus\""

echo "--- recusas"
confere "127.0.0.1 = 403"                   "$(codigo --data-binary @$T/release.sprx "$L/api/ampr/enviar?nome=r.sprx")" "403"
confere "navegador do PS5 = 403"            "$(codigo -A "$UA_PS5" --data-binary @$T/release.sprx "$R/api/ampr/enviar?nome=r.sprx")" "403"
confere "sem X-GLR = 403"                   "$(curl -s -o /dev/null -w '%{http_code}' -H "X-GLR-Token: $TOKEN" --data-binary @$T/release.sprx "$R/api/ampr/enviar?nome=r.sprx")" "403"
confere "sem token = 401"                   "$(curl -s -o /dev/null -w '%{http_code}' -H 'X-GLR: 1' --data-binary @$T/release.sprx "$R/api/ampr/enviar?nome=r.sprx")" "401"
confere "nome que nao e .sprx"              "$(enviar $T/release.sprx r.elf)" '"chave":"ampr_arquivo_nome"'
confere "sem o marcador = recusa"           "$(enviar $T/sem-marcador.sprx s.sprx)" 'nao tem o marcador'
confere "nao e SELF/ELF = recusa"           "$(enviar $T/nao-elf.sprx n.sprx)" 'nao e um SELF/ELF'
confere "pequeno demais = recusa"           "$(enviar $T/pequeno.sprx p.sprx)" 'tamanho fora do limite'
confere "grande demais (envio) = 413"       "$(codigo --data-binary @$T/grande.sprx "$R/api/ampr/enviar?nome=g.sprx")" "413"
confere "grande demais (disco) = recusa"    "$(post --data-urlencode "caminho=$D/pasta/grande.sprx" $R/api/ampr/arquivo)" 'tamanho fora do limite'
confere "fora dos discos = recusa"          "$(post --data-urlencode "caminho=$T/release.sprx" $R/api/ampr/arquivo)" '"chave":"ampr_arquivo_fora"'
confere "caminho com .. = recusa"           "$(post --data-urlencode "caminho=$D/pasta/../pasta/ampr-pr113-debug.sprx" $R/api/ampr/arquivo)" '"chave":"ampr_arquivo_fora"'
confere "nada gravado"                      "$(ls $M/shadowmount/emus/ampr-emu-ng 2>&1)" "No such file"

echo "--- enviar o release pelo celular/PC"
E=$(enviar $T/release.sprx ampr-emu-ng-pr113-5a8cca6-release.sprx)
confere "envio ok"                          "$E" '"ok":true,"nome":"ampr-emu-ng-pr113-5a8cca6-release.sprx","versao":"0.5.0","commit":"","depuracao":false'
confere "gravado no lugar do ShadowKraken"  "$(sha256sum $RT | cut -d' ' -f1)" "^$SHA_REL$"
confere "sem .tmp sobrando"                 "$(ls $M/shadowmount/emus/ampr-emu-ng)" "^libSceAmpr.sprx$"
E=$(estado)
confere "estado: teste valido"              "$E" "\"teste\":{\"valido\":true,\"caminho\":\"$RT\",\"versao\":\"0.5.0\",\"commit\":\"\",\"depuracao\":false"
confere "estado: SHA-256"                   "$E" "\"sha256\":\"$SHA_REL\""
confere "diario: instalado"                 "$(cat $DADOS/glibren.log)" "ampr-teste: build de teste instalado: celular/PC: ampr-emu-ng-pr113-5a8cca6-release.sprx"

echo "--- jogo aberto: recusa"
echo PPSA29629 > "$T/abertos"
E=$(post --data-urlencode "caminho=$D/pasta/ampr-pr113-debug.sprx" $R/api/ampr/arquivo)
confere "jogo aberto = ampr_jogo_aberto"    "$E" '"chave":"ampr_jogo_aberto".*"nome":"PPSA29629"'
confere "embutido com jogo aberto = 409"    "$(codigo -X POST $R/api/ampr/embutido)" "409"
confere "nao trocou"                        "$(sha256sum $RT | cut -d' ' -f1)" "^$SHA_REL$"
rm -f "$T/abertos"

echo "--- escolher o de depuracao num disco"
E=$(post --data-urlencode "caminho=$D/pasta/ampr-pr113-debug.sprx" $R/api/ampr/arquivo)
confere "disco ok, depuracao e commit"      "$E" '"ok":true,"nome":"ampr-pr113-debug.sprx","versao":"0.5.0","commit":"5a8cca6","depuracao":true'
confere "gravado (depuracao)"               "$(sha256sum $RT | cut -d' ' -f1)" "^$SHA_DBG$"
confere "release guardado como .anterior"   "$(sha256sum $RT.anterior | cut -d' ' -f1)" "^$SHA_REL$"
confere "origem fica"                       "$(ls $D/pasta)" "ampr-pr113-debug.sprx"
E=$(estado)
confere "estado: anterior = release"        "$E" "\"anterior\":{\"valido\":true,\"caminho\":\"$RT.anterior\",\"versao\":\"0.5.0\",\"commit\":\"\",\"depuracao\":false"

echo "--- [emulators] path do ShadowKraken"
printf '[general]\npath = /nao\n[emulators]\npath = /data/shadowmount/emus2/\n' > "$M/shadowmount/config.ini"
confere "pasta do config.ini"               "$(estado)" "\"pasta_emus\":\"$M/shadowmount/emus2\",\"teste\":null"
rm -f "$M/shadowmount/config.ini"

echo "--- voltar ao embutido"
confere "embutido ok"                       "$(post -X POST $R/api/ampr/embutido)" '"ok":true,"ja":false'
confere "arquivo de teste saiu"             "$(ls $RT 2>&1)" "No such file"
confere "o de teste ficou como .anterior"   "$(sha256sum $RT.anterior | cut -d' ' -f1)" "^$SHA_DBG$"
confere "estado: embutido"                  "$(estado)" '"teste":null'
confere "de novo: ja estava"                "$(post -X POST $R/api/ampr/embutido)" '"ok":true,"ja":true'
confere "diario: voltou"                    "$(cat $DADOS/glibren.log)" "ampr-teste: voltou ao ampr-emu-ng embutido"
printf 'lixo' > "$RT"
confere "arquivo invalido no lugar"         "$(estado)" "\"teste\":{\"valido\":false,\"caminho\":\"$RT\"}"
rm -f "$RT"

echo "--- traces do build de depuracao"
TR=$M/ampr_emu_trace.txt
for k in 1 2 3 4 5 6 7; do
  printf 'ampr-emu-ng 0.5.0 debug\ntitle PPSA29629 inicio %s\nlinha final %s\n' "$k" "$k" > "$TR"
  touch -d "2026-11-20 22:0$k:00" "$TR"
  for i in $(seq 1 40); do ls $DADOS/ampr-traces 2>/dev/null | grep -q "22:0$k\|220${k}00" && break; sleep 0.1; done
done
sleep 0.6
L5=$(ls $DADOS/ampr-traces)
confere "so as 5 mais novas"                "$(echo "$L5" | wc -l)" "^5$"
confere "nome com data e title ID"          "$L5" "2026-11-20_220700-PPSA29629.txt"
nao_tem "a mais velha saiu"                 "$L5" "220100"
nao_tem "a 2a mais velha saiu"              "$L5" "220200"
confere "conteudo copiado"                  "$(cat $DADOS/ampr-traces/2026-11-20_220700-PPSA29629.txt)" "linha final 7"
E=$(estado)
confere "estado: 5 traces e o ultimo"       "$E" '"traces":5,"ultimo_trace":{"nome":"2026-11-20_220700-PPSA29629.txt"'
confere "diario: trace copiado"             "$(cat $DADOS/glibren.log)" "ampr-teste: trace do ampr-emu-ng copiado: 2026-11-20_220700-PPSA29629.txt"
# o mesmo arquivo sem mudar: nao copia de novo
sleep 0.6
confere "sem copia repetida"                "$(ls $DADOS/ampr-traces | wc -l)" "^5$"
# sendo gravado agora (mtime recente): espera ficar parado
printf 'gravando\n' > "$TR"
sleep 0.4
confere "recente: ainda nao copia"          "$(grep -l gravando $DADOS/ampr-traces/* 2>/dev/null | wc -l)" "^0$"
sleep 3
confere "parado: copia"                     "$(grep -l gravando $DADOS/ampr-traces/* | wc -l)" "^1$"
para

echo "--- reinicio: o trace que ja existe nao vira copia nova"
inicia
sleep 1
confere "reinicio sem copia nova"           "$(ls $DADOS/ampr-traces | wc -l)" "^5$"
para

echo "--- pagina"
inicia
P=$(curl -s $L/payloads)
confere "pagina: secao do ampr-emu-ng"      "$P" 'class="ampr"'
confere "pagina: rota /api/ampr"            "$P" '/api/ampr/enviar'
confere "pagina: textos pt/en/es"           "$P" 'ampr_tit: "🧪 ampr-emu-ng runtime"'
para

rm -rf "$T"
echo "=== $ok ok, $falhas falhas"
[ $falhas -eq 0 ]
