# ShadowMount+/ShadowKraken falso (0.9.36) para os testes do original que vai para o BACKUP: imita a API local
# (POST com JSON, um pedido por conexao; json-c escreve "/" como "\/"; aqui o texto vai com \uXXXX nos acentos).
#   POST /api/v1/version            {"status":0,"shadowmount_version":"falso"}
#   POST /api/v1/games              {"status":0,"games":[{"path","title_id","mounted",...}]}
#   POST /api/v1/images             {"status":0,"images":[{"path","mounted","mapped",...}]}
#   POST /api/v1/games/unmount      {"title_id"}: jogo em "ativos" -> 409 {"status":16,"error_reason":"game_active"};
#                                   senao 200 e o jogo fica "mounted": false
#   POST /api/v1/scan               {"reset_attempts": bool} -> {"status":0,"queued":true}
# Estado em <pasta>/estado.json = {"games": [...], "images": [...], "ativos": ["PPSA..."]}, lido a cada pedido (o teste
# troca o arquivo). Os pedidos recebidos vao para <pasta>/pedidos.jsonl ({"rota", "corpo"}).
#   python3 -I smp_falso.py <porta> <pasta>
import json, socket, sys, threading

porta, pasta = int(sys.argv[1]), sys.argv[2]
trava = threading.Lock()


def estado():
    try:
        return json.load(open(pasta + "/estado.json", encoding="utf-8"))
    except (OSError, ValueError):
        return {"games": [], "images": [], "ativos": []}


def gravar(e):
    json.dump(e, open(pasta + "/estado.json", "w", encoding="utf-8"))


def responder(c, status, corpo):
    dados = json.dumps(corpo).replace("/", "\\/").encode()   # como o json-c; acentos viram \uXXXX (ensure_ascii)
    c.sendall(b"HTTP/1.1 %d X\r\nContent-Type: application/json\r\nContent-Length: %d\r\nConnection: close\r\n\r\n" % (status, len(dados)) + dados)


def atender(c):
    try:
        dados = b""
        while b"\r\n\r\n" not in dados:
            d = c.recv(65536)
            if not d:
                return
            dados += d
        cab, corpo = dados.split(b"\r\n\r\n", 1)
        linhas = cab.decode().split("\r\n")
        metodo, rota = linhas[0].split(" ")[:2]
        n = 0
        for l in linhas[1:]:
            if l.lower().startswith("content-length:"):
                n = int(l.split(":")[1])
        while len(corpo) < n:
            corpo += c.recv(65536)
        pedido = json.loads(corpo or b"{}")
        with trava:
            open(pasta + "/pedidos.jsonl", "a").write(json.dumps({"rota": rota, "corpo": pedido}) + "\n")
            e = estado()
            if metodo != "POST":
                responder(c, 405, {"status": 22, "error": "method not allowed"})
            elif rota == "/api/v1/version":
                responder(c, 200, {"status": 0, "shadowmount_version": "falso"})
            elif rota == "/api/v1/games":
                jogos = [{"path": g["path"], "runtime_path": "/mnt/shadowmnt/x", "source_type": "image", "image_type": "exfat",
                          "platform": "ps5", "title_id": g["title_id"], "title_name": "Jogo {\"x\"}", "mounted": g.get("mounted", False),
                          "installed": True, "extra": {"lista": [1, 2, {"a": None}]}} for g in e.get("games", [])]
                responder(c, 200, {"status": 0, "games": jogos})
            elif rota == "/api/v1/images":
                imgs = [{"path": i["path"], "mount_point": "/mnt/shadowmnt/y", "size": 1, "unit_id": 3, "backend": "lvd",
                         "complete": True, "source_available": True, "mapped": i.get("mapped", False), "mounted": i.get("mounted", False)}
                        for i in e.get("images", [])]
                responder(c, 200, {"status": 0, "images": imgs})
            elif rota == "/api/v1/games/unmount":
                tid = pedido.get("title_id", "")
                if tid in e.get("ativos", []):
                    responder(c, 409, {"status": 16, "error": "a game is active or awaiting exit; close the game and try again",
                                       "error_reason": "game_active"})
                else:
                    for g in e.get("games", []):
                        if g["title_id"] == tid:
                            g["mounted"] = False
                    gravar(e)
                    responder(c, 200, {"status": 0, "title_id": tid, "mounted": False})
            elif rota == "/api/v1/scan":
                responder(c, 200, {"status": 0, "queued": True, "reset_attempts": bool(pedido.get("reset_attempts"))})
            else:
                responder(c, 404, {"status": 2, "error": "unknown route"})
    except Exception as ex:  # noqa: BLE001 - o teste so precisa ver a falha no log
        print("erro:", ex, flush=True)
    finally:
        c.close()


s = socket.socket()
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("127.0.0.1", porta))
s.listen(16)
while True:
    c, _ = s.accept()
    threading.Thread(target=atender, args=(c,), daemon=True).start()
