#!/bin/bash
# Testa o "Enviar diagnostico" (0.9.21) na versao de PC, sem chamar o GitHub de verdade: um servidor falso em
# 127.0.0.1 (GLR_TESTE_GITHUB) recebe os PUT e guarda o que chegou. Confere: recusa sem chave; chave da Jobe usada
# quando existe (e nunca apagada); colar/remover a chave (0600, nunca em GET, nunca no diario); pareamento (401 pela
# rede sem token, 403 sem X-GLR, 200 com token); upload (caminho glibren/<pasta>/<arquivo>, Bearer, committer PristMC,
# base64); higienizacao (chaves, Authorization, cookies, query strings, e-mails, token e hash do pareamento); erros
# 401/403/404/sem internet; uma rodada por vez (409); pasta repetida no mesmo segundo (-2); o .zip.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_diagnostico.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
VERSAO=$(grep -o 'define VERSAO "[^"]*"' "$ORIGEM/src/api.h" | cut -d'"' -f2)   # versao atual (nao fixa no teste)
PORTA=8901; PORTA_GH=8902; PORTA_MORTA=8903
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R="http://$IP:$PORTA"
T=/root/glr-diag; DADOS=$T/dados; A=$T/lista; GH=$T/gh
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$(echo "$2" | head -c 600)] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
codigo() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
estado() { curl -s "$L/api/diagnostico"; }
espera_fim() { for i in $(seq 1 120); do estado | grep -q '"estado":"running"' || return; sleep 0.25; done; }
rm -rf "$T"; mkdir -p "$DADOS" "$A" "$GH/recebido" "$GH/vistos" "$T/jobe"

# chaves de mentira (formato de fine-grained PAT)
KJOBE="github_pat_11JOBE0000000000000000_abcdefghijklmnopqrstuvwxyz0123456789JOBEjobe1234"
KGLR="github_pat_11GLRN0000000000000000_zyxwvutsrqponmlkjihgfedcba9876543210GLRNglrn9876"
HASH_PAR=$(printf 'token-do-celular' | sha256sum | awk '{print $1}')
# 0.9.23: hashes publicos (sha256 de asset, sha de commit) ficam; um hash solto sem nome continua saindo
SHA_PUB=c57d753e436d56b6b576f6f68f55166bd5c2e0856dcffefa7f33d1a4a8bcdbcc
SHA_PUB2=0d25a9c0d25a9c0d25a9c0d25a9c0d25a9c0d25a9c0d25a9c0d25a9c0d25a9c0
COMMIT_PUB=c4e54fe768bcba25a0d6d9e6550c5226b194ba0c
SHA_SOLTO=9f8e7d6c5b4a39281706f5e4d3c2b1a09f8e7d6c5b4a39281706f5e4d3c2b1a0
printf 'language = pt-BR\nfolder = %s/\npairing = on\npaired = %s 1794600000 Celular da Maria\n' "$A" "$HASH_PAR" > "$DADOS/config.ini"
# diario com tudo o que nao pode sair do PS5
cat > "$DADOS/glibren.log" <<EOF
13/11 10:00:00 iniciando (PC)
13/11 10:00:01 teste: chave $KGLR colada sem querer
13/11 10:00:02 teste: Authorization: Bearer abcdef0123456789secretbearer
13/11 10:00:03 teste: Cookie: SID=cookievalor123; HSID=outro
13/11 10:00:04 teste: link https://release-assets.githubusercontent.com/x/y.zip?sig=ASSINATURA123&se=2026 fim
13/11 10:00:05 teste: video https://rr1---sn-abc.googlevideo.com/videoplayback/caminho/secreto?expire=1 fim
13/11 10:00:06 teste: e-mail fulano.de.tal@exemplo.com.br escreveu
13/11 10:00:07 teste: X-GLR-Token: 0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef
13/11 10:00:08 teste: token=tokenzinho_secreto password: senha123x
13/11 10:00:09 teste: hash do pareado $HASH_PAR
13/11 10:00:10 teste: usuario https://user:senhaurl@github.com/caminho/ok fim
13/11 10:00:11 diag: tela cheia 1540x700 (texto comum deve ficar)
13/11 10:00:12 payloads: {"nome":"x","sha256":"$SHA_PUB","commit": "$COMMIT_PUB"}
13/11 10:00:13 cheats:   trecho 1 0x80117000: 000000000000000000000000000000000000 -> C78038010000640000008B8038010000E945C2: lido de volta ok
13/11 10:00:14 cheats:   trecho 1 0x80117000: C78038010000640000008B8038010000E945C2 -> 000000000000000000000000000000000000: lido de volta ok
13/11 10:00:15 teste: seta -> a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4 fim
13/11 10:00:13 atualizacao: conferido sha256 $SHA_PUB2 ok
13/11 10:00:14 teste: solto $SHA_SOLTO fim
13/11 10:00:15 teste: "sha256":"$HASH_PAR" (segredo conhecido com nome publico)
EOF
printf '[fullscreen]\nresult=0\ncontact=dono@ps5.net\n' > "$T/fullscreen.ini"
# 0.9.42: logs do ShadowKraken (sem os do kraken-mount: nao podem aparecer nem contar como faltando)
mkdir -p "$T/montador/shadowmount"
{ echo "INICIO-QUE-SAI"; head -c 700000 /dev/zero | tr '\0' 'x'; echo; echo "[kraken] montado PPSA12771 por dono@ps5.net"; echo "FIM-DO-LOG-SK"; } > "$T/montador/shadowmount/debug.log"
printf 'scan_path=/data/homebrew\n' > "$T/montador/shadowmount/config.ini"

# GitHub falso: guarda cada PUT (caminho, Authorization, corpo) e responde conforme $GH/modo
cat > "$T/gh.py" <<'EOF'
import base64, http.server, json, os, sys, time
pasta = sys.argv[2]
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_PUT(self):
        n = int(self.headers.get("Content-Length") or 0)
        corpo = self.rfile.read(n)
        modo = open(pasta + "/modo").read().strip()
        if modo == "lento": time.sleep(1.5)
        codigo = {"401": 401, "403": 403, "404": 404, "500": 500}.get(modo, 201)
        if modo == "instavel":   # 0.9.23: a 1a tentativa de cada arquivo da 502, a 2a passa
            marca = pasta + "/vistos/" + self.path.replace("/", "_")
            if not os.path.exists(marca):
                open(marca, "w").close(); codigo = 502
        if modo == "info500" and self.path.endswith("/info.json"): codigo = 500   # 0.9.23: so um arquivo nao sobe
        k = len(os.listdir(pasta + "/recebido"))
        d = {"caminho": self.path, "auth": self.headers.get("Authorization"), "accept": self.headers.get("Accept"),
             "versao": self.headers.get("X-GitHub-Api-Version"), "codigo": codigo}
        try:
            j = json.loads(corpo); d["message"] = j.get("message"); d["committer"] = j.get("committer"); d["branch"] = j.get("branch")
            d["conteudo"] = base64.b64decode(j["content"]).decode("utf-8", "replace")
        except Exception as e:
            d["erro"] = str(e)
        json.dump(d, open("%s/recebido/%04d.json" % (pasta, k), "w"))
        self.send_response(codigo); self.send_header("Content-Type", "application/json"); self.end_headers()
        self.wfile.write(b'{"content":{}}')
http.server.ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1])), H).serve_forever()
EOF
echo ok > "$GH/modo"
python3 -I "$T/gh.py" $PORTA_GH "$GH" > "$T/gh.log" 2>&1 &
PID_GH=$!

inicia() {
  GLR_TESTE_GITHUB="http://127.0.0.1:${1:-$PORTA_GH}" GLR_TESTE_JOBE_TOKEN="$T/jobe/token" GLR_TESTE_FULLSCREEN_INI="$T/fullscreen.ini" GLR_TESTE_MONTADOR="$T/montador" \
  GLR_TESTE_DIAG_PASTA=2026-11-13_101500 GLR_TESTE_FW=12.00 GLR_TESTE_CHEATS="$T/cheats" \
    "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
recebidos() { cat "$GH"/recebido/*.json 2>/dev/null; }
limpa_gh() { rm -f "$GH"/recebido/*.json; }
inicia

echo "--- sem chave"
E=$(estado)
confere "GET: sem chave"                    "$E" '"configurada":false,"origem":"","final":"","propria":false,"estado":"idle"'
confere "enviar sem chave = 400"            "$(codigo -H 'X-GLR: 1' -X POST $L/api/diagnostico/enviar)" "400"
confere "enviar sem chave: diag_sem_chave"  "$(post -X POST $L/api/diagnostico/enviar)" '"chave":"diag_sem_chave"'
confere "nada chegou no GitHub"             "$(ls $GH/recebido | wc -l)" "^0$"

echo "--- pareamento"
confere "rede: colar sem token = 401"       "$(codigo -H 'X-GLR: 1' --data-urlencode "chave=$KGLR" $R/api/diagnostico/chave)" "401"
confere "rede: resposta pede pareamento"    "$(post --data-urlencode "chave=$KGLR" $R/api/diagnostico/chave)" "parear_necessario"
confere "rede: remover sem token = 401"     "$(codigo -H 'X-GLR: 1' -X POST $R/api/diagnostico/chave/remover)" "401"
confere "rede: enviar sem token = 401"      "$(codigo -H 'X-GLR: 1' -X POST $R/api/diagnostico/enviar)" "401"
confere "sem X-GLR = 403"                   "$(codigo --data-urlencode "chave=$KGLR" $R/api/diagnostico/chave)" "403"
confere "sem X-GLR local = 403"             "$(codigo --data-urlencode "chave=$KGLR" $L/api/diagnostico/chave)" "403"
confere "chave nao gravada"                 "$(ls $DADOS/diag/token 2>&1)" "No such file"
confere "rede: GET livre"                   "$(codigo $R/api/diagnostico)" "200"

echo "--- chave da Jobe"
printf '%s\n' "$KJOBE" > "$T/jobe/token"; chmod 600 "$T/jobe/token"
E=$(estado)
confere "usa a chave da Jobe"               "$E" '"configurada":true,"origem":"jobe","final":"1234","propria":false'
nao_tem "GET sem a chave da Jobe"           "$E" "github_pat"
confere "enviar com a chave da Jobe"        "$(post -X POST $L/api/diagnostico/enviar)" '"ok":true,"estado":"running"'
espera_fim
E=$(estado)
confere "enviado (done)"                    "$E" '"estado":"done","pasta":"2026-11-13_101500","erro":""'
N=$(ls $GH/recebido | wc -l)
confere "arquivos enviados = total"         "$E" "\"enviados\":$N,\"total\":$N"
REC=$(recebidos)
confere "caminho glibren/<pasta>/glibren.log" "$REC" '"caminho": "/repos/pristmc-code/ps5-diagnosticos/contents/glibren/2026-11-13_101500/glibren.log"'
for f in config.ini info.json termico.json payloads.json cheats.json discos.json web-browser-fullscreen.ini; do
  confere "enviou $f"                       "$REC" "glibren/2026-11-13_101500/$f\""
done
for f in shadowmount-debug.log shadowmount-config.ini; do
  confere "enviou $f"                       "$REC" "glibren/2026-11-13_101500/$f\""
done
nao_tem "sem log do kraken-mount (nao existe)" "$REC" "krakenmount-"
nao_tem "sem notify.txt (nao existe)"       "$REC" "shadowmount-notify.txt"
confere "enviou ampr-teste.json (0.9.51)"   "$REC" 'glibren/2026-11-13_101500/ampr-teste.json"'
nao_tem "sem traces do ampr (nao ha copias)" "$REC" "ampr-trace-"
confere "debug.log do SK: final"            "$REC" "FIM-DO-LOG-SK"
# 0.9.43: bytes de cheat (hexadecimal maiusculo junto da seta) ficam; minusculo depois da seta continua saindo
confere "cheat: bytes ligados ficam"        "$REC" "000000000000000000000000000000000000 -> C78038010000640000008B8038010000E945C2: lido"
confere "cheat: bytes desligados ficam"     "$REC" "C78038010000640000008B8038010000E945C2 -> 000000000000000000000000000000000000: lido"
nao_tem "seta: token minusculo sai"         "$REC" "a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4"
nao_tem "debug.log do SK: so os ultimos 512 KB" "$REC" "INICIO-QUE-SAI"
nao_tem "debug.log do SK: sem e-mail"       "$REC" "dono@ps5.net"
confere "info.json: faltam vazio"           "$REC" '\\"faltam\\":\\"\\"'
confere "Bearer com a chave da Jobe"        "$REC" "\"auth\": \"Bearer $KJOBE\""
confere "Accept da API"                     "$REC" '"accept": "application/vnd.github+json", "versao": "2022-11-28"'
confere "committer PristMC noreply"         "$REC" '"committer": {"name": "PristMC", "email": "285300718+pristmc-code@users.noreply.github.com"}'
confere "mensagem do commit"                "$REC" "\"message\": \"diagnostico glibren 2026-11-13_101500 $VERSAO\""
confere "base64 decodificado (diario)"      "$REC" "tela cheia 1540x700 (texto comum deve ficar)"
confere "info.json: versao e firmware"      "$REC" '\\"glibren\\":\\"'"$VERSAO"'\\",\\"firmware\\":\\"12.00\\"'
confere "info.json: chave da jobe"          "$REC" '\\"chave_de\\":\\"jobe\\"'
confere "diario: enviado"                   "$(cat $DADOS/glibren.log)" "diagnostico: enviado ($N arquivo(s), pasta glibren/2026-11-13_101500, chave do jobe)"

echo "--- higienizacao (o que chegou ao GitHub, sem os cabecalhos)"
CONT=$(for f in "$GH"/recebido/*.json; do python3 -c 'import json,sys; print(json.load(open(sys.argv[1])).get("conteudo",""))' "$f"; done)
nao_tem "sem chave github_pat"              "$CONT" "github_pat"
nao_tem "sem a chave da Jobe"               "$CONT" "$KJOBE"
nao_tem "sem a chave colada no diario"      "$CONT" "$KGLR"
nao_tem "sem Bearer"                        "$CONT" "secretbearer"
nao_tem "sem cookie"                        "$CONT" "cookievalor123"
nao_tem "sem a 2a parte do cookie"          "$CONT" "HSID=outro"
nao_tem "sem query string assinada"         "$CONT" "ASSINATURA123"
confere "link fica sem a consulta"          "$CONT" "https://release-assets.githubusercontent.com/x/y.zip?\[...\] fim"
nao_tem "googlevideo sem o caminho"         "$CONT" "caminho/secreto"
nao_tem "sem e-mail (diario)"               "$CONT" "fulano.de.tal@exemplo.com.br"
nao_tem "sem e-mail (fullscreen.ini)"       "$CONT" "dono@ps5.net"
confere "e-mail vira [email]"               "$CONT" "e-mail \[email\] escreveu"
nao_tem "sem X-GLR-Token"                   "$CONT" "0123456789abcdef0123456789abcdef"
nao_tem "sem token="                        "$CONT" "tokenzinho_secreto"
nao_tem "sem senha"                         "$CONT" "senha123x"
nao_tem "sem hash do pareado"               "$CONT" "$HASH_PAR"
nao_tem "sem nome do aparelho pareado"      "$CONT" "Celular da Maria"
confere "config.ini: paired escondido"      "$CONT" "paired = \[aparelho pareado\]"
confere "config.ini: idioma fica"           "$CONT" "language = pt-BR"
nao_tem "sem usuario:senha na URL"          "$CONT" "senhaurl"
confere "marcador [segredo]"                "$CONT" "\[segredo\]"
confere "sha256 publico fica (json)"        "$CONT" "\"sha256\":\"$SHA_PUB\""
confere "commit publico fica"               "$CONT" "\"commit\": \"$COMMIT_PUB\""
confere "sha256 publico fica (log)"         "$CONT" "conferido sha256 $SHA_PUB2 ok"
nao_tem "hash solto sem nome sai"           "$CONT" "$SHA_SOLTO"
confere "hash solto vira [segredo]"         "$CONT" "solto \[segredo\] fim"
confere "segredo conhecido sai com nome publico" "$CONT" '"sha256":"\[segredo\]" (segredo'
confere "estado: faltaram vazio"            "$(estado)" '"faltaram":""'

echo "--- colar a propria chave"
confere "chave invalida = 400"              "$(codigo -H 'X-GLR: 1' --data-urlencode 'chave=nao e chave' $L/api/diagnostico/chave)" "400"
confere "chave curta: diag_chave_invalida"  "$(post -d chave=abc $L/api/diagnostico/chave)" "diag_chave_invalida"
E=$(post --data-urlencode "chave=  $KGLR
" $L/api/diagnostico/chave)
confere "colar (local, com espacos)"        "$E" '"configurada":true,"origem":"glibren","final":"9876","propria":true'
nao_tem "resposta sem a chave"              "$E" "github_pat"
confere "arquivo 0600"                      "$(stat -c %a $DADOS/diag/token)" "^600$"
confere "pasta 0700"                        "$(stat -c %a $DADOS/diag)" "^700$"
confere "arquivo so com a chave"            "$(cat $DADOS/diag/token)" "^$KGLR$"
confere "a propria vence a da Jobe"         "$(estado)" '"origem":"glibren","final":"9876"'

echo "--- pareado pela rede"
post -X POST $R/api/parear/pedir > /dev/null
C=$(grep -o 'pareamento [0-9]\{6\}' "$T/glr.log" | tail -1 | awk '{print $2}')
TOKEN=$(post -d codigo=$C -d nome=Teste $R/api/parear | python3 -c 'import json,sys; print(json.load(sys.stdin)["token"])')
confere "token do pareamento"               "$TOKEN" "^[0-9a-f]\{64\}$"
confere "rede com token: remover = 200"     "$(post -H "X-GLR-Token: $TOKEN" -X POST $R/api/diagnostico/chave/remover)" '"configurada":true,"origem":"jobe","final":"1234","propria":false'
confere "remover nao apaga a da Jobe"       "$(cat $T/jobe/token)" "$KJOBE"
confere "rede com token: colar = 200"       "$(post -H "X-GLR-Token: $TOKEN" --data-urlencode "chave=$KGLR" $R/api/diagnostico/chave)" '"origem":"glibren"'

echo "--- erros do GitHub"
for m in "401 unauthorized" "403 forbidden" "404 no-repo" "500 http"; do
  set -- $m; echo "$1" > "$GH/modo"; limpa_gh
  post -H "X-GLR-Token: $TOKEN" -X POST $R/api/diagnostico/enviar > /dev/null; espera_fim
  confere "GitHub $1 -> $2"                 "$(estado)" "\"estado\":\"failed\",\"pasta\":\"2026-11-13_101500-[0-9]*\",\"erro\":\"$2\",\"http\":$1,\"enviados\":0"
  if [ "$1" = 500 ]; then
    confere "500: 3 tentativas x 2 arquivos e para" "$(ls $GH/recebido | wc -l)" "^6$"
    confere "500: lista o que faltou"       "$(estado)" '"faltaram":"glibren.log,'
  else
    confere "para no 1o arquivo ($1)"       "$(ls $GH/recebido | wc -l)" "^1$"
  fi
done
confere "pasta repetida ganha sufixo"       "$(estado)" '"pasta":"2026-11-13_101500-5"'
confere "diario: falhou"                    "$(cat $DADOS/glibren.log)" "diagnostico: falhou (unauthorized, HTTP 401)"

echo "--- novas tentativas (0.9.23)"
echo instavel > "$GH/modo"; limpa_gh; rm -f "$GH"/vistos/*
post -X POST $L/api/diagnostico/enviar > /dev/null; espera_fim
E=$(estado)
confere "instavel: 2a tentativa sobe tudo"  "$E" '"estado":"done"'
confere "instavel: nada faltou"             "$E" '"faltaram":""'
NI=$(ls $GH/vistos | wc -l)
confere "instavel: 2 PUTs por arquivo"      "$(ls $GH/recebido | wc -l)" "^$((NI*2))$"
confere "diario: novas tentativas"          "$(cat $DADOS/glibren.log)" "diagnostico: $NI nova(s) tentativa(s) de envio"
echo info500 > "$GH/modo"; limpa_gh
post -X POST $L/api/diagnostico/enviar > /dev/null; espera_fim
E=$(estado)
confere "um arquivo falha: segue com o resto" "$E" "\"estado\":\"failed\",\"pasta\":\"[^\"]*\",\"erro\":\"http\",\"http\":500,\"enviados\":$((NI-1)),\"total\":$NI"
confere "um arquivo falha: faltaram info.json" "$E" '"faltaram":"info.json"'
confere "diario: faltaram"                  "$(cat $DADOS/glibren.log)" "faltaram: info.json"
echo ok > "$GH/modo"

echo "--- traces do ampr-emu-ng (0.9.51)"
mkdir -p "$DADOS/ampr-traces"
printf 'ampr-emu-ng 0.5.0 debug PPSA29629 trace curto\n' > "$DADOS/ampr-traces/2026-11-20_220000-PPSA29629.txt"
{ echo "INICIO-TRACE-QUE-SAI"; head -c 700000 /dev/zero | tr '\0' 'x'; echo; echo "FIM-DO-TRACE"; } > "$DADOS/ampr-traces/2026-11-20_221000-PPSA29629.txt"
limpa_gh
post -X POST $L/api/diagnostico/enviar > /dev/null; espera_fim
confere "com traces: enviado"               "$(estado)" '"estado":"done"'
REC=$(recebidos)
confere "enviou o trace curto"              "$REC" 'ampr-trace-2026-11-20_220000-PPSA29629.txt"'
confere "enviou o trace grande"             "$REC" 'ampr-trace-2026-11-20_221000-PPSA29629.txt"'
confere "trace grande: final"               "$REC" "FIM-DO-TRACE"
nao_tem "trace grande: so os ultimos 512 KB" "$REC" "INICIO-TRACE-QUE-SAI"
confere "info.json: trace grande cortado"   "$REC" '\\"nome\\":\\"ampr-trace-2026-11-20_221000-PPSA29629.txt\\",\\"bytes\\":[0-9]*,\\"cortado\\":true'
confere "ampr-teste.json: 2 traces"         "$REC" '\\"traces\\":2'
rm -rf "$DADOS/ampr-traces"

echo "--- uma rodada por vez"
echo lento > "$GH/modo"; limpa_gh
post -X POST $L/api/diagnostico/enviar > /dev/null
confere "2a rodada = 409"                   "$(codigo -H 'X-GLR: 1' -X POST $L/api/diagnostico/enviar)" "409"
confere "2a rodada: diag_ocupado"           "$(post -X POST $L/api/diagnostico/enviar)" "diag_ocupado"
confere "estado: running"                   "$(estado)" '"estado":"running"'
para; echo ok > "$GH/modo"

echo "--- sem internet"
inicia $PORTA_MORTA
post -X POST $L/api/diagnostico/enviar > /dev/null; espera_fim
confere "sem servidor -> network"           "$(estado)" '"estado":"failed","pasta":"2026-11-13_101500","erro":"network","http":0'
confere "sem servidor: todos faltaram"      "$(estado)" '"enviados":0,.*"faltaram":"glibren.log,config.ini'

echo "--- zip"
curl -s -o "$T/d.zip" -w '%{http_code} %{content_type}' $L/api/diagnostico/zip > "$T/zip.cab"
confere "zip: 200 application/zip"          "$(cat $T/zip.cab)" "200 application/zip"
ZL=$(python3 -I -c 'import sys,zipfile; z=zipfile.ZipFile(sys.argv[1]); assert z.testzip() is None; print("\n".join(z.namelist()))' "$T/d.zip" 2>&1)
confere "zip valido com o diario"           "$ZL" "^2026-11-13_101500/glibren.log$"
confere "zip com info.json"                 "$ZL" "^2026-11-13_101500/info.json$"
confere "zip com config.ini"                "$ZL" "^2026-11-13_101500/config.ini$"
ZC=$(python3 -I -c 'import sys,zipfile; z=zipfile.ZipFile(sys.argv[1]); print("".join(z.read(n).decode("utf-8","replace") for n in z.namelist()))' "$T/d.zip")
nao_tem "zip sem chave"                     "$ZC" "github_pat"
nao_tem "zip sem e-mail"                    "$ZC" "fulano.de.tal"
nao_tem "zip sem hash do pareado"           "$ZC" "$HASH_PAR"
confere "zip: info.json pedido zip"         "$ZC" '"pedido":"zip"'

echo "--- a chave nunca aparece"
TODOS="$(curl -s $L/api/diagnostico)$(curl -s $L/api/estado)$(curl -s $R/api/diagnostico)"
nao_tem "GET sem a chave do glibren"        "$TODOS" "$KGLR"
nao_tem "GET sem a chave da Jobe"           "$TODOS" "$KJOBE"
DIARIO_NOVO=$(tail -n +17 "$DADOS/glibren.log")
nao_tem "diario sem a chave do glibren"     "$DIARIO_NOVO" "$KGLR"
nao_tem "diario sem a chave da Jobe"        "$DIARIO_NOVO" "$KJOBE"
nao_tem "saida do programa sem a chave"     "$(cat $T/glr.log)" "github_pat"
nao_tem "nenhum temporario com a chave"     "$(grep -rl github_pat /tmp/glr-gh-* 2>/dev/null)" "glr"
confere "pagina /diagnostico"               "$(curl -s $L/diagnostico | head -c 3000)" "<title>Diagnóstico</title>"
para

kill $PID_GH 2>/dev/null; wait $PID_GH 2>/dev/null
rm -rf "$T"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
