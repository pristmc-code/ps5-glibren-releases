# 0.9.41: elfldr falso para o "carregar ao iniciar" (testes/teste_autoload.sh): le o .elf ate o fim e fecha (payload que
# fica rodando nao escreve nada). Conexao vazia (sem bytes) nao conta. Cada envio vira <pasta>/recebido-N.elf e uma linha
# "N tamanho sha256 [kstuff]" em <pasta>/recebidos. kstuff falso (bytes com "KSTUFF-FALSO") com <pasta>/ks_vira presente:
# grava "ativo" em <pasta>/kstuff_estado (o kstuff "subiu"; a sonda do glibren no PC le esse arquivo).
#   python3 -I elfldr_falso.py <porta> <pasta>
import hashlib, os, socket, sys

porta, pasta = int(sys.argv[1]), sys.argv[2]
s = socket.socket()
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("127.0.0.1", porta))
s.listen(8)
open(pasta + "/elfldr.pronto", "w").close()
try:  # religado no meio do teste: continua a numeracao
    n = len(open(pasta + "/recebidos").readlines())
except OSError:
    n = 0
while True:
    c, _ = s.accept()
    dados = b""
    while True:
        d = c.recv(65536)
        if not d:
            break
        dados += d
    c.close()
    if not dados:
        continue
    n += 1
    open("%s/recebido-%d.elf" % (pasta, n), "wb").write(dados)
    ks = b"KSTUFF-FALSO" in dados
    with open(pasta + "/recebidos", "a") as f:
        f.write("%d %d %s%s\n" % (n, len(dados), hashlib.sha256(dados).hexdigest(), " kstuff" if ks else ""))
    if ks and os.path.exists(pasta + "/ks_vira"):
        open(pasta + "/kstuff_estado", "w").write("ativo\n")
