#!/bin/bash
# 0.9.41: teste ponta a ponta do fluxo do usuario, na versao de PC, com os falsos de sempre (elfldr, Dump Forge,
# ShadowMount+/ShadowKraken pelo github_falso.py smp) e a sonda do kstuff lida de um arquivo (o elfldr falso grava "ativo"
# quando recebe o kstuff falso):
#   pasta do ps5-payload-manager (/data/pldmgr/payloads simulada) com Kstuff-NG_v1.00.elf e
#   shadowkraken-1.00-Dev.7-pristmc.elf (ELF de teste com o marcador real "1.00-Dev.7-pristmc") -> Instalar de arquivo
#   nos dois (pela lista, como a pagina) -> chaves "Carregar ao iniciar" no kstuff, ShadowKraken e Dump Forge ->
#   reiniciar o glibren -> ordem kstuff -> ShadowKraken -> Dump Forge, nenhum duplicado -> reiniciar de novo no mesmo boot
#   (os tres rodando) -> nada reenviado -> Ativar do kstuff recusado -> "Atualizar a partir deste arquivo" com o Dev.8 ->
#   "Voltar" (Dev.7 de novo) -> instalar 2 .pkg em fila -> cancelar um (o outro segue).
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_ponta_a_ponta_0941.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8641; PEL=8642; PDF=8643; PSMP=8644
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R="http://$IP:$PORTA"
T=/root/glr-ponta0941; DADOS=$T/dados; PAY=$DADOS/payloads; GH=$T/gh; A=$T/lista; PM=$T/pldmgr/payloads
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$(echo "$2" | head -c 700)] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
estado() { curl -s "$L/api/payloads"; }
campo() { estado | python3 -c "import json,sys; d=json.load(sys.stdin); i=[x for x in d['itens'] if x['id']=='$1'][0]; v=eval('i'+sys.argv[1]); print(json.dumps(v) if not isinstance(v,str) else v)" "$2"; }
recebidos() { [ -f $T/el/recebidos ] && wc -l < $T/el/recebidos || echo 0; }
espera_res() { local v=""; for _ in $(seq 1 ${2:-200}); do v=$(campo "$1" "['autoload_res']" 2>/dev/null); case "$v" in carregado|ja_rodando|erro|boot) break;; esac; sleep 0.2; done; echo "$v"; }
espera_livre() { for _ in $(seq 1 150); do estado | grep -q '"ocupado":false' && return; sleep 0.1; done; }
espera_http() { for _ in $(seq 1 150); do curl -s -o /dev/null -m 2 "$1" && return 0; sleep 0.1; done; echo "AVISO: $1 nao respondeu"; }
liga_el() { mkdir -p $T/el; rm -f $T/el/elfldr.pronto; (exec python3 -I "$ORIGEM/testes/elfldr_falso.py" $PEL $T/el) >> $T/el.log 2>&1 & PID_EL=$!; for _ in $(seq 1 50); do [ -e $T/el/elfldr.pronto ] && break; sleep 0.1; done; }
liga_df() { mkdir -p $T/df; (exec python3 -I "$ORIGEM/testes/dumpforge_falso.py" $PDF $T/df) >> $T/df.log 2>&1 & PID_DF=$!; espera_http "http://127.0.0.1:$PDF/api/session"; }
liga_smp() { (exec python3 -I "$ORIGEM/testes/github_falso.py" smp $PSMP $GH) > $T/smp.log 2>&1 & PID_SMP=$!; espera_http "http://127.0.0.1:$PSMP/"; }
# o mesmo "boot" do PS5 em todas as partidas (boottime, id do kernel); o tempo ligado so cresce
inicia() {
  GLR_TESTE_ELFLDR=$PEL GLR_TESTE_SONDA_S=0 GLR_TESTE_DUMPFORGE_PORTA=$PDF GLR_TESTE_SMP_PORTA=$PSMP GLR_TESTE_KRAKEN_PORTA=8649 \
  GLR_TESTE_BLUEV_PORTA=8648 GLR_TESTE_ZHITHEMES_PORTA=8647 GLR_TESTE_MEMDBG_PORTA=8646 GLR_TESTE_MEMDBG_CACHE_S=0 GLR_TESTE_GH=http://127.0.0.1:8645 \
  GLR_TESTE_KSTUFF=$T/el/kstuff_estado GLR_TESTE_BOOT=1810000000 GLR_TESTE_UPTIME=$1 GLR_TESTE_BOOT_ID=5ca1ab1e \
  GLR_TESTE_AUTOLOAD_ESPERA_S=20 GLR_TESTE_KSTUFF_ESPERA_S=5 GLR_TESTE_CONV_VIGIA_S=0 GLR_TESTE_PLDMGR=$T/pldmgr GLR_TESTE_ARQ_RAIZES=$T/usb0 \
  GLR_TESTE_FW=12.00 "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; espera_http "$L/nada"; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
parear() {
  local n0=$(grep -c 'pareamento [0-9]\{6\}' "$T/glr.log") C=""
  post -X POST $R/api/parear/pedir > /dev/null
  for _ in $(seq 1 100); do [ "$(grep -c 'pareamento [0-9]\{6\}' "$T/glr.log")" -gt "$n0" ] && break; sleep 0.1; done
  C=$(grep -o 'pareamento [0-9]\{6\}' "$T/glr.log" | tail -1 | awk '{print $2}')
  TOKEN=$(post -d codigo=$C -d nome=teste $R/api/parear | grep -o '"token":"[0-9a-f]*"' | cut -d'"' -f4)
}
P() { post -H "X-GLR-Token: $TOKEN" "$@"; }
elf() { python3 - "$@" <<'EOF'
import sys
caminho, texto, tam = sys.argv[1], sys.argv[2].encode(), int(sys.argv[3])
d = b"\x7fELF" + b"\0" * 60 + texto + b"\0"
d += bytes((i * 13) % 251 for i in range(max(0, tam - len(d))))
open(caminho, "wb").write(d)
EOF
}
pkg() { python3 - "$1" "$2" "$3" <<'EOF'
import sys
caminho, magia, tam = sys.argv[1], sys.argv[2].encode(), int(sys.argv[3])
open(caminho, "wb").write(bytearray(b"\x7f" + magia + b"\0" * (tam - 1 - len(magia))))
EOF
}
sha() { sha256sum "$1" | cut -d' ' -f1; }
# o caminho de um arquivo da lista "Instalar de arquivo" (o que a pagina mostra) pelo fim do nome
da_lista() { curl -s "$L/api/payloads/arquivos?id=$1" | python3 -c "import json,sys; print([a['caminho'] for a in json.load(sys.stdin)['arquivos'] if a['caminho'].endswith('$2')][0])"; }
de_quem() { local s=$(echo "$1" | awk '{print $3}'); case "$s" in "$SHA_KS") echo kstuff;; "$SHA_SK7") echo shadowkraken;; "$SHA_DF") echo dump-forge;; *) echo "?";; esac; }

rm -rf "$T"; mkdir -p "$DADOS" "$PAY" "$GH" "$A" "$PM" "$T/usb0" "$T/el" "$T/df"
printf 'language = pt-BR\nfolder = %s/\n' "$A" > "$DADOS/config.ini"
elf "$PM/Kstuff-NG_v1.00.elf" "KSTUFF-FALSO Kstuff-NG v1.00 (kernel)" 6000
elf "$PM/shadowkraken-1.00-Dev.7-pristmc.elf" "ShadowMount+ fork 1.00-Dev.7-pristmc" 7000
printf 'Kstuff-NG_v1.00.elf\nshadowkraken-1.00-Dev.7-pristmc.elf\n' > "$T/pldmgr/autoload.txt"
# Dump Forge instalado pelo GitHub (o .elf + o .info com o SHA-256)
elf "$PAY/dump-forge.elf" "DUMP-FORGE-FALSO v0.5.7" 9000
printf 'versao=v0.5.7\nsha256=%s\ntamanho=%s\nasset=dump-forge.elf\n' "$(sha $PAY/dump-forge.elf)" "$(stat -c %s $PAY/dump-forge.elf)" > "$PAY/dump-forge.info"
SHA_KS=$(sha "$PM/Kstuff-NG_v1.00.elf"); SHA_SK7=$(sha "$PM/shadowkraken-1.00-Dev.7-pristmc.elf"); SHA_DF=$(sha "$PAY/dump-forge.elf")
SHA_ORIGENS=$(sha256sum "$PM"/* "$T/pldmgr/autoload.txt")
echo nao > $T/el/kstuff_estado; touch $T/el/ks_vira
liga_el
inicia 300; parear

echo "--- 1. Instalar de arquivo (kstuff e ShadowKraken da pasta do payload manager)"
C_KS=$(da_lista kstuff Kstuff-NG_v1.00.elf); C_SK=$(da_lista shadowkraken shadowkraken-1.00-Dev.7-pristmc.elf)
confere "lista: kstuff do payload manager" "$C_KS" "^$PM/Kstuff-NG_v1.00.elf$"
confere "lista: ShadowKraken Dev.7"        "$(curl -s "$L/api/payloads/arquivos?id=shadowkraken")" 'Dev.7-pristmc.elf","tamanho":7000,"fonte":"pldmgr","sugerido":true,"versao":"1.00-Dev.7-pristmc","sha256":"'$SHA_SK7'","estado":"nao_instalado"'
confere "instalar kstuff"                  "$(P -d id=kstuff -d caminho=$C_KS $R/api/payloads/arquivo)" '"ok":true,"versao":"1.00","nome":"Kstuff-NG_v1.00.elf","fonte":"pldmgr"'
confere "instalar ShadowKraken"            "$(P -d id=shadowkraken -d caminho=$C_SK $R/api/payloads/arquivo)" '"ok":true,"versao":"1.00-Dev.7-pristmc"'
confere "kstuff: nome fixo, mesmo SHA"     "$(sha $PAY/kstuff-PristMC.elf)" "^$SHA_KS$"
confere "SK: nome fixo, mesmo SHA"         "$(sha $PAY/shadowkraken-PristMC.elf)" "^$SHA_SK7$"
confere "pagina: SHA-256 completo do kstuff" "$(campo kstuff "['arquivo_seu']['sha256']")" "^$SHA_KS$"
confere "pagina: kstuff nao carregado"     "$(campo kstuff "['carregado']")" "^nao$"

echo "--- 2. chaves Carregar ao iniciar"
for id in kstuff shadowkraken dump-forge; do confere "chave $id" "$(P -d id=$id -d ligado=1 $R/api/payloads/autoload)" '"ok":true,"autoload":true'; done
confere "config.ini com os tres"           "$(grep payload_autoload $DADOS/config.ini)" "kstuff"
for id in kstuff shadowkraken dump-forge; do confere "pagina: chave $id ligada" "$(campo $id "['autoload']")" "^true$"; done
para

echo "--- 3. reiniciar o glibren: kstuff -> ShadowKraken -> Dump Forge"
inicia 400
confere "kstuff carregado"                 "$(espera_res kstuff)" "^carregado$"
confere "ShadowKraken carregado"           "$(espera_res shadowkraken)" "^carregado$"
confere "Dump Forge carregado"             "$(espera_res dump-forge)" "^carregado$"
confere "3 envios ao elfldr"               "$(recebidos)" "^3$"
confere "1o kstuff"                        "$(de_quem "$(sed -n 1p $T/el/recebidos)")" "^kstuff$"
confere "2o ShadowKraken"                  "$(de_quem "$(sed -n 2p $T/el/recebidos)")" "^shadowkraken$"
confere "3o Dump Forge"                    "$(de_quem "$(sed -n 3p $T/el/recebidos)")" "^dump-forge$"
confere "nenhum duplicado"                 "$(awk '{print $3}' $T/el/recebidos | sort | uniq -d | wc -l)" "^0$"
confere "marcador do boot (id do kernel)"  "$(cat $PAY/kstuff.boot)" "^v2 5ca1ab1e 1810000000 400$"
confere "kstuff ativo agora"               "$(campo kstuff "['carregado']")" "^sim$"
para
# o ShadowKraken e o Dump Forge "subiram" (os falsos respondem como eles)
echo "1.00-Dev.7-pristmc" > $GH/smp_versao; liga_smp; liga_df

echo "--- 4. reiniciar de novo no mesmo boot: nada reenviado"
inicia 520; parear
confere "kstuff: ja mandado neste boot"    "$(espera_res kstuff)" "^boot$"
confere "ShadowKraken: ja rodando"         "$(espera_res shadowkraken)" "^ja_rodando$"
confere "Dump Forge: ja rodando"           "$(espera_res dump-forge)" "^ja_rodando$"
confere "elfldr: nada novo"                "$(recebidos)" "^3$"
confere "SK rodando a versao instalada"    "$(campo shadowkraken "['rodando_versao']")" "^1.00-Dev.7-pristmc$"
confere "Ativar do kstuff: recusado (carregado)" "$(P -d id=kstuff -d confirmo_kstuff=1 $R/api/payloads/ativar)" '"chave":"payload_ja_ativo"'
confere "elfldr: ainda nada novo"          "$(recebidos)" "^3$"

echo "--- 5. Atualizar a partir deste arquivo (Dev.8) e Voltar"
elf "$T/usb0/shadowkraken-1.00-Dev.8-pristmc.elf" "ShadowMount+ fork 1.00-Dev.8-pristmc" 7100
SHA_SK8=$(sha "$T/usb0/shadowkraken-1.00-Dev.8-pristmc.elf")
confere "lista: Dev.8 mais nova"           "$(curl -s "$L/api/payloads/arquivos?id=shadowkraken")" 'Dev.8-pristmc.elf",[^}]*"versao":"1.00-Dev.8-pristmc","sha256":"'$SHA_SK8'","estado":"mais_nova"'
confere "lista: Dev.7 ja instalado"        "$(curl -s "$L/api/payloads/arquivos?id=shadowkraken")" 'Dev.7-pristmc.elf",[^}]*"estado":"igual"'
C8=$(da_lista shadowkraken shadowkraken-1.00-Dev.8-pristmc.elf)
confere "Atualizar a partir deste arquivo" "$(P -d id=shadowkraken -d caminho=$C8 $R/api/payloads/arquivo)" '"ok":true,"versao":"1.00-Dev.8-pristmc"'
confere "instalada Dev.8"                  "$(campo shadowkraken "['gh']['instalada']['versao']")" "^1.00-Dev.8-pristmc$"
confere "anterior Dev.7"                   "$(campo shadowkraken "['gh']['anterior']['versao']")" "^1.00-Dev.7-pristmc$"
confere "rodando Dev.7 != instalada"       "$(campo shadowkraken "['versao_diferente']")" "^true$"
confere "Voltar"                           "$(P -d id=shadowkraken $R/api/payloads/voltar)" '"ok":true'
espera_livre
confere "Voltar: Dev.7 instalada"          "$(campo shadowkraken "['gh']['instalada']['versao']")" "^1.00-Dev.7-pristmc$"
confere "Voltar: o arquivo do Dev.7"       "$(sha $PAY/shadowkraken-PristMC.elf)" "^$SHA_SK7$"
confere "Voltar: anterior Dev.8"           "$(campo shadowkraken "['gh']['anterior']['versao']")" "^1.00-Dev.8-pristmc$"
confere "origens intactas"                 "$(sha256sum "$PM"/* "$T/pldmgr/autoload.txt")" "^$(echo "$SHA_ORIGENS" | head -1)"
confere "autoload.txt do payload manager intacto" "$(sha256sum "$PM"/* "$T/pldmgr/autoload.txt" | tail -1)" "^$(echo "$SHA_ORIGENS" | tail -1)$"
confere "elfldr: nada enviado na troca"    "$(recebidos)" "^3$"

echo "--- 6. instalar 2 .pkg em fila e cancelar um"
pkg "$A/Jogo-PPSA01234.pkg" FIH 8192; pkg "$A/Jogo-CUSA00001.pkg" CNT 4096
echo lento > $T/df/modo_inst; rm -f $T/df/sobreposto
J() { curl -s "$L/api/conversao"; }
item() { J | python3 -c "import json,sys; print(json.dumps([i for i in json.load(sys.stdin)['itens'] if i['instalar'] and i['origem'].endswith('/$1')][0]))"; }
confere "2 na fila"                        "$(P -d "pasta=$A/" -d de=Jogo-PPSA01234.pkg -d "pasta=$A/" -d de=Jogo-CUSA00001.pkg $R/api/conversao/instalar)" '"criadas":2'
confere "1o no Dump Forge"                 "$(item Jogo-PPSA01234.pkg)" '"estado": "\(fila\|rodando\)"'
confere "2o espera a vez"                  "$(item Jogo-CUSA00001.pkg)" '"estado": "espera"'
ID1=$(item Jogo-PPSA01234.pkg | python3 -c "import json,sys; print(json.load(sys.stdin)['id'])")
confere "cancelar o 1o"                    "$(P -d id=$ID1 $R/api/conversao/cancelar)" '"ok":true'
for _ in $(seq 1 30); do item Jogo-PPSA01234.pkg | grep -q '"estado": "cancelado"' && break; sleep 0.1; done
confere "1o cancelado"                     "$(item Jogo-PPSA01234.pkg)" '"estado": "cancelado"'
for _ in $(seq 1 30); do item Jogo-CUSA00001.pkg | grep -q '"estado": "\(fila\|rodando\)"' && break; sleep 0.1; done
confere "2o seguiu para o Dump Forge"      "$(item Jogo-CUSA00001.pkg)" '"estado": "\(fila\|rodando\)"'
confere "nunca dois ao mesmo tempo"        "$(cat $T/df/sobreposto 2>/dev/null || echo nenhum)" "^nenhum$"
confere "os .pkg continuam la"             "$(ls $A | tr '\n' ' ')" "Jogo-CUSA00001.pkg Jogo-PPSA01234.pkg"
para; kill $PID_EL $PID_DF $PID_SMP 2>/dev/null; wait $PID_EL $PID_DF $PID_SMP 2>/dev/null
echo "=== $ok ok, $falhas falhas"
[ $falhas -eq 0 ]
