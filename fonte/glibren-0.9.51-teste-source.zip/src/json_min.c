/* Game Library Renamer (payload PS5) - 0.9.36: leitor JSON minimo. Ver json_min.h. */
#include "json_min.h"

#include <stdlib.h>
#include <string.h>


void js_esp(js_t *j) {
  while(j->p < j->fim && (*j->p == ' ' || *j->p == '\n' || *j->p == '\r' || *j->p == '\t')) j->p++;
}

static int hex4(js_t *j, unsigned *v) {
  if(j->fim - j->p < 4) return -1;
  *v = 0;
  for(int k = 0; k < 4; k++) {
    char h = *j->p++;
    int d = h >= '0' && h <= '9' ? h - '0' : h >= 'a' && h <= 'f' ? h - 'a' + 10 : h >= 'A' && h <= 'F' ? h - 'A' + 10 : -1;
    if(d < 0) return -1;
    *v = *v * 16 + (unsigned)d;
  }
  return 0;
}

/* poe o ponto de codigo em UTF-8 (cabe inteiro ou nao entra) */
static void por_utf8(char *saida, size_t tam, size_t *n, int *cheio, unsigned v) {
  char u[4];
  size_t k;
  if(v < 0x80) u[0] = (char)v, k = 1;
  else if(v < 0x800) u[0] = (char)(0xC0 | v >> 6), u[1] = (char)(0x80 | (v & 0x3F)), k = 2;
  else if(v < 0x10000) u[0] = (char)(0xE0 | v >> 12), u[1] = (char)(0x80 | ((v >> 6) & 0x3F)), u[2] = (char)(0x80 | (v & 0x3F)), k = 3;
  else u[0] = (char)(0xF0 | v >> 18), u[1] = (char)(0x80 | ((v >> 12) & 0x3F)), u[2] = (char)(0x80 | ((v >> 6) & 0x3F)), u[3] = (char)(0x80 | (v & 0x3F)), k = 4;
  if(*n + k >= tam) {
    *cheio = 1;
    return;
  }
  memcpy(saida + *n, u, k);
  *n += k;
}

int js_string(js_t *j, char *saida, size_t tam) {
  js_esp(j);
  if(j->p >= j->fim || *j->p != '"') return -1;
  j->p++;
  size_t n = 0;
  int cheio = !saida || !tam;
  while(j->p < j->fim && *j->p != '"') {
    char c = *j->p++;
    if(c == '\\') {
      if(j->p >= j->fim) return -1;
      char e = *j->p++;
      if(e == 'u') {
        unsigned v, b;
        if(hex4(j, &v)) return -1;
        if(v >= 0xD800 && v < 0xDC00 && j->fim - j->p >= 6 && j->p[0] == '\\' && j->p[1] == 'u') {
          js_t t = {j->p + 2, j->fim};
          if(!hex4(&t, &b) && b >= 0xDC00 && b < 0xE000) {
            v = 0x10000 + ((v - 0xD800) << 10) + (b - 0xDC00);
            j->p = t.p;
          }
        }
        if(v >= 0xD800 && v < 0xE000) v = '?';   /* substituto sozinho */
        if(!cheio) por_utf8(saida, tam, &n, &cheio, v);
        continue;
      }
      c = e == 'n' ? '\n' : e == 't' ? '\t' : e == 'r' ? '\r' : e == 'b' || e == 'f' ? ' ' : e;
    }
    if(cheio) continue;
    if(n + 1 < tam) saida[n++] = c;
    else cheio = 1;
  }
  if(j->p >= j->fim) return -1;
  j->p++;
  if(saida && tam) {
    if(cheio && n) {   /* cortou: nao deixa um caractere UTF-8 (copiado byte a byte) pela metade */
      size_t l = n;
      while(l && ((unsigned char)saida[l - 1] & 0xC0) == 0x80) l--;
      if(l) {
        unsigned char lider = (unsigned char)saida[l - 1];
        size_t quer = lider >= 0xF0 ? 4 : lider >= 0xE0 ? 3 : lider >= 0xC0 ? 2 : 1;
        if(n - (l - 1) < quer) n = l - 1;
      }
    }
    saida[n] = 0;
  }
  return 0;
}

int js_pular(js_t *j, int nivel) {
  js_esp(j);
  if(j->p >= j->fim || nivel > 32) return -1;
  char c = *j->p;
  if(c == '"') return js_string(j, NULL, 0);
  if(c == '{' || c == '[') {
    char fecha = c == '{' ? '}' : ']';
    j->p++;
    js_esp(j);
    if(j->p < j->fim && *j->p == fecha) {
      j->p++;
      return 0;
    }
    for(;;) {
      if(c == '{') {
        if(js_string(j, NULL, 0)) return -1;
        js_esp(j);
        if(j->p >= j->fim || *j->p != ':') return -1;
        j->p++;
      }
      if(js_pular(j, nivel + 1)) return -1;
      js_esp(j);
      if(j->p >= j->fim) return -1;
      if(*j->p == ',') {
        j->p++;
        continue;
      }
      if(*j->p == fecha) {
        j->p++;
        return 0;
      }
      return -1;
    }
  }
  while(j->p < j->fim && !strchr(",}] \n\r\t", *j->p)) j->p++;   /* numero, true, false, null */
  return 0;
}

/* Procura a chave no objeto que comeca em o->p ('{'). Achou: v aponta para o valor e devolve 1. */
int js_campo(const js_t *o, const char *chave, js_t *v) {
  js_t j = *o;
  js_esp(&j);
  if(j.p >= j.fim || *j.p != '{') return 0;
  j.p++;
  js_esp(&j);
  if(j.p < j.fim && *j.p == '}') return 0;
  for(;;) {
    char nome[64];
    if(js_string(&j, nome, sizeof nome)) return 0;
    js_esp(&j);
    if(j.p >= j.fim || *j.p != ':') return 0;
    j.p++;
    js_esp(&j);
    if(!strcmp(nome, chave)) {
      v->p = j.p;
      v->fim = j.fim;
      return 1;
    }
    if(js_pular(&j, 1)) return 0;
    js_esp(&j);
    if(j.p >= j.fim || *j.p != ',') return 0;
    j.p++;
  }
}

unsigned long long js_num(const js_t *v) {
  return (v->p < v->fim && *v->p >= '0' && *v->p <= '9') ? strtoull(v->p, NULL, 10) : 0;
}

int js_nulo(const js_t *v) { return v->fim - v->p >= 4 && !strncmp(v->p, "null", 4); }

int js_verdade(const js_t *v) { return v->fim - v->p >= 4 && !strncmp(v->p, "true", 4); }

int js_cada(const js_t *a, int (*fn)(const js_t *item, void *ctx), void *ctx) {
  js_t j = *a;
  js_esp(&j);
  if(j.p >= j.fim || *j.p != '[') return -1;
  j.p++;
  js_esp(&j);
  int n = 0;
  if(j.p < j.fim && *j.p == ']') return 0;
  for(;;) {
    js_t item = j;
    if(js_pular(&j, 1)) return -1;
    item.fim = j.p;
    n++;
    if(!fn(&item, ctx)) return n;
    js_esp(&j);
    if(j.p < j.fim && *j.p == ',') {
      j.p++;
      js_esp(&j);
      continue;
    }
    return j.p < j.fim && *j.p == ']' ? n : -1;
  }
}
