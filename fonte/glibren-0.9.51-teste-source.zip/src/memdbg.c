/* Game Library Renamer (payload PS5) - 0.9.40: cliente do MemDBG (protocolo MDBG). Ver memdbg.h.

Formato (docs/protocol.md e include/memdbg/core/memdbg_protocol.h do MemDBG, tudo little-endian, sem padding):
  pedido:   magic u32 (0x4742444d "MDBG"), version u16 (1), command u16, request_id u32, length u32, corpo[length]
  resposta: magic u32, version u16, command u16, request_id u32, status i32 (0 = ok), length u32, corpo[length]
  HELLO 0x0001  corpo opcional de 16 bytes: magic "SES1" u32, version u16 (1), role u16 (4 = TOOL), session_id u64.
                resposta: protocol_version u16 @0, platform_id u16 @2, capabilities u32 @4, debug_port u16 @8,
                udp_log_port u16 @10, version[16] @12, name[16] @28, feature_level u16 @44 (V2+), version_full[48] @64 (V3)
  PING 0x0002, GOODBYE 0x0003 (sem corpo)
  PROCESS_PROTECT 0x0108: pid i32, protection u32, address u64, length u64 -> old u32, new u32
  PROCESS_ALLOC   0x0109: pid i32, protection u32, hint u64, length u64, flags u32 (bit 0 = honrar a dica), reserved u32
                          -> address u64, length u64
  PROCESS_FREE    0x010A: pid i32, reserved u32, address u64, length u64 -> vazio
  MEMORY_READ     0x0200: pid i32, address u64, length u32 -> sub-quadro: 0x00 + bytes (cru) ou 0x01 + tam u32 + LZ4
  MEMORY_WRITE    0x0201: o mesmo + bytes -> vazio ou written u32
So socket TCP no 127.0.0.1: nada de ptrace, syscall ou mmap aqui. */
#include "memdbg.h"

#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>


#ifdef MSG_NOSIGNAL
#define SEM_SINAL MSG_NOSIGNAL
#else
#define SEM_SINAL 0
#endif

#define MAGIC 0x4742444du
#define MAGIC_SESSAO 0x31534553u   /* "SES1" */
#define PAPEL_TOOL 4u
#define CMD_HELLO 0x0001
#define CMD_PING 0x0002
#define CMD_GOODBYE 0x0003
#define CMD_PROTECT 0x0108
#define CMD_ALLOC 0x0109
#define CMD_FREE 0x010A
#define CMD_READ 0x0200
#define CMD_WRITE 0x0201
#define MAX_RESPOSTA (64 * 1024)   /* o maior corpo que o glibren pede e uma leitura de 2 KB */
#define PEDACO_LER 2048            /* < 4096: o MemDBG nunca comprime abaixo de 4 KB */
#define PEDACO_GRAVAR (32 * 1024)
#define CACHE_S 20
#define HELLO_DE_NOVO_S 600

static void p16(unsigned char *p, uint32_t v) { p[0] = (unsigned char)v; p[1] = (unsigned char)(v >> 8); }
static void p32(unsigned char *p, uint32_t v) { for(int i = 0; i < 4; i++) p[i] = (unsigned char)(v >> (8 * i)); }
static void p64(unsigned char *p, uint64_t v) { for(int i = 0; i < 8; i++) p[i] = (unsigned char)(v >> (8 * i)); }
static uint32_t g16(const unsigned char *p) { return (uint32_t)p[0] | (uint32_t)p[1] << 8; }
static uint32_t g32(const unsigned char *p) { return (uint32_t)p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24; }
static uint64_t g64(const unsigned char *p) { return (uint64_t)g32(p) | (uint64_t)g32(p + 4) << 32; }

int mdg_porta(void) {
#ifndef __PROSPERO__
  const char *v = getenv("GLR_TESTE_MEMDBG_PORTA");
  if(v && atoi(v) > 0) return atoi(v);
#endif
  return MDG_PORTA;
}

static int cache_s(void) {
#ifndef __PROSPERO__
  const char *v = getenv("GLR_TESTE_MEMDBG_CACHE_S");
  if(v && *v) return atoi(v);
#endif
  return CACHE_S;
}

const char *mdg_status_nome(int st) {
  static const char *const N[] = {"MEMDBG_OK", "MEMDBG_ERR_PARAM", "MEMDBG_ERR_NOMEM", "MEMDBG_ERR_IO", "MEMDBG_ERR_NET",
                                  "MEMDBG_ERR_PROTOCOL", "MEMDBG_ERR_UNSUPPORTED", "MEMDBG_ERR_NOT_FOUND",
                                  "MEMDBG_ERR_PERMISSION", "MEMDBG_ERR_OVERFLOW", "MEMDBG_ERR_STATE"};
  if(st <= 0 && st >= -10) return N[-st];
  if(st == MDG_ERRO_REDE) return "sem_resposta";
  return "desconhecido";
}

static int enviar_tudo(int fd, const unsigned char *d, size_t n) {
  while(n) {
    ssize_t r = send(fd, d, n, SEM_SINAL);
    if(r <= 0) {
      if(r < 0 && errno == EINTR) continue;
      return -1;
    }
    d += r;
    n -= (size_t)r;
  }
  return 0;
}

static int receber_tudo(int fd, unsigned char *d, size_t n) {
  while(n) {
    ssize_t r = recv(fd, d, n, 0);
    if(r <= 0) {
      if(r < 0 && errno == EINTR) continue;
      return -1;
    }
    d += r;
    n -= (size_t)r;
  }
  return 0;
}

static int conectar(void) {
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if(fd < 0) return -1;
  struct timeval t = {.tv_sec = 5};
  setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &t, sizeof t);
  setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &t, sizeof t);
#ifdef SO_NOSIGPIPE
  int sim = 1;
  setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &sim, sizeof sim);
#endif
  struct sockaddr_in end = {.sin_family = AF_INET, .sin_port = htons((uint16_t)mdg_porta())};
  end.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  if(connect(fd, (struct sockaddr *)&end, sizeof end)) {
    close(fd);
    return -1;
  }
  return fd;
}

/* Um pedido e a resposta dele. corpo da resposta em resp (ate max; *nresp = tamanho). Devolve o status do MemDBG
   (0 = ok, negativo = MEMDBG_ERR_*) ou MDG_ERRO_REDE. */
static int pedir(int fd, uint32_t *id, uint32_t cmd, const unsigned char *corpo, uint32_t n, const unsigned char *extra,
                 uint32_t nextra, unsigned char *resp, uint32_t max, uint32_t *nresp) {
  unsigned char cab[16], rc[20];
  uint32_t rid = ++*id;
  if(nresp) *nresp = 0;
  p32(cab, MAGIC);
  p16(cab + 4, 1);
  p16(cab + 6, cmd);
  p32(cab + 8, rid);
  p32(cab + 12, n + nextra);
  if(enviar_tudo(fd, cab, sizeof cab) || (n && enviar_tudo(fd, corpo, n)) || (nextra && enviar_tudo(fd, extra, nextra)))
    return MDG_ERRO_REDE;
  if(receber_tudo(fd, rc, sizeof rc)) return MDG_ERRO_REDE;
  uint32_t len = g32(rc + 16);
  int st = (int)(int32_t)g32(rc + 12);
  if(g32(rc) != MAGIC || g16(rc + 6) != cmd || g32(rc + 8) != rid || len > MAX_RESPOSTA) return MDG_ERRO_REDE;
  unsigned char *b = len ? malloc(len) : NULL;
  if(len && (!b || receber_tudo(fd, b, len))) {
    free(b);
    return MDG_ERRO_REDE;
  }
  if(resp && b) {
    uint32_t k = len < max ? len : max;
    memcpy(resp, b, k);
    if(nresp) *nresp = len;
  } else if(nresp) *nresp = len;
  free(b);
  return st;
}

/* Corpo do HELLO -> info. 0 = e o MemDBG. */
static int ler_hello(const unsigned char *r, uint32_t n, mdg_info_t *i) {
  memset(i, 0, sizeof *i);
  if(n < 44) return -1;
  char nome[17], v[17], vf[49];
  memcpy(nome, r + 28, 16);
  nome[16] = 0;
  if(strncasecmp(nome, "MemDBG", 6)) return -1;
  i->protocolo = g16(r);
  i->plataforma = g16(r + 2);
  i->caps = g32(r + 4);
  i->nivel = n >= 46 ? g16(r + 44) : 1;   /* sem o campo = nivel 1 (docs/protocol.md) */
  memcpy(v, r + 12, 16);
  v[16] = 0;
  vf[0] = 0;
  if(n >= 112) {
    memcpy(vf, r + 64, 48);
    vf[48] = 0;
  }
  const char *esc = vf[0] ? vf : v;
  size_t k = 0;
  for(const char *c = esc; *c && k + 1 < sizeof i->versao; c++)
    if(strchr("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.-+_", *c)) i->versao[k++] = *c;
  i->versao[k] = 0;
  i->rodando = 1;
  return 0;
}

static int hello(int fd, uint32_t *id, mdg_info_t *i) {
  unsigned char c[16], r[256];
  uint32_t nr = 0;
  uint64_t sessao = ((uint64_t)time(NULL) << 20) ^ (uint64_t)getpid() ^ 0x676c6962ull;   /* "glib" */
  if(!sessao) sessao = 1;
  p32(c, MAGIC_SESSAO);
  p16(c + 4, 1);
  p16(c + 6, PAPEL_TOOL);
  p64(c + 8, sessao);
  int st = pedir(fd, id, CMD_HELLO, c, sizeof c, NULL, 0, r, sizeof r, &nr);
  if(st) return st;
  return ler_hello(r, nr < sizeof r ? nr : sizeof r, i) ? MDG_ERRO_REDE : 0;
}

static void tchau(int fd, uint32_t *id) {
  (void)pedir(fd, id, CMD_GOODBYE, NULL, 0, NULL, 0, NULL, 0, NULL);
}

/* ------------------------------------------------------------------ "rodando agora" (cache) */

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static struct {
  time_t em, hello_em;
  mdg_info_t i;
} g_c;

static void guardar(const mdg_info_t *i, int foi_hello) {
  pthread_mutex_lock(&g_trava);
  g_c.i = *i;
  g_c.em = time(NULL);
  if(foi_hello) g_c.hello_em = g_c.em;
  pthread_mutex_unlock(&g_trava);
}

void mdg_estado(mdg_info_t *saida) {
  pthread_mutex_lock(&g_trava);
  time_t agora = time(NULL);
  if(g_c.em && agora >= g_c.em && agora - g_c.em < cache_s()) {
    *saida = g_c.i;
    pthread_mutex_unlock(&g_trava);
    return;
  }
  /* HELLO so na primeira vez (cada HELLO mostra uma notificacao no PS5); depois PING ate 10 min */
  int so_ping = g_c.i.rodando && g_c.hello_em && agora >= g_c.hello_em && agora - g_c.hello_em < HELLO_DE_NOVO_S;
  mdg_info_t i = so_ping ? g_c.i : (mdg_info_t){0};
  pthread_mutex_unlock(&g_trava);
  uint32_t id = 0;
  int fd = conectar(), ok = 0;
  if(fd >= 0) {
    if(so_ping) ok = !pedir(fd, &id, CMD_PING, NULL, 0, NULL, 0, NULL, 0, NULL);
    else ok = !hello(fd, &id, &i);
    if(ok) tchau(fd, &id);
    close(fd);
  }
  if(!ok) memset(&i, 0, sizeof i);
  guardar(&i, ok && !so_ping);
  if(!ok && so_ping) {
    pthread_mutex_lock(&g_trava);
    g_c.hello_em = 0;
    pthread_mutex_unlock(&g_trava);
  }
  *saida = i;
}

int mdg_pode_reservar(const mdg_info_t *i) {
  uint32_t precisa = MDG_CAP_MEMORY_ALLOC | MDG_CAP_MEMORY_READ | MDG_CAP_MEMORY_WRITE;
  return i->rodando && (i->caps & precisa) == precisa;
}

/* ------------------------------------------------------------------ sessao (um ligar/desligar) */

int mdg_abrir(mdg_sessao_t *s) {
  memset(s, 0, sizeof *s);
  s->fd = conectar();
  if(s->fd < 0) {
    mdg_info_t nada = {0};
    guardar(&nada, 0);
    return MDG_ERRO_REDE;
  }
  int st = hello(s->fd, &s->id, &s->info);
  if(st) {
    close(s->fd);
    s->fd = -1;
    mdg_info_t nada = {0};
    guardar(&nada, 0);
    return st;
  }
  guardar(&s->info, 1);
  return 0;
}

void mdg_fechar(mdg_sessao_t *s) {
  if(s->fd < 0) return;
  tchau(s->fd, &s->id);
  close(s->fd);
  s->fd = -1;
}

int mdg_reservar(mdg_sessao_t *s, int pid, uint64_t dica, uint64_t tam, uint32_t prot, uint64_t *end) {
  unsigned char c[32], r[16];
  uint32_t nr = 0;
  *end = 0;
  if(s->fd < 0) return MDG_ERRO_REDE;
  memset(c, 0, sizeof c);
  p32(c, (uint32_t)pid);
  p32(c + 4, prot);
  p64(c + 8, dica);
  p64(c + 16, tam);
  p32(c + 24, 1);   /* honrar a dica quando a plataforma deixar */
  int st = pedir(s->fd, &s->id, CMD_ALLOC, c, sizeof c, NULL, 0, r, sizeof r, &nr);
  if(st) return st;
  if(nr < 8) return MDG_ERRO_REDE;
  *end = g64(r);
  return *end ? 0 : MDG_ERRO_REDE;
}

int mdg_proteger(mdg_sessao_t *s, int pid, uint64_t end, uint64_t tam, uint32_t prot) {
  unsigned char c[24], r[8];
  uint32_t nr = 0;
  if(s->fd < 0) return MDG_ERRO_REDE;
  p32(c, (uint32_t)pid);
  p32(c + 4, prot);
  p64(c + 8, end);
  p64(c + 16, tam);
  return pedir(s->fd, &s->id, CMD_PROTECT, c, sizeof c, NULL, 0, r, sizeof r, &nr);
}

int mdg_liberar(mdg_sessao_t *s, int pid, uint64_t end, uint64_t tam) {
  unsigned char c[24];
  if(s->fd < 0) return MDG_ERRO_REDE;
  p32(c, (uint32_t)pid);
  p32(c + 4, 0);
  p64(c + 8, end);
  p64(c + 16, tam);
  return pedir(s->fd, &s->id, CMD_FREE, c, sizeof c, NULL, 0, NULL, 0, NULL);
}

int mdg_ler(mdg_sessao_t *s, int pid, uint64_t end, void *saida, size_t n) {
  unsigned char c[16], r[PEDACO_LER + 1];
  unsigned char *o = saida;
  if(s->fd < 0) return MDG_ERRO_REDE;
  while(n) {
    uint32_t k = n > PEDACO_LER ? PEDACO_LER : (uint32_t)n, nr = 0;
    p32(c, (uint32_t)pid);
    p64(c + 4, end);
    p32(c + 12, k);
    int st = pedir(s->fd, &s->id, CMD_READ, c, sizeof c, NULL, 0, r, sizeof r, &nr);
    if(st) return st;
    if(nr != k + 1 || r[0] != 0) return MDG_ERRO_REDE;   /* so o sub-quadro cru (0x00): leitura curta ou LZ4 = erro */
    memcpy(o, r + 1, k);
    o += k;
    end += k;
    n -= k;
  }
  return 0;
}

int mdg_gravar(mdg_sessao_t *s, int pid, uint64_t end, const void *dados, size_t n) {
  unsigned char c[16], r[4];
  const unsigned char *d = dados;
  if(s->fd < 0) return MDG_ERRO_REDE;
  while(n) {
    uint32_t k = n > PEDACO_GRAVAR ? PEDACO_GRAVAR : (uint32_t)n, nr = 0;
    p32(c, (uint32_t)pid);
    p64(c + 4, end);
    p32(c + 12, k);
    int st = pedir(s->fd, &s->id, CMD_WRITE, c, sizeof c, d, k, r, sizeof r, &nr);
    if(st) return st;
    if(nr >= 4 && g32(r) != k) return -3;   /* escrita parcial (o MemDBG manda MEMDBG_ERR_IO nesse caso) */
    d += k;
    end += k;
    n -= k;
  }
  return 0;
}
