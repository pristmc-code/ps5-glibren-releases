/* Game Library Renamer (payload PS5) - 0.9.36: leitor JSON minimo (sem alocar), tirado do conversao.c para servir
tambem ao backup.c (respostas do ShadowMount+/ShadowKraken). js_t aponta para o texto; nada e copiado alem das strings
pedidas. \uXXXX vira UTF-8 (pares substitutos inclusive): caminhos com acento chegam iguais aos do disco. */
#pragma once

#include <stddef.h>

typedef struct {
  const char *p, *fim;
} js_t;

/* pula espacos */
void js_esp(js_t *j);
/* le uma string (j->p no '"'); saida pode ser NULL (so pula). 0 = ok. Saida cortada no tamanho (sem quebrar UTF-8). */
int js_string(js_t *j, char *saida, size_t tam);
/* pula um valor qualquer (nivel = profundidade atual; mais de 32 = erro). 0 = ok. */
int js_pular(js_t *j, int nivel);
/* Procura a chave no objeto que comeca em o->p ('{'). Achou: v aponta para o valor e devolve 1. */
int js_campo(const js_t *o, const char *chave, js_t *v);
/* numero inteiro sem sinal (0 se nao for numero) */
unsigned long long js_num(const js_t *v);
/* 1 = null */
int js_nulo(const js_t *v);
/* 1 = true */
int js_verdade(const js_t *v);
/* Percorre um array (a->p no '['): chama fn para cada item (item.p no inicio dele, item.fim no fim). fn devolve 0 para
   parar. Devolve o numero de itens visitados ou -1 se o JSON estiver quebrado. */
int js_cada(const js_t *a, int (*fn)(const js_t *item, void *ctx), void *ctx);
