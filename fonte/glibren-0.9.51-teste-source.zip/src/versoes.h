/* Game Library Renamer (payload PS5) - 0.9.37: versao de cada jogo e "existe versao mais nova na Sony".

O PS5 NUNCA fala com a Sony (regra fixa do projeto): quem consulta o version.xml de cada jogo e o celular (APK Jobe
Controle) ou o app de PC. O payload so:
- lista os jogos das pastas configuradas com a versao local, o firmware minimo e o versionJsonUri do param.json
  (GET /api/versoes, leitura livre como as outras listas);
- guarda o que o celular/PC achou (POST /api/versoes, X-GLR + aparelho pareado) em <dados>/versoes.json;
- devolve esses resultados para a pagina (GET /api/versoes?resultados=1, sem reler as pastas).
Os dados so mudam na proxima consulta do celular/PC. */
#pragma once

#include "http.h"

/* GET /api/versoes[?resultados=1] */
void versoes_rota_listar(pedido_t *p);
/* POST /api/versoes: corpo JSON {"resultados":[{titleId, versao_nova, fw_exigido, tamanho, consultado_em, erro,
   outra_versao, outro_fw}]}; troca o resultado de cada titleId enviado. */
void versoes_rota_gravar(pedido_t *p);
