/* Game Library Renamer (payload PS5) - 0.9.51: build de teste do ampr-emu-ng no ShadowKraken (ver ampr_teste.h). */
#include "ampr_teste.h"

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "config.h"
#include "fps.h"
#include "lancador.h"
#include "payloads.h"
#include "plataforma.h"
#include "sha256.h"

#define AMPR_MIN (64u * 1024)          /* os runtimes reais tem 700-850 KB */
#define AMPR_MAX (8u * 1024 * 1024)    /* = MAX_CORPO do http.c */
#define AMPR_TRACE_MAX (32u * 1024 * 1024)
#define AMPR_PARADO_S 3                /* o trace so e copiado parado ha 3 s (o jogo ainda pode estar gravando) */

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static int g_ocupado;

/* ------------------------------------------------------------------ caminhos */

/* No PC os testes trocam /data por uma pasta (GLR_TESTE_MONTADOR, a mesma do diagnostico). */
static const char *raiz_data(void) {
#ifndef __PROSPERO__
  const char *r = getenv("GLR_TESTE_MONTADOR");
  if(r && *r) return r;
#endif
  return "/data";
}

/* [emulators] path = ... do /data/shadowmount/config.ini (padrao /data/shadowmount/emus). No PC, um caminho que comeca
   em /data vira a pasta de teste. */
static void pasta_emus(char *saida, size_t tam) {
  char cfg[700], linha[512], secao[64] = "", achado[400] = "";
  snprintf(cfg, sizeof cfg, "%s/shadowmount/config.ini", raiz_data());
  FILE *f = fopen(cfg, "r");
  if(f) {
    while(fgets(linha, sizeof linha, f)) {
      char *l = linha;
      while(*l == ' ' || *l == '\t') l++;
      l[strcspn(l, "\r\n")] = 0;
      if(*l == '[') {
        snprintf(secao, sizeof secao, "%.*s", (int)strcspn(l + 1, "]"), l + 1);
        continue;
      }
      if(strcasecmp(secao, "emulators")) continue;
      if(strncasecmp(l, "path", 4) || (l[4] != ' ' && l[4] != '=' && l[4] != '\t')) continue;
      char *v = strchr(l, '=');
      if(!v) continue;
      for(v++; *v == ' ' || *v == '\t'; v++) {}
      size_t n = strlen(v);
      while(n && (v[n - 1] == ' ' || v[n - 1] == '\t' || v[n - 1] == '/')) v[--n] = 0;
      if(v[0] == '/' && !strstr(v, "..")) snprintf(achado, sizeof achado, "%s", v);
    }
    fclose(f);
  }
  if(!achado[0]) snprintf(achado, sizeof achado, "/data/shadowmount/emus");
  if(!strncmp(achado, "/data/", 6) || !strcmp(achado, "/data")) snprintf(saida, tam, "%s%s", raiz_data(), achado + 5);
  else snprintf(saida, tam, "%s", achado);
}

static void caminho_runtime(char *saida, size_t tam, const char *ext) {
  char emus[600];
  pasta_emus(emus, sizeof emus);
  snprintf(saida, tam, "%s/ampr-emu-ng/libSceAmpr.sprx%s", emus, ext ? ext : "");
}

static void caminho_trace(char *saida, size_t tam) { snprintf(saida, tam, "%s/ampr_emu_trace.txt", raiz_data()); }
static void pasta_traces(char *saida, size_t tam) { snprintf(saida, tam, "%s/ampr-traces", g_pasta_dados); }

/* ------------------------------------------------------------------ conferir um runtime */

typedef struct {
  char versao[24];     /* "0.5.0" */
  char commit[16];     /* so no de depuracao ("5a8cca6"), quando acha */
  int depuracao;       /* 1 = build de depuracao (grava /data/ampr_emu_trace.txt) */
  char sha256[65];
  size_t tamanho;
} runtime_t;

static const char *achar(const char *d, size_t n, const char *agulha) {
  size_t k = strlen(agulha);
  if(n < k) return NULL;
  for(size_t i = 0; i + k <= n; i++)
    if(d[i] == agulha[0] && !memcmp(d + i, agulha, k)) return d + i;
  return NULL;
}

static int eh_hex(char c) { return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'); }

/* Confere o .sprx (ja na memoria). 0 = serve; senao o motivo em erro. */
static int conferir(const char *d, size_t n, runtime_t *rt, char *erro, size_t tam_erro) {
  memset(rt, 0, sizeof *rt);
  if(n < AMPR_MIN || n > AMPR_MAX) {
    snprintf(erro, tam_erro, "tamanho fora do limite (%zu bytes; aceito de 64 KB a 8 MB)", n);
    return -1;
  }
  if(memcmp(d, "\x4f\x15\x3d\x1d", 4) && memcmp(d, "\x7f" "ELF", 4)) {
    snprintf(erro, tam_erro, "nao e um SELF/ELF (.sprx)");
    return -1;
  }
  /* "ampr-emu-ng X.Y.Z" (o mesmo marcador que o ShadowKraken le em sm_ampr_ng_read_version) */
  const char *m = d;
  size_t resto = n;
  while((m = achar(m, resto, "ampr-emu-ng "))) {
    const char *v = m + 12;
    size_t i = 0;
    while(v + i < d + n && i < sizeof rt->versao - 1 && ((v[i] >= '0' && v[i] <= '9') || v[i] == '.')) i++;
    if(i >= 5 && v[0] >= '0' && v[0] <= '9') {
      memcpy(rt->versao, v, i);
      rt->versao[i] = 0;
      break;
    }
    resto = (size_t)(d + n - (m + 1));
    m++;
  }
  if(!rt->versao[0]) {
    snprintf(erro, tam_erro, "nao tem o marcador \"ampr-emu-ng X.Y.Z\": nao parece o ampr-emu-ng");
    return -1;
  }
  rt->depuracao = achar(d, n, "/data/ampr_emu_trace.txt") != NULL;
  if(rt->depuracao) {   /* build de depuracao: "...plain-fs 5a8cca6..." (commit curto ao lado dos nomes dos modos) */
    const char *c = achar(d, n, "plain-fs ");
    if(c) {
      c += 9;
      size_t i = 0;
      while(c + i < d + n && i < 12 && eh_hex(c[i])) i++;
      if(i >= 7) snprintf(rt->commit, sizeof rt->commit, "%.*s", (int)i, c);
    }
  }
  sha256_t s;
  uint8_t r[32];
  sha256_iniciar(&s);
  sha256_atualizar(&s, d, n);
  sha256_final(&s, r);
  sha256_hex(r, rt->sha256);
  rt->tamanho = n;
  return 0;
}

static int ler_arquivo(const char *c, buf_t *b, size_t max) {
  int fd = open(c, O_RDONLY | O_NOFOLLOW);
  struct stat st;
  if(fd < 0) return -1;
  if(fstat(fd, &st) || !S_ISREG(st.st_mode) || (size_t)st.st_size > max) {
    close(fd);
    errno = EFBIG;
    return -1;
  }
  char bloco[64 * 1024];
  ssize_t r;
  while((r = read(fd, bloco, sizeof bloco)) > 0) buf_add(b, bloco, (size_t)r);
  close(fd);
  return r < 0 ? -1 : 0;
}

/* Le e confere o runtime de um caminho (estado da pagina). 0 = existe e confere. */
static int runtime_de(const char *c, runtime_t *rt, time_t *quando) {
  struct stat st;
  if(lstat(c, &st) || !S_ISREG(st.st_mode)) return -1;
  if(quando) *quando = st.st_mtime;
  buf_t b = {0};
  char erro[200];
  int r = ler_arquivo(c, &b, AMPR_MAX) ? -1 : conferir(b.d, b.n, rt, erro, sizeof erro);
  buf_free(&b);
  return r;
}

/* ------------------------------------------------------------------ gravar / voltar */

static int ampr_criar_pastas(const char *c) {
  char t[700];
  snprintf(t, sizeof t, "%s", c);
  for(char *p = t + 1; *p; p++)
    if(*p == '/') {
      *p = 0;
      if(mkdir(t, 0777) && errno != EEXIST) return -1;
      *p = '/';
    }
  return mkdir(t, 0777) && errno != EEXIST ? -1 : 0;
}

/* Jogo aberto: a troca so vale na proxima abertura e o fakelib dele esta montado; recusa. */
static int jogo_aberto(char *tid, size_t tam) { return app_de_jogo_aberto(tid, tam) == 1; }

/* .tmp + fsync + rename; o atual vira .anterior. 0 = ok. */
static int gravar(const buf_t *b, char *erro, size_t tam_erro) {
  char dest[700], tmp[720], ant[720], pasta[700];
  caminho_runtime(dest, sizeof dest, NULL);
  caminho_runtime(tmp, sizeof tmp, ".tmp");
  caminho_runtime(ant, sizeof ant, ".anterior");
  snprintf(pasta, sizeof pasta, "%s", dest);
  *strrchr(pasta, '/') = 0;
  if(ampr_criar_pastas(pasta)) {
    snprintf(erro, tam_erro, "nao criou a pasta %s (%s)", pasta, strerror(errno));
    return -1;
  }
  int fd = open(tmp, O_WRONLY | O_CREAT | O_TRUNC | O_NOFOLLOW, 0777);
  if(fd < 0) {
    snprintf(erro, tam_erro, "nao gravou %s (%s)", tmp, strerror(errno));
    return -1;
  }
  size_t feito = 0;
  while(feito < b->n) {
    ssize_t w = write(fd, b->d + feito, b->n - feito);
    if(w <= 0) break;
    feito += (size_t)w;
  }
  int ok = feito == b->n && !fsync(fd);
  if(close(fd)) ok = 0;
  if(!ok) {
    unlink(tmp);
    snprintf(erro, tam_erro, "erro ao gravar %s (%s)", tmp, strerror(errno));
    return -1;
  }
  chmod(tmp, 0777);
  struct stat st;
  if(!lstat(dest, &st) && S_ISREG(st.st_mode)) {
    unlink(ant);
    if(rename(dest, ant)) {
      unlink(tmp);
      snprintf(erro, tam_erro, "nao guardou o anterior (%s)", strerror(errno));
      return -1;
    }
  }
  if(rename(tmp, dest)) {
    snprintf(erro, tam_erro, "nao trocou o arquivo (%s)", strerror(errno));
    unlink(tmp);
    return -1;
  }
  int dfd = open(pasta, O_RDONLY);
  if(dfd >= 0) {
    fsync(dfd);
    close(dfd);
  }
  return 0;
}

static int comecar(pedido_t *p) {
  if(fps_agente_ps5(p->agente) || p->local) {
    responder_erro(p, 403, "ampr_so_celular", "o build de teste so muda pelo celular ou PC pareado", NULL);
    return -1;
  }
  char tid[16];
  if(jogo_aberto(tid, sizeof tid)) {
    responder_erro(p, 409, "ampr_jogo_aberto", "feche o jogo antes de trocar o ampr-emu-ng", tid);
    return -1;
  }
  pthread_mutex_lock(&g_trava);
  int ocupado = g_ocupado;
  g_ocupado = 1;
  pthread_mutex_unlock(&g_trava);
  if(ocupado) {
    responder_erro(p, 409, "ampr_ocupado", "outra troca do ampr-emu-ng esta andando: espere", NULL);
    return -1;
  }
  return 0;
}

static void terminar(void) {
  pthread_mutex_lock(&g_trava);
  g_ocupado = 0;
  pthread_mutex_unlock(&g_trava);
}

static void responder_ok(pedido_t *p, const runtime_t *rt, const char *nome) {
  buf_t r = {0};
  buf_str(&r, "{\"ok\":true,\"nome\":");
  buf_json(&r, nome);
  buf_str(&r, ",\"versao\":");
  buf_json(&r, rt->versao);
  buf_str(&r, ",\"commit\":");
  buf_json(&r, rt->commit);
  buf_fmt(&r, ",\"depuracao\":%s,\"tamanho\":%zu,\"sha256\":", rt->depuracao ? "true" : "false", rt->tamanho);
  buf_json(&r, rt->sha256);
  buf_str(&r, "}");
  responder_json(p, 200, &r);
  buf_free(&r);
}

static int nome_ok(const char *nome) {
  size_t n = strlen(nome);
  if(n < 6 || n >= 128 || strcasecmp(nome + n - 5, ".sprx")) return 0;
  for(const char *c = nome; *c; c++)
    if((unsigned char)*c < ' ' || *c == '/' || *c == '\\') return 0;
  return 1;
}

static void instalar(pedido_t *p, const buf_t *b, const char *nome, const char *origem) {
  runtime_t rt;
  char erro[240] = "";
  if(conferir(b->d, b->n, &rt, erro, sizeof erro) || gravar(b, erro, sizeof erro)) {
    diario("ampr-teste: recusado: %s (%s, %zu bytes)", erro, origem, b->n);
    terminar();
    responder_erro(p, 400, "ampr_arquivo_erro", erro, NULL);
    return;
  }
  char dest[700];
  caminho_runtime(dest, sizeof dest, NULL);
  diario("ampr-teste: build de teste instalado: %s -> %s (ampr-emu-ng %s%s%s, %s, %zu bytes, sha256 %s); vale na proxima abertura de cada jogo",
         origem, dest, rt.versao, rt.commit[0] ? " " : "", rt.commit, rt.depuracao ? "depuracao" : "release", rt.tamanho, rt.sha256);
  terminar();
  responder_ok(p, &rt, nome);
}

void ampr_teste_rota_enviar(pedido_t *p) {
  char nome[160] = "", origem[200];
  param(p->query, "nome", 0, nome, sizeof nome);
  if(!nome_ok(nome)) {
    responder_erro(p, 400, "ampr_arquivo_nome", "escolha um arquivo .sprx", NULL);
    return;
  }
  if(comecar(p)) return;
  snprintf(origem, sizeof origem, "celular/PC: %s", nome);
  buf_t b = {.d = p->corpo, .n = p->corpo ? p->corpo_n : 0};
  instalar(p, &b, nome, origem);
}

void ampr_teste_rota_arquivo(pedido_t *p) {
  char origem[1024] = "";
  param(p->corpo, "caminho", 0, origem, sizeof origem);
  const char *nome = strrchr(origem, '/');
  if(!nome || !nome_ok(nome + 1)) {
    responder_erro(p, 400, "ampr_arquivo_nome", "escolha um arquivo .sprx", NULL);
    return;
  }
  if(!payloads_caminho_de_disco(origem)) {
    responder_erro(p, 400, "ampr_arquivo_fora", "o arquivo tem de estar num disco do PS5 (/data, USB ou disco extra), sem links", NULL);
    return;
  }
  if(comecar(p)) return;
  buf_t b = {0};
  if(ler_arquivo(origem, &b, AMPR_MAX)) {
    char erro[240];
    snprintf(erro, sizeof erro, errno == EFBIG ? "tamanho fora do limite (aceito de 64 KB a 8 MB)" : "nao abriu o arquivo");
    buf_free(&b);
    diario("ampr-teste: recusado: %s (%s)", erro, origem);
    terminar();
    responder_erro(p, 400, "ampr_arquivo_erro", erro, NULL);
    return;
  }
  instalar(p, &b, nome + 1, origem);
  buf_free(&b);
}

void ampr_teste_rota_embutido(pedido_t *p) {
  if(comecar(p)) return;
  char dest[700], ant[720];
  caminho_runtime(dest, sizeof dest, NULL);
  caminho_runtime(ant, sizeof ant, ".anterior");
  struct stat st;
  if(lstat(dest, &st)) {
    terminar();
    static const char ja[] = "{\"ok\":true,\"ja\":true}";
    responder(p, 200, "application/json", ja, sizeof ja - 1, NULL);
    return;
  }
  unlink(ant);
  if(!S_ISREG(st.st_mode) || rename(dest, ant)) {
    char erro[200];
    snprintf(erro, sizeof erro, "nao tirou o arquivo de teste (%s)", S_ISREG(st.st_mode) ? strerror(errno) : "nao e um arquivo");
    diario("ampr-teste: voltar ao embutido falhou: %s", erro);
    terminar();
    responder_erro(p, 400, "ampr_arquivo_erro", erro, NULL);
    return;
  }
  diario("ampr-teste: voltou ao ampr-emu-ng embutido no ShadowKraken (o de teste ficou em %s); vale na proxima abertura de cada jogo", ant);
  terminar();
  static const char feito[] = "{\"ok\":true,\"ja\":false}";
  responder(p, 200, "application/json", feito, sizeof feito - 1, NULL);
}

/* ------------------------------------------------------------------ copias do trace */

typedef struct {
  char nome[96];
  time_t quando;
  long long bytes;
} copia_t;

static int cmp_copia(const void *a, const void *b) {   /* mais nova primeiro (o nome comeca pela data-hora) */
  return strcmp(((const copia_t *)b)->nome, ((const copia_t *)a)->nome);
}

static int listar_copias(copia_t *c, int max) {
  char pasta[600];
  pasta_traces(pasta, sizeof pasta);
  DIR *d = opendir(pasta);
  if(!d) return 0;
  int n = 0;
  copia_t todas[64];
  struct dirent *e;
  while((e = readdir(d)) && n < 64) {
    size_t k = strlen(e->d_name);
    if(e->d_name[0] == '.' || k < 5 || k >= sizeof todas[0].nome || strcmp(e->d_name + k - 4, ".txt")) continue;
    char c2[700];
    struct stat st;
    snprintf(c2, sizeof c2, "%s/%s", pasta, e->d_name);
    if(lstat(c2, &st) || !S_ISREG(st.st_mode)) continue;
    snprintf(todas[n].nome, sizeof todas[n].nome, "%s", e->d_name);
    todas[n].quando = st.st_mtime;
    todas[n].bytes = (long long)st.st_size;
    n++;
  }
  closedir(d);
  qsort(todas, (size_t)n, sizeof todas[0], cmp_copia);
  for(int i = 0; i < n && i < max; i++) c[i] = todas[i];
  return n < max ? n : max;
}

/* Apaga as mais velhas, deixando AMPR_TRACES_MAX. */
static void podar(void) {
  char pasta[600];
  pasta_traces(pasta, sizeof pasta);
  copia_t c[64];
  DIR *d = opendir(pasta);
  if(!d) return;
  int n = 0;
  struct dirent *e;
  while((e = readdir(d)) && n < 64) {
    size_t k = strlen(e->d_name);
    if(e->d_name[0] == '.' || k < 5 || k >= sizeof c[0].nome || strcmp(e->d_name + k - 4, ".txt")) continue;
    snprintf(c[n++].nome, sizeof c[0].nome, "%s", e->d_name);
  }
  closedir(d);
  qsort(c, (size_t)n, sizeof c[0], cmp_copia);
  for(int i = AMPR_TRACES_MAX; i < n; i++) {
    char c2[700];
    snprintf(c2, sizeof c2, "%s/%s", pasta, c[i].nome);
    unlink(c2);
  }
}

/* Title ID no comeco do trace (PPSA/CUSA + 5 digitos); "" se nao achar. */
static void titulo_do_trace(const char *d, size_t n, char *tid) {
  tid[0] = 0;
  if(n > 64 * 1024) n = 64 * 1024;
  for(size_t i = 0; i + 9 <= n; i++) {
    if(memcmp(d + i, "PPSA", 4) && memcmp(d + i, "CUSA", 4)) continue;
    int ok = 1;
    for(int k = 4; k < 9; k++) ok &= d[i + k] >= '0' && d[i + k] <= '9';
    if(ok && (i + 9 == n || d[i + 9] < '0' || d[i + 9] > '9')) {
      memcpy(tid, d + i, 9);
      tid[9] = 0;
      return;
    }
  }
}

static int copiar_trace(const char *origem, const struct stat *st) {
  buf_t b = {0};
  if(ler_arquivo(origem, &b, AMPR_TRACE_MAX)) {
    buf_free(&b);
    return -1;
  }
  char pasta[600], tid[16], dest[760];
  pasta_traces(pasta, sizeof pasta);
  if(ampr_criar_pastas(pasta)) {
    buf_free(&b);
    return -1;
  }
  titulo_do_trace(b.d ? b.d : "", b.n, tid);
  if(!tid[0]) app_de_jogo_aberto(tid, sizeof tid);
  struct tm tm;
  time_t q = st->st_mtime;
  localtime_r(&q, &tm);
  snprintf(dest, sizeof dest, "%s/%04d-%02d-%02d_%02d%02d%02d%s%s.txt", pasta, tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
           tm.tm_hour, tm.tm_min, tm.tm_sec, tid[0] ? "-" : "", tid);
  FILE *f = fopen(dest, "wb");
  int ok = f && (!b.n || fwrite(b.d, 1, b.n, f) == b.n);
  if(f && fclose(f)) ok = 0;
  if(!ok) unlink(dest);
  else diario("ampr-teste: trace do ampr-emu-ng copiado: %s (%zu bytes%s%s)", strrchr(dest, '/') + 1, b.n, tid[0] ? ", " : "", tid);
  buf_free(&b);
  podar();
  return ok ? 0 : -1;
}

static int vigia_intervalo_ms(void) {
#ifndef __PROSPERO__
  const char *v = getenv("GLR_TESTE_AMPR_VIGIA_MS");
  if(v && atoi(v) > 0) return atoi(v);
#endif
  return 2000;
}

static int parado_s(void) {
#ifndef __PROSPERO__
  const char *v = getenv("GLR_TESTE_AMPR_PARADO_S");
  if(v) return atoi(v);
#endif
  return AMPR_PARADO_S;
}

static void *vigia(void *arg) {
  (void)arg;
  char c[700];
  caminho_trace(c, sizeof c);
  /* ao iniciar: o trace que ja existe e o do ultimo jogo; so copia se nao houver copia com a mesma data */
  long long visto_tam = -1;
  time_t visto_mtime = 0;
  copia_t ultima[1];
  struct stat st;
  if(!lstat(c, &st) && listar_copias(ultima, 1) == 1 && ultima[0].bytes == (long long)st.st_size) {
    visto_tam = (long long)st.st_size;
    visto_mtime = st.st_mtime;
  }
  for(;;) {
    usleep((useconds_t)vigia_intervalo_ms() * 1000);
    if(lstat(c, &st) || !S_ISREG(st.st_mode)) continue;
    if((long long)st.st_size == visto_tam && st.st_mtime == visto_mtime) continue;
    if(time(NULL) - st.st_mtime < parado_s()) continue;   /* ainda gravando */
    if(!copiar_trace(c, &st)) {
      visto_tam = (long long)st.st_size;
      visto_mtime = st.st_mtime;
    } else {
      visto_tam = (long long)st.st_size;   /* nao tenta de novo o mesmo arquivo a cada 2 s */
      visto_mtime = st.st_mtime;
    }
  }
  return NULL;
}

void ampr_teste_iniciar(void) {
  pthread_t t;
  if(!criar_thread(vigia, NULL, &t)) pthread_detach(t);
}

int ampr_teste_traces(char nomes[][96], char caminhos[][600], int max) {
  copia_t c[AMPR_TRACES_MAX];
  char pasta[600];
  pasta_traces(pasta, sizeof pasta);
  int n = listar_copias(c, max < AMPR_TRACES_MAX ? max : AMPR_TRACES_MAX);
  for(int i = 0; i < n; i++) {
    snprintf(nomes[i], 96, "ampr-trace-%s", c[i].nome);
    snprintf(caminhos[i], 600, "%s/%s", pasta, c[i].nome);
  }
  return n;
}

/* ------------------------------------------------------------------ estado */

static void runtime_json(buf_t *b, const char *chave, const char *c) {
  runtime_t rt;
  time_t q = 0;
  buf_fmt(b, ",\"%s\":", chave);
  if(runtime_de(c, &rt, &q)) {
    struct stat st;
    if(!lstat(c, &st)) {   /* existe mas nao confere: o ShadowKraken tambem nao usa */
      buf_str(b, "{\"valido\":false,\"caminho\":");
      buf_json(b, c);
      buf_str(b, "}");
    } else buf_str(b, "null");
    return;
  }
  buf_str(b, "{\"valido\":true,\"caminho\":");
  buf_json(b, c);
  buf_str(b, ",\"versao\":");
  buf_json(b, rt.versao);
  buf_str(b, ",\"commit\":");
  buf_json(b, rt.commit);
  buf_fmt(b, ",\"depuracao\":%s,\"tamanho\":%zu,\"desde\":%lld,\"sha256\":", rt.depuracao ? "true" : "false", rt.tamanho,
          (long long)q);
  buf_json(b, rt.sha256);
  buf_str(b, "}");
}

void ampr_teste_json(buf_t *b) {
  char c[700], ant[720], emus[600];
  caminho_runtime(c, sizeof c, NULL);
  caminho_runtime(ant, sizeof ant, ".anterior");
  pasta_emus(emus, sizeof emus);
  buf_str(b, "{\"ok\":true,\"pasta_emus\":");
  buf_json(b, emus);
  runtime_json(b, "teste", c);
  runtime_json(b, "anterior", ant);
  copia_t cp[AMPR_TRACES_MAX];
  int n = listar_copias(cp, AMPR_TRACES_MAX);
  buf_fmt(b, ",\"traces\":%d,\"ultimo_trace\":", n);
  if(n) {
    buf_str(b, "{\"nome\":");
    buf_json(b, cp[0].nome);
    buf_fmt(b, ",\"quando\":%lld,\"bytes\":%lld}", (long long)cp[0].quando, cp[0].bytes);
  } else buf_str(b, "null");
  pthread_mutex_lock(&g_trava);
  buf_fmt(b, ",\"ocupado\":%s}", g_ocupado ? "true" : "false");
  pthread_mutex_unlock(&g_trava);
}

void ampr_teste_rota_estado(pedido_t *p) {
  buf_t b = {0};
  ampr_teste_json(&b);
  responder_json(p, 200, &b);
  buf_free(&b);
}
