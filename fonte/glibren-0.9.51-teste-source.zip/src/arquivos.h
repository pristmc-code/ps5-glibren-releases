/* Game Library Renamer (payload PS5) - gerenciador de arquivos, leitura das pastas e renomear. */
#pragma once

#include "util.h"

/* Lista uma pasta (pastas primeiro, depois arquivos, por nome). Devolve 0 ou errno. */
int arquivos_listar(const char *caminho, buf_t *json);
/* Le a raiz de cada pasta configurada: arquivos comuns (com tamanho) e pastas de jogo (tipo "pasta", sem tamanho). */
void arquivos_escanear(buf_t *json);
/* 1 = pasta com eboot.bin e sce_sys/param.json ou sce_sys/param.sfo (pasta de jogo do ShadowMount+). */
int arquivos_pasta_de_jogo(const char *caminho);
/* 0.9.49: 1 = pasta da lista (config_pasta_permitida) OU subpasta <jogo> logo abaixo de uma pasta da lista que fica em
   <disco>/BACKUP (onde a conversao e a Jobe guardam os originais: BACKUP/<jogo>/<arquivo>). A subpasta tem de existir,
   nao pode ser ela mesma uma pasta de jogo nem comecar com ponto. Vale para a ORIGEM de renomear/mover/excluir/
   converter; destino de copiar/mover continua so nas pastas da lista. */
int arquivos_pasta_permitida(const char *pasta);
/* 0.9.49: depois de tirar um item de BACKUP/<jogo>/: se sobrou so o marcador (ou nada), apaga o marcador e a subpasta.
   Nao faz nada para pasta da lista nem para subpasta com qualquer outra coisa dentro. */
void arquivos_limpar_subpasta_backup(const char *pasta);

/* Erros do renomear: chave para a tela (traduzida la). */
typedef enum { REN_OK, REN_INVALIDO, REN_ORIGEM_SUMIU, REN_DESTINO_EXISTE, REN_EM_DOWNLOAD, REN_FALHOU } ren_t;
ren_t arquivos_renomear(const char *pasta, const char *de, const char *para, long long tamanho);
const char *ren_chave(ren_t r);

int em_download(const char *pasta, const char *nome);
