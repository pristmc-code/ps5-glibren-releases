/* Game Library Renamer (payload PS5) - 0.9.37: versao de cada jogo e resultados da consulta feita pelo celular/PC.
Ver versoes.h. O PS5 nao faz nenhum pedido a Sony: nada daqui abre conexao. */
#include "versoes.h"

#include <ctype.h>
#include <dirent.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "arquivos.h"
#include "backup.h"
#include "config.h"
#include "jogo_local.h"
#include "json_min.h"
#include "payloads.h"
#include "plataforma.h"
#include "util.h"

#define MAX_RESULTADOS 3000
#define MAX_JOGOS 3000
#define MAX_ARQUIVO (2 * 1024 * 1024)
#define ARQUIVO "versoes.json"

typedef struct {
  char tid[16];
  char versao[24], fw[8];          /* a mais nova que a Sony oferece e o firmware que ela pede */
  char outra_versao[24], outro_fw[8];   /* 2o pacote diferente (pre-download), se houver */
  long long tamanho;               /* bytes (0 = nao sabe) */
  long long consultado_em;         /* segundos desde 1970 (UTC), do celular/PC */
  char erro[128];                  /* "" = consulta ok */
} resultado_t;

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static resultado_t *g_res;
static int g_n, g_lido;

/* ------------------------------------------------------------------ validacao */

static int tid_ok(const char *t) {
  if(strlen(t) != 9) return 0;
  for(int i = 0; i < 4; i++)
    if(t[i] < 'A' || t[i] > 'Z') return 0;
  for(int i = 4; i < 9; i++)
    if(!isdigit((unsigned char)t[i])) return 0;
  return 1;
}

/* "02.000.003": so digitos e pontos, comeca e termina em digito */
static int versao_ok(const char *v) {
  size_t n = strlen(v);
  if(!n || n > 20 || v[0] == '.' || v[n - 1] == '.') return 0;
  for(; *v; v++)
    if(!isdigit((unsigned char)*v) && *v != '.') return 0;
  return 1;
}

/* "14.20" / "9.00" */
static int fw_ok(const char *f) {
  const char *p = strchr(f, '.');
  if(!p || p == f || p - f > 2 || strlen(p + 1) != 2) return 0;
  for(const char *c = f; *c; c++)
    if(c != p && !isdigit((unsigned char)*c)) return 0;
  return 1;
}

/* erro: texto curto e imprimivel (vai para a tela e para o arquivo) */
static void limpar_texto(char *s) {
  for(unsigned char *c = (unsigned char *)s; *c; c++)
    if(*c < ' ' || *c == 0x7f) *c = ' ';
}

/* ------------------------------------------------------------------ arquivo */

static void caminho_arquivo(char *saida, size_t tam) {
  snprintf(saida, tam, "%s/%s", g_pasta_dados, ARQUIVO);
}

static int ler_item(const js_t *o, resultado_t *r) {
  js_t v;
  memset(r, 0, sizeof *r);
  if(!js_campo(o, "titleId", &v) || js_string(&v, r->tid, sizeof r->tid) || !tid_ok(r->tid)) return -1;
  if(js_campo(o, "versao_nova", &v) && !js_nulo(&v) && js_string(&v, r->versao, sizeof r->versao)) r->versao[0] = 0;
  if(js_campo(o, "fw_exigido", &v) && !js_nulo(&v) && js_string(&v, r->fw, sizeof r->fw)) r->fw[0] = 0;
  if(js_campo(o, "outra_versao", &v) && !js_nulo(&v) && js_string(&v, r->outra_versao, sizeof r->outra_versao)) r->outra_versao[0] = 0;
  if(js_campo(o, "outro_fw", &v) && !js_nulo(&v) && js_string(&v, r->outro_fw, sizeof r->outro_fw)) r->outro_fw[0] = 0;
  if(js_campo(o, "erro", &v) && !js_nulo(&v) && js_string(&v, r->erro, sizeof r->erro)) r->erro[0] = 0;
  if(js_campo(o, "tamanho", &v)) r->tamanho = (long long)js_num(&v);
  if(js_campo(o, "consultado_em", &v)) r->consultado_em = (long long)js_num(&v);
  if(r->versao[0] && !versao_ok(r->versao)) return -1;
  if(r->fw[0] && !fw_ok(r->fw)) return -1;
  if(r->outra_versao[0] && !versao_ok(r->outra_versao)) r->outra_versao[0] = 0;
  if(r->outro_fw[0] && !fw_ok(r->outro_fw)) r->outro_fw[0] = 0;
  if(!r->versao[0] && !r->erro[0]) return -1;   /* nem versao nem erro: nada a guardar */
  if(r->tamanho < 0 || r->tamanho > (1LL << 50)) r->tamanho = 0;
  limpar_texto(r->erro);
  return 0;
}

typedef struct {
  resultado_t *lista;
  int n, max, recusados;
} leitura_t;

static int ler_cada(const js_t *item, void *ctx) {
  leitura_t *l = ctx;
  resultado_t r;
  if(ler_item(item, &r)) {
    l->recusados++;
    return 1;
  }
  for(int i = 0; i < l->n; i++)   /* o mesmo jogo repetido: vale o ultimo */
    if(!strcmp(l->lista[i].tid, r.tid)) {
      l->lista[i] = r;
      return 1;
    }
  if(l->n < l->max) l->lista[l->n++] = r;
  else l->recusados++;
  return 1;
}

/* Carrega o arquivo na primeira vez (com a trava). */
static void carregar(void) {
  if(g_lido) return;
  g_lido = 1;
  if(!g_res) g_res = calloc(MAX_RESULTADOS, sizeof *g_res);
  if(!g_res) return;
  char arq[600];
  caminho_arquivo(arq, sizeof arq);
  FILE *f = fopen(arq, "rb");
  if(!f) return;
  buf_t b = {0};
  char bloco[8192];
  size_t n;
  while((n = fread(bloco, 1, sizeof bloco, f)) > 0 && b.n + n <= MAX_ARQUIVO) buf_add(&b, bloco, n);
  fclose(f);
  buf_add(&b, "", 1);
  js_t raiz = {b.d, b.d + b.n - 1}, lista;
  if(js_campo(&raiz, "resultados", &lista)) {
    leitura_t l = {g_res, 0, MAX_RESULTADOS, 0};
    if(js_cada(&lista, ler_cada, &l) < 0) diario("versoes: %s estragado; comecando do zero", arq);
    else g_n = l.n;
  }
  buf_free(&b);
}

static void item_json(buf_t *b, const resultado_t *r) {
  buf_str(b, "{\"titleId\":");
  buf_json(b, r->tid);
  if(r->versao[0]) {
    buf_str(b, ",\"versao_nova\":");
    buf_json(b, r->versao);
  }
  if(r->fw[0]) {
    buf_str(b, ",\"fw_exigido\":");
    buf_json(b, r->fw);
  }
  if(r->outra_versao[0]) {
    buf_str(b, ",\"outra_versao\":");
    buf_json(b, r->outra_versao);
    if(r->outro_fw[0]) {
      buf_str(b, ",\"outro_fw\":");
      buf_json(b, r->outro_fw);
    }
  }
  if(r->tamanho > 0) buf_fmt(b, ",\"tamanho\":%lld", r->tamanho);
  buf_fmt(b, ",\"consultado_em\":%lld", r->consultado_em);
  if(r->erro[0]) {
    buf_str(b, ",\"erro\":");
    buf_json(b, r->erro);
  }
  buf_str(b, "}");
}

static void resultados_json(buf_t *b) {
  buf_str(b, "[");
  for(int i = 0; i < g_n; i++) {
    if(i) buf_str(b, ",");
    item_json(b, &g_res[i]);
  }
  buf_str(b, "]");
}

/* .tmp + rename (com a trava). 0 = gravou. */
static int gravar(void) {
  char arq[600], tmp[610];
  caminho_arquivo(arq, sizeof arq);
  snprintf(tmp, sizeof tmp, "%s.tmp", arq);
  buf_t b = {0};
  buf_str(&b, "{\"versao\":1,\"resultados\":");
  resultados_json(&b);
  buf_str(&b, "}\n");
  FILE *f = fopen(tmp, "wb");
  int ok = f && fwrite(b.d, 1, b.n, f) == b.n;
  if(f && fclose(f)) ok = 0;
  buf_free(&b);
  if(!ok || rename(tmp, arq)) {
    unlink(tmp);
    return -1;
  }
  return 0;
}

/* ------------------------------------------------------------------ lista de jogos */

static int termina(const char *s, const char *fim) {
  size_t a = strlen(s), b = strlen(fim);
  return a > b && !strcasecmp(s + a - b, fim);
}

/* So imagens e pacotes de jogo (a mesma lista da pagina: RE_IMAGEM_JOGO) e pastas de jogo. */
static int candidato(const char *nome) {
  static const char *const EXT[] = {".pkg", ".exfat", ".ffpkg", ".ffpfs", ".ffpfsc", ".ufs2", NULL};
  for(int i = 0; EXT[i]; i++)
    if(termina(nome, EXT[i])) return 1;
  return 0;
}

static void listar_jogos(buf_t *b) {
  char pastas[MAX_PASTAS][1024], icones[600];
  int qtd = config_ler(pastas, NULL), n = 0;
  snprintf(icones, sizeof icones, "%s/icones", g_pasta_dados);
  buf_str(b, "[");
  for(int i = 0; i < qtd && n < MAX_JOGOS; i++) {
    if(backup_dentro(pastas[i])) continue;   /* originais guardados depois de converter: nao sao jogos a mais */
    DIR *d = opendir(pastas[i]);
    if(!d) continue;
    struct dirent *e;
    char caminho[1400];
    size_t np = strlen(pastas[i]);
    while(np > 1 && pastas[i][np - 1] == '/') pastas[i][--np] = 0;
    while((e = readdir(d)) && n < MAX_JOGOS) {
      if(e->d_name[0] == '.') continue;
      snprintf(caminho, sizeof caminho, "%s/%s", strcmp(pastas[i], "/") ? pastas[i] : "", e->d_name);
      struct stat st;
      if(lstat(caminho, &st)) continue;
      if(S_ISDIR(st.st_mode) ? !arquivos_pasta_de_jogo(caminho) : !(S_ISREG(st.st_mode) && candidato(e->d_name))) continue;
      if(!S_ISDIR(st.st_mode) && em_download(pastas[i], e->d_name)) continue;
      info_jogo_t info;
      char formato[16];
      if(jogo_local(caminho, icones, &info, formato, sizeof formato) || !tid_ok(info.title_id)) continue;
      int ps5 = !strncmp(info.title_id, "PPSA", 4);
      buf_str(b, n++ ? ",{\"titleId\":" : "{\"titleId\":");
      buf_json(b, info.title_id);
      buf_str(b, ",\"nome\":");
      buf_json(b, info.nome);
      buf_str(b, ",\"plataforma\":");
      buf_json(b, ps5 ? "PS5" : !strncmp(info.title_id, "CUSA", 4) ? "PS4" : "");
      buf_str(b, ",\"versao_local\":");
      buf_json(b, info.versao);
      buf_str(b, ",\"fw_local\":");
      buf_json(b, info.fw_minimo);
      if(ps5 && info.version_uri[0]) {   /* PS4 usa outro esquema (com chave): fica so com a versao local */
        buf_str(b, ",\"versionJsonUri\":");
        buf_json(b, info.version_uri);
      }
      buf_str(b, ",\"caminho\":");
      buf_json(b, caminho);
      buf_str(b, "}");
    }
    closedir(d);
  }
  buf_str(b, "]");
}

/* ------------------------------------------------------------------ rotas */

void versoes_rota_listar(pedido_t *p) {
  char so[4] = "", fw[16];
  param(p->query, "resultados", 0, so, sizeof so);
  payloads_firmware(fw, sizeof fw);
  buf_t b = {0};
  buf_str(&b, "{\"ok\":true,\"fw_console\":");
  buf_json(&b, fw);
  if(strcmp(so, "1")) {
    buf_str(&b, ",\"jogos\":");
    listar_jogos(&b);
  }
  buf_str(&b, ",\"resultados\":");
  pthread_mutex_lock(&g_trava);
  carregar();
  resultados_json(&b);
  pthread_mutex_unlock(&g_trava);
  buf_str(&b, "}");
  responder_json(p, 200, &b);
  buf_free(&b);
}

void versoes_rota_gravar(pedido_t *p) {
  if(!p->corpo || !p->corpo_n) {
    responder_erro(p, 400, "requisicao_invalida", "corpo vazio", NULL);
    return;
  }
  js_t raiz = {p->corpo, p->corpo + p->corpo_n}, lista;
  if(!js_campo(&raiz, "resultados", &lista)) {
    responder_erro(p, 400, "requisicao_invalida", "falta \"resultados\"", NULL);
    return;
  }
  resultado_t *novos = calloc(MAX_RESULTADOS, sizeof *novos);
  if(!novos) {
    responder_erro(p, 500, "memoria", "sem memoria", NULL);
    return;
  }
  leitura_t l = {novos, 0, MAX_RESULTADOS, 0};
  if(js_cada(&lista, ler_cada, &l) < 0) {
    free(novos);
    responder_erro(p, 400, "requisicao_invalida", "JSON invalido", NULL);
    return;
  }
  long long agora = (long long)time(NULL);
  pthread_mutex_lock(&g_trava);
  carregar();
  int gravados = 0, erro = !g_res;
  for(int i = 0; !erro && i < l.n; i++) {
    resultado_t *r = &novos[i];
    if(r->consultado_em <= 0) r->consultado_em = agora;
    int k = 0;
    while(k < g_n && strcmp(g_res[k].tid, r->tid)) k++;
    if(k == g_n) {
      if(g_n >= MAX_RESULTADOS) {
        l.recusados++;
        continue;
      }
      g_n++;
    }
    g_res[k] = *r;
    gravados++;
  }
  if(!erro && gravados) erro = gravar();
  pthread_mutex_unlock(&g_trava);
  free(novos);
  if(erro) {
    responder_erro(p, 500, "gravar", "nao foi possivel gravar versoes.json", NULL);
    return;
  }
  diario("versoes: %d resultado(s) do celular/PC guardado(s), %d recusado(s)", gravados, l.recusados);
  buf_t b = {0};
  buf_fmt(&b, "{\"ok\":true,\"gravados\":%d,\"recusados\":%d}", gravados, l.recusados);
  responder_json(p, 200, &b);
  buf_free(&b);
}
