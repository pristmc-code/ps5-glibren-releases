/* Game Library Renamer (payload PS5) - atualizacao pelo proprio PS5 (versoes assinadas, repositorio publico). */
#pragma once

#include <stddef.h>
#include "util.h"

/* {"atual","nova","notas","fase","erro","rodando"}; forcar = consulta o GitHub agora (senao, a cada 15 min). */
void atualizacao_estado(buf_t *json, int forcar);
/* Logo ao iniciar: se ha uma versao mais nova gravada pela atualizacao (assinatura valida), envia ela ao elfldr.
   1 = passou a vez (esta copia deve sair). */
int atualizacao_ao_iniciar(void);
/* Baixa, confere a assinatura, grava e reinicia pela versao nova. 0 = iniciou. */
int atualizacao_iniciar(char *msg, size_t tam);
/* 0.9.41 (revisao): versao do marcador "GLIBREN-VERSAO:<versao>\n" dentro de um .elf ("" = nao e o glibren) */
void atualizacao_versao_elf(const void *d, size_t n, char *saida, size_t tam);
