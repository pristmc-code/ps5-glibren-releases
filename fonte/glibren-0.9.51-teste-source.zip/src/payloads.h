/* Game Library Renamer (payload PS5) - payloads de terceiros para teste (0.9.20).

Catalogo FIXO no codigo (payloads.c), so com payloads conferidos por nos: cada item tem a URL do asset da release no
GitHub, o tamanho e o SHA-256 fixados (baixados e calculados por quem publicou o glibren). Ativar = baixar pelo cliente
HTTPS do glibren (DNS robusto), recusar se o SHA-256 nao bater, guardar em /data/glibren/payloads/ e enviar ao elfldr
(127.0.0.1:9021), lendo a saida do payload pelo mesmo socket (o elfldr liga o stdout do payload a conexao). */
#pragma once

#include "http.h"

/* GET /api/payloads: {"ok","firmware","ocupado","itens":[...]} (leitura livre) */
void payloads_rota_estado(pedido_t *p);
/* 0.9.21: o mesmo JSON, num buffer (diagnostico) */
void payloads_json(buf_t *b);
/* "12.00" (vazio = nao sabe) */
void payloads_firmware(char *saida, size_t tam);
/* POST /api/payloads/baixar e /api/payloads/ativar (id, reabrir): pareamento + X-GLR ja conferidos pelo api.c.
   Recusa o navegador do PS5 e outros programas do proprio PS5, menos o item de tela cheia aberto pelo navegador do PS5. */
void payloads_rota_acao(pedido_t *p, int ativar);
/* POST /api/navegador/abrir (destino): 0.9.24 - abre o navegador do PS5 numa pagina da lista fixa (Jobe web /app,
   Jobe /teste, glibren), com o mesmo mecanismo do item de tela cheia (tela inicial e sceSystemServiceLaunchWebBrowser).
   Pareamento + X-GLR ja conferidos pelo api.c; so do celular/PC (o navegador do PS5 tem os atalhos na propria tela);
   recusa com jogo/app aberto. */
void payloads_rota_navegador(pedido_t *p);
/* 1 = baixando ou ativando agora (a atualizacao do glibren espera). */
int payloads_ocupado(void);
/* 0.9.33: POST /api/payloads/voltar (id): troca a versao instalada pela anterior guardada (itens acompanhados pelo
   GitHub). Mesmas regras do baixar (pareamento + X-GLR, so celular/PC). */
void payloads_rota_voltar(pedido_t *p);
/* 0.9.34: POST /api/payloads/remover (id): apaga o que esta guardado de um item acompanhado pelo GitHub. */
void payloads_rota_remover(pedido_t *p);
/* 0.9.33: POST /api/payloads/procurar (forcar): consulta a ultima release dos itens acompanhados pelo GitHub numa
   thread. Sem forcar: so os com cache de mais de 1 h (abrir a pagina); forcar = botao, no maximo 1 vez por minuto. */
void payloads_rota_procurar(pedido_t *p);
/* 0.9.41: carregar ao iniciar o glibren: uma thread (uma vez por glibren) manda ao elfldr os itens marcados que estao
   instalados e NAO estao rodando, um por vez, na ordem kstuff -> montador (ShadowKraken ou kraken-mount) -> os outros.
   Por item: espera a porta 9021 aceitar conexao (prazo de 60 s no relogio monotonico), pega a vez (nada da pagina no
   meio), le e confere o SHA-256 uma vez e, logo antes de cada envio, confere de novo que nao esta rodando (kstuff: sonda
   dizendo claramente "nao carregado" e sem o marcador deste boot; o marcador e gravado uma vez antes do envio). */
void payloads_autoload_iniciar(void);
/* 0.9.41: POST /api/payloads/autoload (id, ligado = 1|0): a chave "Carregar ao iniciar o glibren" por item (config.ini
   payload_autoload). Pode: Dump Forge, BlueV, MemDBG, kraken-mount ou ShadowKraken (um montador so: ligar um desliga o
   outro, "desligou" = o nome dele) e o kstuff (regras proprias acima). Nao pode (400 payload_autoload_proibido): os que
   mexem na interface do PS5 (tela cheia, PrefBar, ZhiThemes) e os sem sonda de "rodando agora". Pareamento + X-GLR, so
   celular/PC. */
void payloads_rota_autoload(pedido_t *p);
/* 0.9.41: GET /api/payloads/arquivos?id= (pareamento; o proprio PS5 passa): todos os .elf da pasta do ps5-payload-manager
   (/data/pldmgr/payloads, primeiro) e dos discos do PS5; os com o nome do item (shadowkraken, kstuff) primeiro e so eles
   lidos inteiros (versao, SHA-256, comparacao com o instalado); os outros so com a conferencia barata. Uma busca por vez
   (a segunda: 409 payload_busca_ocupada). */
void payloads_rota_arquivos(pedido_t *p);
/* 0.9.41: POST /api/payloads/arquivo (id, caminho): "Instalar de arquivo" - copia o .elf para a pasta de payloads do
   glibren (SHA-256 no .info, conferido antes de cada carga). Recusa o proprio glibren (marcador GLIBREN-VERSAO) e, no
   ShadowKraken, ELF sem o marcador de versao dele. Pareamento + X-GLR, so celular/PC. */
void payloads_rota_arquivo(pedido_t *p);
/* 0.9.51: 1 = caminho absoluto num disco do PS5 (as mesmas raizes do "Instalar de arquivo"), sem links nem "..", fora
   da pasta de payloads do glibren. Usado pelo build de teste do ampr-emu-ng (ampr_teste.c). */
int payloads_caminho_de_disco(const char *origem);
/* 0.9.45: POST /api/payloads/enviar?id=&nome= (corpo = o .elf, ate 40 MB): "Enviar do celular/PC", mesmas regras e
   conferencias do payloads_rota_arquivo. */
void payloads_rota_enviar(pedido_t *p);
