/* Game Library Renamer (payload PS5) - 0.9.33: ultima release de um repositorio do GitHub (API publica, sem token).

So le o necessario do JSON: tag_name, prerelease, draft, published_at e, dos assets, name, size e digest
("sha256:<hex>", que a API do GitHub calcula para cada asset). O asset certo e o UNICO cujo nome casa com o padrao
do item ("*" = qualquer sequencia). Sem token: a API aceita 60 pedidos por hora por IP; o glibren se limita a
GH_MAX_POR_HORA e, depois de um 403/429, nao pergunta nada por GH_PAUSA_LIMITE segundos.
Testes no PC: GLR_TESTE_GH=http://127.0.0.1:PORTA (no lugar de https://api.github.com e https://github.com/; precisa
de GLR_TESTE_BASE com o mesmo inicio). */
#pragma once

#include <stddef.h>

#define GH_MAX_POR_HORA 30
#define GH_PAUSA_LIMITE (30 * 60)

typedef struct {
  char tag[64];
  int pre;                    /* pre-release ("experimental") */
  char publicado[24];         /* published_at (ISO) */
  char asset[128];
  char sha256[65];            /* "" = a API nao trouxe o digest */
  unsigned long long tamanho;
} gh_release_t;

/* Resultado de gh_consultar */
enum {
  GH_OK = 0,
  GH_REDE = -1,          /* sem conexao */
  GH_HTTP = -2,          /* status diferente de 200 (http recebe o status) */
  GH_LIMITE = -3,        /* 403/429 ou limite proprio do glibren: espere */
  GH_JSON = -4,          /* resposta que nao deu para ler */
  GH_SEM_RELEASE = -5,
  GH_SEM_ASSET = -6,     /* nenhum asset casa com o padrao */
  GH_VARIOS_ASSETS = -7, /* mais de um casa: ambiguo, recusado */
  GH_REPO_SUMIU = -8,    /* 0.9.34: o repositorio responde 404 (removido ou privado) */
};

/* repo "dono/nome"; incluir_pre = 1 pega a mais nova da lista (inclusive pre-release), 0 = /releases/latest.
   http recebe o status HTTP (ou -1). */
int gh_consultar(const char *repo, int incluir_pre, const char *padrao, gh_release_t *r, int *http);
/* URL do asset (https://github.com/<repo>/releases/download/<tag>/<asset>) */
void gh_url_asset(const char *repo, const gh_release_t *r, char *saida, size_t tam);
/* Hora (time_t) ate quando nao pergunta nada (0 = livre) */
long long gh_bloqueado_ate(void);
/* 0.9.39: hora (time_t) em que o glibren volta a perguntar (pausa de 403/429 ou limite proprio de GH_MAX_POR_HORA por
   hora); 0 = livre agora */
long long gh_livre_em(void);
/* "*" = qualquer sequencia; o resto, igual (diferencia maiusculas) */
int gh_casa(const char *padrao, const char *nome);
/* 1 = so letras, numeros e . _ - + (tag e nome de asset) */
int gh_nome_ok(const char *s, size_t max);
