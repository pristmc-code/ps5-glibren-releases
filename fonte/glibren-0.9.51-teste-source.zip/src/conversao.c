/* Game Library Renamer (payload PS5) - 0.9.30: conversao de formato pelo ps5-dump-forge. Ver conversao.h.

Regras:
  - so arquivos/pastas DENTRO das pastas da lista (config_pasta_permitida), nome simples, origem que existe;
  - origem aceita (a mesma do Dump Forge v0.5.6): pasta de jogo, .exfat, .ffpkg, .ffpfs, .ffpfsc, .pkg, .zip, .7z, .rar
    (0.9.31: pasta so com eboot.bin + sce_sys/param.json ou param.sfo; RAR em volumes so o .part1.rar);
    (".complete" no fim = download terminado: sai antes de olhar a extensao);
  - mesmo formato da origem = recusado; destino que ja existe (ou que outra conversao nossa ainda vai criar) = recusado;
  - delete_source nunca vai no pedido: o Dump Forge nunca apaga a origem;
  - 0.9.36: terminou bem ("feito") e a saida conferida (existe; arquivo com tamanho > 0; pasta de jogo com eboot.bin +
    sce_sys), o original vai para <disco>/BACKUP/<jogo>/ (backup.c: o mesmo lugar e marcador da Jobe), se a opcao
    convert_backup estiver ligada (padrao) na hora em que a conversao termina. Falhou/cancelou/parou: nada se move. Outra
    conversao do mesmo original ainda rodando: espera ela terminar. Nao moveu (montado, jogo aberto, ShadowMount+ sem
    resposta, erro do disco): o original fica e a tela mostra o motivo + "Mover agora" (POST /api/conversao/backup);
  - quem acompanha: a pagina (GET /api/conversao) e, com a pagina fechada, um vigia que consulta o Dump Forge a cada 5 s
    enquanto houver conversao andando (testes: GLR_TESTE_CONV_VIGIA_S, 0 = sem vigia);
  - o glibren guarda so os trabalhos que ELE pediu (id do Dump Forge + saida esperada); o estado vem do GET /api/jobs do
    Dump Forge, conferido pela saida (id igual com outra saida = o Dump Forge reiniciou, o trabalho se perdeu);
  - o ShadowMount+ acha sozinho a imagem nova nas pastas que ele monitora; depois de mover um original para o BACKUP o
    glibren pede a releitura (POST /api/v1/scan).
JSON do Dump Forge lido por um leitor minimo daqui (so o que precisa: id, request.output/install, progress.stage/done/total,
done.result.Ok/Err).

0.9.41: instalar .pkg pelo Dump Forge (POST /api/conversao/instalar, mesma lista e mesmo vigia das conversoes). Pedido ao
Dump Forge: POST /api/start_job {"request": {"source": "", "format": "folder", "output": "", "install": "<pkg>"}} (o
mesmo do InstallDialog.tsx da v0.5.6; source/output/format sao ignorados num trabalho de instalacao). O Dump Forge
serve o .pkg em 127.0.0.1 por HTTP Range para o instalador da Sony (sceAppInstUtilInstallByPackage); o trabalho
termina quando TODO byte foi servido (nao ve o fim da instalacao: isso fica nas notificacoes do PS5) ou com
"the PS5 refused the package: 0x80A3xxxx (...)". Regras daqui: so arquivo .pkg (cabecalho \x7FCNT = PS4, \x7FFIH/\x7FLIH =
PS5) dentro das pastas da lista; um por vez (o glibren guarda a fila, estado "espera", e so pede o proximo quando o
anterior terminou; nao gasta as 8 vagas do Dump Forge); o .pkg nunca e apagado nem movido (nada de BACKUP aqui).
Revisao da 0.9.41: a lista guarda ate MAX_CONV trabalhos e NUNCA descarta um ativo (espera/fila/rodando/cancelando):
sem vaga, o pedido e recusado com motivo "fila_cheia" (a conversao confere antes de pedir ao Dump Forge e, se encher no
meio, cancela o trabalho que acabou de pedir); .pkg que uma conversao ainda gera = "em_uso"; as conferencias da fila de
instalacao e a gravacao nela ficam sob a mesma trava; o Dump Forge so "fechou" (perdido) depois de 3 consultas seguidas
sem resposta, e a "espera" (job 0, ainda no glibren) nunca vira perdido.

0.9.48: tamanho do original e do convertido em cada conversao (tam_origem / tam_destino no GET /api/conversao; a pagina
mostra "Original: X" durante e "Original: X -> Convertido: Y (N% menor|maior)" no fim; o glibren.log leva os dois na
linha "feita"). Arquivo = lstat na hora; pasta = soma dos arquivos numa thread a parte (nao segura a pagina). O tamanho
final vem do arquivo de saida no disco, nao do "bytes" do Dump Forge. A lista passa a ser gravada em
<dados>/conversoes.json (escrita so quando muda) e relida ao iniciar: uma atualizacao do glibren no meio de uma conversao
nao perde mais a tarefa (o Dump Forge e outro processo e segue convertendo; o original ainda vai para o BACKUP no fim).
Trabalho de conversao que esta no Dump Forge e nao esta na lista (pedido por um glibren anterior a 0.9.48, que nao
gravava) e adotado ao iniciar, se origem e saida ficam nas pastas da lista (no PC so com GLR_TESTE_CONV_ADOTAR=1). */
#include "conversao.h"

#include <arpa/inet.h>
#include <dirent.h>
#include <errno.h>
#include <netinet/in.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#include "arquivos.h"
#include "backup.h"
#include "config.h"
#include "json_min.h"
#include "payloads.h"
#include "tarefas.h"
#include "plataforma.h"
#include "util.h"

#define PORTA_DF 8095
#define MAX_CONV 32
#define MAX_RESPOSTA (8u * 1024 * 1024)   /* /api/jobs traz ate 200 linhas de diario por trabalho */
#ifdef MSG_NOSIGNAL
#define SEM_SINAL MSG_NOSIGNAL
#else
#define SEM_SINAL 0
#endif

/* id glibren, sufixo da saida, formato do Dump Forge, o resto do pedido e a familia do nivel de compressao:
   'k' = kraken_level (.pkg), 'z' = zstd_level 1-22, 'c' = ffpfsc_level (zlib 0-9), 'l' = lz4_level (0 ou 3-12), 0 = sem.
   Nivel vazio = o padrao do Dump Forge (recomendado): o campo nem vai no pedido. 0.9.30: zstd tambem DENTRO das imagens
   (.exfat/.ffpkg/.ffpfs/.ffpfsc; .pkg nao), ids com "_zstd" (combinados com a Jobe). */
static const struct {
  const char *id, *sufixo, *formato, *extra;
  char familia;
} FORMATOS[] = {
  {"exfat", ".exfat", "exfat", "", 0},
  {"ffpkg", ".ffpkg", "ffpkg", "", 0},
  {"ffpfs", ".ffpfs", "ffpfs", "", 0},
  {"ffpfsc", ".ffpfsc", "ffpfsc", "", 'c'},
  {"pkg", ".pkg", "pkg", "", 'k'},
  {"pasta", "", "folder", "", 0},
  {"pasta_zstd", "-zstd", "folder", ",\"zstd_pack\":true", 'z'},
  {"pasta_lz4", "-lz4", "folder", ",\"lz4\":\"pack\"", 'l'},
  {"exfat_zstd", "-zstd.exfat", "exfat", ",\"zstd_pack\":true", 'z'},
  {"ffpkg_zstd", "-zstd.ffpkg", "ffpkg", ",\"zstd_pack\":true", 'z'},
  {"ffpfs_zstd", "-zstd.ffpfs", "ffpfs", ",\"zstd_pack\":true", 'z'},
  {"ffpfsc_zstd", "-zstd.ffpfsc", "ffpfsc", ",\"zstd_pack\":true", 'z'},
};
#define N_FORMATOS ((int)(sizeof FORMATOS / sizeof FORMATOS[0]))
static const char *const KRAKEN[] = {"fast", "balanced", "smallest", "stored"};

typedef struct {
  unsigned long long id;    /* 0.9.41: numero do glibren (a pagina cancela por ele; "espera" ainda nao tem job) */
  unsigned long long job;   /* numero do trabalho no Dump Forge (0 = ainda nao pedido) */
  char origem[1100], destino[1100];
  char formato[16], nivel[12];
  long long inicio;
  char estado[12];      /* espera (so instalacao), fila, rodando, cancelando, feito, erro, cancelado, perdido */
  int instalar;         /* 0.9.41: 1 = instalar o .pkg (destino vazio, formato "instalar") */
  char plataforma[4];   /* 0.9.41: "PS4" (\x7FCNT) ou "PS5" (\x7FFIH/\x7FLIH) pelo cabecalho do .pkg */
  char codigo[12];      /* 0.9.41: codigo de erro da Sony achado no texto ("0x80A30002") */
  char etapa[32];
  unsigned long long feitos, total, bytes;
  char erro[400];
  char base[512];       /* 0.9.36: nome do original sem extensao (reserva do nome da pasta no BACKUP) */
  char backup[12];      /* 0.9.36: "" (ainda nao terminou), esperando, movendo, movido, adiado, falhou, desligado */
  int forcar;           /* "Mover agora": move mesmo com a opcao desligada */
  backup_res_t bk;      /* motivo (chave/detalhe) ou a pasta no BACKUP */
  unsigned long long tam_origem, tam_destino;   /* 0.9.48: bytes no disco (0 = ainda nao medido) */
  int medir;            /* 0.9.48: 1 = falta medir a origem (pasta); 2 = falta medir a saida (pasta) */
  int tam_dito;         /* 0.9.48: os dois tamanhos ja foram para o glibren.log */
  int adotada;          /* 0.9.48: achada no Dump Forge ao iniciar (nao foi este glibren que pediu) */
} conv_t;

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static conv_t g_conv[MAX_CONV];
static int g_qtd;
static int g_movendo;   /* 0.9.36: o trabalho que move os originais para o BACKUP esta rodando */
static int g_vigia;     /* 0.9.36: o vigia (consulta o Dump Forge com a pagina fechada) esta rodando */
static unsigned long long g_seq;   /* 0.9.41: ultimo id do glibren */
static int g_enviando;  /* 0.9.41: uma instalacao da fila esta sendo pedida ao Dump Forge agora */
static int g_falhas_df; /* 0.9.41: consultas seguidas ao /api/jobs sem resposta (3 = o Dump Forge fechou) */
#define FALHAS_FECHOU 3
static int g_medindo;   /* 0.9.48: a thread que soma o tamanho das pastas esta rodando */
static pthread_mutex_t g_trava_arq = PTHREAD_MUTEX_INITIALIZER;   /* 0.9.48: conversoes.json */
static buf_t g_gravado; /* 0.9.48: o ultimo conteudo gravado (so grava de novo quando muda) */
static void salvar(void);
static void disparar_medidor(void);

static int achar_formato(const char *id) {
  for(int i = 0; i < N_FORMATOS; i++)
    if(!strcmp(FORMATOS[i].id, id)) return i;
  return -1;
}

int conversao_formato_valido(const char *id) { return achar_formato(id) >= 0; }

static int numero(const char *v, int min, int max) {
  if(!v[0] || strlen(v) > 2) return 0;
  for(const char *c = v; *c; c++)
    if(*c < '0' || *c > '9') return 0;
  int n = atoi(v);
  return n >= min && n <= max;
}

int conversao_nivel_valido(const char *formato, const char *nivel) {
  int f = achar_formato(formato);
  if(f < 0) return 0;
  if(!nivel[0]) return 1;   /* padrao do Dump Forge */
  switch(FORMATOS[f].familia) {
    case 'k':
      for(int i = 0; i < 4; i++)
        if(!strcmp(KRAKEN[i], nivel)) return 1;
      return 0;
    case 'z': return numero(nivel, 1, 22);
    case 'c': return numero(nivel, 0, 9);
    case 'l': return numero(nivel, 0, 12) && atoi(nivel) != 1 && atoi(nivel) != 2;
    default: return 0;
  }
}

/* o campo do nivel no pedido do Dump Forge ("" = nenhum) */
static void nivel_campo(int f, const char *nivel, buf_t *b) {
  if(!nivel[0]) return;
  switch(FORMATOS[f].familia) {
    case 'k': buf_fmt(b, ",\"kraken_level\":\"%s\"", nivel); break;
    case 'z': buf_fmt(b, ",\"zstd_level\":%d", atoi(nivel)); break;
    case 'c': buf_fmt(b, ",\"ffpfsc_level\":%d", atoi(nivel)); break;
    case 'l': buf_fmt(b, ",\"lz4_level\":%d", atoi(nivel)); break;
  }
}

static int final(const char *estado) {
  return !strcmp(estado, "feito") || !strcmp(estado, "erro") || !strcmp(estado, "cancelado") || !strcmp(estado, "perdido");
}

/* 0.9.36: terminou mas o original ainda vai (ou esta indo) para o BACKUP */
static int pendente(const conv_t *c) { return !strcmp(c->backup, "esperando") || !strcmp(c->backup, "movendo"); }

/* ------------------------------------------------------------------ 0.9.48: tamanho do original e do convertido */

/* Soma dos arquivos de uma pasta (sem seguir link; ate 24 niveis). */
static unsigned long long somar_pasta(const char *pasta, int nivel) {
  unsigned long long soma = 0;
  DIR *d = nivel < 24 ? opendir(pasta) : NULL;
  if(!d) return 0;
  struct dirent *e;
  while((e = readdir(d)) != NULL) {
    if(!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
    char c[1400];
    if(snprintf(c, sizeof c, "%s/%s", pasta, e->d_name) >= (int)sizeof c) continue;
    struct stat st;
    if(lstat(c, &st)) continue;
    if(S_ISDIR(st.st_mode)) soma += somar_pasta(c, nivel + 1);
    else if(S_ISREG(st.st_mode)) soma += (unsigned long long)st.st_size;
  }
  closedir(d);
  return soma;
}

/* "35% menor", "12% maior", "0.4% menor" (menos de 1% = uma casa) ou "mesmo tamanho"; o glibren.log e sem acento. */
static void texto_diferenca(unsigned long long origem, unsigned long long destino, char *saida, size_t tam) {
  if(!origem || origem == destino) {
    snprintf(saida, tam, "mesmo tamanho");
    return;
  }
  unsigned long long dif = destino > origem ? destino - origem : origem - destino;
  double p = (double)dif * 100.0 / (double)origem;
  const char *lado = destino > origem ? "maior" : "menor";
  if(p >= 1.0) snprintf(saida, tam, "%.0f%% %s", p, lado);
  else snprintf(saida, tam, "%.1f%% %s", p < 0.1 ? 0.1 : p, lado);
}

/* Os dois tamanhos no glibren.log, uma vez (chamar com a trava; so quando os dois ja sao conhecidos). */
static void dizer_tamanhos_trava(conv_t *c) {
  if(c->tam_dito || c->instalar || strcmp(c->estado, "feito") || !c->tam_origem || !c->tam_destino) return;
  char dif[40];
  texto_diferenca(c->tam_origem, c->tam_destino, dif, sizeof dif);
  c->tam_dito = 1;
  diario("conversao: %llu: tamanhos: original %llu bytes -> convertido %llu bytes (%s)", c->job, c->tam_origem, c->tam_destino, dif);
}

/* Soma as pastas pendentes (origem e/ou saida), uma por vez e fora da trava: pasta grande leva segundos. */
static void *medidor(void *arg) {
  (void)arg;
  for(;;) {
    pthread_mutex_lock(&g_trava);
    int i;
    for(i = 0; i < g_qtd; i++)
      if(g_conv[i].medir) break;
    if(i == g_qtd) {
      g_medindo = 0;
      pthread_mutex_unlock(&g_trava);
      break;
    }
    unsigned long long id = g_conv[i].id;
    int qual = (g_conv[i].medir & 1) ? 1 : 2;
    char caminho[1100];
    snprintf(caminho, sizeof caminho, "%s", qual == 1 ? g_conv[i].origem : g_conv[i].destino);
    pthread_mutex_unlock(&g_trava);

    struct stat st;
    unsigned long long tam = 0;
    if(!lstat(caminho, &st)) tam = S_ISDIR(st.st_mode) ? somar_pasta(caminho, 0) : S_ISREG(st.st_mode) ? (unsigned long long)st.st_size : 0;

    pthread_mutex_lock(&g_trava);
    for(i = 0; i < g_qtd; i++)
      if(g_conv[i].id == id) {
        g_conv[i].medir &= ~qual;
        if(qual == 1) g_conv[i].tam_origem = tam;
        else g_conv[i].tam_destino = tam;
        dizer_tamanhos_trava(&g_conv[i]);
      }
    pthread_mutex_unlock(&g_trava);
  }
  salvar();
  return NULL;
}

static void disparar_medidor(void) {
  pthread_mutex_lock(&g_trava);
  int ha = 0;
  for(int i = 0; i < g_qtd && !ha; i++) ha = g_conv[i].medir != 0;
  if(ha && !g_medindo) {
    g_medindo = 1;
    if(criar_thread(medidor, NULL, NULL)) g_medindo = 0;
  }
  pthread_mutex_unlock(&g_trava);
}

/* ------------------------------------------------------------------ cliente HTTP do Dump Forge */

static int porta_df(void) {
  const char *v = getenv("GLR_TESTE_DUMPFORGE_PORTA");
  int n = v ? atoi(v) : 0;
  return n > 0 && n < 65536 ? n : PORTA_DF;
}

/* Um pedido (o Dump Forge atende um por conexao e fecha). Devolve o status HTTP, ou -1 se nao conectou / nao respondeu.
   O corpo da resposta vai para resp (sem o cabecalho). */
static int df_pedir(const char *metodo, const char *rota, const char *corpo, buf_t *resp, int espera_s) {
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if(fd < 0) return -1;
  struct timeval t = {.tv_sec = espera_s};
  setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &t, sizeof t);
  setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &t, sizeof t);
#ifdef SO_NOSIGPIPE
  int sim = 1;
  setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &sim, sizeof sim);
#endif
  struct sockaddr_in end = {.sin_family = AF_INET, .sin_port = htons((uint16_t)porta_df())};
  end.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  if(connect(fd, (struct sockaddr *)&end, sizeof end)) {
    close(fd);
    return -1;
  }
  buf_t pedido = {0};
  size_t n = corpo ? strlen(corpo) : 0;
  buf_fmt(&pedido, "%s %s HTTP/1.1\r\nHost: 127.0.0.1:%d\r\nConnection: close\r\n", metodo, rota, porta_df());
  if(corpo) buf_fmt(&pedido, "Content-Type: application/json\r\nContent-Length: %zu\r\n", n);
  buf_str(&pedido, "\r\n");
  if(corpo) buf_add(&pedido, corpo, n);
  int ok = 1;
  for(size_t feitos = 0; ok && feitos < pedido.n;) {
    ssize_t r = send(fd, pedido.d + feitos, pedido.n - feitos, SEM_SINAL);
    if(r <= 0) ok = 0;
    else feitos += (size_t)r;
  }
  buf_free(&pedido);
  buf_t tudo = {0};
  char bloco[16384];
  while(ok) {
    ssize_t r = recv(fd, bloco, sizeof bloco, 0);
    if(r <= 0) break;
    if(tudo.n + (size_t)r > MAX_RESPOSTA) {
      ok = 0;
      break;
    }
    buf_add(&tudo, bloco, (size_t)r);
  }
  close(fd);
  int status = -1;
  if(ok && tudo.n > 12 && !strncmp(tudo.d, "HTTP/1.", 7)) {
    buf_add(&tudo, "", 1);   /* termina em \0 */
    status = atoi(tudo.d + 9);
    const char *c = strstr(tudo.d, "\r\n\r\n");
    if(c) buf_str(resp, c + 4);
    else status = -1;
  }
  buf_free(&tudo);
  return status > 0 ? status : -1;
}

int conversao_dumpforge_no_ar(void) {
  buf_t r = {0};
  int st = df_pedir("GET", "/api/session", NULL, &r, 2);
  buf_free(&r);
  return st == 200;
}

int conversao_dumpforge_versao(char *versao, size_t tam) {
  buf_t r = {0};
  versao[0] = 0;
  int st = df_pedir("GET", "/api/session", NULL, &r, 2);
  if(st == 200 && r.d) {
    buf_add(&r, "", 1);
    const char *v = strstr(r.d, "\"version\"");
    v = v ? strchr(v + 9, '"') : NULL;
    size_t k = 0;
    if(v)
      for(v++; *v && *v != '"' && k + 1 < tam; v++)
        if(strchr("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.-+_", *v)) versao[k++] = *v;
    versao[k] = 0;
  }
  buf_free(&r);
  return st == 200;
}

/* Texto de {"error": "..."} (ou o corpo inteiro, cortado). */
static void erro_df(const buf_t *r, char *saida, size_t tam) {
  saida[0] = 0;
  if(!r->d) return;
  js_t j = {r->d, r->d + r->n}, v;
  if(js_campo(&j, "error", &v) && !js_string(&v, saida, tam)) return;
  snprintf(saida, tam, "%.*s", (int)(r->n < 200 ? r->n : 200), r->d);
}

/* 0.9.41: o primeiro "0x" + 8 hexadecimais do texto ("the PS5 refused the package: 0x80A30002 (...)") -> "0x80A30002" */
static void achar_codigo(const char *texto, char *saida, size_t tam) {
  saida[0] = 0;
  for(const char *p = texto; (p = strstr(p, "0x")) != NULL; p += 2) {
    int n = 0;
    while(n < 8 && strchr("0123456789abcdefABCDEF", p[2 + n]) && p[2 + n]) n++;
    if(n == 8 && !(p[10] && strchr("0123456789abcdefABCDEF", p[10]))) {
      snprintf(saida, tam, "0x");
      for(int i = 0; i < 8 && 2 + i + 1 < (int)tam; i++) {
        char ch = p[2 + i];
        saida[2 + i] = (char)(ch >= 'a' && ch <= 'f' ? ch - 32 : ch);
        saida[3 + i] = 0;
      }
      return;
    }
  }
}

/* ------------------------------------------------------------------ estado */

/* 0.9.41: o Dump Forge nao respondeu ao /api/jobs. Uma demora nao derruba a fila: so na 3a falha seguida os trabalhos
   que ESTAO no Dump Forge (job != 0) viram "perdido"; os que ainda esperam a vez no glibren ("espera", job 0) ficam na
   fila para quando ele voltar. Chamar com a trava. */
static void falhou_df(void) {
  if(++g_falhas_df < FALHAS_FECHOU) return;
  for(int i = 0; i < g_qtd; i++)
    if(g_conv[i].job && !final(g_conv[i].estado)) {
      snprintf(g_conv[i].estado, sizeof g_conv[i].estado, "perdido");
      snprintf(g_conv[i].erro, sizeof g_conv[i].erro, "o Dump Forge fechou: a %s parou", g_conv[i].instalar ? "instalacao" : "conversao");
      diario("%s: %llu perdida: o Dump Forge nao respondeu %d vezes seguidas", g_conv[i].instalar ? "instalacao" : "conversao",
             g_conv[i].job, g_falhas_df);
    }
}

/* Atualiza os nossos trabalhos pelo /api/jobs. Devolve 1 se o Dump Forge respondeu. */
static int atualizar(void) {
  buf_t r = {0};
  int st = df_pedir("GET", "/api/jobs", NULL, &r, 4);
  if(st != 200 || !r.d) {
    buf_free(&r);
    pthread_mutex_lock(&g_trava);
    falhou_df();
    pthread_mutex_unlock(&g_trava);
    return 0;
  }
  pthread_mutex_lock(&g_trava);
  g_falhas_df = 0;
  pthread_mutex_unlock(&g_trava);
  js_t raiz = {r.d, r.d + r.n}, lista;
  int achou[MAX_CONV] = {0};
  if(js_campo(&raiz, "jobs", &lista)) {
    js_t j = lista;
    js_esp(&j);
    if(j.p < j.fim && *j.p == '[') {
      j.p++;
      js_esp(&j);
      while(j.p < j.fim && *j.p == '{') {
        js_t item = j, v, req, out;
        if(js_pular(&j, 1)) break;
        item.fim = j.p;
        unsigned long long id = js_campo(&item, "id", &v) ? js_num(&v) : 0;
        char saida[1100] = "", inst[1100] = "";
        if(js_campo(&item, "request", &req)) {
          if(js_campo(&req, "output", &out)) js_string(&out, saida, sizeof saida);
          js_t ins;   /* 0.9.41: trabalho de instalacao: o .pkg vem em request.install */
          if(js_campo(&req, "install", &ins) && !js_nulo(&ins)) js_string(&ins, inst, sizeof inst);
        }
        pthread_mutex_lock(&g_trava);
        for(int i = 0; i < g_qtd; i++) {
          conv_t *c = &g_conv[i];
          if(!c->job || c->job != id || final(c->estado)) continue;
          if(c->instalar ? strcmp(c->origem, inst) : (inst[0] || strcmp(c->destino, saida))) continue;
          achou[i] = 1;
          js_t prog, done, res, x;
          if(js_campo(&item, "progress", &prog) && !js_nulo(&prog)) {
            if(js_campo(&prog, "stage", &x)) js_string(&x, c->etapa, sizeof c->etapa);
            if(js_campo(&prog, "done", &x)) c->feitos = js_num(&x);
            if(js_campo(&prog, "total", &x)) c->total = js_num(&x);
            if(strcmp(c->estado, "cancelando")) snprintf(c->estado, sizeof c->estado, "rodando");
          }
          if(js_campo(&item, "done", &done) && !js_nulo(&done) && js_campo(&done, "result", &res)) {
            js_t ok, err;
            if(js_campo(&res, "Ok", &ok)) {
              snprintf(c->estado, sizeof c->estado, "feito");
              if(js_campo(&ok, "bytes", &x)) c->bytes = js_num(&x);
              c->feitos = c->total ? c->total : c->feitos;
              if(c->instalar) {   /* 0.9.41: todo byte servido; o fim da instalacao so o PS5 ve. O .pkg fica onde esta. */
                diario("instalacao: %llu entregue ao instalador do PS5: %s", c->job, c->origem);
              } else {
                /* 0.9.48: o tamanho final e o do arquivo no disco; pasta de saida e somada pelo medidor */
                struct stat sd;
                if(!lstat(c->destino, &sd) && S_ISREG(sd.st_mode)) c->tam_destino = (unsigned long long)sd.st_size;
                else if(!c->tam_destino) c->medir |= 2;
                if(c->tam_origem && c->tam_destino) {
                  char dif[40];
                  texto_diferenca(c->tam_origem, c->tam_destino, dif, sizeof dif);
                  c->tam_dito = 1;
                  diario("conversao: %llu feita: %s (original %llu bytes -> convertido %llu bytes, %s)", c->job, c->destino,
                         c->tam_origem, c->tam_destino, dif);
                } else {
                  diario("conversao: %llu feita: %s", c->job, c->destino);
                }
                /* 0.9.36: a opcao vale na hora em que termina */
                /* 0.9.48: adotada = o original fica (pode ter sido pedida por outro programa); a tela oferece "Mover agora" */
                snprintf(c->backup, sizeof c->backup, "%s", config_conversao_mover() && !c->adotada && !backup_dentro(c->origem) ? "esperando" : "desligado");   /* 0.9.49: original que ja esta no BACKUP fica */
              }
            } else if(js_campo(&res, "Err", &err)) {
              js_string(&err, c->erro, sizeof c->erro);
              snprintf(c->estado, sizeof c->estado, "%s", !strncmp(c->erro, "cancelled", 9) ? "cancelado" : "erro");
              achar_codigo(c->erro, c->codigo, sizeof c->codigo);
              diario("%s: %llu %s: %s", c->instalar ? "instalacao" : "conversao", c->job, c->estado, c->erro);
            }
          }
        }
        pthread_mutex_unlock(&g_trava);
        js_esp(&j);
        if(j.p < j.fim && *j.p == ',') {
          j.p++;
          js_esp(&j);
        }
      }
    }
  }
  /* nosso trabalho sumiu da lista do Dump Forge: ele reiniciou (a lista e so da memoria dele) */
  pthread_mutex_lock(&g_trava);
  for(int i = 0; i < g_qtd; i++)
    if(!achou[i] && g_conv[i].job && !final(g_conv[i].estado) && time(NULL) - g_conv[i].inicio > 3) {
      snprintf(g_conv[i].estado, sizeof g_conv[i].estado, "perdido");
      snprintf(g_conv[i].erro, sizeof g_conv[i].erro, "o Dump Forge reiniciou ou fechou: a %s parou",
               g_conv[i].instalar ? "instalacao" : "conversao");
    }
  pthread_mutex_unlock(&g_trava);
  buf_free(&r);
  disparar_medidor();   /* 0.9.48: saida em pasta = soma numa thread */
  salvar();
  return 1;
}

/* ------------------------------------------------------------------ 0.9.36: original para o BACKUP */

/* 1 = outra conversao do mesmo original ainda le dele */
static int origem_em_uso(const conv_t *c) {
  for(int i = 0; i < g_qtd; i++)
    if(&g_conv[i] != c && !final(g_conv[i].estado) && !strcmp(g_conv[i].origem, c->origem)) return 1;
  return 0;
}

/* A saida existe e serve: arquivo com tamanho > 0; pasta de jogo (eboot.bin + sce_sys/param). "" = ok. */
static const char *conferir_saida(const char *destino) {
  struct stat st;
  if(lstat(destino, &st)) return "saida_sumiu";
  if(S_ISDIR(st.st_mode)) return arquivos_pasta_de_jogo(destino) ? "" : "saida_invalida";
  if(!S_ISREG(st.st_mode)) return "saida_invalida";
  return st.st_size > 0 ? "" : "saida_vazia";
}

/* Um trabalho so: move, um por vez, os originais das conversoes "esperando" (rename + conversa com o SMP leva alguns
   segundos: nada disso fica com a trava). */
static void *mover_originais(void *arg) {
  (void)arg;
  for(;;) {
    pthread_mutex_lock(&g_trava);
    int i;
    for(i = 0; i < g_qtd; i++)
      if(!strcmp(g_conv[i].backup, "esperando") && !origem_em_uso(&g_conv[i])) break;
    if(i == g_qtd) {
      g_movendo = 0;
      pthread_mutex_unlock(&g_trava);
      return NULL;
    }
    conv_t c = g_conv[i];
    snprintf(g_conv[i].backup, sizeof g_conv[i].backup, "movendo");
    /* o mesmo original ja foi para o BACKUP por outra conversao dele (dois formatos do mesmo jogo) */
    backup_res_t r;
    memset(&r, 0, sizeof r);
    int ja_movido = 0;
    for(int k = 0; k < g_qtd; k++)
      if(k != i && !strcmp(g_conv[k].origem, c.origem) && !strcmp(g_conv[k].backup, "movido")) {
        r = g_conv[k].bk;
        ja_movido = 1;
      }
    pthread_mutex_unlock(&g_trava);

    const char *estado;
    const char *saida = conferir_saida(c.destino);
    if(ja_movido) estado = "movido";
    else if(!c.forcar && !config_conversao_mover()) estado = "desligado";
    else if(saida[0]) {
      snprintf(r.chave, sizeof r.chave, "%s", saida);
      estado = "falhou";
      diario("conversao: %llu: o original fica (%s: %s)", c.job, saida, c.destino);
    } else {
      int m = backup_mover(c.origem, c.destino, c.base, &r);
      estado = m == 0 ? "movido" : r.adiado ? "adiado" : "falhou";
      diario("conversao: %llu: original %s%s%s%s", c.job, estado, r.chave[0] ? " (" : "", r.chave, r.chave[0] ? ")" : "");
    }
    pthread_mutex_lock(&g_trava);
    for(int k = 0; k < g_qtd; k++)
      if(g_conv[k].job == c.job && !strcmp(g_conv[k].destino, c.destino)) {
        snprintf(g_conv[k].backup, sizeof g_conv[k].backup, "%s", estado);
        g_conv[k].bk = r;
        g_conv[k].forcar = 0;
      }
    pthread_mutex_unlock(&g_trava);
    salvar();
  }
}

static void disparar_mover(void) {
  pthread_mutex_lock(&g_trava);
  int ha = 0;
  for(int i = 0; i < g_qtd && !ha; i++) ha = !strcmp(g_conv[i].backup, "esperando") && !origem_em_uso(&g_conv[i]);
  if(ha && !g_movendo) {
    g_movendo = 1;
    if(criar_thread(mover_originais, NULL, NULL)) g_movendo = 0;
  }
  pthread_mutex_unlock(&g_trava);
}

/* ------------------------------------------------------------------ 0.9.41: fila de instalacao (um .pkg por vez) */

/* corpo do POST /api/start_job de uma instalacao (o mesmo installRequest() do InstallDialog.tsx do Dump Forge) */
static void corpo_instalar(const char *pkg, buf_t *b) {
  buf_str(b, "{\"request\":{\"source\":\"\",\"format\":\"folder\",\"output\":\"\",\"compression_threads\":null,\"inner\":null,"
             "\"remove_backport\":false,\"full_verify\":false,\"install\":");
  buf_json(b, pkg);
  buf_str(b, "}}");
  buf_add(b, "", 1);
}

/* Pede ao Dump Forge a proxima instalacao da fila, se nenhuma das nossas estiver no Dump Forge (fila/rodando/cancelando).
   Um de cada vez (g_enviando): a pagina e o vigia podem chamar juntos. */
static void disparar_instalacao(void) {
  pthread_mutex_lock(&g_trava);
  int i, ocupado = g_enviando;
  for(i = 0; i < g_qtd && !ocupado; i++) ocupado = g_conv[i].instalar && g_conv[i].job && !final(g_conv[i].estado);
  for(i = 0; i < g_qtd && !ocupado; i++)
    if(g_conv[i].instalar && !strcmp(g_conv[i].estado, "espera")) break;
  if(ocupado || i >= g_qtd) {
    pthread_mutex_unlock(&g_trava);
    return;
  }
  g_enviando = 1;
  unsigned long long id = g_conv[i].id;
  char pkg[1100];
  snprintf(pkg, sizeof pkg, "%s", g_conv[i].origem);
  pthread_mutex_unlock(&g_trava);

  buf_t corpo = {0}, resp = {0};
  corpo_instalar(pkg, &corpo);
  int st = df_pedir("POST", "/api/start_job", corpo.d, &resp, 20);
  buf_free(&corpo);
  unsigned long long job = 0;
  char erro[300] = "";
  if(st == 200 && resp.d && resp.n && resp.d[0] >= '0' && resp.d[0] <= '9') {
    buf_add(&resp, "", 1);
    job = strtoull(resp.d, NULL, 10);
  } else {
    erro_df(&resp, erro, sizeof erro);
    if(st < 0) snprintf(erro, sizeof erro, "o Dump Forge nao respondeu");
  }
  buf_free(&resp);

  pthread_mutex_lock(&g_trava);
  for(i = 0; i < g_qtd; i++) {
    conv_t *c = &g_conv[i];
    if(c->id != id) continue;
    c->inicio = (long long)time(NULL);
    if(!strcmp(c->estado, "espera") && job) {
      c->job = job;
      snprintf(c->estado, sizeof c->estado, "fila");
      diario("instalacao: %llu pedida: %s", job, c->origem);
    } else if(!strcmp(c->estado, "espera")) {
      snprintf(c->estado, sizeof c->estado, "erro");
      snprintf(c->erro, sizeof c->erro, "%s", erro);
      achar_codigo(c->erro, c->codigo, sizeof c->codigo);
      diario("instalacao: recusada pelo Dump Forge (%d): %s: %s", st, c->origem, erro);
    } else if(job) {   /* cancelada enquanto o pedido ia: cancela no Dump Forge tambem */
      c->job = job;
      char cj[64];
      snprintf(cj, sizeof cj, "{\"id\":%llu}", job);
      pthread_mutex_unlock(&g_trava);
      buf_t r = {0};
      df_pedir("POST", "/api/cancel_job", cj, &r, 5);
      buf_free(&r);
      pthread_mutex_lock(&g_trava);
    }
    break;
  }
  g_enviando = 0;
  pthread_mutex_unlock(&g_trava);
  salvar();
  /* recusada: a proxima da fila vai logo */
  if(!job) disparar_instalacao();
}

static int vigia_intervalo(void) {
#ifndef __PROSPERO__
  const char *v = getenv("GLR_TESTE_CONV_VIGIA_S");
  if(v) return atoi(v);
#endif
  return 5;
}

/* Com a pagina fechada ninguem pergunta ao Dump Forge: o vigia pergunta enquanto houver conversao andando, para o
   original ir para o BACKUP logo que ela terminar. */
static void *vigia(void *arg) {
  (void)arg;
  int s = vigia_intervalo();
  for(;;) {
    sleep((unsigned)s);
    pthread_mutex_lock(&g_trava);
    int ativos = 0;
    for(int i = 0; i < g_qtd; i++) ativos += !final(g_conv[i].estado);
    if(!ativos) g_vigia = 0;
    pthread_mutex_unlock(&g_trava);
    if(!ativos) break;
    /* 0.9.41: a proxima da fila, com a pagina fechada, so com o Dump Forge respondendo (sem ele a "espera" espera) */
    if(atualizar()) disparar_instalacao();
    disparar_mover();
  }
  disparar_mover();
  return NULL;
}

static void ligar_vigia(void) {
  if(vigia_intervalo() <= 0) return;
  pthread_mutex_lock(&g_trava);
  if(!g_vigia) {
    g_vigia = 1;
    if(criar_thread(vigia, NULL, NULL)) g_vigia = 0;
  }
  pthread_mutex_unlock(&g_trava);
}

void conversao_rota_estado(pedido_t *p) {
  pthread_mutex_lock(&g_trava);
  int ativos = 0;
  for(int i = 0; i < g_qtd; i++) ativos += !final(g_conv[i].estado);
  pthread_mutex_unlock(&g_trava);
  /* fora do ar com trabalhos: atualizar() conta as falhas seguidas (0.9.41: so na 3a o Dump Forge "fechou") */
  int no_ar = ativos ? atualizar() : conversao_dumpforge_no_ar();
  if(no_ar) disparar_instalacao();   /* 0.9.41 */
  disparar_mover();
  char formato[16], nivel[12], fw[16];
  config_conversao(formato, nivel);
  payloads_firmware(fw, sizeof fw);
  buf_t b = {0};
  buf_fmt(&b, "{\"ok\":true,\"no_ar\":%s,\"porta\":%d,\"mover\":%s,\"firmware\":", no_ar ? "true" : "false", porta_df(),
          config_conversao_mover() ? "true" : "false");
  buf_json(&b, fw);   /* 0.9.41: o aviso do .pkg de PS5 (FPKG) acima de 11.60 */
  buf_str(&b, ",\"padrao\":");
  buf_json(&b, formato);
  buf_str(&b, ",\"nivel\":");
  buf_json(&b, nivel);
  buf_str(&b, ",\"formatos\":[");
  for(int i = 0; i < N_FORMATOS; i++) {
    buf_str(&b, i ? "," : "");
    buf_json(&b, FORMATOS[i].id);
  }
  buf_str(&b, "],\"familias\":{");
  for(int i = 0; i < N_FORMATOS; i++)
    buf_fmt(&b, "%s\"%s\":\"%c\"", i ? "," : "", FORMATOS[i].id, FORMATOS[i].familia ? FORMATOS[i].familia : '-');
  buf_str(&b, "},\"itens\":[");
  pthread_mutex_lock(&g_trava);
  for(int i = g_qtd - 1; i >= 0; i--) {   /* mais novo primeiro */
    const conv_t *c = &g_conv[i];
    buf_fmt(&b, "%s{\"id\":%llu,\"job\":%llu,\"instalar\":%s,\"plataforma\":", i == g_qtd - 1 ? "" : ",", c->id, c->job,
            c->instalar ? "true" : "false");
    buf_json(&b, c->plataforma);
    buf_str(&b, ",\"codigo\":");
    buf_json(&b, c->codigo);
    buf_str(&b, ",\"origem\":");
    buf_json(&b, c->origem);
    buf_str(&b, ",\"destino\":");
    buf_json(&b, c->destino);
    buf_str(&b, ",\"formato\":");
    buf_json(&b, c->formato);
    buf_str(&b, ",\"nivel\":");
    buf_json(&b, c->nivel);
    buf_str(&b, ",\"estado\":");
    buf_json(&b, c->estado);
    buf_str(&b, ",\"etapa\":");
    buf_json(&b, c->etapa);
    buf_fmt(&b, ",\"feitos\":%llu,\"total\":%llu,\"bytes\":%llu,\"inicio\":%lld,\"erro\":", c->feitos, c->total, c->bytes, c->inicio);
    buf_json(&b, c->erro);
    buf_str(&b, ",\"backup\":");
    buf_json(&b, c->backup);
    buf_str(&b, ",\"bk_chave\":");
    buf_json(&b, c->bk.chave);
    buf_str(&b, ",\"bk_detalhe\":");
    buf_json(&b, c->bk.detalhe);
    buf_str(&b, ",\"bk_pasta\":");
    buf_json(&b, c->bk.pasta);
    buf_fmt(&b, ",\"tam_origem\":%llu,\"tam_destino\":%llu}", c->tam_origem, c->tam_destino);   /* 0.9.48 */
  }
  pthread_mutex_unlock(&g_trava);
  buf_str(&b, "]}");
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* ------------------------------------------------------------------ iniciar */

static int termina_com(const char *s, const char *fim) {
  size_t a = strlen(s), b = strlen(fim);
  return a > b && !strcasecmp(s + a - b, fim);
}

/* Nome base (sem ".complete" e sem a extensao de jogo/compactado) e formato da origem ("pasta", "exfat", ... ou
   "compactado"). 0 = origem aceita. */
static int origem_ler(const char *nome, int pasta, char *base, size_t tam, char *fmt, size_t tam_fmt) {
  snprintf(base, tam, "%s", nome);
  if(pasta) {
    /* pasta com packs zstd/LZ4 ja e "pasta_zstd"/"pasta_lz4" so pelo conteudo; o nome nao diz: conta como pasta */
    snprintf(fmt, tam_fmt, "pasta");
    return 0;
  }
  if(termina_com(base, ".complete")) base[strlen(base) - 9] = 0;
  static const char *const EXT[] = {".exfat", ".ffpkg", ".ffpfs", ".ffpfsc", ".pkg", ".zip", ".7z", ".rar", NULL};
  for(int i = 0; EXT[i]; i++)
    if(termina_com(base, EXT[i])) {
      base[strlen(base) - strlen(EXT[i])] = 0;
      snprintf(fmt, tam_fmt, "%s", i >= 5 ? "compactado" : EXT[i] + 1);
      /* 0.9.31: RAR em volumes ("x.part1.rar", "x.part2.rar"...): so o 1o volume; o nome novo fica sem ".part1" */
      char *pt = strrchr(base, '.');
      if(!strcmp(EXT[i], ".rar") && pt && !strncasecmp(pt, ".part", 5) && pt[5]) {
        const char *q = pt + 5;
        while(*q == '0') q++;
        int so_digitos = 1;
        for(const char *r = pt + 5; *r; r++) so_digitos &= *r >= '0' && *r <= '9';
        if(so_digitos) {
          if(strcmp(q, "1")) return -1;
          *pt = 0;
        }
      }
      return 0;
    }
  return -1;
}

static void recusa(buf_t *r, int *n, const char *nome, const char *motivo, const char *texto) {
  buf_str(r, (*n)++ ? ",{\"nome\":" : "{\"nome\":");
  buf_json(r, nome);
  buf_str(r, ",\"motivo\":");
  buf_json(r, motivo);
  buf_str(r, ",\"texto\":");
  buf_json(r, texto ? texto : "");
  buf_str(r, "}");
}

/* Vaga na lista (chamar com a trava): cheia, sai o terminado mais velho (sem original indo para o BACKUP). 0.9.41: nunca
   sai um ativo (espera/fila/rodando/cancelando: o trabalho ficaria orfao no Dump Forge) nem um "pendente": sem vaga = -1. */
static int vaga(void) {
  if(g_qtd < MAX_CONV) return 0;
  for(int i = 0; i < g_qtd; i++)
    if(final(g_conv[i].estado) && !pendente(&g_conv[i])) {
      memmove(&g_conv[i], &g_conv[i + 1], (size_t)(g_qtd - i - 1) * sizeof *g_conv);
      g_qtd--;
      return 0;
    }
  return -1;
}

/* 0 = guardado; -1 = lista cheia de trabalhos ativos ("fila_cheia"). Chamar com a trava. */
static int guardar_trava(const conv_t *c) {
  if(vaga()) return -1;
  g_conv[g_qtd] = *c;
  g_conv[g_qtd++].id = ++g_seq;   /* 0.9.41: id do glibren (cancelar/mover pela pagina) */
  return 0;
}

static int guardar(const conv_t *c) {
  pthread_mutex_lock(&g_trava);
  int r = guardar_trava(c);
  pthread_mutex_unlock(&g_trava);
  return r;
}

/* 0.9.41: ainda cabe mais um? (a conversao confere ANTES de pedir ao Dump Forge, para nao deixar trabalho orfao) */
static int tem_vaga(void) {
  pthread_mutex_lock(&g_trava);
  int r = g_qtd < MAX_CONV;
  for(int i = 0; i < g_qtd && !r; i++) r = final(g_conv[i].estado) && !pendente(&g_conv[i]);
  pthread_mutex_unlock(&g_trava);
  return r;
}

/* 0.9.41: cancela no Dump Forge um trabalho que o glibren nao conseguiu guardar (lista encheu no meio) */
static void cancelar_no_df(unsigned long long job) {
  char cj[64];
  snprintf(cj, sizeof cj, "{\"id\":%llu}", job);
  buf_t r = {0};
  df_pedir("POST", "/api/cancel_job", cj, &r, 5);
  buf_free(&r);
}

/* Uma conversao ainda andando vai criar este arquivo. Chamar com a trava. */
static int destino_em_uso_trava(const char *destino) {
  int r = 0;
  for(int i = 0; i < g_qtd && !r; i++) r = !g_conv[i].instalar && !final(g_conv[i].estado) && !strcmp(g_conv[i].destino, destino);
  return r;
}

static int destino_em_uso(const char *destino) {
  pthread_mutex_lock(&g_trava);
  int r = destino_em_uso_trava(destino);
  pthread_mutex_unlock(&g_trava);
  return r;
}

void conversao_rota_iniciar(pedido_t *p) {
  char formato[16] = "", nivel[12] = "", padrao_f[16], padrao_n[12];
  config_conversao(padrao_f, padrao_n);
  param(p->corpo, "formato", 0, formato, sizeof formato);
  param(p->corpo, "nivel", 0, nivel, sizeof nivel);
  if(!formato[0]) snprintf(formato, sizeof formato, "%s", padrao_f);
  (void)padrao_n;   /* nivel vazio = padrao do Dump Forge (a pagina manda o nivel da opcao geral quando vale) */
  int f = achar_formato(formato);
  if(f < 0) {
    responder_erro(p, 400, "conv_formato_invalido", "formato de conversao desconhecido", NULL);
    return;
  }
  if(!conversao_nivel_valido(formato, nivel)) {
    responder_erro(p, 400, "conv_nivel_invalido", "nivel de compressao desconhecido", NULL);
    return;
  }
  if(!conversao_dumpforge_no_ar()) {
    responder_erro(p, 503, "dumpforge_fora", "o Dump Forge nao esta no ar: ligue-o pela pagina Payloads", NULL);
    return;
  }
  buf_t rec = {0};
  int nrec = 0, criadas = 0;
  char pasta[1024], nome[512];
  for(int i = 0; i < 200 && param(p->corpo, "pasta", i, pasta, sizeof pasta); i++) {
    nome[0] = 0;
    param(p->corpo, "de", i, nome, sizeof nome);
    if(!arquivos_pasta_permitida(pasta) || !caminho_valido(pasta)) {   /* 0.9.49: e BACKUP/<jogo>/ */
      recusa(&rec, &nrec, nome, "fora_das_pastas", NULL);
      continue;
    }
    if(!nome_valido(nome)) {
      recusa(&rec, &nrec, nome, "invalido", NULL);
      continue;
    }
    conv_t c;
    memset(&c, 0, sizeof c);
    char base[512], fmt_origem[16];
    snprintf(c.origem, sizeof c.origem, "%s%s%s", pasta, pasta[strlen(pasta) - 1] == '/' ? "" : "/", nome);
    struct stat st;
    if(lstat(c.origem, &st) || !(S_ISREG(st.st_mode) || S_ISDIR(st.st_mode))) {
      recusa(&rec, &nrec, nome, "nao_existe", NULL);
      continue;
    }
    /* 0.9.48: tamanho do original (arquivo: ja; pasta: o medidor soma depois, sem segurar a pagina) */
    if(S_ISREG(st.st_mode)) c.tam_origem = (unsigned long long)st.st_size;
    else c.medir = 1;
    /* pasta: so pasta de jogo (eboot.bin + sce_sys/param.json ou param.sfo), a mesma regra da lista */
    if(origem_ler(nome, S_ISDIR(st.st_mode), base, sizeof base, fmt_origem, sizeof fmt_origem) || !base[0] ||
       (S_ISDIR(st.st_mode) && !arquivos_pasta_de_jogo(c.origem))) {
      recusa(&rec, &nrec, nome, "origem_invalida", NULL);
      continue;
    }
    if(!strcmp(fmt_origem, formato)) {
      recusa(&rec, &nrec, nome, "mesmo_formato", NULL);
      continue;
    }
    snprintf(c.destino, sizeof c.destino, "%s%s%s%s", pasta, pasta[strlen(pasta) - 1] == '/' ? "" : "/", base, FORMATOS[f].sufixo);
    if(!lstat(c.destino, &st) || destino_em_uso(c.destino)) {
      recusa(&rec, &nrec, nome, "destino_existe", c.destino);
      continue;
    }
    if(!tem_vaga()) {   /* 0.9.41: a lista do glibren esta cheia de trabalhos ativos: nem pede ao Dump Forge */
      recusa(&rec, &nrec, nome, "fila_cheia", NULL);
      continue;
    }
    buf_t corpo = {0}, resp = {0};
    buf_str(&corpo, "{\"request\":{\"source\":");
    buf_json(&corpo, c.origem);
    buf_str(&corpo, ",\"output\":");
    buf_json(&corpo, c.destino);
    buf_fmt(&corpo, ",\"format\":\"%s\"%s", FORMATOS[f].formato, FORMATOS[f].extra);
    nivel_campo(f, nivel, &corpo);
    buf_str(&corpo, ",\"delete_source\":false}}");
    buf_add(&corpo, "", 1);
    int st_df = df_pedir("POST", "/api/start_job", corpo.d, &resp, 20);
    buf_free(&corpo);
    if(st_df == 200 && resp.d && resp.n && resp.d[0] >= '0' && resp.d[0] <= '9') {
      buf_add(&resp, "", 1);
      c.job = strtoull(resp.d, NULL, 10);
      snprintf(c.formato, sizeof c.formato, "%s", formato);
      snprintf(c.nivel, sizeof c.nivel, "%s", nivel);
      snprintf(c.estado, sizeof c.estado, "fila");
      snprintf(c.base, sizeof c.base, "%s", base);
      c.inicio = (long long)time(NULL);
      if(guardar(&c)) {   /* 0.9.41: encheu entre a conferencia e o pedido: cancela no Dump Forge (nada orfao) */
        cancelar_no_df(c.job);
        diario("conversao: %llu cancelada: a lista do glibren esta cheia (%d trabalhos ativos)", c.job, MAX_CONV);
        recusa(&rec, &nrec, nome, "fila_cheia", NULL);
      } else {
        criadas++;
        diario("conversao: %llu pedida: %s -> %s (%s%s%s)", c.job, c.origem, c.destino, formato, c.nivel[0] ? " " : "", c.nivel);
      }
    } else {
      char erro[300];
      erro_df(&resp, erro, sizeof erro);
      if(st_df < 0) snprintf(erro, sizeof erro, "o Dump Forge nao respondeu");
      diario("conversao: recusada pelo Dump Forge (%d): %s: %s", st_df, c.origem, erro);
      recusa(&rec, &nrec, nome, "dumpforge", erro);
    }
    buf_free(&resp);
  }
  if(criadas) {
    ligar_vigia();
    disparar_medidor();   /* 0.9.48 */
    salvar();
  }
  buf_t b = {0};
  buf_fmt(&b, "{\"ok\":true,\"criadas\":%d,\"recusadas\":[", criadas);
  if(rec.d) buf_add(&b, rec.d, rec.n);
  buf_str(&b, "]}");
  responder_json(p, 200, &b);
  buf_free(&b);
  buf_free(&rec);
}

/* ------------------------------------------------------------------ cancelar, limpar, padrao */

void conversao_rota_cancelar(pedido_t *p) {
  char id[24] = "";
  param(p->corpo, "id", 0, id, sizeof id);
  unsigned long long nosso = strtoull(id, NULL, 10), job = 0;
  int i, achou = 0, local = 0;
  pthread_mutex_lock(&g_trava);
  for(i = 0; i < g_qtd; i++)
    if(id[0] && g_conv[i].id == nosso && !final(g_conv[i].estado)) {
      achou = 1;
      job = g_conv[i].job;
      /* 0.9.41: instalacao ainda na fila do glibren (o Dump Forge nem sabe dela): sai da fila aqui mesmo */
      if(!job) {
        local = 1;
        snprintf(g_conv[i].estado, sizeof g_conv[i].estado, "cancelado");
        snprintf(g_conv[i].erro, sizeof g_conv[i].erro, "cancelled");
      }
      break;
    }
  pthread_mutex_unlock(&g_trava);
  if(!achou) {
    responder_erro(p, 404, "conv_nao_achada", "conversao nao encontrada (ou ja terminou)", NULL);
    return;
  }
  if(local) {
    salvar();
    diario("instalacao: tirada da fila: id %llu", nosso);
    static const char ok[] = "{\"ok\":true}";
    responder(p, 200, "application/json", ok, sizeof ok - 1, "no-store");
    return;
  }
  char corpo[64];
  snprintf(corpo, sizeof corpo, "{\"id\":%llu}", job);
  buf_t r = {0};
  int st = df_pedir("POST", "/api/cancel_job", corpo, &r, 5);
  buf_free(&r);
  if(st != 200) {
    responder_erro(p, 503, "dumpforge_fora", "o Dump Forge nao respondeu", NULL);
    return;
  }
  pthread_mutex_lock(&g_trava);
  for(i = 0; i < g_qtd; i++)
    if(g_conv[i].job == job && !final(g_conv[i].estado)) snprintf(g_conv[i].estado, sizeof g_conv[i].estado, "cancelando");
  pthread_mutex_unlock(&g_trava);
  salvar();
  diario("conversao: %llu: cancelamento pedido", job);
  static const char ok[] = "{\"ok\":true}";
  responder(p, 200, "application/json", ok, sizeof ok - 1, "no-store");
}

void conversao_rota_limpar(pedido_t *p) {
  pthread_mutex_lock(&g_trava);
  int n = 0;
  for(int i = 0; i < g_qtd; i++)
    if(!final(g_conv[i].estado) || pendente(&g_conv[i])) g_conv[n++] = g_conv[i];
  int tirados = g_qtd - n;
  g_qtd = n;
  pthread_mutex_unlock(&g_trava);
  salvar();
  buf_t b = {0};
  buf_fmt(&b, "{\"ok\":true,\"tirados\":%d}", tirados);
  responder_json(p, 200, &b);
  buf_free(&b);
}

void conversao_rota_padrao(pedido_t *p) {
  char formato[16] = "", nivel[12] = "", atual_f[16], atual_n[12];
  config_conversao(atual_f, atual_n);
  param(p->corpo, "formato", 0, formato, sizeof formato);
  param(p->corpo, "nivel", 0, nivel, sizeof nivel);
  if(!formato[0]) snprintf(formato, sizeof formato, "%s", atual_f);
  (void)atual_n;   /* nivel vazio = padrao do Dump Forge */
  if(!conversao_formato_valido(formato) || !conversao_nivel_valido(formato, nivel)) {
    responder_erro(p, 400, "conv_formato_invalido", "formato ou nivel desconhecido", NULL);
    return;
  }
  if(config_gravar_conversao(formato, nivel)) {
    responder_erro(p, 500, "conv_gravar", "nao gravou o config.ini", NULL);
    return;
  }
  buf_t b = {0};
  buf_str(&b, "{\"ok\":true,\"padrao\":");
  buf_json(&b, formato);
  buf_str(&b, ",\"nivel\":");
  buf_json(&b, nivel);
  buf_str(&b, "}");
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* 0.9.36: "Mover agora": o original de uma conversao pronta que ficou (adiado, falhou ou opcao desligada) vai para o
   BACKUP agora, com as mesmas conferencias (saida, ShadowMount+). */
void conversao_rota_backup(pedido_t *p) {
  char id[24] = "";
  param(p->corpo, "id", 0, id, sizeof id);
  unsigned long long nosso = strtoull(id, NULL, 10), job = 0;
  int achou = 0;
  pthread_mutex_lock(&g_trava);
  for(int i = 0; i < g_qtd; i++) {
    conv_t *c = &g_conv[i];
    if(!id[0] || c->id != nosso || c->instalar || strcmp(c->estado, "feito")) continue;
    job = c->job;
    if(!strcmp(c->backup, "adiado") || !strcmp(c->backup, "falhou") || !strcmp(c->backup, "desligado")) {
      snprintf(c->backup, sizeof c->backup, "esperando");
      memset(&c->bk, 0, sizeof c->bk);
      c->forcar = 1;
      achou = 1;
    }
  }
  pthread_mutex_unlock(&g_trava);
  if(!achou) {
    responder_erro(p, 404, "conv_nao_achada", "conversao pronta com o original para mover nao encontrada", NULL);
    return;
  }
  diario("conversao: %llu: mover o original agora (pedido)", job);
  salvar();
  disparar_mover();
  static const char ok[] = "{\"ok\":true}";
  responder(p, 200, "application/json", ok, sizeof ok - 1, "no-store");
}

/* 0.9.36: POST /api/conversao/mover (ligado = 1|0): a opcao "Mover o original para BACKUP depois de converter" */
void conversao_rota_mover(pedido_t *p) {
  char v[8] = "";
  param(p->corpo, "ligado", 0, v, sizeof v);
  if(strcmp(v, "1") && strcmp(v, "0")) {
    responder_erro(p, 400, "requisicao_invalida", "ligado = 1 ou 0", NULL);
    return;
  }
  if(config_gravar_conversao_mover(v[0] == '1')) {
    responder_erro(p, 500, "conv_gravar", "nao gravou o config.ini", NULL);
    return;
  }
  buf_t b = {0};
  buf_fmt(&b, "{\"ok\":true,\"mover\":%s}", v[0] == '1' ? "true" : "false");
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* ------------------------------------------------------------------ 0.9.41: instalar .pkg */

/* Cabecalho do .pkg: "PS4" (\x7FCNT no inicio), "PS5" (\x7FFIH; \x7FLIH = atualizacao de PS5) ou "" (nao e .pkg). */
static const char *tipo_pkg(const char *caminho) {
  FILE *f = fopen(caminho, "rb");
  if(!f) return "";
  unsigned char m[4] = {0};
  size_t n = fread(m, 1, 4, f);
  fclose(f);
  if(n != 4 || m[0] != 0x7F) return "";
  if(!memcmp(m + 1, "CNT", 3)) return "PS4";
  if(!memcmp(m + 1, "FIH", 3) || !memcmp(m + 1, "LIH", 3)) return "PS5";
  return "";
}

/* Chamar com a trava. */
static int instalando_trava(const char *origem) {
  int r = 0;
  for(int i = 0; i < g_qtd && !r; i++) r = g_conv[i].instalar && !final(g_conv[i].estado) && !strcmp(g_conv[i].origem, origem);
  return r;
}

/* 0.9.41: as conferencias que dependem da lista e a gravacao na fila sob a MESMA trava (dois pedidos juntos nao duplicam
   o mesmo .pkg). NULL = guardado; senao, o motivo da recusa. */
static const char *guardar_instalacao(const conv_t *c) {
  pthread_mutex_lock(&g_trava);
  const char *motivo = NULL;
  if(destino_em_uso_trava(c->origem)) motivo = "em_uso";
  else if(instalando_trava(c->origem)) motivo = "ja_instalando";
  else if(guardar_trava(c)) motivo = "fila_cheia";
  pthread_mutex_unlock(&g_trava);
  return motivo;
}

void conversao_rota_instalar(pedido_t *p) {
  if(!conversao_dumpforge_no_ar()) {
    responder_erro(p, 503, "dumpforge_fora", "o Dump Forge nao esta no ar: ligue-o pela pagina Payloads", NULL);
    return;
  }
  buf_t rec = {0};
  int nrec = 0, criadas = 0;
  char pasta[1024], nome[512];
  for(int i = 0; i < 200 && param(p->corpo, "pasta", i, pasta, sizeof pasta); i++) {
    nome[0] = 0;
    param(p->corpo, "de", i, nome, sizeof nome);
    if(!arquivos_pasta_permitida(pasta) || !caminho_valido(pasta)) {   /* 0.9.49: e BACKUP/<jogo>/ */
      recusa(&rec, &nrec, nome, "fora_das_pastas", NULL);
      continue;
    }
    if(!nome_valido(nome)) {
      recusa(&rec, &nrec, nome, "invalido", NULL);
      continue;
    }
    conv_t c;
    memset(&c, 0, sizeof c);
    snprintf(c.origem, sizeof c.origem, "%s%s%s", pasta, pasta[strlen(pasta) - 1] == '/' ? "" : "/", nome);
    /* 0.9.41: .pkg que uma conversao ainda esta gerando (incompleto): nem le o cabecalho (conferido de novo sob a trava) */
    if(destino_em_uso(c.origem)) {
      recusa(&rec, &nrec, nome, "em_uso", NULL);
      continue;
    }
    struct stat st;
    if(lstat(c.origem, &st) || !S_ISREG(st.st_mode)) {
      recusa(&rec, &nrec, nome, "nao_existe", NULL);
      continue;
    }
    const char *tipo = termina_com(nome, ".pkg") ? tipo_pkg(c.origem) : "";
    if(!tipo[0]) {
      recusa(&rec, &nrec, nome, "nao_pkg", NULL);
      continue;
    }
    c.instalar = 1;
    snprintf(c.formato, sizeof c.formato, "instalar");
    snprintf(c.plataforma, sizeof c.plataforma, "%s", tipo);
    snprintf(c.estado, sizeof c.estado, "espera");
    c.total = (unsigned long long)st.st_size;
    c.inicio = (long long)time(NULL);
    const char *motivo = guardar_instalacao(&c);
    if(motivo) {
      recusa(&rec, &nrec, nome, motivo, NULL);
      continue;
    }
    criadas++;
    diario("instalacao: na fila (%s): %s", tipo, c.origem);
  }
  if(criadas) {
    salvar();
    disparar_instalacao();
    ligar_vigia();
  }
  buf_t b = {0};
  buf_fmt(&b, "{\"ok\":true,\"criadas\":%d,\"recusadas\":[", criadas);
  if(rec.d) buf_add(&b, rec.d, rec.n);
  buf_str(&b, "]}");
  responder_json(p, 200, &b);
  buf_free(&b);
  buf_free(&rec);
}

/* ------------------------------------------------------------------ 0.9.48: lista gravada + adocao ao iniciar */

static void arquivo_lista(char *saida, size_t tam) { snprintf(saida, tam, "%s/conversoes.json", g_pasta_dados); }

/* Grava a lista em <dados>/conversoes.json (arquivo novo + rename), so quando mudou. Nunca com a g_trava na mao. */
static void salvar(void) {
  buf_t b = {0};
  pthread_mutex_lock(&g_trava);
  buf_fmt(&b, "{\"versao\":1,\"seq\":%llu,\"itens\":[", g_seq);
  for(int i = 0; i < g_qtd; i++) {
    const conv_t *c = &g_conv[i];
    buf_fmt(&b, "%s{\"id\":%llu,\"job\":%llu,\"instalar\":%d,\"inicio\":%lld,\"feitos\":%llu,\"total\":%llu,\"bytes\":%llu,"
                "\"tam_origem\":%llu,\"tam_destino\":%llu,\"tam_dito\":%d,\"bk_adiado\":%d,\"adotada\":%d",
            i ? "," : "", c->id, c->job, c->instalar, c->inicio, c->feitos, c->total, c->bytes, c->tam_origem, c->tam_destino,
            c->tam_dito, c->bk.adiado, c->adotada);
    const char *const nomes[] = {"origem", "destino", "formato", "nivel", "estado", "plataforma", "codigo", "etapa", "erro",
                                 "base", "backup", "bk_chave", "bk_detalhe", "bk_pasta"};
    const char *const valores[] = {c->origem, c->destino, c->formato, c->nivel, c->estado, c->plataforma, c->codigo, c->etapa,
                                   c->erro, c->base, c->backup, c->bk.chave, c->bk.detalhe, c->bk.pasta};
    for(int k = 0; k < 14; k++) {
      buf_fmt(&b, ",\"%s\":", nomes[k]);
      buf_json(&b, valores[k]);
    }
    buf_str(&b, "}");
  }
  pthread_mutex_unlock(&g_trava);
  buf_str(&b, "]}\n");
  pthread_mutex_lock(&g_trava_arq);
  if(!g_gravado.d || g_gravado.n != b.n || memcmp(g_gravado.d, b.d, b.n)) {
    char arq[700], novo[720];
    arquivo_lista(arq, sizeof arq);
    snprintf(novo, sizeof novo, "%s.novo", arq);
    FILE *f = fopen(novo, "wb");
    int ok = f && fwrite(b.d, 1, b.n, f) == b.n;
    if(f && fclose(f)) ok = 0;
    if(ok && !rename(novo, arq)) {
      buf_free(&g_gravado);
      g_gravado = b;
      memset(&b, 0, sizeof b);
    } else {
      unlink(novo);
    }
  }
  pthread_mutex_unlock(&g_trava_arq);
  buf_free(&b);
}

static int ler_item(const js_t *item, void *ctx) {
  (void)ctx;
  if(g_qtd >= MAX_CONV) return 0;
  conv_t c;
  memset(&c, 0, sizeof c);
  js_t v;
#define NUM(campo, chave) \
  if(js_campo(item, chave, &v)) c.campo = js_num(&v)
#define TXT(campo, chave) \
  if(js_campo(item, chave, &v)) js_string(&v, c.campo, sizeof c.campo)
  NUM(id, "id");
  NUM(job, "job");
  NUM(feitos, "feitos");
  NUM(total, "total");
  NUM(bytes, "bytes");
  NUM(tam_origem, "tam_origem");
  NUM(tam_destino, "tam_destino");
  if(js_campo(item, "instalar", &v)) c.instalar = (int)js_num(&v);
  if(js_campo(item, "inicio", &v)) c.inicio = (long long)js_num(&v);
  if(js_campo(item, "tam_dito", &v)) c.tam_dito = (int)js_num(&v);
  if(js_campo(item, "bk_adiado", &v)) c.bk.adiado = (int)js_num(&v);
  if(js_campo(item, "adotada", &v)) c.adotada = (int)js_num(&v);
  TXT(origem, "origem");
  TXT(destino, "destino");
  TXT(formato, "formato");
  TXT(nivel, "nivel");
  TXT(estado, "estado");
  TXT(plataforma, "plataforma");
  TXT(codigo, "codigo");
  TXT(etapa, "etapa");
  TXT(erro, "erro");
  TXT(base, "base");
  TXT(backup, "backup");
  TXT(bk.chave, "bk_chave");
  TXT(bk.detalhe, "bk_detalhe");
  TXT(bk.pasta, "bk_pasta");
#undef NUM
#undef TXT
  if(!c.id || !c.origem[0] || !c.estado[0]) return 1;
  /* o original estava indo para o BACKUP quando o glibren fechou: tenta de novo (o backup.c confere tudo outra vez) */
  if(!strcmp(c.backup, "movendo")) snprintf(c.backup, sizeof c.backup, "esperando");
  if(!c.instalar) {
    struct stat st;
    if(!c.tam_origem && !lstat(c.origem, &st)) c.medir |= 1;
    if(!c.tam_destino && !strcmp(c.estado, "feito")) c.medir |= 2;
  }
  g_conv[g_qtd++] = c;
  if(c.id > g_seq) g_seq = c.id;
  return 1;
}

static void carregar(void) {
  char arq[700];
  arquivo_lista(arq, sizeof arq);
  FILE *f = fopen(arq, "rb");
  if(!f) return;
  buf_t b = {0};
  char bloco[8192];
  size_t n;
  while((n = fread(bloco, 1, sizeof bloco, f)) > 0 && b.n < 4u * 1024 * 1024) buf_add(&b, bloco, n);
  fclose(f);
  if(!b.d) return;
  js_t raiz = {b.d, b.d + b.n}, v;
  pthread_mutex_lock(&g_trava);
  if(js_campo(&raiz, "itens", &v)) js_cada(&v, ler_item, NULL);
  if(js_campo(&raiz, "seq", &v) && js_num(&v) > g_seq) g_seq = js_num(&v);
  int lidas = g_qtd, ativas = 0;
  for(int i = 0; i < g_qtd; i++) ativas += !final(g_conv[i].estado);
  pthread_mutex_unlock(&g_trava);
  buf_free(&b);
  if(lidas) diario("conversao: %d tarefa(s) da lista gravada (%d em andamento)", lidas, ativas);
}

/* id do glibren pelo pedido do Dump Forge: mesmo "format" e a saida termina com o sufixo (o mais longo vence) */
static int formato_do_pedido(const char *formato_df, const char *saida) {
  int melhor = -1;
  size_t tam = 0;
  for(int i = 0; i < N_FORMATOS; i++) {
    if(strcmp(FORMATOS[i].formato, formato_df)) continue;
    size_t k = strlen(FORMATOS[i].sufixo);
    if(k && !termina_com(saida, FORMATOS[i].sufixo)) continue;
    if(melhor < 0 || k > tam) {
      melhor = i;
      tam = k;
    }
  }
  return melhor;
}

static void pasta_de(const char *caminho, char *pasta, size_t tam) {
  snprintf(pasta, tam, "%s", caminho);
  char *b = strrchr(pasta, '/');
  if(b && b != pasta) *b = 0;
}

/* Conversoes que estao no Dump Forge e nao estao na lista (pedidas por um glibren que nao gravava a lista, ou com o
   conversoes.json perdido): entram na lista para a pagina acompanhar e o original ir para o BACKUP no fim. So trabalho de
   conversao ainda andando, com origem e saida dentro das pastas da lista. Devolve quantas adotou (-1 = sem resposta). */
static int adotar(void) {
  buf_t r = {0};
  if(df_pedir("GET", "/api/jobs", NULL, &r, 4) != 200 || !r.d) {
    buf_free(&r);
    return -1;
  }
  int adotadas = 0;
  js_t raiz = {r.d, r.d + r.n}, lista;
  if(js_campo(&raiz, "jobs", &lista)) {
    js_t j = lista;
    js_esp(&j);
    if(j.p < j.fim && *j.p == '[') {
      j.p++;
      js_esp(&j);
      while(j.p < j.fim && *j.p == '{') {
        js_t item = j, v, req, x;
        if(js_pular(&j, 1)) break;
        item.fim = j.p;
        conv_t c;
        memset(&c, 0, sizeof c);
        char fmt_df[16] = "", inst[8] = "";
        c.job = js_campo(&item, "id", &v) ? js_num(&v) : 0;
        int terminou = js_campo(&item, "done", &v) && !js_nulo(&v);
        if(js_campo(&item, "request", &req)) {
          if(js_campo(&req, "source", &x)) js_string(&x, c.origem, sizeof c.origem);
          if(js_campo(&req, "output", &x)) js_string(&x, c.destino, sizeof c.destino);
          if(js_campo(&req, "format", &x)) js_string(&x, fmt_df, sizeof fmt_df);
          if(js_campo(&req, "install", &x) && !js_nulo(&x)) snprintf(inst, sizeof inst, "sim");
        }
        char po[1100], pd[1100], base[512], fmt_origem[16];
        pasta_de(c.origem, po, sizeof po);
        pasta_de(c.destino, pd, sizeof pd);
        int f = formato_do_pedido(fmt_df, c.destino);
        struct stat st;
        const char *nome = strrchr(c.origem, '/');
        if(c.job && !terminou && !inst[0] && c.origem[0] && c.destino[0] && f >= 0 && nome && nome[1] &&
           caminho_valido(po) && caminho_valido(pd) && config_pasta_permitida(po) && config_pasta_permitida(pd) &&
           !lstat(c.origem, &st) && (S_ISREG(st.st_mode) || S_ISDIR(st.st_mode)) &&
           !origem_ler(nome + 1, S_ISDIR(st.st_mode), base, sizeof base, fmt_origem, sizeof fmt_origem) && base[0]) {
          snprintf(c.formato, sizeof c.formato, "%s", FORMATOS[f].id);
          snprintf(c.estado, sizeof c.estado, "fila");
          snprintf(c.base, sizeof c.base, "%s", base);
          c.inicio = (long long)time(NULL);
          c.adotada = 1;
          if(S_ISREG(st.st_mode)) c.tam_origem = (unsigned long long)st.st_size;
          else c.medir = 1;
          pthread_mutex_lock(&g_trava);
          int tem = 0;
          for(int i = 0; i < g_qtd && !tem; i++) tem = g_conv[i].job == c.job && !strcmp(g_conv[i].destino, c.destino);
          int guardou = !tem && !guardar_trava(&c);
          pthread_mutex_unlock(&g_trava);
          if(guardou) {
            adotadas++;
            diario("conversao: %llu adotada (pedida antes de o glibren reiniciar): %s -> %s (%s)", c.job, c.origem, c.destino,
                   c.formato);
          }
        }
        js_esp(&j);
        if(j.p < j.fim && *j.p == ',') {
          j.p++;
          js_esp(&j);
        }
      }
    }
  }
  buf_free(&r);
  return adotadas;
}

static void *ao_iniciar(void *arg) {
  (void)arg;
  int adota = 1;
#ifndef __PROSPERO__
  const char *v = getenv("GLR_TESTE_CONV_ADOTAR");
  adota = v && *v == '1';
#endif
  /* 0.9.49: <disco>/BACKUP -> <disco>/backup e originais de backup/<jogo>/ soltos na pasta; nunca com conversao (nossa,
     gravada na lista) ou copia/movimento em andamento */
  pthread_mutex_lock(&g_trava);
  int andando = 0;
  for(int i = 0; i < g_qtd; i++) andando += !final(g_conv[i].estado) || pendente(&g_conv[i]);
  pthread_mutex_unlock(&g_trava);
  backup_arrumar(andando || tarefas_ativas());
  /* o Dump Forge pode demorar alguns segundos para responder logo depois de o glibren subir: ate 1 minuto */
  for(int k = 0; adota && k < 12; k++) {
    if(conversao_dumpforge_no_ar() && adotar() >= 0) break;
    sleep(5);
  }
  pthread_mutex_lock(&g_trava);
  int ativas = 0;
  for(int i = 0; i < g_qtd; i++) ativas += !final(g_conv[i].estado) || pendente(&g_conv[i]);
  pthread_mutex_unlock(&g_trava);
  if(ativas) ligar_vigia();
  disparar_medidor();
  disparar_mover();
  salvar();
  return NULL;
}

void conversao_iniciar(void) {
  carregar();
  if(criar_thread(ao_iniciar, NULL, NULL)) diario("conversao: a thread de inicio nao subiu");
}
