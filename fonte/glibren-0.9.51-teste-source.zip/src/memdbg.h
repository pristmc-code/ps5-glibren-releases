/* Game Library Renamer (payload PS5) - 0.9.40: CLIENTE do MemDBG (seregonwar/MemDBG, GPL-3).

O MemDBG e um payload aberto SEPARADO que a pessoa carrega pela pagina Payloads. Ele escuta em 127.0.0.1/0.0.0.0:9020
com o protocolo binario "MDBG" documentado em docs/protocol.md do proprio MemDBG (feature level 4, wire v1). O glibren
so CONVERSA com ele por TCP: HELLO (versao e capacidades), PING, PROCESS_ALLOC / PROCESS_PROTECT / PROCESS_FREE (reservar
e liberar a "area extra" que uma cheat precisa e o jogo nao tem), MEMORY_READ / MEMORY_WRITE (ler e gravar nessa area)
e GOODBYE. Quem mexe no processo do jogo e o MemDBG; o glibren nao tem ptrace, injecao de syscall nem mmap no jogo.

Cuidados do lado do MemDBG (acceptor.c dele): no maximo 8 conexoes por minuto do mesmo endereco (127.0.0.1 conta) e
cada HELLO novo mostra a notificacao "MemDBG 127.0.0.1 connected" no PS5. Por isso: "rodando agora" com cache (20 s),
HELLO so na primeira vez (e a cada 10 min) e PING nas outras; uma conexao so para cada ligar/desligar. */
#pragma once

#include <stddef.h>
#include <stdint.h>

#define MDG_PORTA 9020

/* capacidades do HELLO (docs/protocol.md, "Capabilities") */
#define MDG_CAP_MEMORY_READ (1u << 2)
#define MDG_CAP_MEMORY_WRITE (1u << 3)
#define MDG_CAP_MEMORY_PROTECT (1u << 22)
#define MDG_CAP_MEMORY_ALLOC (1u << 23)

/* protecao (MEMDBG_MAP_PROT_*) */
#define MDG_PROT_L 1u
#define MDG_PROT_E 2u
#define MDG_PROT_X 4u

/* retornos: 0 = MEMDBG_OK; -1..-10 = status do MemDBG (MEMDBG_ERR_*); estes sao do lado do glibren */
#define MDG_ERRO_REDE (-100)   /* nao conectou, caiu no meio ou resposta fora do protocolo */

typedef struct {
  int rodando;                 /* 1 = respondeu (HELLO valido, nome MemDBG) */
  unsigned protocolo, plataforma, nivel;   /* protocol_version, platform_id, feature_level (0 = HELLO V1) */
  uint32_t caps;
  char versao[64];             /* version_full (HELLO V3) ou version[16] */
} mdg_info_t;

typedef struct {
  int fd;
  uint32_t id;
  mdg_info_t info;
} mdg_sessao_t;

int mdg_porta(void);
/* "Rodando agora" com cache (20 s; GLR_TESTE_MEMDBG_CACHE_S no PC). */
void mdg_estado(mdg_info_t *i);
/* 1 = anuncia reservar memoria, ler e gravar (o que a area extra precisa) */
int mdg_pode_reservar(const mdg_info_t *i);
/* Abre uma conexao com HELLO (atualiza o cache). 0 = ok. */
int mdg_abrir(mdg_sessao_t *s);
/* GOODBYE + fecha (sem efeito se nao estiver aberta). */
void mdg_fechar(mdg_sessao_t *s);
/* PROCESS_ALLOC: reserva tam bytes no processo pid, dica de endereco (flags bit 0 = respeitar a dica). *end = onde ficou. */
int mdg_reservar(mdg_sessao_t *s, int pid, uint64_t dica, uint64_t tam, uint32_t prot, uint64_t *end);
/* PROCESS_PROTECT */
int mdg_proteger(mdg_sessao_t *s, int pid, uint64_t end, uint64_t tam, uint32_t prot);
/* PROCESS_FREE */
int mdg_liberar(mdg_sessao_t *s, int pid, uint64_t end, uint64_t tam);
/* MEMORY_READ / MEMORY_WRITE (em pedacos pequenos: a resposta da leitura nunca vem comprimida abaixo de 4 KB) */
int mdg_ler(mdg_sessao_t *s, int pid, uint64_t end, void *saida, size_t n);
int mdg_gravar(mdg_sessao_t *s, int pid, uint64_t end, const void *dados, size_t n);
/* "MEMDBG_ERR_IO" etc. (para o diario e para a pagina) */
const char *mdg_status_nome(int st);
