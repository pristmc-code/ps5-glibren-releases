/* Game Library Renamer (payload PS5) - rotas da API e arquivos servidos para a pagina.

A logica de nomes (codigo no nome, compactados, patch, nome novo, ShadowMountPlus) fica no JavaScript
da pagina; aqui ficam so o acesso ao disco do PS5 e a internet (que o navegador nao pode fazer por CORS).
*/
#include "api.h"

#include <arpa/inet.h>
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <netinet/in.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "apps.h"
#include "arquivos.h"
#include "ampr_teste.h"
#include "sk_pastas.h"
#include "backup.h"
#include "config.h"
#include "http.h"
#include "https.h"
#include "jogo_local.h"
#include "lancador.h"
#include "plataforma.h"
#include "relogio.h"
#include "usb_temp.h"
#include "tarefas.h"
#include "termico.h"
#include "fps.h"
#include "cheats.h"
#include "discos.h"
#include "dns_resolver.h"
#include "pareamento.h"
#include "payloads.h"
#include "jobe_payload.h"
#include "conversao.h"
#include "prefbar.h"
#include "diagnostico.h"
#include "coredump.h"
#include "primeiro_plano.h"
#include "internet.h"
#include "versoes.h"

#include <sys/statvfs.h>
#include "web_icone.h"
#include "atualizacao.h"
#include "web_index.h"
#include "web_youtube.h"
#include "web_telacheia.h"
#include "web_temperatura.h"
#include "web_discos.h"
#include "web_internet.h"
#include "web_fps.h"
#include "web_cheats.h"
#include "web_payloads.h"
#include "web_ps5tela.h"
#include "web_diagnostico.h"

#define URL_BASE "https://raw.githubusercontent.com/andshrew/PlayStation-Titles/main/All_Titles.tsv"
#define VALIDADE_BASE_S (24 * 3600)   /* a base e baixada de novo uma vez por dia */
#define MAX_BASE (64 * 1024 * 1024)
#define MAX_ICONE (2 * 1024 * 1024)
#define MAX_PAGINA (4 * 1024 * 1024)
#define MAX_CACHE (8 * 1024 * 1024)

int g_porta = 8765;

/* ------------------------------------------------------------------ base de titulos */

static pthread_mutex_t g_trava_base = PTHREAD_MUTEX_INITIALIZER;
static char g_base_situacao[16] = "carregando";
static char g_base_erro[256];

static void arquivo_dados(char *saida, size_t tam, const char *nome) {
  snprintf(saida, tam, "%s/%s", g_pasta_dados, nome);
}

static void *baixar_base(void *forcar) {
  char arquivo[600], tmp[610];
  struct stat st;
  arquivo_dados(arquivo, sizeof arquivo, "base_titulos.tsv");
  snprintf(tmp, sizeof tmp, "%s.tmp", arquivo);
  int tem = !stat(arquivo, &st) && st.st_size > 0;
  if(tem && !forcar && time(NULL) - st.st_mtime < VALIDADE_BASE_S) {
    pthread_mutex_lock(&g_trava_base);
    snprintf(g_base_situacao, sizeof g_base_situacao, "ok");
    pthread_mutex_unlock(&g_trava_base);
    return NULL;
  }
  pthread_mutex_lock(&g_trava_base);
  snprintf(g_base_situacao, sizeof g_base_situacao, tem ? "ok" : "baixando");
  pthread_mutex_unlock(&g_trava_base);

  buf_t b = {0};
  int status = https_get(URL_BASE, &b, MAX_BASE, 180);
  char erro[256] = "";
  if(status != 200) snprintf(erro, sizeof erro, "nao foi possivel baixar a base (%d)", status);
  else if(b.n < 8 || strncmp(b.d, "titleId\t", 8)) snprintf(erro, sizeof erro, "arquivo baixado nao tem o formato esperado");
  else {
    FILE *f = fopen(tmp, "wb");
    if(!f || fwrite(b.d, 1, b.n, f) != b.n || fclose(f) || rename(tmp, arquivo))
      snprintf(erro, sizeof erro, "nao foi possivel gravar a base (%s)", strerror(errno));
  }
  buf_free(&b);

  pthread_mutex_lock(&g_trava_base);
  snprintf(g_base_erro, sizeof g_base_erro, "%s", erro);
  tem = !stat(arquivo, &st) && st.st_size > 0;
  snprintf(g_base_situacao, sizeof g_base_situacao, tem ? "ok" : "indisponivel");
  pthread_mutex_unlock(&g_trava_base);
  return NULL;
}

void api_atualizar_base(int forcar) {
  criar_thread(baixar_base, forcar ? (void *)1 : NULL, NULL);
}

static void base_json(buf_t *b) {
  char arquivo[600];
  struct stat st;
  arquivo_dados(arquivo, sizeof arquivo, "base_titulos.tsv");
  pthread_mutex_lock(&g_trava_base);
  buf_str(b, "{\"situacao\":");
  buf_json(b, g_base_situacao);
  buf_str(b, ",\"erro\":");
  buf_json(b, g_base_erro);
  if(!stat(arquivo, &st)) buf_fmt(b, ",\"baixada_em\":%lld,\"tamanho\":%lld", (long long)st.st_mtime, (long long)st.st_size);
  buf_str(b, "}");
  pthread_mutex_unlock(&g_trava_base);
}

/* ------------------------------------------------------------------ icones */

static const struct {
  const char *ext, *tipo;
} TIPOS[] = {{".webp", "image/webp"}, {".jpg", "image/jpeg"}, {".png", "image/png"}};

static int codigo_valido(const char *c) {
  if(strlen(c) != 9) return 0;
  for(int i = 0; i < 4; i++) if(c[i] < 'A' || c[i] > 'Z') return 0;
  for(int i = 4; i < 9; i++) if(c[i] < '0' || c[i] > '9') return 0;
  return 1;
}

/* O CDN dos sites nao envia Content-Type: identifica a imagem pelos primeiros bytes. */
static int tipo_imagem(const buf_t *b) {
  const unsigned char *d = (const unsigned char *)b->d;
  if(b->n > 12 && !memcmp(d, "RIFF", 4) && !memcmp(d + 8, "WEBP", 4)) return 0;
  if(b->n > 3 && d[0] == 0xff && d[1] == 0xd8 && d[2] == 0xff) return 1;
  if(b->n > 8 && !memcmp(d, "\x89PNG\r\n\x1a\n", 8)) return 2;
  return -1;
}

/* "icones":["PPSA08329",...] - os ja guardados no PS5 (a tela so pede os outros depois dos detalhes). */
static void icones_json(buf_t *b) {
  char pasta[600];
  arquivo_dados(pasta, sizeof pasta, "icones");
  DIR *d = opendir(pasta);
  int n = 0;
  buf_str(b, "\"icones\":[");
  struct dirent *e;
  while(d && (e = readdir(d))) {
    char codigo[16];
    if(e->d_name[0] == '.' || strlen(e->d_name) < 9) continue;
    snprintf(codigo, sizeof codigo, "%.9s", e->d_name);
    if(!codigo_valido(codigo)) continue;
    buf_str(b, n++ ? "," : "");
    buf_json(b, codigo);
  }
  if(d) closedir(d);
  buf_fmt(b, "],\"icones_qtd\":%d", n);
}

/* Icone que falhou e tentado de novo so depois de 5 minutos (como o app de PC). */
#define NOVA_TENTATIVA_ICONE_S 300
#define MAX_SEM_ICONE 256
static pthread_mutex_t g_trava_icone = PTHREAD_MUTEX_INITIALIZER;
static struct {
  char codigo[10];
  time_t quando;
} g_sem_icone[MAX_SEM_ICONE];

static int falhou_ha_pouco(const char *codigo) {
  int r = 0;
  pthread_mutex_lock(&g_trava_icone);
  for(int i = 0; i < MAX_SEM_ICONE; i++) {
    if(!strcmp(g_sem_icone[i].codigo, codigo) && time(NULL) - g_sem_icone[i].quando < NOVA_TENTATIVA_ICONE_S) r = 1;
  }
  pthread_mutex_unlock(&g_trava_icone);
  return r;
}

static void marcar_sem_icone(const char *codigo) {
  pthread_mutex_lock(&g_trava_icone);
  int livre = 0;
  for(int i = 0; i < MAX_SEM_ICONE; i++) {
    if(!strcmp(g_sem_icone[i].codigo, codigo)) { livre = i; break; }
    if(g_sem_icone[i].quando < g_sem_icone[livre].quando) livre = i;   /* o mais antigo */
  }
  snprintf(g_sem_icone[livre].codigo, sizeof g_sem_icone[livre].codigo, "%s", codigo);
  g_sem_icone[livre].quando = time(NULL);
  pthread_mutex_unlock(&g_trava_icone);
}

static void rota_icone(pedido_t *p, const char *codigo) {
  char pasta[600], arquivo[700], url[2048];
  if(!codigo_valido(codigo)) {
    responder(p, 404, "text/plain", "", 0, NULL);
    return;
  }
  arquivo_dados(pasta, sizeof pasta, "icones");
  for(size_t i = 0; i < 3; i++) {
    snprintf(arquivo, sizeof arquivo, "%s/%s%s", pasta, codigo, TIPOS[i].ext);
    if(!responder_arquivo(p, arquivo, TIPOS[i].tipo, "max-age=604800")) return;
  }
  /* Jogo instalado no PS5: a capa do proprio sistema (icon0.png do appmeta), sem internet (0.9.15, pagina de FPS). */
  const char *appmeta = "/user/appmeta";
#ifndef __PROSPERO__
  appmeta = getenv("GLR_TESTE_APPMETA") ? getenv("GLR_TESTE_APPMETA") : "/nao-existe";
#endif
  snprintf(arquivo, sizeof arquivo, "%s/%s/icon0.png", appmeta, codigo);
  if(!responder_arquivo(p, arquivo, "image/png", "max-age=86400")) return;
  /* Ainda nao baixado: a pagina manda a URL do site do jogo (so sites da lista fixa; nada da loja da Sony). */
  if(falhou_ha_pouco(codigo)) {
    responder(p, 404, "text/plain", "", 0, NULL);
    return;
  }
  buf_t b = {0};
  int tipo = -1, status = 0;
  if(param(p->query, "url", 0, url, sizeof url) && url_permitida(url) && (status = https_get(url, &b, MAX_ICONE, 6)) == 200)
    tipo = tipo_imagem(&b);
  if(strstr(p->query, "url")) {
    const unsigned char *d = (const unsigned char *)(b.d ? b.d : "");
    if(tipo < 0) diario("icone %s: falhou (status %d, %zu bytes, inicio %02x%02x%02x%02x, url %.80s)", codigo, status, b.n,
                        b.n > 0 ? d[0] : 0, b.n > 1 ? d[1] : 0, b.n > 2 ? d[2] : 0, b.n > 3 ? d[3] : 0, url);
    else diario("icone %s: baixado (%zu bytes, %s)", codigo, b.n, TIPOS[tipo].ext + 1);
  }
  if(tipo < 0) {
    if(strstr(p->query, "url")) marcar_sem_icone(codigo);
    responder(p, 404, "text/plain", "", 0, NULL);
  } else {
    mkdir_p(pasta);
    snprintf(arquivo, sizeof arquivo, "%s/%s%s", pasta, codigo, TIPOS[tipo].ext);
    FILE *f = fopen(arquivo, "wb");
    if(f) {
      fwrite(b.d, 1, b.n, f);
      fclose(f);
    }
    responder(p, 200, TIPOS[tipo].tipo, b.d, b.n, "max-age=604800");
  }
  buf_free(&b);
}

/* ------------------------------------------------------------------ rotas */

static void rota_estado(pedido_t *p) {
  char ip[64] = "";
  buf_t b = {0};
  meu_ip(ip, sizeof ip);
  buf_str(&b, "{\"ok\":true,\"versao\":");
  buf_json(&b, VERSAO);
  buf_str(&b, ",\"ip\":");
  buf_json(&b, ip);
  buf_fmt(&b, ",\"porta\":%d,\"pasta_dados\":", g_porta);
  buf_json(&b, g_pasta_dados);
  buf_str(&b, ",");
  config_json(&b);
  buf_str(&b, ",\"base\":");
  base_json(&b);
  buf_str(&b, ",");
  icones_json(&b);
  buf_str(&b, "}");
  responder_json(p, 200, &b);
  buf_free(&b);
}

static void rota_fs(pedido_t *p) {
  char caminho[1024] = "/";
  param(p->query, "caminho", 0, caminho, sizeof caminho);
  if(!caminho_valido(caminho)) {
    responder_erro(p, 400, "pasta_invalida", "caminho invalido", NULL);
    return;
  }
  buf_t b = {0};
  int erro = arquivos_listar(caminho, &b);
  if(erro) responder_erro(p, 404, "pasta_nao_abre", strerror(erro), caminho);
  else responder_json(p, 200, &b);
  buf_free(&b);
}

/* monitoradas: grava as pastas marcadas como do ShadowMount (todas de uma vez; nenhuma = desmarca todas). */
static void rota_pastas(pedido_t *p, int monitoradas) {
  static char pastas[MAX_PASTAS][1024];
  static pthread_mutex_t trava = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_lock(&trava);
  int qtd = 0;
  while(qtd < MAX_PASTAS && param(p->corpo, "pasta", qtd, pastas[qtd], sizeof pastas[qtd])) qtd++;
  int r = monitoradas ? config_gravar_monitoradas(pastas, qtd) : config_gravar(pastas, qtd, NULL);
  pthread_mutex_unlock(&trava);
  if(r) {
    responder_erro(p, 400, "pasta_invalida", monitoradas ? "a pasta nao esta na lista" : "o caminho deve comecar com /", NULL);
    return;
  }
  buf_t b = {0};
  buf_str(&b, "{\"ok\":true,");
  config_json(&b);
  buf_str(&b, "}");
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* Arquivos ocultos da lista de jogos: grava a lista inteira (nenhum = mostra todos de novo).
   mostrados = 1: lista dos .complete que o usuario mandou mostrar (nenhum = todos voltam a ficar ocultos sozinhos). */
static void rota_ocultos(pedido_t *p, int mostrados) {
  static char nomes[MAX_OCULTOS][TAM_OCULTO];
  static pthread_mutex_t trava = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_lock(&trava);
  int qtd = 0;
  while(qtd < MAX_OCULTOS && param(p->corpo, "nome", qtd, nomes[qtd], sizeof nomes[qtd])) qtd++;
  int r = mostrados ? config_gravar_mostrados(nomes, qtd) : config_gravar_ocultos(nomes, qtd);
  pthread_mutex_unlock(&trava);
  if(r) {
    responder_erro(p, 400, "nome_invalido", "nome de arquivo invalido", NULL);
    return;
  }
  buf_t b = {0};
  buf_str(&b, "{\"ok\":true,");
  config_json(&b);
  buf_str(&b, "}");
  responder_json(p, 200, &b);
  buf_free(&b);
}

static void rota_renomear(pedido_t *p) {
  char pasta[1024] = "", de[300] = "", para[300] = "", tamanho[32] = "";
  param(p->corpo, "pasta", 0, pasta, sizeof pasta);
  param(p->corpo, "de", 0, de, sizeof de);
  param(p->corpo, "para", 0, para, sizeof para);
  long long tam = param(p->corpo, "tamanho", 0, tamanho, sizeof tamanho) && *tamanho ? atoll(tamanho) : -1;
  if(!arquivos_pasta_permitida(pasta) || !caminho_valido(pasta)) {   /* G5: so nas pastas da lista (0.9.49: e BACKUP/<jogo>/) */
    responder_erro(p, 200, "fora_das_pastas", "a pasta nao esta na lista de pastas", pasta);
    return;
  }
  ren_t r = arquivos_renomear(pasta, de, para, tam);
  if(r == REN_OK) {
    responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
    return;
  }
  const char *nome = r == REN_DESTINO_EXISTE ? para : de;
  char msg[400];
  snprintf(msg, sizeof msg, "%s: %s", ren_chave(r), r == REN_FALHOU ? strerror(errno) : nome);
  responder_erro(p, 200, ren_chave(r), msg, nome);
}

/* memmem nao existe na libc do PS5 */
static int contem(const char *d, size_t n, const char *s) {
  size_t m = strlen(s);
  for(size_t i = 0; i + m <= n; i++) if(!memcmp(d + i, s, m)) return 1;
  return 0;
}

/* Nome, Title ID e icone de dentro do arquivo do jogo (sem internet); so arquivos das pastas configuradas. */
static void rota_local(pedido_t *p) {
  char pasta[1024] = "", nome[300] = "", caminho[1400], icones[600], formato[16] = "";
  param(p->query, "pasta", 0, pasta, sizeof pasta);
  param(p->query, "nome", 0, nome, sizeof nome);
  int permitida = arquivos_pasta_permitida(pasta);   /* 0.9.49: e BACKUP/<jogo>/ */
  size_t np = strlen(pasta);
  while(np > 1 && pasta[np - 1] == '/') pasta[--np] = 0;   /* "/data/homebrew/" = "/data/homebrew" */
  if(!permitida || !caminho_valido(pasta) || !nome_valido(nome)) {
    responder_erro(p, 400, "requisicao_invalida", "pasta ou nome invalido", NULL);
    return;
  }
  snprintf(caminho, sizeof caminho, "%s/%s", strcmp(pasta, "/") ? pasta : "", nome);
  arquivo_dados(icones, sizeof icones, "icones");
  info_jogo_t info;
  buf_t b = {0};
  if(jogo_local(caminho, icones, &info, formato, sizeof formato)) {
    buf_str(&b, "{\"ok\":true,\"achou\":false}");
  } else {
    buf_str(&b, "{\"ok\":true,\"achou\":true,\"title_id\":");
    buf_json(&b, info.title_id);
    buf_str(&b, ",\"nome\":");
    buf_json(&b, info.nome);
    buf_str(&b, ",\"content_id\":");
    buf_json(&b, info.content_id);
    buf_str(&b, ",\"formato\":");
    buf_json(&b, formato);
    buf_str(&b, ",\"versao\":");      /* 0.9.37: versao e firmware minimo do proprio jogo */
    buf_json(&b, info.versao);
    buf_str(&b, ",\"fw_local\":");
    buf_json(&b, info.fw_minimo);
    snprintf(icones + strlen(icones), sizeof icones - strlen(icones), "/%s.png", info.title_id);
    struct stat st;
    buf_fmt(&b, ",\"icone\":%s}", stat(icones, &st) ? "false" : "true");
  }
  responder_json(p, 200, &b);
  buf_free(&b);
}

static void rota_web(pedido_t *p) {
  /* Paginas dos sites de patches (nome do publisher e URL do icone); a pagina le o HTML. */
  char url[2048];
  /* so os sites de patches: nada do GitHub (base, versoes, apps) nem do teste de internet */
  if(!param(p->query, "url", 0, url, sizeof url) || !url_permitida(url) || strncmp(url, "https://", 8) || strstr(url, "github") ||
     strstr(url, "speed.cloudflare")) {
    responder(p, 403, "text/plain", "", 0, NULL);
    return;
  }
  buf_t b = {0};
  int status = https_get(url, &b, MAX_PAGINA, 30);
  if(status == 200 && !(b.n && contem(b.d, b.n, "og:title"))) {   /* pagina sem os dados do jogo: registra o que veio */
    const unsigned char *d = (const unsigned char *)(b.d ? b.d : "");
    diario("pagina %.80s: veio sem og:title (%zu bytes, inicio %02x%02x%02x%02x)", url, b.n, b.n > 0 ? d[0] : 0,
           b.n > 1 ? d[1] : 0, b.n > 2 ? d[2] : 0, b.n > 3 ? d[3] : 0);
  } else if(status < 0) {
    diario("pagina %.80s: falhou", url);
  }
  if(status < 0) responder(p, 502, "text/plain", "", 0, NULL);
  /* W4: texto puro - o HTML de terceiros nunca roda na origem do glibren (a pagina so le o texto) */
  else responder(p, status, "text/plain; charset=utf-8", b.d ? b.d : "", b.n, NULL);
  buf_free(&b);
}

static void rota_cache_gravar(pedido_t *p) {
  char arquivo[600], tmp[610];
  arquivo_dados(arquivo, sizeof arquivo, "cache_consultas.json");
  snprintf(tmp, sizeof tmp, "%s.tmp", arquivo);
  if(!p->corpo_n || p->corpo_n > MAX_CACHE || p->corpo[0] != '{') {
    responder_erro(p, 400, "requisicao_invalida", "requisicao invalida", NULL);
    return;
  }
  FILE *f = fopen(tmp, "wb");
  int ok = f && fwrite(p->corpo, 1, p->corpo_n, f) == p->corpo_n;
  if(f && fclose(f)) ok = 0;
  if(ok && !rename(tmp, arquivo)) responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  else responder_erro(p, 500, "falha_gravar", strerror(errno), NULL);
}

/* Copiar / mover / excluir em lote: tipo, destino e, para cada arquivo, pasta + de + para (na mesma ordem). */
static void rota_tarefas(pedido_t *p) {
  char tipo[16] = "", destino[1024] = "", pasta[1024], de[300], para[300];
  param(p->corpo, "tipo", 0, tipo, sizeof tipo);
  param(p->corpo, "destino", 0, destino, sizeof destino);
  tarefa_tipo_t tt = !strcmp(tipo, "copiar") ? TAR_COPIAR : !strcmp(tipo, "mover") ? TAR_MOVER : TAR_EXCLUIR;
  if(strcmp(tipo, "copiar") && strcmp(tipo, "mover") && strcmp(tipo, "excluir")) {
    responder_erro(p, 400, "requisicao_invalida", "tipo invalido", NULL);
    return;
  }
  /* cada recusa com o motivo, para a tela dizer o certo (antes tudo virava "ja estao nessa pasta") */
  int criadas = 0, mesma_pasta = 0, em_download = 0, fila_cheia = 0, invalidos = 0, fora = 0;
  int destino_ok = tt == TAR_EXCLUIR || (config_pasta_permitida(destino) && caminho_valido(destino));
  for(int i = 0; param(p->corpo, "pasta", i, pasta, sizeof pasta); i++) {
    de[0] = para[0] = 0;
    param(p->corpo, "de", i, de, sizeof de);
    param(p->corpo, "para", i, para, sizeof para);
    /* G5: origem (e destino de copiar/mover) so nas pastas da lista - o processo e root fora da jaula */
    if(!destino_ok || !arquivos_pasta_permitida(pasta) || !caminho_valido(pasta)) {   /* 0.9.49: origem em BACKUP/<jogo>/ */
      fora++;
      continue;
    }
    /* copiar/mover um arquivo que ja esta na pasta de destino: ignorado (nunca vira renomear) */
    if(tt != TAR_EXCLUIR && !strcmp(pasta, destino)) {
      mesma_pasta++;
      continue;
    }
    int r = tarefas_adicionar(tt, pasta, de, destino, para);
    if(r > 0) criadas++;
    else if(r == TAR_R_EM_DOWNLOAD) em_download++;
    else if(r == TAR_R_FILA_CHEIA) fila_cheia++;
    else invalidos++;
  }
  int recusadas = mesma_pasta + em_download + fila_cheia + invalidos + fora;
  if(fora) diario("tarefas: %d recusada(s) fora das pastas da lista (destino %.200s)", fora, destino);
  buf_t b = {0};
  buf_fmt(&b, "{\"ok\":%s,\"criadas\":%d,\"recusadas\":%d,\"motivos\":{\"mesma_pasta\":%d,\"em_download\":%d,"
          "\"fila_cheia\":%d,\"invalido\":%d,\"fora_das_pastas\":%d}}", criadas ? "true" : "false", criadas, recusadas,
          mesma_pasta, em_download, fila_cheia, invalidos, fora);
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* ATIVAR: copia um jogo "so armazenado" para uma pasta do ShadowMount escolhida aqui, sem perguntar.
   Destino: entre as pastas marcadas (fora a de origem) que existem e ainda nao tem esse arquivo, a que fica com mais
   espaco livre depois do que a fila ja prometeu (tarefas_reservado); precisa caber o arquivo + MARGEM_ATIVAR.
   E sempre COPIA (o original fica onde esta). */
#define MARGEM_ATIVAR (512LL * 1024 * 1024)

static void erro_ativar(pedido_t *p, const char *chave, const char *msg, long long precisa, long long maior) {
  buf_t b = {0};
  buf_str(&b, "{\"ok\":false,\"chave\":");
  buf_json(&b, chave);
  buf_str(&b, ",\"erro\":");
  buf_json(&b, msg);
  buf_fmt(&b, ",\"params\":{\"precisa\":%lld,\"maior\":%lld}}", precisa, maior);
  responder_json(p, 200, &b);
  buf_free(&b);
}

static void rota_ativar(pedido_t *p) {
  char pasta[1024] = "", nome[300] = "", origem[1400], alvo[1400], monit[MAX_PASTAS][1024];
  param(p->corpo, "pasta", 0, pasta, sizeof pasta);
  param(p->corpo, "nome", 0, nome, sizeof nome);
  struct stat st;
  size_t np = strlen(pasta);
  snprintf(origem, sizeof origem, "%s%s%s", pasta, (np && pasta[np - 1] == '/') ? "" : "/", nome);
  if(!config_pasta_permitida(pasta)) {   /* G5 */
    erro_ativar(p, "fora_das_pastas", "a pasta nao esta na lista de pastas", 0, 0);
    return;
  }
  if(!caminho_valido(pasta) || !nome_valido(nome) || lstat(origem, &st) || !S_ISREG(st.st_mode)) {
    erro_ativar(p, "ativar_origem", "o arquivo nao existe mais", 0, 0);
    return;
  }
  int qtd = config_monitoradas(monit, MAX_PASTAS);
  if(!qtd) {
    erro_ativar(p, "ativar_sem_pasta", "nenhuma pasta marcada como do ShadowMount", 0, 0);
    return;
  }
  for(int i = 0; i < qtd; i++) {
    if(!strcmp(monit[i], pasta)) {
      erro_ativar(p, "ativar_ja_ativo", "o jogo ja esta numa pasta do ShadowMount", 0, 0);
      return;
    }
  }
  if(tarefas_tem(pasta, nome)) {
    erro_ativar(p, "ativar_na_fila", "este arquivo ja esta na fila", 0, 0);
    return;
  }
  long long precisa = (long long)st.st_size + MARGEM_ATIVAR, maior = -1;
  int escolhida = -1, validas = 0;
  for(int i = 0; i < qtd; i++) {
    size_t n = strlen(monit[i]);
    snprintf(alvo, sizeof alvo, "%s%s%s", monit[i], (n && monit[i][n - 1] == '/') ? "" : "/", nome);
    struct stat sd;
    if(!lstat(alvo, &sd)) {   /* mesmo nome numa pasta do ShadowMount: ja esta ativo la (nunca sobrescreve) */
      erro_ativar(p, "ativar_ja_ativo", "ja existe uma copia ativa deste arquivo", 0, 0);
      return;
    }
    struct statvfs v;
    if(stat(monit[i], &sd) || !S_ISDIR(sd.st_mode) || statvfs(monit[i], &v)) continue;   /* disco desligado */
    validas++;
    long long livre = (long long)v.f_bavail * (long long)v.f_frsize - tarefas_reservado(monit[i]);
    if(livre > maior) {
      maior = livre;
      if(livre >= precisa) escolhida = i;
    }
  }
  if(!validas) {
    erro_ativar(p, "ativar_sem_disco", "as pastas do ShadowMount nao estao acessiveis", 0, 0);
    return;
  }
  long long maior_livre = maior > 0 ? maior : 0;
  if(escolhida < 0) {
    diario("ativar: %s sem espaco (precisa %lld, maior livre %lld)", nome, precisa, maior_livre);
    erro_ativar(p, "ativar_sem_espaco", "sem espaco nas pastas do ShadowMount", precisa, maior_livre);
    return;
  }
  int id = tarefas_adicionar(TAR_COPIAR, pasta, nome, monit[escolhida], "");
  if(id <= 0) {
    if(id == TAR_R_EM_DOWNLOAD) erro_ativar(p, "em_download", "o arquivo ainda esta sendo baixado", 0, 0);
    else erro_ativar(p, "ativar_origem", "nao foi possivel por na fila", 0, 0);
    return;
  }
  diario("ativar: %s de %s para %s (precisa %lld com margem, livre %lld)", nome, pasta, monit[escolhida], precisa, maior);
  buf_t b = {0};
  buf_fmt(&b, "{\"ok\":true,\"id\":%d,\"destino\":", id);
  buf_json(&b, monit[escolhida]);
  buf_fmt(&b, ",\"livre\":%lld,\"precisa\":%lld}", maior, precisa);
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* Espaco livre da pasta (para a tela mostrar no destino). */
/* 0.9.48: GET /api/pasta-info?pasta=&nome= : arquivos e bytes de uma pasta de jogo (para a confirmacao do Excluir) e se
   o ShadowMount+/ShadowKraken a tem montada. So pasta de jogo, so nas pastas da lista. */
static void rota_pasta_info(pedido_t *p) {
  char pasta[1024] = "", nome[300] = "", caminho[1400];
  param(p->query, "pasta", 0, pasta, sizeof pasta);
  param(p->query, "nome", 0, nome, sizeof nome);
  if(!arquivos_pasta_permitida(pasta) || !caminho_valido(pasta) || !nome_valido(nome)) {
    responder_erro(p, 400, "requisicao_invalida", "pasta ou nome invalido", NULL);
    return;
  }
  snprintf(caminho, sizeof caminho, "%s%s%s", pasta, pasta[strlen(pasta) - 1] == '/' ? "" : "/", nome);
  struct stat st;
  if(lstat(caminho, &st) || !S_ISDIR(st.st_mode) || !arquivos_pasta_de_jogo(caminho)) {
    responder_erro(p, 404, "nao_pasta_de_jogo", "nao e uma pasta de jogo", nome);
    return;
  }
  long long arquivos = 0, bytes = 0;
  int m = tarefas_pasta_medir(caminho, &arquivos, &bytes);
  char motivo[24];
  int uso = backup_em_uso(caminho, motivo, sizeof motivo);
  buf_t b = {0};
  buf_fmt(&b, "{\"ok\":true,\"arquivos\":%lld,\"bytes\":%lld,\"outro_disco\":%s,\"leu_tudo\":%s,\"em_uso\":%s,\"motivo\":",
          arquivos, bytes, m == -2 ? "true" : "false", m ? "false" : "true", uso ? "true" : "false");
  buf_json(&b, motivo);
  buf_str(&b, "}");
  responder_json(p, 200, &b);
  buf_free(&b);
}

static void rota_espaco(pedido_t *p) {
  char caminho[1024] = "/";
  param(p->query, "caminho", 0, caminho, sizeof caminho);
  struct statvfs v;
  buf_t b = {0};
  if(!caminho_valido(caminho) || statvfs(caminho, &v)) buf_str(&b, "{\"ok\":false}");
  else buf_fmt(&b, "{\"ok\":true,\"livre\":%lld,\"total\":%lld}", (long long)v.f_bavail * (long long)v.f_frsize,
               (long long)v.f_blocks * (long long)v.f_frsize);
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* ------------------------------------------------------------------ POST /launch (so do proprio PS5) */

/* Titulos que /launch pode abrir: Jobe, YouTube Max'd, ytps5 e o icone do glibren. Nada alem disso. */
static const char *const LANCAVEIS[] = {"PPSA99471", "PPSA99991", "PPSA99350", GLIBREN_TITLE_ID};

static int espaco_json(char c) {
  return c == 0x20 || c == 0x09 || c == 0x0d || c == 0x0a;
}

/* Valor de um campo de titulo de um objeto JSON pequeno: {"title":"PPSA99991","from":"PPSA99471"}. So aceita
   4 letras maiusculas + 5 digitos (nada de escapes). 0 = achou e valido; 1 = campo ausente; -1 = invalido. */
static int json_titulo(const char *corpo, const char *campo, char *saida, size_t tam) {
  char chave[24];
  snprintf(chave, sizeof chave, "\"%s\"", campo);
  const char *p = corpo ? strstr(corpo, chave) : NULL;
  if(!p) return 1;
  if(tam < 10) return -1;
  p += strlen(chave);
  while(espaco_json(*p)) p++;
  if(*p++ != ':') return -1;
  while(espaco_json(*p)) p++;
  if(*p++ != '"') return -1;
  for(int i = 0; i < 9; i++) {
    char c = p[i];
    if(i < 4 ? !(c >= 'A' && c <= 'Z') : !(c >= '0' && c <= '9')) return -1;
  }
  if(p[9] != '"') return -1;
  memcpy(saida, p, 9);
  saida[9] = 0;
  return 0;
}

/* Pedido de outro app do PS5 (ex.: o YouTube Max'd ao sair, para reabrir o glibren ou a Jobe quando ele mesmo nao
   consegue lancar): POST /launch, Content-Type application/json, corpo {"title":"PPSA....."}.
   - so conexoes de 127.0.0.0/8 com Host 127.0.0.1 ou localhost (do PC/celular, ou outro Host: 403);
   - Content-Type application/json obrigatorio: um site aberto no navegador do PS5 nao manda esse tipo sem a
     pre-checagem CORS (que este servidor nao autoriza), entao nao da para disparar por formulario;
   - so os titulos de LANCAVEIS; abre sem fechar nada (sceSystemServiceLaunchApp);
   - com "from" (o titulo aberto agora, ex.: o Max'd): responde {"ok":true,"pending":true} na hora e uma thread
     espera o "from" fechar (ate 2 min), espera ~15 s e abre com ate 4 tentativas (lancador.c, mesmo contrato do
     /switch do payload de fundo da Jobe). Um pedido novo substitui o pendente;
   - sem "from": so abre se nao houver app de jogo aberto; senao 409 {"error":"app_aberto"} (lancar por cima de
     outro app falha com 0x80940011/0x80940031 e e suspeito de derrubar o console). */
static void rota_launch(pedido_t *p) {
  char title[16] = "", from[16] = "", aberto[16] = "";
  if(!p->local) {
    responder_erro(p, 403, "so_local", "so aceito do proprio PS5 (127.0.0.1)", NULL);
    return;
  }
  /* Host do proprio PS5 (bloqueia DNS rebinding: um site que aponta o proprio nome para 127.0.0.1) */
  size_t n_host = strcspn(p->host, ":");
  if(!((n_host == 9 && !strncmp(p->host, "127.0.0.1", 9)) || (n_host == 9 && !strncasecmp(p->host, "localhost", 9)))) {
    responder_erro(p, 403, "so_local", "Host deve ser 127.0.0.1 ou localhost", NULL);
    return;
  }
  if(strncasecmp(p->tipo, "application/json", 16)) {
    responder_erro(p, 415, "tipo", "use Content-Type: application/json", NULL);
    return;
  }
  if(json_titulo(p->corpo, "title", title, sizeof title) || json_titulo(p->corpo, "from", from, sizeof from) < 0) {
    responder_erro(p, 400, "requisicao_invalida", "corpo esperado: {\"title\":\"PPSA00000\",\"from\":\"PPSA00000\"}", NULL);
    return;
  }
  size_t i = 0;
  while(i < sizeof LANCAVEIS / sizeof *LANCAVEIS && strcmp(title, LANCAVEIS[i])) i++;
  if(i == sizeof LANCAVEIS / sizeof *LANCAVEIS) {
    diario("launch: %s recusado (fora da lista)", title);
    responder_erro(p, 403, "fora_da_lista", "titulo fora da lista permitida", title);
    return;
  }
  buf_t b = {0};
  if(from[0]) {
    if(lancador_pedir(title, from)) {
      responder_erro(p, 500, "launch", "nao foi possivel agendar", title);
      return;
    }
    buf_str(&b, "{\"ok\":true,\"pending\":true,\"title\":");
    buf_json(&b, title);
    buf_str(&b, ",\"from\":");
    buf_json(&b, from);
    buf_str(&b, "}");
    responder_json(p, 200, &b);
    buf_free(&b);
    return;
  }
  int aberto_r = app_de_jogo_aberto(aberto, sizeof aberto);
  if(aberto_r < 0) {   /* R7: sem como saber se ha app aberto, nao lanca */
    diario("launch: %s nao aberto: nao deu para saber se ha app aberto", title);
    responder_erro(p, 409, "app_desconhecido", "nao deu para saber se ha outro app aberto", title);
    return;
  }
  if(aberto_r == 1) {
    diario("launch: %s nao aberto: %s esta aberto (mande \"from\" para esperar ele fechar)", title, aberto);
    buf_str(&b, "{\"ok\":false,\"error\":\"app_aberto\",\"chave\":\"app_aberto\",\"erro\":\"outro app esta aberto\",\"open\":");
    buf_json(&b, aberto);
    buf_str(&b, ",\"params\":{\"nome\":");
    buf_json(&b, aberto);
    buf_str(&b, "}}");
    responder_json(p, 409, &b);
    buf_free(&b);
    return;
  }
  int r = abrir_app(title);
  diario("launch: pedido local para abrir %s -> 0x%08x", title, (unsigned)r);
  if(r) {
    char msg[96];
    snprintf(msg, sizeof msg, "o PS5 nao abriu %s (0x%08x)", title, (unsigned)r);
    responder_erro(p, 502, "launch", msg, title);
    return;
  }
  buf_str(&b, "{\"ok\":true,\"title\":");
  buf_json(&b, title);
  buf_str(&b, "}");
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* G4 (DNS rebinding): um site que aponta o proprio nome para o IP do PS5 vira "mesma origem" e manda X-GLR. O
   navegador sempre manda o Host com o nome que abriu; entao so vale Host que e IP literal (IPv4 ou [IPv6], como o
   http://IP-DO-PS5:8765 do PC/celular e o 127.0.0.1 do proprio PS5) ou localhost, com ou sem :porta. Sem Host
   (cliente que nao e navegador, ex.: HTTP/1.0) passa: o ataque precisa de um navegador. */
static int host_permitido(const char *host) {
  char nome[128];
  const char *porta;
  if(!host[0]) return 1;
  if(host[0] == '[') {
    const char *fim = strchr(host, ']');
    if(!fim || (size_t)(fim - host - 1) >= sizeof nome) return 0;
    memcpy(nome, host + 1, (size_t)(fim - host - 1));
    nome[fim - host - 1] = 0;
    struct in6_addr a6;
    if(inet_pton(AF_INET6, nome, &a6) != 1) return 0;
    porta = fim + 1;
  } else {
    size_t n = strcspn(host, ":");
    if(!n || n >= sizeof nome) return 0;
    memcpy(nome, host, n);
    nome[n] = 0;
    struct in_addr a4;
    if(strcasecmp(nome, "localhost") && inet_pton(AF_INET, nome, &a4) != 1) return 0;
    porta = host + n;
  }
  if(!*porta) return 1;
  if(*porta++ != ':' || !*porta) return 0;
  for(; *porta; porta++)
    if(!isdigit((unsigned char)*porta)) return 0;
  return 1;
}

/* 0.9.16: acoes que apagam, movem, renomeiam, atualizam, ejetam, ativam ou trocam de app (e desligar/parar o
   payload) pedem um aparelho pareado (pareamento.c). Pedidos de 127.0.0.1 ficam isentos.
   0.9.17: baixar o catalogo de cheats tambem (troca a pasta /data/glibren/cheats/json inteira e baixa ~14 MB).
   0.9.18: ligar e desligar cheats (grava na memoria do jogo).
   0.9.21: colar/remover a chave do GitHub e enviar o diagnostico.
   0.9.22: gravar a configuracao do PrefBar (/data/prefbar/prefbar.conf).
   0.9.24: abrir o navegador do PS5 numa pagina da lista fixa (Jobe web, Jobe /teste, glibren).
   0.9.25: ligar/desligar a area extra (teste) das cheats.
   0.9.27: ligar o payload da Jobe (bg-downloader) que ja esta no PS5.
   0.9.37: gravar os resultados da consulta de versoes feita pelo celular/PC (POST /api/versoes).
   0.9.54: adicionar/remover pastas vigiadas pelo ShadowKraken.
   0.9.56: ligar/desligar os jogos instalados pelo sistema no ShadowKraken. */
static int rota_protegida(const char *c) {
  static const char *const ROTAS[] = {"/api/tarefas", "/api/renomear", "/api/ativar", "/api/atualizar", "/api/apps/instalar",
                                      "/api/apps/desinstalar", "/api/discos/ejetar", "/api/youtube", "/api/youtube/maxd",
                                      "/api/energia", "/api/sair", "/api/cheats/catalogo", "/api/cheats/ligar",
                                      "/api/cheats/desligar", "/api/payloads/baixar", "/api/payloads/ativar", "/api/payloads/voltar", "/api/payloads/remover", "/api/payloads/procurar",
                                      "/api/diagnostico/chave", "/api/diagnostico/chave/remover", "/api/diagnostico/enviar",
                                      "/api/prefbar/conf", "/api/navegador/abrir", "/api/cheats/area-extra", "/api/jobe-payload/ligar",
                                      "/api/conversao", "/api/conversao/cancelar", "/api/conversao/limpar", "/api/conversao/padrao",
                                      "/api/conversao/backup", "/api/conversao/mover", "/api/conversao/instalar", "/api/payloads/autoload", "/api/payloads/arquivo", "/api/payloads/enviar", "/api/versoes",
                                      "/api/ampr/enviar", "/api/ampr/arquivo", "/api/ampr/embutido", "/api/ampr/backport", "/api/ampr/lista", "/api/coredump/enviar", "/api/coredump/apagar", "/api/coredump/travar",
                                      "/api/sk/pastas/adicionar", "/api/sk/pastas/remover", "/api/sk/instalados", NULL};
  for(int i = 0; ROTAS[i]; i++)
    if(!strcmp(c, ROTAS[i])) return 1;
  return 0;
}

void api_tratar(pedido_t *p) {
  char arquivo[600];
  if(!host_permitido(p->host)) {
    static time_t avisado;
    if(time(NULL) - avisado > 60) {   /* uma linha por minuto no maximo */
      avisado = time(NULL);
      char h[64];
      snprintf(h, sizeof h, "%s", p->host);
      for(char *c = h; *c; c++) if(*c < ' ' || *c > '~') *c = '?';
      diario("pedido recusado: Host \"%s\" (so IP ou localhost)", h);
    }
    static const char msg[] = "Host recusado: abra pelo IP do PS5\n";
    responder(p, 403, "text/plain", msg, sizeof msg - 1, NULL);
    return;
  }
  int get = !strcmp(p->metodo, "GET") || !strcmp(p->metodo, "HEAD");
  int post = !strcmp(p->metodo, "POST");

  if(get && (!strcmp(p->caminho, "/") || !strcmp(p->caminho, "/index.html"))) {
    responder_pagina(p, web_index_html, web_index_html_len, web_index_gz, web_index_gz_len);
  } else if(get && (!strcmp(p->caminho, "/favicon.ico") || !strcmp(p->caminho, "/icone.png"))) {
    responder(p, 200, "image/png", web_icone_png, web_icone_png_len, "max-age=86400");
  } else if(get && !strcmp(p->caminho, "/teste-tela-cheia")) {
    responder_pagina(p, web_telacheia_html, web_telacheia_html_len, web_telacheia_gz, web_telacheia_gz_len);
  } else if(get && !strcmp(p->caminho, "/api/diag")) {
    /* linhas de diagnostico das paginas de teste (ex.: tela cheia) para o diario; limite contra abuso */
    static time_t janela;
    static int qtd;
    char msg[400] = "";
    param(p->query, "msg", 0, msg, sizeof msg);
    for(char *c = msg; *c; c++) if((unsigned char)*c < ' ') *c = ' ';
    if(time(NULL) - janela > 60) {
      janela = time(NULL);
      qtd = 0;
    }
    if(msg[0] && qtd++ < 60) diario("diag: %s", msg);
    responder(p, 204, "text/plain", "", 0, NULL);
  } else if(get && !strcmp(p->caminho, "/youtube")) {
    /* pagina de teste: o PS5 toca o player embutido do YouTube? */
    responder_pagina(p, web_youtube_html, web_youtube_html_len, web_youtube_gz, web_youtube_gz_len);
  } else if(get && !strcmp(p->caminho, "/diario")) {
    /* diario do payload (glibren.log): passos, falhas de rede e quedas - para ver sem FTP */
    arquivo_dados(arquivo, sizeof arquivo, "glibren.log");
    if(responder_arquivo(p, arquivo, "text/plain; charset=utf-8", "no-store"))
      responder(p, 200, "text/plain; charset=utf-8", "(diario vazio)\n", 15, NULL);
  } else if(get && !strcmp(p->caminho, "/app-log")) {
    /* diagnostico dos apps de YouTube: hora do PS5 + final do yt.log do ytps5 (com o app aberto) */
    char id[48] = "ytps5";
    param(p->query, "id", 0, id, sizeof id);
    buf_t b = {0};
    apps_log(id, &b);
    responder(p, 200, "text/plain; charset=utf-8", b.d, b.n, "no-store");
    buf_free(&b);
  } else if(get && !strcmp(p->caminho, "/api/estado")) {
    rota_estado(p);
  } else if(get && !strcmp(p->caminho, "/api/fs")) {
    rota_fs(p);
  } else if(get && !strcmp(p->caminho, "/api/tarefas")) {
    buf_t b = {0};
    tarefas_json(&b);
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(get && !strcmp(p->caminho, "/api/termico")) {
    char hist[4] = "";
    param(p->query, "historico", 0, hist, sizeof hist);
    buf_t b = {0};
    termico_json(&b, hist[0] == '1');
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(get && (!strcmp(p->caminho, "/fps") || !strcmp(p->caminho, "/api/fps"))) {
    /* FPS do jogo aberto (teste, 0.9.14; capa e pagina nova na 0.9.15): so para o celular/PC - nada aparece nem e lido pelo navegador do PS5 */
    if(fps_agente_ps5(p->agente)) {
      static const char msg[] = "A pagina de FPS e so para o celular ou o PC (nada aparece na tela do PS5)\n";
      responder(p, 403, "text/plain; charset=utf-8", msg, sizeof msg - 1, NULL);
    } else if(!strcmp(p->caminho, "/fps")) {
      responder_pagina(p, web_fps_html, web_fps_html_len, web_fps_gz, web_fps_gz_len);
    } else {
      char hist[4] = "";
      param(p->query, "historico", 0, hist, sizeof hist);
      buf_t b = {0};
      fps_json(&b, hist[0] == '1');
      responder_json(p, 200, &b);
      buf_free(&b);
    }
  } else if(get && (!strcmp(p->caminho, "/cheats") || !strcmp(p->caminho, "/api/cheats"))) {
    /* Cheats do jogo aberto (teste; leitura aqui, escrita nas rotas POST): so para o celular/PC, como o FPS */
    if(fps_agente_ps5(p->agente)) {
      static const char msg[] = "A pagina de cheats e so para o celular ou o PC (nada aparece na tela do PS5)\n";
      responder(p, 403, "text/plain; charset=utf-8", msg, sizeof msg - 1, NULL);
    } else if(!strcmp(p->caminho, "/cheats")) {
      responder_pagina(p, web_cheats_html, web_cheats_html_len, web_cheats_gz, web_cheats_gz_len);
    } else {
      buf_t b = {0};
      cheats_json(&b);
      responder_json(p, 200, &b);
      buf_free(&b);
    }
  } else if(get && !strcmp(p->caminho, "/payloads")) {
    /* 0.9.20: payloads de terceiros para teste (catalogo fixo em payloads.c) */
    responder_pagina(p, web_payloads_html, web_payloads_html_len, web_payloads_gz, web_payloads_gz_len);
  } else if(get && !strcmp(p->caminho, "/api/payloads/arquivos")) {
    /* 0.9.41: .elf nos discos para "Instalar de arquivo". Le e confere o SHA-256 de ate 50 arquivos: so aparelho pareado
       (ou o proprio PS5), para nao virar carga de disco sem autenticacao */
    if(!pareamento_permitido(p)) pareamento_recusar(p);
    else payloads_rota_arquivos(p);
  } else if(get && !strcmp(p->caminho, "/api/payloads")) {
    payloads_rota_estado(p);
  } else if(get && !strcmp(p->caminho, "/api/conversao")) {
    conversao_rota_estado(p);
  } else if(get && !strcmp(p->caminho, "/api/jobe-payload")) {
    jobe_payload_rota_estado(p);   /* 0.9.27: no ar / fora do ar e a copia que seria enviada (leitura livre) */
  } else if(get && !strcmp(p->caminho, "/api/prefbar/conf")) {
    prefbar_rota_ler(p);   /* 0.9.22: leitura livre (so a configuracao de exibicao do PrefBar) */
  } else if(get && !strcmp(p->caminho, "/diagnostico")) {
    responder_pagina(p, web_diagnostico_html, web_diagnostico_html_len, web_diagnostico_gz, web_diagnostico_gz_len);
  } else if(get && !strcmp(p->caminho, "/api/diagnostico")) {
    diagnostico_rota_estado(p);   /* nunca devolve a chave: so "configurada" e o final */
  } else if(get && !strcmp(p->caminho, "/api/coredump")) {
    coredump_rota_estado(p);      /* 0.9.59: dumps do CoreDump Dumper e o envio */
  } else if(get && !strcmp(p->caminho, "/api/diagnostico/zip")) {
    diagnostico_rota_zip(p);      /* os mesmos arquivos do envio, ja higienizados (leitura livre, como o /diario) */
  } else if(get && !strcmp(p->caminho, "/ps5tela.js")) {
    /* 0.9.20: botao de tela cheia das paginas no navegador do PS5 (aplica o ps5-web-browser-fullscreen e reabre) */
    responder(p, 200, "application/javascript; charset=utf-8", web_ps5tela_js, web_ps5tela_js_len, "no-cache");
  } else if(get && !strcmp(p->caminho, "/internet")) {
    responder_pagina(p, web_internet_html, web_internet_html_len, web_internet_gz, web_internet_gz_len);
  } else if(get && !strcmp(p->caminho, "/api/internet/servidores")) {
    buf_t b = {0};
    internet_servidores(&b);
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(get && !strcmp(p->caminho, "/api/internet")) {
    buf_t b = {0};
    internet_estado(&b);
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(get && !strcmp(p->caminho, "/discos")) {
    responder_pagina(p, web_discos_html, web_discos_html_len, web_discos_gz, web_discos_gz_len);
  } else if(get && (!strcmp(p->caminho, "/api/discos") || !strcmp(p->caminho, "/api/velocidade"))) {
    buf_t b = {0};
    if(!strcmp(p->caminho, "/api/discos")) discos_listar(&b);
    else discos_estado(&b);
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(get && !strcmp(p->caminho, "/temperatura")) {
    responder_pagina(p, web_temperatura_html, web_temperatura_html_len, web_temperatura_gz, web_temperatura_gz_len);
  } else if(get && !strcmp(p->caminho, "/api/espaco")) {
    rota_espaco(p);
  } else if(get && !strcmp(p->caminho, "/api/pasta-info")) {
    rota_pasta_info(p);   /* 0.9.48 */
  } else if(get && !strcmp(p->caminho, "/api/escanear")) {
    buf_t b = {0};
    arquivos_escanear(&b);
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(get && !strcmp(p->caminho, "/base_titulos.tsv")) {
    arquivo_dados(arquivo, sizeof arquivo, "base_titulos.tsv");
    if(responder_arquivo(p, arquivo, "text/tab-separated-values; charset=utf-8", "no-cache"))
      responder(p, 404, "text/plain", "", 0, NULL);
  } else if(get && !strncmp(p->caminho, "/icone/", 7)) {
    rota_icone(p, p->caminho + 7);
  } else if(get && !strcmp(p->caminho, "/api/versoes")) {
    versoes_rota_listar(p);   /* 0.9.37: leitura livre (jogos + versao local + resultados guardados) */
  } else if(get && !strcmp(p->caminho, "/api/local")) {
    rota_local(p);
  } else if(get && !strcmp(p->caminho, "/api/web")) {
    rota_web(p);
  } else if(get && !strcmp(p->caminho, "/api/navegador")) {
    /* a pagina conta se o navegador mostra .webp (os icones dos sites vem nesse formato); uma linha por navegador */
    static char ja[4][24];
    char webp[4] = "", ua[200] = "";
    param(p->query, "webp", 0, webp, sizeof webp);
    param(p->query, "ua", 0, ua, sizeof ua);
    for(char *c = ua; *c; c++) if(*c < ' ' || *c > '~') *c = '?';
    int i = 0;
    while(i < 4 && ja[i][0] && strncmp(ja[i], ua + (strlen(ua) > 23 ? strlen(ua) - 23 : 0), 23)) i++;
    if(i < 4 && !ja[i][0]) {
      snprintf(ja[i], sizeof ja[i], "%s", ua + (strlen(ua) > 23 ? strlen(ua) - 23 : 0));
      diario("navegador: webp %s (%s)", !strcmp(webp, "1") ? "sim" : "NAO", ua);
    }
    responder(p, 204, "text/plain", "", 0, NULL);
  } else if(get && !strcmp(p->caminho, "/api/cache")) {
    arquivo_dados(arquivo, sizeof arquivo, "cache_consultas.json");
    if(responder_arquivo(p, arquivo, "application/json; charset=utf-8", "no-store"))
      responder(p, 200, "application/json", "{}", 2, NULL);
  } else if(get && !strcmp(p->caminho, "/api/pareamento")) {
    pareamento_rota_estado(p);
  } else if(get && !strcmp(p->caminho, "/api/sk/pastas")) {
    sk_pastas_rota_estado(p);    /* 0.9.54: pastas vigiadas pelo ShadowKraken (pela API dele) */
  } else if(get && !strcmp(p->caminho, "/api/sk/pastas/conferir")) {
    sk_pastas_rota_conferir(p);  /* 0.9.54: pode/avisos antes de perguntar ao dono */
  } else if(get && !strcmp(p->caminho, "/api/ampr/backports")) {
    ampr_backports_rota_estado(p);   /* 0.9.57: backports achados + o runtime que seria copiado */
  } else if(get && !strcmp(p->caminho, "/api/ampr")) {
    ampr_teste_rota_estado(p);   /* 0.9.51: build de teste do ampr-emu-ng no ShadowKraken + copias do trace */
  } else if(get && !strcmp(p->caminho, "/api/primeiro-plano")) {
    /* diagnostico do primeiro plano (kern.msgbuf): a pagina de FPS mostra no botao i */
    buf_t b = {0};
    primeiro_plano_json(&b);
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(get && !strcmp(p->caminho, "/api/dns")) {
    /* diagnostico do DNS robusto (so os hosts da lista: GitHub, catalogo e icones) */
    char host[128] = "";
    param(p->query, "host", 0, host, sizeof host);
    buf_t b = {0};
    dns_json(host, &b);
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(get && !strcmp(p->caminho, "/api/launch")) {
    /* estado do pedido pendente do POST /launch (diagnostico) */
    buf_t b = {0};
    buf_str(&b, "{\"ok\":true,\"estado\":");
    buf_json(&b, lancador_estado());
    buf_str(&b, "}");
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(post && !strcmp(p->caminho, "/launch")) {
    rota_launch(p);   /* outro app do PS5 (sem X-GLR): protecao propria (127.0.0.1 + JSON + lista) */
  } else if(post && !p->pedido_do_app) {
    /* Sem o cabecalho X-GLR: formulario de outro site tentando mexer no PS5. */
    responder(p, 403, "text/plain", "", 0, NULL);
  } else if(post && rota_protegida(p->caminho) && !pareamento_permitido(p)) {
    pareamento_recusar(p);   /* 401 parear_necessario: a pagina pede o codigo mostrado na TV */
  } else if(post && !strcmp(p->caminho, "/api/parear/pedir")) {
    pareamento_rota_pedir(p);
  } else if(post && !strcmp(p->caminho, "/api/parear")) {
    pareamento_rota_conferir(p);
  } else if(post && !strcmp(p->caminho, "/api/parear/esquecer")) {
    pareamento_rota_esquecer(p);
  } else if(post && !strcmp(p->caminho, "/api/discos/ejetar")) {
    char caminho[256] = "", forcar[4] = "";
    param(p->corpo, "caminho", 0, caminho, sizeof caminho);
    param(p->corpo, "forcar", 0, forcar, sizeof forcar);
    buf_t b = {0};
    discos_ejetar(caminho, !strcmp(forcar, "1"), &b);
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(post && !strcmp(p->caminho, "/api/pastas")) {
    rota_pastas(p, 0);
  } else if(post && !strcmp(p->caminho, "/api/monitoradas")) {
    rota_pastas(p, 1);
  } else if(post && !strcmp(p->caminho, "/api/ocultos")) {
    rota_ocultos(p, 0);
  } else if(post && !strcmp(p->caminho, "/api/mostrados")) {
    rota_ocultos(p, 1);
  } else if(post && !strcmp(p->caminho, "/api/idioma")) {
    char idioma[16] = "";
    param(p->corpo, "idioma", 0, idioma, sizeof idioma);
    if(config_gravar(NULL, 0, idioma)) responder_erro(p, 400, "idioma_invalido", "idioma invalido", NULL);
    else responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && (!strcmp(p->caminho, "/api/termico/limite") || !strcmp(p->caminho, "/api/termico/alerta"))) {
    char c[8] = "", msg[200] = "";
    param(p->corpo, "c", 0, c, sizeof c);
    int r = strstr(p->caminho, "limite") ? termico_definir_limite(atoi(c), msg, sizeof msg) : termico_definir_alerta(atoi(c));
    if(r) responder_erro(p, 200, "ventoinha", msg[0] ? msg : "valor invalido", NULL);
    else {
      buf_t b = {0};
      termico_json(&b, 0);
      responder_json(p, 200, &b);
      buf_free(&b);
    }
  } else if(post && !strcmp(p->caminho, "/api/internet")) {
    char msg[200] = "", servidor[128] = "";
    param(p->corpo, "servidor", 0, servidor, sizeof servidor);
    if(internet_testar(servidor, msg, sizeof msg)) responder_erro(p, 200, "internet", msg, NULL);
    else responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && !strcmp(p->caminho, "/api/internet/cancelar")) {
    internet_cancelar();
    responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && !strcmp(p->caminho, "/api/velocidade")) {
    char caminho[256] = "", mb[8] = "", msg[200] = "";
    param(p->corpo, "caminho", 0, caminho, sizeof caminho);
    param(p->corpo, "mb", 0, mb, sizeof mb);
    if(discos_testar(caminho, atoi(mb), msg, sizeof msg)) responder_erro(p, 200, "velocidade", msg, NULL);
    else responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && !strcmp(p->caminho, "/api/velocidade/cancelar")) {
    discos_cancelar();
    responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && !strcmp(p->caminho, "/api/tarefas")) {
    rota_tarefas(p);
  } else if(post && !strcmp(p->caminho, "/api/ativar")) {
    rota_ativar(p);
  } else if(post && !strcmp(p->caminho, "/api/tarefas/cancelar")) {
    char id[16] = "";
    param(p->corpo, "id", 0, id, sizeof id);
    if(tarefas_cancelar(atoi(id))) responder_erro(p, 200, "tarefa_terminou", "a tarefa ja terminou", NULL);
    else responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && !strcmp(p->caminho, "/api/tarefas/cancelar-todas")) {
    buf_t b = {0};
    buf_fmt(&b, "{\"ok\":true,\"canceladas\":%d}", tarefas_cancelar_todas());
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(post && !strcmp(p->caminho, "/api/tarefas/limpar")) {
    tarefas_limpar_terminadas();
    responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && !strcmp(p->caminho, "/api/versoes")) {
    versoes_rota_gravar(p);   /* 0.9.37: pareamento + X-GLR (acima); quem consulta a Sony e o celular/PC */
  } else if(post && !strcmp(p->caminho, "/api/renomear")) {
    rota_renomear(p);
  } else if(post && !strcmp(p->caminho, "/api/cache")) {
    rota_cache_gravar(p);
  } else if(post && !strcmp(p->caminho, "/api/limpar-cache")) {
    arquivo_dados(arquivo, sizeof arquivo, "cache_consultas.json");
    unlink(arquivo);
    responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && !strcmp(p->caminho, "/api/atualizar-base")) {
    api_atualizar_base(1);
    responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(get && !strcmp(p->caminho, "/api/atualizacao")) {
    buf_t b = {0};
    atualizacao_estado(&b, strstr(p->query, "verificar=1") != NULL);
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(post && !strcmp(p->caminho, "/api/atualizar")) {
    char msg[200] = "";
    if(atualizacao_iniciar(msg, sizeof msg)) responder_erro(p, 200, "atualizacao", msg, NULL);
    else responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(get && !strcmp(p->caminho, "/api/apps")) {
    buf_t b = {0};
    apps_json(&b, strstr(p->query, "verificar=1") != NULL);
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(post && !strcmp(p->caminho, "/api/apps/instalar")) {
    char id[48] = "", msg[200] = "";
    param(p->corpo, "id", 0, id, sizeof id);
    if(apps_instalar(id, msg, sizeof msg)) responder_erro(p, 200, "apps", msg, NULL);
    else responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && !strcmp(p->caminho, "/api/apps/desinstalar")) {
    char id[48] = "", msg[200] = "";
    param(p->corpo, "id", 0, id, sizeof id);
    if(apps_desinstalar(id, msg, sizeof msg)) responder_erro(p, 200, "apps", msg, NULL);
    else responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && !strcmp(p->caminho, "/api/youtube/maxd")) {
    /* acao "YouTube" da janela Apps: abre a Jobe (com YouTube) ou o YouTube Max'd na busca (pode ser vazia), com
       voltar= o glibren */
    char busca[1024] = "", chave[32] = "", msg[200] = "";
    param(p->corpo, "busca", 0, busca, sizeof busca);
    buf_t b = {0};
    if(apps_youtube_maxd(busca, &b, chave, sizeof chave, msg, sizeof msg)) responder_erro(p, 200, chave, strcmp(chave, "app_aberto") ? msg : "outro app esta aberto", strcmp(chave, "app_aberto") ? NULL : msg);
    else responder_json(p, 200, &b);
    buf_free(&b);
  } else if(post && !strcmp(p->caminho, "/api/youtube")) {
    /* botao YouTube no PS5: grava a busca na Jobe (com YouTube) ou no app de YouTube instalado e abre o app */
    char busca[1024] = "", chave[32] = "", msg[200] = "";
    param(p->corpo, "busca", 0, busca, sizeof busca);
    buf_t b = {0};
    if(apps_youtube(busca, &b, chave, sizeof chave, msg, sizeof msg)) responder_erro(p, 200, chave, strcmp(chave, "app_aberto") ? msg : "outro app esta aberto", strcmp(chave, "app_aberto") ? NULL : msg);
    else responder_json(p, 200, &b);
    buf_free(&b);
  } else if(get && !strcmp(p->caminho, "/api/relogio")) {
    buf_t b = {0};
    buf_str(&b, "{\"ok\":true,");
    relogio_json(&b);
    buf_str(&b, "}");
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(post && (!strcmp(p->caminho, "/api/relogio") || !strcmp(p->caminho, "/api/relogio/conferir"))) {
    /* liga/desliga (auto=1|0) ou confere agora (espera o resultado: poucos segundos, ate ~30 s) */
    char ligado[4] = "";
    if(!strcmp(p->caminho, "/api/relogio/conferir")) relogio_conferir_agora();
    else if(!param(p->corpo, "auto", 0, ligado, sizeof ligado) || (strcmp(ligado, "0") && strcmp(ligado, "1")) ||
            relogio_definir_auto(ligado[0] == '1')) {
      responder_erro(p, 400, "relogio", "valor invalido", NULL);
      return;
    }
    buf_t b = {0};
    buf_str(&b, "{\"ok\":true,");
    relogio_json(&b);
    buf_str(&b, "}");
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if((get || post) && !strcmp(p->caminho, "/api/usb-temperatura")) {
    /* GET = ultimo resultado; POST = le agora (so leitura; alguns segundos no maximo) */
    /* recusado (copia/teste/outra leitura): "recusado" com o motivo e o ultimo resultado, nenhum comando ao disco */
    usb_temp_r r = post ? usb_temp_ler() : USB_TEMP_OK;
    buf_t b = {0};
    buf_str(&b, "{\"ok\":true,\"recusado\":");
    buf_json(&b, usb_temp_motivo(r));
    buf_str(&b, ",");
    usb_temp_json(&b);
    buf_str(&b, "}");
    responder_json(p, 200, &b);
    buf_free(&b);
  } else if(post && !strcmp(p->caminho, "/api/energia")) {
    /* desligar o PS5 ou modo de repouso (TV com defeito: sem o menu na tela). So POST com X-GLR, como o resto. */
    char acao[16] = "", msg[200] = "";
    param(p->corpo, "acao", 0, acao, sizeof acao);
    if(energia_pedir(acao, msg, sizeof msg)) responder_erro(p, 200, "energia", msg, NULL);
    else responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && !strcmp(p->caminho, "/api/cheats/catalogo")) {
    /* baixa o catalogo de cheats (HEN-Cheats-Collection) para /data/glibren/cheats; nada na memoria do jogo */
    char msg[200] = "";
    if(fps_agente_ps5(p->agente)) responder(p, 403, "text/plain", "", 0, NULL);
    else if(cheats_catalogo_baixar(msg, sizeof msg)) responder_erro(p, 200, "cheats", msg, NULL);
    else responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
  } else if(post && (!strcmp(p->caminho, "/api/cheats/ligar") || !strcmp(p->caminho, "/api/cheats/desligar"))) {
    /* 0.9.18 (Fase 1): grava na memoria do jogo. So do celular/PC pareado (rota_protegida acima): nunca do navegador
       do PS5 nem de outro programa do proprio PS5 (127.0.0.1, que o pareamento deixa passar). */
    if(fps_agente_ps5(p->agente) || p->local) {
      static const char msg[] = "{\"ok\":false,\"chave\":\"cheats_so_celular\",\"erro\":\"ligar e desligar cheats so pelo celular ou PC\",\"params\":{}}";
      responder(p, 403, "application/json", msg, sizeof msg - 1, NULL);
    } else {
      buf_t b = {0};
      int status = cheats_acao(!strcmp(p->caminho, "/api/cheats/ligar"), p->corpo, p->corpo ? p->corpo_n : 0, &b);
      responder_json(p, status, &b);
      buf_free(&b);
    }
  } else if(post && !strcmp(p->caminho, "/api/cheats/area-extra")) {
    /* 0.9.25: chave "Area extra (teste)" da pagina Cheats; como ligar/desligar: pareamento + X-GLR (acima) e nunca
       do navegador do PS5 nem de 127.0.0.1 */
    if(fps_agente_ps5(p->agente) || p->local) {
      static const char msg[] = "{\"ok\":false,\"chave\":\"cheats_so_celular\",\"erro\":\"a area extra so muda pelo celular ou PC\",\"params\":{}}";
      responder(p, 403, "application/json", msg, sizeof msg - 1, NULL);
    } else {
      buf_t b = {0};
      int status = cheats_area_extra_mudar(p->corpo, p->corpo ? p->corpo_n : 0, &b);
      responder_json(p, status, &b);
      buf_free(&b);
    }
  } else if(post && (!strcmp(p->caminho, "/api/payloads/baixar") || !strcmp(p->caminho, "/api/payloads/ativar"))) {
    /* 0.9.20: pareamento + X-GLR (acima); payloads.c recusa o navegador do PS5, menos o item de tela cheia */
    payloads_rota_acao(p, !strcmp(p->caminho, "/api/payloads/ativar"));
  } else if(post && !strcmp(p->caminho, "/api/payloads/arquivo")) {
    payloads_rota_arquivo(p);    /* 0.9.41: pareamento + X-GLR (acima); "Instalar de arquivo" (ShadowKraken, kstuff) */
  } else if(post && !strcmp(p->caminho, "/api/payloads/enviar")) {
    payloads_rota_enviar(p);     /* 0.9.45: pareamento + X-GLR (acima); "Enviar do celular/PC" (.elf no corpo) */
  } else if(post && !strcmp(p->caminho, "/api/ampr/enviar")) {
    ampr_teste_rota_enviar(p);   /* 0.9.51: pareamento + X-GLR (acima); build de teste do ampr-emu-ng (.sprx no corpo) */
  } else if(post && !strcmp(p->caminho, "/api/ampr/arquivo")) {
    ampr_teste_rota_arquivo(p);  /* 0.9.51: .sprx de um disco do PS5 */
  } else if(post && !strcmp(p->caminho, "/api/sk/instalados")) {
    sk_instalados_rota(p);       /* 0.9.56: [fpkg] installed do ShadowKraken (pareamento + X-GLR, acima) */
  } else if(post && (!strcmp(p->caminho, "/api/sk/pastas/adicionar") || !strcmp(p->caminho, "/api/sk/pastas/remover"))) {
    sk_pastas_rota_mudar(p, !strcmp(p->caminho, "/api/sk/pastas/adicionar"));   /* 0.9.54: pareamento + X-GLR (acima) */
  } else if(post && !strcmp(p->caminho, "/api/ampr/lista")) {
    ampr_lista_rota(p);          /* 0.9.58: listas por jogo do ShadowKraken (pareamento + X-GLR, acima) */
  } else if(post && !strcmp(p->caminho, "/api/ampr/backport")) {
    ampr_backport_rota(p);       /* 0.9.57: ampr-emu-ng no fakelib/ de um backport (pareamento + X-GLR, acima) */
  } else if(post && !strcmp(p->caminho, "/api/ampr/embutido")) {
    ampr_teste_rota_embutido(p); /* 0.9.51: volta ao ampr-emu-ng embutido no ShadowKraken */
  } else if(post && !strcmp(p->caminho, "/api/payloads/autoload")) {
    payloads_rota_autoload(p);   /* 0.9.41: pareamento + X-GLR (acima); chave "Carregar ao iniciar o glibren" */
  } else if(post && !strcmp(p->caminho, "/api/payloads/voltar")) {
    payloads_rota_voltar(p);     /* 0.9.33: pareamento + X-GLR (acima) */
  } else if(post && !strcmp(p->caminho, "/api/payloads/remover")) {
    payloads_rota_remover(p);    /* 0.9.34: pareamento + X-GLR (acima) */
  } else if(post && !strcmp(p->caminho, "/api/payloads/procurar")) {
    payloads_rota_procurar(p);   /* 0.9.33: pareamento + X-GLR (acima; o navegador do PS5 e local); cache de 1 h */
  } else if(post && !strcmp(p->caminho, "/api/conversao")) {
    conversao_rota_iniciar(p);
  } else if(post && !strcmp(p->caminho, "/api/conversao/cancelar")) {
    conversao_rota_cancelar(p);
  } else if(post && !strcmp(p->caminho, "/api/conversao/limpar")) {
    conversao_rota_limpar(p);
  } else if(post && !strcmp(p->caminho, "/api/conversao/padrao")) {
    conversao_rota_padrao(p);
  } else if(post && !strcmp(p->caminho, "/api/conversao/backup")) {
    conversao_rota_backup(p);
  } else if(post && !strcmp(p->caminho, "/api/conversao/mover")) {
    conversao_rota_mover(p);
  } else if(post && !strcmp(p->caminho, "/api/conversao/instalar")) {
    conversao_rota_instalar(p);   /* 0.9.41: pareamento + X-GLR (acima); .pkg pelo Dump Forge, um por vez */
  } else if(post && !strcmp(p->caminho, "/api/jobe-payload/ligar")) {
    jobe_payload_rota_ligar(p);   /* 0.9.27: pareamento + X-GLR (acima); confere a assinatura antes de enviar */
  } else if(post && !strcmp(p->caminho, "/api/navegador/abrir")) {
    payloads_rota_navegador(p);   /* 0.9.24: pareamento + X-GLR (acima); lista fixa; recusa com jogo aberto */
  } else if(post && !strcmp(p->caminho, "/api/prefbar/conf")) {
    prefbar_rota_gravar(p);   /* 0.9.22: pareamento + X-GLR (acima); valida e grava de forma atomica */
  } else if(post && !strcmp(p->caminho, "/api/diagnostico/chave")) {
    diagnostico_rota_chave(p);    /* 0.9.21: pareamento + X-GLR (acima) */
  } else if(post && !strcmp(p->caminho, "/api/diagnostico/chave/remover")) {
    diagnostico_rota_remover(p);
  } else if(post && !strcmp(p->caminho, "/api/coredump/enviar")) {
    coredump_rota_enviar(p);      /* 0.9.59: pareamento + X-GLR (acima) */
  } else if(post && !strcmp(p->caminho, "/api/coredump/apagar")) {
    coredump_rota_apagar(p);
  } else if(post && !strcmp(p->caminho, "/api/coredump/travar")) {
    coredump_rota_travar(p);      /* 0.9.60: GET /crash no ampr-emu-ng de depuracao */
  } else if(post && !strcmp(p->caminho, "/api/diagnostico/enviar")) {
    diagnostico_rota_enviar(p);
  } else if(post && !strcmp(p->caminho, "/api/sair")) {
    responder(p, 200, "application/json", "{\"ok\":true}", 11, NULL);
    servidor_parar();
  } else if(get || post) {
    responder(p, 404, "text/plain", "", 0, NULL);
  } else {
    responder(p, 405, "text/plain", "", 0, NULL);
  }
}
