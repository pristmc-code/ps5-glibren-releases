/* Game Library Renamer (payload PS5) - downloads HTTPS (base de titulos, paginas dos sites e icones).
   No PS5 usa as bibliotecas do proprio console (sceHttp2); no PC (teste) usa o curl. */
#pragma once

#include "util.h"

void https_iniciar(void);
/* So os sites que o app usa (lista fixa). Recusa "@" e, depois do host, so aceita fim, "/", "?", "#" ou ":porta". */
int url_permitida(const char *url);
/* Libera mais um host (sem a porta) - servidores de teste de internet da lista do speedtest.net. So valem para o
   teste de velocidade (https_fluxo); IP literal e recusado. */
void https_permitir_host(const char *host);
/* GET; o corpo vai para "saida" (ate max bytes). Devolve o status HTTP ou -1 (sem conexao).
   segundos: tempo maximo (por enquanto so no PC; no PS5 vale o padrao da sceHttp2). */
int https_get(const char *url, buf_t *saida, size_t max, int segundos);

/* Para o teste de internet: GET (corpo NULL) entregando os dados aos poucos para "recebeu" (sem guardar), ou POST
   do corpo inteiro (recebeu e chamado uma vez com dados NULL e n = bytes enviados). "recebeu" devolve 0 para
   continuar ou 1 para parar. Pode rodar em varias threads ao mesmo tempo. Devolve o status HTTP ou -1. */
typedef int (*https_recebeu_t)(const void *dados, size_t n, void *ctx);
int https_fluxo(const char *url, const void *corpo, size_t tam_corpo, https_recebeu_t recebeu, void *ctx);

/* Download grande em fluxo (zips dos apps): GET seguindo redirecionamentos SO para hosts permitidos; o corpo vai
   aos pedacos para "recebeu" (que pode parar devolvendo 1). So entrega o corpo da resposta final (status 200).
   Devolve o status HTTP final, ou -1 (sem conexao, redirecionamento para fora da lista ou erro no meio da leitura). */
int https_baixar(const char *url, https_recebeu_t recebeu, void *ctx);

/* Relogio: GET so para ler o cabecalho Date da resposta (corpo descartado). "data" recebe o valor (ex.:
   "Tue, 10 Nov 2026 11:22:33 GMT"). Devolve o status HTTP ou -1. */
int https_data(const char *url, char *data, size_t tam);

/* DNS por HTTPS (0.9.16, so o dns_resolver.c chama): POST de uma pergunta DNS. url (so testes no PC) ou nome + ip
   fixos (ex.: "cloudflare-dns.com", "1.1.1.1"). Devolve o tamanho da resposta em "resposta" ou -1. */
int https_doh(const char *url, const char *nome, const char *ip, const void *pergunta, size_t n, void *resposta, size_t max);
