# teste-pad 1.0

Payload de teste para PS5 que verifica se um payload consegue **criar um DualSense virtual e apertar um botão** usando só o método limpo: `open("/dev/hid")` + `ioctl()` feitos pelo próprio processo do payload.

**O que ele NÃO faz:** ptrace, injeção em outros processos, escrita na memória do kernel, mudança de ucred/authid ou code cave. Por isso pode falhar por falta de permissão. Se falhar, a resposta também serve, porque mostra até onde o método limpo chega no 12.00.

## O que ele faz (cerca de 7 s)

1. Mostra a notificação **"teste-pad: iniciando"**.
2. Lê o usuário em primeiro plano (`sceUserServiceGetForegroundUser`).
3. Abre `/dev/hid` e cria o controle virtual (ioctl `0xC018482A`). Se o PS5 recusar o usuário real, tenta de novo com o usuário 1 ("sem dono"), como o ps5-mcp faz no 13.60.
4. Envia o estado neutro a cada 8 ms durante 3 s (ioctl `0x8018482C`).
5. Aperta **DIREITA no direcional 2 vezes** (150 ms apertado, 500 ms de intervalo).
6. Espera 2 s, apaga o controle (ioctl `0x80104850`) e fecha `/dev/hid`. O controle é apagado em qualquer saída, inclusive em caso de erro ou sinal.
7. Mostra a notificação **"teste-pad: ok (handle N)"** ou **"teste-pad: falhou em <etapa> errno X"**.

Todos os códigos de retorno e valores de errno saem no stdout e são **acrescentados** em `/data/teste-pad.log`.

## O que você deve ver

- **Funcionou por completo:** na tela inicial, a seleção anda **duas vezes para a direita**.
- **Pode aparecer "Quem está usando este controle?"**: isso já mostra que a criação e o envio do estado funcionaram, porque o PS5 reconheceu o controle novo. Escolha seu perfil com o controle de verdade ou feche a pergunta. Nesse caso, a seleção talvez não ande.
- Se nada se mexer e a notificação disser "ok", o envio foi aceito, mas o sistema não usou o controle (falta ligar o controle ao usuário, ver abaixo).

## Como enviar

Igual aos outros payloads, pela porta **9021** (elfldr):

```
nc -q0 IP_DO_PS5 9021 < teste-pad.elf
```

Também dá para usar `make test PS5_HOST=IP_DO_PS5` ou o "Instalar de arquivo" do GL.

Deixe a **tela inicial** aberta (sem jogo) antes de enviar.

## O que mandar de volta

O arquivo **`/data/teste-pad.log`** (pelo FTP ou pelo diagnóstico do GL), além do que apareceu na tela: notificações, se a seleção andou e se surgiu a pergunta do controle.

## Passo 2 (opcional, desligado por padrão): ligar o controle ao usuário

Crie o arquivo vazio **`/data/teste-pad.bind`** (pelo FTP) e envie o payload de novo. Ele vai carregar `libSceMbus` **dentro do próprio processo** (`dlopen`/`dlsym`) e chamar `sceMbusBindDeviceWithUserId(handle, usuário)`.

Isso é experimental. O ps5-mcp usa o id do aparelho lido do klog, mas aqui usamos o handle como id. Observação: o `dlsym` do SDK localiza o símbolo **lendo** a tabela do módulo pelo kernel (só leitura, nenhuma escrita). Para desligar de novo, apague `/data/teste-pad.bind`.

## Como compilar

Com o ps5-payload-sdk aberto (`/opt/ps5-payload-sdk`):

```
make PS5_PAYLOAD_SDK=/opt/ps5-payload-sdk
```

## Créditos e licença

GPL-3.0-or-later. O código foi baseado em:

- **Darkatek7/ProsperoSunshine**: `src/platform/ps5/pad.c` (ioctls add/insert/delete, layout do bloco de 0xA8 bytes, sensor de movimento em repouso). GPL-3.0.
- **Gl0ttis/ps5-mcp**: `src/pad.c`, `src/pad.h`, `src/backend.h` (valores dos botões, reenvio a cada 8 ms, bind via libSceMbus). GPL-3.0-or-later.
