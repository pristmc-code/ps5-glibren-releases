/* Game Library Renamer (payload PS5) - 0.9.64: bateria automatica de testes (compatibilidade e desempenho do
ampr-emu-ng por formato de jogo), sem o dono apertar botao. Desenho: ps5/contribuicoes/DESENHO-GL-0964-BATERIA.md.

Plano: glibren/ampr-bateria.json do repositorio privado pristmc-code/ps5-diagnosticos (a mesma chave e o mesmo caminho
da sugestao do Claude da 0.9.63), guardado em <dados>/bateria/plano.json. Uma thread roda rodada por rodada, repeticao
por repeticao: PREPARAR (ShadowKraken no ar, nenhum jogo aberto, temperatura, espaco) -> TROCAR (a versao pedida vai para
a pasta ativa SO por rename() no mesmo disco) -> ESPERAR_SK (releitura + /api/v1/games ate o titulo voltar com o caminho e
o formato certos) -> AMPR (build e ajustes) -> ABRIR -> CARREGAR (heuristica de "chegou ao menu" sem botoes) -> AJUSTAR
(/set) -> TRECHO (Inicio/Fim da 0.9.63, ou so espera na rodada de compatibilidade) -> FECHAR (controle virtual; reserva
KillApp) -> ESFRIAR. Cada passo grava <dados>/bateria/estado.json antes; cada rename vai antes para o journal.txt
(fsync). Fim normal, Parar e reinicio do PS5 = Desfazer tudo (o journal de tras para frente, conferindo dev+inode).
Resultados: resultados.jsonl (uma linha por repeticao), resultado-<id>.json e relatorio-<id>.md (ingles, medianas,
higienizado), enviados para glibren/ampr-bateria/<id>/ com as medidas.

Regras de seguranca (recusas duras): nunca copiar nem apagar jogo (so rename); mesmo st_dev entre origem e destino;
destino existente, arquivo em download, jogo aberto ou caminho fora das pastas do glibren/ShadowKraken = recusa.
KillApp (sceLncUtilKillApp, reserva sceSystemServiceKillApp(appid,-1,0,0)) e uma EXCECAO autorizada pelo dono
(23/11/2026) a regra "nunca KillApp" e so vale aqui: so para o titulo que a bateria abriu e so depois do controle virtual
falhar (ou com "fechar_metodo":"kill" no plano). Qual caminho fechou fica no resultado.

Rotas (api.c; POST so pelo celular/PC pareado + X-GLR; o navegador do PS5 so le):
  GET  /api/bateria            {ok, estado, passo, plano, atual, resultados, journal_pendente, problemas, erro, ...}
  POST /api/bateria/buscar     baixa e confere o plano (429 bat_espera se < 30 s; 400 bat_sem_chave; 404 bat_sem_plano)
  POST /api/bateria/conferir   validacao + ensaio seco dos movimentos (nada e movido)
  POST /api/bateria/iniciar    (a_partir=N) 409 bat_ocupado/bat_jogo_aberto/bat_sk_fora/bat_tarefas/bat_journal
  POST /api/bateria/pausar     termina a repeticao atual e para antes da proxima
  POST /api/bateria/continuar
  POST /api/bateria/parar      para ja (cancela o trecho, fecha o jogo) e desfaz
  POST /api/bateria/desfazer   so o desfazer (ex.: depois de um reinicio)
  POST /api/bateria/enviar     reenvia resultado + relatorio + medidas
No PC (testes): GLR_TESTE_SEGUNDO_MS (duracao de um "segundo" das esperas), GLR_TESTE_BAT_TEMP (arquivo com a
temperatura), GLR_TESTE_BAT_LIVRE_MIB (arquivo com o espaco livre), GLR_TESTE_BAT_ABRE=1 (abrir_app poe o titulo em
GLR_TESTE_ABERTOS), GLR_TESTE_PAD_FECHA=1 (a sequencia do controle virtual fecha o jogo), GLR_TESTE_KILL (falha|sys),
GLR_TESTE_KILL_LOG, GLR_TESTE_BOOT (boot), GLR_TESTE_COREDUMPS. */
#pragma once

#include "http.h"
#include "util.h"

/* Ao iniciar o glibren: le o estado gravado; com uma bateria andando no mesmo boot, retoma; com boot novo, marca
   "interrompida" e desfaz. */
void bateria_iniciar(void);
/* 1 = bateria andando ou pausada (a atualizacao do glibren espera). */
int bateria_ocupada(void);
/* GET /api/bateria */
void bateria_rota_estado(pedido_t *p);
/* POST /api/bateria/<acao>. 1 = era uma rota da bateria (ja respondeu). */
int bateria_rota_acao(pedido_t *p);
/* Para o diagnostico: o mesmo JSON do GET. */
void bateria_json(buf_t *b);
/* Para o diagnostico: arquivos da bateria (journal, estado, resultados, relatorio). Devolve quantos. */
int bateria_arquivos(char nomes[][96], char caminhos[][600], int max);
