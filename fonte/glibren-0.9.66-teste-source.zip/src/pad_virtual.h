/* Game Library Renamer (payload PS5) - 0.9.64: controle virtual (DualSense) so para a bateria automatica fechar o jogo.

NAO TESTADO no PS5 Pro 12.00: e o nucleo do nosso payload de teste teste-pad (ps5/teste-controle/teste-pad, GPL-3.0-or-later),
que por sua vez se baseia em codigo GPL-3:
  - Darkatek7/ProsperoSunshine  src/platform/ps5/pad.c  (ioctls add/insert/delete do /dev/hid, bloco de estado de 0xA8
    bytes, repouso do sensor de movimento)
  - Gl0ttis/ps5-mcp  src/pad.c, src/pad.h, src/backend.h  (valores dos botoes, reenvio do estado a cada 8 ms, usuario 1
    "sem dono" quando o add recusa o usuario real)
Metodo limpo: so open("/dev/hid") + ioctl() do PROPRIO processo do glibren. Sem ptrace, sem injecao em outro processo,
sem escrita na memoria do kernel, sem mudar ucred/authid. Se o PS5 recusar, a bateria cai na reserva (KillApp) e anota.

Uso unico: bateria.c abre o pad, aperta a sequencia que o plano manda (padrao: PS, Options, X, X para "Fechar jogo") e
apaga o pad. Nenhuma outra automacao de botoes no glibren.

No PC (testes): nada de /dev/hid. GLR_TESTE_PAD = "falha" -> pad_abrir falha (EACCES); cada aperto vai para o arquivo
GLR_TESTE_PAD_LOG ("nome segurar_ms"). */
#pragma once

#include <stddef.h>
#include <stdint.h>

/* Botao pelo nome do plano: ps, options, cruz (ou x), circulo, quadrado, triangulo, cima, baixo, esquerda, direita, l1,
   r1, l2, r2, l3, r3, create, touchpad. 0 = nome desconhecido. */
uint32_t pad_botao(const char *nome);
/* Cria o controle virtual e manda o estado neutro por repouso_ms. 0 = ok; senao -errno (erro recebe "etapa errno N"). */
int pad_abrir(int repouso_ms, char *erro, size_t tam_erro);
/* Segura os botoes por segurar_ms e solta, mantendo o neutro por depois_ms (reenvio a cada 8 ms). 0 = ok. */
int pad_apertar(uint32_t botoes, int segurar_ms, int depois_ms);
/* Mantem o neutro por ms (espera entre botoes). */
void pad_esperar(int ms);
/* Apaga o controle e fecha o /dev/hid (sempre chamar depois de um pad_abrir que deu 0). */
void pad_fechar(void);
