/* Game Library Renamer (payload PS5) - 0.9.63: "Velocidade do ampr" (ajustes e medidas do ampr-emu-ng de depuracao).

O build de depuracao do ampr-emu-ng (o -deb.sprx escolhido no bloco de teste, ampr_teste.c) abre um servidor de texto
em 127.0.0.1:9090 enquanto o jogo roda (um cliente por vez, estilo HTTP/1.0, respostas de ate 16 KiB):
  GET /metrics   1a linha "build ampr-emu-ng <versao> <rev> debug", 2a "pack_format <plain|lz4|zstd|pkg>", depois
                 "nome valor" (contadores de tempo de job, leituras, descompressao, pool, tune_...)
  GET /set       lista os ajustes: "knobs (/data/ampr_emu_tune.txt):" e uma linha por ajuste
                 "nome=valor [min..max] live" ou "... next launch"
  GET /set?k=v&k2=v2  aplica os pares em ordem (para no primeiro ruim: "error: bad pair '...' (later pairs not
                 applied)"), regrava /data/ampr_emu_tune.txt ("error: could not write ...") e lista
  GET /threads, /fsfail, /bench   threads, chamadas que falharam e a velocidade crua do volume 0 do pacote
O arquivo /data/ampr_emu_tune.txt vale para toda abertura de jogo seguinte (so o build de depuracao le); apagar volta
ao padrao na proxima abertura (o que ja foi aplicado "live" fica ate o jogo fechar).

Aqui: a pagina Payloads (cartao do ShadowKraken) mostra e muda os ajustes, guarda medidas (/metrics + /threads + /set +
/fsfail, ou /bench) em <dados>/ampr-medidas/AAAA-MM-DD_HHMMSS[_NN].txt (ficam as 40 mais novas, todas vao
no diagnostico) e volta ao padrao.

Rotas (api.c):
  GET  /api/ampr/ajustes            {ok,no_ar,ocupado,build,formato,arquivo_ajustes,ajustes:[{nome,valor,min,max,ao_vivo}],
                                     resumo:{bloco_ms,...,cache_pct,...} (null = contador ausente), contadores:{...},
                                     medidas:[{nome,tamanho,nota,hora}]}  (le /set e /metrics: os *_max zeram a cada leitura)
  POST /api/ampr/ajustes   nome=&valor= (repetidos; pareamento + X-GLR)  400 ampr_aj_nome/ampr_aj_valor/ampr_aj_vazio,
                                     409 ampr_dep_fora/ampr_ocupado; devolve a lista nova e "erro_ampr" (linha error:)
  POST /api/ampr/padrao             apaga /data/ampr_emu_tune.txt (vale na proxima abertura do jogo)
  POST /api/ampr/medir     nota=    guarda uma medida (409 ampr_dep_fora/ampr_ocupado)
  POST /api/ampr/bench     nota=    GET /bench (ate ~30 s) guardado como medida "bench: <nota>"; devolve o texto
  POST /api/ampr/medida/apagar nome=  400 ampr_medida_nome, 404 ampr_medida_nao_achou
No PC (testes): GLR_TESTE_AMPR_PORTA no lugar da 9090; GLR_TESTE_MONTADOR no lugar de /data (o arquivo de ajustes). */
#pragma once

#include "http.h"
#include "util.h"

#define AMPR_MEDIDAS_MAX 40
#define AMPR_MEDIDAS_DIAG 40

/* Conexao com o servidor de depuracao do ampr-emu-ng (127.0.0.1:9090). -1 se ninguem atende. (Era do coredump.c.) */
int ampr_dep_conectar(int espera_s);
/* So conecta e fecha: 1 = o jogo aberto tem o ampr-emu-ng de depuracao respondendo. */
int ampr_dep_no_ar(void);
/* GET <caminho> no 9090: le ate fechar (ate 64 KiB), tira o cabecalho HTTP se vier. >= 0 = bytes do corpo em resp;
   -1 = ninguem atende; -2 = conectou mas nao respondeu. */
int ampr_dep_get(const char *caminho, buf_t *resp, int espera_s);

void ampr_ajuste_rota_estado(pedido_t *p);
void ampr_ajuste_rota_aplicar(pedido_t *p);
void ampr_ajuste_rota_padrao(pedido_t *p);
void ampr_ajuste_rota_medir(pedido_t *p);
void ampr_ajuste_rota_bench(pedido_t *p);
void ampr_ajuste_rota_apagar(pedido_t *p);
/* 0.9.63 (segunda leva): POST /api/ampr/trecho/inicio|fim|cancelar, /marca, /sugestao/buscar|aplicar,
   /conjunto/salvar|aplicar|apagar, /medida/enviar e /disco. 1 = era uma dessas (ja respondeu). */
int ampr_ajuste_rota_mais(pedido_t *p);

/* Para o diagnostico: o mesmo JSON do GET (sem esperar se outra conversa com o 9090 estiver em andamento). */
void ampr_ajuste_json(buf_t *b);
/* Para o diagnostico: as medidas mais novas (nome "ampr-medida-<arquivo>"). Devolve quantas. */
int ampr_ajuste_medidas(char nomes[][96], char caminhos[][600], int max);

/* ------------------------------------------------------------------ 0.9.64: para a bateria automatica (bateria.c)
   Os mesmos nucleos das rotas da 0.9.63 (as rotas chamam estes; o comportamento das rotas nao muda). */
#define AMPR_AJ_NOME 40
typedef struct {
  double bloco_ms, leitura_ms, decode_us, cache_pct, peso_decode_pct, disco_kib;   /* -1 = contador ausente */
  double fps_media, low1, pior_ms, temp_max;                                       /* -1 = sem leitura */
  double segundos;
} ampr_resumo_t;
typedef struct {
  unsigned long long apr_read_bytes, apr_reads, pack_disk_bytes, decodes;
  int tem_bytes;   /* 1 = o /metrics trouxe apr_read_bytes */
} ampr_cont4_t;
/* Inicio do trecho (fps = 1 liga o FPS no amostrador). 0 = aberto; senao HTTP do erro e "chave: mensagem" em erro. */
int ampr_trecho_comecar(int fps, char *erro, size_t tam_erro);
/* Fim do trecho: grava a medida (cab_extra = linhas a mais no cabecalho) e devolve os numeros. 0 = ok. */
int ampr_trecho_terminar(const char *nota, const char *cab_extra, char *medida, size_t tam, ampr_resumo_t *res, char *erro, size_t tam_erro);
/* Cancela o trecho aberto (se houver) sem gravar. */
void ampr_trecho_desistir(void);
/* "Medir agora" sem pedido (rodada de compatibilidade). 0 = gravou. */
int ampr_medir_curto(const char *nota, const char *cab_extra, char *nome, size_t tam_nome);
/* Aplica pares no ampr aberto (o que ele nao tem fica de fora: ignorados). proxima_mudou = algum ajuste "next launch"
   mudou de valor (so vale na proxima abertura). 0 = aplicado (erro = linha "error:" do ampr, se houver); senao HTTP. */
int ampr_aplicar_pares(char nomes[][AMPR_AJ_NOME + 1], const long long *vals, int n, char *erro, size_t tam_erro, char *ignorados,
                       size_t tam_ign, int *proxima_mudou);
/* Apaga o arquivo de ajustes: 1 = apagou, 0 = nao havia, -1 = erro. */
int ampr_padrao(void);
/* Caminho do arquivo de ajustes (/data/ampr_emu_tune.txt; no PC dentro de GLR_TESTE_MONTADOR). */
void ampr_arquivo_ajustes(char *s, size_t tam);
/* /metrics agora: 1 = no ar (c preenchido), 0 = ninguem responde, -1 = outra conversa em andamento. */
int ampr_contadores(ampr_cont4_t *c);
/* build e formato do ultimo /metrics lido */
void ampr_build_atual(char *build, size_t tb, char *formato, size_t tf);
/* base64 da API do GitHub (ignora \n, = e espacos) */
void ampr_base64_dec(const char *in, size_t n, buf_t *out);
