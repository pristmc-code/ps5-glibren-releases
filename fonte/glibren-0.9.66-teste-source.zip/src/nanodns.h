/* Game Library Renamer (payload PS5) - editor do nanodns.ini do nanoDNS (0.9.66).

O nanoDNS (drakmor/nanoDNS, GPL-3.0) e um servidor DNS que roda no proprio PS5 (porta 53) e le /data/nanodns/
nanodns.ini SO ao subir: [general] log/debug/quiet/bind/bind6, [upstream] server=<IPv4> (ate 8; o 1o server= troca a
lista padrao) e timeout_ms, [overrides] <mascara>=<IPv4> (ate 128) e [exceptions] uma mascara por linha (ate 128;
passam direto para os servidores). Mascaras no estilo shell (*, ?, [abc], [a-z], [!x]), sem diferenca de maiusculas.
Arquivo lido: as regras do arquivo SUBSTITUEM as de fabrica (um arquivo sem [overrides] nao bloqueia nada da Sony).
Comentario: linha que comeca com # ou ;, e o resto da linha depois de # ou ;. Regras lidas no main.c da v0.4
(load_config, domain_mask_match); o codigo e proprio. Para valer, o nanoDNS tem de ser mandado de novo (ele encerra a
copia que esta rodando e rele o arquivo). */
#pragma once

#include <stddef.h>

#include "http.h"
#include "util.h"

/* Pasta do nanoDNS: /data/nanodns no PS5; <pasta de dados>/nanodns no PC (testes). */
void nanodns_pasta(char *saida, size_t tam);

/* Analise de um texto de nanodns.ini (sem tocar no disco). JSON em b:
   "erros":[{"linha":n,"chave":"..."}] (o glibren nao grava), "riscos":[host...] (enderecos da Sony que passariam: so
   grava com confirmo=1), "avisos":[{"linha":n,"chave":"..."}], "servidores":[...], "regras":n, "excecoes":n,
   "image_api":true/false (image.api.playstation.com liberado). Devolve o numero de erros; *riscos = numero de riscos. */
int nanodns_analisar(const char *texto, buf_t *b, int *riscos);

/* GET /api/nanodns: {"ok","existe","ilegivel","caminho","texto","padrao","tem_backup","rodando","sonda",...analise} */
void nanodns_rota_ler(pedido_t *p);
/* POST /api/nanodns (texto=...&confirmo=1; pareamento + X-GLR ja conferidos pelo api.c). Analisa, recusa com erros ou
   com riscos sem confirmo; grava de forma atomica e guarda a versao anterior em nanodns.ini.bak. */
void nanodns_rota_gravar(pedido_t *p);
