/* Game Library Renamer (payload PS5) - 0.9.54: pastas vigiadas pelo ShadowKraken, pela API dele.

Fonte da verdade: a API do proprio ShadowKraken (endereco do config.ini dele, como o resto do glibren). Le com
POST /api/v1/settings {} e grava com POST /api/v1/settings/update. O update exige debug, quiet_mode, update_emulators,
allow_lan_access, fan_target_temperature e scan_paths; os outros (auto_update_ampr, add_emulators, fpkg_direct_mount,
auto_remove_missing_games, auto_remove_missing_delay_seconds, fakelib_default_mode) ficam como estao se faltarem. Aqui
todos os que vieram no GET voltam com o texto JSON exato que veio: so scan_paths muda. O ShadowKraken grava o
config.ini e recarrega sozinho (a busca de jogos vem junto; chamar /api/v1/scan logo depois atrapalharia).

Cuidados vistos no codigo do ShadowKraken:
- scan_paths do GET so traz as pastas escolhidas; vazio = ele usa a lista padrao (/data/homebrew, /data/etaHEN/games,
  <usb/ext>/homebrew, <usb/ext>/etaHEN/games e a raiz dos discos USB/extra). Ao mexer numa lista vazia, as pastas
  padrao que existem entram primeiro (senao os jogos delas sairiam da biblioteca).
- allow_lan_access regrava [api] bind_address (0.0.0.0 ou 127.0.0.1): com o ShadowKraken ligado num IP so, nao grava.
- profundidade ([scan] depth, 1 ou 2): uma pasta dentro de outra vigiada ate depth-1 niveis ja e vista.

"shadowmount =" do config.ini do glibren (pastas da lista marcadas "Ativo"): passa a seguir a lista do ShadowKraken a
cada leitura (pasta da lista coberta por uma pasta vigiada). Uma pasta adicionada aqui tambem entra na lista do glibren.
Mudancas so pelo celular/PC pareado (rota_protegida + recusa do navegador do PS5 e do 127.0.0.1). */
#pragma once

#include "http.h"

/* GET /api/sk/pastas: pastas vigiadas (existe, espaco do disco), profundidade, padrao ou escolhidas. */
void sk_pastas_rota_estado(pedido_t *p);
/* GET /api/sk/pastas/conferir?caminho=: pode ou nao (erro) e os avisos, antes de perguntar ao dono. */
void sk_pastas_rota_conferir(pedido_t *p);
/* POST /api/sk/pastas/adicionar (caminho=) e /api/sk/pastas/remover (caminho=). */
void sk_pastas_rota_mudar(pedido_t *p, int adicionar);
/* 0.9.56: [fpkg] installed do ShadowKraken (Dev.35+: roda os .pkg instalados pelo sistema). 1 = ligado. */
int sk_instalados_ligado(void);
/* POST /api/sk/instalados (ligar=1|0): grava so essa linha no config.ini; o ShadowKraken recarrega sozinho. */
void sk_instalados_rota(pedido_t *p);
/* 0.9.64: pastas que valem agora para o ShadowKraken (as escolhidas, ou a lista padrao que existe), para a bateria.
   padrao = 1 se e a lista padrao; prof = profundidade ([scan] depth). Devolve quantas, ou -1 sem resposta da API. */
#define SK_PASTA_TAM 400
int sk_pastas_listar(char pastas[][SK_PASTA_TAM], int max, int *padrao, int *prof);
