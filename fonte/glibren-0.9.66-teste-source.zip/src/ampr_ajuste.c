/* Game Library Renamer (payload PS5) - 0.9.63: "Velocidade do ampr" pela pagina Payloads (ver ampr_ajuste.h).
   Conversa com o servidor de depuracao do ampr-emu-ng (127.0.0.1:9090, um cliente por vez): uma conversa por vez
   tambem aqui (g_dep); o estado da pagina nao espera (usa o ultimo lido e diz "ocupado"). */
#include "ampr_ajuste.h"

#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <pthread.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#include "api.h"
#include "config.h"
#include "desempenho.h"
#include "diagnostico.h"
#include "fps.h"
#include "https.h"
#include "json_min.h"
#include "lancador.h"
#include "payloads.h"
#include "plataforma.h"
#include "termico.h"

#ifdef MSG_NOSIGNAL
#define SEM_SINAL MSG_NOSIGNAL
#else
#define SEM_SINAL 0
#endif

#define DEP_MAX_RESP (64u * 1024)   /* o servidor responde ate 16 KiB; folga para builds futuros */
#define AJ_MAX 64
#define AJ_NOME 40
#define NOTA_MAX 120
#define BENCH_ESPERA_S 35

/* ------------------------------------------------------------------ conexao com o 9090 (era do coredump.c) */

/* Porta das paginas do build de depuracao do ampr-emu-ng (docs/debug-build.md: TCP 9090, um cliente por vez). */
static int porta_ampr(void) {
#ifndef __PROSPERO__
  const char *e = getenv("GLR_TESTE_AMPR_PORTA");
  if(e && atoi(e) > 0) return atoi(e);
#endif
  return 9090;
}

int ampr_dep_conectar(int espera_s) {
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if(fd < 0) return -1;
  struct timeval t = {.tv_sec = espera_s};
  setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &t, sizeof t);
  setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &t, sizeof t);
#ifdef SO_NOSIGPIPE
  int sim = 1;
  setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &sim, sizeof sim);
#endif
  struct sockaddr_in end = {.sin_family = AF_INET, .sin_port = htons((uint16_t)porta_ampr())};
  end.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  if(connect(fd, (struct sockaddr *)&end, sizeof end)) {
    close(fd);
    return -1;
  }
  return fd;
}

int ampr_dep_no_ar(void) {
  int fd = ampr_dep_conectar(1);
  if(fd < 0) return 0;
  close(fd);
  return 1;
}

int ampr_dep_get(const char *caminho, buf_t *resp, int espera_s) {
  resp->n = 0;
  int fd = ampr_dep_conectar(espera_s);
  if(fd < 0) return -1;
  char pedido[512];
  int k = snprintf(pedido, sizeof pedido, "GET %s HTTP/1.0\r\nHost: 127.0.0.1\r\n\r\n", caminho);
  if(k <= 0 || (size_t)k >= sizeof pedido || send(fd, pedido, (size_t)k, SEM_SINAL) != k) {
    close(fd);
    return -2;
  }
  char bloco[8192];
  for(;;) {
    ssize_t r = recv(fd, bloco, sizeof bloco, 0);
    if(r < 0 && errno == EINTR) continue;
    if(r <= 0) break;   /* fechou (fim da resposta) ou passou do prazo */
    size_t cabe = DEP_MAX_RESP - resp->n;
    buf_add(resp, bloco, (size_t)r < cabe ? (size_t)r : cabe);
    if(resp->n >= DEP_MAX_RESP) break;
  }
  close(fd);
  if(!resp->n) return -2;
  /* com ou sem a linha de status: "HTTP/1.x 200 OK\r\n...\r\n\r\n<corpo>" ou so o corpo */
  if(resp->n >= 5 && !memcmp(resp->d, "HTTP/", 5)) {
    size_t i = 0, pula = 0;
    for(; i + 1 < resp->n; i++) {
      if(i + 3 < resp->n && !memcmp(resp->d + i, "\r\n\r\n", 4)) { pula = i + 4; break; }
      if(!memcmp(resp->d + i, "\n\n", 2)) { pula = i + 2; break; }
    }
    if(!pula) pula = resp->n;   /* so cabecalho */
    memmove(resp->d, resp->d + pula, resp->n - pula);
    resp->n -= pula;
  }
  buf_add(resp, "", 1);   /* termina em \0 (fora da contagem) */
  resp->n--;
  return (int)resp->n;
}

/* ------------------------------------------------------------------ uma conversa por vez */

static pthread_mutex_t g_dep = PTHREAD_MUTEX_INITIALIZER;     /* conversa com o 9090 */
static pthread_mutex_t g_cache = PTHREAD_MUTEX_INITIALIZER;   /* ultimo estado lido */

/* Pega a vez de conversar com o 9090, esperando ate espera_ms. 0 = pegou. */
static int dep_trancar(int espera_ms) {
  for(int i = 0;; i++) {
    if(!pthread_mutex_trylock(&g_dep)) return 0;
    if(i * 50 >= espera_ms) return -1;
    usleep(50 * 1000);
  }
}

/* ------------------------------------------------------------------ caminhos */

static const char *raiz_data(void) {
#ifndef __PROSPERO__
  const char *r = getenv("GLR_TESTE_MONTADOR");
  if(r && *r) return r;
#endif
  return "/data";
}

static void arquivo_ajustes(char *s, size_t tam) { snprintf(s, tam, "%s/ampr_emu_tune.txt", raiz_data()); }
static void pasta_medidas(char *s, size_t tam) { snprintf(s, tam, "%s/ampr-medidas", g_pasta_dados); }

/* ------------------------------------------------------------------ ajustes (lista do GET /set) */

typedef struct {
  char nome[AJ_NOME + 1];
  long long valor, min, max;
  int ao_vivo;
} ajuste_t;

/* nome de ajuste: [a-z_][a-z0-9_]{0,39} */
static int nome_ajuste_ok(const char *s, size_t k) {
  if(!k || k > AJ_NOME || !(islower((unsigned char)s[0]) || s[0] == '_')) return 0;
  for(size_t i = 0; i < k; i++)
    if(!(islower((unsigned char)s[i]) || isdigit((unsigned char)s[i]) || s[i] == '_')) return 0;
  return 1;
}

static int ler_numero(const char **p, long long *v) {
  const char *s = *p;
  int neg = 0;
  if(*s == '-') { neg = 1; s++; }
  if(!isdigit((unsigned char)*s)) return 0;
  long long n = 0;
  int dig = 0;
  while(isdigit((unsigned char)*s)) {
    if(++dig > 15) return 0;
    n = n * 10 + (*s++ - '0');
  }
  *v = neg ? -n : n;
  *p = s;
  return 1;
}

/* "nome=valor [min..max] live|next launch" por linha; "error: ..." vai para erro. Devolve quantos ajustes. */
static int ler_lista(const char *t, ajuste_t *a, int max, char *erro, size_t tam_erro) {
  int n = 0;
  if(erro) erro[0] = 0;
  while(t && *t) {
    const char *fim = strchr(t, '\n');
    size_t k = fim ? (size_t)(fim - t) : strlen(t);
    char l[256];
    if(k >= sizeof l) k = sizeof l - 1;
    memcpy(l, t, k);
    l[k] = 0;
    l[strcspn(l, "\r")] = 0;
    t = fim ? fim + 1 : NULL;
    if(!strncmp(l, "error:", 6)) {
      if(erro && !erro[0]) {
        snprintf(erro, tam_erro, "%s", l);
        for(char *c = erro; *c; c++) if((unsigned char)*c < ' ') *c = ' ';
      }
      continue;
    }
    char *ig = strchr(l, '=');
    if(!ig || n >= max || !nome_ajuste_ok(l, (size_t)(ig - l))) continue;
    ajuste_t x;
    memset(&x, 0, sizeof x);
    memcpy(x.nome, l, (size_t)(ig - l));
    const char *p = ig + 1;
    if(!ler_numero(&p, &x.valor) || strncmp(p, " [", 2)) continue;
    p += 2;
    if(!ler_numero(&p, &x.min) || strncmp(p, "..", 2)) continue;
    p += 2;
    if(!ler_numero(&p, &x.max) || *p != ']') continue;
    p++;
    while(*p == ' ') p++;
    x.ao_vivo = !strncmp(p, "live", 4);
    a[n++] = x;
  }
  return n;
}

static void ajustes_json(buf_t *b, const ajuste_t *a, int n) {
  buf_str(b, "\"ajustes\":[");
  for(int i = 0; i < n; i++) {
    buf_str(b, i ? ",{\"nome\":" : "{\"nome\":");
    buf_json(b, a[i].nome);
    buf_fmt(b, ",\"valor\":%lld,\"min\":%lld,\"max\":%lld,\"ao_vivo\":%s}", a[i].valor, a[i].min, a[i].max, a[i].ao_vivo ? "true" : "false");
  }
  buf_str(b, "]");
}

/* ------------------------------------------------------------------ resumo do /metrics (contadores do stats.rs, 4db1b08) */

/* Os contadores sao totais desde que o jogo abriu; os *_max zeram a cada leitura do /metrics (entao sao "desde a
   ultima leitura", e a pagina le a cada ~5 s). */
static const char *const CONT[] = {"apr_read_bytes", "apr_read_ns", "apr_read_ns_max", "apr_reads", "cache_hits", "cache_misses",
                                   "cache_miss_first", "cache_miss_repeat", "cache_protected_bytes", "decode_errors", "decode_ns",
                                   "decoded_bytes", "decodes", "job_count", "job_first_issue_ns", "job_first_issues", "job_notify_ns",
                                   "job_notifies", "job_order_wait_ns", "job_order_waits", "job_total_ns", "job_total_ns_max",
                                   "job_totals", "pack_disk_bytes", "pack_disk_reads", "pack_job_errors", "pack_job_ns",
                                   "pack_job_ns_max", "pack_jobs"};
#define N_CONT ((int)(sizeof CONT / sizeof CONT[0]))

typedef struct {
  unsigned long long v[N_CONT];
  unsigned char tem[N_CONT];
} cont_t;

static int idx(const char *nome) {
  for(int i = 0; i < N_CONT; i++)
    if(!strcmp(CONT[i], nome)) return i;
  return -1;
}

/* linhas "nome valor" do /metrics */
static void ler_contadores(const char *t, cont_t *c) {
  memset(c, 0, sizeof *c);
  for(const char *l = t; l && *l; l = strchr(l, '\n') ? strchr(l, '\n') + 1 : NULL) {
    size_t k = strcspn(l, " \r\n");
    if(!k || k >= 40 || l[k] != ' ' || !isdigit((unsigned char)l[k + 1])) continue;
    char nome[41];
    memcpy(nome, l, k);
    nome[k] = 0;
    int i = idx(nome);
    if(i < 0) continue;
    c->v[i] = strtoull(l + k + 1, NULL, 10);
    c->tem[i] = 1;
  }
}

static int tem(const cont_t *c, const char *n) {
  int i = idx(n);
  return i >= 0 && c->tem[i];
}
static double val(const cont_t *c, const char *n) {
  int i = idx(n);
  return i >= 0 && c->tem[i] ? (double)c->v[i] : 0;
}

typedef struct {
  const char *chave, *rotulo, *unidade;
  int tipo;            /* 0 = razao a/b, 1 = valor de a, 2 = acerto do cache a/(a+b), 3 = erro (so se > 0) */
  const char *a, *b;
  double escala;
} campo_t;

static const campo_t CAMPOS[] = {
    {"bloco_ms", "tempo medio por bloco de comandos", "ms", 0, "job_total_ns", "job_totals", 1e-6},
    {"bloco_max_ms", "pior bloco (desde a ultima leitura)", "ms", 1, "job_total_ns_max", NULL, 1e-6},
    {"leitura_ms", "leitura do jogo", "ms por leitura", 0, "apr_read_ns", "apr_reads", 1e-6},
    {"leitura_max_ms", "pior leitura do jogo (desde a ultima leitura)", "ms", 1, "apr_read_ns_max", NULL, 1e-6},
    {"decode_us", "descompressao", "us por bloco", 0, "decode_ns", "decodes", 1e-3},
    {"decodes", "blocos descomprimidos", "", 1, "decodes", NULL, 1},
    {"disco_kib", "disco", "KiB por leitura", 0, "pack_disk_bytes", "pack_disk_reads", 1.0 / 1024},
    {"pacote_ms", "pedido ao pacote", "ms", 0, "pack_job_ns", "pack_jobs", 1e-6},
    {"pacote_max_ms", "pior pedido ao pacote (desde a ultima leitura)", "ms", 1, "pack_job_ns_max", NULL, 1e-6},
    {"peso_decode_pct", "peso da descompressao (aproximado)", "%", 0, "decode_ns", "job_total_ns", 100},
    {"cache_pct", "acerto do cache", "%", 2, "cache_hits", "cache_misses", 100},
    {"ordem_ms", "espera pela ordem", "ms", 0, "job_order_wait_ns", "job_order_waits", 1e-6},
    {"primeira_ms", "ate a 1a leitura", "ms", 0, "job_first_issue_ns", "job_first_issues", 1e-6},
    {"decode_errors", "erros de descompressao", "", 3, "decode_errors", NULL, 1},
    {"pack_job_errors", "erros de pedido ao pacote", "", 3, "pack_job_errors", NULL, 1},
};
#define N_CAMPOS ((int)(sizeof CAMPOS / sizeof CAMPOS[0]))

static int campo(const cont_t *c, const campo_t *f, double *r) {
  switch(f->tipo) {
  case 0:
    if(!tem(c, f->a) || !tem(c, f->b) || val(c, f->b) <= 0) return 0;
    *r = val(c, f->a) / val(c, f->b) * f->escala;
    return 1;
  case 2:
    if(!tem(c, f->a) || !tem(c, f->b) || val(c, f->a) + val(c, f->b) <= 0) return 0;
    *r = val(c, f->a) / (val(c, f->a) + val(c, f->b)) * 100;
    return 1;
  case 3:
    if(!tem(c, f->a) || val(c, f->a) <= 0) return 0;
    *r = val(c, f->a);
    return 1;
  default:
    if(!tem(c, f->a)) return 0;
    *r = val(c, f->a) * f->escala;
    return 1;
  }
}

/* "resumo":{chave:numero|null,...},"contadores":{nome:valor,...} (so os que vieram) */
static void resumo_json(buf_t *b, const cont_t *c) {
  buf_str(b, "\"resumo\":{");
  for(int i = 0; i < N_CAMPOS; i++) {
    double r;
    buf_fmt(b, "%s\"%s\":", i ? "," : "", CAMPOS[i].chave);
    if(campo(c, &CAMPOS[i], &r)) buf_fmt(b, "%.3f", r);
    else buf_str(b, "null");
  }
  buf_str(b, "},\"contadores\":{");
  int pri = 1;
  for(int i = 0; i < N_CONT; i++)
    if(c->tem[i]) {
      buf_fmt(b, "%s\"%s\":%llu", pri ? "" : ",", CONT[i], c->v[i]);
      pri = 0;
    }
  buf_str(b, "}");
}

/* O mesmo resumo em texto, no topo da medida */
static void resumo_texto(buf_t *b, const cont_t *c, const char *titulo) {
  buf_fmt(b, "\n=== Resumo (%s)\n", titulo);
  for(int i = 0; i < N_CAMPOS; i++) {
    double r;
    int ok = campo(c, &CAMPOS[i], &r);
    if(CAMPOS[i].tipo == 3 && !ok) continue;
    if(ok) buf_fmt(b, "%s: %.3f%s%s\n", CAMPOS[i].rotulo, r, CAMPOS[i].unidade[0] ? " " : "", CAMPOS[i].unidade);
    else buf_fmt(b, "%s: -\n", CAMPOS[i].rotulo);
  }
  buf_str(b, "contadores:");
  for(int i = 0; i < N_CONT; i++)
    if(c->tem[i]) buf_fmt(b, " %s=%llu", CONT[i], c->v[i]);
  buf_str(b, "\n");
}

/* ultimo estado lido (para quando outra conversa esta em andamento) */
static struct {
  int no_ar;
  char build[160], formato[24];
  ajuste_t aj[AJ_MAX];
  int n;
  cont_t cont;
} g_c;

/* ------------------------------------------------------------------ 0.9.63: cronometro, rodada e cabecalho das medidas */

static long long agora_ms(void) {
  struct timespec t;
  clock_gettime(CLOCK_MONOTONIC, &t);
  return (long long)t.tv_sec * 1000 + t.tv_nsec / 1000000;
}

/* Cronometro de carregamento: marcas do dono (abri, menu, save, livre) e as automaticas (jogo abriu, o 9090 respondeu;
   vistas pela leitura de estado da pagina, a cada ~5 s). Vao na proxima medida e entao zeram. */
#define MARCAS_MAX 24
static struct {
  char tipo[16], texto[64];
  long long ms;
  long long quando;
} g_marcas[MARCAS_MAX];
static int g_nmarcas, g_marca_no_ar, g_marca_jogo;   /* estados anteriores para as automaticas */
static pthread_mutex_t g_trava_marcas = PTHREAD_MUTEX_INITIALIZER;

static void marca_add(const char *tipo, const char *texto) {   /* chamar com g_trava_marcas */
  if(g_nmarcas >= MARCAS_MAX) return;
  snprintf(g_marcas[g_nmarcas].tipo, sizeof g_marcas[0].tipo, "%s", tipo);
  snprintf(g_marcas[g_nmarcas].texto, sizeof g_marcas[0].texto, "%s", texto ? texto : "");
  g_marcas[g_nmarcas].ms = agora_ms();
  g_marcas[g_nmarcas].quando = (long long)time(NULL);
  g_nmarcas++;
}

static const char *marca_nome(const char *tipo) {
  return !strcmp(tipo, "abri") ? "abri o jogo" : !strcmp(tipo, "menu") ? "menu apareceu" : !strcmp(tipo, "save") ? "save carregou" :
         !strcmp(tipo, "jogo_abriu") ? "jogo aberto (visto pelo glibren, +-5 s)" :
         !strcmp(tipo, "ampr_respondeu") ? "ampr 9090 respondeu (visto pelo glibren, +-5 s)" : "marca livre";
}

/* Marcas para o cabecalho da medida (e zera). */
static void marcas_texto(buf_t *b) {
  pthread_mutex_lock(&g_trava_marcas);
  if(g_nmarcas) {
    buf_str(b, "cronometro de carregamento (segundos desde a 1a marca):\n");
    for(int i = 0; i < g_nmarcas; i++)
      buf_fmt(b, "  %7.1f s  %s%s%s\n", (double)(g_marcas[i].ms - g_marcas[0].ms) / 1000.0, marca_nome(g_marcas[i].tipo),
              g_marcas[i].texto[0] ? ": " : "", g_marcas[i].texto);
  }
  g_nmarcas = 0;
  pthread_mutex_unlock(&g_trava_marcas);
}

/* Rodada da ultima sugestao do Claude aplicada (vai no cabecalho das medidas seguintes). */
static int g_rodada = -1;
static void arquivo_rodada(char *s, size_t tam) { snprintf(s, tam, "%s/ampr-rodada.txt", g_pasta_dados); }
static int rodada(void) {
  if(g_rodada < 0) {
    char c[600];
    arquivo_rodada(c, sizeof c);
    FILE *f = fopen(c, "r");
    g_rodada = 0;
    if(f) {
      if(fscanf(f, "%d", &g_rodada) != 1 || g_rodada < 0) g_rodada = 0;
      fclose(f);
    }
  }
  return g_rodada;
}
static void rodada_gravar(int r) {
  char c[600];
  arquivo_rodada(c, sizeof c);
  FILE *f = fopen(c, "w");
  if(f) {
    fprintf(f, "%d\n", r);
    fclose(f);
  }
  g_rodada = r;
}

/* Numero de um campo de um JSON (k2: dentro do objeto k1). -1 se nao tem. */
static double campo_num(const char *json, size_t n, const char *k1, const char *k2) {
  js_t o = {json, json + n}, v, w;
  if(!json || !js_campo(&o, k1, &v)) return -1;
  if(k2) {
    if(!js_campo(&v, k2, &w)) return -1;
    v = w;
  }
  char *fim;
  double d = strtod(v.p, &fim);
  return fim == v.p ? -1 : d;
}

/* Payloads rodando agora (a mesma sonda da pagina Payloads), para o cabecalho. */
typedef struct {
  buf_t *b;
  int n;
} rodando_ctx_t;
static int um_payload(const js_t *it, void *ctx) {
  rodando_ctx_t *r = ctx;
  js_t v;
  char id[64] = "", versao[48] = "";
  if(!js_campo(it, "rodando", &v) || !js_verdade(&v)) return 1;
  if(js_campo(it, "id", &v)) js_string(&v, id, sizeof id);
  if(js_campo(it, "rodando_versao", &v)) js_string(&v, versao, sizeof versao);
  buf_fmt(r->b, "%s%s%s%s", r->n++ ? ", " : "", id, versao[0] ? " " : "", versao);
  return 1;
}
static void payloads_rodando(buf_t *b) {
  buf_t j = {0};
  payloads_json(&j);
  js_t o = {j.d, j.d + j.n}, itens;
  rodando_ctx_t r = {b, 0};
  buf_str(b, "payloads rodando: ");
  if(j.d && js_campo(&o, "itens", &itens)) js_cada(&itens, um_payload, &r);
  if(!r.n) buf_str(b, "nenhum (ou nao deu para saber)");
  buf_str(b, "\n");
  buf_free(&j);
}

/* Temperaturas e clocks agora, numa linha */
static void termico_linha(buf_t *b, const char *quando) {
  buf_t t = {0}, d = {0};
  termico_json(&t, 0);
  desempenho_pedido();
  buf_str(&d, "{");
  desempenho_json(&d);
  buf_str(&d, "}");
  buf_fmt(b, "temperatura e clock %s: cpu %.0f C, soc %.0f C, ventoinha %.0f, cpu %.0f MHz, gpu %.0f MHz\n", quando,
          campo_num(t.d, t.n, "cpu", NULL), campo_num(t.d, t.n, "soc", NULL), campo_num(t.d, t.n, "ventoinha", NULL),
          campo_num(d.d, d.n, "desempenho", "cpu_mhz"), campo_num(d.d, d.n, "desempenho", "gpu_mhz"));
  buf_free(&t);
  buf_free(&d);
}

/* Linhas extras do cabecalho de toda medida: rodada, payloads, temperatura/clock e o cronometro. */
static void cabecalho_extras(buf_t *b) {
  if(rodada() > 0) buf_fmt(b, "rodada da sugestao do Claude: %d\n", rodada());
  payloads_rodando(b);
  termico_linha(b, "agora");
  marcas_texto(b);
}

/* /metrics: 1a linha "build ...", e a linha "pack_format X" */
static void ler_metrics(const char *t, char *build, size_t tb, char *formato, size_t tf) {
  build[0] = formato[0] = 0;
  if(!t) return;
  size_t k = strcspn(t, "\r\n");
  if(!strncmp(t, "build ", 6)) snprintf(build, tb, "%.*s", (int)k, t);
  for(const char *l = t; l && *l; l = strchr(l, '\n') ? strchr(l, '\n') + 1 : NULL)
    if(!strncmp(l, "pack_format ", 12)) {
      snprintf(formato, tf, "%.*s", (int)strcspn(l + 12, " \r\n"), l + 12);
      break;
    }
  for(char *c = build; *c; c++) if((unsigned char)*c < ' ') *c = ' ';
  for(char *c = formato; *c; c++) if(!isalnum((unsigned char)*c) && *c != '_' && *c != '-') *c = '?';
}

/* Guarda build, formato e contadores de um /metrics no cache. Chamar com g_dep. */
static void cache_metrics(const char *t, cont_t *saida) {
  char build[160], formato[24];
  static cont_t c;   /* so com g_dep (uma conversa por vez) */
  ler_metrics(t, build, sizeof build, formato, sizeof formato);
  ler_contadores(t, &c);
  pthread_mutex_lock(&g_cache);
  snprintf(g_c.build, sizeof g_c.build, "%s", build);
  snprintf(g_c.formato, sizeof g_c.formato, "%s", formato);
  g_c.cont = c;
  pthread_mutex_unlock(&g_cache);
  if(saida) *saida = c;
}

/* Le /set e /metrics e guarda no cache. Chamar com g_dep. 1 = no ar. */
static int atualizar_cache(int espera_s) {
  buf_t s = {0}, m = {0};
  static ajuste_t aj[AJ_MAX];   /* so com g_dep */
  int no_ar = ampr_dep_get("/set", &s, espera_s) >= 0, n = no_ar ? ler_lista(s.d, aj, AJ_MAX, NULL, 0) : 0;
  if(no_ar && ampr_dep_get("/metrics", &m, espera_s) >= 0) cache_metrics(m.d, NULL);
  pthread_mutex_lock(&g_cache);
  if(no_ar) {
    memcpy(g_c.aj, aj, sizeof aj[0] * (size_t)n);
    g_c.n = n;
  } else {
    g_c.build[0] = g_c.formato[0] = 0;
    g_c.n = 0;
    memset(&g_c.cont, 0, sizeof g_c.cont);
  }
  g_c.no_ar = no_ar;
  pthread_mutex_unlock(&g_cache);
  buf_free(&s);
  buf_free(&m);
  return no_ar;
}

/* ------------------------------------------------------------------ medidas guardadas */

typedef struct {
  char nome[48];
  long long bytes;
  time_t hora;
} medida_t;

/* AAAA-MM-DD_HHMMSS.txt ou AAAA-MM-DD_HHMMSS_NN.txt (nada mais: sem barra, sem ponto-ponto) */
static int nome_medida_ok(const char *n) {
  static const char MOLDE[] = "0000-00-00_000000";
  size_t k = strlen(n);
  if(k != 21 && k != 24) return 0;
  for(size_t i = 0; i < 17; i++) {
    if(MOLDE[i] == '0' ? !isdigit((unsigned char)n[i]) : n[i] != MOLDE[i]) return 0;
  }
  if(k == 24 && (n[17] != '_' || !isdigit((unsigned char)n[18]) || !isdigit((unsigned char)n[19]))) return 0;
  return !strcmp(n + k - 4, ".txt");
}

static int cmp_medida(const void *a, const void *b) {   /* mais nova primeiro (o nome comeca pela data-hora) */
  return strcmp(((const medida_t *)b)->nome, ((const medida_t *)a)->nome);
}

/* Todas as medidas (ate 128), da mais nova para a mais velha. */
static int listar_medidas(medida_t *m, int max) {
  char pasta[600];
  pasta_medidas(pasta, sizeof pasta);
  DIR *d = opendir(pasta);
  if(!d) return 0;
  int n = 0;
  struct dirent *e;
  while((e = readdir(d)) && n < max) {
    if(!nome_medida_ok(e->d_name)) continue;
    char c[700];
    struct stat st;
    snprintf(c, sizeof c, "%s/%s", pasta, e->d_name);
    if(lstat(c, &st) || !S_ISREG(st.st_mode)) continue;
    snprintf(m[n].nome, sizeof m[n].nome, "%s", e->d_name);
    m[n].bytes = (long long)st.st_size;
    m[n].hora = st.st_mtime;
    n++;
  }
  closedir(d);
  qsort(m, (size_t)n, sizeof m[0], cmp_medida);
  return n;
}

/* A linha "nota: " do cabecalho da medida. */
static void nota_da_medida(const char *nome, char *nota, size_t tam) {
  nota[0] = 0;
  char c[700], linha[400];
  pasta_medidas(c, sizeof c);
  size_t k = strlen(c);
  snprintf(c + k, sizeof c - k, "/%s", nome);
  int fd = open(c, O_RDONLY | O_NOFOLLOW);
  if(fd < 0) return;
  FILE *f = fdopen(fd, "r");
  if(!f) {
    close(fd);
    return;
  }
  for(int i = 0; i < 8 && fgets(linha, sizeof linha, f); i++)
    if(!strncmp(linha, "nota: ", 6)) {
      linha[strcspn(linha, "\r\n")] = 0;
      snprintf(nota, tam, "%s", linha + 6);
      break;
    }
  fclose(f);
}

static void medidas_json(buf_t *b) {
  static medida_t m[128];
  static pthread_mutex_t trava = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_lock(&trava);
  int n = listar_medidas(m, 128);
  if(n > AMPR_MEDIDAS_MAX) n = AMPR_MEDIDAS_MAX;
  buf_str(b, "\"medidas\":[");
  for(int i = 0; i < n; i++) {
    char nota[NOTA_MAX * 2 + 16];
    nota_da_medida(m[i].nome, nota, sizeof nota);
    buf_str(b, i ? ",{\"nome\":" : "{\"nome\":");
    buf_json(b, m[i].nome);
    buf_fmt(b, ",\"tamanho\":%lld,\"nota\":", m[i].bytes);
    buf_json(b, nota);
    buf_fmt(b, ",\"hora\":%lld}", (long long)m[i].hora);
  }
  buf_str(b, "]");
  pthread_mutex_unlock(&trava);
}

/* Apaga as mais velhas, deixando AMPR_MEDIDAS_MAX. */
static void podar_medidas(void) {
  static medida_t m[128];
  char pasta[600];
  pasta_medidas(pasta, sizeof pasta);
  int n = listar_medidas(m, 128);
  for(int i = AMPR_MEDIDAS_MAX; i < n; i++) {
    char c[700];
    snprintf(c, sizeof c, "%s/%s", pasta, m[i].nome);
    unlink(c);
  }
}

/* campo do pedido (nota=, nome= do conjunto, texto= da marca): ate max bytes, sem caracteres de controle, sem cortar um
   caractere UTF-8 no meio, sem espacos nas pontas */
static void pedir_texto(pedido_t *p, const char *campo, char *nota, size_t tam, size_t max) {
  char bruta[1024] = "";
  param(p->corpo, campo, 0, bruta, sizeof bruta);
  size_t o = 0;
  for(size_t i = 0; bruta[i] && o + 1 < tam && o < max; i++) {
    unsigned char c = (unsigned char)bruta[i];
    nota[o++] = c < ' ' || c == 0x7f ? ' ' : (char)c;
  }
  nota[o] = 0;
  /* cortou no meio de um caractere UTF-8? volta ate o comeco dele */
  if(o && ((unsigned char)nota[o - 1] & 0x80)) {
    size_t i = o;
    while(i && ((unsigned char)nota[i - 1] & 0xC0) == 0x80) i--;   /* continuacoes */
    if(i) {
      unsigned char lider = (unsigned char)nota[i - 1];
      size_t quer = lider >= 0xF0 ? 4 : lider >= 0xE0 ? 3 : lider >= 0xC0 ? 2 : 1;
      if(o - (i - 1) < quer) nota[i - 1] = 0;
    } else {
      nota[0] = 0;
    }
  }
  /* espacos nas pontas */
  size_t k = strlen(nota);
  while(k && nota[k - 1] == ' ') nota[--k] = 0;
  size_t ini = strspn(nota, " ");
  if(ini) memmove(nota, nota + ini, k - ini + 1);
}

static void pedir_nota(pedido_t *p, char *nota, size_t tam) { pedir_texto(p, "nota", nota, tam, NOTA_MAX); }

/* Grava uma medida nova (.tmp + rename) com cabecalho + as secoes. 0 = ok, nome recebe o arquivo. */
/* 0.9.63: cab_extra = linhas a mais no cabecalho (trecho, disco); titulo = de onde vem o resumo. */
static int gravar_medida(const char *nota, const char *cab_extra, const cont_t *resumo, const char *titulo,
                         const char *const *caminhos, buf_t *corpos, int n, char *nome, size_t tam_nome) {
  char pasta[600];
  pasta_medidas(pasta, sizeof pasta);
  if(mkdir_p(pasta) && errno != EEXIST) return -1;
  time_t agora = time(NULL);
  struct tm tm;
  localtime_r(&agora, &tm);
  char base[24], c[700];
  strftime(base, sizeof base, "%Y-%m-%d_%H%M%S", &tm);
  struct stat st;
  nome[0] = 0;
  for(int i = 1; i < 100; i++) {
    if(i == 1) snprintf(nome, tam_nome, "%s.txt", base);
    else snprintf(nome, tam_nome, "%s_%02d.txt", base, i);
    snprintf(c, sizeof c, "%s/%s", pasta, nome);
    if(lstat(c, &st)) break;
    nome[0] = 0;
  }
  if(!nome[0]) return -1;
  char tid[16] = "", data[32];
  int aberto = app_de_jogo_aberto(tid, sizeof tid);
  strftime(data, sizeof data, "%Y-%m-%d %H:%M:%S", &tm);
  buf_t b = {0};
  buf_fmt(&b, "# Medida do ampr-emu-ng de depuracao (glibren %s)\ndata: %s\nnota: %s\njogo: %s\n", VERSAO, data, nota,
          aberto == 1 ? tid : aberto == 0 ? "nenhum aberto" : "nao deu para saber");
  pthread_mutex_lock(&g_cache);
  buf_fmt(&b, "build: %s\nformato: %s\n", g_c.build[0] ? g_c.build : "?", g_c.formato[0] ? g_c.formato : "?");
  pthread_mutex_unlock(&g_cache);
  char aj[600];
  arquivo_ajustes(aj, sizeof aj);
  buf_fmt(&b, "arquivo de ajustes: %s\n", lstat(aj, &st) ? "nao (padrao)" : "sim");
  cabecalho_extras(&b);
  if(cab_extra && *cab_extra) buf_str(&b, cab_extra);
  if(resumo) resumo_texto(&b, resumo, titulo ? titulo : "do /metrics desta medida; contadores somados desde que o jogo abriu");
  for(int i = 0; i < n; i++) {
    buf_fmt(&b, "\n=== %s\n", caminhos[i]);
    if(corpos[i].d && corpos[i].n) buf_add(&b, corpos[i].d, corpos[i].n);
    else buf_str(&b, "(sem resposta)");
    if(!b.n || b.d[b.n - 1] != '\n') buf_str(&b, "\n");
  }
  char tmp[720];
  snprintf(tmp, sizeof tmp, "%s.tmp", c);
  FILE *f = fopen(tmp, "wb");
  int ok = f && fwrite(b.d, 1, b.n, f) == b.n;
  if(f && fclose(f)) ok = 0;
  if(ok && rename(tmp, c)) ok = 0;
  if(!ok) unlink(tmp);
  buf_free(&b);
  if(ok) podar_medidas();
  return ok ? 0 : -1;
}

/* ------------------------------------------------------------------ estado */

static void extras_json(buf_t *b);   /* 0.9.63: trecho, marcas, sugestao, conjuntos e teste de disco (mais abaixo) */

static void estado_json(buf_t *b, int ocupado) {
  char aj[600];
  struct stat st;
  arquivo_ajustes(aj, sizeof aj);
  pthread_mutex_lock(&g_cache);
  buf_fmt(b, "{\"ok\":true,\"no_ar\":%s,\"ocupado\":%s,\"build\":", g_c.no_ar ? "true" : "false", ocupado ? "true" : "false");
  buf_json(b, g_c.build);
  buf_str(b, ",\"formato\":");
  buf_json(b, g_c.formato);
  buf_fmt(b, ",\"arquivo_ajustes\":%s,", lstat(aj, &st) ? "false" : "true");
  ajustes_json(b, g_c.aj, g_c.n);
  buf_str(b, ",");
  resumo_json(b, &g_c.cont);
  pthread_mutex_unlock(&g_cache);
  buf_str(b, ",");
  medidas_json(b);
  extras_json(b);
}

/* Marcas automaticas do cronometro (so com o cronometro andando): o jogo abriu e o 9090 respondeu. */
static void marcas_automaticas(int no_ar) {
  pthread_mutex_lock(&g_trava_marcas);
  int ligado = g_nmarcas > 0;
  pthread_mutex_unlock(&g_trava_marcas);
  if(!ligado) return;
  char tid[16] = "";
  int jogo = app_de_jogo_aberto(tid, sizeof tid) == 1;
  pthread_mutex_lock(&g_trava_marcas);
  if(g_nmarcas > 0) {
    if(jogo && !g_marca_jogo) marca_add("jogo_abriu", tid);
    if(no_ar && !g_marca_no_ar) marca_add("ampr_respondeu", "");
    g_marca_jogo = jogo;
    g_marca_no_ar = no_ar;
  }
  pthread_mutex_unlock(&g_trava_marcas);
}

void ampr_ajuste_json(buf_t *b) {
  int ocupado = dep_trancar(0) != 0, no_ar = 0;
  if(!ocupado) {
    no_ar = atualizar_cache(2);
    pthread_mutex_unlock(&g_dep);
    marcas_automaticas(no_ar);
  }
  estado_json(b, ocupado);
  buf_str(b, "}");
}

void ampr_ajuste_rota_estado(pedido_t *p) {
  buf_t b = {0};
  ampr_ajuste_json(&b);
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* 0.9.64: pega a vez e confere que o ampr de depuracao responde, sem pedido (rotas e bateria). 0 = ok (com g_dep);
   senao 409 e a chave/mensagem do erro. */
static int comecar_sem(const char **chave, const char **msg) {
  if(dep_trancar(3000)) {
    *chave = "ampr_ocupado";
    *msg = "outra conversa com o ampr-emu-ng em andamento (medida do disco?): espere";
    return 409;
  }
  if(!atualizar_cache(3)) {
    pthread_mutex_unlock(&g_dep);
    *chave = "ampr_dep_fora";
    *msg = "nenhum jogo com o ampr-emu-ng de depuracao respondendo na porta 9090";
    return 409;
  }
  return 0;
}

/* Pega a vez e confere que o ampr de depuracao responde; 0 = ok (com g_dep), senao ja respondeu o erro. */
static int comecar(pedido_t *p) {
  const char *chave, *msg;
  int st = comecar_sem(&chave, &msg);
  if(st) responder_erro(p, st, chave, msg, NULL);
  return st ? -1 : 0;
}

/* ------------------------------------------------------------------ POST /api/ampr/ajustes */

/* 0.9.64: resultado do nucleo do aplicar (rota e bateria) */
typedef struct {
  int status;               /* 0 = aplicado; senao o HTTP do erro */
  const char *chave;
  char msg[160], param[AJ_NOME + 1];
  char erro[300];           /* linha "error:" do ampr */
  char ignorados[600];
  int usados;
  int proxima_mudou;        /* algum ajuste "next launch" mudou de valor (so vale na proxima abertura) */
} aplicar_res_t;

/* 0.9.63: aplica pares ja lidos (manual, sugestao do Claude ou conjunto salvo). pular = conjunto: o que o ampr aberto nao
   tem ou esta fora do limite fica de fora (vai em "ignorados"); senao recusa o pedido inteiro. rodada > 0: e a sugestao
   dessa rodada (vai para as medidas seguintes). 0.9.64: nucleo sem pedido (a bateria usa o mesmo). */
static void aplicar_core(char nomes[][AJ_NOME + 1], const long long *vals, int n, int pular, int rodada_nova, const char *origem,
                         aplicar_res_t *r) {
  memset(r, 0, sizeof *r);
  const char *ch, *ms;
  if((r->status = comecar_sem(&ch, &ms))) {
    r->chave = ch;
    snprintf(r->msg, sizeof r->msg, "%s", ms);
    return;
  }
  char consulta[2048];
  size_t q = (size_t)snprintf(consulta, sizeof consulta, "/set?");
  int usados = 0;
  pthread_mutex_lock(&g_cache);
  for(int i = 0; i < n; i++) {
    int achou = -1;
    for(int j = 0; j < g_c.n; j++)
      if(!strcmp(g_c.aj[j].nome, nomes[i])) achou = j;
    long long v = vals[i];
    const char *chave = achou < 0 ? "ampr_aj_nome" : v < g_c.aj[achou].min || v > g_c.aj[achou].max ? "ampr_aj_valor" : NULL;
    if(chave && pular) {
      size_t k = strlen(r->ignorados);
      snprintf(r->ignorados + k, sizeof r->ignorados - k, "%s%s", k ? "," : "", nomes[i]);
      continue;
    }
    if(chave) {
      if(achou < 0) snprintf(r->msg, sizeof r->msg, "o ampr-emu-ng aberto nao tem o ajuste %s", nomes[i]);
      else snprintf(r->msg, sizeof r->msg, "%s fora do limite (%lld a %lld)", nomes[i], g_c.aj[achou].min, g_c.aj[achou].max);
      pthread_mutex_unlock(&g_cache);
      pthread_mutex_unlock(&g_dep);
      r->status = 400;
      r->chave = chave;
      snprintf(r->param, sizeof r->param, "%s", nomes[i]);
      return;
    }
    if(!g_c.aj[achou].ao_vivo && g_c.aj[achou].valor != v) r->proxima_mudou = 1;
    q += (size_t)snprintf(consulta + q, sizeof consulta - q, "%s%s=%lld", usados++ ? "&" : "", nomes[i], v);
  }
  pthread_mutex_unlock(&g_cache);
  r->usados = usados;
  if(!usados) {
    pthread_mutex_unlock(&g_dep);
    r->status = 400;
    r->chave = "ampr_aj_vazio";
    snprintf(r->msg, sizeof r->msg, "nenhum ajuste serve para o ampr-emu-ng aberto");
    return;
  }
  buf_t b = {0};
  int st = ampr_dep_get(consulta, &b, 5);
  static ajuste_t aj[AJ_MAX];   /* so com g_dep */
  int na = st >= 0 ? ler_lista(b.d, aj, AJ_MAX, r->erro, sizeof r->erro) : 0;
  if(st >= 0 && na) {
    pthread_mutex_lock(&g_cache);
    memcpy(g_c.aj, aj, sizeof aj[0] * (size_t)na);
    g_c.n = na;
    pthread_mutex_unlock(&g_cache);
  }
  pthread_mutex_unlock(&g_dep);
  buf_free(&b);
  if(st < 0) {
    diario("ampr-ajuste: %s sem resposta do ampr-emu-ng", consulta);
    r->status = 409;
    r->chave = "ampr_dep_fora";
    snprintf(r->msg, sizeof r->msg, "o ampr-emu-ng nao respondeu ao pedido (o jogo fechou?)");
    return;
  }
  if(rodada_nova > 0 && !r->erro[0]) rodada_gravar(rodada_nova);
  diario("ampr-ajuste: %s%s%s%s%s%s", origem, consulta, r->erro[0] ? " -> " : "", r->erro, r->ignorados[0] ? " (ignorados: " : "",
         r->ignorados[0] ? r->ignorados : "");
}

static void aplicar_lista(pedido_t *p, char nomes[][AJ_NOME + 1], const long long *vals, int n, int pular, int rodada_nova,
                          const char *origem) {
  static aplicar_res_t r;   /* grande para a pilha; quem chama ja segura uma trava propria */
  static pthread_mutex_t trava = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_lock(&trava);
  aplicar_core(nomes, vals, n, pular, rodada_nova, origem, &r);
  if(r.status) {
    responder_erro(p, r.status, r.chave, r.msg, r.param[0] ? r.param : NULL);
    pthread_mutex_unlock(&trava);
    return;
  }
  buf_t b = {0};
  estado_json(&b, 0);
  buf_str(&b, ",\"erro_ampr\":");
  buf_json(&b, r.erro);
  buf_fmt(&b, ",\"aplicados\":%d,\"ignorados\":", r.usados);
  buf_json(&b, r.ignorados);
  buf_str(&b, "}");
  pthread_mutex_unlock(&trava);
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* 0.9.64: para a bateria (ver ampr_ajuste.h) */
int ampr_aplicar_pares(char nomes[][AMPR_AJ_NOME + 1], const long long *vals, int n, char *erro, size_t tam_erro, char *ignorados,
                       size_t tam_ign, int *proxima_mudou) {
  static aplicar_res_t r;
  static pthread_mutex_t trava = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_lock(&trava);
  aplicar_core(nomes, vals, n, 1, 0, "bateria: ", &r);
  int st = r.status;
  if(st) snprintf(erro, tam_erro, "%s: %s", r.chave, r.msg);
  else snprintf(erro, tam_erro, "%s", r.erro);
  if(ignorados) snprintf(ignorados, tam_ign, "%s", r.ignorados);
  if(proxima_mudou) *proxima_mudou = r.proxima_mudou;
  pthread_mutex_unlock(&trava);
  return st;
}

void ampr_ajuste_rota_aplicar(pedido_t *p) {
  static char nomes[AJ_MAX][AJ_NOME + 1];
  static long long vals[AJ_MAX];
  static pthread_mutex_t trava = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_lock(&trava);
  int n = 0;
  for(; n < AJ_MAX + 1; n++) {
    char nm[128], vl[64];
    int tn = param(p->corpo, "nome", n, nm, sizeof nm), tv = param(p->corpo, "valor", n, vl, sizeof vl);
    if(!tn && !tv) break;
    if(n >= AJ_MAX) {
      pthread_mutex_unlock(&trava);
      responder_erro(p, 400, "ampr_aj_nome", "ajustes demais num pedido", NULL);
      return;
    }
    if(!tn || !nome_ajuste_ok(nm, strlen(nm)) || strlen(nm) > AJ_NOME) {
      pthread_mutex_unlock(&trava);
      responder_erro(p, 400, "ampr_aj_nome", "nome de ajuste invalido", tn ? NULL : "");
      return;
    }
    size_t k = tv ? strlen(vl) : 0;
    if(!k || k > 15 || strspn(vl, "0123456789") != k) {
      pthread_mutex_unlock(&trava);
      responder_erro(p, 400, "ampr_aj_valor", "valor invalido (so numeros)", nm);
      return;
    }
    snprintf(nomes[n], sizeof nomes[n], "%s", nm);
    vals[n] = atoll(vl);
  }
  if(!n) {
    pthread_mutex_unlock(&trava);
    responder_erro(p, 400, "ampr_aj_vazio", "nenhum ajuste no pedido", NULL);
    return;
  }
  aplicar_lista(p, nomes, vals, n, 0, 0, "");
  pthread_mutex_unlock(&trava);
}

/* ------------------------------------------------------------------ POST /api/ampr/padrao */

/* 0.9.64: apaga o arquivo de ajustes (rota e bateria). 1 = apagou, 0 = nao havia, -1 = erro (errno). */
int ampr_padrao(void) {
  char aj[600];
  arquivo_ajustes(aj, sizeof aj);
  struct stat st;
  if(lstat(aj, &st)) return 0;
  return unlink(aj) ? -1 : 1;
}

void ampr_arquivo_ajustes(char *s, size_t tam) { arquivo_ajustes(s, tam); }

void ampr_ajuste_rota_padrao(pedido_t *p) {
  char aj[600];
  arquivo_ajustes(aj, sizeof aj);
  int r = ampr_padrao();
  if(r < 0) {
    int e = errno;
    diario("ampr-ajuste: apagar %s: %s", aj, strerror(e));
    responder_erro(p, 500, "ampr_padrao", strerror(e), NULL);
    return;
  }
  int tinha = r > 0;
  diario("ampr-ajuste: voltar ao padrao (%s)", tinha ? "arquivo de ajustes apagado" : "nao havia arquivo de ajustes");
  buf_t b = {0};
  estado_json(&b, 0);
  buf_fmt(&b, ",\"apagado\":%s,\"mensagem\":", tinha ? "true" : "false");
  buf_json(&b, "vale na proxima abertura do jogo; o que ja foi aplicado na hora fica ate o jogo fechar");
  buf_str(&b, "}");
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* ------------------------------------------------------------------ POST /api/ampr/medir e /bench */

/* 0.9.64: nucleo do "Medir agora" (rota e bateria, tipo compat). 0 = gravou (nome); senao o HTTP do erro e a chave. */
static int medir_core(const char *nota, const char *cab_extra, char *nome, size_t tam_nome, const char **chave, const char **msg) {
  int st = comecar_sem(chave, msg);
  if(st) return st;
  static const char *const CAMINHOS[] = {"/metrics", "/threads", "/set", "/fsfail"};
  buf_t r[4] = {{0}};
  for(int i = 0; i < 4; i++) ampr_dep_get(CAMINHOS[i], &r[i], 3);
  static cont_t resumo;   /* so com g_dep */
  memset(&resumo, 0, sizeof resumo);
  if(r[0].d) cache_metrics(r[0].d, &resumo);   /* o /metrics desta medida (os *_max zeraram com ele) */
  cont_t meu = resumo;
  pthread_mutex_unlock(&g_dep);
  int g = gravar_medida(nota, cab_extra, &meu, NULL, CAMINHOS, r, 4, nome, tam_nome);
  for(int i = 0; i < 4; i++) buf_free(&r[i]);
  if(g) {
    *chave = "ampr_medida_gravar";
    *msg = "nao deu para gravar a medida";
    return 500;
  }
  diario("ampr-ajuste: medida %s guardada%s%s", nome, nota[0] ? ": " : "", nota);
  return 0;
}

void ampr_ajuste_rota_medir(pedido_t *p) {
  char nota[NOTA_MAX + 8], nome[48];
  const char *chave, *msg;
  pedir_nota(p, nota, sizeof nota);
  int st = medir_core(nota, NULL, nome, sizeof nome, &chave, &msg);
  if(st) {
    responder_erro(p, st, chave, msg, NULL);
    return;
  }
  buf_t b = {0};
  estado_json(&b, 0);
  buf_str(&b, ",\"medida\":");
  buf_json(&b, nome);
  buf_str(&b, "}");
  responder_json(p, 200, &b);
  buf_free(&b);
}

int ampr_medir_curto(const char *nota, const char *cab_extra, char *nome, size_t tam_nome) {
  const char *chave, *msg;
  return medir_core(nota, cab_extra, nome, tam_nome, &chave, &msg);
}

void ampr_ajuste_rota_bench(pedido_t *p) {
  char nota[NOTA_MAX + 8], nota2[NOTA_MAX + 16], nome[48];
  pedir_nota(p, nota, sizeof nota);
  snprintf(nota2, sizeof nota2, "bench%s%s", nota[0] ? ": " : "", nota);
  if(comecar(p)) return;
  static const char *const CAMINHOS[] = {"/bench"};
  buf_t r[1] = {{0}};
  int st = ampr_dep_get("/bench", &r[0], BENCH_ESPERA_S);
  pthread_mutex_unlock(&g_dep);
  if(st < 0) {
    buf_free(&r[0]);
    diario("ampr-ajuste: /bench sem resposta");
    responder_erro(p, 409, "ampr_dep_fora", "o ampr-emu-ng nao respondeu a medida do disco", NULL);
    return;
  }
  int g = gravar_medida(nota2, NULL, NULL, NULL, CAMINHOS, r, 1, nome, sizeof nome);
  if(g) {
    buf_free(&r[0]);
    responder_erro(p, 500, "ampr_medida_gravar", "nao deu para gravar a medida", NULL);
    return;
  }
  diario("ampr-ajuste: medida do disco %s guardada", nome);
  buf_t b = {0};
  estado_json(&b, 0);
  buf_str(&b, ",\"medida\":");
  buf_json(&b, nome);
  buf_str(&b, ",\"texto\":");
  buf_json(&b, r[0].d ? r[0].d : "");
  buf_str(&b, "}");
  buf_free(&r[0]);
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* ------------------------------------------------------------------ POST /api/ampr/medida/apagar */

void ampr_ajuste_rota_apagar(pedido_t *p) {
  char nome[128] = "";
  param(p->corpo, "nome", 0, nome, sizeof nome);
  if(!nome_medida_ok(nome)) {
    responder_erro(p, 400, "ampr_medida_nome", "nome de medida invalido", NULL);
    return;
  }
  char c[700];
  struct stat st;
  pasta_medidas(c, sizeof c);
  size_t k = strlen(c);
  snprintf(c + k, sizeof c - k, "/%s", nome);
  if(lstat(c, &st) || !S_ISREG(st.st_mode)) {
    responder_erro(p, 404, "ampr_medida_nao_achou", "medida nao encontrada", nome);
    return;
  }
  if(unlink(c)) {
    responder_erro(p, 500, "ampr_medida_apagar", strerror(errno), nome);
    return;
  }
  diario("ampr-ajuste: medida %s apagada", nome);
  buf_t b = {0};
  estado_json(&b, 0);
  buf_str(&b, "}");
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* ================================================================== 0.9.63: trecho, FPS, sugestoes, conjuntos, disco */

static void responder_estado(pedido_t *p, const char *chave_extra, const char *valor_extra) {
  buf_t b = {0};
  estado_json(&b, 0);
  if(chave_extra) {
    buf_fmt(&b, ",\"%s\":", chave_extra);
    buf_json(&b, valor_extra ? valor_extra : "");
  }
  buf_str(&b, "}");
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* ------------------------------------------------------------------ amostrador (durante um trecho) */

/* A cada 1 s: temperatura (termico.c), clocks da CPU/GPU (desempenho.c) e, se pedido, o FPS (fps.c; ligar o FPS custa
   ~500 leituras do contador de quadros por segundo, por isso e opcional). */
#define AMOSTRAS_MAX 3600
typedef struct {
  double min, max, soma;
  int n;
} faixa_t;
static void faixa_add(faixa_t *f, double v) {
  if(v <= 0) return;
  if(!f->n || v < f->min) f->min = v;
  if(!f->n || v > f->max) f->max = v;
  f->soma += v;
  f->n++;
}
static struct {
  int rodando, parar, fps, amostras, nf;
  pthread_t t;
  faixa_t cpu_c, soc_c, cpu_mhz, gpu_mhz, fps_f;
  float fps_v[AMOSTRAS_MAX];
  double pior_ms, low1;
} g_am;
static pthread_mutex_t g_trava_am = PTHREAD_MUTEX_INITIALIZER;

static int amostra_intervalo_ms(void) {
#ifndef __PROSPERO__
  const char *e = getenv("GLR_TESTE_AMOSTRA_MS");
  if(e && atoi(e) > 0) return atoi(e);
#endif
  return 1000;
}

static void amostrar(int fps) {
  buf_t t = {0}, d = {0}, f = {0};
  termico_json(&t, 0);
  desempenho_pedido();
  buf_str(&d, "{");
  desempenho_json(&d);
  buf_str(&d, "}");
  double v_fps = -1, pior = -1, low = -1;
  if(fps) {
    fps_json(&f, 0);
    v_fps = campo_num(f.d, f.n, "fps", NULL);
    pior = campo_num(f.d, f.n, "pior_ms", NULL);
    low = campo_num(f.d, f.n, "low1", NULL);
  }
  pthread_mutex_lock(&g_trava_am);
  faixa_add(&g_am.cpu_c, campo_num(t.d, t.n, "cpu", NULL));
  faixa_add(&g_am.soc_c, campo_num(t.d, t.n, "soc", NULL));
  faixa_add(&g_am.cpu_mhz, campo_num(d.d, d.n, "desempenho", "cpu_mhz"));
  faixa_add(&g_am.gpu_mhz, campo_num(d.d, d.n, "desempenho", "gpu_mhz"));
  if(v_fps > 0) {
    faixa_add(&g_am.fps_f, v_fps);
    if(g_am.nf < AMOSTRAS_MAX) g_am.fps_v[g_am.nf++] = (float)v_fps;
  }
  if(pior > g_am.pior_ms) g_am.pior_ms = pior;
  if(low > 0) g_am.low1 = low;
  g_am.amostras++;
  pthread_mutex_unlock(&g_trava_am);
  buf_free(&t);
  buf_free(&d);
  buf_free(&f);
}

static int am_parar(void) {
  pthread_mutex_lock(&g_trava_am);
  int p = g_am.parar;
  pthread_mutex_unlock(&g_trava_am);
  return p;
}

static void *amostrador(void *arg) {
  (void)arg;
  while(!am_parar()) {
    pthread_mutex_lock(&g_trava_am);
    int fps = g_am.fps;
    pthread_mutex_unlock(&g_trava_am);
    amostrar(fps);
    for(int i = 0; i < amostra_intervalo_ms() / 50 && !am_parar(); i++) usleep(50 * 1000);
  }
  return NULL;
}

static void amostrador_ligar(int fps) {
  pthread_mutex_lock(&g_trava_am);
  if(g_am.rodando) {
    pthread_mutex_unlock(&g_trava_am);
    return;
  }
  memset(&g_am, 0, sizeof g_am);
  g_am.fps = fps;
  g_am.pior_ms = -1;
  g_am.rodando = 1;
  pthread_t t;
  pthread_mutex_unlock(&g_trava_am);
  if(criar_thread(amostrador, NULL, &t)) {
    pthread_mutex_lock(&g_trava_am);
    g_am.rodando = 0;
    pthread_mutex_unlock(&g_trava_am);
    return;
  }
  pthread_mutex_lock(&g_trava_am);
  g_am.t = t;
  pthread_mutex_unlock(&g_trava_am);
}

static void faixa_texto(buf_t *b, const char *nome, const faixa_t *f, const char *un) {
  if(!f->n) buf_fmt(b, "%s: -\n", nome);
  else buf_fmt(b, "%s: min %.0f, media %.0f, max %.0f %s\n", nome, f->min, f->soma / f->n, f->max, un);
}

/* Para o amostrador; texto (pode ser NULL) recebe o resumo do trecho. 0.9.64: res (pode ser NULL) recebe os numeros. */
static void amostrador_parar_res(buf_t *texto, ampr_resumo_t *res);
static void amostrador_parar(buf_t *texto) { amostrador_parar_res(texto, NULL); }
static void amostrador_parar_res(buf_t *texto, ampr_resumo_t *res) {
  static pthread_mutex_t so_um = PTHREAD_MUTEX_INITIALIZER;   /* 0.9.64: rota e bateria ao mesmo tempo: um join so */
  pthread_mutex_lock(&so_um);
  pthread_mutex_lock(&g_trava_am);
  int r = g_am.rodando;
  g_am.parar = 1;
  pthread_t t = g_am.t;
  pthread_mutex_unlock(&g_trava_am);
  if(r) pthread_join(t, NULL);
  pthread_mutex_lock(&g_trava_am);
  if(texto) {
    buf_fmt(texto, "amostras: %d (1 a cada %d ms)\n", g_am.amostras, amostra_intervalo_ms());
    faixa_texto(texto, "temperatura da CPU", &g_am.cpu_c, "C");
    faixa_texto(texto, "temperatura do SoC", &g_am.soc_c, "C");
    faixa_texto(texto, "clock da CPU", &g_am.cpu_mhz, "MHz");
    faixa_texto(texto, "clock da GPU", &g_am.gpu_mhz, "MHz");
    if(!g_am.fps) buf_str(texto, "FPS: nao medido (marque \"Medir FPS durante o trecho\")\n");
    else if(!g_am.fps_f.n) buf_str(texto, "FPS: sem leitura (jogo de PS4, sem jogo na tela ou leitura recusada)\n");
    else {
      double media = g_am.fps_f.soma / g_am.fps_f.n;
      int quedas = 0;
      for(int i = 0; i < g_am.nf; i++) quedas += g_am.fps_v[i] < 0.8 * media;
      buf_fmt(texto, "FPS (leitura do glibren, por segundo): media %.1f, minimo %.1f, maximo %.1f\n", media, g_am.fps_f.min, g_am.fps_f.max);
      buf_fmt(texto, "1%% low: %.1f; pior quadro: %.1f ms; segundos abaixo de 80%% da media (engasgos): %d de %d\n", g_am.low1,
              g_am.pior_ms, quedas, g_am.nf);
    }
  }
  if(res) {   /* 0.9.64: para a bateria (-1 = sem leitura) */
    res->fps_media = g_am.fps && g_am.fps_f.n ? g_am.fps_f.soma / g_am.fps_f.n : -1;
    res->low1 = g_am.fps && g_am.fps_f.n && g_am.low1 > 0 ? g_am.low1 : -1;
    res->pior_ms = g_am.fps && g_am.fps_f.n ? g_am.pior_ms : -1;
    res->temp_max = g_am.cpu_c.n || g_am.soc_c.n ? (g_am.cpu_c.max > g_am.soc_c.max ? g_am.cpu_c.max : g_am.soc_c.max) : -1;
  }
  g_am.rodando = 0;
  pthread_mutex_unlock(&g_trava_am);
  pthread_mutex_unlock(&so_um);
}

/* ------------------------------------------------------------------ trecho (inicio/fim) */

/* Inicio guarda um /metrics (na memoria e em <dados>/ampr-trecho-inicio.txt, para um glibren reaberto); fim pega outro
   e a medida tem o resumo da DIFERENCA (fim - inicio). Os *_max ficam de fora: zeram a cada leitura do /metrics. */
static struct {
  int aberto, fps;
  long long t0;
  buf_t m0;
  char cab0[300];
} g_tr;
static pthread_mutex_t g_trava_tr = PTHREAD_MUTEX_INITIALIZER;
static void arquivo_trecho(char *s, size_t tam) { snprintf(s, tam, "%s/ampr-trecho-inicio.txt", g_pasta_dados); }

/* glibren reaberto no meio de um trecho: le o inicio do arquivo. Chamar com g_trava_tr. */
static void trecho_carregar(void) {
  if(g_tr.aberto) return;
  char c[600];
  arquivo_trecho(c, sizeof c);
  FILE *f = fopen(c, "rb");
  if(!f) return;
  char linha[64];
  long long t0 = 0;
  if(fgets(linha, sizeof linha, f) && sscanf(linha, "inicio: %lld", &t0) == 1 && t0 > 0) {
    char bloco[4096];
    size_t k;
    buf_free(&g_tr.m0);
    while((k = fread(bloco, 1, sizeof bloco, f)) > 0 && g_tr.m0.n < DEP_MAX_RESP) buf_add(&g_tr.m0, bloco, k);
    g_tr.aberto = 1;
    g_tr.t0 = t0;
    snprintf(g_tr.cab0, sizeof g_tr.cab0, "(o glibren foi reaberto no meio do trecho: sem temperatura do inicio nem amostras)\n");
  }
  fclose(f);
}

static void trecho_fechar(void) {   /* chamar com g_trava_tr */
  char c[600];
  arquivo_trecho(c, sizeof c);
  unlink(c);
  buf_free(&g_tr.m0);
  g_tr.aberto = 0;
}

/* 0.9.64: nucleo do Inicio do trecho (rota e bateria). 0 = aberto; senao o HTTP do erro e a chave/mensagem. */
static int trecho_comecar_core(int com_fps, const char **chave, const char **msg) {
  pthread_mutex_lock(&g_trava_tr);
  trecho_carregar();
  int aberto = g_tr.aberto;
  pthread_mutex_unlock(&g_trava_tr);
  if(aberto) {
    *chave = "ampr_trecho_aberto";
    *msg = "ja ha um trecho aberto: toque em Fim do trecho (ou Cancelar)";
    return 409;
  }
  int st = comecar_sem(chave, msg);
  if(st) return st;
  buf_t m = {0};
  st = ampr_dep_get("/metrics", &m, 3);
  if(st >= 0) cache_metrics(m.d, NULL);
  pthread_mutex_unlock(&g_dep);
  if(st < 0) {
    buf_free(&m);
    *chave = "ampr_dep_fora";
    *msg = "o ampr-emu-ng nao respondeu ao /metrics";
    return 409;
  }
  buf_t cab = {0};
  termico_linha(&cab, "no inicio");
  pthread_mutex_lock(&g_trava_tr);
  g_tr.aberto = 1;
  g_tr.fps = com_fps;
  g_tr.t0 = (long long)time(NULL);
  g_tr.m0 = m;
  snprintf(g_tr.cab0, sizeof g_tr.cab0, "%s", cab.d ? cab.d : "");
  char c[600];
  arquivo_trecho(c, sizeof c);
  FILE *f = fopen(c, "wb");
  if(f) {
    fprintf(f, "inicio: %lld\n", g_tr.t0);
    fwrite(m.d, 1, m.n, f);
    fclose(f);
  }
  pthread_mutex_unlock(&g_trava_tr);
  buf_free(&cab);
  amostrador_ligar(com_fps);
  diario("ampr-ajuste: inicio do trecho%s", com_fps ? " (com FPS)" : "");
  return 0;
}

static void ampr_trecho_inicio(pedido_t *p) {
  char fps[8] = "";
  const char *chave, *msg;
  param(p->corpo, "fps", 0, fps, sizeof fps);
  int st = trecho_comecar_core(!strcmp(fps, "1"), &chave, &msg);
  if(st) {
    responder_erro(p, st, chave, msg, NULL);
    return;
  }
  responder_estado(p, NULL, NULL);
}

/* 0.9.64: nucleo do Fim do trecho (rota e bateria). cab_extra = linhas a mais no cabecalho; res (pode ser NULL) = os
   numeros do resumo. 0 = medida gravada (nome); senao o HTTP do erro e a chave/mensagem. */
static int trecho_terminar_core(const char *nota, const char *cab_extra, char *nome, size_t tam_nome, ampr_resumo_t *res,
                                const char **chave, const char **msg) {
  pthread_mutex_lock(&g_trava_tr);
  trecho_carregar();
  int aberto = g_tr.aberto;
  pthread_mutex_unlock(&g_trava_tr);
  if(!aberto) {
    *chave = "ampr_trecho_fechado";
    *msg = "nenhum trecho aberto: toque em Inicio do trecho antes";
    return 409;
  }
  int st0 = comecar_sem(chave, msg);
  if(st0) return st0;
  static const char *const CAMINHOS[] = {"Durante o trecho", "/metrics (inicio)", "/metrics (fim)", "/threads", "/set", "/fsfail"};
  static const char *const PEDIR[] = {"/metrics", "/threads", "/set", "/fsfail"};
  buf_t r[6] = {{0}};
  for(int i = 0; i < 4; i++) ampr_dep_get(PEDIR[i], &r[2 + i], 3);
  static cont_t c0, c1, dif;   /* so com g_dep */
  memset(&c1, 0, sizeof c1);
  if(r[2].d) cache_metrics(r[2].d, &c1);
  pthread_mutex_lock(&g_trava_tr);
  ler_contadores(g_tr.m0.d, &c0);
  memset(&dif, 0, sizeof dif);
  for(int i = 0; i < N_CONT; i++) {
    size_t k = strlen(CONT[i]);
    if(!c0.tem[i] || !c1.tem[i] || (k > 4 && !strcmp(CONT[i] + k - 4, "_max"))) continue;
    dif.v[i] = c1.v[i] >= c0.v[i] ? c1.v[i] - c0.v[i] : 0;
    dif.tem[i] = 1;
  }
  cont_t meu = dif;
  pthread_mutex_unlock(&g_dep);
  long long t0 = g_tr.t0, seg = (long long)time(NULL) - t0;
  buf_add(&r[1], g_tr.m0.d ? g_tr.m0.d : "", g_tr.m0.n);
  buf_t cab = {0};
  char h0[16], h1[16];
  time_t a = (time_t)t0, b2 = time(NULL);
  struct tm tm;
  localtime_r(&a, &tm);
  strftime(h0, sizeof h0, "%H:%M:%S", &tm);
  localtime_r(&b2, &tm);
  strftime(h1, sizeof h1, "%H:%M:%S", &tm);
  buf_fmt(&cab, "trecho: %lld s (de %s a %s)\n%s", seg, h0, h1, g_tr.cab0);
  pthread_mutex_unlock(&g_trava_tr);
  termico_linha(&cab, "no fim");
  if(cab_extra && *cab_extra) buf_str(&cab, cab_extra);
  amostrador_parar_res(&r[0], res);
  if(res) {   /* 0.9.64: os numeros do resumo da diferenca (-1 = contador ausente) */
    static const struct {
      const char *chave;
      size_t pos;
    } M[] = {{"bloco_ms", offsetof(ampr_resumo_t, bloco_ms)},       {"leitura_ms", offsetof(ampr_resumo_t, leitura_ms)},
             {"decode_us", offsetof(ampr_resumo_t, decode_us)},     {"cache_pct", offsetof(ampr_resumo_t, cache_pct)},
             {"peso_decode_pct", offsetof(ampr_resumo_t, peso_decode_pct)}, {"disco_kib", offsetof(ampr_resumo_t, disco_kib)}};
    for(size_t k = 0; k < sizeof M / sizeof M[0]; k++) {
      double *d = (double *)((char *)res + M[k].pos), v;
      *d = -1;
      for(int i = 0; i < N_CAMPOS; i++)
        if(!strcmp(CAMPOS[i].chave, M[k].chave) && campo(&meu, &CAMPOS[i], &v)) *d = v;
    }
    res->segundos = (double)seg;
  }
  int g = gravar_medida(nota, cab.d, &meu, "diferenca fim - inicio do trecho; os *_max ficam de fora (zeram a cada leitura)", CAMINHOS, r,
                        6, nome, tam_nome);
  for(int i = 0; i < 6; i++) buf_free(&r[i]);
  buf_free(&cab);
  if(g) {
    *chave = "ampr_medida_gravar";
    *msg = "nao deu para gravar a medida";
    return 500;
  }
  pthread_mutex_lock(&g_trava_tr);
  trecho_fechar();
  pthread_mutex_unlock(&g_trava_tr);
  diario("ampr-ajuste: fim do trecho (%lld s): medida %s", seg, nome);
  return 0;
}

static void ampr_trecho_fim(pedido_t *p) {
  char nota[NOTA_MAX + 8], nome[48];
  const char *chave, *msg;
  pedir_nota(p, nota, sizeof nota);
  int st = trecho_terminar_core(nota, NULL, nome, sizeof nome, NULL, &chave, &msg);
  if(st) {
    responder_erro(p, st, chave, msg, NULL);
    return;
  }
  responder_estado(p, "medida", nome);
}

void ampr_trecho_desistir(void) {
  amostrador_parar(NULL);
  pthread_mutex_lock(&g_trava_tr);
  trecho_carregar();
  trecho_fechar();
  pthread_mutex_unlock(&g_trava_tr);
}

static void ampr_trecho_cancelar(pedido_t *p) {
  ampr_trecho_desistir();
  responder_estado(p, NULL, NULL);
}

/* 0.9.64: para a bateria (ver ampr_ajuste.h) */
int ampr_trecho_comecar(int fps, char *erro, size_t tam_erro) {
  const char *chave = "", *msg = "";
  int st = trecho_comecar_core(fps, &chave, &msg);
  if(st) snprintf(erro, tam_erro, "%s: %s", chave, msg);
  return st;
}

int ampr_trecho_terminar(const char *nota, const char *cab_extra, char *medida, size_t tam, ampr_resumo_t *res, char *erro, size_t tam_erro) {
  const char *chave = "", *msg = "";
  int st = trecho_terminar_core(nota, cab_extra, medida, tam, res, &chave, &msg);
  if(st) snprintf(erro, tam_erro, "%s: %s", chave, msg);
  return st;
}

/* 0.9.64: os contadores da heuristica de "carregou" (sem esperar outra conversa: ocupado = -1). */
int ampr_contadores(ampr_cont4_t *c) {
  memset(c, 0, sizeof *c);
  if(dep_trancar(1500)) return -1;
  buf_t m = {0};
  int st = ampr_dep_get("/metrics", &m, 2);
  static cont_t k;   /* so com g_dep */
  if(st >= 0) cache_metrics(m.d, &k);
  if(st >= 0) {
    c->apr_read_bytes = (unsigned long long)val(&k, "apr_read_bytes");
    c->apr_reads = (unsigned long long)val(&k, "apr_reads");
    c->pack_disk_bytes = (unsigned long long)val(&k, "pack_disk_bytes");
    c->decodes = (unsigned long long)val(&k, "decodes");
    c->tem_bytes = tem(&k, "apr_read_bytes");
  }
  pthread_mutex_unlock(&g_dep);
  buf_free(&m);
  return st >= 0 ? 1 : 0;
}

/* 0.9.64: build e formato do ultimo /metrics lido (a bateria guarda no resultado). */
void ampr_build_atual(char *build, size_t tb, char *formato, size_t tf) {
  pthread_mutex_lock(&g_cache);
  snprintf(build, tb, "%s", g_c.build);
  snprintf(formato, tf, "%s", g_c.formato);
  pthread_mutex_unlock(&g_cache);
}

/* ------------------------------------------------------------------ cronometro de carregamento */

static void ampr_marca(pedido_t *p) {
  char tipo[16] = "", texto[80];
  param(p->corpo, "tipo", 0, tipo, sizeof tipo);
  pedir_texto(p, "texto", texto, sizeof texto, 60);
  if(strcmp(tipo, "abri") && strcmp(tipo, "menu") && strcmp(tipo, "save") && strcmp(tipo, "livre") && strcmp(tipo, "zerar")) {
    responder_erro(p, 400, "ampr_marca_tipo", "marca invalida", NULL);
    return;
  }
  int no_ar = 0, jogo = 0;
  pthread_mutex_lock(&g_trava_marcas);
  int primeira = !g_nmarcas;
  pthread_mutex_unlock(&g_trava_marcas);
  if(primeira && strcmp(tipo, "zerar")) {   /* estados de agora, para as marcas automaticas so pegarem mudancas */
    char tid[16];
    jogo = app_de_jogo_aberto(tid, sizeof tid) == 1;
    pthread_mutex_lock(&g_cache);
    no_ar = g_c.no_ar;
    pthread_mutex_unlock(&g_cache);
  }
  pthread_mutex_lock(&g_trava_marcas);
  if(!strcmp(tipo, "zerar")) g_nmarcas = 0;
  else {
    if(!g_nmarcas) {
      g_marca_jogo = jogo;
      g_marca_no_ar = no_ar;
    }
    marca_add(tipo, texto);
  }
  pthread_mutex_unlock(&g_trava_marcas);
  responder_estado(p, NULL, NULL);
}

/* ------------------------------------------------------------------ sugestoes do Claude */

/* glibren/ampr-sugestoes.json do repositorio privado de diagnosticos (a mesma chave do "Enviar diagnostico"), so leitura.
   Formato: {"rodada":3,"criado":"...","titulo":"...","explicacao":"...","ajustes":{"workers":6},"medir":"..."}. Guardado
   ja conferido em <dados>/ampr-sugestao.json (o glibren reescreve: so os campos conhecidos, textos com tamanho maximo). */
#define SUG_CAMINHO "/repos/pristmc-code/ps5-diagnosticos/contents/glibren/ampr-sugestoes.json"
static time_t g_sug_ult;
static void arquivo_sugestao(char *s, size_t tam) { snprintf(s, tam, "%s/ampr-sugestao.json", g_pasta_dados); }

void ampr_base64_dec(const char *in, size_t n, buf_t *out) {
  uint32_t v = 0;
  int bits = 0;
  for(size_t i = 0; i < n; i++) {
    char c = in[i];
    int x = c >= 'A' && c <= 'Z' ? c - 'A' : c >= 'a' && c <= 'z' ? c - 'a' + 26 : c >= '0' && c <= '9' ? c - '0' + 52 :
            c == '+' ? 62 : c == '/' ? 63 : -1;
    if(x < 0) continue;   /* \n, = e espacos */
    v = v << 6 | (uint32_t)x;
    bits += 6;
    if(bits >= 8) {
      bits -= 8;
      unsigned char o = (unsigned char)(v >> bits);
      buf_add(out, &o, 1);
    }
  }
}

/* {"k":numero,...} -> nomes/valores; -1 se algo estiver fora do formato */
static int ler_obj_ajustes(const js_t *v, char nomes[][AJ_NOME + 1], long long *vals, int max) {
  js_t j = *v;
  if(j.p >= j.fim || *j.p != '{') return -1;
  j.p++;
  int n = 0;
  for(;;) {
    js_esp(&j);
    if(j.p >= j.fim) return -1;
    if(*j.p == '}') return n;
    if(*j.p == ',') {
      j.p++;
      continue;
    }
    char k[64];
    if(*j.p != '"' || js_string(&j, k, sizeof k)) return -1;
    js_esp(&j);
    if(j.p >= j.fim || *j.p != ':') return -1;
    j.p++;
    js_esp(&j);
    long long x = 0;
    int dig = 0;
    while(j.p < j.fim && isdigit((unsigned char)*j.p) && dig < 16) x = x * 10 + (*j.p++ - '0'), dig++;
    if(!dig || n >= max || strlen(k) > AJ_NOME || !nome_ajuste_ok(k, strlen(k))) return -1;
    snprintf(nomes[n], AJ_NOME + 1, "%s", k);
    vals[n++] = x;
  }
}

/* Confere e reescreve a sugestao (json bruto) no formato do glibren. 0 = ok. */
static int sugestao_normalizar(const char *d, size_t n, buf_t *out, char *erro, size_t tam_erro) {
  js_t o = {d, d + n}, v;
  static char nomes[AJ_MAX][AJ_NOME + 1];
  static long long vals[AJ_MAX];
  static char explicacao[2048];
  char titulo[160] = "", criado[40] = "", medir[700] = "";
  js_esp(&o);
  if(o.p >= o.fim || *o.p != '{' || !js_campo(&o, "rodada", &v)) {
    snprintf(erro, tam_erro, "sem o campo rodada");
    return -1;
  }
  unsigned long long rodada = js_num(&v);
  if(rodada < 1 || rodada > 1000000) {
    snprintf(erro, tam_erro, "rodada invalida");
    return -1;
  }
  explicacao[0] = 0;
  if(js_campo(&o, "titulo", &v)) js_string(&v, titulo, sizeof titulo);
  if(js_campo(&o, "criado", &v)) js_string(&v, criado, sizeof criado);
  if(js_campo(&o, "explicacao", &v)) js_string(&v, explicacao, sizeof explicacao);
  if(js_campo(&o, "medir", &v)) js_string(&v, medir, sizeof medir);
  int na = js_campo(&o, "ajustes", &v) ? ler_obj_ajustes(&v, nomes, vals, AJ_MAX) : -1;
  if(na < 0) {
    snprintf(erro, tam_erro, "ajustes fora do formato (nome: numero)");
    return -1;
  }
  buf_fmt(out, "{\"rodada\":%llu,\"criado\":", rodada);
  buf_json(out, criado);
  buf_str(out, ",\"titulo\":");
  buf_json(out, titulo);
  buf_str(out, ",\"explicacao\":");
  buf_json(out, explicacao);
  buf_str(out, ",\"medir\":");
  buf_json(out, medir);
  buf_str(out, ",\"ajustes\":{");
  for(int i = 0; i < na; i++) buf_fmt(out, "%s\"%s\":%lld", i ? "," : "", nomes[i], vals[i]);
  buf_fmt(out, "},\"buscado\":%lld}", (long long)time(NULL));
  return 0;
}

static int ler_pequeno(const char *c, buf_t *b, size_t max) {
  FILE *f = fopen(c, "rb");
  if(!f) return -1;
  char bloco[4096];
  size_t k;
  while((k = fread(bloco, 1, sizeof bloco, f)) > 0 && b->n < max) buf_add(b, bloco, k);
  fclose(f);
  return b->n ? 0 : -1;
}

static void ampr_sugestao_buscar(pedido_t *p) {
  time_t agora = time(NULL);
  if(g_sug_ult && agora - g_sug_ult < 30) {
    responder_erro(p, 429, "ampr_sug_espera", "busca feita ha menos de 30 s: espere um pouco", NULL);
    return;
  }
  g_sug_ult = agora;
  char chave[256];
  if(!diagnostico_chave_ler(chave, sizeof chave)) {
    responder_erro(p, 400, "ampr_sug_sem_chave", "falta a chave do GitHub (pagina Diagnostico)", NULL);
    return;
  }
  buf_t r = {0};
  int st = https_github_get(SUG_CAMINHO, chave, &r, 1024 * 1024);
  memset(chave, 0, sizeof chave);
  if(st == 404) {
    buf_free(&r);
    responder_erro(p, 404, "ampr_sug_nenhuma", "nenhuma sugestao publicada ainda", NULL);
    return;
  }
  if(st != 200 || !r.d) {
    buf_free(&r);
    char msg[80];
    snprintf(msg, sizeof msg, "o GitHub nao respondeu (HTTP %d)", st);
    responder_erro(p, 502, "ampr_sug_http", msg, NULL);
    return;
  }
  js_t o = {r.d, r.d + r.n}, v;
  buf_t dec = {0}, norm = {0};
  char *conteudo = malloc(r.n + 1), erro[120] = "";
  int ok = conteudo && js_campo(&o, "content", &v) && !js_string(&v, conteudo, r.n + 1);
  if(ok) ampr_base64_dec(conteudo, strlen(conteudo), &dec);
  free(conteudo);
  buf_free(&r);
  if(!ok || !dec.d || sugestao_normalizar(dec.d, dec.n, &norm, erro, sizeof erro)) {
    buf_free(&dec);
    buf_free(&norm);
    char msg[200];
    snprintf(msg, sizeof msg, "sugestao fora do formato: %s", erro[0] ? erro : "sem conteudo");
    responder_erro(p, 422, "ampr_sug_formato", msg, NULL);
    return;
  }
  buf_free(&dec);
  char c[600], tmp[620];
  arquivo_sugestao(c, sizeof c);
  snprintf(tmp, sizeof tmp, "%s.tmp", c);
  FILE *f = fopen(tmp, "wb");
  int gravou = f && fwrite(norm.d, 1, norm.n, f) == norm.n;
  if(f && fclose(f)) gravou = 0;
  if(!gravou || rename(tmp, c)) unlink(tmp);
  diario("ampr-ajuste: sugestao do Claude buscada (%zu bytes)", norm.n);
  buf_free(&norm);
  responder_estado(p, NULL, NULL);
}

static void ampr_sugestao_aplicar(pedido_t *p) {
  static char nomes[AJ_MAX][AJ_NOME + 1];
  static long long vals[AJ_MAX];
  static pthread_mutex_t trava = PTHREAD_MUTEX_INITIALIZER;
  char c[600];
  buf_t b = {0};
  arquivo_sugestao(c, sizeof c);
  if(ler_pequeno(c, &b, 64 * 1024)) {
    responder_erro(p, 404, "ampr_sug_nenhuma", "nenhuma sugestao buscada ainda", NULL);
    return;
  }
  pthread_mutex_lock(&trava);
  js_t o = {b.d, b.d + b.n}, v;
  int rodada_s = js_campo(&o, "rodada", &v) ? (int)js_num(&v) : 0;
  int n = js_campo(&o, "ajustes", &v) ? ler_obj_ajustes(&v, nomes, vals, AJ_MAX) : -1;
  buf_free(&b);
  if(n <= 0) {
    pthread_mutex_unlock(&trava);
    responder_erro(p, 400, "ampr_aj_vazio", "a sugestao nao tem ajustes", NULL);
    return;
  }
  char origem[48];
  snprintf(origem, sizeof origem, "sugestao rodada %d: ", rodada_s);
  aplicar_lista(p, nomes, vals, n, 0, rodada_s, origem);
  pthread_mutex_unlock(&trava);
}

/* ------------------------------------------------------------------ conjuntos salvos */

/* <dados>/ampr-conjuntos.txt, uma linha por conjunto: "nome<TAB>k=v,k=v". Mais o "Padrao 4db1b08" fixo (os padroes do
   release desse build; workers fica de fora: o padrao depende do console). */
#define CONJ_MAX 20
#define CONJ_PADRAO "Padr\xc3\xa3o 4db1b08"
typedef struct {
  char nome[64];
  char nomes[AJ_MAX][AJ_NOME + 1];
  long long v[AJ_MAX];
  int n;
} conj_t;
static conj_t g_conj[CONJ_MAX + 1];
static pthread_mutex_t g_trava_conj = PTHREAD_MUTEX_INITIALIZER;
static void arquivo_conjuntos(char *s, size_t tam) { snprintf(s, tam, "%s/ampr-conjuntos.txt", g_pasta_dados); }

static void conjunto_padrao(conj_t *c) {
  static const struct {
    const char *n;
    long long v;
  } P[] = {{"decoded_mib", 136}, {"pipelines", 12}, {"pread", 1}, {"pread_threads", 8}, {"loose_pread", 1},
           {"loose_pread_part_kib", 64}, {"read_pass_kib", 512}, {"read_chunk_quantum", 8}, {"per_read_active_kib", 2048},
           {"per_read_active_chunks", 4}, {"pread_wake_all", 0}, {"zstd_verify", 1}, {"thread_budget", 16}, {"spin_us", 100},
           {"regrow_s", 5}, {"worker_stack_kib", 0}, {"cache_protect_hits", 3}, {"cache_protect_pct", 50}, {"lane_eop_overlap", 1}};
  memset(c, 0, sizeof *c);
  snprintf(c->nome, sizeof c->nome, "%s", CONJ_PADRAO);
  for(size_t i = 0; i < sizeof P / sizeof P[0]; i++) {
    snprintf(c->nomes[c->n], AJ_NOME + 1, "%s", P[i].n);
    c->v[c->n++] = P[i].v;
  }
}

/* Le os conjuntos salvos (sem o fixo). Chamar com g_trava_conj. */
static int ler_conjuntos(conj_t *c, int max) {
  char arq[600], linha[4096];
  arquivo_conjuntos(arq, sizeof arq);
  FILE *f = fopen(arq, "r");
  if(!f) return 0;
  int n = 0;
  while(n < max && fgets(linha, sizeof linha, f)) {
    linha[strcspn(linha, "\r\n")] = 0;
    char *tab = strchr(linha, '\t');
    if(!tab || tab == linha || (size_t)(tab - linha) >= sizeof c[0].nome) continue;
    memset(&c[n], 0, sizeof c[n]);
    memcpy(c[n].nome, linha, (size_t)(tab - linha));
    for(char *par = strtok(tab + 1, ","); par && c[n].n < AJ_MAX; par = strtok(NULL, ",")) {
      char *ig = strchr(par, '=');
      if(!ig || !nome_ajuste_ok(par, (size_t)(ig - par)) || !ig[1] || strspn(ig + 1, "0123456789") != strlen(ig + 1)) continue;
      snprintf(c[n].nomes[c[n].n], AJ_NOME + 1, "%.*s", (int)(ig - par), par);
      c[n].v[c[n].n++] = atoll(ig + 1);
    }
    n++;
  }
  fclose(f);
  return n;
}

static int gravar_conjuntos(const conj_t *c, int n) {
  char arq[600], tmp[620];
  arquivo_conjuntos(arq, sizeof arq);
  snprintf(tmp, sizeof tmp, "%s.tmp", arq);
  FILE *f = fopen(tmp, "w");
  if(!f) return -1;
  for(int i = 0; i < n; i++) {
    fprintf(f, "%s\t", c[i].nome);
    for(int k = 0; k < c[i].n; k++) fprintf(f, "%s%s=%lld", k ? "," : "", c[i].nomes[k], c[i].v[k]);
    fprintf(f, "\n");
  }
  int ok = !fclose(f);
  if(!ok || rename(tmp, arq)) {
    unlink(tmp);
    return -1;
  }
  return 0;
}

static void conjuntos_json(buf_t *b) {
  pthread_mutex_lock(&g_trava_conj);
  conjunto_padrao(&g_conj[0]);
  int n = 1 + ler_conjuntos(g_conj + 1, CONJ_MAX);
  buf_str(b, ",\"conjuntos\":[");
  for(int i = 0; i < n; i++) {
    buf_str(b, i ? ",{\"nome\":" : "{\"nome\":");
    buf_json(b, g_conj[i].nome);
    buf_fmt(b, ",\"fixo\":%s,\"ajustes\":{", i ? "false" : "true");
    for(int k = 0; k < g_conj[i].n; k++) buf_fmt(b, "%s\"%s\":%lld", k ? "," : "", g_conj[i].nomes[k], g_conj[i].v[k]);
    buf_str(b, "}}");
  }
  buf_str(b, "]");
  pthread_mutex_unlock(&g_trava_conj);
}

/* nome= do conjunto (1 a 40 bytes, sem controle nem TAB); 0 = ok, senao ja respondeu */
static int pedir_nome_conjunto(pedido_t *p, char *nome, size_t tam) {
  pedir_texto(p, "nome", nome, tam, 40);
  if(!nome[0] || strchr(nome, '\t') || strchr(nome, ',')) {
    responder_erro(p, 400, "ampr_conj_nome", "nome invalido (1 a 40 caracteres, sem virgula)", NULL);
    return -1;
  }
  return 0;
}

static void ampr_conjunto_salvar(pedido_t *p) {
  char nome[64];
  if(pedir_nome_conjunto(p, nome, sizeof nome)) return;
  if(!strcmp(nome, CONJ_PADRAO)) {
    responder_erro(p, 400, "ampr_conj_fixo", "esse nome e do conjunto fixo", nome);
    return;
  }
  if(comecar(p)) return;   /* le a lista atual (os valores que vao no conjunto) */
  pthread_mutex_unlock(&g_dep);
  pthread_mutex_lock(&g_trava_conj);
  int n = ler_conjuntos(g_conj, CONJ_MAX), i = 0;
  while(i < n && strcmp(g_conj[i].nome, nome)) i++;
  if(i == n && n >= CONJ_MAX) {
    pthread_mutex_unlock(&g_trava_conj);
    responder_erro(p, 409, "ampr_conj_cheio", "ja ha 20 conjuntos: apague um antes", NULL);
    return;
  }
  memset(&g_conj[i], 0, sizeof g_conj[i]);
  snprintf(g_conj[i].nome, sizeof g_conj[i].nome, "%s", nome);
  pthread_mutex_lock(&g_cache);
  for(int k = 0; k < g_c.n && k < AJ_MAX; k++) {
    snprintf(g_conj[i].nomes[k], AJ_NOME + 1, "%s", g_c.aj[k].nome);
    g_conj[i].v[k] = g_c.aj[k].valor;
    g_conj[i].n++;
  }
  pthread_mutex_unlock(&g_cache);
  int r = gravar_conjuntos(g_conj, i == n ? n + 1 : n);
  pthread_mutex_unlock(&g_trava_conj);
  if(r) {
    responder_erro(p, 500, "ampr_conj_gravar", "nao deu para gravar os conjuntos", NULL);
    return;
  }
  diario("ampr-ajuste: conjunto \"%s\" salvo", nome);
  responder_estado(p, NULL, NULL);
}

static void ampr_conjunto_aplicar(pedido_t *p) {
  char nome[64];
  if(pedir_nome_conjunto(p, nome, sizeof nome)) return;
  static conj_t c;
  static pthread_mutex_t trava = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_lock(&trava);
  int achou = 0;
  if(!strcmp(nome, CONJ_PADRAO)) {
    conjunto_padrao(&c);
    achou = 1;
  } else {
    pthread_mutex_lock(&g_trava_conj);
    int n = ler_conjuntos(g_conj, CONJ_MAX);
    for(int i = 0; i < n && !achou; i++)
      if(!strcmp(g_conj[i].nome, nome)) {
        c = g_conj[i];
        achou = 1;
      }
    pthread_mutex_unlock(&g_trava_conj);
  }
  if(!achou) {
    pthread_mutex_unlock(&trava);
    responder_erro(p, 404, "ampr_conj_nao_achou", "conjunto nao encontrado", nome);
    return;
  }
  char origem[96];
  snprintf(origem, sizeof origem, "conjunto \"%s\": ", nome);
  aplicar_lista(p, c.nomes, c.v, c.n, 1, 0, origem);
  pthread_mutex_unlock(&trava);
}

static void ampr_conjunto_apagar(pedido_t *p) {
  char nome[64];
  if(pedir_nome_conjunto(p, nome, sizeof nome)) return;
  if(!strcmp(nome, CONJ_PADRAO)) {
    responder_erro(p, 400, "ampr_conj_fixo", "o conjunto fixo nao pode ser apagado", nome);
    return;
  }
  pthread_mutex_lock(&g_trava_conj);
  int n = ler_conjuntos(g_conj, CONJ_MAX), i = 0;
  while(i < n && strcmp(g_conj[i].nome, nome)) i++;
  int r = -2;
  if(i < n) {
    memmove(&g_conj[i], &g_conj[i + 1], sizeof g_conj[0] * (size_t)(n - i - 1));
    r = gravar_conjuntos(g_conj, n - 1);
  }
  pthread_mutex_unlock(&g_trava_conj);
  if(r == -2) {
    responder_erro(p, 404, "ampr_conj_nao_achou", "conjunto nao encontrado", nome);
    return;
  }
  if(r) {
    responder_erro(p, 500, "ampr_conj_gravar", "nao deu para gravar os conjuntos", NULL);
    return;
  }
  diario("ampr-ajuste: conjunto \"%s\" apagado", nome);
  responder_estado(p, NULL, NULL);
}

/* ------------------------------------------------------------------ enviar so uma medida */

/* glibren/ampr-medidas/<medida sem .txt>_env<AAAAMMDD-HHMMSS>.txt no repositorio de diagnosticos, higienizada como o
   diagnostico (diagnostico_subir_arquivo; em partes se passar de 8 MB). */
static void ampr_medida_enviar(pedido_t *p) {
  char nome[128] = "";
  param(p->corpo, "nome", 0, nome, sizeof nome);
  if(!nome_medida_ok(nome)) {
    responder_erro(p, 400, "ampr_medida_nome", "nome de medida invalido", NULL);
    return;
  }
  char c[700];
  struct stat st;
  pasta_medidas(c, sizeof c);
  size_t k = strlen(c);
  snprintf(c + k, sizeof c - k, "/%s", nome);
  if(lstat(c, &st) || !S_ISREG(st.st_mode)) {
    responder_erro(p, 404, "ampr_medida_nao_achou", "medida nao encontrada", nome);
    return;
  }
  char chave[256];
  if(!diagnostico_chave_ler(chave, sizeof chave)) {
    responder_erro(p, 400, "ampr_env_sem_chave", "falta a chave do GitHub (pagina Diagnostico)", NULL);
    return;
  }
  char hora[24] = "", destino[200], msg[160];
  time_t agora = time(NULL);
  struct tm tm;
  localtime_r(&agora, &tm);
  strftime(hora, sizeof hora, "%Y%m%d-%H%M%S", &tm);
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_DIAG_PASTA")) snprintf(hora, sizeof hora, "teste");
#endif
  snprintf(destino, sizeof destino, "glibren/ampr-medidas/%.*s_env%s.txt", (int)(strlen(nome) - 4), nome, hora);
  snprintf(msg, sizeof msg, "medida do ampr %s (glibren %s)", nome, VERSAO);
  diag_partes_t r;
  int s = diagnostico_subir_arquivo(chave, destino, msg, c, 0, (unsigned long long)st.st_size, 8u * 1024 * 1024, 1, &r, NULL);
  memset(chave, 0, sizeof chave);
  if(s != 201) {
    const char *k2 = s == -1 ? "ampr_env_rede" : s == 401 || s == 403 || s == 404 ? "ampr_env_chave" : "ampr_env_http";
    char m[80];
    snprintf(m, sizeof m, "nao subiu (HTTP %d)", s > 0 ? s : 0);
    diario("ampr-ajuste: enviar medida %s: %s", nome, m);
    responder_erro(p, 502, k2, m, nome);
    return;
  }
  diario("ampr-ajuste: medida %s enviada para ps5-diagnosticos/%s (%d parte(s))", nome, destino, r.partes);
  responder_estado(p, "destino", destino);
}

/* ------------------------------------------------------------------ teste de disco sem jogo */

/* Le (nunca grava) um arquivo grande de um disco do PS5 por ~20 s: metade em leituras seguidas de 8 MiB, metade em
   leituras de 64 KiB espalhadas pelo arquivo. Tenta O_DIRECT (sem o cache do sistema); se o sistema recusar, le sem e
   avisa que pode ter cache. Pode rodar com jogo aberto (avisa que disputa o disco). Vira uma medida. */
static struct {
  int rodando, progresso;
  char estado[12], caminho[600], nota[NOTA_MAX + 8], texto[1400], medida[48];
} g_dk = {0, 0, "parado", "", "", "", ""};
static pthread_mutex_t g_trava_dk = PTHREAD_MUTEX_INITIALIZER;

static double seg_desde(long long ms0) { return (double)(agora_ms() - ms0) / 1000.0; }

static int disco_segundos(void) {
#ifndef __PROSPERO__
  const char *e = getenv("GLR_TESTE_DISCO_S");
  if(e && atoi(e) > 0) return atoi(e);
#endif
  return 20;
}

static void *disco_thread(void *arg) {
  (void)arg;
  char caminho[600], nota[NOTA_MAX + 8];
  pthread_mutex_lock(&g_trava_dk);
  snprintf(caminho, sizeof caminho, "%s", g_dk.caminho);
  snprintf(nota, sizeof nota, "%s", g_dk.nota);
  pthread_mutex_unlock(&g_trava_dk);
  buf_t txt = {0};
  struct stat st;
  int direto = 0, fd = -1;
#ifdef O_DIRECT
  fd = open(caminho, O_RDONLY | O_DIRECT);
  direto = fd >= 0;
#endif
  if(fd < 0) fd = open(caminho, O_RDONLY);
  void *buf = NULL;
  const size_t GRANDE = 8u * 1024 * 1024, PEQ = 64u * 1024;
  if(fd < 0 || fstat(fd, &st) || posix_memalign(&buf, 4096, GRANDE)) {
    if(fd >= 0) close(fd);
    pthread_mutex_lock(&g_trava_dk);
    snprintf(g_dk.estado, sizeof g_dk.estado, "erro");
    snprintf(g_dk.texto, sizeof g_dk.texto, "nao deu para abrir o arquivo");
    g_dk.rodando = 0;
    pthread_mutex_unlock(&g_trava_dk);
    return NULL;
  }
  unsigned long long tam = (unsigned long long)st.st_size;
  double metade = disco_segundos() / 2.0;
  char tid[16] = "";
  int jogo = app_de_jogo_aberto(tid, sizeof tid) == 1;
  /* sequencial */
  long long ini = agora_ms();
  unsigned long long off = 0, bytes_s = 0;
  int n_s = 0;
  double pior_s = 0;
  while(seg_desde(ini) < metade && off < tam) {
    long long t = agora_ms();
    ssize_t k = pread(fd, buf, GRANDE, (off_t)off);
    if(k < 0 && direto && errno == EINVAL) {   /* O_DIRECT recusado na leitura: segue sem */
      close(fd);
      fd = open(caminho, O_RDONLY);
      direto = 0;
      if(fd < 0) break;
      continue;
    }
    if(k <= 0) break;
    double ms = (double)(agora_ms() - t);
    if(ms > pior_s) pior_s = ms;
    off += (unsigned long long)k;
    bytes_s += (unsigned long long)k;
    n_s++;
    pthread_mutex_lock(&g_trava_dk);
    g_dk.progresso = (int)(seg_desde(ini) * 50 / metade);
    pthread_mutex_unlock(&g_trava_dk);
  }
  double dur_s = seg_desde(ini);
  /* aleatorio */
  ini = agora_ms();
  unsigned long long bytes_a = 0, blocos = tam / PEQ ? tam / PEQ : 1, x = 0x9E3779B97F4A7C15ULL ^ (unsigned long long)ini;
  int n_a = 0;
  double pior_a = 0;
  while(fd >= 0 && seg_desde(ini) < metade) {
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    long long t = agora_ms();
    ssize_t k = pread(fd, buf, PEQ, (off_t)((x % blocos) * PEQ));
    if(k < 0 && direto && errno == EINVAL) {
      close(fd);
      fd = open(caminho, O_RDONLY);
      direto = 0;
      continue;
    }
    if(k <= 0) break;
    double ms = (double)(agora_ms() - t);
    if(ms > pior_a) pior_a = ms;
    bytes_a += (unsigned long long)k;
    n_a++;
    pthread_mutex_lock(&g_trava_dk);
    g_dk.progresso = 50 + (int)(seg_desde(ini) * 50 / metade);
    pthread_mutex_unlock(&g_trava_dk);
  }
  double dur_a = seg_desde(ini);
  if(fd >= 0) close(fd);
  free(buf);
  buf_fmt(&txt, "arquivo: %s (%llu bytes)\n", caminho, tam);
  buf_fmt(&txt, "modo: %s\n", direto ? "O_DIRECT (sem o cache do sistema)" : "sem O_DIRECT (o sistema recusou): pode ter cache");
  if(jogo) buf_fmt(&txt, "aviso: jogo aberto (%s) disputando o disco\n", tid);
  if(n_s) buf_fmt(&txt, "sequencial (8 MiB): %.1f MB/s, %d leituras em %.1f s, %.1f ms por leitura (pior %.0f ms)%s\n",
                  dur_s > 0 ? bytes_s / 1e6 / dur_s : 0, n_s, dur_s, dur_s * 1000 / n_s, pior_s, off >= tam ? " (chegou ao fim do arquivo)" : "");
  else buf_str(&txt, "sequencial (8 MiB): nenhuma leitura\n");
  if(n_a) buf_fmt(&txt, "aleatorio (64 KiB): %.1f MB/s, %d leituras em %.1f s, %.2f ms por leitura (pior %.0f ms)\n",
                  dur_a > 0 ? bytes_a / 1e6 / dur_a : 0, n_a, dur_a, dur_a * 1000 / n_a, pior_a);
  else buf_str(&txt, "aleatorio (64 KiB): nenhuma leitura\n");
  char nota2[NOTA_MAX + 24], nome[48] = "";
  snprintf(nota2, sizeof nota2, "disco%s%s", nota[0] ? ": " : "", nota);
  static const char *const CAMINHOS[] = {"teste de disco (sem o ampr)"};
  int g = gravar_medida(nota2, NULL, NULL, NULL, CAMINHOS, &txt, 1, nome, sizeof nome);
  pthread_mutex_lock(&g_trava_dk);
  snprintf(g_dk.estado, sizeof g_dk.estado, "%s", g ? "erro" : "pronto");
  snprintf(g_dk.texto, sizeof g_dk.texto, "%s", txt.d ? txt.d : "");
  snprintf(g_dk.medida, sizeof g_dk.medida, "%s", nome);
  g_dk.progresso = 100;
  g_dk.rodando = 0;
  pthread_mutex_unlock(&g_trava_dk);
  diario("ampr-ajuste: teste de disco em %s: medida %s", caminho, g ? "(nao gravada)" : nome);
  buf_free(&txt);
  return NULL;
}

static void ampr_disco(pedido_t *p) {
  char caminho[600] = "", nota[NOTA_MAX + 8];
  param(p->corpo, "caminho", 0, caminho, sizeof caminho);
  pedir_nota(p, nota, sizeof nota);
  struct stat st;
  if(!caminho_valido(caminho) || !payloads_caminho_de_disco(caminho) || lstat(caminho, &st) || !S_ISREG(st.st_mode)) {
    responder_erro(p, 400, "ampr_disco_caminho", "escolha um arquivo de um disco do PS5", NULL);
    return;
  }
  if(st.st_size < 1024 * 1024) {
    responder_erro(p, 400, "ampr_disco_pequeno", "arquivo pequeno demais: escolha um de pelo menos 1 MB (o maior que tiver)", NULL);
    return;
  }
  pthread_mutex_lock(&g_trava_dk);
  if(g_dk.rodando) {
    pthread_mutex_unlock(&g_trava_dk);
    responder_erro(p, 409, "ampr_disco_ocupado", "um teste de disco ja esta rodando", NULL);
    return;
  }
  g_dk.rodando = 1;
  g_dk.progresso = 0;
  snprintf(g_dk.estado, sizeof g_dk.estado, "rodando");
  snprintf(g_dk.caminho, sizeof g_dk.caminho, "%s", caminho);
  snprintf(g_dk.nota, sizeof g_dk.nota, "%s", nota);
  g_dk.texto[0] = g_dk.medida[0] = 0;
  pthread_mutex_unlock(&g_trava_dk);
  if(criar_thread(disco_thread, NULL, NULL)) {
    pthread_mutex_lock(&g_trava_dk);
    g_dk.rodando = 0;
    snprintf(g_dk.estado, sizeof g_dk.estado, "erro");
    pthread_mutex_unlock(&g_trava_dk);
    responder_erro(p, 500, "ampr_disco_thread", "nao deu para comecar", NULL);
    return;
  }
  diario("ampr-ajuste: teste de disco pedido em %s", caminho);
  responder_estado(p, NULL, NULL);
}

/* ------------------------------------------------------------------ estado das novidades e rotas */

static void extras_json(buf_t *b) {
  pthread_mutex_lock(&g_trava_tr);
  trecho_carregar();
  long long seg = g_tr.aberto ? (long long)time(NULL) - g_tr.t0 : 0;
  buf_fmt(b, ",\"trecho\":{\"aberto\":%s,\"segundos\":%lld,\"fps\":%s", g_tr.aberto ? "true" : "false", seg, g_tr.fps ? "true" : "false");
  pthread_mutex_unlock(&g_trava_tr);
  pthread_mutex_lock(&g_trava_am);
  buf_fmt(b, ",\"amostras\":%d", g_am.rodando ? g_am.amostras : 0);
  if(g_am.rodando && g_am.fps_f.n) buf_fmt(b, ",\"fps_media\":%.1f", g_am.fps_f.soma / g_am.fps_f.n);
  else buf_str(b, ",\"fps_media\":null");
  if(g_am.rodando && g_am.cpu_c.n) buf_fmt(b, ",\"temp_max\":%.0f}", g_am.cpu_c.max);
  else buf_str(b, ",\"temp_max\":null}");
  pthread_mutex_unlock(&g_trava_am);
  pthread_mutex_lock(&g_trava_marcas);
  buf_str(b, ",\"marcas\":[");
  for(int i = 0; i < g_nmarcas; i++) {
    buf_str(b, i ? ",{\"tipo\":" : "{\"tipo\":");
    buf_json(b, g_marcas[i].tipo);
    buf_str(b, ",\"nome\":");
    buf_json(b, marca_nome(g_marcas[i].tipo));
    buf_str(b, ",\"texto\":");
    buf_json(b, g_marcas[i].texto);
    buf_fmt(b, ",\"s\":%.1f,\"quando\":%lld}", (double)(g_marcas[i].ms - g_marcas[0].ms) / 1000.0, g_marcas[i].quando);
  }
  buf_str(b, "]");
  pthread_mutex_unlock(&g_trava_marcas);
  buf_fmt(b, ",\"rodada\":%d,\"sugestao\":", rodada());
  char c[600];
  buf_t s = {0};
  arquivo_sugestao(c, sizeof c);
  if(!ler_pequeno(c, &s, 64 * 1024) && s.d[0] == '{') buf_add(b, s.d, s.n);
  else buf_str(b, "null");
  buf_free(&s);
  conjuntos_json(b);
  pthread_mutex_lock(&g_trava_dk);
  buf_fmt(b, ",\"disco\":{\"estado\":\"%s\",\"progresso\":%d,\"caminho\":", g_dk.estado, g_dk.progresso);
  buf_json(b, g_dk.caminho);
  buf_str(b, ",\"texto\":");
  buf_json(b, g_dk.texto);
  buf_str(b, ",\"medida\":");
  buf_json(b, g_dk.medida);
  buf_str(b, "}");
  pthread_mutex_unlock(&g_trava_dk);
}

int ampr_ajuste_rota_mais(pedido_t *p) {
  static const struct {
    const char *caminho;
    void (*fn)(pedido_t *);
  } R[] = {{"/api/ampr/trecho/inicio", ampr_trecho_inicio},     {"/api/ampr/trecho/fim", ampr_trecho_fim},
           {"/api/ampr/trecho/cancelar", ampr_trecho_cancelar}, {"/api/ampr/marca", ampr_marca},
           {"/api/ampr/sugestao/buscar", ampr_sugestao_buscar}, {"/api/ampr/sugestao/aplicar", ampr_sugestao_aplicar},
           {"/api/ampr/conjunto/salvar", ampr_conjunto_salvar}, {"/api/ampr/conjunto/aplicar", ampr_conjunto_aplicar},
           {"/api/ampr/conjunto/apagar", ampr_conjunto_apagar}, {"/api/ampr/medida/enviar", ampr_medida_enviar},
           {"/api/ampr/disco", ampr_disco}};
  for(size_t i = 0; i < sizeof R / sizeof R[0]; i++)
    if(!strcmp(p->caminho, R[i].caminho)) {
      R[i].fn(p);
      return 1;
    }
  return 0;
}

/* ------------------------------------------------------------------ diagnostico */

int ampr_ajuste_medidas(char nomes[][96], char caminhos[][600], int max) {
  static medida_t m[128];
  static pthread_mutex_t trava = PTHREAD_MUTEX_INITIALIZER;
  char pasta[600];
  pasta_medidas(pasta, sizeof pasta);
  pthread_mutex_lock(&trava);
  int n = listar_medidas(m, 128);
  if(n > max) n = max;
  for(int i = 0; i < n; i++) {
    snprintf(nomes[i], 96, "ampr-medida-%s", m[i].nome);
    snprintf(caminhos[i], 600, "%s/%s", pasta, m[i].nome);
  }
  pthread_mutex_unlock(&trava);
  return n;
}
