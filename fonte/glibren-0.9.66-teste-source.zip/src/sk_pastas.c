/* Game Library Renamer (payload PS5) - 0.9.54: pastas vigiadas pelo ShadowKraken (ver sk_pastas.h). */
#include "sk_pastas.h"

#include <ctype.h>
#include <limits.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <unistd.h>

#include "apps.h"
#include "config.h"
#include "fps.h"
#include "json_min.h"
#include "plataforma.h"
#include "smp_config.h"

#define SK_MAX 64      /* o ShadowKraken aceita 256; aqui basta bem menos */
#define SK_TAM 400
#define SK_AVISOS 8

typedef char pasta_t[SK_TAM];

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static int g_ocupado;

/* ------------------------------------------------------------------ caminhos */

/* No PC os testes poem os discos do PS5 (/data, /mnt/usbN, /mnt/extN) dentro de uma pasta (GLR_TESTE_SK_RAIZ). */
static const char *raiz_fs(void) {
#ifndef __PROSPERO__
  const char *r = getenv("GLR_TESTE_SK_RAIZ");
  if(r && *r) return r;
#endif
  return "";
}

static void local(char *saida, size_t tam, const char *c) { snprintf(saida, tam, "%s%s", raiz_fs(), c); }

/* tira as barras do fim (menos a de "/") */
static void sem_barra(char *c) {
  size_t n = strlen(c);
  while(n > 1 && c[n - 1] == '/') c[--n] = 0;
}

/* tamanho da raiz do disco em c ("/data", "/mnt/usbN", "/mnt/extN"); 0 = fora dos discos do PS5 */
static size_t disco_de(const char *c) {
  if(!strncmp(c, "/data", 5) && (c[5] == '/' || !c[5])) return 5;
  if(strncmp(c, "/mnt/usb", 8) && strncmp(c, "/mnt/ext", 8)) return 0;
  size_t i = 8;
  while(isdigit((unsigned char)c[i])) i++;
  return i > 8 && (c[i] == '/' || !c[i]) ? i : 0;
}

/* niveis de filho abaixo de pai (0 = a mesma pasta); -1 = nao esta dentro */
static int niveis(const char *pai, const char *filho) {
  size_t n = strlen(pai);
  if(strncmp(pai, filho, n)) return -1;
  if(!filho[n]) return 0;
  if(filho[n] != '/' && strcmp(pai, "/")) return -1;
  int k = 0;
  for(const char *c = filho + n; *c; c++)
    if(*c == '/' && c[1]) k++;
  return k ? k : 1;
}

static int existe_pasta(const char *c) {
  char l[SK_TAM + 300];
  struct stat st;
  local(l, sizeof l, c);
  return !stat(l, &st) && S_ISDIR(st.st_mode);
}

/* mesma pasta sem links no caminho (realpath igual) */
static int sem_links(const char *c) {
  char l[SK_TAM + 300], r[PATH_MAX];
  local(l, sizeof l, c);
  if(!realpath(l, r)) return 0;
  return !strcmp(l, r);
}

/* ------------------------------------------------------------------ ShadowKraken */

/* Campos que voltam no update como vieram (tipo conferido: 'b' = true/false, 'i' = inteiro, 's' = texto). */
static const struct {
  const char *nome;
  char tipo;
  int exigido;
} CAMPOS[] = {
  {"debug", 'b', 1}, {"quiet_mode", 'b', 1}, {"update_emulators", 'b', 1}, {"allow_lan_access", 'b', 1},
  {"fan_target_temperature", 'i', 1}, {"auto_update_ampr", 'b', 0}, {"add_emulators", 'b', 0},
  {"fpkg_direct_mount", 'b', 0}, {"auto_remove_missing_games", 'b', 0}, {"auto_remove_missing_delay_seconds", 'i', 0},
  {"fakelib_default_mode", 's', 0},
};

typedef struct {
  buf_t resp;
  js_t obj;
  pasta_t pastas[SK_MAX];   /* as escolhidas (scan_paths); vazio = lista padrao */
  int qtd;
  int prof;
  char ip[64];              /* [api] bind_address do config.ini */
  int auto_remove;          /* auto_remove_missing_games (-1 = nao veio) */
} sk_t;

static int pegar_pasta(const js_t *item, void *ctx) {
  sk_t *s = ctx;
  js_t j = *item;
  if(s->qtd >= SK_MAX) return 0;
  if(js_string(&j, s->pastas[s->qtd], SK_TAM)) return 1;
  sem_barra(s->pastas[s->qtd]);
  if(s->pastas[s->qtd][0] == '/') s->qtd++;
  return 1;
}

static void sk_soltar(sk_t *s) { buf_free(&s->resp); }

/* 0 = leu; -1 = sem resposta; -2 = respondeu mas sem scan_paths (nao e o ShadowKraken ou versao antiga) */
static int sk_ler(sk_t *s) {
  memset(s, 0, sizeof *s);
  s->prof = 1;
  s->auto_remove = -1;
  FILE *f = fopen(apps_smp_config(), "r");
  if(f) {
    int porta = 0;
    smp_config_ler(f, &porta, s->ip, sizeof s->ip);
    rewind(f);
    s->prof = smp_config_profundidade(f);
    fclose(f);
  }
  int st = apps_smp_pedir("/api/v1/settings", "{}", &s->resp, 5);
  if(st < 0 || !s->resp.d) return -1;
  buf_add(&s->resp, "", 1);
  s->obj.p = s->resp.d;
  s->obj.fim = s->resp.d + s->resp.n - 1;
  js_esp(&s->obj);
  js_t v;
  if(st != 200 || !js_campo(&s->obj, "status", &v) || js_num(&v) != 0 || *v.p != '0') return -2;
  if(!js_campo(&s->obj, "scan_paths", &v) || js_cada(&v, pegar_pasta, s) < 0) return -2;
  if(js_campo(&s->obj, "auto_remove_missing_games", &v)) s->auto_remove = js_verdade(&v);
  return 0;
}

/* Lista padrao do ShadowKraken (sm_paths.h), so as que existem agora. */
static int padrao_existentes(pasta_t *saida, int max) {
  static const char *const BASES[] = {"/data/homebrew", "/data/etaHEN/games", NULL};
  int n = 0;
  for(int i = 0; BASES[i] && n < max; i++)
    if(existe_pasta(BASES[i])) snprintf(saida[n++], SK_TAM, "%s", BASES[i]);
  char c[64];
  for(int e = 0; e < 2; e++) {   /* /mnt/ext0..1/{homebrew,etaHEN/games} */
    snprintf(c, sizeof c, "/mnt/ext%d/homebrew", e);
    if(n < max && existe_pasta(c)) snprintf(saida[n++], SK_TAM, "%s", c);
    snprintf(c, sizeof c, "/mnt/ext%d/etaHEN/games", e);
    if(n < max && existe_pasta(c)) snprintf(saida[n++], SK_TAM, "%s", c);
  }
  for(int u = 0; u < 8; u++) {
    snprintf(c, sizeof c, "/mnt/usb%d/homebrew", u);
    if(n < max && existe_pasta(c)) snprintf(saida[n++], SK_TAM, "%s", c);
    snprintf(c, sizeof c, "/mnt/usb%d/etaHEN/games", u);
    if(n < max && existe_pasta(c)) snprintf(saida[n++], SK_TAM, "%s", c);
  }
  for(int u = 0; u < 8; u++) {
    snprintf(c, sizeof c, "/mnt/usb%d", u);
    if(n < max && existe_pasta(c)) snprintf(saida[n++], SK_TAM, "%s", c);
  }
  for(int e = 0; e < 2; e++) {
    snprintf(c, sizeof c, "/mnt/ext%d", e);
    if(n < max && existe_pasta(c)) snprintf(saida[n++], SK_TAM, "%s", c);
  }
  return n;
}

/* As pastas que valem agora: as escolhidas, ou a lista padrao que existe. */
static int vigiadas(const sk_t *s, pasta_t *saida, int *padrao) {
  *padrao = !s->qtd;
  if(*padrao) return padrao_existentes(saida, SK_MAX);
  memcpy(saida, s->pastas, (size_t)s->qtd * sizeof *saida);
  return s->qtd;
}

/* pasta (do glibren ou do ShadowKraken) e vista pela raiz r com a profundidade prof */
static int coberta(const char *r, const char *pasta, int prof) {
  int k = niveis(r, pasta);
  return k >= 0 && k <= prof - 1;
}

/* "shadowmount =" do glibren = pastas da lista cobertas pelas vigiadas. Grava so se mudou (e diz no diario). */
static void sincronizar(pasta_t *v, int nv, int prof) {
  static char lista[MAX_PASTAS][1024], antes[MAX_PASTAS][1024], novas[MAX_PASTAS][1024];
  char idioma[16], l[SK_TAM + 300], g[1024];
  int qtd = config_ler(lista, idioma), qa = config_monitoradas(antes, MAX_PASTAS), qn = 0;
  for(int i = 0; i < qtd; i++) {
    snprintf(g, sizeof g, "%s", lista[i]);
    sem_barra(g);
    for(int k = 0; k < nv; k++) {
      local(l, sizeof l, v[k]);
      if(coberta(l, g, prof)) {
        snprintf(novas[qn++], sizeof novas[0], "%s", lista[i]);
        break;
      }
    }
  }
  int igual = qa == qn;
  for(int i = 0; igual && i < qn; i++) igual = !strcmp(antes[i], novas[i]);
  if(igual) return;
  buf_t a = {0}, d = {0};
  for(int i = 0; i < qa; i++) buf_fmt(&a, "%s%s", i ? ", " : "", antes[i]);
  for(int i = 0; i < qn; i++) buf_fmt(&d, "%s%s", i ? ", " : "", novas[i]);
  buf_add(&a, "", 1);
  buf_add(&d, "", 1);
  if(!config_gravar_monitoradas(novas, qn))
    diario("sk-pastas: \"Ativo\" (shadowmount =) segue o ShadowKraken: antes [%s], depois [%s]", a.d, d.d);
  buf_free(&a);
  buf_free(&d);
}

/* ------------------------------------------------------------------ jogos instalados (0.9.56) */

/* "on"/"true"/"yes"/"1" (como o ShadowKraken le os ajustes de ligar) */
static int valor_ligado(const char *v) {
  return !strcasecmp(v, "on") || !strcasecmp(v, "true") || !strcasecmp(v, "yes") || !strcmp(v, "1");
}

/* chave da linha "chave = valor" (sem espacos); 0 = nao e linha de ajuste */
static int chave_da_linha(const char *l, char *chave, size_t tam, const char **valor) {
  while(*l == ' ' || *l == '\t') l++;
  size_t i = 0;
  while(*l && *l != '=' && *l != ' ' && *l != '\t' && *l != '\r' && *l != '\n' && i + 1 < tam) chave[i++] = *l++;
  chave[i] = 0;
  while(*l == ' ' || *l == '\t') l++;
  if(!i || *l != '=') return 0;
  l++;
  while(*l == ' ' || *l == '\t' || *l == '"') l++;
  *valor = l;
  return 1;
}

/* secao "[nome]" da linha em s; 0 = nao e cabecalho */
static int secao_da_linha(const char *l, char *s, size_t tam) {
  while(*l == ' ' || *l == '\t') l++;
  if(*l != '[') return 0;
  l++;
  size_t i = 0;
  while(*l && *l != ']' && i + 1 < tam) s[i++] = *l++;
  s[i] = 0;
  return *l == ']';
}

/* [fpkg] installed (v2) ou fpkg_installed (v1): o ShadowKraken (Dev.35+) roda os .pkg instalados pelo sistema */
int sk_instalados_ligado(void) {
  FILE *f = fopen(apps_smp_config(), "r");
  if(!f) return 0;
  char linha[1024], secao[64] = "", chave[64], v[16];
  const char *valor;
  int ligado = 0;
  while(fgets(linha, sizeof linha, f)) {
    if(secao_da_linha(linha, secao, sizeof secao)) continue;
    if(!chave_da_linha(linha, chave, sizeof chave, &valor)) continue;
    if((!strcasecmp(secao, "fpkg") && !strcasecmp(chave, "installed")) || (!secao[0] && !strcasecmp(chave, "fpkg_installed"))) {
      size_t n = 0;
      while(valor[n] && !strchr(" \t\r\n\";#", valor[n]) && n + 1 < sizeof v) n++;
      memcpy(v, valor, n);
      v[n] = 0;
      ligado = valor_ligado(v);
    }
  }
  fclose(f);
  return ligado;
}

/* Grava so a linha do ajuste e mantem o resto do arquivo como esta (temporario + rename, como o proprio ShadowKraken;
   ele percebe a troca do arquivo e recarrega sozinho). 0 = gravou. */
static int instalados_gravar(int ligar) {
  const char *cam = apps_smp_config();
  FILE *f = fopen(cam, "r");
  if(!f) return -1;
  buf_t novo = {0};
  char linha[1024], secao[64] = "", chave[64];
  const char *valor;
  int v2 = 0, feito = 0, na_fpkg = 0, ok = 1;
  const char *val = ligar ? "on" : "off";
  while(fgets(linha, sizeof linha, f)) {
    if(strlen(linha) == sizeof linha - 1 && linha[sizeof linha - 2] != '\n') {
      ok = 0;   /* linha longa demais: nao mexe */
      break;
    }
    if(secao_da_linha(linha, secao, sizeof secao)) {
      if(na_fpkg && !feito) {   /* fim da [fpkg] sem a chave: entra no fim dela */
        buf_fmt(&novo, "installed = %s\n", val);
        feito = 1;
      }
      v2 = 1;
      na_fpkg = !strcasecmp(secao, "fpkg");
      buf_str(&novo, linha);
      continue;
    }
    if(chave_da_linha(linha, chave, sizeof chave, &valor) &&
       ((na_fpkg && !strcasecmp(chave, "installed")) || (!secao[0] && !strcasecmp(chave, "fpkg_installed")))) {
      if(!feito) buf_fmt(&novo, "%s = %s\n", na_fpkg ? "installed" : "fpkg_installed", val);
      feito = 1;   /* repetida: fica so uma */
      continue;
    }
    buf_str(&novo, linha);
  }
  fclose(f);
  if(!ok) {
    buf_free(&novo);
    return -1;
  }
  if(!feito) {
    if(novo.n && novo.d[novo.n - 1] != '\n') buf_str(&novo, "\n");
    if(na_fpkg) buf_fmt(&novo, "installed = %s\n", val);
    else if(v2) buf_fmt(&novo, "\n[fpkg]\ninstalled = %s\n", val);
    else buf_fmt(&novo, "fpkg_installed = %s\n", val);
  }
  char tmp[600];
  snprintf(tmp, sizeof tmp, "%s.glibren", cam);
  FILE *o = fopen(tmp, "w");
  int r = -1;
  if(o) {
    r = (novo.n && fwrite(novo.d, 1, novo.n, o) != novo.n) ? -1 : 0;
    if(fflush(o) || fchmod(fileno(o), 0600) || fsync(fileno(o))) r = -1;
    if(fclose(o)) r = -1;
    if(!r && rename(tmp, cam)) r = -1;
    if(r) unlink(tmp);
  }
  buf_free(&novo);
  return r;
}

void sk_instalados_rota(pedido_t *p) {
  char v[8];
  if(!param(p->corpo, "ligar", 0, v, sizeof v) || (strcmp(v, "1") && strcmp(v, "0"))) {
    responder_erro(p, 400, "sk_valor", "ligar tem de ser 1 ou 0", NULL);
    return;
  }
  int ligar = v[0] == '1', antes = sk_instalados_ligado();
  pthread_mutex_lock(&g_trava);
  int ocupado = g_ocupado;
  g_ocupado = 1;
  pthread_mutex_unlock(&g_trava);
  if(ocupado) {
    responder_erro(p, 409, "sk_ocupado", "outra mudanca na configuracao do ShadowKraken esta andando: espere", NULL);
    return;
  }
  int r = antes == ligar ? 0 : instalados_gravar(ligar);
  pthread_mutex_lock(&g_trava);
  g_ocupado = 0;
  pthread_mutex_unlock(&g_trava);
  if(r || sk_instalados_ligado() != ligar) {
    diario("sk-instalados: nao gravou %s em %s", ligar ? "on" : "off", apps_smp_config());
    responder_erro(p, 500, "sk_nao_gravou", "nao deu para gravar a configuracao do ShadowKraken", apps_smp_config());
    return;
  }
  if(antes != ligar)
    diario("sk-instalados: [fpkg] installed = %s (%s)", ligar ? "on" : "off",
           ligar ? "o ShadowKraken passa a cuidar dos jogos instalados pelo sistema" : "os jogos instalados voltam a abrir so pelo sistema");
  buf_t b = {0};
  buf_fmt(&b, "{\"ok\":true,\"instalados\":%s,\"mudou\":%s}", ligar ? "true" : "false", antes != ligar ? "true" : "false");
  responder_json(p, 200, &b);
  buf_free(&b);
}

/* ------------------------------------------------------------------ JSON */

static void pasta_json(buf_t *b, const char *c, int padrao) {
  char l[SK_TAM + 300];
  struct statvfs vf;
  local(l, sizeof l, c);
  int ex = existe_pasta(c);
  buf_str(b, "{\"caminho\":");
  buf_json(b, c);
  buf_fmt(b, ",\"existe\":%s,\"padrao\":%s", ex ? "true" : "false", padrao ? "true" : "false");
  if(ex && !statvfs(l, &vf))
    buf_fmt(b, ",\"livre\":%llu,\"total\":%llu", (unsigned long long)vf.f_bavail * vf.f_frsize,
            (unsigned long long)vf.f_blocks * vf.f_frsize);
  buf_str(b, "}");
}

static void estado_json(buf_t *b, sk_t *s) {
  pasta_t *v = calloc(SK_MAX, sizeof *v);
  int padrao = 0, nv = v ? vigiadas(s, v, &padrao) : 0;
  buf_fmt(b, "{\"ok\":true,\"profundidade\":%d,\"padrao\":%s,\"auto_remove\":%s,\"ip_fixo\":%s,\"pastas\":[", s->prof,
          padrao ? "true" : "false", s->auto_remove < 0 ? "null" : s->auto_remove ? "true" : "false",
          s->ip[0] && strcmp(s->ip, "0.0.0.0") && strcmp(s->ip, "127.0.0.1") ? "true" : "false");
  for(int i = 0; i < nv; i++) {
    if(i) buf_str(b, ",");
    pasta_json(b, v[i], padrao);
  }
  pthread_mutex_lock(&g_trava);
  buf_fmt(b, "],\"instalados\":%s,\"ocupado\":%s}", sk_instalados_ligado() ? "true" : "false", g_ocupado ? "true" : "false");
  pthread_mutex_unlock(&g_trava);
  if(v) sincronizar(v, nv, s->prof);
  free(v);
}

static void sem_resposta(pedido_t *p, int r) {
  if(r == -1) responder_erro(p, 503, "sk_fora", "o ShadowKraken nao respondeu (API desligada ou payload fora do ar)", NULL);
  else responder_erro(p, 502, "sk_sem_settings", "a API respondeu sem a lista de pastas (precisa do ShadowKraken)", NULL);
}

void sk_pastas_rota_estado(pedido_t *p) {
  sk_t s;
  int r = sk_ler(&s);
  if(r) {
    sem_resposta(p, r);
    sk_soltar(&s);
    return;
  }
  buf_t b = {0};
  estado_json(&b, &s);
  responder_json(p, 200, &b);
  buf_free(&b);
  sk_soltar(&s);
}

/* ------------------------------------------------------------------ conferir */

typedef struct {
  const char *chave;
  char p[SK_TAM];
} aviso_t;

/* pasta "especial" (rel abaixo do disco: PS4, downloads/packages, backup) e a propria c ou o conteudo dela fica ao
   alcance da busca (dentro de c ate depth-1 niveis) */
static int toca(const char *c, const char *rel, int prof) {
  size_t d = disco_de(c);
  if(!d) return 0;
  char e[SK_TAM + 64];
  snprintf(e, sizeof e, "%.*s/%s", (int)d, c, rel);
  if(!strcasecmp(e, c)) return 1;
  int k = niveis(c, e);
  return k > 0 && k <= prof - 1 && existe_pasta(e);
}

/* Confere c (ja sem barra no fim). 0 = pode; senao chave/mensagem do erro. avisos: ate SK_AVISOS. */
static int conferir(const char *c, int adicionar, pasta_t *v, int nv, int padrao, int prof, aviso_t *av, int *na,
                    const char **chave, const char **msg) {
  *na = 0;
  int achou = -1;
  for(int i = 0; i < nv; i++)
    if(!strcmp(v[i], c)) achou = i;
  if(!adicionar) {
    if(achou < 0) {
      *chave = "sk_nao_esta";
      *msg = "essa pasta nao esta na lista do ShadowKraken";
      return -1;
    }
    if(padrao && nv == 1) {
      *chave = "sk_ultima_padrao";
      *msg = "e a unica pasta da lista padrao: o ShadowKraken voltaria para ela mesma";
      return -1;
    }
    av[(*na)++].chave = "remove_jogos";
    if(nv == 1) av[(*na)++].chave = "volta_padrao";
    return 0;
  }
  if(!caminho_valido(c) || strlen(c) >= SK_TAM - 1 || !disco_de(c) || !strcmp(c, "/data")) {
    *chave = "sk_pasta_fora";
    *msg = "a pasta tem de ficar em /data, num disco extra (/mnt/extN) ou num USB (/mnt/usbN)";
    return -1;
  }
  if(!strncmp(c, "/data/shadowmount", 17) || !strncmp(c, "/mnt/shadowmnt", 14)) {
    *chave = "sk_pasta_fora";
    *msg = "essa pasta e do proprio ShadowKraken";
    return -1;
  }
  if(!existe_pasta(c)) {
    *chave = "sk_nao_existe";
    *msg = "a pasta nao existe";
    return -1;
  }
  if(!sem_links(c)) {
    *chave = "sk_link";
    *msg = "o caminho tem um link: escolha a pasta de verdade";
    return -1;
  }
  if(achou >= 0) {
    *chave = "sk_ja_esta";
    *msg = "essa pasta ja esta na lista";
    return -1;
  }
  for(int i = 0; i < nv && *na < SK_AVISOS - 4; i++) {
    int k = niveis(v[i], c), k2 = niveis(c, v[i]);
    aviso_t *a = &av[*na];
    if(k > 0) a->chave = k <= prof - 1 ? "dentro_coberta" : "dentro_funda";
    else if(k2 > 0) a->chave = "contem";
    else continue;
    snprintf(a->p, sizeof a->p, "%s", v[i]);
    (*na)++;
  }
  if(toca(c, "PS4", prof) || toca(c, "downloads/packages", prof)) av[(*na)++].chave = "ps4";
  if(toca(c, "backup", prof)) av[(*na)++].chave = "backup";
  if(padrao && nv) av[(*na)++].chave = "copia_padrao";
  return 0;
}

static void avisos_json(buf_t *b, const aviso_t *av, int na) {
  buf_str(b, "\"avisos\":[");
  for(int i = 0; i < na; i++) {
    buf_fmt(b, "%s{\"chave\":\"%s\",\"p\":", i ? "," : "", av[i].chave);
    buf_json(b, av[i].p);
    buf_str(b, "}");
  }
  buf_str(b, "]");
}

/* caminho do pedido: aceita o do PS5 e, no PC, o da pasta de teste */
static int caminho_pedido(const char *qs, char *c, size_t tam) {
  char bruto[1024];
  if(!qs || !param(qs, "caminho", 0, bruto, sizeof bruto)) return -1;
  sem_barra(bruto);
  size_t r = strlen(raiz_fs());
  if(r && !strncmp(bruto, raiz_fs(), r) && bruto[r] == '/') memmove(bruto, bruto + r, strlen(bruto + r) + 1);
  if(strlen(bruto) >= tam) return -1;
  snprintf(c, tam, "%s", bruto);
  return 0;
}

static void prof_json(buf_t *b, int prof) { buf_fmt(b, ",\"profundidade\":%d,", prof); }

void sk_pastas_rota_conferir(pedido_t *p) {
  char c[SK_TAM];
  int adicionar = 1;
  char modo[16];
  if(param(p->query, "modo", 0, modo, sizeof modo) && !strcmp(modo, "remover")) adicionar = 0;
  if(caminho_pedido(p->query, c, sizeof c)) {
    responder_erro(p, 400, "sk_caminho", "caminho invalido", NULL);
    return;
  }
  sk_t s;
  int r = sk_ler(&s);
  if(r) {
    sem_resposta(p, r);
    sk_soltar(&s);
    return;
  }
  pasta_t *v = calloc(SK_MAX, sizeof *v);
  aviso_t av[SK_AVISOS];
  memset(av, 0, sizeof av);
  int padrao = 0, nv = v ? vigiadas(&s, v, &padrao) : 0, na = 0;
  const char *chave = "", *msg = "";
  if(!v || conferir(c, adicionar, v, nv, padrao, s.prof, av, &na, &chave, &msg)) {
    responder_erro(p, 400, v ? chave : "sk_memoria", v ? msg : "sem memoria", c);
  } else {
    buf_t b = {0};
    buf_str(&b, "{\"ok\":true,\"caminho\":");
    buf_json(&b, c);
    prof_json(&b, s.prof);
    avisos_json(&b, av, na);
    buf_str(&b, "}");
    responder_json(p, 200, &b);
    buf_free(&b);
  }
  free(v);
  sk_soltar(&s);
}

/* ------------------------------------------------------------------ gravar */

static int valor_tipo(const char *v, size_t n, char tipo) {
  if(tipo == 'b') return (n == 4 && !strncmp(v, "true", 4)) || (n == 5 && !strncmp(v, "false", 5));
  if(tipo == 'i') {
    if(!n || n > 12) return 0;
    for(size_t i = 0; i < n; i++)
      if(!isdigit((unsigned char)v[i]) && !(i == 0 && v[i] == '-')) return 0;
    return 1;
  }
  return n >= 2 && v[0] == '"' && v[n - 1] == '"';
}

/* corpo do update: os campos lidos, com o texto exato que veio, e a lista nova. 0 = ok; senao o campo que faltou. */
static int montar_update(const sk_t *s, pasta_t *nova, int qn, buf_t *b, const char **falta) {
  buf_str(b, "{");
  for(size_t i = 0; i < sizeof CAMPOS / sizeof CAMPOS[0]; i++) {
    js_t v, w;
    if(!js_campo(&s->obj, CAMPOS[i].nome, &v)) {
      if(CAMPOS[i].exigido) {
        *falta = CAMPOS[i].nome;
        return -1;
      }
      continue;
    }
    w = v;
    if(js_pular(&w, 1) || !valor_tipo(v.p, (size_t)(w.p - v.p), CAMPOS[i].tipo)) {
      if(CAMPOS[i].exigido) {
        *falta = CAMPOS[i].nome;
        return -1;
      }
      continue;   /* opcional estranho: fica de fora e o ShadowKraken mantem o que tem */
    }
    buf_fmt(b, "\"%s\":", CAMPOS[i].nome);
    buf_add(b, v.p, (size_t)(w.p - v.p));
    buf_str(b, ",");
  }
  buf_str(b, "\"scan_paths\":[");
  for(int i = 0; i < qn; i++) {
    if(i) buf_str(b, ",");
    buf_json(b, nova[i]);
  }
  buf_str(b, "]}");
  return 0;
}

static void lista_texto(buf_t *b, pasta_t *v, int n, int padrao) {
  if(padrao) buf_str(b, "(padrao) ");
  buf_str(b, "[");
  for(int i = 0; i < n; i++) buf_fmt(b, "%s%s", i ? ", " : "", v[i]);
  buf_str(b, "]");
  buf_add(b, "", 1);
}

/* a pasta nova tambem entra na lista do glibren (para os jogos dela aparecerem e o "Ativo" valer) */
static void na_lista_glibren(const char *c) {
  static char lista[MAX_PASTAS][1024];
  char idioma[16], l[SK_TAM + 300], g[1024];
  local(l, sizeof l, c);
  int qtd = config_ler(lista, idioma);
  for(int i = 0; i < qtd; i++) {
    snprintf(g, sizeof g, "%s", lista[i]);
    sem_barra(g);
    if(!strcmp(g, l)) return;
  }
  if(qtd >= MAX_PASTAS) {
    diario("sk-pastas: %s nao entrou na lista do glibren (cheia: %d pastas)", l, qtd);
    return;
  }
  snprintf(lista[qtd++], sizeof lista[0], "%s/", l);
  if(!config_gravar(lista, qtd, NULL)) diario("sk-pastas: %s entrou tambem na lista do glibren", l);
}

void sk_pastas_rota_mudar(pedido_t *p, int adicionar) {
  if(fps_agente_ps5(p->agente) || p->local) {
    responder_erro(p, 403, "sk_so_celular", "as pastas do ShadowKraken so mudam pelo celular ou PC pareado", NULL);
    return;
  }
  char c[SK_TAM];
  if(caminho_pedido(p->corpo, c, sizeof c)) {
    responder_erro(p, 400, "sk_caminho", "caminho invalido", NULL);
    return;
  }
  pthread_mutex_lock(&g_trava);
  int ocupado = g_ocupado;
  g_ocupado = 1;
  pthread_mutex_unlock(&g_trava);
  if(ocupado) {
    responder_erro(p, 409, "sk_ocupado", "outra mudanca nas pastas do ShadowKraken esta andando: espere", NULL);
    return;
  }
  sk_t s;
  pasta_t *v = calloc(SK_MAX, sizeof *v), *nova = calloc(SK_MAX + 1, sizeof *nova);
  aviso_t av[SK_AVISOS];
  memset(av, 0, sizeof av);
  buf_t corpo = {0}, resp = {0}, antes = {0}, depois = {0}, b = {0};
  int r = sk_ler(&s), padrao = 0, nv = 0, na = 0, qn = 0;
  const char *chave = "", *msg = "", *falta = "";
  if(r) {
    sem_resposta(p, r);
    goto fim;
  }
  if(!v || !nova) {
    responder_erro(p, 500, "sk_memoria", "sem memoria", NULL);
    goto fim;
  }
  nv = vigiadas(&s, v, &padrao);
  if(conferir(c, adicionar, v, nv, padrao, s.prof, av, &na, &chave, &msg)) {
    responder_erro(p, 400, chave, msg, c);
    goto fim;
  }
  if(s.ip[0] && strcmp(s.ip, "0.0.0.0") && strcmp(s.ip, "127.0.0.1")) {
    /* o update regrava bind_address (0.0.0.0 ou 127.0.0.1): o IP escolhido pelo dono se perderia */
    responder_erro(p, 409, "sk_ip_fixo", "o ShadowKraken esta ligado num IP so (bind_address); gravar trocaria isso: mude pela pagina dele", s.ip);
    goto fim;
  }
  for(int i = 0; i < nv; i++)
    if(adicionar || strcmp(v[i], c)) snprintf(nova[qn++], SK_TAM, "%s", v[i]);
  if(adicionar) snprintf(nova[qn++], SK_TAM, "%s", c);
  if(montar_update(&s, nova, qn, &corpo, &falta)) {
    responder_erro(p, 502, "sk_sem_campo", "a resposta do ShadowKraken nao trouxe um ajuste exigido: nada foi gravado", falta);
    goto fim;
  }
  buf_add(&corpo, "", 1);
  lista_texto(&antes, v, nv, padrao);
  lista_texto(&depois, nova, qn, 0);
  int st = apps_smp_pedir("/api/v1/settings/update", corpo.d, &resp, 10);
  js_t o = {NULL, NULL}, sv;
  if(resp.d) {
    buf_add(&resp, "", 1);
    o.p = resp.d;
    o.fim = resp.d + resp.n - 1;
  }
  if(st != 200 || !o.p || !js_campo(&o, "status", &sv) || *sv.p != '0') {
    char erro[200] = "";
    if(o.p && js_campo(&o, "error", &sv)) js_string(&sv, erro, sizeof erro);
    diario("sk-pastas: %s %s recusado pelo ShadowKraken (HTTP %d%s%s); lista continua %s", adicionar ? "adicionar" : "remover",
           c, st, erro[0] ? ": " : "", erro, antes.d);
    responder_erro(p, 502, "sk_recusou", erro[0] ? erro : "o ShadowKraken nao gravou", c);
    goto fim;
  }
  diario("sk-pastas: %s %s; antes %s; depois %s (o ShadowKraken recarrega e busca os jogos de novo)",
         adicionar ? "adicionou" : "removeu", c, antes.d, depois.d);
  if(adicionar) na_lista_glibren(c);
  /* o ShadowKraken grava o config.ini e recarrega sozinho; confere a lista nova */
  sk_soltar(&s);
  int relido = 0;
  for(int t = 0; t < 6 && !relido; t++) {
    usleep(500 * 1000);
    sk_soltar(&s);
    if(sk_ler(&s)) continue;
    relido = s.qtd == qn;
    for(int i = 0; relido && i < qn; i++) relido = !strcmp(s.pastas[i], nova[i]);
  }
  buf_fmt(&b, "{\"ok\":true,\"relido\":%s,\"caminho\":", relido ? "true" : "false");
  buf_json(&b, c);
  buf_str(&b, ",");
  avisos_json(&b, av, na);
  buf_str(&b, ",\"estado\":");
  if(s.resp.d && s.obj.p) estado_json(&b, &s);
  else buf_str(&b, "null");
  buf_str(&b, "}");
  responder_json(p, 200, &b);
fim:
  free(v);
  free(nova);
  buf_free(&corpo);
  buf_free(&resp);
  buf_free(&antes);
  buf_free(&depois);
  buf_free(&b);
  sk_soltar(&s);
  pthread_mutex_lock(&g_trava);
  g_ocupado = 0;
  pthread_mutex_unlock(&g_trava);
}

/* ------------------------------------------------------------------ 0.9.64: para a bateria automatica */

int sk_pastas_listar(char pastas[][SK_PASTA_TAM], int max, int *padrao, int *prof) {
  static sk_t s;   /* grande para a pilha das threads */
  static pasta_t v[SK_MAX];
  static pthread_mutex_t trava = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_lock(&trava);
  int r = sk_ler(&s);
  if(r) {
    sk_soltar(&s);
    pthread_mutex_unlock(&trava);
    return -1;
  }
  int pd = 0, n = vigiadas(&s, v, &pd);
  if(padrao) *padrao = pd;
  if(prof) *prof = s.prof;
  if(n > max) n = max;
  for(int i = 0; i < n; i++) snprintf(pastas[i], SK_PASTA_TAM, "%s", v[i]);
  sk_soltar(&s);
  pthread_mutex_unlock(&trava);
  return n;
}
