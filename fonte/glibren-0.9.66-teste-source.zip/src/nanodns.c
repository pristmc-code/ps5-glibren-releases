/* Game Library Renamer (payload PS5) - editor do nanodns.ini do nanoDNS (0.9.66). Ver nanodns.h.

Credito: nanoDNS e de drakmor (drakmor/nanoDNS, GPL-3.0). Daqui so o formato do arquivo, os limites e a regra das
mascaras, lidos no main.c da v0.4; o arquivo padrao abaixo e o que o proprio nanoDNS cria quando nao acha um.

A analise repete o que o nanoDNS faz ao ler o arquivo e recusa (erros) o que ele ignoraria em silencio ou leria
diferente do que parece: servidor que nao e IPv4, servidor no proprio PS5 (127.x: o nanoDNS perguntaria a si mesmo),
IPv4 de regra invalido, mais de 8 servidores / 128 regras / 128 excecoes, linha com 512+ caracteres (ele le em
pedacos de 511 e a sobra vira outra linha), valores de debug/quiet/timeout_ms/bind/bind6 que ele troca pelo padrao.
Riscos: enderecos da Sony conhecidos (atualizacao do sistema, patches, downloads, telemetria) que deixariam de ser
bloqueados com o texto novo; o glibren so grava com confirmo=1. Gravacao atomica como o prefbar.c, com .bak. */
#include "nanodns.h"

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <unistd.h>

#include "config.h"
#include "plataforma.h"

#define MAX_ARQUIVO (32 * 1024)
#define MAX_LINHA 511        /* fgets(line, 512): 511 caracteres + o \0 */
#define MAX_SERVIDORES 8
#define MAX_REGRAS 128
#define MAX_EXCECOES 128
#define MAX_MASCARA 255      /* o nanoDNS guarda a mascara num campo de 256 */

/* O arquivo que o nanoDNS 0.4 cria quando nao acha um (k_default_config, sem os comentarios de ajuda). */
static const char PADRAO[] =
  "[general]\n"
  "log=/data/nanodns/nanodns.log\n"
  "debug=0\n"
  "quiet=0\n"
  "bind=127.0.0.1\n"
  "bind6=::1\n"
  "\n"
  "[upstream]\n"
  "server=1.1.1.1\n"
  "server=8.8.8.8\n"
  "server=77.88.8.8\n"
  "timeout_ms=1500\n"
  "\n"
  "[overrides]\n"
  "*.playstation.com=0.0.0.0\n"
  "*.playstation.com.*=0.0.0.0\n"
  "playstation.com=0.0.0.0\n"
  "*.playstation.net=0.0.0.0\n"
  "*.playstation.net.*=0.0.0.0\n"
  "*.psndl.net=0.0.0.0\n"
  "playstation.net=0.0.0.0\n"
  "psndl.net=0.0.0.0\n"
  "\n"
  "[exceptions]\n"
  "feature.api.playstation.com\n"
  "*.stun.playstation.net\n"
  "stun.*.playstation.net\n"
  "ena.net.playstation.net\n"
  "post.net.playstation.net\n"
  "gst.prod.dl.playstation.net\n";

/* Enderecos da Sony que nao podem passar sem o usuario confirmar. Todos bloqueados pelo arquivo padrao acima. */
static const char *const SONY[] = {
  "fus01.ps5.update.playstation.net",       /* atualizacao do sistema */
  "sgst.prod.dl.playstation.net",           /* versoes dos jogos (version.xml) */
  "gs2.ww.prod.dl.playstation.net",         /* download de patches */
  "telemetry-console.api.playstation.com",  /* telemetria */
  "psndl.net",
  NULL,
};
#define IMAGE_API "image.api.playstation.com"

void nanodns_pasta(char *saida, size_t tam) {
#ifdef __PROSPERO__
  snprintf(saida, tam, "/data/nanodns");
#else
  snprintf(saida, tam, "%s/nanodns", g_pasta_dados);
#endif
}

static void arquivo_ini(char *saida, size_t tam, const char *sufixo) {
  char p[512];
  nanodns_pasta(p, sizeof p);
  snprintf(saida, tam, "%s/nanodns.ini%s", p, sufixo);
}

/* ------------------------------------------------------------------ leitura como o nanoDNS */

static char *aparar(char *s) {
  while(*s == ' ' || *s == '\t' || *s == '\r' || *s == '\n') s++;
  size_t n = strlen(s);
  while(n && (s[n - 1] == ' ' || s[n - 1] == '\t' || s[n - 1] == '\r' || s[n - 1] == '\n')) s[--n] = 0;
  return s;
}

static void tirar_comentario(char *s) {
  char *c = strpbrk(s, "#;");
  if(c) {
    *c = 0;
    aparar(s);
  }
}

/* minusculas e sem ponto no fim (normalize_domain) */
static void normalizar(char *s) {
  size_t n = 0;
  for(char *c = s; *c; c++, n++) *c = (char)((*c >= 'A' && *c <= 'Z') ? *c + 32 : *c);
  while(n && s[n - 1] == '.') s[--n] = 0;
}

/* domain_mask_match do nanoDNS: *, ?, [abc], [a-z], [!x] / [^x], \x */
static int casa(const char *m, const char *d) {
  while(*m) {
    if(*m == '*') {
      while(*m == '*') m++;
      if(!*m) return 1;
      for(; *d; d++)
        if(casa(m, d)) return 1;
      return 0;
    }
    if(!*d) return 0;
    if(*m == '?') {
      m++;
      d++;
      continue;
    }
    if(*m == '[') {
      int nega = 0, achou = 0;
      const char *p = m + 1;
      if(*p == '!' || *p == '^') {
        nega = 1;
        p++;
      }
      if(*p == ']') {
        achou = *d == ']';
        p++;
      }
      while(*p && *p != ']') {
        unsigned char ini, fim;
        if(*p == '\\' && p[1]) {
          ini = (unsigned char)p[1];
          p += 2;
        } else ini = (unsigned char)*p++;
        fim = ini;
        if(*p == '-' && p[1] && p[1] != ']') {
          p++;
          if(*p == '\\' && p[1]) {
            fim = (unsigned char)p[1];
            p += 2;
          } else fim = (unsigned char)*p++;
        }
        if((unsigned char)*d >= ini && (unsigned char)*d <= fim) achou = 1;
      }
      if(*p != ']') {   /* sem o ] de fechar: o [ vale como letra */
        if(*m != *d) return 0;
        m++;
        d++;
        continue;
      }
      if(nega ? achou : !achou) return 0;
      m = p + 1;
      d++;
      continue;
    }
    if(*m == '\\' && m[1]) m++;
    if(*m != *d) return 0;
    m++;
    d++;
  }
  return !*d;
}

typedef struct {
  char regras[MAX_REGRAS][MAX_MASCARA + 1];
  char excecoes[MAX_EXCECOES][MAX_MASCARA + 1];
  int n_regras, n_excecoes;
} regras_t;

/* 1 = o nanoDNS responde sozinho (regra sem excecao): o pedido nao chega a nenhum servidor de fora */
static int bloqueado(const regras_t *r, const char *host) {
  for(int i = 0; i < r->n_excecoes; i++)
    if(casa(r->excecoes[i], host)) return 0;
  for(int i = 0; i < r->n_regras; i++)
    if(casa(r->regras[i], host)) return 1;
  return 0;
}

static int inteiro(const char *v) {
  if(!*v) return 0;
  const char *c = v;
  if(*c == '-' || *c == '+') c++;
  if(!*c) return 0;
  for(; *c; c++)
    if(*c < '0' || *c > '9') return 0;
  return strlen(v) <= 9;
}

static void item(buf_t *b, int *n, int linha, const char *chave, const char *valor) {
  buf_fmt(b, "%s{\"linha\":%d,\"chave\":\"%s\",\"valor\":", (*n)++ ? "," : "", linha, chave);
  buf_json(b, valor ? valor : "");
  buf_str(b, "}");
}

int nanodns_analisar(const char *texto, buf_t *b, int *riscos) {
  enum { NENHUMA, GERAL, SERVIDORES, REGRAS, EXCECOES } secao = NENHUMA;
  static regras_t r;   /* ~64 KB: fora da pilha (threads do servidor com pilha pequena); g_trava_analise protege */
  static pthread_mutex_t g_trava_analise = PTHREAD_MUTEX_INITIALIZER;
  char servidores[MAX_SERVIDORES][16];
  int n_serv = 0, trocou_servidores = 0, n_erros = 0, n_avisos = 0, linha = 0;
  buf_t erros = {0}, avisos = {0};
  pthread_mutex_lock(&g_trava_analise);
  r.n_regras = r.n_excecoes = 0;
  for(const char *p = texto; p && *p;) {
    const char *fim = strchr(p, '\n');
    size_t n = fim ? (size_t)(fim - p) : strlen(p);
    linha++;
    char bruto[MAX_LINHA + 2];
    if(n > MAX_LINHA) {
      item(&erros, &n_erros, linha, "linha_longa", NULL);
      p = fim ? fim + 1 : NULL;
      continue;
    }
    memcpy(bruto, p, n);
    bruto[n] = 0;
    p = fim ? fim + 1 : NULL;
    for(char *c = bruto; *c; c++)
      if((unsigned char)*c < ' ' && *c != '\t' && *c != '\r') {
        item(&erros, &n_erros, linha, "caractere_controle", NULL);
        bruto[0] = 0;
        break;
      }
    char *s = aparar(bruto);
    if(!*s || *s == '#' || *s == ';') continue;
    if(*s == '[') {
      char *f = strchr(s, ']');
      if(!f) {
        item(&avisos, &n_avisos, linha, "secao_sem_fechar", s);
        continue;
      }
      *f = 0;
      s = aparar(s + 1);
      if(!strcasecmp(s, "general") || !strcasecmp(s, "settings")) secao = GERAL;
      else if(!strcasecmp(s, "upstream") || !strcasecmp(s, "upstreams")) secao = SERVIDORES;
      else if(!strcasecmp(s, "override") || !strcasecmp(s, "overrides")) secao = REGRAS;
      else if(!strcasecmp(s, "exception") || !strcasecmp(s, "exceptions")) secao = EXCECOES;
      else {
        secao = NENHUMA;
        item(&avisos, &n_avisos, linha, "secao_desconhecida", s);
      }
      continue;
    }
    tirar_comentario(s);
    if(!*s) continue;
    if(secao == EXCECOES) {
      char *igual = strchr(s, '=');
      if(igual) *igual = 0;
      char *m = aparar(s);
      if(!*m) continue;
      if(strlen(m) > MAX_MASCARA) item(&erros, &n_erros, linha, "mascara_longa", NULL);
      else if(r.n_excecoes >= MAX_EXCECOES) item(&erros, &n_erros, linha, "excecoes_demais", m);
      else {
        snprintf(r.excecoes[r.n_excecoes], sizeof r.excecoes[0], "%s", m);
        normalizar(r.excecoes[r.n_excecoes++]);
      }
      continue;
    }
    char *igual = strchr(s, '=');
    if(!igual) {
      item(&avisos, &n_avisos, linha, "linha_ignorada", s);
      continue;
    }
    *igual = 0;
    char *k = aparar(s), *v = aparar(igual + 1);
    if(!*k || !*v) {
      item(&avisos, &n_avisos, linha, "linha_ignorada", k);
      continue;
    }
    struct in_addr a4;
    struct in6_addr a6;
    int geral = secao == GERAL || (secao == NENHUMA && (!strcasecmp(k, "log") || !strcasecmp(k, "debug") ||
                                   !strcasecmp(k, "quiet") || !strcasecmp(k, "bind") || !strcasecmp(k, "bind6")));
    if(geral) {
      if(!strcasecmp(k, "debug") || !strcasecmp(k, "quiet")) {
        if(!inteiro(v)) item(&erros, &n_erros, linha, "valor_invalido", k);
      } else if(!strcasecmp(k, "bind")) {
        if(inet_pton(AF_INET, v, &a4) != 1) item(&erros, &n_erros, linha, "bind_invalido", v);
      } else if(!strcasecmp(k, "bind6")) {
        if(strcasecmp(v, "off") && strcasecmp(v, "0") && strcasecmp(v, "no") && strcasecmp(v, "false") &&
           strcasecmp(v, "disabled") && strcasecmp(v, "none") && inet_pton(AF_INET6, v, &a6) != 1)
          item(&erros, &n_erros, linha, "bind_invalido", v);
      } else if(!strcasecmp(k, "log")) {
        if(strlen(v) > 255) item(&erros, &n_erros, linha, "valor_invalido", k);
      } else item(&avisos, &n_avisos, linha, "chave_desconhecida", k);
    } else if(secao == SERVIDORES) {
      if(!strcasecmp(k, "server") || !strcasecmp(k, "dns")) {
        if(!trocou_servidores) {
          n_serv = 0;
          trocou_servidores = 1;
        }
        if(inet_pton(AF_INET, v, &a4) != 1) item(&erros, &n_erros, linha, "servidor_invalido", v);
        else if((ntohl(a4.s_addr) >> 24) == 127 || a4.s_addr == 0) item(&erros, &n_erros, linha, "servidor_local", v);
        else if(n_serv >= MAX_SERVIDORES) item(&erros, &n_erros, linha, "servidores_demais", v);
        else snprintf(servidores[n_serv++], sizeof servidores[0], "%s", v);
      } else if(!strcasecmp(k, "timeout_ms")) {
        if(!inteiro(v) || atoi(v) <= 0) item(&erros, &n_erros, linha, "valor_invalido", k);
      } else item(&avisos, &n_avisos, linha, "chave_desconhecida", k);
    } else if(secao == REGRAS) {
      if(inet_pton(AF_INET, v, &a4) != 1) item(&erros, &n_erros, linha, "ip_invalido", k);
      else if(strlen(k) > MAX_MASCARA) item(&erros, &n_erros, linha, "mascara_longa", NULL);
      else if(r.n_regras >= MAX_REGRAS) item(&erros, &n_erros, linha, "regras_demais", k);
      else {
        snprintf(r.regras[r.n_regras], sizeof r.regras[0], "%s", k);
        normalizar(r.regras[r.n_regras++]);
      }
    } else item(&avisos, &n_avisos, linha, "fora_de_secao", k);
  }
  if(!trocou_servidores) {   /* sem server=: o nanoDNS usa os de fabrica */
    static const char *const FABRICA[] = {"1.1.1.1", "8.8.8.8", "77.88.8.8"};
    for(n_serv = 0; n_serv < 3; n_serv++) snprintf(servidores[n_serv], sizeof servidores[0], "%s", FABRICA[n_serv]);
  }
  if(!r.n_regras) item(&avisos, &n_avisos, 0, "sem_regras", NULL);
  int n_riscos = 0;
  buf_str(b, "\"erros\":[");
  if(erros.n) buf_add(b, erros.d, erros.n);
  buf_str(b, "],\"avisos\":[");
  if(avisos.n) buf_add(b, avisos.d, avisos.n);
  buf_str(b, "],\"riscos\":[");
  for(int i = 0; SONY[i]; i++)
    if(!bloqueado(&r, SONY[i])) {
      buf_str(b, n_riscos++ ? "," : "");
      buf_json(b, SONY[i]);
    }
  buf_str(b, "],\"servidores\":[");
  for(int i = 0; i < n_serv; i++) {
    buf_str(b, i ? "," : "");
    buf_json(b, servidores[i]);
  }
  buf_fmt(b, "],\"regras\":%d,\"excecoes\":%d,\"image_api\":%s", r.n_regras, r.n_excecoes,
          bloqueado(&r, IMAGE_API) ? "false" : "true");
  pthread_mutex_unlock(&g_trava_analise);
  buf_free(&erros);
  buf_free(&avisos);
  *riscos = n_riscos;
  return n_erros;
}

/* ------------------------------------------------------------------ disco */

/* 1 = existe e foi lido; 0 = nao existe; -1 = erro, grande demais ou nao e arquivo comum. */
static int ler_arquivo(const char *arq, buf_t *b) {
  struct stat st;
  if(lstat(arq, &st)) return errno == ENOENT ? 0 : -1;
  if(!S_ISREG(st.st_mode) || st.st_size > MAX_ARQUIVO) return -1;
  int fd = open(arq, O_RDONLY | O_NOFOLLOW);
  if(fd < 0) return -1;
  char bloco[8192];
  ssize_t r;
  while((r = read(fd, bloco, sizeof bloco)) > 0) {
    if(b->n + (size_t)r > MAX_ARQUIVO) {
      close(fd);
      return -1;
    }
    buf_add(b, bloco, (size_t)r);
  }
  close(fd);
  if(r < 0) return -1;
  buf_add(b, "", 1);
  b->n--;
  return 1;
}

static int gravar_tudo(int fd, const char *d, size_t n) {
  for(size_t feitos = 0; feitos < n;) {
    ssize_t r = write(fd, d + feitos, n - feitos);
    if(r <= 0) return -1;
    feitos += (size_t)r;
  }
  return 0;
}

/* Grava texto em arq de forma atomica (.tmp O_EXCL sem seguir link, fsync, rename, fsync da pasta). */
static int gravar_atomico(const char *pasta, const char *arq, const char *texto, size_t n, char *msg, size_t tam) {
  char tmp[700];
  snprintf(tmp, sizeof tmp, "%s.tmp", arq);
  unlink(tmp);
  int fd = open(tmp, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644);
  if(fd < 0) {
    snprintf(msg, tam, "nao criou o arquivo temporario (%s)", strerror(errno));
    return -1;
  }
  int ok = !gravar_tudo(fd, texto, n) && !fsync(fd);
  if(close(fd)) ok = 0;
  if(!ok || rename(tmp, arq)) {
    snprintf(msg, tam, "erro ao gravar (%s): o arquivo antigo ficou como estava", strerror(errno));
    unlink(tmp);
    return -1;
  }
  int d = open(pasta, O_RDONLY);
  if(d >= 0) {
    fsync(d);
    close(d);
  }
  return 0;
}

/* ------------------------------------------------------------------ sonda: o nanoDNS esta respondendo? */

static int porta_dns(void) {
#ifndef __PROSPERO__
  const char *v = getenv("GLR_TESTE_NANODNS_PORTA");
  if(v && atoi(v) > 0) return atoi(v);
#endif
  return 53;
}

/* Pergunta o endereco (A) de playstation.com ao 127.0.0.1:53. "bloqueando" = respondeu 0.0.0.0; "respondeu" = outro
   endereco ou sem endereco (o DNS do PS5 local nao esta bloqueando a Sony); "sem_resposta" = nada em 0,5 s. */
static const char *sonda(void) {
  static const unsigned char PERGUNTA[] = {
    0x4e, 0x44, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    11, 'p', 'l', 'a', 'y', 's', 't', 'a', 't', 'i', 'o', 'n', 3, 'c', 'o', 'm', 0, 0x00, 0x01, 0x00, 0x01};
  int fd = socket(AF_INET, SOCK_DGRAM, 0);
  if(fd < 0) return "sem_resposta";
  struct timeval espera = {0, 500000};
  setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &espera, sizeof espera);
  struct sockaddr_in end = {0};
  end.sin_family = AF_INET;
  end.sin_port = htons((unsigned short)porta_dns());
  end.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  unsigned char r[512];
  ssize_t n = -1;
  if(sendto(fd, PERGUNTA, sizeof PERGUNTA, 0, (struct sockaddr *)&end, sizeof end) == (ssize_t)sizeof PERGUNTA)
    n = recv(fd, r, sizeof r, 0);
  close(fd);
  if(n < (ssize_t)sizeof PERGUNTA || r[0] != 0x4e || r[1] != 0x44 || !(r[2] & 0x80)) return "sem_resposta";
  int respostas = (r[6] << 8) | r[7];
  /* o nanoDNS responde a regra com um registro A apontando para a pergunta (c0 0c) e o IPv4 nos 4 ultimos bytes */
  if(respostas >= 1 && n >= (ssize_t)sizeof PERGUNTA + 16 && !r[n - 4] && !r[n - 3] && !r[n - 2] && !r[n - 1])
    return "bloqueando";
  return "respondeu";
}

/* ------------------------------------------------------------------ rotas */

static void estado_json(buf_t *b, const char *texto, int existe, int ilegivel) {
  char arq[600], bak[620];
  struct stat st;
  arquivo_ini(arq, sizeof arq, "");
  arquivo_ini(bak, sizeof bak, ".bak");
  int riscos = 0;
  buf_fmt(b, "{\"ok\":true,\"existe\":%s,\"ilegivel\":%s,\"caminho\":", existe ? "true" : "false", ilegivel ? "true" : "false");
  buf_json(b, arq);
  buf_str(b, ",\"texto\":");
  buf_json(b, texto);
  buf_str(b, ",\"padrao\":");
  buf_json(b, PADRAO);
  buf_fmt(b, ",\"tem_backup\":%s,\"rodando\":%s,\"sonda\":\"%s\",", !lstat(bak, &st) && S_ISREG(st.st_mode) ? "true" : "false",
          plataforma_processo_rodando("nanodns.elf") ? "true" : "false", sonda());
  /* o arquivo que falta: o nanoDNS cria o padrao ao subir, entao a analise e a do padrao */
  nanodns_analisar(existe ? texto : PADRAO, b, &riscos);
  buf_str(b, "}");
}

void nanodns_rota_ler(pedido_t *p) {
  char arq[600];
  buf_t texto = {0}, b = {0};
  arquivo_ini(arq, sizeof arq, "");
  int r = ler_arquivo(arq, &texto);
  estado_json(&b, r > 0 ? texto.d : "", r > 0, r < 0);
  responder_json(p, 200, &b);
  buf_free(&b);
  buf_free(&texto);
}

static void recusar(pedido_t *p, int status, const char *chave, const char *erro, buf_t *analise) {
  buf_t b = {0};
  buf_fmt(&b, "{\"ok\":false,\"chave\":\"%s\",\"erro\":", chave);
  buf_json(&b, erro);
  if(analise && analise->n) {
    buf_str(&b, ",");
    buf_add(&b, analise->d, analise->n);
  }
  buf_str(&b, "}");
  responder_json(p, status, &b);
  buf_free(&b);
}

void nanodns_rota_gravar(pedido_t *p) {
  static char texto[MAX_ARQUIVO + 2];   /* uma gravacao por vez (g_trava) */
  static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
  char confirmo[8] = "", pasta[512], arq[600], bak[620], msg[256];
  const char *corpo = p->corpo ? p->corpo : "";
  pthread_mutex_lock(&g_trava);
  texto[0] = 0;
  int tem = param(corpo, "texto", 0, texto, sizeof texto);
  param(corpo, "confirmo", 0, confirmo, sizeof confirmo);
  size_t n = strlen(texto);
  if(!tem || !n) {
    pthread_mutex_unlock(&g_trava);
    recusar(p, 400, "nanodns_vazio", "texto vazio: nada gravado", NULL);
    return;
  }
  if(n > MAX_ARQUIVO) {
    pthread_mutex_unlock(&g_trava);
    recusar(p, 400, "nanodns_grande", "texto grande demais (32 KB no maximo): nada gravado", NULL);
    return;
  }
  /* o navegador manda \r\n: o arquivo fica com \n */
  size_t o = 0;
  for(size_t i = 0; i < n; i++)
    if(texto[i] != '\r') texto[o++] = texto[i];
  if(o && texto[o - 1] != '\n') texto[o++] = '\n';
  texto[o] = 0;
  buf_t analise = {0};
  int riscos = 0, erros = nanodns_analisar(texto, &analise, &riscos);
  if(erros) {
    pthread_mutex_unlock(&g_trava);
    diario("nanodns: texto recusado (%d erro(s))", erros);
    recusar(p, 400, "nanodns_invalido", "o arquivo tem erros: nada gravado", &analise);
    buf_free(&analise);
    return;
  }
  if(riscos && strcmp(confirmo, "1")) {
    pthread_mutex_unlock(&g_trava);
    recusar(p, 409, "nanodns_risco", "enderecos da Sony deixariam de ser bloqueados: confirme para gravar", &analise);
    buf_free(&analise);
    return;
  }
  buf_free(&analise);
  nanodns_pasta(pasta, sizeof pasta);
  arquivo_ini(arq, sizeof arq, "");
  arquivo_ini(bak, sizeof bak, ".bak");
  struct stat st;
  if(!lstat(arq, &st) && !S_ISREG(st.st_mode)) {
    pthread_mutex_unlock(&g_trava);
    recusar(p, 409, "nanodns_ilegivel", "o nanodns.ini nao e um arquivo comum: nada gravado", NULL);
    return;
  }
  if(mkdir_p(pasta)) {
    pthread_mutex_unlock(&g_trava);
    snprintf(msg, sizeof msg, "nao criou a pasta %s (%s)", pasta, strerror(errno));
    recusar(p, 500, "nanodns_nao_gravou", msg, NULL);
    return;
  }
  buf_t antigo = {0};
  int r = ler_arquivo(arq, &antigo);
  if(r > 0 && (antigo.n != o || memcmp(antigo.d, texto, o)) &&
     gravar_atomico(pasta, bak, antigo.d, antigo.n, msg, sizeof msg)) {
    buf_free(&antigo);
    pthread_mutex_unlock(&g_trava);
    recusar(p, 500, "nanodns_nao_gravou", msg, NULL);   /* sem a copia de seguranca nao troca o arquivo */
    return;
  }
  buf_free(&antigo);
  if(gravar_atomico(pasta, arq, texto, o, msg, sizeof msg)) {
    pthread_mutex_unlock(&g_trava);
    diario("nanodns: nao gravou: %s", msg);
    recusar(p, 500, "nanodns_nao_gravou", msg, NULL);
    return;
  }
  diario("nanodns: nanodns.ini gravado (%zu bytes%s)", o, riscos ? ", com enderecos da Sony liberados (confirmado)" : "");
  buf_t b = {0};
  estado_json(&b, texto, 1, 0);
  pthread_mutex_unlock(&g_trava);
  b.n--;   /* tira o } final para acrescentar "gravado" */
  buf_str(&b, ",\"gravado\":true}");
  responder_json(p, 200, &b);
  buf_free(&b);
}
