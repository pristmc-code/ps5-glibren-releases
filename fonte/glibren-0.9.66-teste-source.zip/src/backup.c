/* Game Library Renamer (payload PS5) - 0.9.36: o original de uma conversao vai para <disco>/BACKUP/<jogo>/. Ver
backup.h (regras, compatibilidade com a Jobe e por que o ShadowMount+/ShadowKraken nao varre o BACKUP). */
#include "backup.h"

#include <dirent.h>
#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "apps.h"
#include "arquivos.h"
#include "config.h"
#include "imagem.h"
#include "jogo_local.h"
#include "json_min.h"
#include "plataforma.h"
#include "util.h"

#define PASTA_BACKUP "backup"   /* 0.9.49 (decisao do usuario): minusculo; ate a 0.9.48 era "BACKUP", como na Jobe */
#define MARCADOR BACKUP_MARCADOR
#define MAX_VOLUMES 128
#define PROCESSO_SMP "shadowmountplus.elf"   /* o ShadowMount+ e o ShadowKraken usam o mesmo nome */

/* ------------------------------------------------------------------ raiz do disco */

int backup_raiz(const char *caminho, char *raiz, size_t tam) {
  if(!caminho || caminho[0] != '/') return -1;
#ifndef __PROSPERO__
  const char *teste = getenv("GLR_TESTE_RAIZES");   /* so testes no PC: raizes separadas por ":" */
  if(teste && *teste) {
    size_t melhor = 0;
    for(const char *p = teste; *p;) {
      const char *dp = strchr(p, ':');
      size_t n = dp ? (size_t)(dp - p) : strlen(p);
      if(n > 1 && n > melhor && n < tam && !strncmp(caminho, p, n) && caminho[n] == '/') {
        memcpy(raiz, p, n);
        raiz[n] = 0;
        melhor = n;
      }
      p += n + (dp ? 1 : 0);
    }
    return melhor ? 0 : -1;
  }
#endif
  if(!strncmp(caminho, "/data/", 6)) {
    snprintf(raiz, tam, "/data");
    return 0;
  }
  /* /mnt/usb0../mnt/usb7, /mnt/ext0, /mnt/ext1 (os discos que a Jobe e o SMP conhecem) */
  if(!strncmp(caminho, "/mnt/usb", 8) || !strncmp(caminho, "/mnt/ext", 8)) {
    const char *d = caminho + 8;
    if(*d < '0' || *d > '9') return -1;
    while(*d >= '0' && *d <= '9') d++;
    if(*d != '/' || (size_t)(d - caminho) >= tam) return -1;
    memcpy(raiz, caminho, (size_t)(d - caminho));
    raiz[d - caminho] = 0;
    return 0;
  }
  return -1;
}

int backup_dentro(const char *caminho) {
  char raiz[256];
  if(backup_raiz(caminho, raiz, sizeof raiz)) return 0;
  size_t n = strlen(raiz), k = strlen(PASTA_BACKUP);
  /* 0.9.49: qualquer caixa (backup, BACKUP, Backup): a Jobe e as versoes ate a 0.9.48 usam maiusculo */
  return caminho[n] == '/' && !strncasecmp(caminho + n + 1, PASTA_BACKUP, k) && (caminho[n + 1 + k] == 0 || caminho[n + 1 + k] == '/');
}

/* 0.9.49: os nomes que o disco tem para a pasta de backup, pelo readdir (num disco que nao diferencia caixa o stat de
   "backup" acha "BACKUP": so a listagem diz o nome de verdade). minusculo = 1 se existe "backup" exato; outra recebe o
   primeiro nome em outra caixa ("" = nenhum); devolve quantos nomes em outra caixa. */
static int nomes_backup(const char *raiz, int *minusculo, char *outra, size_t tam) {
  int n = 0;
  *minusculo = 0;
  outra[0] = 0;
  DIR *d = opendir(raiz);
  if(!d) return 0;
  struct dirent *e;
  while((e = readdir(d)) != NULL) {
    if(strcasecmp(e->d_name, PASTA_BACKUP)) continue;
    if(!strcmp(e->d_name, PASTA_BACKUP)) *minusculo = 1;
    else if(!n++) snprintf(outra, tam, "%s", e->d_name);
  }
  closedir(d);
  return n;
}

/* A pasta de backup do disco para o glibren gravar. 0.9.50 (decisao do usuario): <disco>/BACKUP e da Jobe e o glibren
   nao grava nela por conta propria; os originais das conversoes vao para <disco>/backup (minusculo), criada se faltar.
   Unica excecao: disco que nao diferencia caixa (exFAT em USB), onde "BACKUP" e "backup" sao a MESMA pasta (o stat de
   "backup" acha a que existe com outro nome): usa a que existe, sem renomear. */
static void pasta_backup_do_disco(const char *raiz, char *saida, size_t tam) {
  int minusculo;
  char outra[64], minus[400];
  struct stat st;
  int outras = nomes_backup(raiz, &minusculo, outra, sizeof outra);
  snprintf(minus, sizeof minus, "%s/%s", raiz, PASTA_BACKUP);
  int mesma = !minusculo && outras == 1 && !stat(minus, &st) && S_ISDIR(st.st_mode);
  snprintf(saida, tam, "%s/%s", raiz, mesma ? outra : PASTA_BACKUP);
}

/* ------------------------------------------------------------------ nome da pasta (safeFolderName da Jobe) */

__attribute__((unused)) static void nome_seguro(const char *in, char *out, size_t tam) {
  size_t n = 0;
  int espaco = 0;
  for(const unsigned char *c = (const unsigned char *)in; *c && n + 1 < tam; c++) {
    int separa = *c < 0x20 || strchr("/\\:*?\"<>|", *c) || *c == ' ' || *c == '\t';
    if(separa) {
      espaco = 1;
      continue;
    }
    if(espaco && n) out[n++] = ' ';
    espaco = 0;
    if(n + 1 < tam) out[n++] = (char)*c;
  }
  out[n] = 0;
  /* sem pontos/espacos nas pontas (o comeco ja nao tem espaco) */
  char *ini = out;
  while(*ini == '.' || *ini == ' ') ini++;
  memmove(out, ini, strlen(ini) + 1);
  n = strlen(out);
  while(n && (out[n - 1] == '.' || out[n - 1] == ' ')) out[--n] = 0;
  /* ate 96 bytes, sem cortar um caractere UTF-8 */
  if(n > 96) {
    n = 96;
    while(n && ((unsigned char)out[n] & 0xC0) == 0x80) n--;
    out[n] = 0;
  }
  /* "_temp" e a pasta das extracoes da Jobe (ela apaga o que estiver la): nunca usar */
  if(!out[0] || !strcasecmp(out, "_temp")) snprintf(out, tam, "Jogo");
}

/* Title ID no texto (PPSA01234 / CUSA01234), "" se nao tiver. */
static void codigo_no_nome(const char *texto, char *tid, size_t tam) {
  tid[0] = 0;
  for(const char *p = texto; p && *p; p++) {
    if(strncasecmp(p, "PPSA", 4) && strncasecmp(p, "CUSA", 4)) continue;
    if(p > texto && ((p[-1] >= 'A' && p[-1] <= 'Z') || (p[-1] >= 'a' && p[-1] <= 'z') || (p[-1] >= '0' && p[-1] <= '9'))) continue;
    int k = 4;
    while(k < 9 && p[k] >= '0' && p[k] <= '9') k++;
    if(k != 9 || (p[9] >= '0' && p[9] <= '9')) continue;
    snprintf(tid, tam, "%.9s", p);
    for(char *c = tid; *c; c++)
      if(*c >= 'a' && *c <= 'z') *c = (char)(*c - 32);
    return;
  }
}

/* ------------------------------------------------------------------ formato e volumes */

static int termina_com(const char *s, const char *fim) {
  size_t a = strlen(s), b = strlen(fim);
  return a >= b && !strcasecmp(s + a - b, fim);
}

/* formato do original para o marcador (a mesma lista da Jobe; pasta = "") */
static void formato_original(const char *nome, int pasta, char *fmt, size_t tam) {
  static const char *const EXT[] = {"exfat", "ffpkg", "ffpfsc", "ffpfs", "pkg", "rar", "7z", "zip", NULL};
  fmt[0] = 0;
  if(pasta) return;
  char base[512];
  snprintf(base, sizeof base, "%s", nome);
  if(termina_com(base, ".complete")) base[strlen(base) - 9] = 0;
  const char *pt = strrchr(base, '.');
  for(int i = 0; pt && EXT[i]; i++)
    if(!strcasecmp(pt + 1, EXT[i])) snprintf(fmt, tam, "%s", EXT[i]);
}

/* Os volumes de um RAR (o original incluso, primeiro). Outros formatos: so o original. */
static int volumes(const char *origem, char (*lista)[1100], int max) {
  snprintf(lista[0], 1100, "%s", origem);
  int n = 1;
  const char *barra = strrchr(origem, '/');
  if(!barra) return n;
  char pasta[1100], nome[512];
  snprintf(pasta, sizeof pasta, "%.*s", (int)(barra - origem), origem);
  snprintf(nome, sizeof nome, "%s", barra + 1);
  if(termina_com(nome, ".complete")) nome[strlen(nome) - 9] = 0;
  if(!termina_com(nome, ".rar")) return n;
  nome[strlen(nome) - 4] = 0;
  /* "x.part1" -> prefixo "x.part" + digitos + ".rar"; "x" -> "x.rar" + "x.r00".."x.z99" */
  char prefixo[512];
  int partes = 0;
  char *pt = strrchr(nome, '.');
  if(pt && !strncasecmp(pt, ".part", 5) && pt[5]) {
    partes = 1;
    for(const char *d = pt + 5; *d; d++) partes &= *d >= '0' && *d <= '9';
  }
  if(partes) snprintf(prefixo, sizeof prefixo, "%.*s", (int)(pt + 5 - nome), nome);
  else snprintf(prefixo, sizeof prefixo, "%s.", nome);
  size_t np = strlen(prefixo);
  DIR *d = opendir(pasta);
  if(!d) return n;
  struct dirent *e;
  while((e = readdir(d)) && n < max) {
    const char *x = e->d_name;
    if(strncmp(x, prefixo, np)) continue;
    const char *resto = x + np;
    int bate = 0;
    if(partes) {
      const char *q = resto;
      while(*q >= '0' && *q <= '9') q++;
      bate = q > resto && (!strcasecmp(q, ".rar") || !strcasecmp(q, ".rar.complete"));
    } else {
      bate = strlen(resto) == 3 && ((resto[0] >= 'r' && resto[0] <= 'z') || (resto[0] >= 'R' && resto[0] <= 'Z')) &&
             resto[1] >= '0' && resto[1] <= '9' && resto[2] >= '0' && resto[2] <= '9';
    }
    if(!bate) continue;
    char completo[1100];
    snprintf(completo, sizeof completo, "%s/%s", pasta, x);
    if(!strcmp(completo, origem)) continue;
    struct stat st;
    if(lstat(completo, &st) || !S_ISREG(st.st_mode)) continue;
    snprintf(lista[n++], 1100, "%s", completo);
  }
  closedir(d);
  return n;
}

/* ------------------------------------------------------------------ ShadowMount+ / ShadowKraken */

static void sem_barra_final(char *c) {
  size_t n = strlen(c);
  while(n > 1 && c[n - 1] == '/') c[--n] = 0;
}

typedef struct {
  const char *alvo, *alvo_real;
  char tid[16];
  int achou, montado, mapeado;
} busca_t;

static int mesmo(const busca_t *b, const char *caminho) {
  char c[1100];
  snprintf(c, sizeof c, "%s", caminho);
  sem_barra_final(c);
  return c[0] && (!strcmp(c, b->alvo) || (b->alvo_real[0] && !strcmp(c, b->alvo_real)));
}

static int ver_jogo(const js_t *item, void *ctx) {
  busca_t *b = ctx;
  js_t v;
  char caminho[1100] = "";
  if(!js_campo(item, "path", &v) || js_string(&v, caminho, sizeof caminho) || !mesmo(b, caminho)) return 1;
  b->achou = 1;
  if(js_campo(item, "title_id", &v)) js_string(&v, b->tid, sizeof b->tid);
  if(js_campo(item, "mounted", &v) && js_verdade(&v)) b->montado = 1;
  return 0;
}

static int ver_imagem(const js_t *item, void *ctx) {
  busca_t *b = ctx;
  js_t v;
  char caminho[1100] = "";
  if(!js_campo(item, "path", &v) || js_string(&v, caminho, sizeof caminho) || !mesmo(b, caminho)) return 1;
  if((js_campo(item, "mounted", &v) && js_verdade(&v)) || (js_campo(item, "mapped", &v) && js_verdade(&v))) b->mapeado = 1;
  return 0;
}

/* motivo de uma recusa do SMP ({"error_reason"} ou {"error"}) */
static void motivo_smp(const buf_t *resp, int status, char *saida, size_t tam) {
  snprintf(saida, tam, "HTTP %d", status);
  if(!resp->d) return;
  js_t j = {resp->d, resp->d + resp->n}, v;
  char a[160] = "", b[160] = "";
  if(js_campo(&j, "error_reason", &v)) js_string(&v, a, sizeof a);
  if(js_campo(&j, "error", &v)) js_string(&v, b, sizeof b);
  if(a[0] || b[0]) snprintf(saida, tam, "%s%s%s", a, a[0] && b[0] ? ": " : "", b);
}

/* 0 = pode mover (smp_no_ar = 1 se a API respondeu: pedir a releitura depois); 1 = adiado (r preenchido). */
static int soltar_do_smp(const char *origem, int *smp_no_ar, backup_res_t *r) {
  *smp_no_ar = 0;
  char alvo[1100], real[PATH_MAX > 1100 ? PATH_MAX : 1100] = "";
  snprintf(alvo, sizeof alvo, "%s", origem);
  sem_barra_final(alvo);
  if(!realpath(origem, real)) real[0] = 0;
  else sem_barra_final(real);
  busca_t b = {alvo, real, "", 0, 0, 0};
  buf_t resp = {0};
  int st = apps_smp_pedir("/api/v1/games", "{}", &resp, 10);
  if(st < 0) {
    buf_free(&resp);
    if(plataforma_processo_rodando(PROCESSO_SMP)) {
      snprintf(r->chave, sizeof r->chave, "smp_sem_resposta");
      r->adiado = 1;
      return 1;
    }
    return 0;   /* sem ShadowMount+/ShadowKraken: nada esta montado por ele */
  }
  *smp_no_ar = 1;
  if(st != 200 || !resp.d) {
    motivo_smp(&resp, st, r->detalhe, sizeof r->detalhe);
    buf_free(&resp);
    snprintf(r->chave, sizeof r->chave, "smp_lista");
    r->adiado = 1;
    return 1;
  }
  js_t raiz = {resp.d, resp.d + resp.n}, lista;
  if(!js_campo(&raiz, "games", &lista) || js_cada(&lista, ver_jogo, &b) < 0) {
    buf_free(&resp);
    snprintf(r->chave, sizeof r->chave, "smp_lista");
    snprintf(r->detalhe, sizeof r->detalhe, "/api/v1/games");
    r->adiado = 1;
    return 1;
  }
  buf_free(&resp);
  /* a imagem anexada (mapped/mounted em /api/v1/images) tambem conta, com ou sem jogo na lista */
  st = apps_smp_pedir("/api/v1/images", "{}", &resp, 10);
  if(st == 200 && resp.d) {
    js_t ri = {resp.d, resp.d + resp.n}, li;
    if(js_campo(&ri, "images", &li)) js_cada(&li, ver_imagem, &b);
  }
  buf_free(&resp);
  if(!b.achou) {   /* imagem presa sem jogo na lista (montando, ou o jogo saiu): nao da para soltar por aqui */
    if(b.mapeado) {
      snprintf(r->chave, sizeof r->chave, "imagem_presa");
      r->adiado = 1;
      return 1;
    }
    return 0;
  }
  diario("backup: %s: no ShadowMount+ como %s (%s%s)", origem, b.tid, b.montado ? "montado" : "nao montado",
         b.mapeado ? ", imagem anexada" : "");
  if(!b.montado && !b.mapeado) return 0;
  char corpo[64];
  snprintf(corpo, sizeof corpo, "{\"title_id\":\"%.12s\"}", b.tid);
  st = apps_smp_pedir("/api/v1/games/unmount", corpo, &resp, 30);
  if(st == 200) {
    diario("backup: %s: desmontado pelo ShadowMount+", b.tid);
    buf_free(&resp);
    return 0;
  }
  motivo_smp(&resp, st, r->detalhe, sizeof r->detalhe);
  buf_free(&resp);
  diario("backup: %s: o ShadowMount+ nao desmontou (%s): o original fica", b.tid, r->detalhe);
  snprintf(r->chave, sizeof r->chave, "montado");
  r->adiado = 1;
  return 1;
}

/* 0.9.64: o mesmo soltar do mover para o BACKUP, publico (bateria). */
int backup_soltar(const char *caminho, backup_res_t *r) {
  int no_ar = 0;
  memset(r, 0, sizeof *r);
  return soltar_do_smp(caminho, &no_ar, r);
}

int backup_em_uso(const char *caminho, char *motivo, size_t tam) {
  char alvo[1100], real[PATH_MAX > 1100 ? PATH_MAX : 1100] = "";
  motivo[0] = 0;
  snprintf(alvo, sizeof alvo, "%s", caminho);
  sem_barra_final(alvo);
  if(!realpath(caminho, real)) real[0] = 0;
  else sem_barra_final(real);
  busca_t b = {alvo, real, "", 0, 0, 0};
  buf_t resp = {0};
  int st = apps_smp_pedir("/api/v1/games", "{}", &resp, 10);
  if(st < 0) {
    buf_free(&resp);
    if(!plataforma_processo_rodando(PROCESSO_SMP)) return 0;   /* sem ShadowMount+: nada montado por ele */
    snprintf(motivo, tam, "smp_sem_resposta");
    return 1;
  }
  js_t raiz = {resp.d, resp.d + (resp.d ? resp.n : 0)}, lista;
  if(st != 200 || !resp.d || !js_campo(&raiz, "games", &lista) || js_cada(&lista, ver_jogo, &b) < 0) {
    buf_free(&resp);
    snprintf(motivo, tam, "smp_lista");
    return 1;
  }
  buf_free(&resp);
  st = apps_smp_pedir("/api/v1/images", "{}", &resp, 10);
  if(st == 200 && resp.d) {
    js_t ri = {resp.d, resp.d + resp.n}, li;
    if(js_campo(&ri, "images", &li)) js_cada(&li, ver_imagem, &b);
  }
  buf_free(&resp);
  if(b.montado) snprintf(motivo, tam, "montado");
  else if(b.mapeado) snprintf(motivo, tam, "imagem_presa");
  return motivo[0] != 0;
}

static void pedir_releitura(void);
void backup_pedir_releitura(void) { pedir_releitura(); }

static void pedir_releitura(void) {
  buf_t resp = {0};
  int st = apps_smp_pedir("/api/v1/scan", "{\"reset_attempts\":false}", &resp, 5);
  diario("backup: releitura pedida ao ShadowMount+ (HTTP %d)", st);
  buf_free(&resp);
}

/* ------------------------------------------------------------------ mover */

__attribute__((unused)) static int gravar_marcador(const char *pasta, const char *tid, const char *fmt) {
  char arq[1200];
  snprintf(arq, sizeof arq, "%s/%s", pasta, MARCADOR);
  const char *plat = !strncmp(tid, "PPSA", 4) ? "ps5" : !strncmp(tid, "CUSA", 4) ? "ps4" : "";
  FILE *f = fopen(arq, "w");
  if(!f) return -1;
  fprintf(f, "{\"titleId\":\"%s\",\"platform\":\"%s\",\"format\":\"%s\",\"source\":\"glibren\"}", tid, plat, fmt);
  int ok = !fflush(f) && !fsync(fileno(f));
  if(fclose(f)) ok = 0;
  chmod(arq, 0666);
  return ok ? 0 : -1;
}

int backup_mover(const char *origem, const char *convertido, const char *nome_base, backup_res_t *r) {
  memset(r, 0, sizeof *r);
  char raiz[256];
  struct stat st;
  if(backup_raiz(origem, raiz, sizeof raiz)) {
    snprintf(r->chave, sizeof r->chave, "disco_desconhecido");
    return -1;
  }
  if(lstat(origem, &st) || !(S_ISREG(st.st_mode) || S_ISDIR(st.st_mode))) {
    snprintf(r->chave, sizeof r->chave, "origem_sumiu");
    return -1;
  }
  int pasta = S_ISDIR(st.st_mode);
  const char *nome = strrchr(origem, '/') + 1;
  char fmt[12];
  formato_original(nome, pasta, fmt, sizeof fmt);
  int montavel = pasta || !(!strcmp(fmt, "zip") || !strcmp(fmt, "7z") || !strcmp(fmt, "rar"));

  /* Title ID so para o glibren.log (0.9.49: o destino e o nome do proprio original, nao mais o titulo do jogo) */
  (void)convertido;
  (void)nome_base;
  char tid[16] = "";
  codigo_no_nome(nome, tid, sizeof tid);

  int smp_no_ar = 0;
  if(montavel && soltar_do_smp(origem, &smp_no_ar, r)) return 1;

  static char vols[MAX_VOLUMES][1100];   /* backup_mover roda num trabalho so por vez (conversao.c) */
  int nv = volumes(origem, vols, MAX_VOLUMES);

  /* 0.9.49 (pedido do usuario): o original vai DIRETO para <disco>/BACKUP/<nome do original> (arquivo ou pasta de jogo),
     sem a subpasta <jogo> e sem marcador (pasta "backup" em minusculo). Nunca sobrescreve: se qualquer volume ja tem um xara no BACKUP, nada se move
     ("ja_existe"; a tela mantem o "Mover agora"). */
  char dir_backup[400], destino[1100];
  pasta_backup_do_disco(raiz, dir_backup, sizeof dir_backup);
  if(mkdir(dir_backup, 0777) && errno != EEXIST) {
    snprintf(r->chave, sizeof r->chave, "falha_mover");
    snprintf(r->detalhe, sizeof r->detalhe, "%s: %s", dir_backup, strerror(errno));
    if(smp_no_ar) pedir_releitura();
    return -1;
  }
  snprintf(destino, sizeof destino, "%s", dir_backup);
  for(int i = 0; i < nv; i++) {
    char alvo[1300];
    struct stat sa;
    snprintf(alvo, sizeof alvo, "%s/%s", destino, strrchr(vols[i], '/') + 1);
    if(!lstat(alvo, &sa)) {
      snprintf(r->chave, sizeof r->chave, "ja_existe");
      snprintf(r->detalhe, sizeof r->detalhe, "%s", alvo);
      diario("backup: %s: nao moveu (ja existe %s)", origem, alvo);
      if(smp_no_ar) pedir_releitura();
      return -1;
    }
  }

  int movidos = 0, erro = 0;
  for(int i = 0; i < nv; i++) {
    char alvo[1300];
    snprintf(alvo, sizeof alvo, "%s/%s", destino, strrchr(vols[i], '/') + 1);
    if(rename(vols[i], alvo)) {
      erro = errno;
      snprintf(r->detalhe, sizeof r->detalhe, "%s: %s", vols[i], strerror(erro));
      break;
    }
    movidos++;
  }
  if(erro) {   /* volta o que ja foi: o original fica inteiro no lugar */
    int volta_ok = 1;
    for(int i = 0; i < movidos; i++) {
      char alvo[1300];
      snprintf(alvo, sizeof alvo, "%s/%s", destino, strrchr(vols[i], '/') + 1);
      if(rename(alvo, vols[i])) volta_ok = 0;
    }
    snprintf(r->chave, sizeof r->chave, "%s", erro == EXDEV ? "outro_disco" : volta_ok ? "falha_mover" : "falha_metade");
    if(!volta_ok) snprintf(r->pasta, sizeof r->pasta, "%s", destino);
    diario("backup: %s: nao moveu (%s)%s", origem, r->detalhe, volta_ok ? "" : " - parte ficou no BACKUP");
    if(smp_no_ar) pedir_releitura();
    return -1;
  }
  snprintf(r->pasta, sizeof r->pasta, "%s", destino);
  diario("backup: %s -> %s (%d arquivo(s), %s)", origem, destino, nv, tid[0] ? tid : "sem Title ID");
  if(smp_no_ar) pedir_releitura();
  return 0;
}

/* ------------------------------------------------------------------ 0.9.49: arrumacao do backup antigo */

/* Uma subpasta <disco>/backup/<jogo>/ criada pelo glibren ate a 0.9.48 (marcador com "source":"glibren") e que so tem o
   marcador e os originais (arquivos comuns e/ou pastas de jogo): os originais sobem para <disco>/backup/ (rename, sem
   sobrescrever) e a subpasta e o marcador saem. Qualquer duvida = fica como esta: sem marcador ou marcador de outro
   programa (Jobe), outra coisa dentro (subpasta que nao e jogo, link), ou um xara ja na pasta de backup. */
static void arrumar_subpasta(const char *dir_backup, const char *sub) {
  char pasta[1300], arq[1700], texto[400] = "";
  snprintf(pasta, sizeof pasta, "%s/%s", dir_backup, sub);
  struct stat st;
  if(lstat(pasta, &st) || !S_ISDIR(st.st_mode) || arquivos_pasta_de_jogo(pasta)) return;
  snprintf(arq, sizeof arq, "%s/%s", pasta, MARCADOR);
  FILE *f = fopen(arq, "rb");
  if(!f) return;   /* sem marcador: nao e nossa com certeza */
  size_t n = fread(texto, 1, sizeof texto - 1, f);
  fclose(f);
  texto[n] = 0;
  if(!strstr(texto, "\"source\":\"glibren\"")) return;   /* marcador da Jobe ou de outro: nao mexe */

  static char nomes[MAX_VOLUMES][256];
  int qtd = 0, duvida = 0;
  DIR *d = opendir(pasta);
  if(!d) return;
  struct dirent *e;
  while((e = readdir(d)) != NULL) {
    if(!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..") || !strcmp(e->d_name, MARCADOR)) continue;
    snprintf(arq, sizeof arq, "%s/%s", pasta, e->d_name);
    if(lstat(arq, &st) || !(S_ISREG(st.st_mode) || (S_ISDIR(st.st_mode) && arquivos_pasta_de_jogo(arq))) || e->d_name[0] == '.' ||
       qtd >= MAX_VOLUMES) {
      duvida = 1;
      break;
    }
    snprintf(nomes[qtd++], sizeof nomes[0], "%s", e->d_name);
  }
  closedir(d);
  if(duvida) {
    diario("backup: arrumacao: %s fica como esta (ha outra coisa alem dos originais)", pasta);
    return;
  }
  for(int i = 0; i < qtd; i++) {
    snprintf(arq, sizeof arq, "%s/%s", dir_backup, nomes[i]);
    if(!lstat(arq, &st)) {
      diario("backup: arrumacao: %s fica como esta (ja existe %s)", pasta, arq);
      return;
    }
  }
  for(int i = 0; i < qtd; i++) {
    char de[1700];
    snprintf(de, sizeof de, "%s/%s", pasta, nomes[i]);
    snprintf(arq, sizeof arq, "%s/%s", dir_backup, nomes[i]);
    if(rename(de, arq)) {
      diario("backup: arrumacao: %s nao subiu (%s); o resto de %s fica como esta", de, strerror(errno), pasta);
      return;
    }
    diario("backup: arrumacao: %s -> %s", de, arq);
  }
  snprintf(arq, sizeof arq, "%s/%s", pasta, MARCADOR);
  unlink(arq);
  if(!rmdir(pasta)) diario("backup: arrumacao: subpasta removida: %s", pasta);
}

typedef struct {
  const char *prefixo;
  int montado;
} busca_prefixo_t;

static int ver_montado_em(const js_t *item, void *ctx) {
  busca_prefixo_t *b = ctx;
  js_t v;
  char caminho[1100] = "";
  size_t n = strlen(b->prefixo);
  if(!js_campo(item, "path", &v) || js_string(&v, caminho, sizeof caminho)) return 1;
  if(strncmp(caminho, b->prefixo, n) || (caminho[n] != '/' && caminho[n] != 0)) return 1;
  if((js_campo(item, "mounted", &v) && js_verdade(&v)) || (js_campo(item, "mapped", &v) && js_verdade(&v))) b->montado = 1;
  return 1;
}

/* 1 = o ShadowMount+/ShadowKraken tem algo montado/anexado a partir desta pasta, ou esta rodando e nao respondeu. */
static int montado_dentro(const char *pasta) {
  busca_prefixo_t b = {pasta, 0};
  buf_t resp = {0};
  int st = apps_smp_pedir("/api/v1/games", "{}", &resp, 10);
  if(st < 0) {
    buf_free(&resp);
    return plataforma_processo_rodando(PROCESSO_SMP);
  }
  js_t raiz = {resp.d, resp.d + (resp.d ? resp.n : 0)}, lista;
  if(st != 200 || !resp.d || !js_campo(&raiz, "games", &lista) || js_cada(&lista, ver_montado_em, &b) < 0) {
    buf_free(&resp);
    return 1;
  }
  buf_free(&resp);
  st = apps_smp_pedir("/api/v1/images", "{}", &resp, 10);
  if(st == 200 && resp.d) {
    js_t ri = {resp.d, resp.d + resp.n}, li;
    if(js_campo(&ri, "images", &li)) js_cada(&li, ver_montado_em, &b);
  }
  buf_free(&resp);
  return b.montado;
}

void backup_arrumar(int ocupado) {
  if(ocupado) {
    diario("backup: arrumacao adiada: ha conversao ou movimento em andamento");
    return;
  }
  char pastas[MAX_PASTAS][1024], feitos[MAX_PASTAS][300];
  int qtd = config_ler(pastas, NULL), nf = 0;
  for(int i = 0; i < qtd; i++) {
    char raiz[256], dir_backup[400], outra[64];
    if(backup_raiz(pastas[i], raiz, sizeof raiz)) continue;
    int repetido = 0;
    for(int k = 0; k < nf; k++) repetido |= !strcmp(feitos[k], raiz);
    if(repetido) continue;
    snprintf(feitos[nf++], sizeof feitos[0], "%s", raiz);

    /* 0.9.50 (decisao do usuario): so a pasta com o nome EXATO "backup" (minusculo) e do glibren. <disco>/BACKUP (ou
       outra caixa) e da Jobe: nada e renomeado, movido nem apagado dela por conta propria - nem no disco que nao
       diferencia caixa, onde so existe um dos nomes. (A 0.9.49 renomeava BACKUP para backup e juntava as duas.) */
    int minusculo;
    nomes_backup(raiz, &minusculo, outra, sizeof outra);
    if(!minusculo) continue;
    snprintf(dir_backup, sizeof dir_backup, "%s/%s", raiz, PASTA_BACKUP);
    if(montado_dentro(dir_backup)) {
      diario("backup: arrumacao: subpastas de %s ficam para depois (ha jogo montado a partir dali, ou o ShadowMount+ nao respondeu)", dir_backup);
      continue;
    }
    static char subs[256][256];
    int ns = 0;
    DIR *d = opendir(dir_backup);
    if(!d) continue;
    struct dirent *e;
    while(ns < 256 && (e = readdir(d)) != NULL)
      if(e->d_name[0] != '.' && strcmp(e->d_name, "_temp")) snprintf(subs[ns++], sizeof subs[0], "%s", e->d_name);
    closedir(d);
    for(int k = 0; k < ns; k++) arrumar_subpasta(dir_backup, subs[k]);
  }
}
