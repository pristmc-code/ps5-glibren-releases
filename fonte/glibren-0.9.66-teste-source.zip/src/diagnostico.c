/* Game Library Renamer (payload PS5) - "Enviar diagnostico" para o GitHub (0.9.21). Ver diagnostico.h. */
#include "diagnostico.h"

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "api.h"
#include "cheats.h"
#include "config.h"
#include "discos.h"
#include "https.h"
#include "miniz_cfg.h"
#include "payloads.h"
#include "jobe_payload.h"
#include "ampr_ajuste.h"
#include "ampr_teste.h"
#include "bateria.h"
#include "plataforma.h"
#include "sha256.h"
#include "termico.h"

#define DIAG_TAIL (8u * 1024 * 1024)        /* JSON montado na memoria: teto de seguranca */
#define DIAG_TAIL_ZIP (2u * 1024 * 1024)    /* .zip: diario so os ultimos ~2 MB (como antes da 0.9.63) */
#define DIAG_MONTADOR_ZIP (512u * 1024)     /* .zip: logs do montador, traces e medidas: os ultimos 512 KB (0.9.42) */
#define DIAG_MAX_ARQ 110  /* 0.9.51: + ampr-teste.json e ate 5 traces do ampr-emu-ng; 0.9.57: + ampr-backports.json; 0.9.62: ate 10 traces;
                             0.9.63: + ampr-ajustes.json, ampr-emu-tune.txt, ate 20 traces e as 40 medidas do ampr */
/* 0.9.63: no envio nada e cortado: arquivo do disco vai inteiro, em partes de DIAG_PARTE (ver diagnostico.h). Tetos de
   seguranca: DIAG_ARQ_MAX por arquivo (passou: os ultimos 512 MB) e DIAG_TOTAL no envio todo (passou: saem primeiro os
   traces do ampr mais velhos, depois as medidas mais velhas); tudo que fica de fora vai no info.json e no _arquivos.txt. */
#define DIAG_PARTE (8u * 1024 * 1024)
#define DIAG_ARQ_MAX (512ULL * 1024 * 1024)
#define DIAG_TOTAL (1024ULL * 1024 * 1024)
#define DIAG_RESERVA (256u * 1024)          /* folga para o info.json, que entra por ultimo */
#define DIAG_REPO "/repos/pristmc-code/ps5-diagnosticos/contents/glibren/"
#define DIAG_COMMITTER "{\"name\":\"PristMC\",\"email\":\"285300718+pristmc-code@users.noreply.github.com\"}"
#define DIAG_OCULTO "[segredo]"

/* ---- AS REGRAS DE HIGIENIZACAO (lista unica; diagnostico_limpar as aplica a tudo que sai, envio e .zip) --------
   1. Valores secretos conhecidos (as chaves do GitHub do glibren e da Jobe, os SHA-256 dos aparelhos pareados) saem
      onde aparecerem.
   2. Endereco http(s): usuario:senha sai; a consulta (?...) e o #... saem sempre (links assinados); num host de
      DIAG_HOSTS_PRIVADOS (links temporarios: googlevideo, servicos debrid) sai o caminho inteiro.
   3. "Bearer xxx" / "Basic xxx" (Authorization).
   4. nome=valor / nome: valor / "nome":"valor" com um nome de DIAG_NOMES_SECRETOS (cookie, authorization e
      set-cookie levam a linha inteira).
   5. E-mails.
   6. Tokens soltos: os prefixos de DIAG_PREFIXOS (chaves do GitHub), UUID e qualquer trecho de 32+ letras e digitos
      misturados (hashes, tokens do pareamento, cookies).
      Excecao (0.9.23): um hash hexadecimal de 40 ou 64 digitos logo depois de um nome de DIAG_NOMES_PUBLICOS
      ("sha256": "...", commit=..., sha ...) e publico (SHA-256 dos assets, sha dos commits) e fica como esta. A regra 1
      vem antes, entao um segredo conhecido sai mesmo com esses nomes.
   Alem disso, no config.ini as linhas "paired" (aparelhos pareados) viram "paired = [aparelho pareado]".
   Arquivos que nunca vao: as chaves (diag/token do glibren e da Jobe). */
static const char *const DIAG_NOMES_SECRETOS[] = {
  "access_token", "refresh_token", "id_token", "token", "apikey", "api_key", "api-key", "key", "chave", "password", "passwd",
  "senha", "secret", "client_secret", "authorization", "auth", "set-cookie", "cookie", "sessionid", "session", "sid",
  "sapisid", "signature", "sig", "x-glr-token", "x-jobe-token", "x-session", "code_verifier", "device_code", "user_code",
  "codigo", "paired", NULL};
static const char *const DIAG_NOMES_LINHA[] = {"authorization", "set-cookie", "cookie", NULL};
static const char *const DIAG_HOSTS_PRIVADOS[] = {
  "googlevideo.com", "youtube.com", "youtu.be", "googleapis.com", "torbox", "tb-cdn", "alldebrid", "debrid", "real-debrid",
  "rdeb.io", "premiumize", "debrid-link", "1fichier", NULL};
static const char *const DIAG_NOMES_PUBLICOS[] = {"sha256", "sha1", "sha", "commit", NULL};
static const char *const DIAG_PREFIXOS[] = {"github_pat_", "ghp_", "gho_", "ghu_", "ghs_", "ghr_", NULL};

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static struct {
  int rodando;
  char estado[12], pasta[24], erro[16];
  int http, enviados, total;
  long long em;
  char faltaram[400];   /* 0.9.23: arquivos que nao subiram, separados por virgula */
} g_d = {0, "idle", "", "", 0, 0, 0, 0, ""};
/* duas rodadas no mesmo segundo nao caem na mesma pasta (no GitHub, PUT num arquivo que ja existe sem "sha" da 422) */
static char g_ult_pasta[24];
static int g_usos;

/* ------------------------------------------------------------------ caminhos */

static void pasta_diag(char *s, size_t tam) {
#ifdef __PROSPERO__
  snprintf(s, tam, "/data/glibren/diag");
#else
  const char *e = getenv("GLR_TESTE_DIAG");
  if(e && *e) snprintf(s, tam, "%s", e);
  else snprintf(s, tam, "%s/diag", g_pasta_dados);
#endif
}

static void arquivo_chave(char *s, size_t tam) {
  char p[512];
  pasta_diag(p, sizeof p);
  snprintf(s, tam, "%s/token", p);
}

/* A chave que a Jobe guardou (bg_diag.c: <diag>/token com <diag> = /data/JobeesLair/diag). So leitura. */
static void arquivo_chave_jobe(char *s, size_t tam) {
#ifdef __PROSPERO__
  snprintf(s, tam, "/data/JobeesLair/diag/token");
#else
  const char *e = getenv("GLR_TESTE_JOBE_TOKEN");
  snprintf(s, tam, "%s", e ? e : "");
#endif
}

static void arquivo_fullscreen(char *s, size_t tam) {
#ifdef __PROSPERO__
  snprintf(s, tam, "/data/web-browser-fullscreen.ini");
#else
  const char *e = getenv("GLR_TESTE_FULLSCREEN_INI");
  snprintf(s, tam, "%s", e ? e : "");
#endif
}

/* Os ultimos `cap` bytes de `caminho` (comecando numa linha inteira quando corta). NULL se nao existe ou vazio. */
static char *ler_final(const char *caminho, size_t cap, size_t *n, int *cortado) {
  *cortado = 0;
  *n = 0;
  if(!caminho[0]) return NULL;
  int fd = open(caminho, O_RDONLY);
  if(fd < 0) return NULL;
  struct stat st;
  if(fstat(fd, &st) || !S_ISREG(st.st_mode) || st.st_size <= 0) {
    close(fd);
    return NULL;
  }
  size_t quer = (size_t)st.st_size;
  off_t de = 0;
  if(quer > cap) {
    de = st.st_size - (off_t)cap;
    quer = cap;
    *cortado = 1;
  }
  char *t = malloc(quer + 1);
  if(!t) {
    close(fd);
    return NULL;
  }
  size_t lidos = 0;
  while(lidos < quer) {
    ssize_t k = pread(fd, t + lidos, quer - lidos, de + (off_t)lidos);
    if(k < 0 && errno == EINTR) continue;
    if(k <= 0) break;
    lidos += (size_t)k;
  }
  close(fd);
  t[lidos] = 0;
  if(*cortado) {
    char *l = memchr(t, '\n', lidos);
    if(l && (size_t)(l - t) + 1 < lidos) {
      size_t pula = (size_t)(l - t) + 1;
      memmove(t, t + pula, lidos - pula + 1);
      lidos -= pula;
    }
  }
  for(size_t i = 0; i < lidos; i++)
    if(!t[i]) t[i] = ' ';   /* um \0 no meio cortaria o texto na limpeza */
  if(!lidos) {
    free(t);
    return NULL;
  }
  *n = lidos;
  return t;
}

/* ------------------------------------------------------------------ a chave */

static int chave_ok(const char *k) {
  size_t n = strlen(k);
  return n >= 20 && n <= 200 && strspn(k, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_") == n;
}

/* 1 = ha chave valida no arquivo (em `saida`). Quem chama apaga `saida` (memset) depois de usar. */
static int ler_chave_de(const char *caminho, char *saida, size_t cap) {
  saida[0] = 0;
  size_t n = 0;
  int cortado = 0;
  char *t = ler_final(caminho, 1024, &n, &cortado);
  if(!t) return 0;
  char *ini = t;
  while(*ini == ' ' || *ini == '\n' || *ini == '\r' || *ini == '\t') ini++;
  size_t k = strcspn(ini, " \r\n\t");
  if(k < cap) {
    memcpy(saida, ini, k);
    saida[k] = 0;
  }
  memset(t, 0, n);
  free(t);
  if(cortado || !chave_ok(saida)) {
    memset(saida, 0, cap);
    return 0;
  }
  return 1;
}

/* A chave em uso: a do glibren e, sem ela, a da Jobe. origem: "glibren", "jobe" ou "". */
static int ler_chave(char *saida, size_t cap, const char **origem) {
  char c[600];
  arquivo_chave(c, sizeof c);
  if(ler_chave_de(c, saida, cap)) {
    if(origem) *origem = "glibren";
    return 1;
  }
  arquivo_chave_jobe(c, sizeof c);
  if(ler_chave_de(c, saida, cap)) {
    if(origem) *origem = "jobe";
    return 1;
  }
  if(origem) *origem = "";
  return 0;
}

static void estado_json(buf_t *b) {
  char k[256], final[8] = "", c[600];
  const char *origem = "";
  int tem = ler_chave(k, sizeof k, &origem);
  if(tem) snprintf(final, sizeof final, "%s", k + strlen(k) - 4);
  memset(k, 0, sizeof k);
  arquivo_chave(c, sizeof c);
  struct stat st;
  int propria = !stat(c, &st);
  pthread_mutex_lock(&g_trava);
  buf_fmt(b, "{\"ok\":true,\"configurada\":%s,\"origem\":", tem ? "true" : "false");
  buf_json(b, origem);
  buf_str(b, ",\"final\":");
  buf_json(b, final);
  buf_fmt(b, ",\"propria\":%s,\"estado\":", propria ? "true" : "false");
  buf_json(b, g_d.estado);
  buf_str(b, ",\"pasta\":");
  buf_json(b, g_d.pasta);
  buf_str(b, ",\"erro\":");
  buf_json(b, g_d.erro);
  buf_fmt(b, ",\"http\":%d,\"enviados\":%d,\"total\":%d,\"em\":%lld,\"faltaram\":", g_d.http, g_d.enviados, g_d.total, g_d.em);
  buf_json(b, g_d.faltaram);
  buf_str(b, "}");
  pthread_mutex_unlock(&g_trava);
}

/* ------------------------------------------------------------------ higienizacao */

typedef struct {
  char v[12][160];
  int n;
} segredos_t;

static void segredo_add(segredos_t *s, const char *v) {
  if(s->n < 12 && strlen(v) >= 6 && strlen(v) < sizeof s->v[0]) snprintf(s->v[s->n++], sizeof s->v[0], "%s", v);
}

/* Os valores que o glibren conhece. Quem chama apaga (memset) depois. */
static void segredos_conhecidos(segredos_t *s) {
  memset(s, 0, sizeof *s);
  char k[256], c[600];
  arquivo_chave(c, sizeof c);
  if(ler_chave_de(c, k, sizeof k)) segredo_add(s, k);
  arquivo_chave_jobe(c, sizeof c);
  if(ler_chave_de(c, k, sizeof k)) segredo_add(s, k);
  memset(k, 0, sizeof k);
  char pareados[MAX_PAREADOS][TAM_PAREADO];
  int q = config_pareados(pareados, MAX_PAREADOS);
  for(int i = 0; i < q; i++) {
    pareados[i][strcspn(pareados[i], " ")] = 0;   /* so o sha256 */
    segredo_add(s, pareados[i]);
  }
  memset(pareados, 0, sizeof pareados);
}

static int alnum(char c) { return isalnum((unsigned char)c) != 0; }
static int tokch(char c) { return alnum(c) || c == '-' || c == '_'; }
static int mailch(char c) { return alnum(c) || c == '.' || c == '_' || c == '%' || c == '+' || c == '-'; }
static int fim_valor(char c) { return !c || isspace((unsigned char)c) || strchr("\"',;&}])<>`", c); }
static int fim_url(char c) { return !c || isspace((unsigned char)c) || strchr("\"'<>`\\", c); }

/* Regra 2: o endereco em `p` (comeca com http:// ou https://). Escreve a versao limpa e devolve quantos bytes leu. */
static size_t limpar_url(buf_t *o, const char *p) {
  size_t esquema = !strncasecmp(p, "https://", 8) ? 8 : 7, fim = esquema;
  while(!fim_url(p[fim])) fim++;
  size_t fim_host = esquema;
  while(fim_host < fim && p[fim_host] != '/' && p[fim_host] != '?' && p[fim_host] != '#') fim_host++;
  buf_add(o, p, esquema);
  size_t host = esquema;
  const char *arroba = memchr(p + esquema, '@', fim_host - esquema);
  if(arroba) {
    buf_str(o, DIAG_OCULTO "@");
    host = (size_t)(arroba - p) + 1;
  }
  buf_add(o, p + host, fim_host - host);
  char nome[256];
  size_t n = fim_host - host < sizeof nome - 1 ? fim_host - host : sizeof nome - 1;
  for(size_t i = 0; i < n; i++) nome[i] = (char)tolower((unsigned char)p[host + i]);
  nome[n] = 0;
  int privado = 0;
  for(int i = 0; DIAG_HOSTS_PRIVADOS[i] && !privado; i++) privado = strstr(nome, DIAG_HOSTS_PRIVADOS[i]) != NULL;
  if(privado) {
    if(fim_host < fim) buf_str(o, "/[...]");
    return fim;
  }
  size_t fim_caminho = fim_host;
  while(fim_caminho < fim && p[fim_caminho] != '?' && p[fim_caminho] != '#') fim_caminho++;
  buf_add(o, p + fim_host, fim_caminho - fim_host);
  if(fim_caminho < fim) buf_str(o, p[fim_caminho] == '?' ? "?[...]" : "#[...]");
  return fim;
}

/* Regra 4: um nome de DIAG_NOMES_SECRETOS em `p` seguido de = ou :. Devolve quantos bytes leu (0 = nao e). */
static size_t limpar_nomeado(buf_t *o, const char *p, int nome_entre_aspas) {
  for(int i = 0; DIAG_NOMES_SECRETOS[i]; i++) {
    size_t n = strlen(DIAG_NOMES_SECRETOS[i]);
    if(strncasecmp(p, DIAG_NOMES_SECRETOS[i], n) || alnum(p[n]) || p[n] == '_' || p[n] == '-') continue;
    size_t at = n;
    if(p[at] == '"') at++;
    while(p[at] == ' ' || p[at] == '\t') at++;
    if(p[at] != '=' && p[at] != ':') continue;
    at++;
    while(p[at] == ' ' || p[at] == '\t') at++;
    /* um objeto, uma lista, null/true/false/numero pequeno, ou nada: nao e um valor secreto */
    if(!p[at] || p[at] == '{' || p[at] == '[' || p[at] == '\n' || p[at] == '\r' || !strncmp(p + at, "null", 4) ||
       !strncmp(p + at, "true", 4) || !strncmp(p + at, "false", 5) || !strncmp(p + at, "\"\"", 2))
      return 0;
    int linha = 0;
    for(int k = 0; DIAG_NOMES_LINHA[k]; k++) linha |= !strcasecmp(DIAG_NOMES_SECRETOS[i], DIAG_NOMES_LINHA[k]);
    if(p[at] == '"') {
      buf_add(o, p, at + 1);
      buf_str(o, DIAG_OCULTO);
      at++;
      while(p[at] && p[at] != '"' && p[at] != '\n') at += p[at] == '\\' && p[at + 1] ? 2 : 1;
      return at;   /* a aspa de fechamento segue como texto */
    }
    buf_add(o, p, at);
    buf_str(o, nome_entre_aspas ? "\"" DIAG_OCULTO "\"" : DIAG_OCULTO);
    if(linha && !nome_entre_aspas)
      while(p[at] && p[at] != '\n' && p[at] != '\r') at++;
    else
      while(!fim_valor(p[at])) at++;
    return at;
  }
  return 0;
}

/* Excecao da regra 6: nome de DIAG_NOMES_PUBLICOS + separador + hash hex de 40/64 digitos. Copia tudo como esta e
   devolve quantos bytes leu (0 = nao e). */
static size_t publico_nomeado(buf_t *o, const char *p, const segredos_t *sec) {
  for(int i = 0; DIAG_NOMES_PUBLICOS[i]; i++) {
    size_t n = strlen(DIAG_NOMES_PUBLICOS[i]);
    if(strncasecmp(p, DIAG_NOMES_PUBLICOS[i], n) || alnum(p[n]) || p[n] == '_' || p[n] == '-') continue;
    size_t at = n;
    if(p[at] == '"') at++;
    while(p[at] == ' ' || p[at] == '	') at++;
    if(p[at] == '=' || p[at] == ':') at++;
    else if(at == n) continue;   /* sem = ou : precisa de pelo menos um espaco: "sha256 abc..." */
    while(p[at] == ' ' || p[at] == '	') at++;
    if(p[at] == '"') at++;
    size_t h = 0;
    while(isxdigit((unsigned char)p[at + h])) h++;
    if((h != 40 && h != 64) || tokch(p[at + h])) continue;
    int conhecido = 0;   /* regra 1 vence: um segredo conhecido nao vira publico por causa do nome */
    for(int k = 0; k < sec->n && !conhecido; k++) conhecido = strlen(sec->v[k]) == h && !strncmp(p + at, sec->v[k], h);
    if(conhecido) return 0;
    buf_add(o, p, at + h);
    return at + h;
  }
  return 0;
}

/* Regra 5: um e-mail em `p` (comeco de palavra). Devolve o tamanho (0 = nao e). */
static size_t email(const char *p) {
  size_t local = 0;
  while(local < 64 && mailch(p[local])) local++;
  if(!local || p[local] != '@') return 0;
  size_t at = local + 1, rotulo = 0, pontos = 0, ultimo = 0;
  for(;; at++) {
    char c = p[at];
    if(alnum(c) || c == '-') {
      rotulo++;
      continue;
    }
    if(c == '.' && rotulo) {
      pontos++;
      rotulo = 0;
      continue;
    }
    break;
  }
  for(size_t k = at; k > local + 1 && p[k - 1] != '.'; k--) {
    if(!isalpha((unsigned char)p[k - 1])) return 0;
    ultimo++;
  }
  return pontos && rotulo && ultimo >= 2 ? at : 0;
}

/* Regra 6: um token solto em `p` (comeco de trecho [A-Za-z0-9_-]). Devolve o tamanho e se e segredo. */
static size_t token_solto(const char *p, int *segredo) {
  size_t n = 0;
  while(tokch(p[n])) n++;
  *segredo = 0;
  for(int i = 0; DIAG_PREFIXOS[i]; i++)
    if(!strncmp(p, DIAG_PREFIXOS[i], strlen(DIAG_PREFIXOS[i])) && n > strlen(DIAG_PREFIXOS[i]) + 8) *segredo = 1;
  if(n == 36) {   /* UUID 8-4-4-4-12 */
    int uuid = 1;
    for(size_t i = 0; i < 36 && uuid; i++) uuid = i == 8 || i == 13 || i == 18 || i == 23 ? p[i] == '-' : isxdigit((unsigned char)p[i]) != 0;
    if(uuid) *segredo = 1;
  }
  for(size_t ini = 0; ini < n && !*segredo;) {   /* um pedaco sem - ou _ de 32+ com letras e digitos */
    size_t fim = ini;
    int letras = 0, digitos = 0;
    while(fim < n && alnum(p[fim])) {
      letras += isalpha((unsigned char)p[fim]) != 0;
      digitos += isdigit((unsigned char)p[fim]) != 0;
      fim++;
    }
    if(fim - ini >= 32 && letras && digitos) *segredo = 1;
    ini = fim + 1;
  }
  return n;
}

/* Excecao da 6 (0.9.43): os bytes de uma cheat no diario ("trecho 1 0x80117000: 0000... -> C7803801...: lido de volta
   ok") sao hexadecimal MAIUSCULO junto de uma seta " -> "; um codigo de 32+ digitos ali e o que a cheat grava, nao um
   segredo (no diagnostico de 18/11 o Easy Score saiu como [segredo]). Tokens e hashes do resto do sistema sao minusculos. */
static int bytes_de_cheat(const char *in, size_t i, size_t n, size_t tam) {
  for(size_t k = 0; k < n; k++)
    if(!isdigit((unsigned char)in[i + k]) && !(in[i + k] >= 'A' && in[i + k] <= 'F')) return 0;
  return (i >= 3 && !strncmp(in + i - 3, "-> ", 3)) || (i + n + 4 <= tam && !strncmp(in + i + n, " -> ", 4));
}

static char *limpar(const char *in, size_t tam, const segredos_t *sec, size_t *n_saida) {
  buf_t o = {0};
  buf_add(&o, "", 0);
  for(size_t i = 0; i < tam;) {
    const char *p = in + i;
    char ant = i ? in[i - 1] : ' ';
    size_t usado = 0;
    for(int k = 0; k < sec->n && !usado; k++) {   /* 1 */
      size_t n = strlen(sec->v[k]);
      if(*p == sec->v[k][0] && !strncmp(p, sec->v[k], n)) {
        buf_str(&o, DIAG_OCULTO);
        usado = n;
      }
    }
    if(usado) {
      i += usado;
      continue;
    }
    if((*p == 'h' || *p == 'H') && !alnum(ant) && (!strncasecmp(p, "http://", 7) || !strncasecmp(p, "https://", 8))) {   /* 2 */
      i += limpar_url(&o, p);
      continue;
    }
    if(!alnum(ant) && (!strncasecmp(p, "bearer ", 7) || !strncmp(p, "Basic ", 6))) {   /* 3 */
      size_t at = (*p == 'B' && p[1] == 'a') ? 6 : 7;
      while(p[at] == ' ') at++;
      if(!fim_valor(p[at])) {
        buf_add(&o, p, at);
        buf_str(&o, DIAG_OCULTO);
        while(!fim_valor(p[at])) at++;
        i += at;
        continue;
      }
    }
    if(!tokch(ant) && (*p == 's' || *p == 'S' || *p == 'c' || *p == 'C') && (usado = publico_nomeado(&o, p, sec))) {   /* excecao da 6 */
      i += usado;
      continue;
    }
    if(!alnum(ant) && isalpha((unsigned char)*p) && (usado = limpar_nomeado(&o, p, ant == '"'))) {   /* 4 */
      i += usado;
      continue;
    }
    if(mailch(*p) && !mailch(ant) && (usado = email(p))) {   /* 5 */
      buf_str(&o, "[email]");
      i += usado;
      continue;
    }
    if(tokch(*p) && !tokch(ant)) {   /* 6 */
      int segredo = 0;
      usado = token_solto(p, &segredo);
      if(segredo && bytes_de_cheat(in, i, usado, tam)) segredo = 0;
      if(segredo) {
        buf_str(&o, DIAG_OCULTO);
        i += usado;
        continue;
      }
    }
    buf_add(&o, p, 1);
    i++;
  }
  *n_saida = o.n;
  return o.d;
}

char *diagnostico_limpar(const char *texto, size_t n, size_t *n_saida) {
  segredos_t s;
  segredos_conhecidos(&s);
  char *r = limpar(texto, n, &s, n_saida);
  memset(&s, 0, sizeof s);
  return r;
}

/* ------------------------------------------------------------------ os arquivos */

typedef struct {
  char nome[48];
  char *d;
  size_t n;
  int cortado;
  /* 0.9.63: arquivo do disco (so no envio): lido e higienizado parte por parte na hora de subir */
  int disco;
  char caminho[600];
  unsigned long long inicio, tamanho, no_disco;
} arq_t;

typedef struct {
  arq_t a[DIAG_MAX_ARQ];
  int n;
  char faltam[1600];
  unsigned long long total;   /* 0.9.63: soma do que entrou */
  char fora[1600];            /* 0.9.63: o que ficou de fora pelos tetos */
  int zip;                    /* 0.9.63: montando o .zip (cortes antigos, tudo na memoria) */
  segredos_t sec;             /* 0.9.63: as partes sao higienizadas na hora do envio */
} conjunto_t;

static unsigned long long diag_total(void) {
#ifndef __PROSPERO__
  const char *e = getenv("GLR_TESTE_DIAG_TOTAL");   /* testes: teto menor */
  if(e && atoll(e) > 0) return (unsigned long long)atoll(e);
#endif
  return DIAG_TOTAL;
}

static size_t diag_parte(void) {
#ifndef __PROSPERO__
  const char *e = getenv("GLR_TESTE_DIAG_PARTE");   /* testes: partes menores */
  if(e && atoll(e) > 0) return (size_t)atoll(e);
#endif
  return DIAG_PARTE;
}

static void fora(conjunto_t *c, const char *nome) {
  size_t n = strlen(c->fora);
  snprintf(c->fora + n, sizeof c->fora - n, "%s%s", n ? "," : "", nome);
}

static void conjunto_liberar(conjunto_t *c) {
  for(int i = 0; i < c->n; i++) {
    if(c->a[i].d) memset(c->a[i].d, 0, c->a[i].n);
    free(c->a[i].d);
  }
  memset(c, 0, sizeof *c);
}

static void faltou(conjunto_t *c, const char *nome) {
  size_t n = strlen(c->faltam);
  snprintf(c->faltam + n, sizeof c->faltam - n, "%s%s", n ? "," : "", nome);
}

/* Junta o texto ja limpo (fica com `t`, que e apagado e liberado). */
static void juntar(conjunto_t *c, const char *nome, char *t, size_t n, int cortado, const segredos_t *sec) {
  if(c->n >= DIAG_MAX_ARQ) {
    memset(t, 0, n);
    free(t);
    fora(c, nome);
    return;
  }
  size_t nl = 0;
  char *l = limpar(t, n, sec, &nl);
  memset(t, 0, n);
  free(t);
  if(!l) {
    faltou(c, nome);
    return;
  }
  if(c->total + nl > diag_total()) {   /* 0.9.63: passaria do teto */
    memset(l, 0, nl);
    free(l);
    fora(c, nome);
    return;
  }
  c->total += nl;
  arq_t *a = &c->a[c->n++];
  snprintf(a->nome, sizeof a->nome, "%s", nome);
  a->d = l;
  a->n = nl;
  a->cortado = cortado;
}

/* Arquivo do disco. No .zip: os ultimos `max_zip` bytes, na memoria (como antes). No envio (0.9.63): so anota o
   caminho e o tamanho; o conteudo e lido, higienizado e enviado parte por parte em rodada(). */
static void juntar_final(conjunto_t *c, const char *nome, const char *caminho, const segredos_t *sec, int opcional, size_t max_zip) {
  if(c->zip) {
    size_t n = 0;
    int cortado = 0;
    char *t = ler_final(caminho, max_zip, &n, &cortado);
    if(!t) {
      if(!opcional) faltou(c, nome);
      return;
    }
    juntar(c, nome, t, n, cortado, sec);
    return;
  }
  struct stat st;
  if(!caminho[0] || stat(caminho, &st) || !S_ISREG(st.st_mode) || st.st_size <= 0) {
    if(!opcional) faltou(c, nome);
    return;
  }
  unsigned long long tam = (unsigned long long)st.st_size, inicio = 0;
  if(tam > DIAG_ARQ_MAX) {
    inicio = tam - DIAG_ARQ_MAX;
    tam = DIAG_ARQ_MAX;
  }
  if(c->n >= DIAG_MAX_ARQ || c->total + tam > diag_total()) {
    fora(c, nome);
    return;
  }
  c->total += tam;
  arq_t *a = &c->a[c->n++];
  memset(a, 0, sizeof *a);
  snprintf(a->nome, sizeof a->nome, "%s", nome);
  snprintf(a->caminho, sizeof a->caminho, "%s", caminho);
  a->disco = 1;
  a->inicio = inicio;
  a->tamanho = tam;
  a->no_disco = (unsigned long long)st.st_size;
  a->n = (size_t)tam;
  a->cortado = inicio > 0;
}

static void juntar_arquivo(conjunto_t *c, const char *nome, const char *caminho, const segredos_t *sec, int opcional) {
  juntar_final(c, nome, caminho, sec, opcional, DIAG_TAIL_ZIP);
}

static void juntar_buf(conjunto_t *c, const char *nome, buf_t *b, const segredos_t *sec) {
  if(!b->d || !b->n) {
    buf_free(b);
    faltou(c, nome);
    return;
  }
  char *t = b->d;
  size_t n = b->n;
  int cortado = 0;
  if(n > DIAG_TAIL) {   /* nao acontece com os JSON de hoje; por garantia */
    memmove(t, t + (n - DIAG_TAIL), DIAG_TAIL);
    n = DIAG_TAIL;
    t[n] = 0;
    cortado = 1;
  }
  b->d = NULL;
  b->n = b->cap = 0;
  juntar(c, nome, t, n, cortado, sec);
}

/* config.ini: as linhas "paired" (aparelhos pareados) viram "paired = [aparelho pareado]". */
static void juntar_config(conjunto_t *c, const segredos_t *sec) {
  char caminho[600];
  snprintf(caminho, sizeof caminho, "%s/config.ini", g_pasta_dados);
  size_t n = 0;
  int cortado = 0;
  char *t = ler_final(caminho, DIAG_TAIL, &n, &cortado);
  if(!t) {
    faltou(c, "config.ini");
    return;
  }
  buf_t b = {0};
  for(char *l = t; *l;) {
    char *fim = strchr(l, '\n');
    size_t tl = fim ? (size_t)(fim - l) + 1 : strlen(l);
    const char *x = l;
    while(*x == ' ' || *x == '\t') x++;
    if(!strncmp(x, "paired", 6) && (x[6] == ' ' || x[6] == '=' || x[6] == '\t')) buf_str(&b, "paired = [aparelho pareado]\n");
    else buf_add(&b, l, tl);
    l += tl;
  }
  memset(t, 0, n);
  free(t);
  if(!b.d) buf_add(&b, "", 0);
  juntar_buf(c, "config.ini", &b, sec);
}

/* 0.9.63: traces do ampr (ate AMPR_TRACES_MAX) e medidas (ate AMPR_MEDIDAS_DIAG), da mais nova para a mais velha,
   ate o teto DIAG_TOTAL: conta pelo tamanho no disco antes, e tira primeiro os traces mais velhos, depois as medidas
   mais velhas (o que sai vai no info.json e no _arquivos.txt). */
typedef struct {
  char tn[AMPR_TRACES_MAX][96], tc[AMPR_TRACES_MAX][600], mn[AMPR_MEDIDAS_DIAG][96], mc[AMPR_MEDIDAS_DIAG][600];
  size_t tt[AMPR_TRACES_MAX], tm[AMPR_MEDIDAS_DIAG];
  char ft[AMPR_TRACES_MAX], fm[AMPR_MEDIDAS_DIAG];
} plano_ampr_t;

static size_t tam_no_disco(const char *c, unsigned long long teto) {
  struct stat st;
  if(stat(c, &st) || st.st_size <= 0) return 0;
  return (unsigned long long)st.st_size < teto ? (size_t)st.st_size : (size_t)teto;
}

static void juntar_ampr(conjunto_t *c, const segredos_t *sec) {
  plano_ampr_t *p = calloc(1, sizeof *p);
  if(!p) {
    faltou(c, "ampr-traces");
    return;
  }
  int nt = ampr_teste_traces(p->tn, p->tc, AMPR_TRACES_MAX), nm = ampr_ajuste_medidas(p->mn, p->mc, AMPR_MEDIDAS_DIAG);
  unsigned long long soma = 0, teto = diag_total(), usado = c->total + DIAG_RESERVA, cada = c->zip ? DIAG_MONTADOR_ZIP : DIAG_ARQ_MAX;
  unsigned long long livre = teto > usado ? teto - usado : 0;
  for(int i = 0; i < nt; i++) soma += p->tt[i] = tam_no_disco(p->tc[i], cada);
  for(int i = 0; i < nm; i++) soma += p->tm[i] = tam_no_disco(p->mc[i], cada);
  for(int it = nt - 1, im = nm - 1; soma > livre && (it >= 0 || im >= 0);) {
    if(it >= 0) {
      p->ft[it] = 1;
      soma -= p->tt[it--];
    } else {
      p->fm[im] = 1;
      soma -= p->tm[im--];
    }
  }
  for(int i = 0; i < nt; i++) {
    if(p->ft[i]) fora(c, p->tn[i]);
    else juntar_final(c, p->tn[i], p->tc[i], sec, 1, DIAG_MONTADOR_ZIP);
  }
  for(int i = 0; i < nm; i++) {
    if(p->fm[i]) fora(c, p->mn[i]);
    else juntar_final(c, p->mn[i], p->mc[i], sec, 1, DIAG_MONTADOR_ZIP);
  }
  free(p);
}

/* Junta tudo (ja limpo) em `c`. */
static void coletar(conjunto_t *c, const char *pasta, const char *de) {
  memset(c, 0, sizeof *c);
  c->zip = !strcmp(de, "zip");
  segredos_conhecidos(&c->sec);
#define sec (c->sec)
  char caminho[600], fw[16] = "";
  const char *origem = "";
  char k[256];
  ler_chave(k, sizeof k, &origem);
  memset(k, 0, sizeof k);
  payloads_firmware(fw, sizeof fw);

  snprintf(caminho, sizeof caminho, "%s/glibren.log", g_pasta_dados);
  juntar_arquivo(c, "glibren.log", caminho, &sec, 0);
  juntar_config(c, &sec);
  buf_t b = {0};
  termico_json(&b, 1);   /* temperaturas, ventoinha, consumo (W) e o historico */
  juntar_buf(c, "termico.json", &b, &sec);
  payloads_json(&b);     /* payloads de teste: estado, erro e a saida do ultimo */
  juntar_buf(c, "payloads.json", &b, &sec);
  jobe_payload_json(&b); /* 0.9.27: payload da Jobe no ar e a copia conferida */
  juntar_buf(c, "jobe-payload.json", &b, &sec);
  cheats_json(&b);       /* cheats: jogo aberto, catalogo e o que esta ligado */
  juntar_buf(c, "cheats.json", &b, &sec);
  cheats_caminho_aplicadas(caminho, sizeof caminho);
  juntar_arquivo(c, "cheats-aplicadas.json", caminho, &sec, 1);
  discos_listar(&b);     /* discos e espaco livre */
  juntar_buf(c, "discos.json", &b, &sec);
  arquivo_fullscreen(caminho, sizeof caminho);
  juntar_arquivo(c, "web-browser-fullscreen.ini", caminho, &sec, 1);
  /* 0.9.42: logs do montador (ShadowKraken/ShadowMount+ e kraken-mount), so os ultimos 512 KB de cada; ficam de fora
     se o arquivo nao existe */
  static const char *const MONTADOR[][2] = {
      {"shadowmount-debug.log", "/data/shadowmount/debug.log"},
      {"shadowmount-config.ini", "/data/shadowmount/config.ini"},
      {"shadowmount-notify.txt", "/data/shadowmount/notify.txt"},
      {"krakenmount-kraken.log", "/data/krakenmount/kraken.log"},
      {"krakenmount-klog.txt", "/data/krakenmount/klog.txt"},
      {"ampr-emu-tune.txt", "/data/ampr_emu_tune.txt"},   /* 0.9.63: ajustes do ampr-emu-ng de depuracao */
      {"teste-pad.log", "/data/teste-pad.log"},           /* 0.9.64: log do nosso payload teste-pad (controle virtual) */
  };
  const char *raiz = getenv("GLR_TESTE_MONTADOR");   /* testes no PC: pasta no lugar de /data */
  for(size_t i = 0; i < sizeof MONTADOR / sizeof MONTADOR[0]; i++) {
    snprintf(caminho, sizeof caminho, "%s%s", raiz ? raiz : "/data", MONTADOR[i][1] + 5);
    juntar_final(c, MONTADOR[i][0], caminho, &sec, 1, DIAG_MONTADOR_ZIP);
  }

  /* 0.9.51: build de teste do ampr-emu-ng (qual esta em uso) e as ultimas copias de /data/ampr_emu_trace.txt, so os
     ultimos 512 KB de cada ("cortado" quando passa) */
  ampr_teste_json(&b);
  juntar_buf(c, "ampr-teste.json", &b, &sec);
  ampr_backports_json(&b);   /* 0.9.57: ampr-emu-ng posto no fakelib/ dos backports */
  juntar_buf(c, "ampr-backports.json", &b, &sec);
  /* 0.9.63: Velocidade do ampr: ajustes/resumo agora (se o jogo com o -deb estiver aberto); depois traces e medidas */
  ampr_ajuste_json(&b);
  juntar_buf(c, "ampr-ajustes.json", &b, &sec);
  juntar_ampr(c, &sec);
  /* 0.9.64: bateria automatica: estado, journal, resultados, plano e o relatorio */
  bateria_json(&b);
  juntar_buf(c, "bateria.json", &b, &sec);
  {
    char bn[6][96], bc[6][600];
    int nb = bateria_arquivos(bn, bc, 6);
    for(int i = 0; i < nb; i++) juntar_final(c, bn[i], bc[i], &sec, 1, DIAG_MONTADOR_ZIP);
  }

  /* info.json: versao, firmware, de onde veio o pedido e o que foi junto */
  char pareados[MAX_PAREADOS][TAM_PAREADO];
  int q = config_pareados(pareados, MAX_PAREADOS);
  memset(pareados, 0, sizeof pareados);
  buf_str(&b, "{\"pasta\":");
  buf_json(&b, pasta);
  buf_str(&b, ",\"pedido\":");
  buf_json(&b, de);
  buf_str(&b, ",\"glibren\":");
  buf_json(&b, VERSAO);
  buf_str(&b, ",\"firmware\":");
  buf_json(&b, fw);
  buf_fmt(&b, ",\"hora\":%lld,\"chave_de\":", (long long)time(NULL));
  buf_json(&b, origem);
  buf_fmt(&b, ",\"pareamento\":{\"ligado\":%s,\"aparelhos\":%d},\"arquivos\":[", config_pareamento() ? "true" : "false", q);
  for(int i = 0; i < c->n; i++) {
    buf_str(&b, i ? ",{\"nome\":" : "{\"nome\":");
    buf_json(&b, c->a[i].nome);
    buf_fmt(&b, ",\"bytes\":%zu,\"cortado\":%s,\"partes\":%s}", c->a[i].n, c->a[i].cortado ? "true" : "false",
            c->a[i].disco && c->a[i].tamanho > diag_parte() ? "true" : "false");
  }
  buf_str(&b, "],\"faltam\":");
  buf_json(&b, c->faltam);
  buf_fmt(&b, ",\"total_bytes\":%llu,\"limite_total\":%llu,\"parte\":%zu,\"fora_pelo_limite\":", c->total, diag_total(), diag_parte());
  buf_json(&b, c->fora);
  buf_str(&b, "}\n");
  if(c->fora[0]) diario("diagnostico: fora pelo limite: %s", c->fora);
  juntar_buf(c, "info.json", &b, &sec);
#undef sec
}

/* ------------------------------------------------------------------ envio */

static void base64(buf_t *b, const unsigned char *d, size_t n) {
  static const char T[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  char q[4];
  for(size_t i = 0; i < n; i += 3) {
    uint32_t v = (uint32_t)d[i] << 16 | (i + 1 < n ? (uint32_t)d[i + 1] << 8 : 0) | (i + 2 < n ? d[i + 2] : 0);
    q[0] = T[v >> 18 & 63];
    q[1] = T[v >> 12 & 63];
    q[2] = i + 1 < n ? T[v >> 6 & 63] : '=';
    q[3] = i + 2 < n ? T[v & 63] : '=';
    buf_add(b, q, 4);
  }
}

/* 0.9.23: uma falha de rede (HTTP 0/-1), 429 ou 5xx tenta de novo ate DIAG_TENTATIVAS vezes, com espera curta.
   401/403/404/422 nao mudam tentando de novo. */
#define DIAG_TENTATIVAS 3
static int vale_repetir(int status) {
  return status <= 0 || status == 408 || status == 429 || status >= 500;
}

static int enviar_um(const char *chave, const char *pasta, const char *msg, const arq_t *a) {
  buf_t corpo = {0};
  buf_str(&corpo, "{\"message\":");
  buf_json(&corpo, msg);
  buf_str(&corpo, ",\"committer\":" DIAG_COMMITTER ",\"branch\":\"main\",\"content\":\"");
  base64(&corpo, (const unsigned char *)a->d, a->n);
  buf_str(&corpo, "\"}");
  char caminho[300];
  snprintf(caminho, sizeof caminho, DIAG_REPO "%s/%s", pasta, a->nome);
  int status = https_github_put(caminho, chave, corpo.d, corpo.n);
  buf_free(&corpo);
  return status;
}

/* 0.9.59: o CoreDump (coredump.c) usa a mesma chave e o mesmo PUT, numa pasta fora de glibren/ do repositorio */
int diagnostico_chave_ler(char *saida, size_t cap) { return ler_chave(saida, cap, NULL); }
int diagnostico_vale_repetir(int status) { return vale_repetir(status); }
int diagnostico_github_arquivo(const char *chave, const char *caminho, const char *msg, const void *d, size_t n) {
  if(!caminho[0] || caminho[0] == '/' || strstr(caminho, "..") ||
     strspn(caminho, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._-/") != strlen(caminho))
    return -1;
  buf_t corpo = {0};
  buf_str(&corpo, "{\"message\":");
  buf_json(&corpo, msg);
  buf_str(&corpo, ",\"committer\":" DIAG_COMMITTER ",\"branch\":\"main\",\"content\":\"");
  base64(&corpo, (const unsigned char *)d, n);
  buf_str(&corpo, "\"}");
  char url[400];
  snprintf(url, sizeof url, "/repos/pristmc-code/ps5-diagnosticos/contents/%s", caminho);
  int status = corpo.d ? https_github_put(url, chave, corpo.d, corpo.n) : -1;
  buf_free(&corpo);
  return status;
}

/* 0.9.63: ver diagnostico.h. Mesmo esquema de partes do CoreDump (0.9.59), agora usado pelos dois. */
static const segredos_t *g_sec_partes;   /* higienizacao das partes do diagnostico (uma rodada por vez) */
int diagnostico_subir_arquivo(const char *chave, const char *destino, const char *msg, const char *caminho, unsigned long long inicio,
                              unsigned long long tamanho, size_t pedaco, int higienizar, diag_partes_t *r, void (*andou)(size_t)) {
  memset(r, 0, sizeof *r);
  int fd = open(caminho, O_RDONLY);
  if(fd < 0) return -2;
  char *buf = malloc(pedaco + 1);
  if(!buf) {
    close(fd);
    return -2;
  }
  int dividir = tamanho > pedaco, st = 0;
  static segredos_t proprios;   /* fora de uma rodada do diagnostico (enviar uma medida do ampr) */
  static pthread_mutex_t trava_sec = PTHREAD_MUTEX_INITIALIZER;
  const segredos_t *sec = g_sec_partes;
  if(higienizar && !sec) {
    pthread_mutex_lock(&trava_sec);
    segredos_conhecidos(&proprios);
    sec = &proprios;
  }
  unsigned long long pos = inicio, fim = inicio + tamanho;
  sha256_t h;
  sha256_iniciar(&h);
  for(int parte = 1;; parte++) {
    size_t quer = fim - pos < pedaco ? (size_t)(fim - pos) : pedaco, k = 0;
    while(k < quer) {
      ssize_t x = pread(fd, buf + k, quer - k, (off_t)(pos + k));
      if(x < 0 && errno == EINTR) continue;
      if(x <= 0) break;
      k += (size_t)x;
    }
    if(k < quer) {   /* o arquivo encolheu */
      st = -2;
      break;
    }
    if(higienizar && pos + k < fim) {   /* a parte termina numa linha inteira (um segredo nunca fica dividido) */
      size_t j = k;
      while(j && buf[j - 1] != '\n') j--;
      if(j) k = j;
    }
    const char *dados = buf;
    size_t n = k;
    char *limpo = NULL;
    if(higienizar) {
      for(size_t i = 0; i < k; i++)
        if(!buf[i]) buf[i] = ' ';   /* um \0 no meio cortaria o texto na limpeza */
      limpo = limpar(buf, k, sec, &n);
      if(!limpo) {
        st = -2;
        break;
      }
      dados = limpo;
    }
    sha256_atualizar(&h, dados, n);
    char alvo[400];
    if(dividir) snprintf(alvo, sizeof alvo, "%s.parte%03d", destino, parte);
    else snprintf(alvo, sizeof alvo, "%s", destino);
    for(int t = 1; t <= DIAG_TENTATIVAS; t++) {
      st = diagnostico_github_arquivo(chave, alvo, msg, dados, n);
      if(st == 200 || st == 201 || !vale_repetir(st) || t == DIAG_TENTATIVAS) break;
      r->retentativas++;
      sleep((unsigned)t);   /* 1 s, depois 2 s: tenta de novo so esta parte */
    }
    if(limpo) {
      memset(limpo, 0, n);
      free(limpo);
    }
    if(st != 200 && st != 201) break;
    st = 201;
    r->bytes += n;
    r->partes = dividir ? parte : 0;
    pos += k;
    if(andou) andou(k);
    if(pos >= fim || !dividir) break;
  }
  memset(buf, 0, pedaco + 1);
  free(buf);
  struct stat s2;
  if(!fstat(fd, &s2) && (unsigned long long)s2.st_size != inicio + tamanho) r->mudou = 1;
  close(fd);
  if(sec == &proprios) {
    memset(&proprios, 0, sizeof proprios);
    pthread_mutex_unlock(&trava_sec);
  }
  uint8_t res[32];
  sha256_final(&h, res);
  sha256_hex(res, r->sha256);
  return st;
}

static void terminar(const char *estado, const char *erro, int http) {
  pthread_mutex_lock(&g_trava);
  snprintf(g_d.estado, sizeof g_d.estado, "%s", estado);
  snprintf(g_d.erro, sizeof g_d.erro, "%s", erro);
  g_d.http = http;
  g_d.rodando = 0;
  g_d.em = (long long)time(NULL);
  pthread_mutex_unlock(&g_trava);
}

static void nome_pasta(char *s, size_t tam) {
#ifndef __PROSPERO__
  const char *e = getenv("GLR_TESTE_DIAG_PASTA");
  if(e && *e) {
    snprintf(s, tam, "%s", e);
    return;
  }
#endif
  time_t agora = time(NULL);
  struct tm t;
  localtime_r(&agora, &t);
  if(!strftime(s, tam, "%Y-%m-%d_%H%M%S", &t)) snprintf(s, tam, "sem-data");
}

static void *rodada(void *arg) {
  char pasta[24];
  snprintf(pasta, sizeof pasta, "%s", (char *)arg);
  free(arg);
  char chave[256];
  const char *origem = "";
  if(!ler_chave(chave, sizeof chave, &origem)) {
    terminar("failed", "no-key", 0);
    return NULL;
  }
  conjunto_t *c = malloc(sizeof *c);
  if(!c) {
    memset(chave, 0, sizeof chave);
    terminar("failed", "memory", 0);
    return NULL;
  }
  coletar(c, pasta, "celular");
  g_sec_partes = &c->sec;
  char msg[120];
  snprintf(msg, sizeof msg, "diagnostico glibren %s %s", pasta, VERSAO);
  pthread_mutex_lock(&g_trava);
  g_d.total = c->n + 1;   /* + _arquivos.txt */
  pthread_mutex_unlock(&g_trava);
  /* 0.9.63: _arquivos.txt (por ultimo): o que subiu, para remontar as partes e conferir */
  buf_t indice = {0};
  buf_fmt(&indice, "# Diagnostico glibren %s, pasta glibren/%s\n# arquivo bytes sha256 partes (partes > 0: cat <arquivo>.parte* > <arquivo>; "
                   "sha256 do arquivo remontado, ja higienizado)\n", VERSAO, pasta);
  /* cada arquivo: ate DIAG_TENTATIVAS vezes. Se nao subir, entra em "faltaram" e o envio segue com o proximo; chave
     recusada (401/403/404) ou 2 arquivos seguidos sem subir (sem internet) param a rodada, e o resto tambem falta. */
  int status = 0, enviados = 0, ruim = 0, seguidos = 0, retentativas = 0;
  char faltaram[400] = "";
  static arq_t ix;   /* o indice (uma rodada por vez) */
  for(int i = 0; i <= c->n; i++) {
    int st = 0;
    const arq_t *a = i < c->n ? &c->a[i] : NULL;
    if(!a && ruim) {   /* sem internet ou chave recusada: o indice tambem fica */
      size_t k = strlen(faltaram);
      snprintf(faltaram + k, sizeof faltaram - k, "%s_arquivos.txt", k ? "," : "");
      break;
    }
    if(!a) {   /* o indice, por ultimo */
      if(c->fora[0]) buf_fmt(&indice, "# fora pelo limite (%llu MB no total): %s\n", diag_total() >> 20, c->fora);
      if(faltaram[0]) buf_fmt(&indice, "# nao subiram: %s\n", faltaram);
      if(c->faltam[0]) buf_fmt(&indice, "# nao existem: %s\n", c->faltam);
      memset(&ix, 0, sizeof ix);
      snprintf(ix.nome, sizeof ix.nome, "_arquivos.txt");
      ix.d = indice.d;
      ix.n = indice.n;
      a = &ix;
      for(int t = 1; t <= DIAG_TENTATIVAS; t++) {
        st = enviar_um(chave, pasta, msg, a);
        if(st == 200 || st == 201 || !vale_repetir(st) || t == DIAG_TENTATIVAS) break;
        retentativas++;
        sleep((unsigned)t);
      }
    } else if(!ruim && a->disco) {   /* 0.9.63: do disco, inteiro, em partes se passar de DIAG_PARTE */
      char destino[200];
      diag_partes_t r;
      snprintf(destino, sizeof destino, "glibren/%s/%s", pasta, a->nome);
      st = diagnostico_subir_arquivo(chave, destino, msg, a->caminho, a->inicio, a->tamanho, diag_parte(), 1, &r, NULL);
      retentativas += r.retentativas;
      if(st == 201) {
        buf_fmt(&indice, "%s %llu %s %d", a->nome, r.bytes, r.sha256, r.partes);
        if(a->cortado) buf_fmt(&indice, " (so os ultimos %llu de %llu bytes: teto de 512 MB por arquivo)", a->tamanho, a->no_disco);
        if(r.mudou) buf_str(&indice, " (o arquivo cresceu durante o envio: foi ate o tamanho do comeco)");
        buf_str(&indice, "\n");
      }
    } else if(!ruim) {
      for(int t = 1; t <= DIAG_TENTATIVAS; t++) {
        st = enviar_um(chave, pasta, msg, a);
        if(st == 200 || st == 201 || !vale_repetir(st) || t == DIAG_TENTATIVAS) break;
        retentativas++;
        sleep((unsigned)t);   /* 1 s, depois 2 s */
      }
      if(st == 200 || st == 201) {
        sha256_t h;
        uint8_t res[32];
        char hex[65];
        sha256_iniciar(&h);
        sha256_atualizar(&h, a->d, a->n);
        sha256_final(&h, res);
        sha256_hex(res, hex);
        buf_fmt(&indice, "%s %zu %s 0%s\n", a->nome, a->n, hex, a->cortado ? " (cortado)" : "");
      }
    }
    if(!ruim && (st == 200 || st == 201)) {
      seguidos = 0;
      pthread_mutex_lock(&g_trava);
      g_d.enviados = ++enviados;
      pthread_mutex_unlock(&g_trava);
      continue;
    }
    if(!ruim) {
      status = st;
      if(!vale_repetir(st) || ++seguidos >= 2) ruim = 1;
    }
    size_t k = strlen(faltaram);
    snprintf(faltaram + k, sizeof faltaram - k, "%s%s", k ? "," : "", a->nome);
  }
  g_sec_partes = NULL;
  buf_free(&indice);
  memset(chave, 0, sizeof chave);
  pthread_mutex_lock(&g_trava);
  snprintf(g_d.faltaram, sizeof g_d.faltaram, "%s", faltaram);
  pthread_mutex_unlock(&g_trava);
  if(retentativas) diario("diagnostico: %d nova(s) tentativa(s) de envio", retentativas);
  int total = c->n + 1;
  conjunto_liberar(c);
  free(c);
  if(total == 1) {   /* so o indice: nada para enviar */
    terminar("failed", "nothing", 0);
    diario("diagnostico: nada para enviar");
    return NULL;
  }
  if(enviados == total) {
    terminar("done", "", 201);
    diario("diagnostico: enviado (%d arquivo(s), pasta glibren/%s, chave do %s)", enviados, pasta, origem);
    return NULL;
  }
  const char *erro = status == -1 ? "network" : status == 401 ? "unauthorized" : status == 403 ? "forbidden" : status == 404 ? "no-repo" : "http";
  terminar("failed", erro, status > 0 ? status : 0);
  diario("diagnostico: falhou (%s, HTTP %d) depois de %d de %d arquivo(s), pasta glibren/%s; faltaram: %s", erro, status > 0 ? status : 0,
         enviados, total, pasta, faltaram);
  return NULL;
}

/* ------------------------------------------------------------------ zip (so "stored": os textos sao pequenos) */

static void le16(buf_t *b, unsigned v) {
  unsigned char x[2] = {(unsigned char)v, (unsigned char)(v >> 8)};
  buf_add(b, x, 2);
}
static void le32(buf_t *b, uint32_t v) {
  unsigned char x[4] = {(unsigned char)v, (unsigned char)(v >> 8), (unsigned char)(v >> 16), (unsigned char)(v >> 24)};
  buf_add(b, x, 4);
}

/* 0.9.63: o .zip vai em pedacos direto para a conexao (antes era montado inteiro na memoria: com o teto de 64 MB
   seriam 2 copias). Primeiro calcula o tamanho total e os CRC; depois manda cabecalho local + dados de cada arquivo e
   o diretorio central no fim. */
static void enviar_zip(pedido_t *p, const conjunto_t *c, const char *pasta) {
  time_t agora = time(NULL);
  struct tm t;
  localtime_r(&agora, &t);
  unsigned hora = (unsigned)(t.tm_hour << 11 | t.tm_min << 5 | t.tm_sec / 2);
  unsigned data = (unsigned)((t.tm_year > 80 ? t.tm_year - 80 : 0) << 9 | (t.tm_mon + 1) << 5 | t.tm_mday);
  static uint32_t off[DIAG_MAX_ARQ], crc[DIAG_MAX_ARQ];
  static char nomes[DIAG_MAX_ARQ][96];
  static pthread_mutex_t trava = PTHREAD_MUTEX_INITIALIZER;   /* os vetores acima sao estaticos (pilha da conexao) */
  pthread_mutex_lock(&trava);
  size_t total = 0;
  for(int i = 0; i < c->n; i++) {
    snprintf(nomes[i], sizeof nomes[i], "%s/%s", pasta, c->a[i].nome);
    crc[i] = (uint32_t)mz_crc32(MZ_CRC32_INIT, (const unsigned char *)c->a[i].d, c->a[i].n);
    off[i] = (uint32_t)total;
    total += 30 + strlen(nomes[i]) + c->a[i].n;
  }
  uint32_t ini_cd = (uint32_t)total;
  for(int i = 0; i < c->n; i++) total += 46 + strlen(nomes[i]);
  uint32_t tam_cd = (uint32_t)total - ini_cd;
  total += 22;
  responder_cabecalho(p, 200, "application/zip", total, "no-store");
  buf_t z = {0};
  int erro = 0;
  for(int i = 0; i < c->n && !erro; i++) {
    z.n = 0;
    le32(&z, 0x04034b50);
    le16(&z, 20);
    le16(&z, 0x0800);   /* nomes em UTF-8 */
    le16(&z, 0);        /* stored */
    le16(&z, hora);
    le16(&z, data);
    le32(&z, crc[i]);
    le32(&z, (uint32_t)c->a[i].n);
    le32(&z, (uint32_t)c->a[i].n);
    le16(&z, (unsigned)strlen(nomes[i]));
    le16(&z, 0);
    buf_str(&z, nomes[i]);
    erro = responder_pedaco(p, z.d, z.n) || responder_pedaco(p, c->a[i].d, c->a[i].n);
  }
  z.n = 0;
  for(int i = 0; i < c->n; i++) {
    le32(&z, 0x02014b50);
    le16(&z, 20);
    le16(&z, 20);
    le16(&z, 0x0800);
    le16(&z, 0);
    le16(&z, hora);
    le16(&z, data);
    le32(&z, crc[i]);
    le32(&z, (uint32_t)c->a[i].n);
    le32(&z, (uint32_t)c->a[i].n);
    le16(&z, (unsigned)strlen(nomes[i]));
    le16(&z, 0);
    le16(&z, 0);
    le16(&z, 0);
    le16(&z, 0);
    le32(&z, 0644u << 16);
    le32(&z, off[i]);
    buf_str(&z, nomes[i]);
  }
  le32(&z, 0x06054b50);
  le16(&z, 0);
  le16(&z, 0);
  le16(&z, (unsigned)c->n);
  le16(&z, (unsigned)c->n);
  le32(&z, tam_cd);
  le32(&z, ini_cd);
  le16(&z, 0);
  if(!erro) responder_pedaco(p, z.d, z.n);
  pthread_mutex_unlock(&trava);
  buf_free(&z);
  diario("diagnostico: .zip baixado (%zu bytes, %d arquivo(s))", total, c->n);
}

/* ------------------------------------------------------------------ rotas */

static void responder_estado(pedido_t *p) {
  buf_t b = {0};
  estado_json(&b);
  responder_json(p, 200, &b);
  buf_free(&b);
}

void diagnostico_rota_estado(pedido_t *p) {
  responder_estado(p);
}

void diagnostico_rota_chave(pedido_t *p) {
  char k[300] = "";
  if(p->corpo) param(p->corpo, "chave", 0, k, sizeof k);
  /* espacos ou quebra de linha colados junto saem */
  char *ini = k;
  while(*ini == ' ' || *ini == '\t' || *ini == '\n' || *ini == '\r') ini++;
  size_t n = strlen(ini);
  while(n && (ini[n - 1] == ' ' || ini[n - 1] == '\t' || ini[n - 1] == '\n' || ini[n - 1] == '\r')) ini[--n] = 0;
  if(!chave_ok(ini)) {
    memset(k, 0, sizeof k);
    responder_erro(p, 400, "diag_chave_invalida", "isso nao parece uma chave do GitHub (github_pat_...)", NULL);
    return;
  }
  char pasta[512], arq[600], tmp[620];
  pasta_diag(pasta, sizeof pasta);
  arquivo_chave(arq, sizeof arq);
  snprintf(tmp, sizeof tmp, "%s.novo", arq);
  int ok = !mkdir_p(pasta);
  if(ok) {
    chmod(pasta, 0700);
    unlink(tmp);
    int fd = open(tmp, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0600);
    ok = fd >= 0 && write(fd, ini, n) == (ssize_t)n;
    if(fd >= 0) {
      fchmod(fd, 0600);
      if(close(fd)) ok = 0;
    }
    ok = ok && !rename(tmp, arq);
    if(!ok) unlink(tmp);
  }
  memset(k, 0, sizeof k);
  if(!ok) {
    responder_erro(p, 500, "diag_nao_gravou", "nao gravou a chave", NULL);
    return;
  }
  diario("diagnostico: chave do GitHub gravada pela pagina");
  responder_estado(p);
}

void diagnostico_rota_remover(pedido_t *p) {
  char arq[600];
  arquivo_chave(arq, sizeof arq);
  if(!unlink(arq)) diario("diagnostico: chave do GitHub removida pela pagina");
  responder_estado(p);
}

void diagnostico_rota_enviar(pedido_t *p) {
  char k[256];
  int tem = ler_chave(k, sizeof k, NULL);
  memset(k, 0, sizeof k);
  if(!tem) {
    responder_erro(p, 400, "diag_sem_chave", "falta a chave do GitHub", NULL);
    return;
  }
  char *pasta = calloc(1, 24);
  if(!pasta) {
    responder_erro(p, 500, "diag_memoria", "sem memoria", NULL);
    return;
  }
  nome_pasta(pasta, 24);
  pthread_mutex_lock(&g_trava);
  if(g_d.rodando) {
    pthread_mutex_unlock(&g_trava);
    free(pasta);
    responder_erro(p, 409, "diag_ocupado", "ja ha um envio em andamento", NULL);
    return;
  }
  if(!strcmp(pasta, g_ult_pasta)) {   /* a mesma hora da rodada anterior: -2, -3... */
    char base[24];
    snprintf(base, sizeof base, "%s", pasta);
    if(g_usos < 99) g_usos++;
    snprintf(pasta, 24, "%.17s-%d", base, g_usos);
  } else {
    snprintf(g_ult_pasta, sizeof g_ult_pasta, "%s", pasta);
    g_usos = 1;
  }
  g_d.rodando = 1;
  snprintf(g_d.estado, sizeof g_d.estado, "running");
  snprintf(g_d.pasta, sizeof g_d.pasta, "%s", pasta);
  g_d.erro[0] = 0;
  g_d.faltaram[0] = 0;
  g_d.http = g_d.enviados = g_d.total = 0;
  g_d.em = (long long)time(NULL);
  pthread_mutex_unlock(&g_trava);
  diario("diagnostico: rodada pedida (pasta glibren/%s)", pasta);
  if(criar_thread(rodada, pasta, NULL)) {
    free(pasta);
    terminar("failed", "memory", 0);
    responder_erro(p, 500, "diag_memoria", "sem memoria", NULL);
    return;
  }
  responder(p, 200, "application/json", "{\"ok\":true,\"estado\":\"running\"}", 30, NULL);
}

void diagnostico_rota_zip(pedido_t *p) {
  char pasta[24];
  nome_pasta(pasta, sizeof pasta);
  conjunto_t *c = malloc(sizeof *c);
  if(!c) {
    responder(p, 500, "text/plain", "", 0, NULL);
    return;
  }
  coletar(c, pasta, "zip");
  enviar_zip(p, c, pasta);
  conjunto_liberar(c);
  free(c);
}
