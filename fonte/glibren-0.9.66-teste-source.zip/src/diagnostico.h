/* Game Library Renamer (payload PS5) - "Enviar diagnostico" para o GitHub (0.9.21).

O jogador manda o diario e o estado do glibren sem o PC: uma chave do GitHub (fine-grained PAT so do repositorio
privado pristmc-code/ps5-diagnosticos, Contents read/write) e usada para gravar os arquivos, ja higienizados, em
glibren/<AAAA-MM-DD_HHMMSS>/ desse repositorio. A chave vem, nesta ordem: da que foi colada no glibren
(/data/glibren/diag/token, 0600) ou da que a Jobe ja guardou no mesmo console (/data/JobeesLair/diag/token, so leitura).
A chave nunca volta num GET (so "configurada, termina em ...xxxx") e nunca vai para o diario. Modelo: bg_diag.c da Jobe
(glibren.44), reescrito em C para o glibren. Reserva: o mesmo conjunto num .zip.

Rotas (api.c):
  GET  /api/diagnostico               {ok, configurada, origem, final, propria, estado, pasta, erro, http, enviados, total, em}
  POST /api/diagnostico/chave         chave=<PAT>   (pareamento + X-GLR)   400 {chave:"diag_chave_invalida"}
  POST /api/diagnostico/chave/remover               (pareamento + X-GLR)   apaga so a chave do glibren
  POST /api/diagnostico/enviar                      (pareamento + X-GLR)   400 diag_sem_chave / 409 diag_ocupado
  GET  /api/diagnostico/zip           application/zip com os mesmos arquivos (leitura livre, como o /diario)

0.9.63: nada se perde. Os arquivos do disco (diario, logs do montador, traces e medidas do ampr) vao inteiros, lidos do
disco uma parte por vez na hora do envio; maior que 8 MB vai em <nome>.parte001, .parte002... (cada parte termina numa
linha inteira e e higienizada sozinha; remonta com cat). Teto de 512 MB por arquivo (passou: os ultimos 512 MB) e de 1 GB
no total (passou: saem primeiro os traces mais velhos, depois as medidas mais velhas). Por ultimo _arquivos.txt:
"arquivo bytes sha256 partes" de cada um (sha256 do que subiu, ja remontado) e o que ficou de fora. Cada parte tenta ate
3 vezes, so ela. O .zip (reserva) continua com os cortes antigos (diario 2 MB, logs/traces 512 KB) e vai em pedacos. */
#pragma once

#include <stddef.h>

#include "http.h"
#include "util.h"

void diagnostico_rota_estado(pedido_t *p);
void diagnostico_rota_chave(pedido_t *p);
void diagnostico_rota_remover(pedido_t *p);
void diagnostico_rota_enviar(pedido_t *p);
void diagnostico_rota_zip(pedido_t *p);

/* Higienizacao (as regras ficam no topo de diagnostico.c). Devolve o texto limpo (malloc). */
char *diagnostico_limpar(const char *texto, size_t n, size_t *n_saida);

/* 0.9.59 (coredump.c): a chave em uso (1 = achou; quem chama apaga com memset), PUT de um arquivo em
   pristmc-code/ps5-diagnosticos/<caminho> (sem "..", so letras, digitos, . _ - /) e a regra de tentar de novo. */
int diagnostico_chave_ler(char *saida, size_t cap);
int diagnostico_github_arquivo(const char *chave, const char *caminho, const char *msg, const void *d, size_t n);
int diagnostico_vale_repetir(int status);

/* 0.9.63: sobe um arquivo do disco (diagnostico e CoreDump): inteiro se tem ate `pedaco` bytes, senao
   <destino>.parte001, .parte002... Le uma parte por vez (nunca o arquivo inteiro na memoria). higienizar=1: cada parte
   termina numa linha inteira e passa pela higienizacao do diagnostico; 0: bytes como estao. Cada parte tenta ate 3 vezes
   (so ela). Envia `tamanho` bytes a partir de `inicio`. andou (opcional): bytes do disco ja enviados. Devolve 201 = ok;
   senao o status do PUT que falhou (-1 rede, -2 leitura: o arquivo encolheu). */
typedef struct {
  unsigned long long bytes;   /* o que subiu (depois da higienizacao) */
  int partes;                 /* 0 = foi inteiro */
  int retentativas;
  int mudou;                  /* o tamanho no disco mudou durante o envio */
  char sha256[65];            /* do que subiu, na ordem (= do arquivo remontado) */
} diag_partes_t;
int diagnostico_subir_arquivo(const char *chave, const char *destino, const char *msg, const char *caminho, unsigned long long inicio,
                              unsigned long long tamanho, size_t pedaco, int higienizar, diag_partes_t *r, void (*andou)(size_t));
