// 0.9.63: pagina Payloads - bloco "Velocidade do ampr" no cartao do ShadowKraken, em 360 e 1280 px: ajustes, resumo,
// trecho, cronometro, sugestao, conjuntos, disco e medidas sem rolar de lado, botoes da mesma linha com a mesma largura,
// nenhum texto cortado. O /api/payloads real vem com o ShadowKraken marcado como instalado (page.route), o resto e o
// glibren-pc com o ampr-emu-ng falso no ar. Chamado pelo testes/teste_ampr_ajuste.sh.
//   node teste_ampr_ajuste_pagina.mjs http://127.0.0.1:8941 <pasta do pacote playwright> [pasta das fotos]
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const [base, pw, fotos] = process.argv.slice(2);
const { chromium } = await import(pathToFileURL(path.join(pw, 'index.mjs')).href);
let ok = 0, falhas = 0;
const confere = (nome, cond, info = '') => { if (cond) { ok++; console.log('OK   ' + nome); } else { falhas++; console.log('FALHA ' + nome + (info ? ': ' + info : '')); } };

let navegador;
for (const channel of ['msedge', 'chrome']) { try { navegador = await chromium.launch({ channel }); break; } catch { /* outro */ } }
if (!navegador) { console.log('FALHA nenhum navegador abriu'); console.log('=== pagina 0 ok, 1 falhas'); process.exit(1); }

for (const tela of [{ w: 360, h: 740 }, { w: 1280, h: 800 }]) {
  const n = s => `${tela.w}px: ${s}`;
  const pagina = await navegador.newPage({ viewport: { width: tela.w, height: tela.h } });
  await pagina.route('**/api/payloads', async rota => {
    const r = await rota.fetch();
    const j = await r.json();
    for (const it of j.itens || []) if (it.id === 'shadowkraken') it.conferido = true;
    await rota.fulfill({ response: r, json: j });
  });
  await pagina.goto(base + '/payloads');
  await pagina.waitForSelector('.vel .vel-aj input', { timeout: 20000 }).catch(() => null);
  await pagina.waitForFunction(() => document.querySelectorAll('.vel .vel-med').length > 2, null, { timeout: 10000 }).catch(() => null);
  const box = '.item[data-id="shadowkraken"] .vel';
  const txt = sel => pagina.$eval(sel, e => e.textContent).catch(() => '');
  confere(n('bloco visivel'), await pagina.isVisible(box));
  confere(n('estado: build e formato'), (await txt(box + ' .vel-estado')).includes('4db1b08') && (await txt(box + ' .vel-estado')).includes('zstd'), await txt(box + ' .vel-estado'));
  confere(n('explicacao do ajuste em portugues'), (await txt(box + ' .vel-ajustes')).includes('Cache de blocos prontos'));
  confere(n('ajuste de build futuro so com o nome'), (await txt(box + ' .vel-ajustes')).includes('knob_futuro'));
  confere(n('resumo'), (await txt(box + ' .vel-resumo')).includes('Acerto do cache'));
  confere(n('conjunto fixo'), (await txt(box + ' .vel-conj')).includes('Padrão 4db1b08'));
  // mudar um valor marca o campo e libera o Aplicar
  await pagina.fill(box + ' input[data-aj="spin_us"]', '42');
  confere(n('Aplicar liberado'), await pagina.isEnabled(box + ' .vel-aplicar'));
  const medidas = await pagina.evaluate(() => {
    const raiz = document.querySelector('.item[data-id="shadowkraken"] .vel');
    const larguras = [...raiz.querySelectorAll('.botoes')].filter(b => b.offsetParent).map(b =>
      [...b.querySelectorAll('button')].filter(x => x.offsetParent).map(x => Math.round(x.getBoundingClientRect().width)));
    const cortados = [...raiz.querySelectorAll('button, .linha, span, h4, h5, b, code')].filter(e => e.offsetParent &&
      (getComputedStyle(e).textOverflow === 'ellipsis' || e.scrollWidth > e.clientWidth + 1)).map(e => e.className + ':' + e.textContent.slice(0, 30));
    const fora = [...raiz.querySelectorAll('*')].filter(e => e.offsetParent && e.getBoundingClientRect().right > innerWidth + 1).map(e => e.className);
    return { larguras, cortados, fora, rola: document.scrollingElement.scrollWidth > innerWidth };
  });
  confere(n('sem rolar de lado'), !medidas.rola && !medidas.fora.length, medidas.fora.slice(0, 5).join(' | '));
  confere(n('botoes da mesma linha com a mesma largura'), medidas.larguras.every(x => x.every(y => Math.abs(y - x[0]) <= 1)), JSON.stringify(medidas.larguras));
  confere(n('nada cortado'), medidas.cortados.length === 0, medidas.cortados.slice(0, 5).join(' | '));
  if (fotos) {
    await pagina.$eval(box, e => e.scrollIntoView());
    await pagina.locator(box).screenshot({ path: path.join(fotos, `velocidade-ampr-${tela.w}.png`) });
  }
  await pagina.close();
}
await navegador.close();
console.log(`=== pagina ${ok} ok, ${falhas} falhas`);
process.exit(falhas ? 1 : 0);
