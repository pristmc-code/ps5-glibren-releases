#!/bin/bash
# Testa a bateria automatica (0.9.64) na versao de PC: ShadowKraken falso (testes/smp_falso.py, modo "varrer"), GitHub
# falso (testes/github_falso.py diag: plano + envio), ampr-emu-ng de depuracao falso na GLR_TESTE_AMPR_PORTA (o mesmo
# protocolo do teste_ampr_ajuste.sh, com roteiro de /metrics: rajada e depois calmo, nunca acalma, o jogo cai).
# Casos: plano recusado (formato e ensaio seco: pasta ativa fora do SK, discos diferentes, nas duas pastas, pasta fora da
# lista do glibren, copia repetida no SK, .sprx que falta), ponta a ponta (3 rodadas, so rename, mesmos inodes no fim,
# build e ajustes do ampr de volta, reabrir por ajuste "next launch", relatorio com medianas e sem caminhos/IP, envio),
# fechar pela reserva KillApp (controle virtual falha / nao fecha / sistema), queda (pula repeticoes; 2 seguidas param),
# nunca acalma, temperatura e espaco (para e desfaz), destino ocupado no meio, Parar, Pausar/Continuar, glibren morto
# com SIGKILL e reaberto (retoma), PS5 reiniciado (interrompida + desfaz + continua da rodada seguinte), journal sem OK
# e inode trocado no Desfazer, so celular/PC pareado, diagnostico e a pagina (360 e 1280 px).
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_bateria.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8961; PSMP=18961; PGH=8962; PAMPR=8963
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R="http://$IP:$PORTA"
T=/root/glr-bat; DADOS=$T/dados; A=$T/data/homebrew; V=$T/data/_versoes; O=$T/outro-disco; M=$T/montador
GH=$T/gh; SKC=$T/sk-config.ini
UA_PS5='Mozilla/5.0 (PlayStation; PlayStation 5/12.00) AppleWebKit/605.1.15 (KHTML, like Gecko)'
KJOBE="github_pat_11JOBE0000000000000000_abcdefghijklmnopqrstuvwxyz0123456789JOBEjobe1234"
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$(echo "$2" | head -c 900)] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
TOKEN=""
post() { curl -s -H 'X-GLR: 1' -H "X-GLR-Token: $TOKEN" "$@"; }
codigo() { curl -s -o /dev/null -w '%{http_code}' -H 'X-GLR: 1' "$@"; }
estado() { curl -s "$L/api/bateria"; }
acao() { post -X POST "$R/api/bateria/$1" ${2:+-d "$2"}; }
campo() { estado | python3 -I -c "import json,sys; d=json.load(sys.stdin); v=eval('d'+sys.argv[1]); print(json.dumps(v) if not isinstance(v,str) else v)" "$1"; }
espera_estado() {   # espera "estado" virar um dos valores (regex) por ate $2 s
  for i in $(seq 1 $(( ${2:-60} * 10 ))); do estado | grep -q "\"estado\":\"\($1\)\"" && return 0; sleep 0.1; done
  echo "AVISO: estado nao virou $1 (agora $(campo "['estado']") / $(campo "['passo']"))"; return 1; }
espera_fim() { for i in $(seq 1 $(( ${1:-60} * 10 ))); do estado | grep -q '"trabalhando":false' && return 0; sleep 0.1; done; echo "AVISO: a bateria nao terminou"; return 1; }
espera_passo() { for i in $(seq 1 $(( ${2:-60} * 10 ))); do estado | grep -q "\"passo\":\"$1\"" && return 0; sleep 0.1; done; echo "AVISO: passo $1 nao veio"; return 1; }
ino() { stat -c %i "$1" 2>/dev/null || echo "-"; }
linhas() { [ -f "$DADOS/bateria/resultados.jsonl" ] && grep -c . "$DADOS/bateria/resultados.jsonl" || echo 0; }

pkill -f "smp_falso.py $PSMP" 2>/dev/null; pkill -f "github_falso.py diag $PGH" 2>/dev/null; pkill -f "bat_ampr.py $PAMPR" 2>/dev/null
umount "$O" 2>/dev/null
rm -rf "$T"
mkdir -p "$DADOS" "$A" "$V" "$O" "$M/shadowmount" "$GH/conteudo/glibren" "$T/smp" "$T/jobe" "$T/dumps" "$DADOS/ampr-builds" "$T/data/BACKUP"
printf '%s\n' "$KJOBE" > "$T/jobe/token"
echo 45 > "$T/temp"; echo 100000 > "$T/livre"; : > "$T/abertos"; echo "calmo:6" > "$T/ampr.modo"
# jogos: DIRT 5 (pkg e exfat guardados), Horizon Chase 2 (exfat ativo, pkg guardado), "OUTRO" so no outro disco
head -c 300000 /dev/urandom > "$V/DIRT5.pkg"; head -c 200000 /dev/urandom > "$V/DIRT5.exfat"
head -c 150000 /dev/urandom > "$A/HC2.exfat"; head -c 160000 /dev/urandom > "$V/HC2.pkg"
# "outro disco": um tmpfs (st_dev diferente) para o teste de discos diferentes
OUTRO_DISCO=1; mount -t tmpfs -o size=8m tmpfs "$O" 2>/dev/null || OUTRO_DISCO=0
I_D5P=$(ino "$V/DIRT5.pkg"); I_D5E=$(ino "$V/DIRT5.exfat"); I_HCE=$(ino "$A/HC2.exfat"); I_HCP=$(ino "$V/HC2.pkg")
printf 'tune original\nspin_us=50\n' > "$M/ampr_emu_tune.txt"
# builds do ampr-emu-ng (o de depuracao tem o marcador do trace e o commit)
python3 -I - "$DADOS/ampr-builds" <<'EOF'
import sys
def grava(nome, corpo, tam=200000):
    d = b"\x7fELF" + b"\0" * 60 + corpo
    open(sys.argv[1] + "/" + nome, "wb").write(d + bytes((i * 7) % 251 for i in range(tam - len(d))))
grava("ampr-251124-0901-4d56acc-deb.sprx", b"ampr-emu-ng 0.6.0\0/data/ampr_emu_trace.txt\0plain-fs 4d56acc\0")
grava("ampr-251124-1551-4db1b08-rel.sprx", b"xx ampr-emu-ng 0.6.1\0")
EOF
printf '[general]\ndebug = off\n[api]\nport = 10101\nbind_address = 127.0.0.1\n[scan]\ndepth = 1\n' > "$SKC"
printf 'language = pt-BR\nfolder = %s/\nfolder = %s/\nfolder = %s/\nfolder = %s/\n' "$A" "$V" "$O" "$T/data/BACKUP" > "$DADOS/config.ini"
sk_estado() {   # $1 = jogos extras (JSON), $2 = scan_paths (JSON)
  python3 -I -c 'import json,sys; json.dump({"games":json.loads(sys.argv[1]),"images":[],"settings":{"scan_paths":json.loads(sys.argv[2])},
    "varrer":{"pastas":json.loads(sys.argv[2]),"titulos":{"DIRT5.pkg":"PPSA01552","DIRT5.exfat":"PPSA01552","HC2.exfat":"PPSA02000","HC2.pkg":"PPSA02000"},"atraso_s":0.2}},
    open(sys.argv[3],"w"))' "${1:-[]}" "${2:-[\"$A\"]}" "$T/smp/estado.json"; }
sk_estado

# ampr-emu-ng de depuracao falso: so responde com jogo aberto; $T/ampr.modo = calmo:N (N /metrics de rajada e depois
# calmo), nunca (rajada sempre), queda:N (rajada e na N+1a leitura o jogo "cai": sai dos abertos e um dump aparece)
cat > "$T/bat_ampr.py" <<'EOF'
import os, re, socket, sys, time, urllib.parse
porta, pasta = int(sys.argv[1]), sys.argv[2]
knobs = [["decoded_mib", 136, 0, 512, 0], ["lane_eop_overlap", 1, 0, 1, 1], ["spin_us", 100, 0, 200, 1]]
ses = {"chave": None, "n": 0, "bytes": 0}
def abertos():
    try: return open(pasta + "/abertos").read().split()
    except OSError: return []
def lista():
    return "knobs (/data/ampr_emu_tune.txt):\n" + "".join("%s=%d [%d..%d] %s\n" % (n, v, a, b, "live" if l else "next launch") for n, v, a, b, l in knobs)
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("127.0.0.1", porta)); s.listen(16)
while True:
    c, _ = s.accept(); c.settimeout(3)
    ab = abertos()
    if not ab:
        c.close(); continue
    try: chave = (tuple(ab), os.stat(pasta + "/abertos").st_mtime_ns)
    except OSError: chave = None
    if chave != ses["chave"]:   # jogo aberto de novo: sessao nova
        ses.update(chave=chave, n=0, bytes=0)
    try: req = c.recv(4096).decode()
    except Exception: req = ""
    linha = req.split("\r\n")[0]
    alvo = linha.split(" ")[1] if linha.count(" ") >= 2 else "/"
    u = urllib.parse.urlparse(alvo)
    modo = open(pasta + "/ampr.modo").read().strip()
    tipo, _, k = modo.partition(":"); k = int(k or 0)
    if u.path == "/metrics":
        ses["n"] += 1
        if tipo == "nunca" or ses["n"] <= k: ses["bytes"] += 40 * 1024 * 1024
        if tipo == "queda" and ses["n"] > k:
            open(pasta + "/abertos", "w").write("")
            os.makedirs(pasta + "/dumps/%s_%d" % (ab[0], int(time.time())), exist_ok=True)
        m = ses["n"]
        corpo = ("build ampr-emu-ng 0.6.0 4d56acc debug\npack_format pkg\napr_read_bytes %d\napr_reads %d\napr_read_ns %d\n"
                 "job_totals %d\njob_total_ns %d\ndecodes %d\ndecode_ns %d\ncache_hits %d\ncache_misses %d\npack_disk_bytes %d\npack_disk_reads %d\n"
                 % (ses["bytes"], 10 * m, 10 * m * 1000000, 100 * m, 100 * m * 2000000, 50 * m, 50 * m * 30000, 90 * m, 10 * m, ses["bytes"], 5 * m))
    elif u.path == "/set":
        corpo = ""
        for par in filter(None, u.query.split("&")):
            mm = re.fullmatch(r"([a-z_0-9]+)=(\d+)", par)
            kn = [x for x in knobs if mm and x[0] == mm.group(1)]
            if not kn: corpo += "error: bad pair '%s' (later pairs not applied)\n" % par; break
            kn[0][1] = int(mm.group(2))
        open(pasta + "/ampr.set", "a").write(u.query + "\n")
        corpo += lista()
    elif u.path == "/threads": corpo = "threads 12\n"
    elif u.path == "/fsfail": corpo = "fsfail 0\n"
    else: corpo = "not found\n"
    c.sendall(("HTTP/1.0 200 OK\r\nContent-Type: text/plain\r\n\r\n" + corpo).encode())
    c.close()
EOF
python3 -I "$ORIGEM/testes/smp_falso.py" $PSMP "$T/smp" > "$T/smp.log" 2>&1 & PID_SMP=$!
python3 -I "$ORIGEM/testes/github_falso.py" diag $PGH "$GH" > "$T/gh.log" 2>&1 & PID_GH=$!
python3 -I "$T/bat_ampr.py" $PAMPR "$T" > "$T/ampr.log" 2>&1 & PID_AMPR=$!

BOOT=1000; EXTRA="GLR_TESTE_PAD_FECHA=1"
inicia() {
  env GLR_TESTE_SMP_PORTA=$PSMP GLR_TESTE_SMP_CONFIG="$SKC" GLR_TESTE_GITHUB="http://127.0.0.1:$PGH" GLR_TESTE_JOBE_TOKEN="$T/jobe/token" \
    GLR_TESTE_MONTADOR="$M" GLR_TESTE_AMPR_PORTA=$PAMPR GLR_TESTE_AMOSTRA_MS=50 GLR_TESTE_ABERTOS="$T/abertos" GLR_TESTE_FPS=60 \
    GLR_TESTE_SEGUNDO_MS=30 GLR_TESTE_BAT_TEMP="$T/temp" GLR_TESTE_BAT_LIVRE_MIB="$T/livre" GLR_TESTE_BAT_ABRE=1 GLR_TESTE_BAT_BUSCA_S=0 \
    GLR_TESTE_PAD_LOG="$T/pad.log" GLR_TESTE_KILL_LOG="$T/kill.log" GLR_TESTE_BOOT=$BOOT GLR_TESTE_COREDUMPS="$T/dumps" \
    GLR_TESTE_SONDA_S=0 GLR_TESTE_GH="http://127.0.0.1:9" GLR_TESTE_BASE="http://127.0.0.1:9/" GLR_TESTE_SEM_REMOVIDOS=1 GLR_TESTE_FW=12.00 \
    $EXTRA "$BIN" -p $PORTA -d "$DADOS" >> "$T/glr.log" 2>&1 & PID=$!
  for i in $(seq 1 50); do curl -s -o /dev/null "$L/api/bateria" && break; sleep 0.1; done; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
mata() { kill -9 $PID 2>/dev/null; wait $PID 2>/dev/null; }
plano() {   # $1 = JSON do plano (com $A/$V ja trocados)
  printf '%s' "$1" > "$GH/conteudo/glibren/ampr-bateria.json"; }
inicia
curl -s -H 'X-GLR: 1' -X POST "$R/api/parear/pedir" > /dev/null
C=$(grep -o 'pareamento [0-9]\{6\}' "$T/glr.log" | tail -1 | awk '{print $2}')
TOKEN=$(curl -s -H 'X-GLR: 1' -d codigo=$C -d nome=Teste "$R/api/parear" | python3 -I -c 'import json,sys; print(json.load(sys.stdin)["token"])')
confere "pareado"                           "$TOKEN" "^[0-9a-f]\{64\}$"

echo "--- estado inicial e recusas de acesso"
confere "GET: parado, sem plano"            "$(estado)" '"ok":true,"estado":"parado"'
confere "GET: plano null"                   "$(estado)" '"plano":null'
confere "sem X-GLR = 403"                   "$(curl -s -o /dev/null -w '%{http_code}' -X POST $R/api/bateria/buscar)" "403"
confere "sem pareamento = 401"              "$(codigo -X POST $R/api/bateria/buscar)" "401"
confere "navegador do PS5 = so leitura"     "$(post -A "$UA_PS5" -X POST $R/api/bateria/buscar)" '"chave":"bat_so_celular"'
confere "do proprio PS5 (127.0.0.1) = so leitura" "$(post -X POST $L/api/bateria/iniciar)" '"chave":"bat_so_celular"'
confere "buscar sem plano publicado = 404"  "$(acao buscar)" '"chave":"bat_sem_plano"'
confere "iniciar sem plano"                 "$(acao iniciar)" '"chave":"bat_conferir"'

echo "--- plano recusado (formato)"
BASEJ='"jogos":{"PPSA01552":{"nome":"DIRT 5","ativa_pasta":"'$A'","versoes":{"pkg":"'$V'/DIRT5.pkg","exfat":"'$V'/DIRT5.exfat"}}}'
plano '{"versao_plano":1,"id":"ruim","padrao":{"repeticoes":9},'"$BASEJ"',"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"pkg"}]}'
confere "repeticoes 9 recusado"             "$(acao buscar)" 'repeticoes fora do limite (1 a 5)'
plano '{"versao_plano":1,"id":"ruim","jogos":{"PPSA01552":{"nome":"x","ativa_pasta":"'$A'","versoes":{"pkg":"'$V'/../x.pkg"}}},"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"pkg"}]}'
confere "caminho com .. recusado"           "$(acao buscar)" 'caminho da versao pkg invalido'
plano '{"versao_plano":1,"id":"ruim","jogos":{"PPSA01552":{"nome":"x","ativa_pasta":"/system/x","versoes":{"pkg":"'$V'/DIRT5.pkg"}}},"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"pkg"}]}'
confere "pasta do sistema recusada"         "$(acao buscar)" 'ativa_pasta ausente ou invalida'
plano '{"versao_plano":1,"id":"ruim",'"$BASEJ"',"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"zstd"}]}'
confere "versao fora da lista"              "$(acao buscar)" 'fora da lista de jogos'
plano '{"versao_plano":1,"id":"ruim",'"$BASEJ"',"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"pkg"},{"id":"r01","jogo":"PPSA01552","versao":"pkg"}]}'
confere "id repetido"                       "$(acao buscar)" 'rodada r01 repetida'
plano '{"versao_plano":1,"id":"ruim",'"$BASEJ"',"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"pkg","ajustes":{"Workers;x":1}}]}'
confere "ajustes fora do formato"           "$(acao buscar)" 'ajustes fora do formato'
plano '{"versao_plano":1,"id":"ruim",'"$BASEJ"',"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"pkg","ampr":"../x.sprx"}]}'
confere "ampr com caminho recusado"         "$(acao buscar)" 'ampr tem de ser'
plano '{"versao_plano":1,"id":"ruim","padrao":{"fechar_botoes":["ps","pulo"]},'"$BASEJ"',"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"pkg"}]}'
confere "botao desconhecido recusado"       "$(acao buscar)" 'fechar_botoes: botao desconhecido'
confere "plano ruim nao fica"               "$(estado)" '"plano":null'
nao_tem "nada foi movido (recusas)"         "$(ls $A)" "DIRT5"

echo "--- ensaio seco (Conferir)"
plano '{"versao_plano":1,"id":"c1",'"$BASEJ"',"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"pkg"}]}'
confere "buscar ok"                         "$(acao buscar)" '"plano":{"id":"c1"'
sk_estado '[]' '["'$T/outra'"]'
confere "ativa fora do ShadowKraken"        "$(acao conferir)" 'nao esta nas pastas do ShadowKraken'
sk_estado
if [ $OUTRO_DISCO = 1 ]; then
  head -c 1000 /dev/urandom > "$O/DIRT5.exfat"
  plano '{"versao_plano":1,"id":"c2","jogos":{"PPSA01552":{"nome":"DIRT 5","ativa_pasta":"'$A'","versoes":{"pkg":"'$V'/DIRT5.pkg","exfat":"'$O'/DIRT5.exfat"}}},"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"exfat"}]}'
  confere "buscar c2"                         "$(acao buscar)" '"plano":{"id":"c2"'
  confere "discos diferentes recusado"        "$(acao conferir)" 'discos diferentes'
  confere "outro disco intacto"               "$(stat -c %s $O/DIRT5.exfat)" "^1000$"
else
  echo "PULADO: discos diferentes (mount de tmpfs recusado)"
fi
cp "$V/DIRT5.pkg" "$A/DIRT5.pkg"
plano '{"versao_plano":1,"id":"c3",'"$BASEJ"',"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"pkg"}]}'
acao buscar > /dev/null
confere "nas duas pastas recusado"          "$(acao conferir)" 'existe na pasta guardada E na ativa'
mv "$A/DIRT5.pkg" "$T/copia-teste.pkg"
mkdir -p "$T/data/fora"; mv "$V/HC2.pkg" "$T/data/fora/HC2.pkg"
plano '{"versao_plano":1,"id":"c4","jogos":{"PPSA02000":{"nome":"HC2","ativa_pasta":"'$A'","versoes":{"exfat":"'$V'/HC2.exfat","pkg":"'$T'/data/fora/HC2.pkg"}}},"rodadas":[{"id":"r01","jogo":"PPSA02000","versao":"pkg"}]}'
acao buscar > /dev/null
confere "pasta fora da lista do glibren"    "$(acao conferir)" 'nao esta na lista de pastas do glibren'
mv "$T/data/fora/HC2.pkg" "$V/HC2.pkg"
sk_estado '[{"path":"'$T'/data/outra/DIRT5.pkg","title_id":"PPSA01552","source_type":"pkg","image_type":""}]'
plano '{"versao_plano":1,"id":"c5",'"$BASEJ"',"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"pkg"}]}'
acao buscar > /dev/null
confere "copia repetida no ShadowKraken"    "$(acao conferir)" 'outra copia do jogo fora do plano'
sk_estado
plano '{"versao_plano":1,"id":"c6",'"$BASEJ"',"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"pkg","ampr":"nao-tem.sprx"}]}'
acao buscar > /dev/null
confere ".sprx que falta recusado"          "$(acao conferir)" 'nao-tem.sprx nao existe'
confere "iniciar tambem confere"            "$(acao iniciar)" '"chave":"bat_conferir"'
confere "nada foi movido (ensaio)"          "$(ino $V/DIRT5.pkg) $(ino $V/DIRT5.exfat) $(ino $A/HC2.exfat) $(ino $V/HC2.pkg)" "^$I_D5P $I_D5E $I_HCE $I_HCP$"

echo "--- ponta a ponta: 3 rodadas (pkg com build -deb e ajustes, exfat padrao, compat do HC2 em .pkg)"
# sk_espera_s 150 (4,5 s de verdade com GLR_TESTE_SEGUNDO_MS=30): com 30 (0,9 s) o ShadowKraken falso as vezes nao
# relia a pasta a tempo com o PC carregado (publicacao da 0.9.66, 24/11/2026); so espera mais quando o jogo demora
PAD='"fechar_pad_espera_s":5,"fechar_espera_s":5,"desmontar_espera_s":5,"sk_espera_s":150,"janela_s":4,"amostra_s":1,"min_tela_s":1,"esfriar_s":0,"compat_s":10'
JOGOS='"jogos":{"PPSA01552":{"nome":"DIRT 5","ativa_pasta":"'$A'","versoes":{"pkg":"'$V'/DIRT5.pkg","exfat":"'$V'/DIRT5.exfat"}},"PPSA02000":{"nome":"Horizon Chase 2","ativa_pasta":"'$A'","versoes":{"exfat":"'$V'/HC2.exfat","pkg":"'$V'/HC2.pkg"}}}'
plano '{"versao_plano":1,"id":"p1","titulo":"beta 4d56acc no 192.168.0.77","padrao":{"carregar_max_s":60,"trecho_s":10,"repeticoes":2,'"$PAD"'},'"$JOGOS"',"rodadas":[
 {"id":"r01","jogo":"PPSA01552","versao":"pkg","ampr":"ampr-251124-0901-4d56acc-deb.sprx","ajustes":{"lane_eop_overlap":0,"decoded_mib":200}},
 {"id":"r02","jogo":"PPSA01552","versao":"exfat","ampr":"manter","ajustes":"padrao"},
 {"id":"r03","jogo":"PPSA02000","versao":"pkg","tipo":"compat","repeticoes":1}]}'
B=$(acao buscar)
confere "plano p1 buscado"                  "$B" '"plano":{"id":"p1","titulo":"beta 4d56acc no 192.168.0.77","rodadas":3,"repeticoes":5'
confere "estimativa"                        "$B" '"estimativa_s":[1-9]'
confere "conferir ok"                       "$(acao conferir)" '"conferencia_ok":true'
confere "conferencia: guardada e ativa"     "$(campo "['conferencia']")" 'HC2.exfat'
: > "$T/pad.log"
confere "iniciar"                           "$(acao iniciar)" '"estado":"rodando"'
confere "iniciar de novo = ocupado"         "$(acao iniciar)" '"chave":"bat_ocupado"'
espera_passo carregar 30 >/dev/null; confere "progresso: rodada 1 de 3"   "$(estado)" '"atual":{"rodada":1,"rodadas":3'
espera_estado concluida 120
E=$(estado)
confere "concluida"                         "$E" '"estado":"concluida"'
confere "5 repeticoes gravadas"             "$(linhas)" "^5$"
RES=$(cat $DADOS/bateria/resultados.jsonl)
confere "r01 rep1: ok, carregou"            "$(sed -n 1p <<<"$RES")" '"id":"r01".*"rep":1,"reps":2,"tipo":"desempenho","resultado":"ok","compat":"carregou","formato_sk":"pkg"'
confere "r01: build -deb no resultado"      "$(sed -n 1p <<<"$RES")" '"build":"build ampr-emu-ng 0.6.0 4d56acc debug"'
confere "r01 rep1: reaberto (next launch)"  "$(sed -n 1p <<<"$RES")" '"reaberto":1'
confere "r01 rep2: sem reabrir"             "$(sed -n 2p <<<"$RES")" '"rep":2,.*"reaberto":0'
confere "r01: trecho com leitura"           "$(sed -n 1p <<<"$RES")" '"trecho":{"x":0,"bloco_ms":[0-9.]*,"leitura_ms":'
confere "r01: medida gravada"               "$(sed -n 1p <<<"$RES")" '"medida":"20[0-9_-]*\.txt"'
confere "r01: fechado pelo controle virtual" "$(sed -n 1p <<<"$RES")" '"fechar":"pad"'
confere "r01: tempos de tela e menu"        "$(sed -n 1p <<<"$RES")" '"t_tela":[0-9.]*,"t_ampr":[0-9.]*,"t_carregado":[0-9.]*,"bytes_ate_menu":[0-9]'
confere "r02: exfat"                        "$(sed -n 3p <<<"$RES")" '"id":"r02".*"formato_sk":"image/exfat"'
confere "r02: ajustes padrao"               "$(sed -n 3p <<<"$RES")" '"ajustes":"padrao"'
confere "r03: compat carregou"              "$(sed -n 5p <<<"$RES")" '"id":"r03".*"tipo":"compat","resultado":"ok","compat":"carregou","formato_sk":"pkg"'
confere "ajustes aplicados pelo /set"       "$(cat $T/ampr.set)" "lane_eop_overlap=0&decoded_mib=200"
confere "medida com cabecalho da bateria"   "$(cat $DADOS/ampr-medidas/$(sed -n 1p <<<"$RES" | grep -o '"medida":"[^"]*"' | cut -d'"' -f4))" "^bateria: p1 r01 rep 1/2 versao=pkg ampr=ampr-251124-0901-4d56acc-deb.sprx"
confere "controle virtual: PS, Options, X"  "$(tr '\n' ' ' < $T/pad.log)" "botao ps 150 espera 1500 botao options 150 espera 1200 botao cruz 150 espera 1200 botao cruz 150 fechar"
confere "nenhum KillApp"                    "$(cat $T/kill.log 2>/dev/null | wc -l)" "^0$"
confere "desfeito: mesmos inodes nos lugares" "$(ino $V/DIRT5.pkg) $(ino $V/DIRT5.exfat) $(ino $A/HC2.exfat) $(ino $V/HC2.pkg)" "^$I_D5P $I_D5E $I_HCE $I_HCP$"
confere "desfeito: nada sobrou na ativa"    "$(ls $A | tr '\n' ' ')" "^HC2.exfat $"
confere "journal: guardado no historico"    "$(ls $DADOS/bateria/ | grep -c '^journal.txt\.[0-9]')" "^[1-9]"
confere "journal: so rename (MOVER/OK)"     "$(cat $DADOS/bateria/journal.txt.* | grep -c '^MOVER')" "^[1-9]"
confere "journal: tudo desfeito"            "$(cat $DADOS/bateria/journal.txt.* | grep -c '^DESFEITO') $(cat $DADOS/bateria/journal.txt.* | grep -c '^MOVER')" "^\([0-9]*\) \1$"
confere "sem journal pendente"              "$E" '"journal_pendente":0'
confere "ampr de volta ao embutido"         "$(ls $M/shadowmount/emus/ampr-emu-ng/ 2>&1)" "libSceAmpr.sprx.anterior"
nao_tem "ampr de teste saiu"                "$(ls $M/shadowmount/emus/ampr-emu-ng/ 2>&1 | grep -x libSceAmpr.sprx)" "libSceAmpr"
confere "ajustes do ampr de volta"          "$(cat $M/ampr_emu_tune.txt)" "tune original"
REL=$(cat "$DADOS/bateria/relatorio-p1.md")
confere "relatorio: titulo"                 "$REL" "^# ampr-emu-ng automated test battery"
confere "relatorio: kraken-mount"           "$REL" "a loader based on kraken-mount"
confere "relatorio: tabela de desempenho"   "$REL" "| DIRT 5 | pkg (pkg) | ampr-251124-0901-4d56acc-deb.sprx | lane_eop_overlap=0,decoded_mib=200 | [0-9.]* ([0-9.]*-[0-9.]*) |"
confere "relatorio: compatibilidade"        "$REL" "| Horizon Chase 2 | pkg | manter | pass | 1 ok"
confere "relatorio: build"                  "$REL" "build ampr-emu-ng 0.6.0 4d56acc debug"
nao_tem "relatorio: sem caminhos do PC"     "$REL" "/root/"
nao_tem "relatorio: sem IP"                 "$REL" "192.168.0.77"
nao_tem "resultado.json: sem IP"            "$(cat $DADOS/bateria/resultado-p1.json)" "192.168.0.77"
confere "enviado: resultado"                "$(cat $GH/recebido/glibren/ampr-bateria/p1/resultado.json 2>&1)" '"plano":"p1"'
confere "enviado: relatorio"                "$(cat $GH/recebido/glibren/ampr-bateria/p1/relatorio.md 2>&1)" "## Compatibility"
confere "enviado: medidas"                  "$(ls $GH/recebido/glibren/ampr-bateria/p1/medidas/ 2>&1 | wc -l)" "^[1-9]"
nao_tem "enviado sem a chave"               "$(cat $GH/recebido/glibren/ampr-bateria/p1/* 2>/dev/null)" "github_pat"
confere "GET: resultados curtos"            "$(estado)" '"resultados":\[{"rodada":1,"rep":1,"id":"r01","jogo":"PPSA01552","versao":"pkg","resultado":"ok","compat":"carregou","fechar":"pad"'
confere "diario: so rename"                 "$(grep -c 'bateria: movido (rename)' $DADOS/glibren.log)" "^[1-9]"

echo "--- fechar pela reserva: controle virtual nao criado -> KillApp"
PC1='"jogos":{"PPSA01552":{"nome":"DIRT 5","ativa_pasta":"'$A'","versoes":{"pkg":"'$V'/DIRT5.pkg","exfat":"'$V'/DIRT5.exfat"}}}'
plano '{"versao_plano":1,"id":"k1","padrao":{"carregar_max_s":60,"repeticoes":1,'"$PAD"'},'"$PC1"',"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"exfat","tipo":"compat"}]}'
para; EXTRA="GLR_TESTE_PAD=falha"; inicia
acao buscar > /dev/null; : > "$T/kill.log"
acao iniciar > /dev/null; espera_estado "concluida\|erro" 60
confere "pad falhou: KillApp"               "$(cat $DADOS/bateria/resultados.jsonl)" '"fechar":"kill"'
confere "KillApp so no titulo da bateria"   "$(cat $T/kill.log)" "^kill PPSA01552 sceLncUtilKillApp$"
confere "diario: motivo da reserva"         "$(cat $DADOS/glibren.log)" "controle virtual nao criado (open /dev/hid errno 13): reserva KillApp"
echo "--- reserva: o controle virtual nao fechou o jogo -> KillApp; e a do sistema"
para; EXTRA="GLR_TESTE_KILL=sys"; inicia
: > "$T/kill.log"; : > "$T/pad.log"
acao iniciar > /dev/null; espera_estado "concluida\|erro" 60
confere "pad apertou mas nao fechou"        "$(cat $T/pad.log)" "botao ps"
confere "fechou pela do sistema"            "$(cat $DADOS/bateria/resultados.jsonl)" '"fechar":"kill_sys"'
confere "log: sceSystemServiceKillApp"      "$(cat $T/kill.log)" "sceSystemServiceKillApp"
echo "--- fechar_metodo kill: nem tenta o controle virtual"
plano '{"versao_plano":1,"id":"k2","padrao":{"fechar_metodo":"kill","carregar_max_s":60,"repeticoes":1,'"$PAD"'},'"$PC1"',"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"pkg","tipo":"compat"}]}'
para; EXTRA="GLR_TESTE_PAD_FECHA=1"; inicia
acao buscar > /dev/null; : > "$T/pad.log"
acao iniciar > /dev/null; espera_estado "concluida\|erro" 60
confere "kill direto"                       "$(cat $DADOS/bateria/resultados.jsonl)" '"fechar":"kill"'
confere "sem controle virtual"              "$(cat $T/pad.log | wc -l)" "^0$"
echo "--- KillApp falha: travou, bateria para e desfaz"
para; EXTRA="GLR_TESTE_KILL=falha"; inicia
acao iniciar > /dev/null; espera_estado "concluida\|erro" 60
confere "travou"                            "$(cat $DADOS/bateria/resultados.jsonl)" '"resultado":"travou","compat":"travou"'
confere "erro: nao fechou"                  "$(estado)" '"estado":"erro".*nao fechou'
: > "$T/abertos"
confere "desfazer depois de fechar na mao"  "$(acao desfazer)" '"ok":true'
espera_fim 30
confere "inodes de volta"                   "$(ino $V/DIRT5.pkg) $(ino $V/DIRT5.exfat)" "^$I_D5P $I_D5E$"
para; EXTRA="GLR_TESTE_PAD_FECHA=1"; inicia

echo "--- queda: pula as repeticoes; 2 rodadas seguidas caindo param a bateria"
plano '{"versao_plano":1,"id":"q1","padrao":{"carregar_max_s":60,"trecho_s":10,"repeticoes":3,'"$PAD"'},'"$PC1"',"rodadas":[
 {"id":"r01","jogo":"PPSA01552","versao":"pkg"},{"id":"r02","jogo":"PPSA01552","versao":"exfat"},{"id":"r03","jogo":"PPSA01552","versao":"pkg"}]}'
acao buscar > /dev/null
echo "queda:3" > "$T/ampr.modo"
acao iniciar > /dev/null; espera_estado "concluida\|erro" 90
RES=$(cat $DADOS/bateria/resultados.jsonl)
confere "2 linhas (1 por rodada)"           "$(linhas)" "^2$"
confere "r01 caiu"                          "$(sed -n 1p <<<"$RES")" '"id":"r01".*"resultado":"queda","compat":"caiu"'
confere "r01: dump do CoreDump achado"      "$(sed -n 1p <<<"$RES")" '"dump":"PPSA01552_'
confere "parou depois de 2 quedas"          "$(estado)" '"estado":"erro".*"erro":"2 rodadas seguidas com o jogo caindo'
confere "r03 nao rodou"                     "$(grep -c '"id":"r03"' $DADOS/bateria/resultados.jsonl)" "^0$"
confere "relatorio: crash"                  "$(cat $DADOS/bateria/relatorio-q1.md)" "| crash |"
confere "desfeito depois da queda"          "$(ino $V/DIRT5.pkg) $(ino $V/DIRT5.exfat)" "^$I_D5P $I_D5E$"

echo "--- nunca acalma: nao_carregou e segue"
plano '{"versao_plano":1,"id":"n1","padrao":{"carregar_max_s":30,"trecho_s":10,"repeticoes":1,'"$PAD"'},'"$PC1"',"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"pkg"},{"id":"r02","jogo":"PPSA01552","versao":"exfat"}]}'
acao buscar > /dev/null
echo "nunca" > "$T/ampr.modo"
acao iniciar > /dev/null; espera_estado "concluida\|erro" 90
RES=$(cat $DADOS/bateria/resultados.jsonl)
confere "r01 nao estabilizou"               "$(sed -n 1p <<<"$RES")" '"resultado":"nao_carregou","compat":"abriu".*"carregou_por":"nao_estabilizou"'
confere "seguiu para a r02"                 "$(sed -n 2p <<<"$RES")" '"id":"r02"'
confere "concluida mesmo assim"             "$(estado)" '"estado":"concluida"'
confere "relatorio: did not settle"         "$(cat $DADOS/bateria/relatorio-n1.md)" "did not settle"
echo "calmo:6" > "$T/ampr.modo"

echo "--- temperatura e espaco: param e desfazem"
plano '{"versao_plano":1,"id":"t1","padrao":{"carregar_max_s":60,"trecho_s":400,"repeticoes":1,'"$PAD"'},'"$PC1"',"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"exfat"}]}'
acao buscar > /dev/null
acao iniciar > /dev/null; espera_passo trecho 30 >/dev/null
echo 90 > "$T/temp"
espera_estado "erro" 30
confere "parou pela temperatura"            "$(estado)" '"erro":"temperatura 90 C (limite 85 C): bateria parada"'
confere "jogo fechado"                      "$(cat $T/abertos | wc -w)" "^0$"
confere "desfeito (temperatura)"            "$(ino $V/DIRT5.exfat)" "^$I_D5E$"
echo 45 > "$T/temp"
acao iniciar > /dev/null; espera_passo trecho 30 >/dev/null
echo 100 > "$T/livre"
espera_estado "erro" 30
confere "parou pelo espaco"                 "$(estado)" '"erro":"espaco livre baixo (100 MiB'
echo 100000 > "$T/livre"
confere "desfeito (espaco)"                 "$(ino $V/DIRT5.exfat)" "^$I_D5E$"

echo "--- destino ocupado no meio: recusa (nunca sobrescreve), para e desfaz"
plano '{"versao_plano":1,"id":"d1","padrao":{"carregar_max_s":60,"trecho_s":200,"repeticoes":1,'"$PAD"'},'"$PC1"',"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"pkg"},{"id":"r02","jogo":"PPSA01552","versao":"exfat"}]}'
acao buscar > /dev/null
acao iniciar > /dev/null; espera_passo trecho 30 >/dev/null
echo "bloqueio" > "$A/DIRT5.exfat"
espera_estado "erro" 60
confere "recusou o destino ocupado"         "$(estado)" 'DIRT5.exfat existe na pasta guardada e na ativa'
confere "o bloqueio ficou intacto"          "$(cat $A/DIRT5.exfat)" "^bloqueio$"
confere "o .pkg voltou"                     "$(ino $V/DIRT5.pkg)" "^$I_D5P$"
confere "o .exfat guardado intacto"         "$(ino $V/DIRT5.exfat)" "^$I_D5E$"
mv "$A/DIRT5.exfat" "$T/bloqueio.txt"

echo "--- Parar e desfazer no meio do trecho"
acao iniciar > /dev/null; espera_passo trecho 30 >/dev/null
confere "parar"                             "$(acao parar)" '"estado":"parando"'
espera_estado "parado\|erro" 60
confere "parada pelo dono"                  "$(estado)" '"estado":"parado".*"erro":"parada pelo dono"'
confere "jogo fechado (parar)"              "$(cat $T/abertos | wc -w)" "^0$"
confere "desfeito (parar)"                  "$(ino $V/DIRT5.pkg) $(ino $V/DIRT5.exfat)" "^$I_D5P $I_D5E$"
confere "trecho do ampr cancelado"          "$(ls $DADOS/ampr-trecho-inicio.txt 2>&1)" "No such file"

echo "--- Pausar e Continuar"
plano '{"versao_plano":1,"id":"pa1","padrao":{"carregar_max_s":60,"trecho_s":10,"repeticoes":2,'"$PAD"'},'"$PC1"',"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"pkg"}]}'
acao buscar > /dev/null
acao iniciar > /dev/null
confere "pausar"                            "$(acao pausar)" '"estado":"pausando"'
espera_estado pausado 60
confere "pausada depois de 1 repeticao"     "$(linhas)" "^1$"
confere "versao fica na ativa (pausada)"    "$(ls $A)" "DIRT5.pkg"
confere "buscar recusado (pausada)"         "$(acao buscar)" '"chave":"bat_ocupado"'
confere "continuar"                         "$(acao continuar)" '"ok":true'
espera_estado concluida 60
confere "2 repeticoes no fim"               "$(linhas)" "^2$"
confere "desfeito (pausa)"                  "$(ino $V/DIRT5.pkg)" "^$I_D5P$"

echo "--- glibren morto (SIGKILL) no trecho e reaberto: retoma e refaz a repeticao"
plano '{"versao_plano":1,"id":"s1","padrao":{"carregar_max_s":60,"trecho_s":100,"repeticoes":1,'"$PAD"'},'"$PC1"',"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"exfat"}]}'
acao buscar > /dev/null
acao iniciar > /dev/null; espera_passo trecho 30 >/dev/null; sleep 0.5
mata
confere "estado gravado: trecho"            "$(cat $DADOS/bateria/estado.json)" '"estado":"rodando","passo":"trecho"'
confere "journal pendente gravado"          "$(grep -c '^OK' $DADOS/bateria/journal.txt)" "^[1-9]"
inicia
espera_estado concluida 60
confere "retomou e concluiu"                "$(estado)" '"estado":"concluida"'
confere "diario: retomando"                 "$(cat $DADOS/glibren.log)" "glibren reaberto no meio da bateria"
confere "1 repeticao (refeita)"             "$(linhas)" "^1$"
confere "fechou o jogo que sobrou"          "$(tail -40 $DADOS/glibren.log | grep -c 'PPSA01552 fechado pelo controle virtual')" "^[2-9]"
confere "desfeito (retomada)"               "$(ino $V/DIRT5.exfat)" "^$I_D5E$"

echo "--- PS5 reiniciado no meio: interrompida, desfaz, Iniciar continua da rodada seguinte"
plano '{"versao_plano":1,"id":"b1","padrao":{"carregar_max_s":60,"trecho_s":100,"repeticoes":1,'"$PAD"'},'"$PC1"',"rodadas":[{"id":"r01","jogo":"PPSA01552","versao":"pkg"},{"id":"r02","jogo":"PPSA01552","versao":"exfat"}]}'
acao buscar > /dev/null
acao iniciar > /dev/null; espera_passo trecho 30 >/dev/null; sleep 0.5
mata; : > "$T/abertos"
BOOT=5000; inicia
espera_fim 30
E=$(estado)
confere "interrompida"                      "$E" '"estado":"interrompida"'
confere "erro diz o reinicio"               "$E" 'interrompida: o PS5 reiniciou no passo trecho da rodada 1'
confere "queda_reinicio registrada"         "$(cat $DADOS/bateria/resultados.jsonl)" '"id":"r01".*"resultado":"queda_reinicio","compat":"travou"'
confere "desfeito (reinicio)"               "$(ino $V/DIRT5.pkg)" "^$I_D5P$"
confere "continua da rodada 2"              "$(acao iniciar)" 'iniciando na rodada 2 de 2'
espera_estado concluida 60
confere "r02 rodou depois"                  "$(cat $DADOS/bateria/resultados.jsonl)" '"id":"r02".*"resultado":"ok"'
confere "resultados mantidos (2 linhas)"    "$(linhas)" "^2$"

echo "--- Desfazer: journal sem OK e inode trocado"
mv "$V/HC2.pkg" "$A/HC2.pkg"
S=$(stat -c '%d %i %s' "$A/HC2.pkg")
printf 'MOVER 900 dev=%s ino=%s tam=%s\t%s\t%s\n' $(echo $S | awk '{print $1, $2, $3}') "$V/HC2.pkg" "$A/HC2.pkg" > "$DADOS/bateria/journal.txt"
confere "journal pendente visto"            "$(estado)" '"journal_pendente":1'
confere "iniciar recusado (journal)"        "$(acao iniciar)" '"chave":"bat_journal"'
confere "desfazer (sem OK)"                 "$(acao desfazer)" '"ok":true'
espera_fim 30
confere "voltou (sem OK)"                   "$(ino $V/HC2.pkg)" "^$I_HCP$"
mv "$V/HC2.pkg" "$A/HC2.pkg"
S=$(stat -c '%d %i %s' "$A/HC2.pkg")
printf 'MOVER 901 dev=%s ino=%s tam=%s\t%s\t%s\nOK 901\n' $(echo $S | awk '{print $1, $2, $3}') "$V/HC2.pkg" "$A/HC2.pkg" > "$DADOS/bateria/journal.txt"
mv "$A/HC2.pkg" "$T/HC2-guardado.pkg"; echo "outro arquivo" > "$A/HC2.pkg"
acao desfazer > /dev/null; espera_fim 30
E=$(estado)
confere "inode trocado: recusa"             "$E" '"estado":"erro"'
confere "lista para resolver na mao"        "$E" '"problemas":"HC2.pkg nao esta mais em'
confere "nada mexido (inode trocado)"       "$(cat $A/HC2.pkg) $(ls $V | grep -c HC2.pkg)" "^outro arquivo 0$"
mv "$A/HC2.pkg" "$T/outro.txt"; mv "$T/HC2-guardado.pkg" "$A/HC2.pkg"
acao desfazer > /dev/null; espera_fim 30
confere "resolvido e desfeito"              "$(ino $V/HC2.pkg) $(estado | grep -o '"journal_pendente":[0-9]*')" "^$I_HCP \"journal_pendente\":0$"

echo "--- diagnostico"
echo "teste-pad: ok (handle 3)" > "$M/teste-pad.log"
curl -s -o "$T/d.zip" "$L/api/diagnostico/zip"
ZL=$(python3 -I -c 'import sys,zipfile; z=zipfile.ZipFile(sys.argv[1]); print("\n".join(z.namelist()))' "$T/d.zip" 2>&1)
confere "zip: bateria.json"                 "$ZL" "/bateria.json$"
confere "zip: resultados"                   "$ZL" "/bateria-resultados.jsonl$"
confere "zip: plano"                        "$ZL" "/bateria-plano.json$"
confere "zip: teste-pad.log"                "$ZL" "/teste-pad.log$"
confere "payloads: teste-pad e websrv"      "$(curl -s $L/api/payloads | grep -o '"id":"\(teste-pad\|websrv\)"' | tr '\n' ' ')" '"id":"teste-pad" "id":"websrv"'
nao_tem "nada apagado: arquivos dos jogos"  "$(ls $V $A | tr '\n' ' ')" "^$"
confere "todos os jogos inteiros"           "$(ino $V/DIRT5.pkg) $(ino $V/DIRT5.exfat) $(ino $A/HC2.exfat) $(ino $V/HC2.pkg)" "^$I_D5P $I_D5E $I_HCE $I_HCP$"

echo "--- pagina (360 e 1280 px), se houver Edge/Chrome no Windows"
NODE_WIN="/mnt/c/Program Files/nodejs/node.exe"
LAD=$(cmd.exe /c 'echo %LOCALAPPDATA%' 2>/dev/null | tr -d '\r')
PW=""; [ -n "$LAD" ] && PW=$(ls -d "$(wslpath "$LAD")"/npm-cache/_npx/*/node_modules/playwright 2>/dev/null | head -1)
if [ -x "$NODE_WIN" ] && [ -n "$PW" ]; then
  SAIDA=$("$NODE_WIN" "$(wslpath -w "$ORIGEM/testes/teste_bateria_pagina.mjs")" "http://127.0.0.1:$PORTA" "$(wslpath -w "$PW")" ${GLR_FOTOS:-} 2>&1)
  echo "$SAIDA"
  ok=$((ok + $(echo "$SAIDA" | grep -c '^OK '))); falhas=$((falhas + $(echo "$SAIDA" | grep -c '^FALHA')))
  echo "$SAIDA" | grep -q '^=== pagina' || { falhas=$((falhas+1)); echo "FALHA pagina: o script nao terminou"; }
else
  echo "PULADO: teste da pagina (sem node.exe ou Playwright no Windows)"
fi

para
kill $PID_SMP $PID_GH $PID_AMPR 2>/dev/null; wait $PID_SMP $PID_GH $PID_AMPR 2>/dev/null
umount "$O" 2>/dev/null
rm -rf "$T"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
