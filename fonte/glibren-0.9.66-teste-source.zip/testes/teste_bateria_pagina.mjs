// 0.9.64: pagina Payloads - bloco "Bateria automatica" no cartao do ShadowKraken, em 360 e 1280 px: andando (barra,
// "rodada N de M", passo, resultados, conferencia, problemas), botoes da mesma linha com a mesma largura, nada cortado,
// sem rolar de lado; no navegador do PS5 so leitura (sem botoes). /api/payloads real com o ShadowKraken marcado como
// instalado e /api/bateria simulado (page.route). Chamado pelo testes/teste_bateria.sh.
//   node teste_bateria_pagina.mjs http://127.0.0.1:8961 <pasta do pacote playwright> [pasta das fotos]
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const [base, pw, fotos] = process.argv.slice(2);
const { chromium } = await import(pathToFileURL(path.join(pw, 'index.mjs')).href);
let ok = 0, falhas = 0;
const confere = (nome, cond, info = '') => { if (cond) { ok++; console.log('OK   ' + nome); } else { falhas++; console.log('FALHA ' + nome + (info ? ': ' + info : '')); } };

let navegador;
for (const channel of ['msedge', 'chrome']) { try { navegador = await chromium.launch({ channel }); break; } catch { /* outro */ } }
if (!navegador) { console.log('FALHA nenhum navegador abriu'); console.log('=== pagina 0 ok, 1 falhas'); process.exit(1); }

const agora = Math.floor(Date.now() / 1000);
const BAT = { ok: true, estado: 'rodando', passo: 'carregar', desde: agora - 47, agora, msg: 'esperando PPSA01552 chegar ao menu (ate 240 s)',
  erro: '', problemas: '', envio: '', relatorio: '', journal_pendente: 0, trabalhando: true, plano_ok: true, plano_erro: '', buscado: agora - 600,
  conferencia: ['ShadowKraken: 1 pasta(s) vigiada(s), profundidade 1', 'PPSA01552 DIRT 5: versao pkg guardada (/data/homebrew/_versoes/DIRT5_um_nome_de_arquivo_bem_comprido_para_quebrar_linha.pkg)',
    'Plano 2026-11-24-a: 12 rodada(s), cerca de 190 min no total'], conferencia_ok: true,
  plano: { id: '2026-11-24-a', titulo: 'beta 4db1b08 x 4d56acc, formatos (pkg, exfat, zstd) no SSD interno', rodadas: 12, repeticoes: 36, estimativa_s: 11400, jogos: 3 },
  atual: { rodada: 2, rodadas: 12, rep: 3, reps: 3, id: 'r02', jogo: 'PPSA01552', nome: 'DIRT 5', versao: 'exfat', ampr: 'ampr-251124-0901-4d56acc-deb.sprx', t_tela: 12.5, t_carregado: null, carregar: 'vivo, 9090 no ar' },
  resultados: [
    { rodada: 1, rep: 1, id: 'r01', jogo: 'PPSA01552', versao: 'pkg', resultado: 'ok', compat: 'carregou', fechar: 'pad', medida: '2026-11-24_020101.txt', t_carregado: 38.2 },
    { rodada: 1, rep: 2, id: 'r01', jogo: 'PPSA01552', versao: 'pkg', resultado: 'queda', compat: 'caiu', fechar: 'caiu', medida: '', t_carregado: null },
    { rodada: 2, rep: 1, id: 'r02', jogo: 'PPSA01552', versao: 'exfat', resultado: 'ok', compat: 'carregou', fechar: 'kill', medida: '2026-11-24_021501.txt', t_carregado: 41.0 }],
  resultados_total: 4 };

for (const [ua, nomeUa] of [['', 'celular'], ['Mozilla/5.0 (PlayStation; PlayStation 5/12.00) AppleWebKit/605.1.15 (KHTML, like Gecko)', 'PS5']]) {
  for (const tela of [{ w: 360, h: 740 }, { w: 1280, h: 800 }]) {
    if (nomeUa === 'PS5' && tela.w === 360) continue;
    const n = s => `${tela.w}px ${nomeUa}: ${s}`;
    const ctx = await navegador.newContext({ viewport: { width: tela.w, height: tela.h }, ...(ua ? { userAgent: ua } : {}) });
    const pagina = await ctx.newPage();
    await pagina.route('**/api/payloads', async rota => {
      const r = await rota.fetch();
      const j = await r.json();
      for (const it of j.itens || []) if (it.id === 'shadowkraken') it.conferido = true;
      await rota.fulfill({ response: r, json: j });
    });
    await pagina.route('**/api/bateria', rota => rota.fulfill({ contentType: 'application/json', body: JSON.stringify(BAT) }));
    await pagina.goto(base + '/payloads');
    const box = '.item[data-id="shadowkraken"] .bat';
    await pagina.waitForFunction(s => { const e = document.querySelector(s + ' .bat-passo'); return e && !e.hidden && e.textContent.length > 10; }, box, { timeout: 20000 }).catch(() => {});
    const txt = sel => pagina.$eval(sel, e => e.textContent).catch(() => '');
    confere(n('bloco visivel'), await pagina.isVisible(box));
    confere(n('titulo'), (await txt(box + ' h3')).includes('Bateria automática'));
    confere(n('plano'), (await txt(box + ' .bat-plano')).includes('Plano 2026-11-24-a') && (await txt(box + ' .bat-plano')).includes('190 min'), await txt(box + ' .bat-plano'));
    confere(n('progresso rodada 2 de 12'), /Rodada 2 de 12 · repetição 3 de 3 · DIRT 5 \(exfat\)/.test(await txt(box + ' .bat-passo')), await txt(box + ' .bat-passo'));
    confere(n('passo: chegar ao menu'), (await txt(box + ' .bat-passo')).includes('Esperando chegar ao menu'), await txt(box + ' .bat-passo'));
    confere(n('barra visivel'), await pagina.isVisible(box + ' .bat-barra'));
    confere(n('resultados (mais novo primeiro)'), /^Rodada 2 \(r02\)/.test(await pagina.$eval(box + ' .bat-res .linha', e => e.textContent).catch(() => '')));
    confere(n('resultado: fechado a forca'), (await txt(box + ' .bat-res')).includes('fechado à força (KillApp)'));
    confere(n('resultado: queda'), (await txt(box + ' .bat-res')).includes('o jogo caiu'));
    confere(n('conferencia'), (await txt(box + ' .bat-conf')).includes('Conferência:'));
    if (nomeUa === 'PS5') {
      confere(n('so leitura: sem botoes'), (await pagina.$$(box + ' button')).length === 0);
      confere(n('so leitura: aviso'), (await txt(box)).includes('só é comandada pelo celular ou PC pareado'));
    } else {
      confere(n('Iniciar desligado (andando)'), await pagina.isDisabled(box + ' [data-bat="iniciar"]'));
      confere(n('Pausar ligado'), await pagina.isEnabled(box + ' [data-bat="pausar"]'));
      confere(n('Parar ligado'), await pagina.isEnabled(box + ' [data-bat="parar"]'));
      confere(n('Buscar desligado (andando)'), await pagina.isDisabled(box + ' [data-bat="buscar"]'));
    }
    const medidas = await pagina.evaluate(() => {
      const raiz = document.querySelector('.item[data-id="shadowkraken"] .bat');
      const larguras = [...raiz.querySelectorAll('.botoes')].filter(b => b.offsetParent).map(b =>
        [...b.querySelectorAll('button')].filter(x => x.offsetParent).map(x => Math.round(x.getBoundingClientRect().width)));
      const cortados = [...raiz.querySelectorAll('button, .linha, span, h3, h5, b')].filter(e => e.offsetParent &&
        (getComputedStyle(e).textOverflow === 'ellipsis' || e.scrollWidth > e.clientWidth + 1)).map(e => e.className + ':' + e.textContent.slice(0, 30));
      const fora = [...raiz.querySelectorAll('*')].filter(e => e.offsetParent && e.getBoundingClientRect().right > innerWidth + 1).map(e => e.className);
      const reticencias = /…|\.\.\./.test(raiz.textContent);
      return { larguras, cortados, fora, reticencias, rola: document.scrollingElement.scrollWidth > innerWidth };
    });
    confere(n('sem rolar de lado'), !medidas.rola && !medidas.fora.length, medidas.fora.slice(0, 5).join(' | '));
    confere(n('botoes da mesma linha com a mesma largura'), medidas.larguras.every(x => x.every(y => Math.abs(y - x[0]) <= 1)), JSON.stringify(medidas.larguras));
    confere(n('nada cortado'), medidas.cortados.length === 0, medidas.cortados.slice(0, 5).join(' | '));
    confere(n('sem reticencias'), !medidas.reticencias);
    if (fotos) {
      await pagina.$eval(box, e => e.scrollIntoView());
      await pagina.locator(box).screenshot({ path: path.join(fotos, `bateria-${nomeUa}-${tela.w}.png`) });
    }
    await ctx.close();
  }
}
// pausada: o botao vira Continuar
{
  const ctx = await navegador.newContext({ viewport: { width: 360, height: 740 } });
  const pagina = await ctx.newPage();
  await pagina.route('**/api/payloads', async rota => { const r = await rota.fetch(); const j = await r.json(); for (const it of j.itens || []) if (it.id === 'shadowkraken') it.conferido = true; await rota.fulfill({ response: r, json: j }); });
  await pagina.route('**/api/bateria', rota => rota.fulfill({ contentType: 'application/json', body: JSON.stringify({ ...BAT, estado: 'pausado', trabalhando: false }) }));
  await pagina.goto(base + '/payloads');
  const b = '.item[data-id="shadowkraken"] .bat .bat-pausa';
  await pagina.waitForFunction(s => document.querySelector(s)?.textContent === 'Continuar', b, { timeout: 20000 }).catch(() => {});
  confere('pausada: botao Continuar', (await pagina.$eval(b, e => e.textContent).catch(() => '')) === 'Continuar');
  confere('pausada: Iniciar desligado', await pagina.isDisabled('.item[data-id="shadowkraken"] .bat [data-bat="iniciar"]'));
  await ctx.close();
}
await navegador.close();
console.log(`=== pagina ${ok} ok, ${falhas} falhas`);
process.exit(falhas ? 1 : 0);
