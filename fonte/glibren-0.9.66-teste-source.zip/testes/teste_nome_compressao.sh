#!/bin/bash
# 0.9.65: nome novo mantem -zstd/-lz4 (funcoes puras do web/index.html).
exec node "$(dirname "$0")/teste_nome_compressao.mjs"
