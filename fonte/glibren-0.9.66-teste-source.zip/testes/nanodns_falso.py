"""Servidor DNS de mentira para o teste do editor do nanoDNS (teste_nanodns.sh): responde toda pergunta com um
registro A fixo, como o nanoDNS faz com uma regra (0.0.0.0 = bloqueando) ou um DNS comum (outro IPv4).
  python3 -I nanodns_falso.py <porta> <ipv4>
"""
import socket
import sys

porta, ip = int(sys.argv[1]), sys.argv[2]
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.bind(("127.0.0.1", porta))
endereco = bytes(int(x) for x in ip.split("."))
while True:
    d, de = s.recvfrom(512)
    if len(d) < 12:
        continue
    fim = 12
    while fim < len(d) and d[fim]:
        fim += 1 + d[fim]
    pergunta = d[12:fim + 5]
    cab = d[:2] + b"\x81\x80" + b"\x00\x01\x00\x01\x00\x00\x00\x00"
    resp = b"\xc0\x0c\x00\x01\x00\x01\x00\x00\x00\x3c\x00\x04" + endereco
    s.sendto(cab + pergunta + resp, de)
