// 0.9.65: o nome novo mantem a marca -zstd/-lz4 do nome atual e, se faltar espaco, encurta o titulo (nunca tira a
// marca). Le as funcoes puras do web/index.html (sem navegador).  node testes/teste_nome_compressao.mjs
import { readFileSync } from 'node:fs';
const html = readFileSync(new URL('../web/index.html', import.meta.url), 'utf8');
const pega = re => { const m = html.match(re); if (!m) throw new Error('nao achei ' + re); return m[0]; };
const fonte = [
  pega(/const semExtensao = [^\n]*\n/),
  pega(/const RE_COMPRESSAO = [^\n]*\n/),
  pega(/function marcaCompressao\(nome\) \{[\s\S]*?\n\}\n/),
  pega(/function encurtarNome\(base, max\) \{[\s\S]*?\n\}\n/),
].join('');
const { marcaCompressao, encurtarNome } = new Function(fonte + 'return { marcaCompressao, encurtarNome };')();
let ok = 0, falhas = 0;
const confere = (nome, obtido, esperado) => {
  if (obtido === esperado) { ok++; console.log('OK   ' + nome); }
  else { falhas++; console.log(`FALHA ${nome}: ${JSON.stringify(obtido)} != ${JSON.stringify(esperado)}`); }
};
confere('marca zstd', marcaCompressao('Horizon_Chase_2-PPSA12771-US-PS5-zstd.exfat'), '-zstd');
confere('marca LZ4 maiuscula', marcaCompressao('Jogo-PPSA00001-EU-PS5_LZ4.exfat'), '-lz4');
confere('marca no meio', marcaCompressao('Jogo-zstd-PPSA00001.exfat'), '-zstd');
confere('sem marca', marcaCompressao('Horizon_Chase_2-PPSA12771-US-PS5.exfat'), '');
confere('palavra parecida nao conta', marcaCompressao('Zstdlike_Game-PPSA00001.exfat'), '');
confere('nome do caso real', 'Horizon_Chase_2-PPSA12771-US-PS5' + marcaCompressao('Horizon_Chase_2-PPSA12771-US-PS5-zstd.exfat') + '.exfat',
  'Horizon_Chase_2-PPSA12771-US-PS5-zstd.exfat');
const longo = 'The_Very_Long_Game_Title_With_Many_Words_And_More_Words-PPSA12345-US-PS5-zstd';
const curto = encurtarNome(longo, 58);
confere('encurtado cabe em 58', curto.length <= 58, true);
confere('encurtado mantem -zstd', curto.endsWith('-PPSA12345-US-PS5-zstd'), true);
confere('encurtado corta o titulo', curto.startsWith('The_Very_Long'), true);
confere('sem marca continua igual', encurtarNome('The_Very_Long_Game_Title_With_Many_Words_And_More_Words-PPSA12345-US-PS5', 58).endsWith('-PPSA12345-US-PS5'), true);
console.log(`=== nome compressao ${ok} ok, ${falhas} falhas`);
process.exit(falhas ? 1 : 0);
