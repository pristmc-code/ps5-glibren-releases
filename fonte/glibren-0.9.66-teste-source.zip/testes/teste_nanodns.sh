#!/bin/bash
# Testa a 0.9.66 na versao de PC: editor do nanodns.ini do nanoDNS (src/nanodns.c) - leitura, analise como o nanoDNS
# (erros nao gravam; enderecos da Sony liberados so com confirmo=1), gravacao atomica com .bak, sonda em 127.0.0.1
# (servidor DNS de mentira testes/nanodns_falso.py), pareamento e o nanoDNS na pagina Payloads.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_nanodns.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8862; PDNS=8863
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R="http://$IP:$PORTA"
T=/root/glr-nanodns; DADOS=$T/dados; A=$T/lista
INI=$DADOS/nanodns/nanodns.ini
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
codigo() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
grava() { post --data-urlencode "texto@$1" "${@:2}" $L/api/nanodns; }
inicia() { env GLR_TESTE_NANODNS_PORTA=$PDNS "$@" "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1; }
para() { kill $PID 2>/dev/null; wait $PID 2>/dev/null; }
dns() { [ -n "${DPID:-}" ] && kill $DPID 2>/dev/null; wait ${DPID:-0} 2>/dev/null; DPID=""; [ -n "$1" ] && { python3 -I "$ORIGEM/testes/nanodns_falso.py" $PDNS "$1" & DPID=$!; sleep 0.5; }; }
campo() { curl -s $L/api/nanodns | python3 -c "import json,sys; print(json.dumps(json.load(sys.stdin)$1))"; }
rm -rf "$T"; mkdir -p "$DADOS" "$A"
printf 'language = pt-BR\nfolder = %s/\n' "$A" > "$DADOS/config.ini"
trap 'para; dns ""' EXIT

echo "--- leitura sem arquivo (o nanoDNS cria o padrao: a analise e a do padrao)"
inicia
C=$(curl -s $L/api/nanodns)
confere "ok"                               "$C" '"ok":true'
confere "nao existe"                       "$C" '"existe":false'
confere "padrao vem junto"                 "$(campo "['padrao']")" 'playstation.com=0.0.0.0'
confere "padrao: 8 regras, 6 excecoes"     "$C" '"regras":8,"excecoes":6'
confere "padrao: 3 servidores"             "$(campo "['servidores']")" '\["1.1.1.1", "8.8.8.8", "77.88.8.8"\]'
confere "padrao: nenhum risco"             "$(campo "['riscos']")" '^\[\]$'
confere "padrao: capas bloqueadas"         "$C" '"image_api":false'
confere "parado"                           "$C" '"rodando":false'
confere "sonda: sem resposta"              "$C" '"sonda":"sem_resposta"'
para

echo "--- sonda e processo"
dns 0.0.0.0
inicia GLR_TESTE_PROCESSOS="nanodns.elf"
C=$(curl -s $L/api/nanodns)
confere "rodando pelo processo"            "$C" '"rodando":true'
confere "sonda: bloqueando (0.0.0.0)"      "$C" '"sonda":"bloqueando"'
para
dns 1.2.3.4
inicia
confere "sonda: respondeu (outro IPv4)"    "$(curl -s $L/api/nanodns)" '"sonda":"respondeu"'
dns ""

echo "--- protecao"
printf '[upstream]\nserver=9.9.9.9\n' > $T/t0.ini
confere "sem X-GLR: 403"                   "$(codigo --data-urlencode "texto@$T/t0.ini" $L/api/nanodns)" "403"
confere "rede sem pareamento: 401"         "$(codigo -H 'X-GLR: 1' --data-urlencode "texto@$T/t0.ini" $R/api/nanodns)" "401"
confere "vazio recusado"                   "$(post -d texto= $L/api/nanodns)" "nanodns_vazio"
confere "nada gravado ate aqui"            "$(ls $DADOS/nanodns 2>&1)" "No such\|^$"

echo "--- gravar o padrao (cria a pasta, sem .bak)"
curl -s $L/api/nanodns | python3 -c "import json,sys; sys.stdout.write(json.load(sys.stdin)['padrao'])" > $T/padrao.ini
G=$(grava $T/padrao.ini)
confere "gravou"                           "$G" '"gravado":true'
confere "arquivo igual ao padrao"          "$(cmp $INI $T/padrao.ini && echo igual)" "igual"
confere "sem .bak na 1a vez"               "$(ls $DADOS/nanodns)" "^nanodns.ini$"
confere "agora existe"                     "$(curl -s $L/api/nanodns)" '"existe":true'
confere "diario: gravado"                  "$(cat $DADOS/glibren.log)" "nanodns: nanodns.ini gravado"

echo "--- liberar so as capas da Sony (sem risco) + .bak"
{ cat $T/padrao.ini; printf 'image.api.playstation.com\n'; } > $T/capas.ini
G=$(grava $T/capas.ini)
confere "gravou sem confirmar"             "$G" '"gravado":true'
confere "capas liberadas"                  "$G" '"image_api":true'
confere ".bak = versao anterior"           "$(cmp $DADOS/nanodns/nanodns.ini.bak $T/padrao.ini && echo igual)" "igual"
confere "tem_backup"                       "$G" '"tem_backup":true'
nao_tem "sem .tmp sobrando"                "$(ls -a $DADOS/nanodns)" "\.tmp"

echo "--- erros: nada gravado"
cp $INI $T/antes.ini
erro() { printf "$2" > $T/e.ini; local G; G=$(grava $T/e.ini); confere "$1" "$G" "$3"; confere "$1: arquivo intacto" "$(cmp $INI $T/antes.ini && echo igual)" "igual"; }
erro "servidor nao IPv4"                   '[upstream]\nserver=dns.google\n' '"chave":"servidor_invalido","valor":"dns.google"'
erro "servidor no proprio PS5"             '[upstream]\nserver=127.0.0.1\n' 'servidor_local'
erro "servidor 0.0.0.0"                    '[upstream]\nserver=0.0.0.0\n' 'servidor_local'
erro "9 servidores"                        '[upstream]\nserver=1.1.1.1\nserver=1.1.1.2\nserver=1.1.1.3\nserver=1.1.1.4\nserver=1.1.1.5\nserver=1.1.1.6\nserver=1.1.1.7\nserver=1.1.1.8\nserver=1.1.1.9\n' '"linha":10,"chave":"servidores_demais"'
erro "IPv4 de regra invalido"              '[overrides]\n*.playstation.com=0.0.0\n' 'ip_invalido'
erro "timeout_ms negativo"                 '[upstream]\ntimeout_ms=-5\n' 'valor_invalido'
erro "debug nao inteiro"                   '[general]\ndebug=sim\n' 'valor_invalido'
erro "bind invalido"                       '[general]\nbind=localhost\n' 'bind_invalido'
python3 -c "print('[overrides]'); print('a'*520+'=0.0.0.0')" > $T/e.ini
confere "linha longa"                      "$(grava $T/e.ini)" 'linha_longa'
python3 -c "print('[exceptions]'); [print('x%d.example.com' % i) for i in range(4000)]" > $T/e.ini
confere "texto acima de 32 KB"             "$(grava $T/e.ini)" 'nanodns_grande'
confere "arquivo intacto no fim"           "$(cmp $INI $T/antes.ini && echo igual)" "igual"

echo "--- riscos: so grava confirmando"
printf '[upstream]\nserver=9.9.9.9\n' > $T/r.ini
G=$(grava $T/r.ini)
confere "sem [overrides]: risco"           "$G" 'nanodns_risco'
confere "riscos listados"                  "$G" 'fus01.ps5.update.playstation.net'
confere "aviso sem regras"                 "$G" 'sem_regras'
confere "nao gravou"                       "$(cmp $INI $T/antes.ini && echo igual)" "igual"
G=$(grava $T/r.ini -d confirmo=1)
confere "confirmado: gravou"               "$G" '"gravado":true'
confere "diario: liberados confirmado"     "$(cat $DADOS/glibren.log)" "com enderecos da Sony liberados (confirmado)"
{ cat $T/padrao.ini; printf '*.playstation.net\n'; } > $T/r.ini
G=$(grava $T/r.ini)
confere "excecao larga: risco"             "$G" 'nanodns_risco'
confere "excecao larga: atualizacao"       "$G" 'fus01.ps5.update.playstation.net'
nao_tem "excecao larga: telemetria (.com) fica bloqueada" "$(echo "$G" | python3 -c "import json,sys; print(json.load(sys.stdin)['riscos'])")" "telemetry"

echo "--- leitura como o nanoDNS"
printf '[OVERRIDES]\n*.PlayStation.COM.=0.0.0.0 ; maiusculas e ponto\n*.playstation.net=0.0.0.0\n*.psndl.net=0.0.0.0\npsndl.net=0.0.0.0\n[upstream]\nserver=9.9.9.9 # comentario\n[exceptions]\nIMAGE.API.playstation.com\n' > $T/m.ini
G=$(grava $T/m.ini)
confere "maiusculas/comentarios: sem risco" "$G" '"gravado":true'
confere "excecao em maiusculas vale"       "$G" '"image_api":true'
confere "servidor sem o comentario"        "$G" '"servidores":\["9.9.9.9"\]'
printf '[general]\nquiet=1\n[outra]\nx=1\n[upstream]\nfoo=2\n[overrides]\n*.playstation.com=0.0.0.0\n*.playstation.net=0.0.0.0\npsndl.net=0.0.0.0\n' > $T/m.ini
G=$(grava $T/m.ini)
confere "avisos nao impedem"               "$G" '"gravado":true'
confere "aviso secao desconhecida"         "$G" '"chave":"secao_desconhecida","valor":"outra"'
confere "aviso chave desconhecida"         "$G" '"chave":"chave_desconhecida","valor":"foo"'
printf '[overrides]\n*.playstation.com=0.0.0.0\r\n*.playstation.net=0.0.0.0\r\npsndl.net=0.0.0.0\r\n' > $T/m.ini
grava $T/m.ini > /dev/null
nao_tem "CRLF vira LF"                     "$(cat -A $INI)" '\^M'

echo "--- arquivo que nao e comum"
rm -f $INI; ln -s /etc/hostname $INI
confere "link: ilegivel na leitura"        "$(curl -s $L/api/nanodns)" '"ilegivel":true'
confere "link: recusado"                   "$(grava $T/padrao.ini)" 'nanodns_ilegivel'
rm -f $INI

echo "--- pagina Payloads"
confere "pagina tem o editor"              "$(curl -s $L/payloads)" 'ndAbrir'
confere "botao incluir/remover capas"      "$(curl -s $L/payloads)" 'function ndCapas'
para

echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
