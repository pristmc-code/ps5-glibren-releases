#!/bin/bash
# Teste do leitor PFS/PFSC (src/fmt_pfs.c) com imagens REAIS geradas pelo MkPFS.
# Rodar no WSL/Linux, na raiz do payload:  bash testes/fmt_pfs/teste_pfs.sh
# Precisa: clang-18 e o MkPFS (variavel MKPFS; padrao /root/venv-mkpfs/bin/mkpfs - instalar com
#   python3 -m venv /root/venv-mkpfs && /root/venv-mkpfs/bin/pip install mkpfs).
set -u
cd "$(dirname "$0")/../.."
MKPFS=${MKPFS:-/root/venv-mkpfs/bin/mkpfs}
T=${TRAB:-$(mktemp -d /tmp/teste_pfs.XXXXXX)}
echo "pasta de trabalho: $T"
FALHAS=0
OKS=0

ok() { OKS=$((OKS + 1)); echo "  ok   $*"; }
falha() { FALHAS=$((FALHAS + 1)); echo "  FALHA $*"; }

# ---------------------------------------------------------------- compila (ASan + UBSan)
clang-18 -Wall -Werror -g -O1 -fsanitize=address,undefined -fno-sanitize-recover=undefined -Isrc \
  src/fmt_pfs.c src/imagem.c testes/fmt_pfs/teste_pfs.c -o "$T/teste_pfs" || { echo "nao compilou"; exit 1; }
TP="$T/teste_pfs"
export ASAN_OPTIONS=detect_leaks=1:abort_on_error=0

# ---------------------------------------------------------------- arvore de jogo de teste
J="$T/jogo"
rm -rf "$J"; mkdir -p "$J"
python3 - "$J" <<'EOF'
import os, random, sys, json
r = random.Random(1234)
j = sys.argv[1]
def w(p, d):
    p = os.path.join(j, p); os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, "wb").write(d)
w("sce_sys/param.json", json.dumps({"titleId": "PPSA01234", "contentId": "UP0000-PPSA01234_00-TESTE0000000000",
  "localizedParameters": {"defaultLanguage": "en-US", "en-US": {"titleName": "Jogo de Teste"},
  "pt-BR": {"titleName": "Jogo de Teste BR"}}}, indent=2).encode())
# icone: cabecalho PNG + metade compressivel, metade aleatoria (~210 KB, varios blocos)
w("sce_sys/icon0.png", b"\x89PNG\r\n\x1a\n" + bytes(i % 7 for i in range(100000)) + r.randbytes(110000))
w("eboot.bin", b"".join(b"linha %08d do executavel de teste\n" % i for i in range(90000)))  # ~3 MB compressivel
w("dados/aleatorio.bin", r.randbytes(150001))
# o MkPFS so comprime arquivos >= 64 KiB que nao sejam executavel/imagem: estes viram PFSC dentro do PFS
w("dados/texto_grande.dat", b"".join(b"registro %07d valor %d\n" % (i, i * 7 % 1000) for i in range(80000)))
w("dados/misto.dat", b"".join((bytes(70000) if k % 2 else r.randbytes(70000)) for k in range(6)))  # blocos crus e zlib
w("a/b/c/d/profundo.txt", b"arquivo bem fundo\n")
w("Maiusculas.TXT", b"nome com maiusculas\n")
w("vazio.txt", b"")
for i in range(2500):   # diretorio com muitos blocos (entradas cruzam o limite de 64 KiB)
    w("muitos/arquivo_com_nome_comprido_para_encher_o_diretorio_%05d.txt" % i, b"conteudo %d\n" % i)
EOF
echo "arvore criada: $(find "$J" -type f | wc -l) arquivos"

# ---------------------------------------------------------------- funcoes de conferencia
# confere_ler IMG CAMINHO ARQUIVO_ORIGINAL   (pfs_ler deve devolver 0 e o conteudo igual)
confere_ler() {
  local img=$1 cam=$2 orig=$3 saida="$T/saida.bin" res
  rm -f "$saida"
  res=$("$TP" ler "$img" "$cam" "$saida" 400000000 2>&1)
  if [[ "$res" == ret=0* ]] && cmp -s "$saida" "$orig"; then ok "$(basename "$img"): $cam ($res)"
  else falha "$(basename "$img"): $cam -> $res"; fi
}
# espera_ret IMG CAMINHO RET [MAX]
espera_ret() {
  local res
  res=$("$TP" ler "$1" "$2" "$T/saida.bin" ${4:-} 2>&1)
  if [[ "$res" == "ret=$3 "* ]]; then ok "$(basename "$1"): $2 -> ret=$3"
  else falha "$(basename "$1"): $2 esperava ret=$3, veio: $res"; fi
}
confere_imagem() {   # todos os arquivos da arvore
  local img=$1
  confere_ler "$img" sce_sys/param.json "$J/sce_sys/param.json"
  confere_ler "$img" sce_sys/icon0.png "$J/sce_sys/icon0.png"
  confere_ler "$img" eboot.bin "$J/eboot.bin"
  confere_ler "$img" dados/aleatorio.bin "$J/dados/aleatorio.bin"
  confere_ler "$img" dados/texto_grande.dat "$J/dados/texto_grande.dat"
  confere_ler "$img" dados/misto.dat "$J/dados/misto.dat"
  confere_ler "$img" a/b/c/d/profundo.txt "$J/a/b/c/d/profundo.txt"
  confere_ler "$img" /a//b/c/d/profundo.txt "$J/a/b/c/d/profundo.txt"
  confere_ler "$img" vazio.txt "$J/vazio.txt"
  confere_ler "$img" Maiusculas.TXT "$J/Maiusculas.TXT"
  confere_ler "$img" muitos/arquivo_com_nome_comprido_para_encher_o_diretorio_00000.txt \
    "$J/muitos/arquivo_com_nome_comprido_para_encher_o_diretorio_00000.txt"
  confere_ler "$img" muitos/arquivo_com_nome_comprido_para_encher_o_diretorio_01234.txt \
    "$J/muitos/arquivo_com_nome_comprido_para_encher_o_diretorio_01234.txt"
  confere_ler "$img" muitos/arquivo_com_nome_comprido_para_encher_o_diretorio_02499.txt \
    "$J/muitos/arquivo_com_nome_comprido_para_encher_o_diretorio_02499.txt"
  espera_ret "$img" sce_sys/nao_existe.json -2
  espera_ret "$img" pasta_nao_existe/param.json -2
  espera_ret "$img" sce_sys -2                 # pasta, nao arquivo
  espera_ret "$img" sce_sys/param.json/x -2    # arquivo usado como pasta
  espera_ret "$img" "" -2
  espera_ret "$img" sce_sys/icon0.png -3 1000  # maior que o limite
}

MK() { "$MKPFS" "$@" >"$T/mkpfs.log" 2>&1 || { echo "mkpfs falhou: $*"; tail -5 "$T/mkpfs.log"; return 1; }; }

# ---------------------------------------------------------------- .ffpfs (varias variantes)
echo "== .ffpfs PS5 sem compressao (D32)"
MK pack folder --raw --no-compress --version PS5 --inode-bits 32 --case-sensitive "$J" "$T/a.ffpfs" && {
  confere_imagem "$T/a.ffpfs"
  espera_ret "$T/a.ffpfs" maiusculas.txt -2   # case-sensitive
}

echo "== .ffpfs PS5 com arquivos comprimidos (flag 0x1 -> PFSC dentro do PFS), case-insensitive"
MK pack folder --raw --version PS5 --inode-bits 32 "$J" "$T/b.ffpfs" && {
  n=$(grep -c -a PFSC "$T/b.ffpfs")
  [ "$n" -ge 2 ] && ok "b.ffpfs tem arquivos comprimidos (PFSC)" || falha "b.ffpfs sem arquivos comprimidos"
  confere_imagem "$T/b.ffpfs"
  confere_ler "$T/b.ffpfs" maiusculas.txt "$J/Maiusculas.TXT"
  confere_ler "$T/b.ffpfs" SCE_SYS/PARAM.JSON "$J/sce_sys/param.json"
}

echo "== .ffpfs PS4 (versao 1)"
MK pack folder --raw --no-compress --version PS4 "$J" "$T/c.ffpfs" && confere_imagem "$T/c.ffpfs"

echo "== .ffpfs bloco de 16 KiB, comprimido"
MK pack folder --raw --block-size 16384 "$J" "$T/d.ffpfs" && confere_imagem "$T/d.ffpfs"

echo "== .ffpfs assinado S32 (inodes de 0x2C8, blocos por registros com assinatura)"
MK pack folder --raw --no-compress --signed --inode-bits 32 --no-verify-structure "$J" "$T/e.ffpfs" && confere_imagem "$T/e.ffpfs"

echo "== .ffpfs assinado S64 (inodes de 0x310)"
MK pack folder --raw --signed --inode-bits 64 --no-verify-structure "$J" "$T/f.ffpfs" && confere_imagem "$T/f.ffpfs"

echo "== .ffpfs nao assinado com bit de inode 64 (o MkPFS grava D32 mesmo assim)"
MK pack folder --raw --no-compress --inode-bits 64 "$J" "$T/g.ffpfs" && confere_imagem "$T/g.ffpfs"

# Assinado: bloco k > 12 + 1820 (64 KiB / 36) usa os dois niveis de ib[1] -> arquivo de ~130 MB.
# (O MkPFS 1.1.0 nao gera assinado com bloco < 64 KiB: falha na propria validacao.)
echo "== .ffpfs assinado S32 com arquivo de 130 MB (ib[0] e os dois niveis de ib[1])"
J2="$T/jogo2"; rm -rf "$J2"; mkdir -p "$J2/sce_sys"
cp "$J/sce_sys/param.json" "$J2/sce_sys/"
python3 - "$J2/grande.bin" <<'EOF'
import sys
with open(sys.argv[1], "wb") as f:   # cada bloco de 64 KiB com o proprio numero: detecta bloco trocado
    for k in range(2080):
        f.write((b"bloco %08d " % k) * 4096)
EOF
MK pack folder --raw --no-compress --signed --no-verify-structure "$J2" "$T/h.ffpfs" && {
  confere_ler "$T/h.ffpfs" grande.bin "$J2/grande.bin"
  confere_ler "$T/h.ffpfs" sce_sys/param.json "$J2/sce_sys/param.json"
}
rm -rf "$J2"

# ---------------------------------------------------------------- .ffpfsc
echo "== .ffpfsc com pfs_image.dat (fluxo de duas passadas do README do MkPFS)"
MK pack folder --raw --no-compress --no-adjust-output-file-extension "$J" "$T/pfs_image.dat" &&
MK pack file "$T/pfs_image.dat" "$T/x.ffpfsc" && {
  res=$("$TP" interno "$T/x.ffpfsc" "$T/interno.bin")
  if [[ "$res" == "ret=0 "*"nome=pfs_image.dat leitura=0" ]] && cmp -s "$T/interno.bin" "$T/pfs_image.dat"; then
    ok "x.ffpfsc: imagem interna identica ($res)"; else falha "x.ffpfsc: $res"; fi
  res=$("$TP" interno_ler "$T/x.ffpfsc" sce_sys/param.json "$T/saida.bin")
  if [[ "$res" == ret=0* ]] && cmp -s "$T/saida.bin" "$J/sce_sys/param.json"; then ok "x.ffpfsc: param.json via interno ($res)"
  else falha "x.ffpfsc interno_ler: $res"; fi
  res=$("$TP" interno_ler "$T/x.ffpfsc" eboot.bin "$T/saida.bin")
  if [[ "$res" == ret=0* ]] && cmp -s "$T/saida.bin" "$J/eboot.bin"; then ok "x.ffpfsc: eboot.bin via interno ($res)"
  else falha "x.ffpfsc interno_ler eboot: $res"; fi
  # pfs_ler direto no .ffpfsc tambem funciona (e um PFS): o arquivo comprimido sai inflado
  confere_ler "$T/x.ffpfsc" pfs_image.dat "$T/pfs_image.dat"
}

echo "== .ffpfsc com .ffpfs comprimido dentro (PFSC dentro de PFSC)"
cp "$T/b.ffpfs" "$T/JOGO.ffpfs" && MK pack file "$T/JOGO.ffpfs" "$T/y.ffpfsc" && {
  res=$("$TP" interno "$T/y.ffpfsc" "$T/interno.bin")
  if [[ "$res" == "ret=0 "*"nome=JOGO.ffpfs leitura=0" ]] && cmp -s "$T/interno.bin" "$T/JOGO.ffpfs"; then
    ok "y.ffpfsc: imagem interna identica ($res)"; else falha "y.ffpfsc: $res"; fi
  res=$("$TP" interno_ler "$T/y.ffpfsc" sce_sys/icon0.png "$T/saida.bin")
  if [[ "$res" == ret=0* ]] && cmp -s "$T/saida.bin" "$J/sce_sys/icon0.png"; then ok "y.ffpfsc: icon0.png via interno ($res)"
  else falha "y.ffpfsc interno_ler: $res"; fi
}

echo "== .ffpfsc com .exfat dentro (exFAT gerado pelo MkPFS)"
MK pack exfat "$J" "$T/PPSA01234.exfat" && MK pack file "$T/PPSA01234.exfat" "$T/z.ffpfsc" && {
  res=$("$TP" interno "$T/z.ffpfsc" "$T/interno.bin")
  if [[ "$res" == "ret=0 "*"nome=PPSA01234.exfat leitura=0" ]] && cmp -s "$T/interno.bin" "$T/PPSA01234.exfat"; then
    ok "z.ffpfsc: imagem exFAT interna identica, sha256 $(sha256sum < "$T/interno.bin" | cut -c1-16)"
  else falha "z.ffpfsc: $res"; fi
}

echo "== .ffpfsc com .exfat do mkfs.exfat (imagem quase toda zeros: muitos blocos comprimidos)"
if command -v mkfs.exfat >/dev/null; then
  truncate -s 64M "$T/vazia.exfat" && mkfs.exfat "$T/vazia.exfat" >/dev/null 2>&1 &&
  MK pack file "$T/vazia.exfat" "$T/w.ffpfsc" && {
    res=$("$TP" interno "$T/w.ffpfsc" "$T/interno.bin")
    if [[ "$res" == "ret=0 "*"nome=vazia.exfat leitura=0" ]] && cmp -s "$T/interno.bin" "$T/vazia.exfat"; then
      ok "w.ffpfsc: identica ($(stat -c %s "$T/w.ffpfsc") bytes -> $(stat -c %s "$T/vazia.exfat"))"
    else falha "w.ffpfsc: $res"; fi
  }
fi

echo "== .ffpfsc em uma passada (pack folder padrao: exFAT embrulhado)"
MK pack folder "$J" "$T/k.ffpfsc" && {
  res=$("$TP" interno "$T/k.ffpfsc" "$T/interno.bin")
  if [[ "$res" == "ret=0 "*".exfat leitura=0" ]] && [ "$(dd if="$T/interno.bin" bs=1 skip=3 count=8 2>/dev/null)" = "EXFAT   " ]; then
    ok "k.ffpfsc: interna comeca com assinatura exFAT ($res)"; else falha "k.ffpfsc: $res"; fi
}

# ---------------------------------------------------------------- casos de erro
echo "== erros"
head -c 3000000 /dev/urandom > "$T/lixo.bin"
espera_ret "$T/lixo.bin" sce_sys/param.json -1
head -c 100 "$T/a.ffpfs" > "$T/curto.bin"
espera_ret "$T/curto.bin" sce_sys/param.json -1
res=$("$TP" interno "$T/lixo.bin" "$T/i.bin"); [[ "$res" == ret=-1* ]] && ok "ffpfsc_abrir em lixo -> -1" || falha "ffpfsc lixo: $res"
res=$("$TP" interno "$T/a.ffpfs" "$T/i.bin"); [[ "$res" == ret=-2* ]] && ok "ffpfsc_abrir em .ffpfs sem imagem interna -> -2" || falha "ffpfsc sem interna: $res"
if MK pack folder --raw --no-compress --encrypted "$J" "$T/cifrado.ffpfs"; then
  espera_ret "$T/cifrado.ffpfs" sce_sys/param.json -1
fi
# truncado: cabecalho e inodes inteiros, dados faltando
head -c $((256 * 1024)) "$T/a.ffpfs" > "$T/truncado.ffpfs"
espera_ret "$T/truncado.ffpfs" eboot.bin -3
head -c $(( $(stat -c %s "$T/y.ffpfsc") * 6 / 10 )) "$T/y.ffpfsc" > "$T/truncado.ffpfsc"
res=$("$TP" interno "$T/truncado.ffpfsc" "$T/i.bin"); [[ "$res" == ret=-3* || "$res" == *leitura=-1 ]] && ok "ffpfsc truncado -> erro ($res)" || falha "ffpfsc truncado: $res"
# bloco PFSC corrompido (zlib estragado) dentro do .ffpfs comprimido
python3 - "$T/b.ffpfs" "$T/corr.ffpfs" <<'EOF'
import sys
d = bytearray(open(sys.argv[1], "rb").read())
i = d.find(b"PFSC")
while i >= 0:   # estraga os dados comprimidos de todo conteiner PFSC (pula cabecalho e tabela)
    t = int.from_bytes(d[i + 0x18:i + 0x20], "little"); dados = int.from_bytes(d[i + 0x20:i + 0x28], "little")
    a = int.from_bytes(d[i + t:i + t + 8], "little")
    for k in range(i + a + 2, i + a + 200): d[k] ^= 0x5A
    i = d.find(b"PFSC", i + 4)
open(sys.argv[2], "wb").write(d)
EOF
espera_ret "$T/corr.ffpfs" dados/texto_grande.dat -3

# fuzz: bytes aleatorios estragados no cabecalho, inodes e diretorios; so nao pode travar nem dar erro de memoria
echo "== fuzz (300 imagens estragadas, ASan/UBSan)"
python3 - "$T" <<'EOF'
import random, sys, os
t = sys.argv[1]
r = random.Random(99)
srcs = [open(os.path.join(t, n), "rb").read()[:1 << 21] for n in ("a.ffpfs", "b.ffpfs", "e.ffpfs", "x.ffpfsc")]
for k in range(300):
    d = bytearray(r.choice(srcs))
    for _ in range(r.randint(1, 20)):
        zona = r.choice([(0, 0x400), (0x10000, 0x10000 + 0x4000), (0, len(d))])
        p = r.randrange(zona[0], min(zona[1], len(d)))
        d[p] = r.randrange(256)
    open(os.path.join(t, "fuzz_%03d.bin" % k), "wb").write(d)
EOF
FUZZ_RUIM=0
for f in "$T"/fuzz_*.bin; do
  for c in "ler $f sce_sys/param.json $T/s.bin" "ler $f muitos/arquivo_com_nome_comprido_para_encher_o_diretorio_02000.txt $T/s.bin" \
           "ler $f eboot.bin $T/s.bin" "interno $f $T/s.bin"; do
    out=$(timeout 20 $TP $c 2>&1); rc=$?
    if [ $rc -ne 0 ] || [[ "$out" == *ERROR* || "$out" == *runtime\ error* ]]; then
      FUZZ_RUIM=$((FUZZ_RUIM + 1)); echo "  fuzz: $c -> rc=$rc"; echo "$out" | head -5
    fi
  done
done
[ $FUZZ_RUIM -eq 0 ] && ok "fuzz: 1200 execucoes sem travar nem erro de memoria" || falha "fuzz: $FUZZ_RUIM problemas"
rm -f "$T"/fuzz_*.bin

echo
echo "RESULTADO: $OKS ok, $FALHAS falhas"
[ -z "${TRAB:-}" ] && [ $FALHAS -eq 0 ] && rm -rf "$T"
[ $FALHAS -eq 0 ]
