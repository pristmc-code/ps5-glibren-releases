/* Game Library Renamer (payload PS5) - downloads HTTPS (base de titulos, paginas dos sites e icones).
   No PS5 usa as bibliotecas do proprio console (sceHttp2); no PC (teste) usa o curl. */
#pragma once

#include "util.h"

void https_iniciar(void);
/* So os sites que o app usa (lista fixa). */
int url_permitida(const char *url);
/* Libera mais um host (sem a porta) - servidores de teste de internet da lista do speedtest.net. */
void https_permitir_host(const char *host);
/* GET; o corpo vai para "saida" (ate max bytes). Devolve o status HTTP ou -1 (sem conexao).
   segundos: tempo maximo (por enquanto so no PC; no PS5 vale o padrao da sceHttp2). */
int https_get(const char *url, buf_t *saida, size_t max, int segundos);

/* Para o teste de internet: GET (corpo NULL) entregando os dados aos poucos para "recebeu" (sem guardar), ou POST
   do corpo inteiro. "recebeu" devolve 0 para continuar ou 1 para parar. Pode rodar em varias threads ao mesmo tempo.
   Devolve o status HTTP ou -1. No POST, *enviados recebe quantos bytes foram enviados. */
typedef int (*https_recebeu_t)(size_t n, void *ctx);
int https_fluxo(const char *url, const void *corpo, size_t tam_corpo, https_recebeu_t recebeu, void *ctx);
