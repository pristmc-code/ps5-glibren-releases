/* Game Library Renamer (payload PS5) - confere a assinatura Ed25519 das atualizacoes (TweetNaCl, dominio publico). */
#include "assinatura.h"

#include <stdint.h>
#include <stdlib.h>
#include <string.h>

/* TweetNaCl e codigo de terceiros: compila sem os avisos do nosso -Werror. */
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Weverything"
#include "terceiros/tweetnacl.c"
#pragma clang diagnostic pop

#include "chave_publica.h"

/* So para gerar chaves (nunca usado aqui: o payload apenas confere assinaturas). */
void randombytes(u8 *x, u64 n) {
  memset(x, 0, n);
}

int assinatura_valida(const void *dados, size_t n, const unsigned char assinatura[64]) {
  /* crypto_sign_open espera assinatura + mensagem juntas */
  u8 *sm = malloc(n + 64), *m = malloc(n + 64);
  int ok = 0;
  if(sm && m) {
    memcpy(sm, assinatura, 64);
    memcpy(sm + 64, dados, n);
    u64 mlen = 0;
    ok = crypto_sign_open(m, &mlen, sm, n + 64, CHAVE_PUBLICA) == 0 && mlen == n;
  }
  free(sm);
  free(m);
  return ok;
}
