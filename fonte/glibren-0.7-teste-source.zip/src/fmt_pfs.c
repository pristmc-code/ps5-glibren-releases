/* Game Library Renamer (payload PS5) - leitor PFS (.ffpfs) e PFSC (.ffpfsc), so leitura. Ver imagem.h.

PFS (PlayStation File System), tudo little-endian:
  Cabecalho (bloco 0, sempre em claro):
    0x00 version u64 (1 = PS4, 2 = PS5)   0x08 magic u64 = 20130315
    0x1C mode u16: 0x1 assinado, 0x2 inode 64 bits (so muda algo no assinado), 0x4 cifrado (XTS-AES: nao da para
         ler sem chave -> IMG_FORMATO), 0x8 nomes sem diferenca de maiusculas
    0x20 block_size u32 (64 KiB; o MkPFS aceita outros: aqui 4..64 KiB)
    0x30 quantidade de inodes u64   0x38 ndblock u64 (blocos da imagem)   0x40 blocos da tabela de inodes u64
    0x50 inode "S64" que descreve a tabela de inodes; os ib[] (0x2B8 + i*40) que nao sao 0 sao blocos de assinatura
         que vem antes da tabela (o LibOrbisPkg faz: tabela comeca no bloco 1 + quantos ib > 0).
  Inodes: contiguos a partir desse bloco, sem cruzar blocos (bs / tamanho_do_inode por bloco).
    Comum: +0 mode u16 (0x4000 dir, 0x8000 arquivo)  +4 flags u32 (0x1 comprimido)  +0x08 size u64
           +0x10 size_compressed u64  +0x60 blocks u32.
    ATENCAO, nomes invertidos: no arquivo comprimido "size" e o tamanho ARMAZENADO (o conteiner PFSC) e
    "size_compressed" e o tamanho LOGICO (descompactado). Sem compressao os dois sao iguais.
    D32 (0xA8, imagem nao assinada, mesmo com o bit 0x2 - e o que o MkPFS grava): db[12] i32 em 0x64, ib[5] em 0x94.
      Dados contiguos: db[0] e o primeiro bloco e db[1..] = -1 (o super-root tem db[1..] = 0 com 1 bloco).
    S32 (0x2C8, assinado): entradas de 36 bytes (assinatura de 32 + ponteiro i32) a partir de 0x64: 12 db e 5 ib.
    S64 (0x310, assinado + bit 0x2): entradas de 40 bytes (32 + i64) a partir de 0x68 (blocks ocupa 8 bytes).
    Assinado: bloco k do arquivo = db[k] (k < 12); depois registros no bloco ib[0]; depois ib[1] aponta blocos de
    registros (dois niveis). Cada registro: assinatura (32) + ponteiro. As assinaturas nao sao conferidas.
  Diretorio: entradas {ino u32, type i32 (2 arq, 3 dir, 4 ".", 5 ".."), namelen i32, entsize i32, nome}, entsize =
    namelen+17 arredondado a 8. entsize 0 = fim das entradas daquele bloco (o LibOrbisPkg pula para o proximo bloco
    quando sobra pouco espaco; o MkPFS deixa a entrada cruzar o limite do bloco) - os dois jeitos sao aceitos.
  Inode 0 = super-root, com flat_path_table, collision_resolver e "uroot" (a raiz do jogo).
PFSC (conteudo de arquivo com flag 0x1; tambem o arquivo unico do .ffpfsc):
  0x00 "PFSC"  0x0C block_size u32  0x10 block_size u64  0x18 posicao da tabela u64 (0x400)  0x20 inicio dos dados
  0x28 tamanho dos dados (blocos * block_size). Tabela: n+1 deslocamentos u64 (relativos ao inicio do conteiner).
  Bloco com tamanho == block_size esta cru; menor = zlib que infla para exatamente block_size.
.ffpfsc: PFS externo cujo uroot tem um unico arquivo (pfs_image.dat, *.ffpfs, *.exfat, *.ffpkg, *.ufs2), normalmente
  comprimido; o MkPFS grava sem compressao (e sem a flag) quando comprimir nao ganha nada.

Fontes: ps5-dump-forge (crates/ps5-dump-forge-pfs/src/read.rs), LibOrbisPkg (PFS/PfsStructs.cs, PfsReader.cs,
PFSCReader.cs, PFSBuilder.cs) e MkPFS (mkpfs/pfs.py, consts.py). Detalhes: ps5-conhecimento/05-formatos-de-jogos.md.
zlib: miniz 3.0.2 (MIT, terceiros/miniz.c), so o inflate (tinfl).

Robustez: tudo que vem da imagem e conferido (tamanhos, blocos dentro da imagem, lacos limitados), nada e lido alem
de d->tamanho e cada bloco PFSC infla no maximo block_size bytes (bomba de descompressao impossivel).
*/
#include "imagem.h"

#include <stdlib.h>
#include <string.h>

/* miniz e codigo de terceiros: so o inflate, compilado sem os avisos do nosso -Werror. */
#define MINIZ_NO_STDIO
#define MINIZ_NO_TIME
#define MINIZ_NO_ARCHIVE_APIS
#define MINIZ_NO_ARCHIVE_WRITING_APIS
#define MINIZ_NO_DEFLATE_APIS
#define MINIZ_NO_ZLIB_APIS
#define MINIZ_NO_ZLIB_COMPATIBLE_NAMES
#ifndef NDEBUG
#define NDEBUG   /* sem assert() do miniz: um assert derrubaria o payload */
#endif
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Weverything"
#include "terceiros/miniz.c"
#pragma clang diagnostic pop

#define PFS_MAGIC 20130315ull
#define PFS_ASSINADO 0x1
#define PFS_INODE64 0x2
#define PFS_CIFRADO 0x4
#define PFS_SEM_CAIXA 0x8

#define INO_DIR 0x4000
#define INO_ARQ 0x8000
#define INO_COMPRIMIDO 0x1

#define ENT_ARQ 2
#define ENT_DIR 3

#define PFSC_MAGIC 0x43534650u

#define MAX_INODES 10000000ull     /* bem acima de qualquer jogo */
#define MAX_DIR (64ull << 20)      /* bytes de entradas num diretorio */
#define MAX_NIVEIS 64              /* pastas no caminho */
#define CACHE_BLOCOS 4             /* blocos PFSC inflados guardados */

static uint16_t le16(const uint8_t *p) {
  return (uint16_t)(p[0] | (p[1] << 8));
}

static uint32_t le32(const uint8_t *p) {
  return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static uint64_t le64(const uint8_t *p) {
  return (uint64_t)le32(p) | ((uint64_t)le32(p + 4) << 32);
}

/* ---------------------------------------------------------------- PFS */

typedef struct {
  dispositivo_t *d;
  uint32_t bs;
  uint64_t nblocos;          /* blocos inteiros que existem de fato na imagem */
  uint64_t ninodes;
  uint64_t bloco_inodes;     /* primeiro bloco da tabela de inodes */
  uint64_t por_bloco;        /* inodes por bloco */
  uint32_t tam_inode;
  int assinado, s64, sem_caixa;
} pfs_t;

typedef struct {
  uint16_t modo;
  uint32_t flags;
  uint64_t armazenado;       /* bytes ocupados na imagem */
  uint64_t logico;           /* tamanho real do arquivo (descompactado) */
  uint64_t blocos;
  int64_t db[12], ib[5];
} inode_t;

static int pfs_abrir(pfs_t *p, dispositivo_t *d) {
  uint8_t h[0x400];
  memset(p, 0, sizeof *p);
  p->d = d;
  if(d->tamanho < sizeof h) return IMG_FORMATO;
  if(d->ler(d, 0, h, sizeof h)) return IMG_ERRO;
  uint64_t versao = le64(h);
  if((versao != 1 && versao != 2) || le64(h + 8) != PFS_MAGIC) return IMG_FORMATO;
  uint16_t modo = le16(h + 0x1C);
  if(modo & PFS_CIFRADO) return IMG_FORMATO;
  p->assinado = (modo & PFS_ASSINADO) != 0;
  p->s64 = p->assinado && (modo & PFS_INODE64);
  p->sem_caixa = (modo & PFS_SEM_CAIXA) != 0;
  p->tam_inode = p->assinado ? (p->s64 ? 0x310 : 0x2C8) : 0xA8;
  p->bs = le32(h + 0x20);
  if(p->bs < 0x1000 || p->bs > 0x10000 || (p->bs & (p->bs - 1))) return IMG_FORMATO;
  p->nblocos = d->tamanho / p->bs;
  uint64_t ndblock = le64(h + 0x38);
  if(ndblock && ndblock < p->nblocos) p->nblocos = ndblock;
  p->ninodes = le64(h + 0x30);
  if(p->ninodes == 0 || p->ninodes > MAX_INODES) return IMG_ERRO;
  p->por_bloco = p->bs / p->tam_inode;
  p->bloco_inodes = 1;
  for(int i = 0; i < 5; i++)
    if((int64_t)le64(h + 0x2B8 + i * 40) > 0) p->bloco_inodes++;
  uint64_t blocos_tabela = (p->ninodes + p->por_bloco - 1) / p->por_bloco;
  if(p->bloco_inodes + blocos_tabela > p->nblocos) return IMG_ERRO;
  return IMG_OK;
}

static int ler_inode(pfs_t *p, uint64_t n, inode_t *in) {
  uint8_t b[0x310];
  if(n >= p->ninodes) return IMG_ERRO;
  uint64_t off = (p->bloco_inodes + n / p->por_bloco) * p->bs + (n % p->por_bloco) * p->tam_inode;
  if(p->d->ler(p->d, off, b, p->tam_inode)) return IMG_ERRO;
  memset(in, 0, sizeof *in);
  in->modo = le16(b);
  in->flags = le32(b + 4);
  uint64_t size = le64(b + 8), size_c = le64(b + 0x10);
  in->blocos = le32(b + 0x60);
  for(int i = 0; i < 12; i++) {
    if(!p->assinado) in->db[i] = (int32_t)le32(b + 0x64 + i * 4);
    else if(!p->s64) in->db[i] = (int32_t)le32(b + 0x64 + i * 36 + 32);
    else in->db[i] = (int64_t)le64(b + 0x68 + i * 40 + 32);
  }
  for(int i = 0; i < 5; i++) {
    if(!p->assinado) in->ib[i] = (int32_t)le32(b + 0x94 + i * 4);
    else if(!p->s64) in->ib[i] = (int32_t)le32(b + 0x64 + 12 * 36 + i * 36 + 32);
    else in->ib[i] = (int64_t)le64(b + 0x68 + 12 * 40 + i * 40 + 32);
  }
  /* Nomes invertidos (ver o cabecalho): comprimido -> size = armazenado, size_compressed = logico. */
  in->armazenado = size;
  in->logico = (in->flags & INO_COMPRIMIDO) ? size_c : size;
  if(in->armazenado > (uint64_t)INT64_MAX || in->logico > (uint64_t)INT64_MAX) return IMG_ERRO;
  /* Os blocos declarados tem de cobrir o que esta armazenado. */
  uint64_t precisa = (in->armazenado + p->bs - 1) / p->bs;
  if(precisa > in->blocos) return IMG_ERRO;
  return IMG_OK;
}

/* Inode contiguo: nao assinado com db[1] = -1 (ou um bloco so). */
static int contiguo(const pfs_t *p, const inode_t *in) {
  return !p->assinado && (in->blocos <= 1 || in->db[1] == -1);
}

/* Le o ponteiro do registro "idx" (assinatura + ponteiro) do bloco de indices "bloco" (imagem assinada). */
static int ler_registro(pfs_t *p, int64_t bloco, uint64_t idx, int64_t *saida) {
  uint32_t tam = p->s64 ? 40 : 36;
  if(bloco <= 0 || (uint64_t)bloco >= p->nblocos || idx >= p->bs / tam) return -1;
  uint8_t b[8];
  if(p->d->ler(p->d, (uint64_t)bloco * p->bs + idx * tam + 32, b, p->s64 ? 8 : 4)) return -1;
  *saida = p->s64 ? (int64_t)le64(b) : (int64_t)(int32_t)le32(b);
  return 0;
}

/* Bloco da imagem onde esta o bloco k do arquivo. */
static int mapear(pfs_t *p, const inode_t *in, uint64_t k, uint64_t *fisico) {
  int64_t f;
  if(k >= in->blocos) return -1;
  if(contiguo(p, in)) {
    if(in->db[0] <= 0) return -1;
    f = in->db[0] + (int64_t)k;     /* db[0] < 2^31 e k < 2^32: sem estouro */
  } else if(k < 12) {
    f = in->db[k];
  } else if(!p->assinado) {
    return -1;   /* nao assinado e nao contiguo com mais de 12 blocos: nenhuma ferramenta gera; nao suportado */
  } else {
    uint64_t por = p->bs / (p->s64 ? 40u : 36u), k2 = k - 12;
    if(k2 < por) {
      if(ler_registro(p, in->ib[0], k2, &f)) return -1;
    } else {
      k2 -= por;
      int64_t ind;
      if(k2 / por >= por || ler_registro(p, in->ib[1], k2 / por, &ind) || ler_registro(p, ind, k2 % por, &f))
        return -1;
    }
  }
  if(f <= 0 || (uint64_t)f >= p->nblocos) return -1;
  *fisico = (uint64_t)f;
  return 0;
}

/* Le n bytes armazenados do inode a partir de off (sem descompactar). */
static int ler_dados(pfs_t *p, const inode_t *in, uint64_t off, void *buf, size_t n) {
  if(off > in->armazenado || n > in->armazenado - off) return -1;
  if(n == 0) return 0;
  if(contiguo(p, in)) {
    uint64_t usados = (in->armazenado + p->bs - 1) / p->bs;
    if(in->db[0] <= 0 || (uint64_t)in->db[0] >= p->nblocos || usados > p->nblocos - (uint64_t)in->db[0]) return -1;
    return p->d->ler(p->d, (uint64_t)in->db[0] * p->bs + off, buf, n);
  }
  uint8_t *o = buf;
  while(n) {
    uint64_t f, dentro = off % p->bs;
    size_t m = p->bs - dentro;
    if(m > n) m = n;
    if(mapear(p, in, off / p->bs, &f) || p->d->ler(p->d, f * p->bs + dentro, o, m)) return -1;
    o += m;
    off += m;
    n -= m;
  }
  return 0;
}

/* Percorre as entradas de um diretorio. cb devolve 0 para continuar, 1 para parar. */
typedef int (*cb_dir_t)(void *ctx, uint32_t ino, int32_t tipo, const char *nome, size_t n);

static int iterar_dir(pfs_t *p, const inode_t *dir, cb_dir_t cb, void *ctx) {
  if(!(dir->modo & INO_DIR) || (dir->flags & INO_COMPRIMIDO)) return IMG_ERRO;
  uint64_t tam = dir->armazenado;
  if(tam > MAX_DIR) return IMG_ERRO;
  uint8_t *jan = malloc(p->bs);   /* janela: [jan_off, jan_off + jan_n) do diretorio */
  if(!jan) return IMG_ERRO;
  uint64_t jan_off = 0, jan_n = 0, pos = 0;
  int r = IMG_OK;
  while(pos + 16 <= tam) {
    if(pos < jan_off || pos + 16 > jan_off + jan_n) {
      jan_off = pos;
      jan_n = tam - pos < p->bs ? tam - pos : p->bs;
      if(ler_dados(p, dir, jan_off, jan, (size_t)jan_n)) { r = IMG_ERRO; break; }
    }
    const uint8_t *e = jan + (pos - jan_off);
    uint32_t ino = le32(e);
    int32_t tipo = (int32_t)le32(e + 4), nlen = (int32_t)le32(e + 8), ent = (int32_t)le32(e + 12);
    if(ent == 0) {            /* resto do bloco vazio: as entradas continuam no proximo bloco (se houver) */
      pos = (pos / p->bs + 1) * p->bs;
      continue;
    }
    if(nlen <= 0 || nlen > 255 || ent < 16 + nlen || (ent & 7) || (uint64_t)ent > tam - pos) { r = IMG_ERRO; break; }
    if(pos + (uint64_t)ent > jan_off + jan_n) {   /* entrada cruza o fim da janela: recarrega a partir dela */
      jan_off = pos;
      jan_n = tam - pos < p->bs ? tam - pos : p->bs;
      if(ler_dados(p, dir, jan_off, jan, (size_t)jan_n)) { r = IMG_ERRO; break; }
      e = jan;
    }
    const char *nome = (const char *)e + 16;
    if(memchr(nome, 0, (size_t)nlen) || memchr(nome, '/', (size_t)nlen)) { r = IMG_ERRO; break; }
    if(cb(ctx, ino, tipo, nome, (size_t)nlen)) break;
    pos += (uint64_t)ent;
  }
  free(jan);
  return r;
}

static int letra_igual(char a, char b, int sem_caixa) {
  if(sem_caixa) {
    if(a >= 'A' && a <= 'Z') a = (char)(a - 'A' + 'a');
    if(b >= 'A' && b <= 'Z') b = (char)(b - 'A' + 'a');
  }
  return a == b;
}

typedef struct {
  const char *nome;
  size_t n;
  int sem_caixa;
  int achou;
  uint32_t ino;
} busca_t;

static int cb_busca(void *ctx, uint32_t ino, int32_t tipo, const char *nome, size_t n) {
  busca_t *b = ctx;
  if((tipo != ENT_ARQ && tipo != ENT_DIR) || n != b->n) return 0;
  for(size_t i = 0; i < n; i++)
    if(!letra_igual(nome[i], b->nome[i], b->sem_caixa)) return 0;
  b->achou = 1;
  b->ino = ino;
  return 1;
}

/* Procura "nome" (n bytes) no diretorio e le o inode achado. */
static int procurar(pfs_t *p, const inode_t *dir, const char *nome, size_t n, inode_t *saida) {
  busca_t b = {nome, n, p->sem_caixa, 0, 0};
  int r = iterar_dir(p, dir, cb_busca, &b);
  if(r) return r;
  if(!b.achou) return IMG_NAO_ACHOU;
  return ler_inode(p, b.ino, saida);
}

/* Inode do uroot (raiz do jogo): super-root (inode 0) -> "uroot". */
static int abrir_uroot(pfs_t *p, inode_t *uroot) {
  inode_t sr;
  int r = ler_inode(p, 0, &sr);
  if(r) return r;
  if(!(sr.modo & INO_DIR)) return IMG_ERRO;
  int sem_caixa = p->sem_caixa;
  p->sem_caixa = 0;
  r = procurar(p, &sr, "uroot", 5, uroot);
  p->sem_caixa = sem_caixa;
  if(r == IMG_NAO_ACHOU) return IMG_ERRO;   /* PFS sem uroot: estrutura invalida */
  if(r) return r;
  return (uroot->modo & INO_DIR) ? IMG_OK : IMG_ERRO;
}

/* Acha o arquivo "caminho" (relativo ao uroot) e devolve o inode dele. */
static int achar(pfs_t *p, const char *caminho, inode_t *saida) {
  inode_t atual;
  int r = abrir_uroot(p, &atual);
  if(r) return r;
  const char *s = caminho;
  int niveis = 0;
  while(*s == '/') s++;
  if(!*s) return IMG_NAO_ACHOU;
  while(*s) {
    const char *fim = strchr(s, '/');
    size_t n = fim ? (size_t)(fim - s) : strlen(s);
    if(n > 255 || ++niveis > MAX_NIVEIS) return IMG_NAO_ACHOU;
    if(!(atual.modo & INO_DIR)) return IMG_NAO_ACHOU;
    inode_t prox;
    r = procurar(p, &atual, s, n, &prox);
    if(r) return r;
    atual = prox;
    s += n;
    while(*s == '/') s++;
  }
  if(!(atual.modo & INO_ARQ) || (atual.modo & INO_DIR)) return IMG_NAO_ACHOU;
  *saida = atual;
  return IMG_OK;
}

/* Dispositivo com os bytes armazenados de um arquivo do PFS. */
typedef struct {
  dispositivo_t base;   /* copia do dispositivo da imagem (o chamador continua dono dele) */
  pfs_t p;              /* p.d aponta para base */
  inode_t in;
} bruto_t;

static int ler_bruto(dispositivo_t *d, uint64_t off, void *buf, size_t n) {
  bruto_t *b = d->ctx;
  return ler_dados(&b->p, &b->in, off, buf, n);
}

static void fechar_bruto(dispositivo_t *d) {
  free(d->ctx);
  d->ctx = NULL;
}

/* ---------------------------------------------------------------- PFSC */

typedef struct {
  dispositivo_t base;   /* conteiner armazenado; fechado junto com este */
  uint32_t bs;
  uint64_t nblocos;     /* blocos logicos usados (tamanho logico / bs, arredondado) */
  uint64_t tabela, tabela_fim;
  struct {
    uint64_t idx, uso;
    uint8_t *d;
  } cache[CACHE_BLOCOS];
  uint64_t relogio;
  uint8_t *comp;
  tinfl_decompressor *dec;
} pfsc_t;

/* Bloco logico i inflado (ponteiro para bs bytes no cache), ou NULL. */
static const uint8_t *pfsc_bloco(pfsc_t *c, uint64_t i) {
  int livre = 0;
  for(int k = 0; k < CACHE_BLOCOS; k++) {
    if(c->cache[k].d && c->cache[k].idx == i) {
      c->cache[k].uso = ++c->relogio;
      return c->cache[k].d;
    }
    if(c->cache[k].uso < c->cache[livre].uso) livre = k;
  }
  if(i >= c->nblocos) return NULL;
  if(!c->cache[livre].d && !(c->cache[livre].d = malloc(c->bs))) return NULL;
  uint8_t *saida = c->cache[livre].d;
  c->cache[livre].idx = UINT64_MAX;
  c->cache[livre].uso = 0;
  uint8_t t[16];
  if(c->base.ler(&c->base, c->tabela + i * 8, t, sizeof t)) return NULL;
  uint64_t a = le64(t), b = le64(t + 8);
  if(a < c->tabela_fim || b <= a || b > c->base.tamanho || b - a > c->bs) return NULL;
  if(b - a == c->bs) {
    if(c->base.ler(&c->base, a, saida, c->bs)) return NULL;
  } else {
    if(c->base.ler(&c->base, a, c->comp, (size_t)(b - a))) return NULL;
    size_t n_ent = (size_t)(b - a), n_sai = c->bs;
    tinfl_init(c->dec);
    /* Saida limitada a bs: se o fluxo quiser mais, o status nao e DONE e o bloco e recusado. */
    tinfl_status st = tinfl_decompress(c->dec, c->comp, &n_ent, saida, saida, &n_sai,
                                       TINFL_FLAG_PARSE_ZLIB_HEADER | TINFL_FLAG_USING_NON_WRAPPING_OUTPUT_BUF);
    if(st != TINFL_STATUS_DONE || n_sai != c->bs) return NULL;
  }
  c->cache[livre].idx = i;
  c->cache[livre].uso = ++c->relogio;
  return saida;
}

static int ler_pfsc(dispositivo_t *d, uint64_t off, void *buf, size_t n) {
  pfsc_t *c = d->ctx;
  if(off > d->tamanho || n > d->tamanho - off) return -1;
  uint8_t *o = buf;
  while(n) {
    uint64_t dentro = off % c->bs;
    size_t m = c->bs - dentro;
    if(m > n) m = n;
    const uint8_t *blk = pfsc_bloco(c, off / c->bs);
    if(!blk) return -1;
    memcpy(o, blk + dentro, m);
    o += m;
    off += m;
    n -= m;
  }
  return 0;
}

static void fechar_pfsc(dispositivo_t *d) {
  pfsc_t *c = d->ctx;
  if(!c) return;
  for(int k = 0; k < CACHE_BLOCOS; k++) free(c->cache[k].d);
  free(c->comp);
  free(c->dec);
  if(c->base.fechar) c->base.fechar(&c->base);
  free(c);
  d->ctx = NULL;
}

/* Monta em "saida" o dispositivo que le o conteiner PFSC "base" ja inflado, com tamanho logico "logico".
   Se der certo, saida passa a ser dona de base (fecha junto); se falhar, base continua do chamador. */
static int pfsc_abrir(const dispositivo_t *base, uint64_t logico, dispositivo_t *saida) {
  uint8_t h[0x30];
  if(base->tamanho < sizeof h) return IMG_ERRO;
  dispositivo_t b = *base;
  if(b.ler(&b, 0, h, sizeof h)) return IMG_ERRO;
  if(le32(h) != PFSC_MAGIC) return IMG_ERRO;
  uint32_t bs = le32(h + 0x0C);
  if(bs < 0x1000 || bs > 0x10000 || (bs & (bs - 1)) || le64(h + 0x10) != bs) return IMG_ERRO;
  uint64_t tabela = le64(h + 0x18), dados = le64(h + 0x28);
  if(dados % bs) return IMG_ERRO;
  uint64_t total = dados / bs, nblocos = logico / bs + (logico % bs != 0);
  if(nblocos > total) return IMG_ERRO;
  /* tabela com total+1 entradas dentro do conteiner (sem estouro: total <= tamanho/8) */
  if(tabela < sizeof h || tabela > base->tamanho || total >= base->tamanho / 8 ||
     (total + 1) * 8 > base->tamanho - tabela)
    return IMG_ERRO;
  pfsc_t *c = calloc(1, sizeof *c);
  if(!c) return IMG_ERRO;
  c->base = b;
  c->bs = bs;
  c->nblocos = nblocos;
  c->tabela = tabela;
  c->tabela_fim = tabela + (total + 1) * 8;
  c->comp = malloc(bs);
  c->dec = malloc(sizeof *c->dec);
  if(!c->comp || !c->dec) {
    free(c->comp);
    free(c->dec);
    free(c);
    return IMG_ERRO;
  }
  saida->ler = ler_pfsc;
  saida->fechar = fechar_pfsc;
  saida->tamanho = logico;
  saida->ctx = c;
  return IMG_OK;
}

/* ---------------------------------------------------------------- API */

int pfs_ler(dispositivo_t *d, const char *caminho, buf_t *saida, size_t max) {
  bruto_t b;
  int r = pfs_abrir(&b.p, d);
  if(r) return r;
  r = achar(&b.p, caminho, &b.in);
  if(r) return r;
  if(b.in.logico > max) return IMG_ERRO;
  dispositivo_t bruto = {ler_bruto, NULL, b.in.armazenado, &b}, conteudo = bruto;
  if(b.in.flags & INO_COMPRIMIDO) {
    r = pfsc_abrir(&bruto, b.in.logico, &conteudo);
    if(r) return r;
  } else if(b.in.armazenado != b.in.logico) {
    return IMG_ERRO;
  }
  size_t pedaco = 0x10000;
  uint8_t *tmp = malloc(pedaco);
  if(!tmp) r = IMG_ERRO;
  for(uint64_t off = 0; !r && off < b.in.logico;) {
    size_t m = b.in.logico - off < pedaco ? (size_t)(b.in.logico - off) : pedaco;
    if(conteudo.ler(&conteudo, off, tmp, m)) r = IMG_ERRO;
    else buf_add(saida, tmp, m);
    off += m;
  }
  free(tmp);
  if(conteudo.fechar) conteudo.fechar(&conteudo);
  return r;
}

/* Nomes que o ShadowMountPlus aceita como imagem interna do .ffpfsc. */
static int imagem_interna(const char *nome, size_t n) {
  static const char *const finais[] = {".ffpfs", ".exfat", ".ffpkg", ".ufs2"};
  char baixo[256];
  if(n == 0 || n >= sizeof baixo) return 0;
  for(size_t i = 0; i < n; i++) baixo[i] = (nome[i] >= 'A' && nome[i] <= 'Z') ? (char)(nome[i] - 'A' + 'a') : nome[i];
  baixo[n] = 0;
  if(!strcmp(baixo, "pfs_image.dat")) return 1;
  for(size_t i = 0; i < sizeof finais / sizeof finais[0]; i++) {
    size_t f = strlen(finais[i]);
    if(n > f && !memcmp(baixo + n - f, finais[i], f)) return 1;
  }
  return 0;
}

typedef struct {
  int quantos;
  uint32_t ino;
  char nome[256];
} interna_t;

static int cb_interna(void *ctx, uint32_t ino, int32_t tipo, const char *nome, size_t n) {
  interna_t *x = ctx;
  if(tipo != ENT_ARQ || !imagem_interna(nome, n)) return 0;
  if(x->quantos++ == 0) {
    x->ino = ino;
    memcpy(x->nome, nome, n);
    x->nome[n] = 0;
  }
  return x->quantos > 1;   /* mais de uma: ja da para parar */
}

int ffpfsc_abrir(dispositivo_t *externo, dispositivo_t *interno, char *nome_interno, size_t tam_nome) {
  bruto_t *b = calloc(1, sizeof *b);
  if(!b) return IMG_ERRO;
  b->base = *externo;
  inode_t uroot;
  interna_t x = {0, 0, {0}};
  int r = pfs_abrir(&b->p, &b->base);
  if(!r) r = abrir_uroot(&b->p, &uroot);
  if(!r) r = iterar_dir(&b->p, &uroot, cb_interna, &x);
  if(!r && x.quantos == 0) r = IMG_NAO_ACHOU;
  if(!r && x.quantos > 1) r = IMG_ERRO;   /* ambiguo: o SMP tambem exige uma so */
  if(!r && strlen(x.nome) + 1 > tam_nome) r = IMG_ERRO;
  if(!r) r = ler_inode(&b->p, x.ino, &b->in);
  if(!r && (!(b->in.modo & INO_ARQ) || (b->in.modo & INO_DIR) || b->in.logico == 0)) r = IMG_ERRO;
  if(!r && !(b->in.flags & INO_COMPRIMIDO) && b->in.armazenado != b->in.logico) r = IMG_ERRO;
  if(r) {
    free(b);
    return r;
  }
  dispositivo_t bruto = {ler_bruto, fechar_bruto, b->in.armazenado, b};
  if(b->in.flags & INO_COMPRIMIDO) {
    r = pfsc_abrir(&bruto, b->in.logico, interno);
    if(r) {
      free(b);
      return r;
    }
  } else {
    *interno = bruto;   /* o MkPFS grava sem compressao quando comprimir nao ganha nada */
  }
  memcpy(nome_interno, x.nome, strlen(x.nome) + 1);
  return IMG_OK;
}
