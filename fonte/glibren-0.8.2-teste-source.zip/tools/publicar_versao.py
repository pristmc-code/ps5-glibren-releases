"""Prepara uma versao do glibren para o repositorio publico de versoes (pristmc-code/ps5-glibren-releases).

Assina saida/glibren.elf com a chave privada Ed25519 (fica so neste PC, fora do repositorio) e grava na pasta do
repositorio publico: glibren.elf, glibren.elf.sig (64 bytes) e versao.json. O payload no PS5 so instala um .elf
cuja assinatura confere com a chave publica embutida nele (src/chave_publica.h).

Uso:  python tools/publicar_versao.py PASTA_DO_REPO_PUBLICO "notas da versao"
Depois: commit e push na pasta do repositorio publico.
"""
import hashlib
import json
import os
import re
import sys

from cryptography.hazmat.primitives import serialization

CHAVE = os.path.join(os.path.expanduser("~"), ".glibren", "assinatura_ed25519.pem")
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 1
    destino, notas = sys.argv[1], sys.argv[2]
    versao = re.search(r'#define VERSAO "([^"]+)"', open(os.path.join(RAIZ, "src", "api.h"), encoding="utf-8").read()).group(1)
    elf = open(os.path.join(RAIZ, "saida", "glibren.elf"), "rb").read()
    if versao.encode() not in elf:
        print(f"saida/glibren.elf nao e a versao {versao} (compile de novo)")
        return 1
    chave = serialization.load_pem_private_key(open(CHAVE, "rb").read(), None)
    publica = chave.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    embutida = bytes(int(x, 16) for x in re.findall(r"0x([0-9a-f]{2})", open(os.path.join(RAIZ, "src", "chave_publica.h"), encoding="utf-8").read()))
    if publica != embutida:
        print("a chave privada nao corresponde a chave publica embutida no payload")
        return 1
    assinatura = chave.sign(elf)
    chave.public_key().verify(assinatura, elf)   # confere antes de publicar
    os.makedirs(destino, exist_ok=True)
    open(os.path.join(destino, "glibren.elf"), "wb").write(elf)
    open(os.path.join(destino, "glibren.elf.sig"), "wb").write(assinatura)
    info = {"versao": versao, "notas": notas, "tamanho": len(elf), "sha256": hashlib.sha256(elf).hexdigest()}
    with open(os.path.join(destino, "versao.json"), "w", encoding="utf-8", newline="\n") as f:
        json.dump(info, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(f"versao {versao} pronta em {destino} ({len(elf)} bytes, sha256 {info['sha256'][:16]}...)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
