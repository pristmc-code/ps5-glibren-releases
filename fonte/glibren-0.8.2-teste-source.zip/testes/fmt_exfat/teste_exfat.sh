#!/bin/bash
# Teste do leitor exFAT (src/fmt_exfat.c) com imagens REAIS: mkfs.exfat (exfatprogs) + montagem loop do kernel Linux.
# Rodar como root no WSL (precisa de mount -o loop):
#   wsl -d Ubuntu-24.04 -u root -- bash "/mnt/d/##__GoogleDrive/###_Claude/ps5/payload/testes/fmt_exfat/teste_exfat.sh"
# Pacotes: exfatprogs, clang-18, python3 (para corromper bytes).
# Imagens:
#   c64k   cluster 64 KB (como o mkexfat.sh do ShadowMountPlus), copia normal -> arquivos contiguos (NoFatChain)
#   c4k    cluster 4 KB, copia normal -> pastas com muitos clusters, raiz com varios clusters pela FAT
#   frag   cluster 4 KB, arquivos e uma pasta escritos intercalados -> fragmentados, lidos pela cadeia da FAT
set -u
AQUI="$(cd "$(dirname "$0")" && pwd)"
RAIZ="$(cd "$AQUI/../.." && pwd)"
T=/tmp/exfat_teste
BIN=$T/teste_exfat
FALHAS=0
OKS=0

ok() { OKS=$((OKS + 1)); }
falha() { echo "FALHOU: $*"; FALHAS=$((FALHAS + 1)); }

umount $T/mnt 2>/dev/null
rm -rf $T && mkdir -p $T/mnt $T/orig

echo "== compilando (ASan + UBSan)"
clang-18 -Wall -Werror -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=all -I"$RAIZ/src" \
  "$AQUI/teste_exfat.c" "$RAIZ/src/fmt_exfat.c" "$RAIZ/src/imagem.c" "$RAIZ/src/util.c" -o $BIN || exit 1

echo "== montando a arvore de origem"
O=$T/orig
mkdir -p $O/sce_sys/about "$O/Pasta Com Nome Bem Comprido Para Varias Entradas 0xC1" "$O/Ação Jogo" $O/muitos
cat > $O/sce_sys/param.json <<'J'
{"titleId":"PPSA01234","contentId":"UP0001-PPSA01234_00-TESTEEXFAT000000","localizedParameters":{"defaultLanguage":"en-US","en-US":{"titleName":"Teste exFAT"},"pt-BR":{"titleName":"Teste exFAT BR"}}}
J
head -c 70000 /dev/urandom > $O/sce_sys/icon0.png
printf '\x89PNG\r\n\x1a\n' | dd of=$O/sce_sys/icon0.png conv=notrunc 2>/dev/null
head -c 300000 /dev/urandom > $O/eboot.bin
head -c 1 /dev/urandom > $O/sce_sys/about/um_byte.bin
: > $O/sce_sys/vazio.txt
head -c 5000 /dev/urandom > "$O/Pasta Com Nome Bem Comprido Para Varias Entradas 0xC1/Arquivo com nome comprido de mais de quarenta caracteres.dat"
head -c 777 /dev/urandom > "$O/Ação Jogo/canção.txt"
for i in $(seq 1 1200); do head -c $((i % 97 + 1)) /dev/urandom > "$O/muitos/arquivo_numero_$(printf %05d $i)_comprido.bin"; done
for i in $(seq 1 150); do echo "raiz $i" > "$O/raiz_$(printf %04d $i)_nome_um_pouco_longo.txt"; done

# lista de arquivos a conferir: todos fora de "muitos" + uma amostra de "muitos"
(cd $O && find . -type f ! -path './muitos/*' | sed 's|^\./||'; \
  for i in 1 2 50 333 600 999 1199 1200; do echo "muitos/arquivo_numero_$(printf %05d $i)_comprido.bin"; done) > $T/lista

criar_copia() {   # nome cluster tamanho
  truncate -s $3 $T/$1.exfat
  mkfs.exfat -c $2 -L TESTE $T/$1.exfat > /dev/null || exit 1
  mount -o loop $T/$1.exfat $T/mnt || exit 1
  cp -r $O/. $T/mnt/
  umount $T/mnt
}

echo "== criando imagens"
criar_copia c64k 64K 200M
criar_copia c4k 4K 64M

# frag: intercala escritas de eboot.bin e icon0.png (arquivos fragmentados) e cria a pasta "fragpasta" aos poucos,
# alternando com crescimento de um arquivo grande, para a propria pasta ficar fragmentada
truncate -s 64M $T/frag.exfat
mkfs.exfat -c 4K $T/frag.exfat > /dev/null || exit 1
mount -o loop $T/frag.exfat $T/mnt || exit 1
mkdir -p $T/mnt/sce_sys $T/mnt/fragpasta
: > $T/mnt/eboot.bin; : > $T/mnt/sce_sys/icon0.png; : > $T/mnt/enchimento.bin
for k in $(seq 0 9); do
  dd if=$O/eboot.bin of=$T/mnt/eboot.bin bs=30000 skip=$k seek=$k count=1 conv=notrunc 2>/dev/null; sync
  dd if=$O/sce_sys/icon0.png of=$T/mnt/sce_sys/icon0.png bs=7000 skip=$k seek=$k count=1 conv=notrunc 2>/dev/null; sync
  for j in $(seq 1 40); do echo "f $k $j" > "$T/mnt/fragpasta/arquivo_da_pasta_fragmentada_${k}_$j.txt"; done; sync
  head -c 8192 /dev/urandom >> $T/mnt/enchimento.bin; sync
done
cp $O/sce_sys/param.json $T/mnt/sce_sys/
echo "== fragmentacao (filefrag; mais de 1 extent = cadeia pela FAT):"
for f in eboot.bin sce_sys/icon0.png fragpasta; do echo "  $f: $(filefrag $T/mnt/$f 2>&1 | sed 's/.*: //')"; done
cp -r $T/mnt/fragpasta $T/orig_fragpasta
umount $T/mnt

conferir() {   # imagem caminho_na_imagem original
  local saida=$T/saida.bin r
  r=$($BIN $T/$1.exfat "$2" 67108864 $saida 2>&1)
  if [[ "$r" == ret=0* ]] && cmp -s $saida "$3"; then ok; else falha "$1 '$2' -> $r"; fi
}

esperar() {   # imagem caminho max codigo
  local r
  r=$($BIN "$1" "$2" "$3" 2>&1)
  if [[ "$r" == "ret=$4 "* ]]; then ok; else falha "$1 '$2' max=$3 esperava ret=$4 -> $r"; fi
}

echo "== conferindo byte a byte"
for img in c64k c4k; do
  while read -r f; do conferir $img "$f" "$O/$f"; done < $T/lista
  conferir $img "SCE_SYS/PARAM.JSON" $O/sce_sys/param.json      # maiusculas
  conferir $img "/sce_sys//icon0.png" $O/sce_sys/icon0.png      # barras sobrando
done
conferir frag eboot.bin $O/eboot.bin
conferir frag sce_sys/icon0.png $O/sce_sys/icon0.png
conferir frag sce_sys/param.json $O/sce_sys/param.json
for f in $(ls $T/orig_fragpasta | head -400); do conferir frag "fragpasta/$f" "$T/orig_fragpasta/$f"; done

echo "== casos de erro"
esperar $T/c4k.exfat sce_sys/nao_existe.json 1000000 -2
esperar $T/c4k.exfat sce_sys 1000000 -2                         # pasta pedida como arquivo
esperar $T/c4k.exfat eboot.bin/x 1000000 -2                     # arquivo usado como pasta
esperar $T/c4k.exfat "" 1000000 -2
esperar $T/c4k.exfat sce_sys/icon0.png 1000 -3                  # maior que max
esperar $T/c4k.exfat sce_sys/icon0.png 70000 0                  # exatamente max
esperar $T/c4k.exfat sce_sys/vazio.txt 0 0
head -c 1048576 /dev/urandom > $T/aleatorio.bin
esperar $T/aleatorio.bin sce_sys/param.json 1000000 -1
: > $T/vazio.bin
esperar $T/vazio.bin sce_sys/param.json 1000000 -1
esperar $O/sce_sys/param.json sce_sys/param.json 1000000 -1      # arquivo pequeno (< 512)

echo "== imagem truncada"
for n in 512 4096 65536 1000000 3000000; do
  head -c $n $T/c4k.exfat > $T/trunc.exfat
  for f in sce_sys/param.json sce_sys/icon0.png muitos/arquivo_numero_01200_comprido.bin; do
    r=$($BIN $T/trunc.exfat $f 2>&1)
    if [[ "$r" == ret=* ]]; then ok; else falha "truncada $n $f -> $r"; fi
  done
done

echo "== cadeia circular na FAT (raiz e arquivo fragmentado)"
python3 - $T/frag.exfat $T/circ.exfat <<'P'
import struct, sys
b = bytearray(open(sys.argv[1], 'rb').read())
bps = 1 << b[0x6C]; fat = struct.unpack_from('<I', b, 0x50)[0] * bps; raiz = struct.unpack_from('<I', b, 0x60)[0]
# a raiz passa a apontar para si mesma: nunca termina pela FAT
struct.pack_into('<I', b, fat + 4 * raiz, raiz)
open(sys.argv[2], 'wb').write(b)
P
for f in nao_existe.txt sce_sys/param.json eboot.bin; do
  r=$(timeout 60 $BIN $T/circ.exfat $f 2>&1)
  if [[ "$r" == ret=* ]]; then ok; echo "  circular $f -> $r"; else falha "circular $f -> $r"; fi
done
python3 - $T/frag.exfat $T/circ2.exfat <<'P'
import struct, sys
b = bytearray(open(sys.argv[1], 'rb').read())
bps = 1 << b[0x6C]; fat = struct.unpack_from('<I', b, 0x50)[0] * bps; n = struct.unpack_from('<I', b, 0x5C)[0]
# toda entrada de FAT "fim de cadeia" vira laco para o proprio cluster (arquivos fragmentados nunca terminam)
for c in range(2, n + 2):
  if struct.unpack_from('<I', b, fat + 4 * c)[0] == 0xFFFFFFFF: struct.pack_into('<I', b, fat + 4 * c, c)
open(sys.argv[2], 'wb').write(b)
P
for f in eboot.bin sce_sys/icon0.png fragpasta/arquivo_da_pasta_fragmentada_9_40.txt; do
  r=$(timeout 60 $BIN $T/circ2.exfat $f 2>&1)
  if [[ "$r" == ret=* ]]; then ok; echo "  circular2 $f -> $r"; else falha "circular2 $f -> $r"; fi
done

echo "== bytes corrompidos ao acaso (boot, FAT, diretorios) - 300 rodadas"
python3 - $T/c4k.exfat $T <<'P'
import random, struct, sys
src = open(sys.argv[1], 'rb').read()
random.seed(1234)
bps = 1 << src[0x6C]; heap = struct.unpack_from('<I', src, 0x58)[0] * bps
for i in range(300):
  b = bytearray(src)
  for _ in range(random.randint(1, 40)):
    zona = random.random()
    if zona < 0.15: p = random.randrange(0, 512)               # boot sector
    elif zona < 0.4: p = random.randrange(512, heap)            # FAT etc.
    else: p = random.randrange(heap, min(len(b), heap + 600000))  # inicio do heap (bitmap, up-case, raiz, pastas)
    b[p] = random.randrange(256)
  open('%s/fuzz_%03d.exfat' % (sys.argv[2], i), 'wb').write(b)
P
for i in $(seq -f %03g 0 299); do
  for f in sce_sys/param.json muitos/arquivo_numero_00600_comprido.bin; do
    r=$(timeout 60 $BIN $T/fuzz_$i.exfat $f 2>&1)
    if [[ "$r" == ret=* ]]; then ok; else falha "fuzz $i $f -> $r"; fi
  done
  rm -f $T/fuzz_$i.exfat
done

echo "== resultado: $OKS ok, $FALHAS falhas"
[ $FALHAS -eq 0 ]
