#!/bin/bash
# Testa copiar / mover / excluir / cancelar da versao de PC do payload no WSL.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_tarefas.sh
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8797
U="http://127.0.0.1:$PORTA"
ok=0; falhou=0
confere() { if echo "$2" | grep -q -- "$3"; then echo "OK   $1"; ok=$((ok+1)); else echo "FALHOU $1 -> $2"; falhou=$((falhou+1)); fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
espera() {  # espera a fila esvaziar
  for i in $(seq 1 120); do curl -s $U/api/tarefas | grep -q '"estado":"\(fila\|rodando\)"' || return; sleep 0.5; done
}

A=/root/glr-t/a; B=/root/glr-t/b; C=/dev/shm/glr-c   # C fica em outro disco (tmpfs)
rm -rf /root/glr-t $C /root/glr-dados-t; mkdir -p $A $B $C
head -c $((200*1024*1024)) /dev/urandom > "$A/PPSA08329-app.pkg"
head -c $((50*1024*1024)) /dev/urandom > "$A/CUSA07408.pkg"
head -c 1000 /dev/urandom > "$A/apagar.pkg"
head -c 1000 /dev/urandom > "$B/existe.pkg"
truncate -s $((3*1024*1024*1024)) "$A/grande.pkg"
truncate -s $((900*1024*1024*1024)) "$A/enorme.pkg"
MD5=$(md5sum "$A/PPSA08329-app.pkg" | cut -d' ' -f1)

"$BIN" -p $PORTA -d /root/glr-dados-t > /tmp/glr-t.log 2>&1 &
PID=$!; sleep 1

confere "sem X-GLR"        "$(curl -s -o /dev/null -w '%{http_code}' -d "tipo=excluir&pasta=$A&de=apagar.pkg" $U/api/tarefas)" "403"
confere "copiar renomeando" "$(post --data-urlencode tipo=copiar --data-urlencode destino=$B --data-urlencode pasta=$A --data-urlencode de=PPSA08329-app.pkg --data-urlencode para=God_of_War_Ragnarok-PPSA08329-US-PS5.pkg $U/api/tarefas)" '"criadas":1'
espera
confere "copia feita"      "$(curl -s $U/api/tarefas)" '"tipo":"copiar","estado":"feita"'
confere "copia confere"    "$(md5sum "$B/God_of_War_Ragnarok-PPSA08329-US-PS5.pkg" | cut -d' ' -f1)" "$MD5"
confere "origem ficou"     "$(ls $A)" "PPSA08329-app.pkg"
confere "sem .part"        "$(ls $B | grep -c part)" "^0$"
confere "copiar p/ existente" "$(post -d tipo=copiar -d destino=$B -d pasta=$A -d de=apagar.pkg -d para=existe.pkg $U/api/tarefas; espera; curl -s $U/api/tarefas)" "ja existe 'existe.pkg' no destino"
confere "mesma pasta recusa" "$(post -d tipo=copiar -d destino=$A -d pasta=$A -d de=apagar.pkg $U/api/tarefas)" '"recusadas":1'
confere "mesma pasta c/ nome novo recusa" "$(post -d tipo=mover -d destino=$A -d pasta=$A -d de=apagar.pkg -d para=outro.pkg $U/api/tarefas)" '"recusadas":1'
confere "mover outro disco" "$(post -d tipo=mover -d destino=$C -d pasta=$A -d de=CUSA07408.pkg $U/api/tarefas; espera; ls $C; ls $A)" "CUSA07408.pkg"
confere "origem apagada"   "$(ls $A | grep -c CUSA07408)" "^0$"
confere "mover mesmo disco" "$(post -d tipo=mover -d destino=$B -d pasta=$A -d de=PPSA08329-app.pkg $U/api/tarefas; espera; ls $B)" "PPSA08329-app.pkg"
confere "sem espaco"       "$(post -d tipo=copiar -d destino=$C -d pasta=$A -d de=enorme.pkg $U/api/tarefas; espera; curl -s $U/api/tarefas)" "sem espaco no destino"
confere "excluir"          "$(post -d tipo=excluir -d pasta=$A -d de=apagar.pkg $U/api/tarefas >/dev/null; espera; ls $A | grep -c apagar)" "^0$"
ID=$(post -d tipo=copiar -d destino=$B -d pasta=$A -d de=grande.pkg $U/api/tarefas >/dev/null; curl -s $U/api/tarefas | grep -o '"id":[0-9]*,"tipo":"copiar","estado":"\(fila\|rodando\)"' | grep -o '[0-9]*' | head -1)
sleep 0.5
confere "cancelar"         "$(post -d id=$ID $U/api/tarefas/cancelar)" '"ok":true'
espera
confere "cancelada"        "$(curl -s $U/api/tarefas)" '"estado":"cancelada"'
confere "cancelada sem lixo" "$(ls $B | grep -c grande)" "^0$"
confere "espaco"           "$(curl -s "$U/api/espaco?caminho=$C")" '"livre":'
confere "limpar"           "$(post -X POST $U/api/tarefas/limpar; curl -s $U/api/tarefas)" '"tarefas":\[\]'
confere "nome com /"       "$(post -d tipo=excluir -d pasta=$A -d de=../etc/passwd $U/api/tarefas)" '"criadas":0'

kill $PID; rm -rf /root/glr-t $C /root/glr-dados-t
echo "=== $ok ok, $falhou falharam"
echo "--- log:"; cat /tmp/glr-t.log
