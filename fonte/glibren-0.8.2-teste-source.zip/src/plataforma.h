/* Game Library Renamer (payload PS5) - o que muda entre PS5 e PC: notificacao, IP e permissoes. */
#pragma once

#include <stddef.h>

/* Permissoes, nome do processo, copias antigas, diario (pasta_dados/glibren.log) e aviso de queda. */
void plataforma_iniciar(const char *pasta_dados);
/* Cria/atualiza o icone na aba Midia (abre http://127.0.0.1:porta). So no PS5; roda numa thread. */
void plataforma_instalar_icone(int porta);
/* Linha no diario (com data e hora). */
void diario(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
void notificar(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
/* Primeiro IPv4 da rede (sem o 127.x). Devolve 0 se achou. */
int meu_ip(char *saida, size_t tam);
/* Abre o app (title_id, ex.: "PPSA99350") em primeiro plano, sem fechar o que estiver aberto. So no PS5; no PC
   so registra no diario. 0 = o sistema aceitou; senao o codigo do PS5 (negativo). */
int abrir_app(const char *title_id);
