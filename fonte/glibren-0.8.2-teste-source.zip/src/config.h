/* Game Library Renamer (payload PS5) - configuracao (idioma e pastas), gravada no PS5. */
#pragma once

#include "util.h"

#define MAX_PASTAS 32

extern char g_pasta_dados[512];   /* /data/GameLibraryRenamer no PS5 */

void config_iniciar(const char *pasta_dados);
/* Copia as pastas e o idioma atuais (thread-safe). Devolve a quantidade de pastas. */
int config_ler(char pastas[MAX_PASTAS][1024], char idioma[16]);
/* Grava; pastas NULL mantem as atuais, idioma NULL mantem o atual. Devolve 0 ou -1. */
int config_gravar(char (*pastas)[1024], int qtd, const char *idioma);
void config_json(buf_t *b);   /* "idioma":"..","pastas":[..] (sem chaves em volta) */
