/* Game Library Renamer (payload PS5) - fila de tarefas: copiar, mover e excluir arquivos.
   Uma tarefa por vez, numa thread propria (continua com a tela fechada). */
#pragma once

#include "util.h"

typedef enum { TAR_COPIAR, TAR_MOVER, TAR_EXCLUIR } tarefa_tipo_t;

void tarefas_iniciar(void);
/* Poe na fila. destino: pasta (ignorada no excluir); para: nome no destino ("" = mesmo nome).
   Devolve o id (> 0) ou 0 se os dados forem invalidos. */
int tarefas_adicionar(tarefa_tipo_t tipo, const char *pasta, const char *nome, const char *destino, const char *para);
int tarefas_cancelar(int id);      /* 0 = ok, -1 = nao achou ou ja terminou */
void tarefas_limpar_terminadas(void);
void tarefas_json(buf_t *b);       /* {"ok":true,"tarefas":[...]} */
