/* Game Library Renamer (payload PS5) - configuracao.

Arquivo <pasta de dados>/config.ini:
  language = pt-BR
  folder = /data/homebrew/
  folder = /mnt/ext1/homebrew/
*/
#include "config.h"

#include <pthread.h>
#include <stdio.h>
#include <string.h>

char g_pasta_dados[512];

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static char g_pastas[MAX_PASTAS][1024];
static int g_qtd;
static char g_idioma[16] = "pt-BR";

static const char *PADRAO[] = {"/data/homebrew/", "/mnt/ext1/homebrew/"};

static void arquivo(char *saida, size_t tam) {
  snprintf(saida, tam, "%s/config.ini", g_pasta_dados);
}

static int idioma_valido(const char *idioma) {
  return !strcmp(idioma, "pt-BR") || !strcmp(idioma, "en") || !strcmp(idioma, "es");
}

static void aparar(char *s) {
  size_t n = strlen(s);
  while(n && (s[n - 1] == '\n' || s[n - 1] == '\r' || s[n - 1] == ' ' || s[n - 1] == '\t')) s[--n] = 0;
}

static int gravar_arquivo(void) {
  char nome[600], tmp[610];
  arquivo(nome, sizeof nome);
  snprintf(tmp, sizeof tmp, "%s.tmp", nome);
  FILE *f = fopen(tmp, "w");
  if(!f) return -1;
  fprintf(f, "; Game Library Renamer (payload PS5)\nlanguage = %s\n", g_idioma);
  for(int i = 0; i < g_qtd; i++) fprintf(f, "folder = %s\n", g_pastas[i]);
  if(fclose(f)) return -1;
  return rename(tmp, nome);
}

void config_iniciar(const char *pasta_dados) {
  snprintf(g_pasta_dados, sizeof g_pasta_dados, "%s", pasta_dados);
  mkdir_p(g_pasta_dados);

  char nome[600], linha[1200];
  arquivo(nome, sizeof nome);
  pthread_mutex_lock(&g_trava);
  FILE *f = fopen(nome, "r");
  if(!f) {
    g_qtd = 0;
    for(size_t i = 0; i < sizeof PADRAO / sizeof *PADRAO; i++) snprintf(g_pastas[g_qtd++], 1024, "%s", PADRAO[i]);
    gravar_arquivo();
  } else {
    g_qtd = 0;
    while(fgets(linha, sizeof linha, f)) {
      aparar(linha);
      char *igual = strchr(linha, '=');
      if(linha[0] == ';' || !igual) continue;
      char *valor = igual + 1;
      while(*valor == ' ') valor++;
      *igual = 0;
      aparar(linha);
      if(!strcmp(linha, "language") && idioma_valido(valor)) snprintf(g_idioma, sizeof g_idioma, "%s", valor);
      else if(!strcmp(linha, "folder") && caminho_valido(valor) && g_qtd < MAX_PASTAS)
        snprintf(g_pastas[g_qtd++], 1024, "%s", valor);
    }
    fclose(f);
  }
  pthread_mutex_unlock(&g_trava);
}

int config_ler(char pastas[MAX_PASTAS][1024], char idioma[16]) {
  pthread_mutex_lock(&g_trava);
  int qtd = g_qtd;
  if(pastas) memcpy(pastas, g_pastas, sizeof g_pastas);
  if(idioma) memcpy(idioma, g_idioma, sizeof g_idioma);
  pthread_mutex_unlock(&g_trava);
  return qtd;
}

int config_gravar(char (*pastas)[1024], int qtd, const char *idioma) {
  if(idioma && !idioma_valido(idioma)) return -1;
  if(pastas) {
    if(qtd > MAX_PASTAS) return -1;
    for(int i = 0; i < qtd; i++) {
      if(!caminho_valido(pastas[i])) return -1;
    }
  }
  pthread_mutex_lock(&g_trava);
  if(idioma) snprintf(g_idioma, sizeof g_idioma, "%s", idioma);
  if(pastas) {
    /* sem repetidas, na ordem recebida */
    g_qtd = 0;
    for(int i = 0; i < qtd; i++) {
      int repetida = 0;
      for(int j = 0; j < g_qtd; j++) repetida |= !strcmp(g_pastas[j], pastas[i]);
      if(!repetida) snprintf(g_pastas[g_qtd++], 1024, "%s", pastas[i]);
    }
  }
  int r = gravar_arquivo();
  pthread_mutex_unlock(&g_trava);
  return r;
}

void config_json(buf_t *b) {
  char pastas[MAX_PASTAS][1024], idioma[16];
  int qtd = config_ler(pastas, idioma);
  buf_str(b, "\"idioma\":");
  buf_json(b, idioma);
  buf_str(b, ",\"pastas\":[");
  for(int i = 0; i < qtd; i++) {
    if(i) buf_str(b, ",");
    buf_json(b, pastas[i]);
  }
  buf_str(b, "]");
}
