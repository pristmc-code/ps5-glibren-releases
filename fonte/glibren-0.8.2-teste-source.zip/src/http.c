/* Game Library Renamer (payload PS5) - servidor HTTP minimo. */
#include "http.h"

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <unistd.h>

#define MAX_CABECALHO (16 * 1024)
#define MAX_CORPO (8 * 1024 * 1024)

static tratador_t g_tratador;
static volatile int g_parar;
static int g_srvfd = -1;

static const char *texto_status(int status) {
  switch(status) {
  case 200: return "OK";
  case 304: return "Not Modified";
  case 400: return "Bad Request";
  case 403: return "Forbidden";
  case 404: return "Not Found";
  case 405: return "Method Not Allowed";
  case 413: return "Payload Too Large";
  case 500: return "Internal Server Error";
  case 502: return "Bad Gateway";
  default: return "OK";
  }
}

static int enviar_tudo(int fd, const void *dados, size_t n) {
  const char *p = dados;
  while(n) {
    ssize_t r = send(fd, p, n, 0);
    if(r < 0 && errno == EINTR) continue;
    if(r <= 0) return -1;
    p += r;
    n -= r;
  }
  return 0;
}

static void cabecalho(pedido_t *p, int status, const char *tipo, size_t n, const char *cache, const char *extra) {
  char cab[1024];
  int len = snprintf(cab, sizeof cab,
                     "HTTP/1.1 %d %s\r\nContent-Type: %s\r\nContent-Length: %zu\r\n"
                     "Cache-Control: %s\r\nX-Content-Type-Options: nosniff\r\n"
                     /* o player embutido do YouTube exige referrer valido (sem isso: Erro 153) */
                     "Referrer-Policy: strict-origin-when-cross-origin\r\n%sConnection: close\r\n\r\n",
                     status, texto_status(status), tipo, n, cache ? cache : "no-store", extra ? extra : "");
  enviar_tudo(p->fd, cab, len);
}

void responder(pedido_t *p, int status, const char *tipo, const void *corpo, size_t n, const char *cache) {
  cabecalho(p, status, tipo, n, cache, NULL);
  if(n && strcmp(p->metodo, "HEAD")) enviar_tudo(p->fd, corpo, n);
}

void responder_pagina(pedido_t *p, const void *normal, size_t n_normal, const void *gz, size_t n_gz) {
  const char *tipo = "text/html; charset=utf-8";
  if(p->aceita_gzip && gz && n_gz) {
    cabecalho(p, 200, tipo, n_gz, NULL, "Content-Encoding: gzip\r\nVary: Accept-Encoding\r\n");
    if(strcmp(p->metodo, "HEAD")) enviar_tudo(p->fd, gz, n_gz);
  } else {
    responder(p, 200, tipo, normal, n_normal, NULL);
  }
}

void responder_json(pedido_t *p, int status, buf_t *json) {
  responder(p, status, "application/json; charset=utf-8", json->d, json->n, NULL);
}

void responder_erro(pedido_t *p, int status, const char *chave, const char *mensagem, const char *nome) {
  buf_t b = {0};
  buf_str(&b, "{\"ok\":false,\"chave\":");
  buf_json(&b, chave);
  buf_str(&b, ",\"erro\":");
  buf_json(&b, mensagem);
  buf_str(&b, ",\"params\":{");
  if(nome) {
    buf_str(&b, "\"nome\":");
    buf_json(&b, nome);
  }
  buf_str(&b, "}}");
  responder_json(p, status, &b);
  buf_free(&b);
}

int responder_arquivo(pedido_t *p, const char *arquivo, const char *tipo, const char *cache) {
  struct stat st;
  int fd = open(arquivo, O_RDONLY);
  if(fd < 0) return -1;
  if(fstat(fd, &st) || !S_ISREG(st.st_mode)) {
    close(fd);
    return -1;
  }
  char etag[64], extra[128];
  snprintf(etag, sizeof etag, "\"%llx-%llx\"", (unsigned long long)st.st_size, (unsigned long long)st.st_mtime);
  snprintf(extra, sizeof extra, "ETag: %s\r\n", etag);
  if(!strcmp(p->se_nao_mudou, etag)) {
    cabecalho(p, 304, tipo, 0, cache, extra);
    close(fd);
    return 0;
  }
  cabecalho(p, 200, tipo, st.st_size, cache, extra);
  if(strcmp(p->metodo, "HEAD")) {
    char bloco[64 * 1024];
    ssize_t r;
    while((r = read(fd, bloco, sizeof bloco)) > 0) {
      if(enviar_tudo(p->fd, bloco, r)) break;
    }
  }
  close(fd);
  return 0;
}

static void decodificar_caminho(char *s) {
  char *o = s;
  for(char *i = s; *i; i++) {
    if(*i == '%' && i[1] && i[2]) {
      char hex[3] = {i[1], i[2], 0};
      char *fim;
      long v = strtol(hex, &fim, 16);
      if(!*fim) {
        *o++ = (char)v;
        i += 2;
        continue;
      }
    }
    *o++ = *i;
  }
  *o = 0;
}

static void valor_cabecalho(const char *cabs, const char *nome, char *saida, size_t tam) {
  size_t tam_nome = strlen(nome);
  saida[0] = 0;
  for(const char *l = cabs; l && *l; l = strstr(l, "\r\n") ? strstr(l, "\r\n") + 2 : NULL) {
    if(!strncasecmp(l, nome, tam_nome) && l[tam_nome] == ':') {
      const char *v = l + tam_nome + 1;
      while(*v == ' ') v++;
      size_t n = strcspn(v, "\r\n");
      if(n >= tam) n = tam - 1;
      memcpy(saida, v, n);
      saida[n] = 0;
      return;
    }
  }
}

static void *atender(void *arg) {
  int fd = (int)(intptr_t)arg;
  pedido_t p = {.fd = fd};
  char *buf = malloc(MAX_CABECALHO + 1);
  size_t n = 0;
  char *fim = NULL;

  struct timeval espera = {.tv_sec = 30};
  setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &espera, sizeof espera);
  setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &espera, sizeof espera);

  while(!fim && n < MAX_CABECALHO) {
    ssize_t r = recv(fd, buf + n, MAX_CABECALHO - n, 0);
    if(r < 0 && errno == EINTR) continue;
    if(r <= 0) goto sair;
    n += r;
    buf[n] = 0;
    fim = strstr(buf, "\r\n\r\n");
  }
  if(!fim) goto sair;
  *fim = 0;

  /* Linha do pedido: METODO /caminho?query HTTP/1.1 */
  char alvo[sizeof p.caminho + sizeof p.query];
  if(sscanf(buf, "%7s %5119s", p.metodo, alvo) != 2) goto sair;
  char *q = strchr(alvo, '?');
  if(q) {
    *q = 0;
    snprintf(p.query, sizeof p.query, "%s", q + 1);
  }
  snprintf(p.caminho, sizeof p.caminho, "%s", alvo);
  decodificar_caminho(p.caminho);

  const char *cabs = strstr(buf, "\r\n") ? strstr(buf, "\r\n") + 2 : "";
  char tmp[64];
  valor_cabecalho(cabs, "Content-Type", p.tipo, sizeof p.tipo);
  valor_cabecalho(cabs, "If-None-Match", p.se_nao_mudou, sizeof p.se_nao_mudou);
  valor_cabecalho(cabs, "X-GLR", tmp, sizeof tmp);
  p.pedido_do_app = tmp[0] != 0;
  char codificacao[160];
  valor_cabecalho(cabs, "Accept-Encoding", codificacao, sizeof codificacao);
  p.aceita_gzip = strstr(codificacao, "gzip") != NULL;
  valor_cabecalho(cabs, "Content-Length", tmp, sizeof tmp);
  size_t tam_corpo = strtoul(tmp, NULL, 10);

  if(tam_corpo > MAX_CORPO) {
    responder_erro(&p, 413, "corpo_grande", "pedido grande demais", NULL);
    goto sair;
  }
  if(tam_corpo) {
    p.corpo = malloc(tam_corpo + 1);
    size_t ja = n - (fim + 4 - buf);
    if(ja > tam_corpo) ja = tam_corpo;
    memcpy(p.corpo, fim + 4, ja);
    while(ja < tam_corpo) {
      ssize_t r = recv(fd, p.corpo + ja, tam_corpo - ja, 0);
      if(r < 0 && errno == EINTR) continue;
      if(r <= 0) goto sair;
      ja += r;
    }
    p.corpo[tam_corpo] = 0;
    p.corpo_n = tam_corpo;
  }

  g_tratador(&p);

sair:
  free(p.corpo);
  free(buf);
  /* Fechamento gradual: com Content-Length o navegador sabe onde a resposta acaba e fecha a conexao sozinho;
     espera esse fechamento (ate 2 s) antes do close(). Mandar o fim (FIN/RST) logo atras dos dados fazia
     algumas redes perderem os ultimos bytes (ERR_CONTENT_LENGTH_MISMATCH: pagina ou consulta incompleta). */
  struct timeval curto = {.tv_sec = 2};
  setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &curto, sizeof curto);
  char resto[1024];
  while(recv(fd, resto, sizeof resto, 0) > 0) {}
  close(fd);
  return NULL;
}

static int abrir(int porta) {
  int srv = socket(AF_INET, SOCK_STREAM, 0);
  if(srv < 0) return -1;
  setsockopt(srv, SOL_SOCKET, SO_REUSEADDR, &(int){1}, sizeof(int));
  struct sockaddr_in end = {0};
  end.sin_family = AF_INET;
  end.sin_addr.s_addr = htonl(INADDR_ANY);
  end.sin_port = htons(porta);
  if(bind(srv, (struct sockaddr *)&end, sizeof end) || listen(srv, 32)) {
    int erro = errno;
    close(srv);
    errno = erro;
    return -1;
  }
  return srv;
}

int servidor_rodar(int porta, tratador_t tratador) {
  g_tratador = tratador;
  int srv = abrir(porta);
  if(srv < 0) return -1;
  g_srvfd = srv;
  int falhas = 0;

  while(!g_parar) {
    int fd = accept(srv, NULL, NULL);
    if(fd < 0) {
      if(errno == EINTR) continue;
      if(g_parar) break;
      if(errno == EINVAL || errno == ECONNABORTED || errno == EBADF) falhas = 19;   /* socket derrubado: reabre ja */
      /* Depois do modo de repouso a rede volta e o socket antigo pode ficar inutil: reabre a porta. */
      if(++falhas >= 20) {
        close(srv);
        g_srvfd = -1;
        for(int i = 0; i < 60 && !g_parar && (srv = abrir(porta)) < 0; i++) sleep(1);
        if(srv < 0) return -1;
        g_srvfd = srv;
        falhas = 0;
        continue;
      }
      usleep(100000);
      continue;
    }
    falhas = 0;
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &(int){1}, sizeof(int));
#ifdef SO_NOSIGPIPE
    setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &(int){1}, sizeof(int));   /* navegador fechou: erro, nao queda */
#endif
    if(criar_thread(atender, (void *)(intptr_t)fd, NULL)) close(fd);   /* pilha de 1 MB (buffers de 64 KB) */
  }
  close(srv);
  g_srvfd = -1;
  return 0;
}

void servidor_reabrir(void) {
  /* volta do modo de repouso: derruba o socket de escuta; o laco do accept percebe e abre a porta de novo */
  if(g_srvfd >= 0) shutdown(g_srvfd, SHUT_RDWR);
}

void servidor_parar(void) {
  g_parar = 1;
  if(g_srvfd >= 0) shutdown(g_srvfd, SHUT_RDWR);
}
