/* Game Library Renamer (payload PS5) - temperaturas, ventoinha e alerta.

Leitura (sempre funciona): sceKernelGetCpuTemperature, sceKernelGetSocSensorTemperature (canal 0 = SoC,
canal 2 = SSD M.2; slot vazio le ~0, so vale de 20 C para cima) e sceKernelGetCurrentFanDuty (0..1024).
Ventoinha (precisa do kstuff): /dev/icc_fan, ioctl de leitura/gravacao do perfil "autoservo" (28 bytes; o
byte 5 e a temperatura em que ela acelera). O sistema volta ao perfil dele ao abrir jogos, por isso o limite
escolhido e reaplicado a cada 15 s. Faixa permitida 50..85 C.
(As chamadas do sistema foram levantadas lendo o ProsperoMgr; este codigo e proprio.)

No PC (teste) os valores sao simulados.
*/
#include "termico.h"

#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <time.h>
#include <unistd.h>

#include "config.h"
#include "plataforma.h"
#include "sistema.h"

#define INTERVALO_S 2
#define HISTORICO 450               /* 15 min com uma leitura a cada 2 s */
#define REAPLICAR_S 2      /* o firmware desfaz o limite logo depois (onionHEN issue #40): confere a cada 2 s, so grava se mudou */
#define LIMITE_MIN 50
#define LIMITE_MAX 85
#define ALERTA_REPETIR_S 300        /* no maximo um alerta a cada 5 min */

#define ICC_FAN "/dev/icc_fan"
#define ICC_FAN_GRAVAR 0xC01C8F07ul
#define ICC_FAN_LER 0xC01C8F08ul
#define PERFIL_TAM 28
#define PERFIL_ALVO 5

typedef struct {
  time_t quando;
  signed char cpu, soc, m2, ventoinha;   /* -1 = sem leitura */
} amostra_t;

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static amostra_t g_hist[HISTORICO];
static int g_inicio, g_qtd;
static amostra_t g_atual = {0, -1, -1, -1, -1};
static int g_max_cpu = -1, g_max_soc = -1, g_max_m2 = -1;
static int g_limite;        /* 0 = automatico */
static int g_alerta;        /* 0 = desligado */
static char g_erro_limite[160];
static int g_alvo_fabrica = -1;   /* alvo do sistema lido antes de qualquer mudanca (nunca passamos dele) */
static int g_falhas;              /* reaplicacoes seguidas que falharam */
static int g_ultimo_aplicado;     /* ultimo limite que NOS gravamos (para reconhecer outro programa mexendo) */
static int g_conflito;            /* 1 = outro programa (ex.: ProsperoMgr) controla a ventoinha */
#define MAX_FALHAS 5
static time_t g_ultimo_alerta;

/* ------------------------------------------------------------------ sensores */

#ifdef __PROSPERO__
int sceKernelGetCpuTemperature(int *);
int sceKernelGetSocSensorTemperature(int, int *);
int sceKernelGetCurrentFanDuty(uint16_t *, uint64_t *);

static void ler_sensores(amostra_t *a) {
  int v;
  uint16_t duty = 0;
  uint64_t chassi = 0;
  a->cpu = (!sceKernelGetCpuTemperature(&v) && v >= 0 && v <= 130) ? v : -1;
  a->soc = (!sceKernelGetSocSensorTemperature(0, &v) && v >= 0 && v <= 130) ? v : -1;
  a->m2 = (!sceKernelGetSocSensorTemperature(2, &v) && v >= 20 && v <= 130) ? v : -1;
  a->ventoinha = !sceKernelGetCurrentFanDuty(&duty, &chassi) ? (duty * 100 + 512) / 1024 : -1;
  if(a->ventoinha > 100) a->ventoinha = 100;
}

static int ler_perfil(int fd, uint8_t perfil[PERFIL_TAM]) {
  memset(perfil, 0, PERFIL_TAM);
  return ioctl(fd, ICC_FAN_LER, perfil);
}

/* Grava o limite na ventoinha (se ja nao estiver). 0 ou -1 com a mensagem em g_erro_limite. */
static int aplicar_limite(int celsius) {
  uint8_t perfil[PERFIL_TAM], conferido[PERFIL_TAM];
  int fd = open(ICC_FAN, O_RDWR);
  if(fd < 0) {
    snprintf(g_erro_limite, sizeof g_erro_limite, "sem acesso a ventoinha (o kstuff esta carregado?): %s", strerror(errno));
    return -1;
  }
  int r = -1;
  if(ler_perfil(fd, perfil)) snprintf(g_erro_limite, sizeof g_erro_limite, "nao leu a ventoinha: %s", strerror(errno));
  else if(g_alvo_fabrica > 0 && celsius > g_alvo_fabrica)
    snprintf(g_erro_limite, sizeof g_erro_limite, "o limite nao pode passar do valor do sistema (%d C)", g_alvo_fabrica);
  else if(g_alvo_fabrica > 0 && perfil[PERFIL_ALVO] != g_alvo_fabrica && perfil[PERFIL_ALVO] != g_ultimo_aplicado &&
          perfil[PERFIL_ALVO] != celsius) {
    /* nem o valor do sistema nem o nosso: outro programa (ex.: ProsperoMgr) esta controlando - nao briga com ele */
    g_conflito = perfil[PERFIL_ALVO];
    snprintf(g_erro_limite, sizeof g_erro_limite, "outro programa ja controla a ventoinha (%d C); desligue o controle dele ou use so o dele",
             perfil[PERFIL_ALVO]);
  }
  else if(perfil[PERFIL_ALVO] == celsius) r = 0;
  else {
    perfil[PERFIL_ALVO] = (uint8_t)celsius;
    if(ioctl(fd, ICC_FAN_GRAVAR, perfil)) snprintf(g_erro_limite, sizeof g_erro_limite, "nao gravou na ventoinha: %s", strerror(errno));
    else if(ler_perfil(fd, conferido) || conferido[PERFIL_ALVO] != celsius)
      snprintf(g_erro_limite, sizeof g_erro_limite, "a ventoinha recusou o limite");
    else r = 0;
  }
  if(!r) {
    g_ultimo_aplicado = celsius;
    g_conflito = 0;
  }
  close(fd);
  if(!r) g_erro_limite[0] = 0;
  return r;
}

/* Le o alvo do proprio sistema (varia por placa: 91, 86, 69 C...) antes de qualquer mudanca nossa. */
static void ler_alvo_sistema(void) {
  uint8_t perfil[PERFIL_TAM];
  int fd = open(ICC_FAN, O_RDWR);
  if(fd < 0) return;
  if(!ler_perfil(fd, perfil) && perfil[PERFIL_ALVO] > 0 && perfil[PERFIL_ALVO] != g_limite) g_alvo_fabrica = perfil[PERFIL_ALVO];
  close(fd);
}
#else
/* PC: valores simulados (variam devagar, como num jogo). */
static void ler_sensores(amostra_t *a) {
  static double t;
  t += 0.07;
  double carga = 0.5 + 0.5 * sin(t) * sin(t * 0.37);
  a->cpu = (signed char)(52 + 26 * carga + rand() % 3);
  a->soc = (signed char)(a->cpu - 4 + rand() % 3);
  a->m2 = (signed char)(44 + 8 * carga);
  int base = g_limite ? (a->cpu > g_limite ? 70 : 35) : 30 + (int)(40 * carga);
  a->ventoinha = (signed char)(base + rand() % 4);
}

static int aplicar_limite(int celsius) {
  if(g_alvo_fabrica > 0 && celsius > g_alvo_fabrica) {
    snprintf(g_erro_limite, sizeof g_erro_limite, "o limite nao pode passar do valor do sistema (%d C)", g_alvo_fabrica);
    return -1;
  }
  g_erro_limite[0] = 0;
  g_ultimo_aplicado = celsius;
  g_conflito = 0;
  return 0;
}

static void ler_alvo_sistema(void) { g_alvo_fabrica = 80; }   /* PC: valor simulado */
#endif

/* ------------------------------------------------------------------ configuracao (limite e alerta) */

static void arquivo(char *saida, size_t tam) {
  snprintf(saida, tam, "%s/temperatura.txt", g_pasta_dados);
}

static void gravar_config(void) {
  char nome[600];
  arquivo(nome, sizeof nome);
  FILE *f = fopen(nome, "w");
  if(f) {
    fprintf(f, "fan_threshold = %d\nalert = %d\n", g_limite, g_alerta);
    fclose(f);
  }
}

static void ler_config(void) {
  char nome[600], linha[128];
  arquivo(nome, sizeof nome);
  FILE *f = fopen(nome, "r");
  if(!f) return;
  while(fgets(linha, sizeof linha, f)) {
    int v;
    if(sscanf(linha, "fan_threshold = %d", &v) == 1 && (v == 0 || (v >= LIMITE_MIN && v <= LIMITE_MAX))) g_limite = v;
    if(sscanf(linha, "alert = %d", &v) == 1 && (v == 0 || (v >= 50 && v <= 100))) g_alerta = v;
  }
  fclose(f);
}

/* ------------------------------------------------------------------ thread */

static void *vigiar(void *arg) {
  (void)arg;
  ler_alvo_sistema();
  int desde_reaplicar = REAPLICAR_S;
  for(;;) {
    amostra_t a = {time(NULL), -1, -1, -1, -1};
    ler_sensores(&a);
    pthread_mutex_lock(&g_trava);
    g_atual = a;
    g_hist[(g_inicio + g_qtd) % HISTORICO] = a;
    if(g_qtd < HISTORICO) g_qtd++;
    else g_inicio = (g_inicio + 1) % HISTORICO;
    if(a.cpu > g_max_cpu) g_max_cpu = a.cpu;
    if(a.soc > g_max_soc) g_max_soc = a.soc;
    if(a.m2 > g_max_m2) g_max_m2 = a.m2;
    int limite = g_limite, alerta = g_alerta;
    pthread_mutex_unlock(&g_trava);

    /* o sistema desfaz o limite ao abrir jogos: reaplica de tempos em tempos */
    desde_reaplicar += INTERVALO_S;
    if(limite && desde_reaplicar >= REAPLICAR_S) {
      desde_reaplicar = 0;
      pthread_mutex_lock(&g_trava);
      if(aplicar_limite(limite) == 0) g_falhas = 0;
      else if(g_conflito) {
        g_limite = 0;
        g_falhas = 0;
        gravar_config();
        notificar("Game Library Renamer: outro programa controla a ventoinha (%d C); o nosso voltou ao automatico", g_conflito);
      } else if(++g_falhas >= MAX_FALHAS) {
        /* falhou varias vezes seguidas: volta ao automatico do sistema e avisa */
        g_limite = 0;
        g_falhas = 0;
        gravar_config();
        notificar("Game Library Renamer: ventoinha voltou ao automatico (%s)", g_erro_limite);
      }
      pthread_mutex_unlock(&g_trava);
    }

    int quente = a.cpu > a.soc ? a.cpu : a.soc;
    if(a.m2 > quente) quente = a.m2;
    if(alerta && quente >= alerta && time(NULL) - g_ultimo_alerta >= ALERTA_REPETIR_S) {
      g_ultimo_alerta = time(NULL);
      notificar("Game Library Renamer: PS5 a %d C (alerta em %d C)", quente, alerta);
    }
    sleep(INTERVALO_S);
  }
  return NULL;
}

void termico_iniciar(void) {
  ler_config();
  criar_thread(vigiar, NULL, NULL);
}

int termico_definir_limite(int celsius, char *msg, size_t tam) {
  if(celsius && (celsius < LIMITE_MIN || celsius > LIMITE_MAX)) {
    snprintf(msg, tam, "o limite deve ficar entre %d e %d C", LIMITE_MIN, LIMITE_MAX);
    return -1;
  }
  pthread_mutex_lock(&g_trava);
  int r = 0;
  if(celsius && aplicar_limite(celsius)) {
    snprintf(msg, tam, "%s", g_erro_limite);
    r = -1;
  } else {
    /* automatico: so para de reaplicar; o sistema volta ao perfil dele no proximo jogo/menu */
    g_limite = celsius;
    gravar_config();
  }
  pthread_mutex_unlock(&g_trava);
  return r;
}

int termico_definir_alerta(int celsius) {
  if(celsius && (celsius < 50 || celsius > 100)) return -1;
  pthread_mutex_lock(&g_trava);
  g_alerta = celsius;
  g_ultimo_alerta = 0;
  gravar_config();
  pthread_mutex_unlock(&g_trava);
  return 0;
}

void termico_json(buf_t *b, int com_historico) {
  pthread_mutex_lock(&g_trava);
  amostra_t a = g_atual;
  buf_fmt(b, "{\"ok\":true,\"alvo_sistema\":%d,\"cpu\":%d,\"soc\":%d,\"m2\":%d,\"ventoinha\":%d,\"max_cpu\":%d,\"max_soc\":%d,\"max_m2\":%d,"
          "\"limite\":%d,\"conflito\":%d,\"alerta\":%d,\"limite_min\":%d,\"limite_max\":%d,\"intervalo\":%d,\"erro_limite\":",
          g_alvo_fabrica, a.cpu, a.soc, a.m2, a.ventoinha, g_max_cpu, g_max_soc, g_max_m2, g_limite, g_conflito, g_alerta, LIMITE_MIN, LIMITE_MAX,
          INTERVALO_S);
  buf_json(b, g_erro_limite);
  if(com_historico) {
    /* [cpu, soc, m2, ventoinha] do mais antigo ao mais novo */
    buf_str(b, ",\"historico\":[");
    for(int i = 0; i < g_qtd; i++) {
      amostra_t *h = &g_hist[(g_inicio + i) % HISTORICO];
      buf_fmt(b, "%s[%d,%d,%d,%d]", i ? "," : "", h->cpu, h->soc, h->m2, h->ventoinha);
    }
    buf_str(b, "]");
  }
  pthread_mutex_unlock(&g_trava);
  buf_str(b, ",");
  sistema_json(b);
  buf_str(b, "}");
}
