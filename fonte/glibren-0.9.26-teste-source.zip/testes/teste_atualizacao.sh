#!/bin/bash
# Testa a atualizacao do proprio payload na versao de PC (0.9.12: R1, R3, R4, R10; 0.9.24: commit fixo e cache do
# "main" misturado, com nova tentativa - GLR_TESTE_ESPERA_CACHE): servidor local no lugar do GitHub
# (GLR_TESTE_BASE), chave de TESTE gerada na hora (GLR_TESTE_CHAVE - so no build de PC) e um elfldr de mentira
# (GLR_TESTE_ELFLDR) para a versao gravada que assume ao iniciar.
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_atualizacao.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
T=$(mktemp -d /tmp/glr-atual.XXXXXX)
PORTA=8782; PORTA_SRV=8783; PORTA_ELFLDR=8784
U="http://127.0.0.1:$PORTA"
BASE="http://127.0.0.1:$PORTA_SRV/"
DADOS=/root/glr-dados-atual; SRV="$T/srv"; A=/root/glr-atual-pasta
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
rm -rf "$DADOS" "$A"; mkdir -p "$SRV" "$DADOS" "$A"
VERSAO=$(grep -o '#define VERSAO "[^"]*"' "$ORIGEM/src/api.h" | cut -d'"' -f2)

python3 -I - "$T" <<'EOF'
import sys
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
k = Ed25519PrivateKey.generate()
open(sys.argv[1] + "/chave.pem", "wb").write(k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
open(sys.argv[1] + "/chave.hex", "w").write(k.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex())
EOF
CHAVE_HEX=$(cat "$T/chave.hex")
# $1 = arquivo .elf, $2 = versao no marcador (assinado com a chave de teste, .sig ao lado)
fazer_elf() { python3 -I - "$T/chave.pem" "$1" "$2" <<'EOF'
import sys, os
from cryptography.hazmat.primitives import serialization
k = serialization.load_pem_private_key(open(sys.argv[1], "rb").read(), None)
d = os.urandom(5000) + b"GLIBREN-VERSAO:" + sys.argv[3].encode() + b"\n" + os.urandom(5000)
open(sys.argv[2], "wb").write(d)
open(sys.argv[2] + ".sig", "wb").write(k.sign(d))
EOF
}
anunciar() { printf '{"versao": "%s", "notas": "teste"}\n' "$1" > "$SRV/versao.json"; }
estado() { curl -s "$U/api/atualizacao$1"; }
espera_fim() { for i in $(seq 1 60); do estado '' | grep -q '"rodando":false' && return; sleep 0.25; done; }

(cd "$SRV" && exec python3 -m http.server $PORTA_SRV --bind 127.0.0.1) > "$T/srv.log" 2>&1 &
PID_SRV=$!
printf 'language = pt-BR\nfolder = %s/\n' "$A" > "$DADOS/config.ini"
ESPERA_CACHE=1
inicia() { GLR_TESTE_ESPERA_CACHE=$ESPERA_CACHE GLR_TESTE_BASE="$BASE" GLR_TESTE_CHAVE="$CHAVE_HEX" "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!; sleep 1; }
anunciar 9.9.9; fazer_elf "$SRV/glibren.elf" 9.9.5
inicia

echo "--- R1: versao anunciada x marcador do .elf baixado"
confere "anuncio mais novo aparece"        "$(estado '?verificar=1')" '"nova":"9.9.9"'
confere "atualizar iniciou"                "$(post -X POST $U/api/atualizar)" '"ok":true'
espera_fim
confere "marcador diferente: msg clara"    "$(estado '')" 'o servidor de versoes ainda esta se atualizando (veio a 9.9.5, anunciada a 9.9.9): tente de novo em alguns minutos'
confere "marcador diferente: tentou 2 vezes" "$(grep -ac 'GET /glibren.elf ' $T/srv.log)" "^2$"
confere "recusado: nada gravado"           "$(ls $DADOS | grep -c 'glibren.elf')" "^0$"
anunciar 0.0.1
confere "anuncio mais velho nao aparece"   "$(estado '?verificar=1')" '"nova":""'
confere "anuncio mais velho: nao atualiza" "$(post -X POST $U/api/atualizar)" 'nenhuma versao nova'
anunciar "$VERSAO"
confere "anuncio igual nao aparece"        "$(estado '?verificar=1')" '"nova":""'

echo "--- R4: recusa com tarefa na fila"
anunciar 9.9.9; fazer_elf "$SRV/glibren.elf" 9.9.9
estado '?verificar=1' > /dev/null
truncate -s $((3*1024*1024*1024)) "$A/grande.pkg"; mkdir -p /root/glr-atual-destino
printf 'language = pt-BR\nfolder = %s/\nfolder = /root/glr-atual-destino/\n' "$A" > "$DADOS/config.ini"
kill $PID; wait $PID 2>/dev/null; inicia; estado '?verificar=1' > /dev/null
post -d tipo=copiar -d destino=/root/glr-atual-destino -d pasta=$A -d de=grande.pkg $U/api/tarefas > /dev/null
confere "com copia na fila: recusado"      "$(post -X POST $U/api/atualizar)" 'ha tarefas de copiar, mover ou excluir na fila'
post -X POST $U/api/tarefas/cancelar-todas > /dev/null
for i in $(seq 1 40); do curl -s $U/api/tarefas | grep -q '"estado":"\(fila\|rodando\)"' || break; sleep 0.25; done
confere "cancelar todas: nada rodando"     "$(curl -s $U/api/tarefas)" '"estado":"cancelada"'
rm -f "$A/grande.pkg"; rm -rf /root/glr-atual-destino

echo "--- R1/R10: versao certa e gravada"
confere "atualizar iniciou"                "$(post -X POST $U/api/atualizar)" '"ok":true'
espera_fim
confere "gravada sem erro"                 "$(estado '')" '"fase":"reiniciando","erro":""'
confere "elf gravado igual ao baixado"     "$(cmp "$SRV/glibren.elf" "$DADOS/glibren.elf" && cmp "$SRV/glibren.elf.sig" "$DADOS/glibren.elf.sig" && echo igual)" "igual"
confere "sem .part"                        "$(ls $DADOS | grep -c '\.part')" "^0$"

echo "--- 0.9.24: commit fixo (o main do servidor ainda esta com a versao velha - cache do raw do GitHub)"
COMMIT=0123456789abcdef0123456789abcdef01234567
# anunciar_ext versao commit sha tamanho (commit/sha vazios = campo ausente)
anunciar_ext() {
  { printf '{"versao": "%s", "notas": "teste"' "$1"
    [ -n "$4" ] && printf ', "tamanho": %s' "$4"
    [ -n "$3" ] && printf ', "sha256": "%s"' "$3"
    [ -n "$2" ] && printf ', "commit": "%s"' "$2"
    printf ', "commit_fonte": "fedcba9876543210fedcba9876543210fedcba98"}\n'; } > "$SRV/versao.json"
}
mkdir -p "$SRV/$COMMIT"; rm -f "$DADOS/glibren.elf" "$DADOS/glibren.elf.sig"
fazer_elf "$SRV/$COMMIT/glibren.elf" 9.9.9; fazer_elf "$SRV/glibren.elf" 9.9.8
SHA=$(sha256sum "$SRV/$COMMIT/glibren.elf" | cut -d' ' -f1); TAM=$(stat -c %s "$SRV/$COMMIT/glibren.elf")
anunciar_ext 9.9.9 $COMMIT $SHA $TAM; : > "$T/srv.log"
estado '?verificar=1' > /dev/null
confere "commit: atualizar iniciou"        "$(post -X POST $U/api/atualizar)" '"ok":true'
espera_fim
confere "commit: gravada sem erro"         "$(estado '')" '"fase":"reiniciando","erro":""'
confere "commit: gravou o .elf do commit"  "$(cmp "$SRV/$COMMIT/glibren.elf" "$DADOS/glibren.elf" && cmp "$SRV/$COMMIT/glibren.elf.sig" "$DADOS/glibren.elf.sig" && echo igual)" "igual"
confere "commit: baixou pelo commit"       "$(tr -d '\0' < $T/srv.log)" "GET /$COMMIT/glibren.elf "
confere "commit: nem tocou no main"        "$(grep -ac 'GET /glibren.elf' $T/srv.log)" "^0$"

echo "--- 0.9.24: commit fixo fora do ar (404): cai no main"
rm -rf "$SRV/$COMMIT"; rm -f "$DADOS/glibren.elf" "$DADOS/glibren.elf.sig"
fazer_elf "$SRV/glibren.elf" 9.9.9
SHA=$(sha256sum "$SRV/glibren.elf" | cut -d' ' -f1); TAM=$(stat -c %s "$SRV/glibren.elf")
anunciar_ext 9.9.9 $COMMIT $SHA $TAM; : > "$T/srv.log"
estado '?verificar=1' > /dev/null
post -X POST $U/api/atualizar > /dev/null; espera_fim
confere "404 no commit: gravada pelo main" "$(estado '')" '"fase":"reiniciando","erro":""'
confere "404 no commit: tentou o commit"   "$(tr -d '\0' < $T/srv.log)" "GET /$COMMIT/glibren.elf .* 404"
confere "404 no commit: .elf do main"      "$(cmp "$SRV/glibren.elf" "$DADOS/glibren.elf" && echo igual)" "igual"

echo "--- 0.9.24: sem commit (versao.json antigo) e main com sha diferente: tenta 2 vezes e explica"
rm -f "$DADOS/glibren.elf" "$DADOS/glibren.elf.sig"
anunciar_ext 9.9.9 "" $SHA $TAM; fazer_elf "$SRV/glibren.elf" 9.9.8; : > "$T/srv.log"
estado '?verificar=1' > /dev/null
post -X POST $U/api/atualizar > /dev/null; espera_fim
confere "sha diferente: msg clara"         "$(estado '')" 'o servidor de versoes ainda esta se atualizando (veio a 9.9.8, anunciada a 9.9.9): tente de novo em alguns minutos'
confere "sha diferente: 2 tentativas"      "$(grep -ac 'GET /glibren.elf ' $T/srv.log)" "^2$"
confere "sha diferente: nada gravado"      "$(ls $DADOS | grep -c 'glibren.elf')" "^0$"
confere "sha diferente: diario"            "$(cat $DADOS/glibren.log)" "main: sha256 .* (veio a 9.9.8)"
confere "sha diferente: sem commit no url" "$(grep -ac "GET /$COMMIT" $T/srv.log)" "^0$"

echo "--- 0.9.24: sem commit e o cache do main se resolve antes da segunda tentativa"
kill $PID; wait $PID 2>/dev/null; ESPERA_CACHE=4; inicia; ESPERA_CACHE=1
cp "$SRV/glibren.elf" "$T/velho.elf"; cp "$SRV/glibren.elf.sig" "$T/velho.elf.sig"
fazer_elf "$T/novo.elf" 9.9.9
SHA=$(sha256sum "$T/novo.elf" | cut -d' ' -f1); TAM=$(stat -c %s "$T/novo.elf")
anunciar_ext 9.9.9 "" $SHA $TAM
estado '?verificar=1' > /dev/null
post -X POST $U/api/atualizar > /dev/null; sleep 1.5
cp "$T/novo.elf" "$SRV/glibren.elf"; cp "$T/novo.elf.sig" "$SRV/glibren.elf.sig"   # o cache "se resolveu"
espera_fim
confere "cache resolvido: gravada"         "$(estado '')" '"fase":"reiniciando","erro":""'
confere "cache resolvido: .elf novo"       "$(cmp "$T/novo.elf" "$DADOS/glibren.elf" && echo igual)" "igual"
confere "cache resolvido: diario"          "$(cat $DADOS/glibren.log)" "o main ainda nao bate"

echo "--- 0.9.24: commit invalido no versao.json e ignorado (nao entra no endereco)"
rm -f "$DADOS/glibren.elf" "$DADOS/glibren.elf.sig"
anunciar_ext 9.9.9 "../../etc/passwd" $SHA $TAM; : > "$T/srv.log"
estado '?verificar=1' > /dev/null
post -X POST $U/api/atualizar > /dev/null; espera_fim
confere "commit invalido: gravada pelo main" "$(estado '')" '"fase":"reiniciando","erro":""'
confere "commit invalido: so o main"       "$(grep -ac 'GET /glibren.elf ' $T/srv.log)" "^1$"
kill $PID; wait $PID 2>/dev/null

echo "--- R3: a versao gravada nao responde na porta"
# elfldr de mentira: recebe o .elf; modo "responde" sobe um servidor na porta do payload dizendo a versao gravada
cat > "$T/elfldr.py" <<'EOF'
import socket, sys, http.server, threading, time
porta_elfldr, porta, modo, versao = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3], sys.argv[4]
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); s.bind(("127.0.0.1", porta_elfldr)); s.listen(1)
c, _ = s.accept(); n = 0
while True:
    d = c.recv(65536)
    if not d: break
    n += len(d)
c.close(); print("recebeu", n, flush=True)
if modo == "responde":
    class H(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            b = ('{"ok":true,"versao":"%s"}' % versao).encode()
            self.send_response(200); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
        def log_message(self, *a): pass
    srv = http.server.HTTPServer(("127.0.0.1", porta), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    time.sleep(8)
EOF
inicia_elfldr() {   # $1 modo
  python3 -I "$T/elfldr.py" $PORTA_ELFLDR $PORTA "$1" 9.9.9 > "$T/elfldr.log" 2>&1 & PID_EL=$!; sleep 0.5
  GLR_TESTE_ELFLDR=$PORTA_ELFLDR GLR_TESTE_ESPERA_NOVA=3 GLR_TESTE_CHAVE="$CHAVE_HEX" "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!
}
: > "$DADOS/glibren.log"
inicia_elfldr calado; sleep 6
confere "nao respondeu: esta segue rodando" "$(curl -s $U/api/estado)" "\"versao\":\"$VERSAO\""
confere "nao respondeu: elfldr recebeu"     "$(cat $T/elfldr.log)" "recebeu 10[0-9]*"
confere "nao respondeu: virou .ruim"        "$(ls $DADOS | tr '\n' ' ')" "glibren.elf.ruim glibren.elf.sig.ruim"
confere "nao respondeu: .elf saiu"          "$(ls $DADOS/glibren.elf 2>&1)" "No such"
confere "nao respondeu: diario"             "$(cat $DADOS/glibren.log)" "a 9.9.9 gravada nao respondeu na porta $PORTA em 3 s - virou"
kill $PID $PID_EL 2>/dev/null; wait $PID $PID_EL 2>/dev/null

mv "$DADOS/glibren.elf.ruim" "$DADOS/glibren.elf"; mv "$DADOS/glibren.elf.sig.ruim" "$DADOS/glibren.elf.sig"
: > "$DADOS/glibren.log"
inicia_elfldr responde; sleep 4
confere "respondeu: esta copia saiu"        "$(kill -0 $PID 2>&1)" "No such process"
confere "respondeu: diario"                 "$(cat $DADOS/glibren.log)" "a 9.9.9 respondeu na porta $PORTA; esta copia ($VERSAO) sai"
confere "respondeu: tentativa contada"      "$(cat $DADOS/tentativas_atualizacao)" "^9.9.9 1$"
confere "respondeu: .elf continua"          "$(ls $DADOS/glibren.elf)" "glibren.elf"
kill $PID_EL 2>/dev/null; wait $PID $PID_EL 2>/dev/null

echo "9.9.9 3" > "$DADOS/tentativas_atualizacao"; : > "$DADOS/glibren.log"
inicia_elfldr calado; sleep 1.5
confere "3 tentativas: virou .ruim sem passar" "$(cat $DADOS/glibren.log)" "subiu e caiu (ou nao subiu) varias vezes seguidas - virou"
confere "3 tentativas: nao chamou o elfldr" "$(cat $T/elfldr.log)" "^$"
confere "3 tentativas: zerou o contador"    "$(ls $DADOS/tentativas_atualizacao 2>&1)" "No such"
confere "3 tentativas: segue rodando"       "$(curl -s $U/api/estado)" "\"versao\":\"$VERSAO\""
kill $PID $PID_EL 2>/dev/null; wait $PID $PID_EL 2>/dev/null

kill $PID_SRV 2>/dev/null; wait 2>/dev/null
rm -rf "$T" "$A" "$DADOS"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
