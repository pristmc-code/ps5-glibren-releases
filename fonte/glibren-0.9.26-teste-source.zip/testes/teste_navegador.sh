#!/bin/bash
# Testa o "Abrir no navegador do PS5" (0.9.24) na versao de PC: POST /api/navegador/abrir com lista fixa de paginas
# (Jobe web /app, Jobe /teste, glibren), pareamento + X-GLR, recusa do navegador do PS5 e de 127.0.0.1, recusa com jogo
# aberto, e os atalhos da tela principal (so no navegador do PS5).
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_navegador.sh
set -u
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
PORTA=8895
IP=$(hostname -I | awk '{print $1}')
L="http://127.0.0.1:$PORTA"; R="http://$IP:$PORTA"
T=/root/glr-naveg; DADOS=$T/dados; A=$T/lista
UA_PS5='Mozilla/5.0 (PlayStation; PlayStation 5/12.00) AppleWebKit/605.1.15 (KHTML, like Gecko)'
ok=0; falhas=0
confere() { if echo "$2" | grep -q -- "$3"; then ok=$((ok+1)); echo "OK   $1"; else falhas=$((falhas+1)); echo "FALHA $1: [$2] (esperado $3)"; fi; }
nao_tem() { if echo "$2" | grep -q -- "$3"; then falhas=$((falhas+1)); echo "FALHA $1: achou [$3]"; else ok=$((ok+1)); echo "OK   $1"; fi; }
post() { curl -s -H 'X-GLR: 1' "$@"; }
codigo() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
rm -rf "$T"; mkdir -p "$DADOS" "$A"; : > "$T/abertos"
printf 'language = pt-BR\nfolder = %s/\n' "$A" > "$DADOS/config.ini"
GLR_TESTE_ABERTOS="$T/abertos" "$BIN" -p $PORTA -d "$DADOS" > "$T/glr.log" 2>&1 & PID=$!
sleep 1

echo "--- pareamento e X-GLR"
confere "rede sem pareamento: 401"        "$(codigo -H 'X-GLR: 1' -d destino=jobe $R/api/navegador/abrir)" "401"
confere "sem X-GLR: 403"                  "$(codigo -d destino=jobe $R/api/navegador/abrir)" "403"
post -X POST $R/api/parear/pedir > /dev/null; sleep 0.3
C=$(grep -o 'pareamento [0-9]\{6\}' "$T/glr.log" | tail -1 | awk '{print $2}')
TK=$(post -d codigo=$C -d nome=teste $R/api/parear | grep -o '"token":"[0-9a-f]*"' | cut -d'"' -f4)
confere "pareou"                          "$TK" "^[0-9a-f]\{16,\}$"
pp() { post -H "X-GLR-Token: $TK" "$@"; }

echo "--- lista fixa"
confere "fora da lista: 404"              "$(codigo -H 'X-GLR: 1' -H "X-GLR-Token: $TK" -d destino=outro $R/api/navegador/abrir)" "404"
confere "fora da lista: chave"            "$(pp -d 'destino=http://site.com/' $R/api/navegador/abrir)" '"chave":"navegador_destino"'
confere "url arbitraria nao entra"        "$(pp -d destino=jobe -d url=http://site.com/ $R/api/navegador/abrir)" '"ok":true'
sleep 1.6
confere "url arbitraria: abriu a da lista" "$(grep 'abriria o navegador' $DADOS/glibren.log | tail -1)" "abriria o navegador em http://127.0.0.1:34201/app$"
nao_tem "url arbitraria: site ignorado"   "$(grep "abriria o navegador" $DADOS/glibren.log)" "site.com"
confere "fora da lista: diario"           "$(cat $DADOS/glibren.log)" 'navegador: pedido recusado: "outro" nao esta na lista'

echo "--- destinos"
confere "jobe /teste"                     "$(pp -d destino=jobe_teste $R/api/navegador/abrir)" '"ok":true'
sleep 1.6
confere "jobe /teste: url"                "$(grep 'abriria o navegador' $DADOS/glibren.log | tail -1)" "http://127.0.0.1:34201/teste$"
confere "glibren"                         "$(pp -d destino=glibren $R/api/navegador/abrir)" '"ok":true'
sleep 1.6
confere "glibren: url com a porta dele"   "$(grep 'abriria o navegador' $DADOS/glibren.log | tail -1)" "http://127.0.0.1:$PORTA/$"
confere "voltou a tela inicial antes"     "$(cat $DADOS/glibren.log)" "voltaria para a tela inicial"
confere "diario do pedido"                "$(cat $DADOS/glibren.log)" "navegador: abrir http://127.0.0.1:$PORTA/ pedido pelo aparelho pareado"
confere "um de cada vez: ocupado"         "$(pp -d destino=jobe $R/api/navegador/abrir; pp -d destino=jobe $R/api/navegador/abrir)" '"chave":"payload_ocupado"'
sleep 1.6

echo "--- recusas"
confere "navegador do PS5: recusado"      "$(pp -A "$UA_PS5" -d destino=jobe $R/api/navegador/abrir)" '"chave":"navegador_so_celular"'
confere "127.0.0.1: recusado"             "$(post -d destino=jobe $L/api/navegador/abrir)" '"chave":"navegador_so_celular"'
echo PPSA01234 > "$T/abertos"
confere "jogo aberto: recusado"           "$(pp -d destino=jobe $R/api/navegador/abrir)" '"chave":"navegador_jogo_aberto".*"nome":"PPSA01234"'
: > "$T/abertos"
N=$(grep -c 'abriria o navegador' $DADOS/glibren.log)
sleep 1.6
confere "recusas: navegador nao abriu"    "$(grep -c 'abriria o navegador' $DADOS/glibren.log)" "^$N$"

echo "--- telas"
H=$(curl -s $L/)
confere "atalho Jobe web na tela"         "$H" 'id="chipJobe" href="http://127.0.0.1:34201/app"'
confere "atalho Jobe /teste na tela"      "$H" 'id="chipJobeTeste" href="http://127.0.0.1:34201/teste"'
confere "atalhos so no PS5 (hidden)"      "$H" 'id="chipJobe" href="http://127.0.0.1:34201/app" title="Jobe web" hidden'
confere "botao em Apps (fora do PS5)"     "$H" 'id="appsNavegador" class="nao-ps5"'
confere "textos em 3 idiomas"             "$(echo "$H" | grep -c 'apps_navegador: "🌐 Abr\|apps_navegador: "🌐 Open')" "^3$"
nao_tem "textos sem reticencias"          "$(echo "$H" | grep -o 'nps_[a-z_]*: "[^"]*"' )" "…"

kill $PID 2>/dev/null; wait $PID 2>/dev/null
rm -rf "$T"
echo "=== $ok ok, $falhas falharam"
[ $falhas -eq 0 ]
