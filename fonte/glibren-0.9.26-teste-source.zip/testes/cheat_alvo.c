/* Alvo de teste das cheats (so PC): faz o papel do jogo. Compilar com o nome "eboot.bin" (o glibren-pc procura o
   processo por esse nome, como no PS5).
     clang -O0 -o eboot.bin testes/cheat_alvo.c
     ./eboot.bin ARQUIVO_INFO
   Grava em ARQUIVO_INFO: "<pid> <offset da AREA> <offset da CAVE> <offset dos PADROES> <offset da SO_EXEC>" (em relacao a base do
   executavel, em hex). A area de teste comeca com bytes conhecidos (ver AREA). Fase 2: CAVE = 256 zeros DENTRO do
   codigo (pagina r-x, como a sobra de codigo que o glibren aceita como "area extra" no teste) e PADROES = bytes para
   a busca de padrao (mask) do .xml (um unico, um repetido). 0.9.26: SO_EXEC = pagina de zeros do codigo com protecao
   so de execucao ("--x", como a area extra do Terminator 2D no PS5 real). Sinais:
     SIGUSR1 -> o proprio alvo grava os bytes "ligado" da 1a cheat (simula outra ferramenta ligando a cheat);
     SIGUSR2 -> grava em ARQUIVO_INFO.soma a soma dos bytes da area (para conferir que o glibren nao mudou nada). */
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

/* 0: C6 80 CC 00 00 00 00 (off da "Vida infinita"); 16: F0 48 01 47 08 (off do "Dinheiro");
   32: 99 99 99 99 99 (nao bate com o arquivo); 48: DE AD (off com espacos/0x no arquivo do onionHEN);
   56: 8 zeros (area extra que da para ler, como no Terminator 2D); 64/72/80: os 3 trechos da "Tres trechos";
   88: 0F 1E 2D (1o trecho da "Meio errado"; o 2o e o 32, que nao bate);
   Fase 2: 100: 31..35 (salto da "Cave executavel"); 106: 41..45 (salto da "Usa a cave"); 112: 61..64 (codigo
   inicial do .mc4); 120: 71 72 (cheat comum do .mc4); 124: 81..84 (cheat do .shn) */
static volatile unsigned char AREA[128] __attribute__((aligned(64))) = {
  0xC6, 0x80, 0xCC, 0x00, 0x00, 0x00, 0x00, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0xF0, 0x48, 0x01, 0x47, 0x08, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0x99, 0x99, 0x99, 0x99, 0x99, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0xDE, 0xAD, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0x11, 0x22, 0x33, 0x44, 0, 0, 0, 0, 0x55, 0x66, 0x77, 0x88, 0, 0, 0, 0,
  0xAA, 0xBB, 0xCC, 0, 0, 0, 0, 0, 0x0F, 0x1E, 0x2D, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0x31, 0x32, 0x33, 0x34, 0x35, 0, 0x41, 0x42, 0x43, 0x44, 0x45, 0,
  0x61, 0x62, 0x63, 0x64, 0, 0, 0, 0, 0x71, 0x72, 0, 0, 0x81, 0x82, 0x83, 0x84};

/* Padroes do .xml: 0: A5 5A C3 3C 7E E7 81 18 + 11 22 (unico; o Value do teste e 1122 em +8); 16 e 32: B6 6B D4 4D
   (repetido = ambiguo). */
static volatile unsigned char PADROES[64] __attribute__((aligned(64))) = {
  0xA5, 0x5A, 0xC3, 0x3C, 0x7E, 0xE7, 0x81, 0x18, 0x11, 0x22, 0, 0, 0, 0, 0, 0,
  0xB6, 0x6B, 0xD4, 0x4D, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0xB6, 0x6B, 0xD4, 0x4D, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

/* Area extra de teste: 256 zeros no meio do codigo (.text, pagina r-x). Nunca e chamada. */
__attribute__((naked, used, aligned(64))) void area_extra_teste(void) { __asm__(".fill 256, 1, 0"); }

/* 0.9.26: uma pagina inteira de zeros no codigo; o main deixa so execucao (mprotect PROT_EXEC = "--x" no maps). */
__attribute__((naked, used, aligned(4096))) void area_so_exec(void) { __asm__(".fill 4096, 1, 0"); }

static volatile sig_atomic_t g_ligar, g_somar;
static void sinal(int s) {
  if(s == SIGUSR1) g_ligar = 1;
  else g_somar = 1;
}

/* Base do executavel: primeira linha de /proc/self/maps com o caminho dele. */
static unsigned long base_propria(void) {
  char exe[1024], linha[1400];
  ssize_t n = readlink("/proc/self/exe", exe, sizeof exe - 1);
  if(n <= 0) return 0;
  exe[n] = 0;
  FILE *f = fopen("/proc/self/maps", "r");
  unsigned long base = 0;
  while(f && fgets(linha, sizeof linha, f)) {
    if(strstr(linha, exe)) {
      base = strtoul(linha, NULL, 16);
      break;
    }
  }
  if(f) fclose(f);
  return base;
}

int main(int argc, char **argv) {
  if(argc < 2) return 2;
  signal(SIGUSR1, sinal);
  signal(SIGUSR2, sinal);
  unsigned long base = base_propria();
  char tmp[1100];
  snprintf(tmp, sizeof tmp, "%s.tmp", argv[1]);
  FILE *f = fopen(tmp, "w");
  if(!f || !base || mprotect((void *)&area_so_exec, 4096, PROT_EXEC)) return 1;
  fprintf(f, "%d %lx %lx %lx %lx\n", (int)getpid(), (unsigned long)((unsigned long)AREA - base),
          (unsigned long)((unsigned long)&area_extra_teste - base), (unsigned long)((unsigned long)PADROES - base),
          (unsigned long)((unsigned long)&area_so_exec - base));
  fclose(f);
  rename(tmp, argv[1]);
  for(;;) {
    pause();
    if(g_ligar) {
      g_ligar = 0;
      static const unsigned char on[] = {0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90};
      for(size_t i = 0; i < sizeof on; i++) AREA[i] = on[i];
    }
    if(g_somar) {
      g_somar = 0;
      unsigned soma = 0;
      for(size_t i = 0; i < sizeof AREA; i++) soma = soma * 31 + AREA[i];
      snprintf(tmp, sizeof tmp, "%s.soma", argv[1]);
      f = fopen(tmp, "w");
      if(f) {
        fprintf(f, "%08x\n", soma);
        fclose(f);
      }
    }
  }
}
