/* Game Library Renamer (payload PS5) - atualizacao pelo proprio PS5.

As versoes ficam no repositorio publico pristmc-code/ps5-glibren-releases (so os .elf, o codigo e privado):
  versao.json        {"versao", "notas", "tamanho", "sha256", "commit", "commit_fonte"}
  glibren.elf        o payload
  glibren.elf.sig    assinatura Ed25519 (64 bytes) do glibren.elf, feita no PC de quem publica
Atualizar: baixa o .elf e a assinatura, confere com a chave publica embutida (um arquivo adulterado ou de outra
pessoa e recusado - importante porque a conexao pode estar sem verificar o certificado), grava em
/data/GameLibraryRenamer/glibren.elf (+ .sig) e envia para o elfldr do proprio PS5 (127.0.0.1:9021). A copia nova
encerra esta (mesmo nome de processo).

Ao iniciar (atualizacao_ao_iniciar): o autoloader/PC continua mandando o .elf antigo de sempre, entao a copia que
sobe confere /data/GameLibraryRenamer/glibren.elf; se a assinatura vale e a versao gravada (marcador
"GLIBREN-VERSAO:" no binario) e mais nova, envia ela ao elfldr e espera ela responder na porta (R3, 0.9.12):
  - enquanto espera, esta copia usa outro nome de processo (a nova encerra as copias antigas pelo nome);
  - a nova respondeu com a versao gravada: esta sai;
  - nao respondeu em ESPERA_NOVA_S: o .elf gravado vira glibren.elf.ruim (com a .sig) e esta segue rodando;
  - tentativas contadas em "tentativas_atualizacao" (versao + quantas vezes passou a vez): a nova que fica de pe por
    ESTAVEL_S apaga o arquivo; na MAX_TENTATIVAS-esima vez sem isso (a nova sobe e cai logo depois), o .elf vira .ruim.
O arquivo "passou_a_vez" (trava das versoes ate a 0.9.11, que nao esperavam a nova) ainda e apagado pela versao nova
ao subir; se uma copia mais antiga que a gravada o encontra, a nova nao subiu: conta como tentativa.

Atualizar pelo botao (R1, R4, R10 na 0.9.12): recusa com tarefa na fila, teste de disco ou instalacao de app em
andamento (a versao nova encerra esta com SIGKILL); depois da assinatura confere que o marcador do .elf baixado e a
versao anunciada e que ela e mais nova que a em execucao (o versao.json nao e assinado: sem isso, um .elf antigo e
legitimo com um versao.json "99.0" voltava o PS5 para uma versao antiga); grava .elf e .sig com fsync.

Cache do raw.githubusercontent.com (0.9.24, visto no PS5 real em 13/11/2026): o CDN guarda cada arquivo do "main"
separadamente por alguns minutos; logo depois de duas publicacoes seguidas o versao.json ja dizia 0.9.23 e o
glibren.elf ainda vinha da 0.9.22 ("nao e a anunciada"). Por isso:
  - "commit" do versao.json (desde a 0.9.24) e o commit do repositorio publico que contem o .elf e a .sig daquela
    versao: baixa de .../ps5-glibren-releases/<commit>/glibren.elf, endereco imutavel (sem cache misturado). Sem
    "commit" valido (40 hex), ou se o endereco fixo falhar, usa o "main" como antes;
  - confere tamanho e sha256 anunciados antes da assinatura e do marcador;
  - pelo "main", se algo nao bate (tamanho, sha256, assinatura ou marcador), tenta de novo uma vez depois de
    ESPERA_CACHE_S; se ainda nao bater, avisa que o servidor ainda esta se atualizando (tentar em alguns minutos).
*/
#include "atualizacao.h"

#include <arpa/inet.h>
#include <ctype.h>
#include <netinet/in.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#include "api.h"
#include "assinatura.h"
#include "apps.h"
#include "sha256.h"
#include "config.h"
#include "discos.h"
#include "https.h"
#include "payloads.h"
#include "plataforma.h"
#include "tarefas.h"

#define REPO "https://raw.githubusercontent.com/pristmc-code/ps5-glibren-releases/"
#define BASE REPO "main/"
#define ESPERA_CACHE_S 8        /* pelo "main": espera antes da segunda tentativa quando o cache esta misturado */
#define MAX_ELF (16 * 1024 * 1024)
#define VALIDADE_S (15 * 60)
#define PORTA_ELFLDR 9021
#define ESPERA_NOVA_S 60        /* quanto a copia que passou a vez espera a nova responder na porta */
#define ESTAVEL_S 180           /* a nova que fica de pe esse tempo zera as tentativas */
#define MAX_TENTATIVAS 3        /* vezes que a versao gravada pode subir e cair antes de virar .ruim */

/* Fica no binario: a copia antiga le a versao do glibren.elf gravado por aqui. */
__attribute__((used)) static const char MARCADOR_VERSAO[] = "GLIBREN-VERSAO:" VERSAO "\n";

static pthread_mutex_t g_trava = PTHREAD_MUTEX_INITIALIZER;
static char g_nova[32], g_notas[600], g_fase[16], g_erro[200];
static char g_commit[48], g_sha[72];   /* do versao.json da versao nova ("" = nao anunciado ou invalido) */
static long g_tamanho;                 /* 0 = nao anunciado */
static time_t g_verificado;
static int g_rodando;

/* Endereco das versoes. So no PC, so nos testes: servidor local (GLR_TESTE_BASE, ver url_permitida). */
static const char *base(void) {
#ifndef __PROSPERO__
  const char *teste = getenv("GLR_TESTE_BASE");
  if(teste && *teste) return teste;
#endif
  return BASE;
}

static void url_base(char *saida, size_t tam, const char *arquivo) {
  snprintf(saida, tam, "%s%s", base(), arquivo);
}

/* Arquivo no commit fixo (imutavel); commit NULL = no "main". Testes no PC: GLR_TESTE_BASE + "<commit>/". */
static void url_ref(char *saida, size_t tam, const char *commit, const char *arquivo) {
  if(!commit) {
    url_base(saida, tam, arquivo);
    return;
  }
#ifndef __PROSPERO__
  const char *teste = getenv("GLR_TESTE_BASE");
  if(teste && *teste) {
    snprintf(saida, tam, "%s%s/%s", teste, commit, arquivo);
    return;
  }
#endif
  snprintf(saida, tam, "%s%s/%s", REPO, commit, arquivo);
}

static int espera_cache_s(void) {
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_ESPERA_CACHE")) return atoi(getenv("GLR_TESTE_ESPERA_CACHE"));
#endif
  return ESPERA_CACHE_S;
}

/* So hexadecimal minusculo com exatamente n digitos (commit = 40, sha256 = 64). */
static int hex_exato(const char *s, size_t n) {
  size_t k = 0;
  for(; s[k]; k++) {
    if(!((s[k] >= '0' && s[k] <= '9') || (s[k] >= 'a' && s[k] <= 'f'))) return 0;
  }
  return k == n;
}

/* Numero inteiro de "chave" num JSON simples (-1 se nao tem). */
static long campo_numero(const char *json, const char *chave) {
  char k[48];
  snprintf(k, sizeof k, "\"%s\"", chave);
  const char *p = strstr(json, k);
  if(!p || !(p = strchr(p + strlen(k), ':'))) return -1;
  while(*++p == ' ') {}
  if(*p < '0' || *p > '9') return -1;
  return strtol(p, NULL, 10);
}

/* "0.7-teste" -> 0007000; compara so os numeros */
static long numero_versao(const char *v) {
  long partes[3] = {0, 0, 0};
  for(int i = 0; i < 3 && *v; i++) {
    partes[i] = strtol(v, (char **)&v, 10);
    if(*v != '.') break;
    v++;
  }
  return partes[0] * 1000000 + partes[1] * 1000 + partes[2];
}

/* Texto de "chave" num JSON simples (sem escapes alem de \" e \n). */
static void campo_json(const char *json, const char *chave, char *saida, size_t tam) {
  char k[48];
  snprintf(k, sizeof k, "\"%s\"", chave);
  saida[0] = 0;
  const char *p = strstr(json, k);
  if(!p) return;
  p = strchr(p + strlen(k), ':');
  if(!p) return;
  while(*++p == ' ') {}
  if(*p != '"') return;
  size_t n = 0;
  for(p++; *p && *p != '"' && n + 1 < tam; p++) {
    if(*p == '\\' && p[1]) {
      p++;
      saida[n++] = *p == 'n' ? '\n' : *p;
    } else {
      saida[n++] = *p;
    }
  }
  saida[n] = 0;
}

static void verificar(int forcar) {
  pthread_mutex_lock(&g_trava);
  int recente = !forcar && g_verificado && time(NULL) - g_verificado < VALIDADE_S;
  pthread_mutex_unlock(&g_trava);
  if(recente) return;
  buf_t b = {0};
  char url[600];
  url_base(url, sizeof url, "versao.json");
  if(https_get(url, &b, 64 * 1024, 15) == 200) {
    buf_add(&b, "", 1);
    char versao[32], notas[600], commit[48], sha[72];
    campo_json(b.d, "versao", versao, sizeof versao);
    campo_json(b.d, "notas", notas, sizeof notas);
    campo_json(b.d, "commit", commit, sizeof commit);
    campo_json(b.d, "sha256", sha, sizeof sha);
    long tamanho = campo_numero(b.d, "tamanho");
    pthread_mutex_lock(&g_trava);
    if(versao[0] && numero_versao(versao) > numero_versao(VERSAO)) {
      snprintf(g_nova, sizeof g_nova, "%s", versao);
      snprintf(g_notas, sizeof g_notas, "%s", notas);
      /* so vale o formato exato: o commit entra no endereco e o sha256 na conferencia */
      snprintf(g_commit, sizeof g_commit, "%s", hex_exato(commit, 40) ? commit : "");
      snprintf(g_sha, sizeof g_sha, "%s", hex_exato(sha, 64) ? sha : "");
      g_tamanho = tamanho > 0 && tamanho <= MAX_ELF ? tamanho : 0;
    } else {
      g_nova[0] = g_notas[0] = g_commit[0] = g_sha[0] = 0;
      g_tamanho = 0;
    }
    g_verificado = time(NULL);
    pthread_mutex_unlock(&g_trava);
  }
  buf_free(&b);
}

void atualizacao_estado(buf_t *json, int forcar) {
  verificar(forcar);
  pthread_mutex_lock(&g_trava);
  buf_str(json, "{\"ok\":true,\"atual\":");
  buf_json(json, VERSAO);
  buf_str(json, ",\"nova\":");
  buf_json(json, g_nova);
  buf_str(json, ",\"notas\":");
  buf_json(json, g_notas);
  buf_str(json, ",\"fase\":");
  buf_json(json, g_fase);
  buf_str(json, ",\"erro\":");
  buf_json(json, g_erro);
  buf_fmt(json, ",\"rodando\":%s}", g_rodando ? "true" : "false");
  pthread_mutex_unlock(&g_trava);
}

static void fase(const char *f, const char *erro) {
  pthread_mutex_lock(&g_trava);
  snprintf(g_fase, sizeof g_fase, "%s", f);
  snprintf(g_erro, sizeof g_erro, "%s", erro ? erro : "");
  if(erro) g_rodando = 0;
  pthread_mutex_unlock(&g_trava);
  if(erro) diario("atualizacao: %s", erro);
}

/* Entrega o .elf ao elfldr do proprio PS5, que o executa (a copia nova encerra esta). */
static int enviar_elfldr(const void *dados, size_t n) {
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if(fd < 0) return -1;
  int porta = PORTA_ELFLDR;
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_ELFLDR")) porta = atoi(getenv("GLR_TESTE_ELFLDR"));   /* so testes: elfldr de mentira */
#endif
  struct sockaddr_in end = {.sin_family = AF_INET, .sin_port = htons(porta)};
  end.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  int ok = !connect(fd, (struct sockaddr *)&end, sizeof end);
  for(size_t enviados = 0; ok && enviados < n;) {
    ssize_t r = send(fd, (const char *)dados + enviados, n - enviados, 0);
    if(r <= 0) ok = 0;
    else enviados += r;
  }
  close(fd);
  return ok ? 0 : -1;
}

/* Grava os dados em caminho.part, com fsync (R10). 0 = ok (o .part fica para o rename). */
static int gravar_parcial(const char *caminho, const void *dados, size_t n, char *parcial, size_t tam) {
  snprintf(parcial, tam, "%s.part", caminho);
  FILE *f = fopen(parcial, "wb");
  int ok = f && fwrite(dados, 1, n, f) == n && !fflush(f) && !fsync(fileno(f));
  if(f && fclose(f)) ok = 0;
  if(!ok) unlink(parcial);
  return ok ? 0 : -1;
}

/* Motivo para nao atualizar agora (a versao nova encerra esta com SIGKILL): NULL = pode. */
static const char *motivo_ocupado(void) {
  if(tarefas_ativas()) return "ha tarefas de copiar, mover ou excluir na fila: espere terminar ou cancele";
  if(discos_testando()) return "um teste de velocidade de disco esta rodando: espere terminar ou cancele";
  if(apps_ocupado()) return "um app esta sendo instalado ou desinstalado: espere terminar";
  if(payloads_ocupado()) return "um payload de teste esta sendo baixado ou ativado: espere terminar";
  return NULL;
}

static void versao_do_elf(const char *d, size_t n, char *saida, size_t tam);

/* Resultado de uma tentativa de baixar e conferir. */
enum { BX_OK, BX_REDE_ELF, BX_REDE_SIG, BX_DIVERGE, BX_ASSINATURA };

/* Baixa .elf e .sig (do commit fixo ou, com commit NULL, do "main") e confere, nesta ordem: tamanho e sha256
   anunciados, assinatura e marcador da versao. baixada = versao do marcador ("" se nao achou). */
static int baixar_conferir(const char *commit, const char *anunciada, const char *sha, long tamanho, buf_t *elf,
                           buf_t *sig, char *baixada, size_t tam_baixada) {
  char url[600], hex[65];
  buf_free(elf);
  buf_free(sig);
  baixada[0] = 0;
  url_ref(url, sizeof url, commit, "glibren.elf");
  if(https_get(url, elf, MAX_ELF, 60) != 200 || elf->n < 1024) return BX_REDE_ELF;
  url_ref(url, sizeof url, commit, "glibren.elf.sig");
  if(https_get(url, sig, 1024, 15) != 200 || sig->n != 64) return BX_REDE_SIG;
  fase("verificando", NULL);
  versao_do_elf(elf->d, elf->n, baixada, tam_baixada);   /* tambem entra na mensagem, se algo nao bater */
  const char *origem = commit ? commit : "main";
  if(tamanho > 0 && (long)elf->n != tamanho) {
    diario("atualizacao: %.12s: tamanho %zu, anunciado %ld (veio a %s)", origem, elf->n, tamanho, baixada);
    return BX_DIVERGE;
  }
  if(sha[0]) {
    sha256_t s;
    uint8_t resumo[32];
    sha256_iniciar(&s);
    sha256_atualizar(&s, elf->d, elf->n);
    sha256_final(&s, resumo);
    sha256_hex(resumo, hex);
    if(strcmp(hex, sha)) {
      diario("atualizacao: %.12s: sha256 %.16s..., anunciado %.16s... (veio a %s)", origem, hex, sha, baixada);
      return BX_DIVERGE;
    }
  }
  if(!assinatura_valida(elf->d, elf->n, (const unsigned char *)sig->d)) return BX_ASSINATURA;
  /* R1: a assinatura so prova que o .elf e nosso, nao que e o mais novo; o versao.json nao e assinado */
  if(!baixada[0] || strcmp(baixada, anunciada)) return BX_DIVERGE;
  return BX_OK;
}

static void *atualizar(void *arg) {
  (void)arg;
  buf_t elf = {0}, sig = {0};
  char destino[600], parcial[640], arq_sig[640], sig_parcial[660], anunciada[32], baixada[32], erro[200];
  char tentativas[600], commit[48], sha[72];
  long tamanho;
  const char *ocupado;
  pthread_mutex_lock(&g_trava);
  snprintf(anunciada, sizeof anunciada, "%s", g_nova);
  snprintf(commit, sizeof commit, "%s", g_commit);
  snprintf(sha, sizeof sha, "%s", g_sha);
  tamanho = g_tamanho;
  pthread_mutex_unlock(&g_trava);
  fase("baixando", NULL);
  int r = BX_REDE_ELF;
  if(commit[0]) {   /* endereco imutavel: o cache do "main" nao mistura versoes */
    r = baixar_conferir(commit, anunciada, sha, tamanho, &elf, &sig, baixada, sizeof baixada);
    if(r == BX_ASSINATURA) {   /* arquivo imutavel com assinatura errada: nao e cache */
      fase("", "assinatura invalida: atualizacao recusada (arquivo adulterado ou de outra origem)");
      goto fim;
    }
    if(r != BX_OK) diario("atualizacao: pelo commit %.12s nao deu (%d); tentando pelo main", commit, r);
  }
  for(int vez = 0; r != BX_OK && vez < 2; vez++) {   /* pelo "main": o cache pode estar misturado, tenta 2 vezes */
    if(vez) {
      diario("atualizacao: o main ainda nao bate (%d); nova tentativa em %d s", r, espera_cache_s());
      fase("baixando", NULL);
      sleep(espera_cache_s());
    }
    r = baixar_conferir(NULL, anunciada, sha, tamanho, &elf, &sig, baixada, sizeof baixada);
    if(r == BX_REDE_ELF || r == BX_REDE_SIG) break;   /* sem internet: nao adianta esperar o cache */
  }
  if(r == BX_REDE_ELF) {
    fase("", "nao foi possivel baixar a versao nova");
    goto fim;
  }
  if(r == BX_REDE_SIG) {
    fase("", "nao foi possivel baixar a assinatura da versao nova");
    goto fim;
  }
  if(r == BX_ASSINATURA) {
    fase("", "assinatura invalida: atualizacao recusada (arquivo adulterado ou de outra origem)");
    goto fim;
  }
  if(r == BX_DIVERGE) {
    snprintf(erro, sizeof erro,
             "o servidor de versoes ainda esta se atualizando (veio a %s, anunciada a %s): tente de novo em alguns "
             "minutos",
             baixada[0] ? baixada : "?", anunciada);
    fase("", erro);
    goto fim;
  }
  if(numero_versao(baixada) <= numero_versao(VERSAO)) {
    snprintf(erro, sizeof erro, "a versao baixada (%s) nao e mais nova que a atual (%s): atualizacao recusada", baixada, VERSAO);
    fase("", erro);
    goto fim;
  }
  if((ocupado = motivo_ocupado())) {   /* R4: de novo, porque o download levou um tempo */
    fase("", ocupado);
    goto fim;
  }
  fase("instalando", NULL);
  snprintf(destino, sizeof destino, "%s/glibren.elf", g_pasta_dados);
  snprintf(arq_sig, sizeof arq_sig, "%s.sig", destino);
  /* .elf e .sig gravados (com fsync) antes de trocar; sem a .sig certa a versao gravada nao assume ao iniciar */
  if(gravar_parcial(destino, elf.d, elf.n, parcial, sizeof parcial)) {
    fase("", "nao foi possivel gravar a versao nova no PS5");
    goto fim;
  }
  if(gravar_parcial(arq_sig, sig.d, sig.n, sig_parcial, sizeof sig_parcial)) {
    unlink(parcial);
    fase("", "nao foi possivel gravar a versao nova no PS5");
    goto fim;
  }
  if(rename(parcial, destino) || rename(sig_parcial, arq_sig)) {
    unlink(parcial);
    unlink(sig_parcial);
    fase("", "nao foi possivel gravar a versao nova no PS5");
    goto fim;
  }
  snprintf(tentativas, sizeof tentativas, "%s/tentativas_atualizacao", g_pasta_dados);
  unlink(tentativas);   /* versao nova gravada: as tentativas comecam do zero */
  diario("atualizacao: versao %s verificada e gravada em %s", baixada, destino);
  fase("reiniciando", NULL);
#ifdef __PROSPERO__
  if(enviar_elfldr(elf.d, elf.n)) {
    fase("", "versao nova gravada, mas o elfldr (porta 9021) nao respondeu: envie glibren.elf de novo");
    goto fim;
  }
  diario("atualizacao: enviada ao elfldr; a versao nova assume");
#else
  diario("atualizacao (PC): nao envia ao elfldr");
#endif
  pthread_mutex_lock(&g_trava);
  g_rodando = 0;   /* se a versao nova nao assumir, da para tentar de novo */
  pthread_mutex_unlock(&g_trava);
fim:
  buf_free(&elf);
  buf_free(&sig);
  return NULL;
}

/* Arquivo inteiro para b (ate max bytes). 0 = ok. */
static int ler_arquivo(const char *caminho, buf_t *b, size_t max) {
  FILE *f = fopen(caminho, "rb");
  if(!f) return -1;
  char bloco[64 * 1024];
  size_t n;
  int ok = 1;
  while(ok && (n = fread(bloco, 1, sizeof bloco, f)) > 0) {
    ok = b->n + n <= max;
    if(ok) buf_add(b, bloco, n);
  }
  fclose(f);
  return ok ? 0 : -1;
}

/* Versao do marcador dentro de um .elf ("" se nao tem). So vale "GLIBREN-VERSAO:<digito>...\n": a propria constante
   de busca abaixo tambem esta no binario, sem versao depois. */
static void versao_do_elf(const char *d, size_t n, char *saida, size_t tam) {
  static const char m[] = "GLIBREN-VERSAO:";
  saida[0] = 0;
  for(const char *p = d; (p = memchr(p, 'G', n - (size_t)(p - d))) && (size_t)(d + n - p) > sizeof m; p++) {
    if(memcmp(p, m, sizeof m - 1)) continue;
    const char *v = p + sizeof m - 1;
    size_t k = 0;
    while(v + k < d + n && k + 1 < tam && v[k] > 0x20 && v[k] < 0x7f) k++;
    if(!k || v[0] < '0' || v[0] > '9' || v + k >= d + n || v[k] != '\n') continue;
    memcpy(saida, v, k);
    saida[k] = 0;
    return;
  }
}

/* "tentativas_atualizacao": "<versao> <n>". Devolve n se a versao bate, senao 0. */
static int ler_tentativas(const char *arq, const char *versao) {
  char v[32] = "";
  int n = 0;
  FILE *f = fopen(arq, "r");
  if(!f) return 0;
  if(fscanf(f, "%31s %d", v, &n) != 2 || strcmp(v, versao) || n < 0) n = 0;
  fclose(f);
  return n;
}

static void gravar_tentativas(const char *arq, const char *versao, int n) {
  char tmp[640];
  snprintf(tmp, sizeof tmp, "%s.tmp", arq);
  FILE *f = fopen(tmp, "w");
  if(!f) return;
  fprintf(f, "%s %d\n", versao, n);
  int ok = !fflush(f) && !fsync(fileno(f));
  if(fclose(f) || !ok || rename(tmp, arq)) unlink(tmp);
}

/* A versao gravada nao ficou de pe: glibren.elf (+ .sig) vira .ruim, e esta copia segue rodando. */
static void marcar_ruim(const char *elf_arq, const char *sig_arq, const char *gravada, const char *motivo) {
  char ruim[640], ruim_sig[660];
  snprintf(ruim, sizeof ruim, "%s.ruim", elf_arq);
  snprintf(ruim_sig, sizeof ruim_sig, "%s.ruim", sig_arq);
  rename(elf_arq, ruim);
  rename(sig_arq, ruim_sig);
  diario("atualizacao: a %s gravada %s - virou %s; segue a %s", gravada, motivo, ruim, VERSAO);
  notificar("Game Library Renamer: a versao %s nao subiu; voltou para a %s", gravada, VERSAO);
}

/* Algum glibren responde em 127.0.0.1:g_porta com a versao dada? */
static int nova_respondeu(const char *versao) {
  int fd = socket(AF_INET, SOCK_STREAM, 0);
  if(fd < 0) return 0;
  struct timeval espera = {.tv_sec = 3};
  setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &espera, sizeof espera);
  setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &espera, sizeof espera);
  struct sockaddr_in end = {.sin_family = AF_INET, .sin_port = htons(g_porta)};
  end.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  char resposta[4096], procura[64];
  size_t n = 0;
  if(!connect(fd, (struct sockaddr *)&end, sizeof end)) {
    static const char pedido[] = "GET /api/estado HTTP/1.0\r\nHost: 127.0.0.1\r\n\r\n";
    if(send(fd, pedido, sizeof pedido - 1, 0) == (ssize_t)(sizeof pedido - 1)) {
      ssize_t r;
      while(n < sizeof resposta - 1 && (r = recv(fd, resposta + n, sizeof resposta - 1 - n, 0)) > 0) n += (size_t)r;
    }
  }
  close(fd);
  resposta[n] = 0;
  snprintf(procura, sizeof procura, "\"versao\":\"%s\"", versao);
  return n && strstr(resposta, procura) != NULL;
}

/* A versao gravada ficou de pe ESTAVEL_S: zera as tentativas. */
static void *confirmar_estavel(void *arg) {
  (void)arg;
  char arq[600];
  snprintf(arq, sizeof arq, "%s/tentativas_atualizacao", g_pasta_dados);
  sleep(ESTAVEL_S);
  if(ler_tentativas(arq, VERSAO)) {
    unlink(arq);
    diario("atualizacao: a %s ficou de pe; tentativas zeradas", VERSAO);
  }
  return NULL;
}

static int espera_nova_s(void) {
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_ESPERA_NOVA")) return atoi(getenv("GLR_TESTE_ESPERA_NOVA"));
#endif
  return ESPERA_NOVA_S;
}

int atualizacao_ao_iniciar(void) {
  char elf_arq[600], sig_arq[640], trava[600], tentativas[600], gravada[32], motivo[64];
  snprintf(elf_arq, sizeof elf_arq, "%s/glibren.elf", g_pasta_dados);
  snprintf(sig_arq, sizeof sig_arq, "%s.sig", elf_arq);
  snprintf(trava, sizeof trava, "%s/passou_a_vez", g_pasta_dados);
  snprintf(tentativas, sizeof tentativas, "%s/tentativas_atualizacao", g_pasta_dados);
  int trava_velha = !access(trava, F_OK);
  if(trava_velha) unlink(trava);   /* das versoes ate a 0.9.11 */
  if(ler_tentativas(tentativas, VERSAO)) criar_thread(confirmar_estavel, NULL, NULL);   /* esta e a versao gravada */
  buf_t elf = {0}, sig = {0};
  int passou = 0;
  if(ler_arquivo(elf_arq, &elf, MAX_ELF) || ler_arquivo(sig_arq, &sig, 1024) || sig.n != 64) goto fim;
  versao_do_elf(elf.d, elf.n, gravada, sizeof gravada);
  if(!gravada[0] || numero_versao(gravada) <= numero_versao(VERSAO)) goto fim;
  if(!assinatura_valida(elf.d, elf.n, (const unsigned char *)sig.d)) {
    diario("atualizacao: %s gravado com assinatura invalida - ignorado", elf_arq);
    goto fim;
  }
  int n = ler_tentativas(tentativas, gravada);
  if(trava_velha) {
    n++;   /* uma copia antiga passou a vez e a nova nao apagou a trava: nao subiu */
    diario("atualizacao: a %s nao apagou a trava da copia anterior (tentativa %d)", gravada, n);
  }
  if(n >= MAX_TENTATIVAS) {
    marcar_ruim(elf_arq, sig_arq, gravada, "subiu e caiu (ou nao subiu) varias vezes seguidas");
    unlink(tentativas);
    goto fim;
  }
#ifndef __PROSPERO__
  if(!getenv("GLR_TESTE_ELFLDR")) {   /* PC sem o elfldr de mentira dos testes: so registra */
    diario("atualizacao (PC): passaria a vez para a %s", gravada);
    goto fim;
  }
#endif
  gravar_tentativas(tentativas, gravada, n + 1);
  diario("atualizacao: esta copia e a %s, mas a %s esta gravada: passando a vez para ela (tentativa %d de %d)", VERSAO,
         gravada, n + 1, MAX_TENTATIVAS);
  plataforma_nome("glibren-espera");   /* a nova encerra as copias antigas pelo nome: esta precisa ficar para conferir */
  if(enviar_elfldr(elf.d, elf.n)) {
    plataforma_nome(NULL);
    gravar_tentativas(tentativas, gravada, n);   /* a culpa nao e da versao gravada */
    diario("atualizacao: o elfldr (porta 9021) nao respondeu - segue a %s", VERSAO);
    goto fim;
  }
  int espera = espera_nova_s();
  for(int s = 0; s < espera && !passou; s++) {
    sleep(1);
    passou = nova_respondeu(gravada);
  }
  if(passou) {
    diario("atualizacao: a %s respondeu na porta %d; esta copia (%s) sai", gravada, g_porta, VERSAO);
  } else {
    snprintf(motivo, sizeof motivo, "nao respondeu na porta %d em %d s", g_porta, espera);
    marcar_ruim(elf_arq, sig_arq, gravada, motivo);
    unlink(tentativas);
    plataforma_encerrar_copias();   /* a nova, se ficou presa no meio do caminho */
    plataforma_nome(NULL);
  }
fim:
  buf_free(&elf);
  buf_free(&sig);
  return passou;
}

int atualizacao_iniciar(char *msg, size_t tam) {
  pthread_mutex_lock(&g_trava);
  if(g_rodando) {
    pthread_mutex_unlock(&g_trava);
    snprintf(msg, tam, "a atualizacao ja esta em andamento");
    return -1;
  }
  if(!g_nova[0]) {
    pthread_mutex_unlock(&g_trava);
    snprintf(msg, tam, "nenhuma versao nova");
    return -1;
  }
  const char *ocupado = motivo_ocupado();
  if(ocupado) {   /* R4: a versao nova encerra esta com SIGKILL - nada pode estar no meio */
    pthread_mutex_unlock(&g_trava);
    snprintf(msg, tam, "%s", ocupado);
    return -1;
  }
  g_rodando = 1;
  g_erro[0] = 0;
  pthread_mutex_unlock(&g_trava);
  if(criar_thread(atualizar, NULL, NULL)) {
    fase("", "nao iniciou a atualizacao");
    snprintf(msg, tam, "nao iniciou a atualizacao");
    return -1;
  }
  return 0;
}
