/* Game Library Renamer (payload PS5) - cheats do jogo aberto (teste). Fase 0 (0.9.17): leitura. Fase 1 (0.9.18):
ligar e desligar (.json). Fase 2 (branch cheats-fase2, nao publicada): formatos .shn, .mc4 e .xml (Illusion) e o
prototipo da "area extra" (code cave), desligado por padrao.

O que faz: descobre o jogo aberto e a versao dele, acha no catalogo os arquivos de cheat dessa versao exata,
e para cada cheat LE os bytes atuais da memoria do jogo e compara com o "off" (desligada) e o "on" (ligada) do
arquivo. POST /api/cheats/ligar e /desligar gravam o "on" ou os bytes originais, sempre com leitura de volta.

Regras da escrita (Fase 1, todas obrigatorias; valem para .json, .shn e .mc4):
- ligar: os bytes atuais de TODOS os trechos tem de bater com o "off" (senao recusa com o motivo); os originais sao
  guardados em memoria e em <catalogo>/aplicadas.json ANTES de gravar; grava os trechos em ordem e le cada um de
  volta; se um falhar, desfaz os ja gravados.
- desligar: os bytes atuais tem de bater com o "on"; restaura os originais (que tem de ser iguais ao "off").
- jogo mudou (pid ou app id): as cheats ligadas viram "perdidas" e nada e gravado.
- ao fechar o glibren (/api/sair ou SIGTERM): restaura as ligadas se o jogo ainda for o mesmo.
- de fora ("nao suportada"): section != 0, endereco absoluto, trecho sem "off", "process" diferente do eboot.bin,
  trechos que se sobrepoem, .xml (so leitura: o formato nao tem o "off") e "area extra" (ver abaixo).
- dependencias (Fase 2): uma cheat cujo codigo salta (E8/E9/0F 8x + rel32) para a area extra de OUTRA cheat do mesmo
  arquivo so liga se a outra estiver ligada pelo glibren (e a outra so desliga depois dela). Num .shn/.mc4 com
  <StartUP> ("codigo inicial", master code), as cheats comuns so ligam com todos os codigos iniciais ligados.
- uma escrita por vez (g_trava_mem); cada acao vai para o diario ("cheats: ligou/desligou <nome> em <TID>").

0.9.26: o .xml (Illusion) tambem liga e desliga. Ele nao tem "off": ao ligar, os bytes ORIGINAIS sao lidos e guardados
(memoria + aplicadas.json, "fonte":"xml") e viram o desligado; desligar exige os bytes atuais = "on" e devolve os
originais. mask so com o padrao achado EXATAMENTE uma vez nas partes do modulo (ambiguo/ausente seguem "nao
suportada"); mask_jump32 so com a area extra (teste) ligada e a area do Target existente, r-x, no modulo e zerada.
Area extra so execucao ("--x", visto no PS5 real no Terminator 2D) = "area_extra_sem_leitura" (nao da para ligar).

Area extra (code cave) - Fase 2, PROTOTIPO, so com "cheats_area_extra = on" no config.ini (padrao: off; 0.9.25: a
chave "Area extra (teste)" no fim da pagina Cheats grava essa linha; desligar com cheat de area extra ligada e recusado)
- trecho com "off" todo zero = area que o HEN usa para codigo novo. O onionHEN CRIA a area quando ela nao existe:
  ptrace no jogo (pt_attach), executa um mmap DENTRO do jogo trocando os registradores (pt_syscall) e da
  kernel_mprotect(RWX); nunca libera. O glibren NAO faz isso (ptrace para o jogo inteiro, troca registradores e
  depende de authid de depurador; o risco de fechar o jogo e alto e nao ha como liberar com seguranca).
- O glibren so usa area extra que JA EXISTE: legivel, com os bytes atuais = "off" (zeros) e numa pagina EXECUTAVEL do
  jogo (kernel_get_vmem_protection do SDK, so leitura; e, se a lista de faixas do modulo existir, dentro de uma
  faixa executavel dele). Zeros numa pagina de codigo = sobra (padding) do executavel: o jogo nao escreve ali.
- ligar: grava primeiro as areas extras e depois os saltos; desligar: tira os saltos primeiro e depois devolve os
  zeros (a area "liberada" = do jeito que estava). Sempre com leitura de volta. Area ilegivel = "nao suportada".

Catalogo
- HEN-Cheats-Collection (TeeKay87, github.com/TeeKay87/HEN-Cheats-Collection), o mesmo que o onionHEN usa. Baixado
  como zip da branch master em codeload.github.com (POST /api/cheats/catalogo). Do zip sao extraidos os arquivos de
  "<topo>/cheats/json/", "cheats/shn/" e "cheats/mc4/" para /data/glibren/cheats/{json,shn,mc4}/ (troca de cada
  pasta inteira; um zip ruim nao apaga o catalogo anterior). /data/glibren/cheats/xml/ (manual) tambem e lida.
- Tambem le /data/OnionHEN/cheats/ (pasta plana do onionHEN) se existir; com o mesmo nome nos dois, vale o do onionHEN.
- Nome do arquivo: <TITLE_ID>_<VERSAO>[_<PROCESSO>][_<ID 8 hex>].{json,shn,mc4}; a versao tem de ser IGUAL (texto) a
  do jogo. .xml (Illusion): <TITLE_ID>.xml ou <TITLE_ID>_<VERSAO>.xml (a versao vem do AppVer de cada patch).
  PS5: contentVersion do param.json ("01.000.002"). PS4: maior entre VERSION e APP_VER do param.sfo ("01.07").
- Prioridade (como o onionHEN): .json > .shn > .mc4 > .xml. Um arquivo de prioridade menor com as MESMAS cheats
  (mesmos trechos) de um ja mostrado fica de fora (lista "ignorados").

Formatos (conferidos nos arquivos reais em 13/11/2026; ver ps5/ESTUDO-cheats-onionhen.md)
- .json: {"name","id","version","process","mods":[{"name","description","type","memory":[{"offset","on","off",
  "section","absolute"}]}],"credits"|"authors"}. offset = hex sem "0x", relativo a base do modulo "process".
- .shn (texto XML, GoldHEN/PS4 Cheats Manager): <Trainer Game Moder Cusa Version Process> com <Cheat Text
  Description> (e <StartUP>, os codigos iniciais) e dentro <Cheatline><Offset/><Section/><ValueOn/><ValueOff/>
  [<Absolute>True</Absolute>]</Cheatline>. Bytes em hex separados por "-" ("90-90-90").
- .mc4: o MESMO XML do .shn, codificado: Base64 -> AES-256-CBC (chave e IV fixos, publicos no codigo aberto do
  GoldHEN Cheat Manager e do onionHEN) -> padding PKCS#7. Decodificado aqui com AES proprio (so decifrar).
- .xml (Illusion PS4-PS5-Game-Patch): <Patch><TitleID><ID>..</ID></TitleID><Metadata Name AppVer AppElf
  [ImageBase=0x400000] Note Author><PatchList><Line Type Address Value [Offset Target Size]/>..; campos como atributo
  ou elemento. Type: byte, bytes16/32/64 (inteiro little-endian), bytes (hex), float32/64, utf8, utf16, mask
  (Address = padrao hex com ?/??, Offset com sinal a partir do 1o byte, Value = bytes) e mask_jump32 (+ Target =
  bytes da area de destino e Size). Enderecos diretos: offset = Address - ImageBase. NAO tem "off": so leitura.
  mask: o padrao e procurado nas faixas do modulo; achado uma unica vez = mostra a leitura; nenhuma ou mais de uma
  vez = "nao suportada" (padrao ambiguo/nao achado).

Como le a memoria do jogo (PS5) - ideia reescrita, sem copiar codigo, a partir de:
  ps5-payload-sdk (John Tornblom, GPL-3: crt/kernel_procio.c, crt/kernel.c), ps5debug-NG (Pharaoh2k), etaHEN e
  onionHEN (aydencharles, GPL-3: source/util/source/cheats), GoldHEN Cheat Manager / PS4 Cheats Manager (formatos
  .shn/.mc4) e Illusion PS4-PS5-Game-Patch (formato .xml). Creditos no README.
  1. jogo: sceSystemServiceGetAppIdOfRunningBigApp (app id) + sceSystemServiceGetAppTitleId;
  2. processo: lista de processos (sysctl KERN_PROC_PROC) + sceKernelGetAppInfo(pid) com o mesmo app id (como a
     amostra "ps" do SDK); prefere o de nome "eboot.bin";
  3. base do modulo: kernel_dynlib_handle(pid, nome) + kernel_dynlib_mapbase_addr (SDK: lista de objetos em
     proc+0x3e8). Endereco = base + offset (ou o offset, se "absolute");
  4. leitura: kernel_proc_copyout(pid, endereco, ...) do SDK: tenta o mdbg (syscall 573, comando de LEITURA 0x12) e,
     se falhar, anda a tabela de paginas do processo (proc+0x200 -> vmspace -> pmap -> 4 niveis) e copia pelo DMAP
     com o kernel R/W que o elfldr entrega. Funcionou no PS5 PRO fw 12.00 (13/11/2026, Terminator 2D PPSA25872).
  5. escrita: kernel_proc_copyin do SDK, o par da leitura: mdbg de escrita e, se falhar (bloqueado no fw >= 8.40),
     tabela de paginas + DMAP (grava na memoria fisica, ignora a protecao da pagina). Nao usa ptrace nem mprotect.
     Leitura e escrita vao em pedacos dentro de uma pagina de 4 KB (ver pedaco()).
  6. (Fase 2, so leitura) faixas do modulo para procurar padroes: syscalls dl_get_list (0x217) e dl_get_info_2
     (0x2cd) com o layout do NineS/onionHEN (secoes vaddr/tamanho/protecao; buffer de 16 KB zerado; a secao 0 tem de
     ser a base do SDK, senao a lista e descartada) ou, sem elas, os cabecalhos ELF na base. Protecao de uma pagina:
     kernel_get_vmem_protection do SDK (anda a arvore vm_map do processo, so leitura).
  Dependem do firmware (todos DENTRO do SDK v0.45, que tem tabela ate 14.xx e cobre o 12.00): offset do pmap no
  vmspace (0x2e8 no fw >= 6), proc+0x200 (vmspace), proc+0x3e8 (lista de modulos), raiz do vm_map (0x1d0 no 12.00) e
  o numero/formato do mdbg. Neste arquivo nao ha offset de kernel nenhum (os do dl_get_info_2 sao da resposta da
  syscall, nao do kernel). Tudo vai para o diario (linhas "cheats:").

No PC (teste) o "jogo" e um processo chamado eboot.bin (testes/cheat_alvo.c): acha por /proc/<pid>/comm, base pela
primeira linha do modulo em /proc/<pid>/maps, faixas e protecao pelo /proc/<pid>/maps, le por /proc/<pid>/mem
(O_RDONLY) e grava por /proc/<pid>/mem (O_RDWR, so no modo de teste). GLR_TESTE_CHEATS_FALHAR=<endereco hex> faz a
escrita nesse endereco falhar. Variaveis: GLR_TESTE_ABERTOS (jogo aberto), GLR_TESTE_APPMETA (pasta no lugar de
/user/appmeta), GLR_TESTE_CHEATS (pasta do catalogo), GLR_TESTE_ONION (pasta do onionHEN), GLR_TESTE_CHEATS_PID (so
este processo), GLR_TESTE_CHEATS_URL (zip do catalogo; servidor local via GLR_TESTE_BASE). "glibren-pc
--teste-cheat ARQUIVO TID VERSAO" imprime o arquivo lido (teste dos parsers com os arquivos reais).
*/
#include "cheats.h"

#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#include "config.h"
#include "https.h"
#include "imagem.h"
#include "lancador.h"
#include "plataforma.h"
#include "zip.h"

#ifdef __PROSPERO__
#include <sys/sysctl.h>
#include <sys/user.h>
#include <ps5/kernel.h>
#endif

#define URL_CATALOGO "https://codeload.github.com/TeeKay87/HEN-Cheats-Collection/zip/refs/heads/master"
#define MAX_ZIP (256ull * 1024 * 1024)          /* o zip tinha 13,8 MB (2486 .json, 1862 .shn, 2041 .mc4) */
#define MAX_TOTAL_ZIP (2ull * 1024 * 1024 * 1024)
#define MAX_JSON (4 * 1024 * 1024)              /* um arquivo de cheat (o maior .shn real tem ~1 MB) */
#define MAX_ARQUIVOS 24                         /* arquivos da mesma versao (fontes e formatos diferentes) */
#define MAX_TRECHO 4096                         /* bytes de um "on"/"off" */
#define MAX_LEITURAS 2000                       /* trechos lidos por pedido */
#define FOLGA_DISCO (300ull * 1024 * 1024)

/* formatos, na ordem de prioridade (json > shn > mc4 > xml) */
enum { FMT_JSON, FMT_SHN, FMT_MC4, FMT_XML, FMT_QTD };
static const char *const FMT_EXT[FMT_QTD] = {".json", ".shn", ".mc4", ".xml"};
static const char *const FMT_NOME[FMT_QTD] = {"json", "shn", "mc4", "xml"};

/* ------------------------------------------------------------------ JSON (arvore pequena, so leitura) */

/* Parser JSON estrito e pequeno so para os arquivos de cheat: monta uma arvore (objetos, listas, textos, numeros,
   true/false/null) com limites de tamanho, de profundidade e de nos. Textos: escapes decodificados (\uXXXX vira
   UTF-8; \u0000 vira espaco). Liberar com jv_liberar. */
typedef enum { JV_NULO, JV_LOGICO, JV_NUMERO, JV_TEXTO, JV_LISTA, JV_OBJETO } jv_tipo_t;

typedef struct jv {
  jv_tipo_t tipo;
  char *chave;          /* dentro de objeto: o nome do campo */
  char *texto;          /* JV_TEXTO (e o numero como escrito, em JV_NUMERO) */
  int logico;
  struct jv *filho, *prox;
} jv_t;

#define JV_MAX_PROF 24
#define JV_MAX_NOS 200000

typedef struct {
  const char *p, *fim;
  int nos;
  const char *erro;
} jv_leitor_t;

static void jv_liberar(jv_t *v) {
  while(v) {
    jv_t *prox = v->prox;
    jv_liberar(v->filho);
    free(v->chave);
    free(v->texto);
    free(v);
    v = prox;
  }
}

static void jv_espacos(jv_leitor_t *l) {
  while(l->p < l->fim && (*l->p == ' ' || *l->p == '\t' || *l->p == '\n' || *l->p == '\r')) l->p++;
}

static int jv_hex4(const char *p, unsigned *v) {
  *v = 0;
  for(int i = 0; i < 4; i++) {
    char c = p[i];
    int d = c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1;
    if(d < 0) return -1;
    *v = *v * 16 + (unsigned)d;
  }
  return 0;
}

static void jv_utf8(buf_t *b, unsigned cp) {
  char s[4];
  size_t k;
  if(!cp) cp = ' ';
  if(cp < 0x80) { s[0] = (char)cp; k = 1; }
  else if(cp < 0x800) { s[0] = (char)(0xC0 | (cp >> 6)); s[1] = (char)(0x80 | (cp & 0x3F)); k = 2; }
  else if(cp < 0x10000) { s[0] = (char)(0xE0 | (cp >> 12)); s[1] = (char)(0x80 | ((cp >> 6) & 0x3F)); s[2] = (char)(0x80 | (cp & 0x3F)); k = 3; }
  else { s[0] = (char)(0xF0 | (cp >> 18)); s[1] = (char)(0x80 | ((cp >> 12) & 0x3F)); s[2] = (char)(0x80 | ((cp >> 6) & 0x3F)); s[3] = (char)(0x80 | (cp & 0x3F)); k = 4; }
  buf_add(b, s, k);
}

/* Le um texto entre aspas (l->p no '"'); devolve malloc ou NULL. */
static char *jv_texto(jv_leitor_t *l) {
  buf_t b = {0};
  l->p++;
  while(l->p < l->fim && *l->p != '"') {
    unsigned char c = (unsigned char)*l->p;
    if(c < 0x20) { l->erro = "caractere de controle dentro de texto"; buf_free(&b); return NULL; }
    if(c != '\\') { buf_add(&b, l->p++, 1); continue; }
    if(l->fim - l->p < 2) break;
    char e = l->p[1];
    l->p += 2;
    switch(e) {
    case '"': buf_add(&b, "\"", 1); break;
    case '\\': buf_add(&b, "\\", 1); break;
    case '/': buf_add(&b, "/", 1); break;
    case 'b': case 'f': case 'n': case 'r': case 't': buf_add(&b, " ", 1); break;
    case 'u': {
      unsigned cp, baixo;
      if(l->fim - l->p < 4 || jv_hex4(l->p, &cp)) { l->erro = "escape \\u invalido"; buf_free(&b); return NULL; }
      l->p += 4;
      if(cp >= 0xD800 && cp <= 0xDBFF && l->fim - l->p >= 6 && l->p[0] == '\\' && l->p[1] == 'u' && !jv_hex4(l->p + 2, &baixo) &&
         baixo >= 0xDC00 && baixo <= 0xDFFF) {
        cp = 0x10000 + ((cp - 0xD800) << 10) + (baixo - 0xDC00);
        l->p += 6;
      } else if(cp >= 0xD800 && cp <= 0xDFFF) cp = 0xFFFD;
      jv_utf8(&b, cp);
      break;
    }
    default: l->erro = "escape invalido"; buf_free(&b); return NULL;
    }
  }
  if(l->p >= l->fim) { l->erro = "texto sem fim"; buf_free(&b); return NULL; }
  l->p++;
  if(!b.d) buf_add(&b, "", 0);
  return b.d;
}

static jv_t *jv_valor(jv_leitor_t *l, int prof);

static jv_t *jv_novo(jv_leitor_t *l, jv_tipo_t tipo) {
  if(++l->nos > JV_MAX_NOS) { l->erro = "JSON grande demais"; return NULL; }
  jv_t *v = calloc(1, sizeof *v);
  if(!v) { l->erro = "sem memoria"; return NULL; }
  v->tipo = tipo;
  return v;
}

static jv_t *jv_composto(jv_leitor_t *l, int prof, int objeto) {
  jv_t *v = jv_novo(l, objeto ? JV_OBJETO : JV_LISTA), **ultimo;
  if(!v) return NULL;
  ultimo = &v->filho;
  l->p++;
  jv_espacos(l);
  if(l->p < l->fim && *l->p == (objeto ? '}' : ']')) { l->p++; return v; }
  for(;;) {
    char *chave = NULL;
    jv_espacos(l);
    if(objeto) {
      if(l->p >= l->fim || *l->p != '"') { l->erro = "esperava o nome de um campo"; goto falha; }
      if(!(chave = jv_texto(l))) goto falha;
      jv_espacos(l);
      if(l->p >= l->fim || *l->p != ':') { free(chave); l->erro = "esperava ':'"; goto falha; }
      l->p++;
    }
    jv_t *f = jv_valor(l, prof + 1);
    if(!f) { free(chave); goto falha; }
    f->chave = chave;
    *ultimo = f;
    ultimo = &f->prox;
    jv_espacos(l);
    if(l->p < l->fim && *l->p == ',') { l->p++; continue; }
    if(l->p < l->fim && *l->p == (objeto ? '}' : ']')) { l->p++; return v; }
    l->erro = objeto ? "esperava ',' ou '}'" : "esperava ',' ou ']'";
    goto falha;
  }
falha:
  jv_liberar(v);
  return NULL;
}

static jv_t *jv_valor(jv_leitor_t *l, int prof) {
  if(prof > JV_MAX_PROF) { l->erro = "JSON fundo demais"; return NULL; }
  jv_espacos(l);
  if(l->p >= l->fim) { l->erro = "fim inesperado"; return NULL; }
  char c = *l->p;
  if(c == '{' || c == '[') return jv_composto(l, prof, c == '{');
  if(c == '"') {
    char *s = jv_texto(l);
    if(!s) return NULL;
    jv_t *v = jv_novo(l, JV_TEXTO);
    if(!v) { free(s); return NULL; }
    v->texto = s;
    return v;
  }
  static const struct { const char *s; jv_tipo_t t; int b; } PAL[] = {{"true", JV_LOGICO, 1}, {"false", JV_LOGICO, 0}, {"null", JV_NULO, 0}};
  for(size_t i = 0; i < sizeof PAL / sizeof PAL[0]; i++) {
    size_t n = strlen(PAL[i].s);
    if((size_t)(l->fim - l->p) >= n && !memcmp(l->p, PAL[i].s, n)) {
      l->p += n;
      jv_t *v = jv_novo(l, PAL[i].t);
      if(v) v->logico = PAL[i].b;
      return v;
    }
  }
  if(c == '-' || (c >= '0' && c <= '9')) {
    const char *ini = l->p;
    if(*l->p == '-') l->p++;
    while(l->p < l->fim && strchr("0123456789.eE+-", *l->p)) l->p++;
    jv_t *v = jv_novo(l, JV_NUMERO);
    if(!v) return NULL;
    v->texto = strndup(ini, (size_t)(l->p - ini));
    if(!v->texto) { free(v); l->erro = "sem memoria"; return NULL; }
    return v;
  }
  l->erro = "valor invalido";
  return NULL;
}

/* Documento inteiro (com BOM UTF-8 opcional). NULL se invalido (erro recebe o motivo). */
static jv_t *jv_ler(const char *dados, size_t n, const char **erro) {
  jv_leitor_t l = {dados, dados + n, 0, NULL};
  if(n >= 3 && !memcmp(dados, "\xEF\xBB\xBF", 3)) l.p += 3;
  jv_t *v = jv_valor(&l, 0);
  if(v) {
    jv_espacos(&l);
    if(l.p != l.fim) { jv_liberar(v); v = NULL; l.erro = "sobra depois do JSON"; }
  }
  if(erro) *erro = l.erro ? l.erro : "";
  return v;
}

/* Campo de um objeto (nome sem diferenciar maiusculas: os arquivos da comunidade variam "Offset"/"offset"). */
static const jv_t *jv_campo(const jv_t *o, const char *nome) {
  if(!o || o->tipo != JV_OBJETO) return NULL;
  for(const jv_t *f = o->filho; f; f = f->prox)
    if(f->chave && !strcasecmp(f->chave, nome)) return f;
  return NULL;
}

/* Texto de um campo (numero tambem vale, como escrito); "" se nao tiver. */
static const char *jv_txt(const jv_t *o, const char *nome) {
  const jv_t *f = jv_campo(o, nome);
  return f && (f->tipo == JV_TEXTO || f->tipo == JV_NUMERO) ? f->texto : "";
}

/* ------------------------------------------------------------------ pastas */

static void pasta_catalogo(char *s, size_t tam) {
#ifdef __PROSPERO__
  snprintf(s, tam, "/data/glibren/cheats");
#else
  const char *e = getenv("GLR_TESTE_CHEATS");
  if(e && *e) snprintf(s, tam, "%s", e);
  else snprintf(s, tam, "%s/cheats", g_pasta_dados);
#endif
}

static const char *pasta_onion(void) {
#ifdef __PROSPERO__
  return "/data/OnionHEN/cheats";
#else
  const char *e = getenv("GLR_TESTE_ONION");
  return e && *e ? e : "/nao-existe";
#endif
}

static int ler_arquivo(const char *caminho, buf_t *b, size_t max) {
  FILE *f = fopen(caminho, "rb");
  if(!f) return -1;
  char bloco[16384];
  size_t n;
  int r = 0;
  while((n = fread(bloco, 1, sizeof bloco, f)) > 0) {
    if(b->n + n > max) { r = -1; break; }
    buf_add(b, bloco, n);
  }
  fclose(f);
  if(!r && !b->d) buf_add(b, "", 0);
  return r;
}

/* ------------------------------------------------------------------ jogo aberto e versao */

#ifdef __PROSPERO__
int sceSystemServiceGetAppIdOfRunningBigApp(void) __attribute__((weak));
int sceSystemServiceGetAppTitleId(int app_id, char *title_id) __attribute__((weak));
#endif

typedef struct {
  char tid[16];
  int app_id;          /* -1 = nao sabe (PC ou funcao ausente) */
  char tipo[16];       /* ps5, ps4, menu, desconhecido */
  char nome[256];
  char versao[32];     /* contentVersion (PS5) ou VERSION/APP_VER (PS4) */
  char versao_de[24];  /* de onde veio (campo) */
  char mestre[32];     /* masterVersion (so informativo) */
} jogo_t;

static void jogo_aberto(jogo_t *j) {
  memset(j, 0, sizeof *j);
  j->app_id = -1;
  int sabe = 0;
#ifdef __PROSPERO__
  if(sceSystemServiceGetAppIdOfRunningBigApp && sceSystemServiceGetAppTitleId) {
    int id = sceSystemServiceGetAppIdOfRunningBigApp();
    sabe = 1;
    if(id >= 0) {
      char t[32];
      memset(t, 0, sizeof t);
      if(!sceSystemServiceGetAppTitleId(id, t)) {
        t[sizeof t - 1] = 0;
        snprintf(j->tid, sizeof j->tid, "%s", t);
        j->app_id = id;
      } else sabe = 0;
    }
  }
#endif
  if(!sabe) sabe = app_de_jogo_aberto(j->tid, sizeof j->tid) >= 0;
  const char *t = j->tid;
  if(!sabe) snprintf(j->tipo, sizeof j->tipo, "desconhecido");
  else if(!t[0] || !titulo_valido(t) || !strncmp(t, "NPXS", 4) || !strcmp(t, GLIBREN_TITLE_ID)) snprintf(j->tipo, sizeof j->tipo, "menu");
  else if(!strncmp(t, "CUSA", 4)) snprintf(j->tipo, sizeof j->tipo, "ps4");
  else snprintf(j->tipo, sizeof j->tipo, "ps5");
}

static const char *pasta_appmeta(void) {
#ifdef __PROSPERO__
  return "/user/appmeta";
#else
  const char *e = getenv("GLR_TESTE_APPMETA");
  return e && *e ? e : "/nao-existe";
#endif
}

/* Versao de jogo: so digitos e pontos (vai para nome de arquivo e para a tela). */
static int versao_valida(const char *v) {
  if(!*v || strlen(v) > 20) return 0;
  for(; *v; v++)
    if(!isdigit((unsigned char)*v) && *v != '.') return 0;
  return 1;
}

static uint32_t le32(const unsigned char *p) {
  return p[0] | p[1] << 8 | p[2] << 16 | (uint32_t)p[3] << 24;
}

/* PS4: VERSION e APP_VER do param.sfo (formato em fmt_param.c). Fica com o maior (como o onionHEN). */
static int sfo_versao(const unsigned char *d, size_t n, char *saida, size_t tam, char *campo, size_t tam_campo) {
  if(n >= 0x800 + 0x14 && !memcmp(d, "SCEC", 4)) { d += 0x800; n -= 0x800; }
  if(n < 0x14 || memcmp(d, "\0PSF", 4)) return -1;
  uint32_t chaves = le32(d + 8), dados = le32(d + 12), qtd = le32(d + 16);
  if(qtd > 1000 || 0x14 + (size_t)qtd * 16 > n || chaves >= n || dados >= n) return -1;
  saida[0] = campo[0] = 0;
  for(uint32_t i = 0; i < qtd; i++) {
    const unsigned char *it = d + 0x14 + i * 16;
    uint32_t k = it[0] | it[1] << 8, fmt = it[2] | it[3] << 8, len = le32(it + 4), off = le32(it + 12);
    if((size_t)chaves + k >= n || (fmt & 0xff) != 4 || (size_t)dados + off + len > n || len == 0 || len > 31) continue;
    const char *nome = (const char *)d + chaves + k;
    if(strnlen(nome, n - chaves - k) == n - chaves - k) continue;
    if(strcmp(nome, "VERSION") && strcmp(nome, "APP_VER")) continue;
    char v[32];
    memcpy(v, d + dados + off, len);
    v[len] = 0;
    if(!versao_valida(v)) continue;
    if(!saida[0] || strcmp(v, saida) > 0) {
      snprintf(saida, tam, "%s", v);
      snprintf(campo, tam_campo, "%s", nome);
    }
  }
  return saida[0] ? 0 : -1;
}

/* Nome e versao pelo param.json (PS5) ou param.sfo (PS4) do jogo instalado. Caminhos na ordem do onionHEN/etaHEN. */
static void jogo_versao(jogo_t *j) {
  if(strcmp(j->tipo, "ps5") && strcmp(j->tipo, "ps4")) return;
  static char pastas[MAX_PASTAS][1024];
  static pthread_mutex_t trava = PTHREAD_MUTEX_INITIALIZER;
  char caminhos[6][320], idioma[16] = "pt-BR";
  pthread_mutex_lock(&trava);
  config_ler(pastas, idioma);
  pthread_mutex_unlock(&trava);
  int ps4 = !strcmp(j->tipo, "ps4");
  const char *arq = ps4 ? "param.sfo" : "param.json";
  int n = 0;
  snprintf(caminhos[n++], sizeof caminhos[0], "%s/%s/%s", pasta_appmeta(), j->tid, arq);
#ifdef __PROSPERO__
  snprintf(caminhos[n++], sizeof caminhos[0], "/system_data/priv/appmeta/%s/%s", j->tid, arq);
  snprintf(caminhos[n++], sizeof caminhos[0], "/system_data/priv/appmeta/external/%s/%s", j->tid, arq);
  snprintf(caminhos[n++], sizeof caminhos[0], "/system_ex/app/%s/sce_sys/%s", j->tid, arq);
  snprintf(caminhos[n++], sizeof caminhos[0], "/user/app/%s/sce_sys/%s", j->tid, arq);
#endif
  for(int i = 0; i < n && !j->versao[0]; i++) {
    buf_t b = {0};
    if(ler_arquivo(caminhos[i], &b, 1024 * 1024)) { buf_free(&b); continue; }
    info_jogo_t info;
    memset(&info, 0, sizeof info);
    if(ps4) {
      if(!param_sfo_ler(b.d, b.n, idioma, &info) && !j->nome[0]) snprintf(j->nome, sizeof j->nome, "%s", info.nome);
      sfo_versao((const unsigned char *)b.d, b.n, j->versao, sizeof j->versao, j->versao_de, sizeof j->versao_de);
    } else {
      if(!param_json_ler(b.d, b.n, idioma, &info) && !j->nome[0]) snprintf(j->nome, sizeof j->nome, "%s", info.nome);
      jv_t *r = jv_ler(b.d, b.n, NULL);
      static const char *CAMPOS[] = {"contentVersion", "content_version", "titleVersion", "version", "APP_VER", NULL};
      for(int c = 0; r && CAMPOS[c] && !j->versao[0]; c++) {
        const char *v = jv_txt(r, CAMPOS[c]);
        if(versao_valida(v)) {
          snprintf(j->versao, sizeof j->versao, "%s", v);
          snprintf(j->versao_de, sizeof j->versao_de, "%s", CAMPOS[c]);
        }
      }
      if(r && versao_valida(jv_txt(r, "masterVersion"))) snprintf(j->mestre, sizeof j->mestre, "%s", jv_txt(r, "masterVersion"));
      jv_liberar(r);
    }
    buf_free(&b);
  }
  for(char *c = j->nome; *c; c++) if((unsigned char)*c < ' ') *c = ' ';
}

/* ------------------------------------------------------------------ XML (arvore pequena, so leitura) */

/* Parser XML estrito e pequeno para os .shn/.mc4 (Trainer) e .xml (Illusion): elementos, atributos ("..." ou '...'),
   texto (entidades &lt; &gt; &amp; &quot; &apos; &#N; &#xN; decodificadas), comentarios, <?..?>, <!DOCTYPE..> e
   CDATA. Com limites de tamanho, profundidade e nos. Liberar com xn_liberar. */
typedef struct xa {
  char *nome, *valor;
  struct xa *prox;
} xa_t;

typedef struct xn {
  char *nome, *texto;
  xa_t *attr;
  struct xn *filho, *prox;
} xn_t;

#define XN_MAX_PROF 32
#define XN_MAX_NOS 400000

typedef struct {
  const char *p, *fim;
  int nos;
  const char *erro;
  buf_t tmp;   /* rascunho reaproveitado (buf_add reserva no minimo 1 KB: cada texto e copiado do tamanho certo) */
} xl_t;

static void xn_liberar(xn_t *n) {
  while(n) {
    xn_t *prox = n->prox;
    xn_liberar(n->filho);
    for(xa_t *a = n->attr; a;) {
      xa_t *pa = a->prox;
      free(a->nome);
      free(a->valor);
      free(a);
      a = pa;
    }
    free(n->nome);
    free(n->texto);
    free(n);
    n = prox;
  }
}

/* procura s em [p, fim); NULL se nao achar */
static const char *achar_txt(const char *p, const char *fim, const char *s) {
  size_t n = strlen(s);
  for(; p + n <= fim; p++)
    if(*p == *s && !memcmp(p, s, n)) return p;
  return NULL;
}

static int xl_comeca(const xl_t *l, const char *s) {
  size_t n = strlen(s);
  return (size_t)(l->fim - l->p) >= n && !memcmp(l->p, s, n);
}

static void xl_espacos(xl_t *l) {
  while(l->p < l->fim && (*l->p == ' ' || *l->p == '\t' || *l->p == '\n' || *l->p == '\r')) l->p++;
}

static int xl_nome_char(char c) {
  return isalnum((unsigned char)c) || c == '_' || c == '-' || c == '.' || c == ':' || (unsigned char)c >= 0x80;
}

/* texto [p, q) com as entidades decodificadas, acrescentado em b */
static void xml_entidades(buf_t *b, const char *p, const char *q) {
  while(p < q) {
    const char *amp = p;
    while(amp < q && *amp != '&') amp++;
    if(amp > p) buf_add(b, p, (size_t)(amp - p));
    if(amp >= q) break;
    const char *pv = amp;
    while(pv < q && pv - amp < 12 && *pv != ';') pv++;
    if(pv >= q || *pv != ';') { buf_add(b, "&", 1); p = amp + 1; continue; }
    size_t n = (size_t)(pv - amp - 1);
    const char *e = amp + 1;
    if(n == 2 && !memcmp(e, "lt", 2)) buf_add(b, "<", 1);
    else if(n == 2 && !memcmp(e, "gt", 2)) buf_add(b, ">", 1);
    else if(n == 3 && !memcmp(e, "amp", 3)) buf_add(b, "&", 1);
    else if(n == 4 && !memcmp(e, "quot", 4)) buf_add(b, "\"", 1);
    else if(n == 4 && !memcmp(e, "apos", 4)) buf_add(b, "'", 1);
    else if(n >= 2 && e[0] == '#') {
      unsigned long cp = 0;
      int hexa = e[1] == 'x' || e[1] == 'X', ok = 1;
      for(const char *c = e + 1 + hexa; c < pv; c++) {
        int d = hexa ? (isxdigit((unsigned char)*c) ? (isdigit((unsigned char)*c) ? *c - '0' : (tolower((unsigned char)*c) - 'a' + 10)) : -1)
                     : (isdigit((unsigned char)*c) ? *c - '0' : -1);
        if(d < 0 || cp > 0x10FFFF) { ok = 0; break; }
        cp = cp * (hexa ? 16 : 10) + (unsigned long)d;
      }
      if(!ok || cp > 0x10FFFF || pv == e + 1 + hexa) { buf_add(b, amp, (size_t)(pv - amp + 1)); p = pv + 1; continue; }
      jv_utf8(b, (unsigned)cp);
    } else {
      buf_add(b, amp, (size_t)(pv - amp + 1));   /* entidade desconhecida: fica como esta */
    }
    p = pv + 1;
  }
}

/* texto [p, q) decodificado, em malloc do tamanho certo (NULL sem memoria). atributo = 1: tab e quebra de linha
   literais viram espaco antes das entidades (normalizacao de atributo do XML 1.0, como o xml.etree). */
static char *xl_texto(xl_t *l, const char *p, const char *q, int atributo) {
  l->tmp.n = 0;
  if(atributo) {
    buf_t cru = {0};
    for(const char *c = p; c < q; c++) buf_add(&cru, *c == '\t' || *c == '\n' || *c == '\r' ? " " : c, 1);
    xml_entidades(&l->tmp, cru.d ? cru.d : "", cru.d ? cru.d + cru.n : "");
    buf_free(&cru);
  } else xml_entidades(&l->tmp, p, q);
  return strndup(l->tmp.d && l->tmp.n ? l->tmp.d : "", l->tmp.n);
}

static xn_t *xl_elemento(xl_t *l, int prof);

/* pula comentario, <?..?> e <!DOCTYPE ..>; 1 = pulou, 0 = nao era, -1 = erro */
static int xl_pular_especial(xl_t *l) {
  const char *fim;
  if(xl_comeca(l, "<!--")) fim = achar_txt(l->p + 4, l->fim, "-->"), l->p = fim ? fim + 3 : l->p;
  else if(xl_comeca(l, "<?")) fim = achar_txt(l->p + 2, l->fim, "?>"), l->p = fim ? fim + 2 : l->p;
  else if(xl_comeca(l, "<!DOCTYPE") || xl_comeca(l, "<!doctype")) fim = achar_txt(l->p, l->fim, ">"), l->p = fim ? fim + 1 : l->p;
  else return 0;
  if(!fim) { l->erro = "comentario ou declaracao sem fim"; return -1; }
  return 1;
}

static xn_t *xl_elemento(xl_t *l, int prof) {
  if(prof > XN_MAX_PROF) { l->erro = "XML fundo demais"; return NULL; }
  if(++l->nos > XN_MAX_NOS) { l->erro = "XML grande demais"; return NULL; }
  l->p++;   /* '<' */
  const char *ini = l->p;
  while(l->p < l->fim && xl_nome_char(*l->p)) l->p++;
  if(l->p == ini) { l->erro = "nome de elemento invalido"; return NULL; }
  xn_t *n = calloc(1, sizeof *n);
  if(!n || !(n->nome = strndup(ini, (size_t)(l->p - ini)))) { free(n); l->erro = "sem memoria"; return NULL; }
  xa_t **ua = &n->attr;
  for(;;) {
    xl_espacos(l);
    if(l->p >= l->fim) { l->erro = "elemento sem fim"; goto falha; }
    if(*l->p == '/') {
      if(l->p + 1 < l->fim && l->p[1] == '>') {
        l->p += 2;
        if(!(n->texto = strdup(""))) { l->erro = "sem memoria"; goto falha; }
        return n;
      }
      l->erro = "esperava '/>'";
      goto falha;
    }
    if(*l->p == '>') { l->p++; break; }
    const char *an = l->p;
    while(l->p < l->fim && xl_nome_char(*l->p)) l->p++;
    if(l->p == an) { l->erro = "atributo invalido"; goto falha; }
    const char *an_fim = l->p;
    xl_espacos(l);
    if(l->p >= l->fim || *l->p != '=') { l->erro = "esperava '=' no atributo"; goto falha; }
    l->p++;
    xl_espacos(l);
    if(l->p >= l->fim || (*l->p != '"' && *l->p != '\'')) { l->erro = "atributo sem aspas"; goto falha; }
    char aspas = *l->p++;
    const char *v = l->p;
    while(l->p < l->fim && *l->p != aspas) {
      if(*l->p == '<') { l->erro = "'<' dentro de atributo"; goto falha; }
      l->p++;
    }
    if(l->p >= l->fim) { l->erro = "atributo sem fim"; goto falha; }
    char *valor = xl_texto(l, v, l->p, 1);
    l->p++;
    xa_t *a = calloc(1, sizeof *a);
    if(!valor || !a || !(a->nome = strndup(an, (size_t)(an_fim - an)))) { free(a); free(valor); l->erro = "sem memoria"; goto falha; }
    a->valor = valor;
    *ua = a;
    ua = &a->prox;
    if(++l->nos > XN_MAX_NOS) { l->erro = "XML grande demais"; goto falha; }
  }
  /* conteudo */
  buf_t txt = {0};
  xn_t **uf = &n->filho;
  for(;;) {
    if(l->p >= l->fim) { l->erro = "elemento sem fim"; buf_free(&txt); goto falha; }
    if(*l->p != '<') {
      const char *q = l->p;
      while(q < l->fim && *q != '<') q++;
      xml_entidades(&txt, l->p, q);
      l->p = q;
      continue;
    }
    if(xl_comeca(l, "</")) {
      l->p += 2;
      const char *fn = l->p;
      while(l->p < l->fim && xl_nome_char(*l->p)) l->p++;
      if((size_t)(l->p - fn) != strlen(n->nome) || memcmp(fn, n->nome, (size_t)(l->p - fn))) {
        l->erro = "fechamento de elemento trocado";
        buf_free(&txt);
        goto falha;
      }
      xl_espacos(l);
      if(l->p >= l->fim || *l->p != '>') { l->erro = "esperava '>'"; buf_free(&txt); goto falha; }
      l->p++;
      break;
    }
    if(xl_comeca(l, "<![CDATA[")) {
      const char *fim = achar_txt(l->p + 9, l->fim, "]]>");
      if(!fim) { l->erro = "CDATA sem fim"; buf_free(&txt); goto falha; }
      buf_add(&txt, l->p + 9, (size_t)(fim - l->p - 9));
      l->p = fim + 3;
      continue;
    }
    int r = xl_pular_especial(l);
    if(r < 0) { buf_free(&txt); goto falha; }
    if(r) continue;
    if(xl_comeca(l, "<!")) { l->erro = "declaracao nao suportada"; buf_free(&txt); goto falha; }
    xn_t *f = xl_elemento(l, prof + 1);
    if(!f) { buf_free(&txt); goto falha; }
    *uf = f;
    uf = &f->prox;
  }
  n->texto = strndup(txt.d ? txt.d : "", txt.n);
  buf_free(&txt);
  if(!n->texto) { l->erro = "sem memoria"; goto falha; }
  return n;
falha:
  xn_liberar(n);
  return NULL;
}

/* Documento inteiro (BOM UTF-8 opcional; um so elemento raiz). NULL se invalido (erro recebe o motivo). */
static xn_t *xml_ler(const char *dados, size_t n, const char **erro) {
  xl_t l = {dados, dados + n, 0, NULL, {0}};
  xn_t *raiz = NULL;
  if(n >= 3 && !memcmp(dados, "\xEF\xBB\xBF", 3)) l.p += 3;
  for(;;) {
    xl_espacos(&l);
    if(l.p >= l.fim) break;
    int r = xl_pular_especial(&l);
    if(r < 0) break;
    if(r) continue;
    if(*l.p != '<' || raiz) { l.erro = raiz ? "sobra depois do XML" : "esperava '<'"; break; }
    if(!(raiz = xl_elemento(&l, 0))) break;
  }
  buf_free(&l.tmp);
  if(l.erro || !raiz) {
    xn_liberar(raiz);
    if(erro) *erro = l.erro ? l.erro : "XML vazio";
    return NULL;
  }
  if(erro) *erro = "";
  return raiz;
}

/* atributo (nome sem diferenciar maiusculas) ou NULL */
static const char *xn_attr(const xn_t *n, const char *nome) {
  for(const xa_t *a = n ? n->attr : NULL; a; a = a->prox)
    if(!strcasecmp(a->nome, nome)) return a->valor;
  return NULL;
}

/* proximo filho com o nome (sem diferenciar maiusculas), a partir de "depois" (NULL = do primeiro) */
static const xn_t *xn_filho(const xn_t *n, const char *nome, const xn_t *depois) {
  for(const xn_t *f = depois ? depois->prox : n ? n->filho : NULL; f; f = f->prox)
    if(!strcasecmp(f->nome, nome)) return f;
  return NULL;
}

/* copia s sem espacos nas pontas para saida. -1 se nao couber. */
static int copiar_aparado(const char *s, char *saida, size_t tam) {
  while(*s == ' ' || *s == '\t' || *s == '\n' || *s == '\r') s++;
  size_t n = strlen(s);
  while(n && (s[n - 1] == ' ' || s[n - 1] == '\t' || s[n - 1] == '\n' || s[n - 1] == '\r')) n--;
  if(n >= tam) return -1;
  memmove(saida, s, n);
  saida[n] = 0;
  return 0;
}

/* como copiar_aparado, mas um texto grande demais e cortado (num limite de caractere UTF-8) em vez de recusado */
static void copiar_cortado(const char *s, char *saida, size_t tam) {
  while(*s == ' ' || *s == '\t' || *s == '\n' || *s == '\r') s++;
  size_t n = strlen(s);
  while(n && (s[n - 1] == ' ' || s[n - 1] == '\t' || s[n - 1] == '\n' || s[n - 1] == '\r')) n--;
  if(n >= tam) {
    n = tam - 1;
    while(n && ((unsigned char)s[n] & 0xC0) == 0x80) n--;
  }
  memmove(saida, s, n);
  saida[n] = 0;
}

/* Valor de um campo que pode ser atributo OU elemento filho (formato Illusion). 1 = tem, 0 = nao tem (saida ""),
   -1 = ambiguo (atributo e elemento, ou dois elementos) ou grande demais. */
static int xn_valor(const xn_t *n, const char *nome, char *saida, size_t tam) {
  const char *a = xn_attr(n, nome);
  const xn_t *f = xn_filho(n, nome, NULL);
  saida[0] = 0;
  if((a && f) || (f && xn_filho(n, nome, f))) return -1;
  if(!a && !f) return 0;
  if(f && f->filho) return -1;
  return copiar_aparado(a ? a : f->texto, saida, tam) ? -1 : 1;
}

/* ------------------------------------------------------------------ .mc4: Base64 e AES-256-CBC (so decifrar) */

/* Base64 padrao (espacos e quebras de linha ignorados, "=" so no fim). 0 = ok. */
static int base64_dec(const char *s, size_t n, buf_t *saida) {
  unsigned v = 0;
  int bits = 0, fim = 0;
  for(size_t i = 0; i < n; i++) {
    int c = (unsigned char)s[i], d;
    if(c == ' ' || c == '\t' || c == '\n' || c == '\r') continue;
    if(c == '=') { fim = 1; continue; }
    if(fim) return -1;
    if(c >= 'A' && c <= 'Z') d = c - 'A';
    else if(c >= 'a' && c <= 'z') d = c - 'a' + 26;
    else if(c >= '0' && c <= '9') d = c - '0' + 52;
    else if(c == '+') d = 62;
    else if(c == '/') d = 63;
    else return -1;
    v = (v << 6 | (unsigned)d) & 0xFFFFFF;
    bits += 6;
    if(bits >= 8) {
      bits -= 8;
      char b = (char)((v >> bits) & 0xFF);
      buf_add(saida, &b, 1);
    }
  }
  return 0;
}

/* AES (FIPS-197) escrito a partir da especificacao; a S-box e calculada (inverso em GF(2^8) + transformacao
   afim), sem tabelas copiadas. So a decifragem (InvCipher) com chave de 256 bits. */
static unsigned char g_aes_sb[256], g_aes_isb[256];
static pthread_once_t g_aes_uma = PTHREAD_ONCE_INIT;

static unsigned char rotl8(unsigned char x, int k) { return (unsigned char)(x << k | x >> (8 - k)); }

static void aes_tabelas(void) {
  unsigned char p = 1, q = 1;
  do {
    p = (unsigned char)(p ^ (p << 1) ^ (p & 0x80 ? 0x1B : 0));   /* p * 3 */
    q ^= (unsigned char)(q << 1);                                 /* q / 3 */
    q ^= (unsigned char)(q << 2);
    q ^= (unsigned char)(q << 4);
    if(q & 0x80) q ^= 0x09;
    g_aes_sb[p] = (unsigned char)(q ^ rotl8(q, 1) ^ rotl8(q, 2) ^ rotl8(q, 3) ^ rotl8(q, 4) ^ 0x63);
  } while(p != 1);
  g_aes_sb[0] = 0x63;
  for(int i = 0; i < 256; i++) g_aes_isb[g_aes_sb[i]] = (unsigned char)i;
}

static unsigned char gmul(unsigned char a, unsigned char b) {
  unsigned char r = 0;
  while(b) {
    if(b & 1) r ^= a;
    a = (unsigned char)((a << 1) ^ (a & 0x80 ? 0x1B : 0));
    b >>= 1;
  }
  return r;
}

/* chave de 32 bytes -> 15 chaves de rodada (240 bytes) */
static void aes256_chaves(const unsigned char *chave, unsigned char *w) {
  static const unsigned char RCON[8] = {0, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40};
  memcpy(w, chave, 32);
  for(int i = 8; i < 60; i++) {
    unsigned char t[4];
    memcpy(t, w + (i - 1) * 4, 4);
    if(i % 8 == 0) {
      unsigned char x = t[0];
      t[0] = (unsigned char)(g_aes_sb[t[1]] ^ RCON[i / 8]);
      t[1] = g_aes_sb[t[2]];
      t[2] = g_aes_sb[t[3]];
      t[3] = g_aes_sb[x];
    } else if(i % 8 == 4) {
      for(int k = 0; k < 4; k++) t[k] = g_aes_sb[t[k]];
    }
    for(int k = 0; k < 4; k++) w[i * 4 + k] = (unsigned char)(w[(i - 8) * 4 + k] ^ t[k]);
  }
}

static void aes256_decifrar_bloco(const unsigned char *w, unsigned char *s) {
  unsigned char t[16];
  for(int k = 0; k < 16; k++) s[k] ^= w[14 * 16 + k];
  for(int rodada = 13; rodada >= 0; rodada--) {
    /* InvShiftRows (linha r anda r colunas para a direita) + InvSubBytes */
    for(int c = 0; c < 4; c++)
      for(int r = 0; r < 4; r++) t[r + 4 * c] = g_aes_isb[s[r + 4 * ((c - r + 4) % 4)]];
    for(int k = 0; k < 16; k++) s[k] = (unsigned char)(t[k] ^ w[rodada * 16 + k]);
    if(!rodada) break;
    for(int c = 0; c < 4; c++) {   /* InvMixColumns */
      unsigned char a0 = s[4 * c], a1 = s[4 * c + 1], a2 = s[4 * c + 2], a3 = s[4 * c + 3];
      s[4 * c] = (unsigned char)(gmul(a0, 14) ^ gmul(a1, 11) ^ gmul(a2, 13) ^ gmul(a3, 9));
      s[4 * c + 1] = (unsigned char)(gmul(a0, 9) ^ gmul(a1, 14) ^ gmul(a2, 11) ^ gmul(a3, 13));
      s[4 * c + 2] = (unsigned char)(gmul(a0, 13) ^ gmul(a1, 9) ^ gmul(a2, 14) ^ gmul(a3, 11));
      s[4 * c + 3] = (unsigned char)(gmul(a0, 11) ^ gmul(a1, 13) ^ gmul(a2, 9) ^ gmul(a3, 14));
    }
  }
}

/* .mc4 -> texto XML (malloc em saida, terminado em 0). Base64 -> AES-256-CBC -> tira o padding PKCS#7.
   Chave e IV: os do GoldHEN Cheat Manager (publicos no codigo aberto dele e no do onionHEN). 0 = ok. */
static int mc4_decodificar(const char *dados, size_t n, buf_t *saida, const char **erro) {
  static const unsigned char CHAVE[32] = "304c6528f659c766110239a51cl5dd9c";
  static const unsigned char IV[16] = "u@}kzW2u[u(8DWar";
  buf_t bin = {0};
  *erro = "";
  if(base64_dec(dados, n, &bin)) { buf_free(&bin); *erro = "mc4: Base64 invalido"; return -1; }
  if(!bin.n || bin.n % 16) { buf_free(&bin); *erro = "mc4: tamanho invalido"; return -1; }
  pthread_once(&g_aes_uma, aes_tabelas);
  unsigned char w[240], anterior[16], atual[16];
  aes256_chaves(CHAVE, w);
  memcpy(anterior, IV, 16);
  unsigned char *d = (unsigned char *)bin.d;
  for(size_t i = 0; i < bin.n; i += 16) {
    memcpy(atual, d + i, 16);
    aes256_decifrar_bloco(w, d + i);
    for(int k = 0; k < 16; k++) d[i + k] ^= anterior[k];
    memcpy(anterior, atual, 16);
  }
  unsigned pad = d[bin.n - 1];
  int ok = pad >= 1 && pad <= 16;
  for(unsigned k = 1; ok && k <= pad; k++) ok = d[bin.n - k] == pad;
  if(!ok) { buf_free(&bin); *erro = "mc4: padding invalido (chave errada?)"; return -1; }
  bin.n -= pad;
  buf_add(&bin, "", 1);   /* termina em 0 */
  bin.n--;
  *saida = bin;
  return 0;
}

/* ------------------------------------------------------------------ catalogo (download) */

static pthread_mutex_t g_trava_cat = PTHREAD_MUTEX_INITIALIZER;
static char g_cat_estado[16] = "parado";   /* parado, baixando, extraindo, pronto, erro */
static char g_cat_erro[200];
static unsigned long long g_cat_bytes;

static void cat_estado(const char *estado, const char *erro) {
  pthread_mutex_lock(&g_trava_cat);
  snprintf(g_cat_estado, sizeof g_cat_estado, "%s", estado);
  snprintf(g_cat_erro, sizeof g_cat_erro, "%s", erro ? erro : "");
  pthread_mutex_unlock(&g_trava_cat);
}

/* Apaga uma pasta so com arquivos (as pastas json/, shn/ e mc4/ do catalogo). Ignora o que nao existe. */
static void apagar_pasta_plana(const char *pasta) {
  DIR *d = opendir(pasta);
  if(d) {
    struct dirent *e;
    char c[1024];
    while((e = readdir(d))) {
      if(!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
      snprintf(c, sizeof c, "%s/%s", pasta, e->d_name);
      unlink(c);
    }
    closedir(d);
  }
  rmdir(pasta);
}

typedef struct {
  int fd;
  unsigned long long n;
  int excedeu, erro;
} baixando_t;

static int recebeu_zip(const void *dados, size_t n, void *ctx) {
  baixando_t *b = ctx;
  if(b->n + n > MAX_ZIP) { b->excedeu = 1; return 1; }
  const char *p = dados;
  size_t feito = 0;
  while(feito < n) {
    ssize_t w = write(b->fd, p + feito, n - feito);
    if(w <= 0) { b->erro = 1; return 1; }
    feito += (size_t)w;
  }
  b->n += n;
  pthread_mutex_lock(&g_trava_cat);
  g_cat_bytes = b->n;
  pthread_mutex_unlock(&g_trava_cat);
  return 0;
}

/* Formatos extraidos do zip (o .xml do Illusion nao vem no HEN-Cheats-Collection). */
#define FMT_ZIP 3

/* "<topo>/cheats/<fmt>/<arquivo>.<fmt>" (ou sem a pasta de topo), com fmt json, shn ou mc4: devolve o nome do
   arquivo e o formato em *fmt; senao NULL. */
static const char *arquivo_do_catalogo(const char *nome, int *fmt) {
  for(int f = 0; f < FMT_ZIP; f++) {
    char pasta[24];
    snprintf(pasta, sizeof pasta, "cheats/%s/", FMT_NOME[f]);
    const char *m = strstr(nome, pasta);
    if(!m) continue;
    if(m != nome) {   /* antes: uma unica pasta de topo */
      const char *barra = strchr(nome, '/');
      if(!barra || barra + 1 != m) return NULL;
    }
    const char *arq = m + strlen(pasta);
    size_t n = strlen(arq), ne = strlen(FMT_EXT[f]);
    if(n <= ne || n > 200 || strchr(arq, '/') || strcasecmp(arq + n - ne, FMT_EXT[f]) || !nome_valido(arq) || arq[0] == '.') return NULL;
    *fmt = f;
    return arq;
  }
  return NULL;
}

static void *baixar_catalogo(void *arg) {
  (void)arg;
  char pasta[512], parcial[600], novo[FMT_ZIP][600], atual[FMT_ZIP][600], antigo[FMT_ZIP][600], info[600], erro[200] = "";
  pasta_catalogo(pasta, sizeof pasta);
  snprintf(parcial, sizeof parcial, "%s/.catalogo.zip.parcial", pasta);
  for(int f = 0; f < FMT_ZIP; f++) {
    snprintf(novo[f], sizeof novo[f], "%s/%s.novo", pasta, FMT_NOME[f]);
    snprintf(atual[f], sizeof atual[f], "%s/%s", pasta, FMT_NOME[f]);
    snprintf(antigo[f], sizeof antigo[f], "%s/%s.antigo", pasta, FMT_NOME[f]);
  }
  snprintf(info, sizeof info, "%s/catalogo.txt", pasta);
  const char *url = URL_CATALOGO;
#ifndef __PROSPERO__
  if(getenv("GLR_TESTE_CHEATS_URL")) url = getenv("GLR_TESTE_CHEATS_URL");
#endif
  zip_t z;
  memset(&z, 0, sizeof z);
  z.fd = -1;
  int abriu_zip = 0, qtd = 0, qtd_fmt[FMT_ZIP] = {0}, trocou = 0;
  baixando_t b = {-1, 0, 0, 0};
  struct statvfs sv;
  if(mkdir_p(pasta)) { snprintf(erro, sizeof erro, "nao criou %s (errno %d)", pasta, errno); goto fim; }
  if(!statvfs(pasta, &sv) && (unsigned long long)sv.f_bavail * sv.f_frsize < FOLGA_DISCO) {
    snprintf(erro, sizeof erro, "pouco espaco livre no PS5 (%llu MB)", (unsigned long long)sv.f_bavail * sv.f_frsize / (1024 * 1024));
    goto fim;
  }
  diario("cheats: baixando o catalogo (%s)", url);
  unlink(parcial);
  if((b.fd = open(parcial, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644)) < 0) {
    snprintf(erro, sizeof erro, "nao criou o arquivo do download (errno %d)", errno);
    goto fim;
  }
  int status = https_baixar(url, recebeu_zip, &b);
  int fechou = close(b.fd);
  diario("cheats: catalogo: status %d, %llu bytes", status, b.n);
  if(status != 200 || b.excedeu || b.erro || fechou) {
    if(status != 200) snprintf(erro, sizeof erro, "nao baixou o catalogo (HTTP %d)", status);
    else if(b.excedeu) snprintf(erro, sizeof erro, "catalogo maior que o limite");
    else snprintf(erro, sizeof erro, "erro ao gravar o download");
    goto fim;
  }
  cat_estado("extraindo", NULL);
  char ezip[160] = "";
  if(zip_abrir(&z, parcial, MAX_TOTAL_ZIP, ezip, sizeof ezip)) {
    snprintf(erro, sizeof erro, "zip recusado: %s", ezip);
    goto fim;
  }
  abriu_zip = 1;
  for(int f = 0; f < FMT_ZIP; f++) {
    apagar_pasta_plana(novo[f]);
    if(mkdir(novo[f], 0777)) { snprintf(erro, sizeof erro, "nao criou %s (errno %d)", novo[f], errno); goto fim; }
  }
  for(uint32_t i = 0; i < z.n; i++) {
    const zip_entrada_t *e = &z.e[i];
    int f = 0;
    const char *arq = e->pasta ? NULL : arquivo_do_catalogo(e->nome, &f);
    if(!arq || e->tam > MAX_JSON) continue;
    buf_t j = {0};
    char e2[160], destino[1024];
    if(zip_ler(&z, e, &j, MAX_JSON, e2, sizeof e2)) {
      diario("cheats: catalogo: %s pulado (%s)", arq, e2);
      buf_free(&j);
      continue;
    }
    snprintf(destino, sizeof destino, "%s/%s", novo[f], arq);
    int fd = open(destino, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644);
    int ok = fd >= 0 && write(fd, j.d ? j.d : "", j.n) == (ssize_t)j.n;
    if(fd >= 0 && close(fd)) ok = 0;
    buf_free(&j);
    if(!ok) { snprintf(erro, sizeof erro, "erro ao gravar %.100s (errno %d)", arq, errno); goto fim; }
    qtd++;
    qtd_fmt[f]++;
  }
  if(!qtd) { snprintf(erro, sizeof erro, "o zip nao tem cheats (json, shn ou mc4)"); goto fim; }
  /* troca cada pasta inteira: X -> X.antigo, X.novo -> X (se uma falhar, as ja trocadas voltam) */
  for(trocou = 0; trocou < FMT_ZIP; trocou++) {
    int f = trocou;
    apagar_pasta_plana(antigo[f]);
    if(rename(atual[f], antigo[f]) && errno != ENOENT) { snprintf(erro, sizeof erro, "nao trocou a pasta (errno %d)", errno); break; }
    if(rename(novo[f], atual[f])) {
      snprintf(erro, sizeof erro, "nao trocou a pasta (errno %d)", errno);
      rename(antigo[f], atual[f]);
      break;
    }
  }
  if(erro[0]) {
    for(int f = trocou - 1; f >= 0; f--) {
      apagar_pasta_plana(atual[f]);
      rename(antigo[f], atual[f]);
    }
    goto fim;
  }
  for(int f = 0; f < FMT_ZIP; f++) apagar_pasta_plana(antigo[f]);
  FILE *fi = fopen(info, "w");
  if(fi) {
    fprintf(fi, "quando=%lld\narquivos=%d\nbytes=%llu\njson=%d\nshn=%d\nmc4=%d\n", (long long)time(NULL), qtd, b.n, qtd_fmt[FMT_JSON],
            qtd_fmt[FMT_SHN], qtd_fmt[FMT_MC4]);
    fclose(fi);
  }
fim:
  if(abriu_zip) zip_fechar(&z);
  unlink(parcial);
  for(int f = 0; f < FMT_ZIP; f++) apagar_pasta_plana(novo[f]);
  if(erro[0]) {
    diario("cheats: catalogo: %s", erro);
    cat_estado("erro", erro);
  } else {
    diario("cheats: catalogo pronto: %d arquivos (%d .json, %d .shn, %d .mc4)", qtd, qtd_fmt[FMT_JSON], qtd_fmt[FMT_SHN], qtd_fmt[FMT_MC4]);
    cat_estado("pronto", NULL);
  }
  return NULL;
}

int cheats_catalogo_baixar(char *msg, size_t tam) {
  pthread_mutex_lock(&g_trava_cat);
  int ocupado = !strcmp(g_cat_estado, "baixando") || !strcmp(g_cat_estado, "extraindo");
  if(!ocupado) {
    snprintf(g_cat_estado, sizeof g_cat_estado, "baixando");
    g_cat_erro[0] = 0;
    g_cat_bytes = 0;
  }
  pthread_mutex_unlock(&g_trava_cat);
  if(ocupado) { snprintf(msg, tam, "o catalogo ja esta sendo baixado"); return -1; }
  if(criar_thread(baixar_catalogo, NULL, NULL)) {
    cat_estado("erro", "nao criou a thread do download");
    snprintf(msg, tam, "nao criou a thread do download");
    return -1;
  }
  msg[0] = 0;
  return 0;
}

static void catalogo_json(buf_t *b) {
  char pasta[512], info[600], linha[128];
  pasta_catalogo(pasta, sizeof pasta);
  snprintf(info, sizeof info, "%s/catalogo.txt", pasta);
  long long quando = 0;
  int arquivos = 0, por_fmt[FMT_ZIP] = {0};
  FILE *f = fopen(info, "r");
  while(f && fgets(linha, sizeof linha, f)) {
    if(!strncmp(linha, "quando=", 7)) quando = atoll(linha + 7);
    else if(!strncmp(linha, "arquivos=", 9)) arquivos = atoi(linha + 9);
    for(int k = 0; k < FMT_ZIP; k++) {
      size_t n = strlen(FMT_NOME[k]);
      if(!strncmp(linha, FMT_NOME[k], n) && linha[n] == '=') por_fmt[k] = atoi(linha + n + 1);
    }
  }
  if(f) fclose(f);
  struct stat st;
  int onion = !stat(pasta_onion(), &st) && S_ISDIR(st.st_mode);
  pthread_mutex_lock(&g_trava_cat);
  buf_str(b, "\"catalogo\":{\"estado\":");
  buf_json(b, g_cat_estado);
  buf_str(b, ",\"erro\":");
  buf_json(b, g_cat_erro);
  buf_fmt(b, ",\"bytes\":%llu,\"quando\":%lld,\"arquivos\":%d,\"json\":%d,\"shn\":%d,\"mc4\":%d,\"onion\":%s}", g_cat_bytes, quando, arquivos,
          por_fmt[FMT_JSON], por_fmt[FMT_SHN], por_fmt[FMT_MC4], onion ? "true" : "false");
  pthread_mutex_unlock(&g_trava_cat);
}

/* ------------------------------------------------------------------ escolha dos arquivos */

typedef struct {
  char caminho[700];
  char nome[256];
  const char *origem;   /* "onionhen" ou "catalogo" */
  int fmt;              /* FMT_JSON.. */
} arquivo_t;

/* Formato pela extensao (-1 = nenhum). */
static int formato_do_nome(const char *nome) {
  size_t n = strlen(nome);
  for(int f = 0; f < FMT_QTD; f++) {
    size_t ne = strlen(FMT_EXT[f]);
    if(n > ne && !strcasecmp(nome + n - ne, FMT_EXT[f])) return f;
  }
  return -1;
}

/* .json/.shn/.mc4: "<TID>_<VERSAO>" seguido de "_" ou da extensao. .xml: "<TID>.xml" ou "<TID>_<VERSAO>[_..].xml"
   (sem diferenciar maiusculas no Title ID e na extensao). Devolve o formato ou -1. */
static int nome_combina(const char *nome, const char *tid, const char *versao) {
  size_t nt = strlen(tid), nv = strlen(versao), n = strlen(nome);
  int f = formato_do_nome(nome);
  if(f < 0 || !nt || !nv) return -1;
  size_t ne = strlen(FMT_EXT[f]);
  if(n < nt + ne || strncasecmp(nome, tid, nt)) return -1;
  if(f == FMT_XML && n == nt + ne) return f;   /* <TID>.xml */
  if(nome[nt] != '_' || strncmp(nome + nt + 1, versao, nv)) return -1;
  const char *depois = nome + nt + 1 + nv;
  return *depois == '_' || depois == nome + n - ne ? f : -1;
}

/* Ordem: formato (json > shn > mc4 > xml), origem (onionHEN antes do catalogo) e nome. */
static int cmp_arquivo(const void *a, const void *b) {
  const arquivo_t *x = a, *y = b;
  if(x->fmt != y->fmt) return x->fmt - y->fmt;
  int ox = !strcmp(x->origem, "onionhen") ? 0 : 1, oy = !strcmp(y->origem, "onionhen") ? 0 : 1;
  if(ox != oy) return ox - oy;
  return strcmp(x->nome, y->nome);
}

static int achar_arquivos(const jogo_t *j, arquivo_t *lista, int max) {
  int n = 0;
  char cat[512], sub[FMT_QTD][600];
  pasta_catalogo(cat, sizeof cat);
  for(int f = 0; f < FMT_QTD; f++) snprintf(sub[f], sizeof sub[f], "%s/%s", cat, FMT_NOME[f]);
  const char *pastas[1 + FMT_QTD] = {pasta_onion(), sub[0], sub[1], sub[2], sub[3]};
  for(int p = 0; p < 1 + FMT_QTD; p++) {
    DIR *d = opendir(pastas[p]);
    if(!d) continue;
    struct dirent *e;
    while((e = readdir(d)) && n < max) {
      int f = nome_combina(e->d_name, j->tid, j->versao);
      if(f < 0 || (p && f != p - 1) || strlen(e->d_name) >= sizeof lista[0].nome) continue;
      int repetido = 0;
      for(int i = 0; i < n && !repetido; i++) repetido = !strcasecmp(lista[i].nome, e->d_name);
      if(repetido) continue;   /* o mesmo nome no onionHEN e no catalogo: vale o do onionHEN (lido primeiro) */
      snprintf(lista[n].caminho, sizeof lista[n].caminho, "%s/%s", pastas[p], e->d_name);
      snprintf(lista[n].nome, sizeof lista[n].nome, "%s", e->d_name);
      lista[n].origem = p ? "catalogo" : "onionhen";
      lista[n].fmt = f;
      n++;
    }
    closedir(d);
  }
  qsort(lista, (size_t)n, sizeof lista[0], cmp_arquivo);
  return n;
}

/* ------------------------------------------------------------------ memoria do jogo (leitura e escrita) */

static int digito_hex(int c) {
  return c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1;
}

/* "C6 80 cc 00" ou "C6-80-CC-00" (.shn) -> bytes. -1 se nao for hex par ou passar de max. */
static int hex_bytes(const char *s, unsigned char *saida, size_t max) {
  size_t n = 0;
  int alto = -1;
  for(; *s; s++) {
    if(*s == ' ' || *s == '\t' || *s == '\n' || *s == '\r' || *s == '-' || *s == '_') continue;
    int d = digito_hex(*s);
    if(d < 0) return -1;
    if(alto < 0) { alto = d; continue; }
    if(n == max) return -1;
    saida[n++] = (unsigned char)(alto << 4 | d);
    alto = -1;
  }
  return alto >= 0 ? -1 : (int)n;
}

/* Offset em hex (com ou sem 0x). -1 se invalido. */
static int hex_offset(const char *s, uint64_t *v) {
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) s += 2;
  if(!*s || strlen(s) > 16) return -1;
  *v = 0;
  for(; *s; s++) {
    int d = digito_hex(*s);
    if(d < 0) return -1;
    *v = *v << 4 | (uint64_t)d;
  }
  return 0;
}

static const char *base_nome(const char *caminho) {
  const char *b = strrchr(caminho, '/');
  return b ? b + 1 : caminho;
}

#define MAX_PIDS 8
#define PAGINA 4096ull

typedef struct {
  int pids[MAX_PIDS];
  int n;
  char comm[MAX_PIDS][24];
} processos_t;

#ifdef __PROSPERO__
/* Mesmo layout da amostra "ps" do ps5-payload-sdk (sceKernelGetAppInfo). */
typedef struct {
  uint32_t app_id;
  uint64_t desconhecido1;
  uint32_t app_type;
  char title_id[10];
  char desconhecido2[0x3c];
} app_info_t;
int sceKernelGetAppInfo(pid_t pid, app_info_t *info) __attribute__((weak));

/* Processos do jogo aberto: mesmo app id (ou, sem app id, mesmo Title ID). O "eboot.bin" fica primeiro. */
static void processos_do_jogo(const jogo_t *j, processos_t *pr) {
  pr->n = 0;
  if(!sceKernelGetAppInfo) return;
  int mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_PROC, 0};
  size_t tam = 0;
  if(sysctl(mib, 4, NULL, &tam, NULL, 0) || !tam) return;
  tam += 16 * sizeof(struct kinfo_proc);
  char *lista = malloc(tam);
  if(!lista) return;
  if(sysctl(mib, 4, lista, &tam, NULL, 0)) { free(lista); return; }
  for(char *p = lista; p + sizeof(int) <= lista + tam;) {
    struct kinfo_proc *ki = (struct kinfo_proc *)p;
    if(ki->ki_structsize <= 0) break;
    p += ki->ki_structsize;
    app_info_t ai;
    memset(&ai, 0, sizeof ai);
    if(sceKernelGetAppInfo(ki->ki_pid, &ai)) continue;
    ai.title_id[sizeof ai.title_id - 1] = 0;
    int mesmo = j->app_id >= 0 ? (int)ai.app_id == j->app_id : !strncmp(ai.title_id, j->tid, 9);
    if(!mesmo || pr->n == MAX_PIDS) continue;
    int i = pr->n++;
    if(!strcmp(ki->ki_comm, "eboot.bin") && i) {   /* eboot primeiro */
      pr->pids[i] = pr->pids[0];
      memcpy(pr->comm[i], pr->comm[0], sizeof pr->comm[0]);
      i = 0;
    }
    pr->pids[i] = ki->ki_pid;
    snprintf(pr->comm[i], sizeof pr->comm[i], "%s", ki->ki_comm);
  }
  free(lista);
}

/* Base do modulo (ex.: "eboot.bin") no processo. 0 = achou. */
static int base_do_modulo(int pid, const char *modulo, uint64_t *base) {
  uint32_t h = 0;
  if(kernel_dynlib_handle(pid, modulo, &h)) return -1;
  intptr_t b = kernel_dynlib_mapbase_addr(pid, h);
  if(!b || b == -1) return -1;
  *base = (uint64_t)b;
  return 0;
}

/* Tamanho do pedaco que fica dentro da pagina de 4 KB do endereco. O caminho pelo DMAP do SDK
   (crt/kernel_procio.c da v0.45) limita cada copia com "plen > len" em vez de "len - i": um trecho que cruza a
   fronteira de pagina copiaria bytes a mais (alem do buffer na leitura; alem do trecho, NA MEMORIA DO JOGO, na
   escrita). Pedacos dentro de uma pagina de 4 KB (que fica inteira dentro de uma pagina grande) evitam isso. */
static size_t pedaco(uint64_t endereco, size_t n) {
  size_t k = (size_t)(PAGINA - (endereco & (PAGINA - 1)));
  return k < n ? k : n;
}

/* Leitura: kernel_proc_copyout (mdbg de leitura e, se falhar, tabela de paginas + DMAP; ver o topo). */
static int ler_memoria(int pid, uint64_t endereco, void *saida, size_t n) {
  unsigned char *s = saida;
  while(n) {
    size_t k = pedaco(endereco, n);
    if(kernel_proc_copyout(pid, (intptr_t)endereco, s, k)) return -1;
    endereco += k;
    s += k;
    n -= k;
  }
  return 0;
}

/* ESCRITA (Fase 1): kernel_proc_copyin do SDK = mdbg de escrita e, se falhar (bloqueado no fw >= 8.40), tabela de
   paginas + DMAP com o kernel R/W do elfldr. Pelo DMAP grava na memoria FISICA e ignora a protecao da pagina (o
   codigo do jogo e so leitura e execucao), como o ps5debug-NG. Quem chama sempre le de volta e confere. */
static int escrever_memoria(int pid, uint64_t endereco, const void *dados, size_t n) {
  const unsigned char *s = dados;
  while(n) {
    size_t k = pedaco(endereco, n);
    if(kernel_proc_copyin(pid, s, (intptr_t)endereco, k)) return -1;
    endereco += k;
    s += k;
    n -= k;
  }
  return 0;
}
#else
/* Teste: GLR_TESTE_CHEATS_PID = so este pid; se comecar com "/", e um arquivo com o pid (o teste troca de "jogo"). */
static int pid_de_teste(void) {
  const char *so = getenv("GLR_TESTE_CHEATS_PID");
  if(!so || !*so) return 0;
  if(*so != '/') return atoi(so);
  char linha[32] = "";
  FILE *f = fopen(so, "r");
  if(f && !fgets(linha, sizeof linha, f)) linha[0] = 0;
  if(f) fclose(f);
  return atoi(linha) > 0 ? atoi(linha) : -1;
}

/* PC: processos chamados "eboot.bin" (o alvo de teste, testes/cheat_alvo.c). */
static void processos_do_jogo(const jogo_t *j, processos_t *pr) {
  (void)j;
  pr->n = 0;
  int so = pid_de_teste();
  DIR *d = opendir("/proc");
  if(!d) return;
  struct dirent *e;
  while((e = readdir(d)) && pr->n < MAX_PIDS) {
    if(!isdigit((unsigned char)e->d_name[0])) continue;
    char c[300], comm[32] = "";
    snprintf(c, sizeof c, "/proc/%s/comm", e->d_name);
    FILE *f = fopen(c, "r");
    if(!f) continue;
    if(!fgets(comm, sizeof comm, f)) comm[0] = 0;
    fclose(f);
    comm[strcspn(comm, "\n")] = 0;
    if(strcmp(comm, "eboot.bin")) continue;
    if(so && so != atoi(e->d_name)) continue;   /* teste: so este pid (a demo pode ter outro eboot.bin) */
    pr->pids[pr->n] = atoi(e->d_name);
    snprintf(pr->comm[pr->n], sizeof pr->comm[0], "%s", comm);
    pr->n++;
  }
  closedir(d);
}

static int base_do_modulo(int pid, const char *modulo, uint64_t *base) {
  char c[64], linha[1200];
  snprintf(c, sizeof c, "/proc/%d/maps", pid);
  FILE *f = fopen(c, "r");
  if(!f) return -1;
  int r = -1;
  while(r && fgets(linha, sizeof linha, f)) {
    unsigned long long ini;
    char caminho[1024] = "";
    linha[strcspn(linha, "\n")] = 0;
    if(sscanf(linha, "%llx-%*x %*s %*s %*s %*s %1023s", &ini, caminho) == 2 && !strcmp(base_nome(caminho), modulo)) {
      *base = ini;
      r = 0;
    }
  }
  fclose(f);
  return r;
}

/* Leitura no PC: /proc/<pid>/mem aberto em O_RDONLY. */
static int ler_memoria(int pid, uint64_t endereco, void *saida, size_t n) {
  char c[64];
  snprintf(c, sizeof c, "/proc/%d/mem", pid);
  int fd = open(c, O_RDONLY);
  if(fd < 0) return -1;
  ssize_t r = pread(fd, saida, n, (off_t)endereco);
  close(fd);
  return r == (ssize_t)n ? 0 : -1;
}

/* ESCRITA no PC (modo de teste): /proc/<pid>/mem em O_RDWR, so no alvo de teste (processo "eboot.bin").
   GLR_TESTE_CHEATS_FALHAR=<endereco hex>: a escrita nesse endereco falha sem gravar nada (teste do desfazer). */
static int escrever_memoria(int pid, uint64_t endereco, const void *dados, size_t n) {
  const char *falhar = getenv("GLR_TESTE_CHEATS_FALHAR");
  uint64_t f;
  if(falhar && *falhar && !hex_offset(falhar, &f) && f == endereco) return -1;
  char c[64];
  snprintf(c, sizeof c, "/proc/%d/mem", pid);
  int fd = open(c, O_RDWR);
  if(fd < 0) return -1;
  ssize_t r = pwrite(fd, dados, n, (off_t)endereco);
  close(fd);
  return r == (ssize_t)n ? 0 : -1;
}
#endif

/* ------------------------------------------------------------------ faixas do modulo, protecao e padroes (Fase 2, so leitura) */

/* Protecao de memoria (bits do vm_map do FreeBSD; o PS5 tem bits de GPU acima destes). */
#define PROT_L 1   /* leitura */
#define PROT_E 2   /* escrita */
#define PROT_X 4   /* execucao */
#define MAX_FAIXAS 16

typedef struct {
  uint64_t ini, tam;
  int prot;
} faixa_t;

/* Padrao em hex para o diario/tela ("??" nos bytes livres; ate 32 bytes, depois ".."). */
static void hex_txt_simples(char *s, size_t tam, const unsigned char *pad, const unsigned char *masc, int n) {
  size_t p = 0;
  s[0] = 0;
  for(int i = 0; i < n && i < 32 && p + 4 < tam; i++)
    p += (size_t)(masc && !masc[i] ? snprintf(s + p, tam - p, "??") : snprintf(s + p, tam - p, "%02X", pad[i]));
  if(n > 32 && p + 3 < tam) snprintf(s + p, tam - p, "..");
}

static uint64_t le64(const unsigned char *p) { return (uint64_t)le32(p) | (uint64_t)le32(p + 4) << 32; }
static unsigned le16(const unsigned char *p) { return (unsigned)(p[0] | p[1] << 8); }

/* Faixas pelos cabecalhos ELF na base (quando o modulo foi carregado com eles; no PS5 o eboot costuma comecar
   direto no codigo e isto falha - entao as faixas vem do dl_get_info_2). */
static int faixas_elf(int pid, uint64_t base, faixa_t *f, int max) {
  unsigned char h[64];
  if(ler_memoria(pid, base, h, sizeof h) || memcmp(h, "\x7f" "ELF", 4) || h[4] != 2 || h[5] != 1) return -1;
  uint64_t phoff = le64(h + 32);
  unsigned phent = le16(h + 54), phnum = le16(h + 56);
  if(phent != 56 || !phnum || phnum > 128 || phoff > (1u << 20)) return -1;
  unsigned char *ph = malloc((size_t)phnum * 56);
  if(!ph || ler_memoria(pid, base + phoff, ph, (size_t)phnum * 56)) { free(ph); return -1; }
  uint64_t menor = UINT64_MAX, alinha = 0x1000;
  for(unsigned i = 0; i < phnum; i++) {
    const unsigned char *x = ph + i * 56;
    uint64_t al = le64(x + 48);
    if(le32(x) != 1 || !le64(x + 40)) continue;   /* so PT_LOAD com tamanho */
    if(le64(x + 16) < menor) menor = le64(x + 16);
    if(al > alinha && al <= (1u << 20) && !(al & (al - 1))) alinha = al;
  }
  int n = -1;
  if(menor != UINT64_MAX && base >= (menor & ~(alinha - 1))) {
    uint64_t vies = base - (menor & ~(alinha - 1));
    n = 0;
    for(unsigned i = 0; i < phnum && n < max; i++) {
      const unsigned char *x = ph + i * 56;
      uint32_t flags = le32(x + 4);
      uint64_t vaddr = le64(x + 16), memsz = le64(x + 40);
      if(le32(x) != 1 || !memsz || memsz > (1ull << 32)) continue;
      f[n].ini = vies + vaddr;
      f[n].tam = memsz;
      f[n].prot = (flags & 4 ? PROT_L : 0) | (flags & 2 ? PROT_E : 0) | (flags & 1 ? PROT_X : 0);
      n++;
    }
  }
  free(ph);
  return n > 0 ? n : -1;
}

#ifdef __PROSPERO__
#define SYS_DL_GET_LIST 0x217
#define SYS_DL_GET_INFO_2 0x2cd
#define DL_INFO_TAM 16384   /* a resposta tem ~2,7 KB; buffer folgado e zerado */
/* Layout da resposta do dl_get_info_2 (como no NineS/onionHEN): nome[128] @0, secoes[4] {vaddr u64, tamanho u64,
   prot u32 + 4} @216, nome da lib[128] @1512, caminho[1024] @1644. So leitura; a secao 0 tem de ser a base que o SDK
   deu (senao a resposta nao e confiavel e e descartada). */
static int faixas_dl(int pid, const char *modulo, uint64_t base, faixa_t *f, int max) {
  size_t qtd = 0;
  uint64_t *h = calloc(1024, sizeof *h);
  unsigned char *info = malloc(DL_INFO_TAM);
  int n = -1;
  if(!h || !info) goto fim;
  if(syscall(SYS_DL_GET_LIST, pid, h, (size_t)1024, &qtd) || !qtd || qtd > 1024) goto fim;
  for(size_t i = 0; i < qtd && n < 0; i++) {
    memset(info, 0, DL_INFO_TAM);
    if(syscall(SYS_DL_GET_INFO_2, pid, 1, h[i], info)) continue;
    char nome[129], lib[129], caminho[1025];
    memcpy(nome, info, 128), nome[128] = 0;
    memcpy(lib, info + 1512, 128), lib[128] = 0;
    memcpy(caminho, info + 1644, 1024), caminho[1024] = 0;
    if(strcmp(nome, modulo) && strcmp(lib, modulo) && strcmp(base_nome(caminho), modulo)) continue;
    if(le64(info + 216) != base) {
      diario("cheats: dl_get_info_2(%s): secao 0 em 0x%llx, base do SDK 0x%llx: faixas descartadas", modulo,
             (unsigned long long)le64(info + 216), (unsigned long long)base);
      break;
    }
    n = 0;
    for(int s = 0; s < 4 && n < max; s++) {
      const unsigned char *p = info + 216 + s * 24;
      uint64_t ini = le64(p), tam = le64(p + 8);
      if(!ini || !tam || tam > (1ull << 32)) continue;
      f[n].ini = ini;
      f[n].tam = tam;
      f[n].prot = (int)(le32(p + 16) & 7);
      n++;
    }
  }
fim:
  free(h);
  free(info);
  return n;
}

/* Protecao das paginas de [end, end+n) no jogo (E dos bits de cada pagina de 4 KB); -1 = nao mapeada/erro. So leitura
   (kernel_get_vmem_protection do SDK anda a arvore vm_map). */
static int prot_memoria(int pid, uint64_t end, size_t n) {
  int acc = 0xFF;
  while(n) {
    size_t k = pedaco(end, n);
    int p = kernel_get_vmem_protection(pid, (intptr_t)end, k);
    if(p < 0) return -1;
    acc &= p;
    end += k;
    n -= k;
  }
  return acc;
}
#else
/* PC: linhas do /proc/<pid>/maps com o modulo (todas as partes dele) */
static int faixas_maps(int pid, const char *modulo, faixa_t *f, int max) {
  char c[64], linha[1200];
  snprintf(c, sizeof c, "/proc/%d/maps", pid);
  FILE *a = fopen(c, "r");
  if(!a) return -1;
  int n = 0;
  while(n < max && fgets(linha, sizeof linha, a)) {
    unsigned long long ini, fim;
    char perm[8] = "", caminho[1024] = "";
    linha[strcspn(linha, "\n")] = 0;
    if(sscanf(linha, "%llx-%llx %7s %*s %*s %*s %1023s", &ini, &fim, perm, caminho) != 4 || strcmp(base_nome(caminho), modulo)) continue;
    f[n].ini = ini;
    f[n].tam = fim - ini;
    f[n].prot = (perm[0] == 'r' ? PROT_L : 0) | (perm[1] == 'w' ? PROT_E : 0) | (perm[2] == 'x' ? PROT_X : 0);
    n++;
  }
  fclose(a);
  return n ? n : -1;
}

/* PC: protecao da regiao do /proc/<pid>/maps que contem [end, end+n) inteira; -1 se nao houver */
static int prot_memoria(int pid, uint64_t end, size_t n) {
  char c[64], linha[1200];
  snprintf(c, sizeof c, "/proc/%d/maps", pid);
  FILE *a = fopen(c, "r");
  if(!a) return -1;
  int r = -1;
  while(r < 0 && fgets(linha, sizeof linha, a)) {
    unsigned long long ini, fim;
    char perm[8] = "";
    if(sscanf(linha, "%llx-%llx %7s", &ini, &fim, perm) != 3) continue;
    if(end >= ini && end + n <= fim)
      r = (perm[0] == 'r' ? PROT_L : 0) | (perm[1] == 'w' ? PROT_E : 0) | (perm[2] == 'x' ? PROT_X : 0);
  }
  fclose(a);
  return r;
}
#endif

/* Faixas do modulo no processo (cache por pid/base/modulo). origem: "dl", "elf", "maps" ou "" (nenhuma). */
static struct {
  int pid;
  uint64_t base;
  char modulo[128];
  int n;
  faixa_t f[MAX_FAIXAS];
  const char *origem;
} g_faixas[8];
static int g_faixas_prox;

static int faixas_do_modulo(int pid, const char *modulo, uint64_t base, const faixa_t **f, const char **origem) {
  for(int i = 0; i < 8; i++)
    if(g_faixas[i].pid == pid && pid > 0 && g_faixas[i].base == base && !strcmp(g_faixas[i].modulo, modulo)) {
      *f = g_faixas[i].f;
      *origem = g_faixas[i].origem;
      return g_faixas[i].n;
    }
  int k = g_faixas_prox++ % 8, n;
  const char *o = "";
#ifdef __PROSPERO__
  n = faixas_dl(pid, modulo, base, g_faixas[k].f, MAX_FAIXAS);
  if(n > 0) o = "dl";
#else
  n = faixas_maps(pid, modulo, g_faixas[k].f, MAX_FAIXAS);
  if(n > 0) o = "maps";
#endif
  if(n <= 0 && (n = faixas_elf(pid, base, g_faixas[k].f, MAX_FAIXAS)) > 0) o = "elf";
  if(n < 0) n = 0;
  g_faixas[k].pid = pid;
  g_faixas[k].base = base;
  snprintf(g_faixas[k].modulo, sizeof g_faixas[k].modulo, "%s", modulo);
  g_faixas[k].n = n;
  g_faixas[k].origem = o;
  char txt[400] = "";
  size_t p = 0;
  for(int i = 0; i < n && p < sizeof txt - 60; i++)
    p += (size_t)snprintf(txt + p, sizeof txt - p, " 0x%llx+0x%llx/%c%c%c", (unsigned long long)g_faixas[k].f[i].ini,
                          (unsigned long long)g_faixas[k].f[i].tam, g_faixas[k].f[i].prot & PROT_L ? 'r' : '-',
                          g_faixas[k].f[i].prot & PROT_E ? 'w' : '-', g_faixas[k].f[i].prot & PROT_X ? 'x' : '-');
  diario("cheats: faixas de %s (pid %d, base 0x%llx): %s%s", modulo, pid, (unsigned long long)base, n ? o : "nenhuma", txt);
  *f = g_faixas[k].f;
  *origem = o;
  return n;
}

static int dentro_das_faixas(const faixa_t *f, int nf, uint64_t end, uint64_t n, int prot) {
  for(int i = 0; i < nf; i++)
    if((f[i].prot & prot) == prot && end >= f[i].ini && end - f[i].ini <= f[i].tam && n <= f[i].tam - (end - f[i].ini)) return 1;
  return 0;
}

/* Busca de padrao (mask do Illusion): resultado em cache por pid/base/padrao (a busca pode ler dezenas de MB). */
enum { BUSCA_ACHOU = 1, BUSCA_AUSENTE, BUSCA_AMBIGUO, BUSCA_SEM_FAIXAS, BUSCA_LIMITE, BUSCA_ERRO };
static const char *const BUSCA_NOME[] = {"", "achou", "ausente", "ambiguo", "sem_faixas", "limite", "erro"};
#define BUSCA_MAX (256ull * 1024 * 1024)
#define BUSCA_BLOCO 65536

static struct {
  int pid;
  uint64_t base, chave, end;
  int estado;
} g_buscas[64];
static int g_buscas_prox;

static uint64_t fnv(uint64_t h, const void *d, size_t n) {
  const unsigned char *p = d;
  for(size_t i = 0; i < n; i++) h = (h ^ p[i]) * 0x100000001b3ull;
  return h;
}

/* Procura o padrao (mascara: 0 = qualquer byte) nas faixas; achado UMA vez = BUSCA_ACHOU e *end. */
static int varrer(int pid, const faixa_t *f, int nf, const unsigned char *pad, const unsigned char *masc, int np, uint64_t *end) {
  unsigned char *buf = malloc(BUSCA_BLOCO + (size_t)np);
  if(!buf) return BUSCA_ERRO;
  uint64_t total = 0, onde = 0;
  int achou = 0, r = 0, primeiro = -1;
  for(int k = 0; k < np && primeiro < 0; k++)
    if(masc[k]) primeiro = k;
  for(int i = 0; i < nf && !r; i++) {
    if(f[i].tam < (uint64_t)np) continue;
    for(uint64_t off = 0; off < f[i].tam && !r; off += BUSCA_BLOCO) {
      uint64_t inicios = f[i].tam - off < BUSCA_BLOCO ? f[i].tam - off : BUSCA_BLOCO;
      uint64_t precisa = f[i].tam - off < inicios + (uint64_t)np - 1 ? f[i].tam - off : inicios + (uint64_t)np - 1;
      if(total + precisa > BUSCA_MAX) { r = BUSCA_LIMITE; break; }
      if(ler_memoria(pid, f[i].ini + off, buf, (size_t)precisa)) { r = BUSCA_ERRO; break; }
      total += precisa;
      for(uint64_t p = 0; p < inicios && p + (uint64_t)np <= precisa; p++) {
        if(buf[p + (uint64_t)primeiro] != pad[primeiro]) continue;
        int igual = 1;
        for(int k = 0; k < np && igual; k++)
          if(masc[k] && buf[p + (uint64_t)k] != pad[k]) igual = 0;
        if(!igual) continue;
        uint64_t cand = f[i].ini + off + p;
        if(achou && cand != onde) { r = BUSCA_AMBIGUO; break; }
        achou = 1;
        onde = cand;
      }
    }
  }
  free(buf);
  if(r) return r;
  if(!achou) return BUSCA_AUSENTE;
  *end = onde;
  return BUSCA_ACHOU;
}

static int buscar_padrao(int pid, const char *modulo, uint64_t base, const unsigned char *pad, const unsigned char *masc, int np,
                         uint64_t *end) {
  uint64_t chave = fnv(fnv(fnv(0xcbf29ce484222325ull, modulo, strlen(modulo) + 1), pad, (size_t)np), masc, (size_t)np);
  for(int i = 0; i < 64; i++)
    if(g_buscas[i].estado && g_buscas[i].pid == pid && g_buscas[i].base == base && g_buscas[i].chave == chave) {
      *end = g_buscas[i].end;
      return g_buscas[i].estado;
    }
  const faixa_t *f;
  const char *origem;
  int nf = faixas_do_modulo(pid, modulo, base, &f, &origem), r;
  if(!nf) r = BUSCA_SEM_FAIXAS;
  else r = varrer(pid, f, nf, pad, masc, np, end);
  int k = g_buscas_prox++ % 64;
  g_buscas[k].pid = pid;
  g_buscas[k].base = base;
  g_buscas[k].chave = chave;
  g_buscas[k].estado = r;
  g_buscas[k].end = r == BUSCA_ACHOU ? *end : 0;
  char h[80];
  hex_txt_simples(h, sizeof h, pad, masc, np);
  if(r == BUSCA_ACHOU) diario("cheats: padrao %s em %s (pid %d): achado em 0x%llx", h, modulo, pid, (unsigned long long)*end);
  else diario("cheats: padrao %s em %s (pid %d): %s", h, modulo, pid, BUSCA_NOME[r]);
  return r;
}

/* ------------------------------------------------------------------ trechos e cheats (todos os formatos) */

#define MAX_TRECHOS_CHEAT 4096
#define MAX_BYTES_CHEAT (64 * 1024)   /* soma dos trechos de uma cheat que o glibren aceita gravar */
#define MAX_APLICADAS 32
#define MAX_CHEATS_ARQ 4000   /* o maior arquivo real (SCUS97328 .shn) tem 1076 */
#define MAX_DEPS 8

static int tudo_zero(const unsigned char *b, int n) {
  for(int i = 0; i < n; i++)
    if(b[i]) return 0;
  return n > 0;
}

/* Um trecho ja convertido. tipo: normal, invalido, secao (section != 0), area_extra (code cave: "off" todo zero),
   absoluto ("absolute"), sem_off (sem "off" para conferir; os enderecos diretos do .xml), padrao (mask do .xml) e
   padrao_salto (mask_jump32 do .xml). */
typedef struct {
  char offset_txt[24];
  uint64_t offset;
  int n;                    /* bytes do "on" (o "off" tem o mesmo tamanho quando existe) */
  unsigned char *on, *off;  /* malloc; off NULL sem "off" */
  const char *tipo;
  unsigned char *padrao, *mascara;   /* padrao/padrao_salto: bytes e mascara (0 = qualquer) */
  int np;
  int64_t desloc;           /* do 1o byte do padrao ate o trecho */
  unsigned char *alvo;      /* padrao_salto (mask_jump32): Target = bytes da area extra do salto (sem curinga) */
  int nalvo, tam_salto;     /* tamanho do Target e Size (bytes do salto na origem, >= 5) */
} trecho_t;

typedef struct {
  char nome[512], descricao[512], tipo[24], modulo[128];
  int inicial;              /* <StartUP> do .shn/.mc4 (codigo inicial / master code) */
  int invalido;             /* bloco que nao deu para ler inteiro (.xml) */
  int dep[MAX_DEPS], ndep;  /* cheats do mesmo arquivo para cuja area extra esta salta (-1 = mais de MAX_DEPS) */
  int nt, cap;
  trecho_t *t;
} cheat_t;

typedef struct {
  int fmt;
  char jogo[160], processo[128], versao[40];
  char creditos[10][80];
  int ncred, n, cap, tem_inicial, versao_confere;
  cheat_t *c;
  char erro[160];
  uint64_t impressao;       /* FNV dos trechos de todas as cheats (arquivos repetidos em outro formato) */
} cfile_t;

static void cfile_liberar(cfile_t *cf) {
  for(int i = 0; cf->c && i < cf->n; i++) {
    for(int k = 0; k < cf->c[i].nt; k++) {
      trecho_t *t = &cf->c[i].t[k];
      free(t->on);
      free(t->off);
      free(t->padrao);
      free(t->mascara);
      free(t->alvo);
    }
    free(cf->c[i].t);
  }
  free(cf->c);
  memset(cf, 0, sizeof *cf);
}

/* texto vindo do arquivo: controles viram espaco */
static void limpar_txt(char *s) {
  for(; *s; s++)
    if((unsigned char)*s < ' ') *s = ' ';
}

static cheat_t *cheat_novo(cfile_t *cf) {
  if(cf->n == MAX_CHEATS_ARQ) return NULL;
  if(cf->n == cf->cap) {
    int cap = cf->cap ? cf->cap * 2 : 16;
    cheat_t *c = realloc(cf->c, (size_t)cap * sizeof *c);
    if(!c) return NULL;
    cf->c = c;
    cf->cap = cap;
  }
  cheat_t *c = &cf->c[cf->n++];
  memset(c, 0, sizeof *c);
  return c;
}

static trecho_t *trecho_novo(cheat_t *c) {
  if(c->nt == MAX_TRECHOS_CHEAT) return NULL;
  if(c->nt == c->cap) {
    int cap = c->cap ? c->cap * 2 : 4;
    trecho_t *t = realloc(c->t, (size_t)cap * sizeof *t);
    if(!t) return NULL;
    c->t = t;
    c->cap = cap;
  }
  trecho_t *t = &c->t[c->nt++];
  memset(t, 0, sizeof *t);
  t->tipo = "invalido";
  return t;
}

static void credito(cfile_t *cf, const char *s) {
  char x[80];
  if(copiar_aparado(s, x, sizeof x) || !x[0] || cf->ncred == 10) return;
  limpar_txt(x);
  for(int i = 0; i < cf->ncred; i++)
    if(!strcmp(cf->creditos[i], x)) return;
  snprintf(cf->creditos[cf->ncred++], sizeof cf->creditos[0], "%s", x);
}

/* Hex de um texto para malloc (n = bytes). NULL se vazio/invalido (*n = -1 se invalido, 0 se vazio). */
static unsigned char *hex_campo_txt(const char *s, int *n) {
  size_t cap = strlen(s) / 2 + 1;
  *n = 0;
  if(cap > MAX_TRECHO + 1) { *n = -1; return NULL; }
  unsigned char *d = malloc(cap);
  if(!d) { *n = -1; return NULL; }
  *n = hex_bytes(s, d, cap);
  if(*n <= 0) { free(d); return NULL; }
  return d;
}

/* Trecho com endereco + on/off (.json, .shn, .mc4): mesma classificacao para os tres formatos. */
static void trecho_classificar(trecho_t *t, const char *offset, const char *on, const char *off, int secao, int absoluto) {
  int non, noff;
  copiar_aparado(offset, t->offset_txt, sizeof t->offset_txt);
  t->on = hex_campo_txt(on, &non);
  t->off = hex_campo_txt(off, &noff);
  t->n = non > 0 ? non : 0;
  if(t->off && noff != t->n) {   /* "off" de outro tamanho: o trecho e invalido e o "off" nao e usado (nem lido) */
    free(t->off);
    t->off = NULL;
  }
  if(hex_offset(t->offset_txt, &t->offset) || non <= 0 || noff < 0 || (noff && noff != non)) t->tipo = "invalido";
  else if(secao) t->tipo = "secao";
  else if(noff && tudo_zero(t->off, noff)) t->tipo = "area_extra";
  else if(absoluto) t->tipo = "absoluto";
  else if(!noff) t->tipo = "sem_off";
  else t->tipo = "normal";
}

/* .json -> cfile */
static int cf_json(const char *dados, size_t n, cfile_t *cf) {
  const char *erro = "";
  jv_t *r = jv_ler(dados, n, &erro);
  if(!r || r->tipo != JV_OBJETO) {
    snprintf(cf->erro, sizeof cf->erro, "%s", r ? "o arquivo nao e um objeto JSON" : erro);
    jv_liberar(r);
    return -1;
  }
  const char *processo = jv_txt(r, "process");
  snprintf(cf->processo, sizeof cf->processo, "%s", *processo ? processo : "eboot.bin");
  snprintf(cf->jogo, sizeof cf->jogo, "%s", jv_txt(r, "name"));
  snprintf(cf->versao, sizeof cf->versao, "%s", jv_txt(r, "version"));
  const jv_t *cr = jv_campo(r, "credits");
  if(!cr) cr = jv_campo(r, "authors");
  for(const jv_t *x = cr && cr->tipo == JV_LISTA ? cr->filho : NULL; x; x = x->prox)
    if(x->tipo == JV_TEXTO) credito(cf, x->texto);
  const jv_t *mods = jv_campo(r, "mods");
  for(const jv_t *mo = mods && mods->tipo == JV_LISTA ? mods->filho : NULL; mo; mo = mo->prox) {
    if(mo->tipo != JV_OBJETO) continue;
    cheat_t *c = cheat_novo(cf);
    if(!c) break;
    copiar_cortado(jv_txt(mo, "name"), c->nome, sizeof c->nome);
    copiar_cortado(jv_txt(mo, "description"), c->descricao, sizeof c->descricao);
    snprintf(c->tipo, sizeof c->tipo, "%s", jv_txt(mo, "type"));
    snprintf(c->modulo, sizeof c->modulo, "%s", base_nome(cf->processo));
    const jv_t *mem = jv_campo(mo, "memory");
    for(const jv_t *m = mem && mem->tipo == JV_LISTA ? mem->filho : NULL; m; m = m->prox) {
      if(m->tipo != JV_OBJETO) continue;
      trecho_t *t = trecho_novo(c);
      if(!t) { c->invalido = 1; break; }
      const jv_t *abs = jv_campo(m, "absolute"), *sec = jv_campo(m, "section");
      int secao = sec && sec->tipo == JV_NUMERO ? atoi(sec->texto) : 0;
      trecho_classificar(t, jv_txt(m, "offset"), jv_txt(m, "on"), jv_txt(m, "off"), secao, abs && abs->tipo == JV_LOGICO && abs->logico);
    }
  }
  jv_liberar(r);
  return 0;
}

/* texto do 1o filho com o nome ("" se nao tiver) */
static const char *xn_txt(const xn_t *n, const char *nome) {
  const xn_t *f = xn_filho(n, nome, NULL);
  return f ? f->texto : "";
}

/* .shn (e .mc4 decodificado) -> cfile. <Trainer> com <Cheat>/<StartUP> e <Cheatline>. */
static int cf_trainer(const char *dados, size_t n, cfile_t *cf) {
  const char *erro = "";
  xn_t *r = xml_ler(dados, n, &erro);
  if(!r || strcasecmp(r->nome, "Trainer")) {
    snprintf(cf->erro, sizeof cf->erro, "%s", r ? "o arquivo nao e um <Trainer>" : erro);
    xn_liberar(r);
    return -1;
  }
  const char *a;
  if((a = xn_attr(r, "Process")) && *a) copiar_aparado(a, cf->processo, sizeof cf->processo);
  if(!cf->processo[0]) snprintf(cf->processo, sizeof cf->processo, "eboot.bin");
  if((a = xn_attr(r, "Game"))) copiar_cortado(a, cf->jogo, sizeof cf->jogo);
  if((a = xn_attr(r, "Version"))) copiar_aparado(a, cf->versao, sizeof cf->versao);
  if((a = xn_attr(r, "Moder"))) credito(cf, a);
  for(const xn_t *x = r->filho; x; x = x->prox) {
    int inicial = !strcasecmp(x->nome, "StartUP");
    if(!inicial && strcasecmp(x->nome, "Cheat")) continue;
    cheat_t *c = cheat_novo(cf);
    if(!c) break;
    c->inicial = inicial;
    cf->tem_inicial |= inicial;
    if((a = xn_attr(x, "Text"))) copiar_cortado(a, c->nome, sizeof c->nome);
    if((a = xn_attr(x, "Description"))) copiar_cortado(a, c->descricao, sizeof c->descricao);
    snprintf(c->tipo, sizeof c->tipo, "checkbox");
    snprintf(c->modulo, sizeof c->modulo, "%s", base_nome(cf->processo));
    for(const xn_t *l = xn_filho(x, "Cheatline", NULL); l; l = xn_filho(x, "Cheatline", l)) {
      trecho_t *t = trecho_novo(c);
      if(!t) { c->invalido = 1; break; }
      char sec[32] = "", ab[16] = "";
      int sec_ok = !copiar_aparado(xn_txt(l, "Section"), sec, sizeof sec);
      copiar_aparado(xn_txt(l, "Absolute"), ab, sizeof ab);
      int secao = 0;
      if(sec[0] && (strspn(sec, "0123456789") != strlen(sec) || !sec_ok)) secao = -1;
      else if(sec[0]) secao = atoi(sec);
      trecho_classificar(t, xn_txt(l, "Offset"), xn_txt(l, "ValueOn"), xn_txt(l, "ValueOff"), secao,
                         !strcasecmp(ab, "true") || !strcmp(ab, "1"));
      if(secao < 0) t->tipo = "invalido";
    }
  }
  xn_liberar(r);
  return 0;
}

/* ---- .xml (Illusion): numeros e valores */

/* digitos numa base (sem sinal); -1 se vazio, invalido ou estourar */
static int digitos(const char *s, int base, uint64_t *v) {
  *v = 0;
  if(!*s) return -1;
  for(; *s; s++) {
    int d = digito_hex(*s);
    if(d < 0 || d >= base || *v > (UINT64_MAX - (uint64_t)d) / (uint64_t)base) return -1;
    *v = *v * (uint64_t)base + (uint64_t)d;
  }
  return 0;
}

/* Endereco: 0x.. (hex), 0.. (octal) ou decimal. */
static int numero_endereco(const char *s, uint64_t *v) {
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) return digitos(s + 2, 16, v);
  if(s[0] == '0' && s[1]) return digitos(s + 1, 8, v);
  return digitos(s, 10, v);
}

/* Deslocamento com sinal ("+9", "-0x10", "" = 0). */
static int desloc_com_sinal(const char *s, int64_t *v) {
  uint64_t m;
  int neg = 0;
  *v = 0;
  if(!*s) return 0;
  if(*s == '+' || *s == '-') neg = *s++ == '-';
  int r;
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) r = digitos(s + 2, 16, &m);
  else if(*s == '#' || *s == '$') r = digitos(s + 1, 16, &m);
  else if(s[0] == '0' && s[1]) r = digitos(s + 1, 8, &m);
  else r = digitos(s, 10, &m);
  if(r || m > (uint64_t)INT64_MAX) return -1;
  *v = neg ? -(int64_t)m : (int64_t)m;
  return 0;
}

/* bytes em hex com prefixo opcional 0x/#/$ e separadores (espaco, - e _) */
static int valor_hex(const char *s, unsigned char *o, int max) {
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) s += 2;
  else if(*s == '#' || *s == '$') s++;
  int n = hex_bytes(s, o, (size_t)max);
  return n > 0 ? n : -1;
}

/* inteiro de "largura" bytes, little-endian (decimal ou 0x/#/$ hex; "-" = complemento de 2) */
static int valor_inteiro(const char *s, int largura, unsigned char *o) {
  uint64_t v;
  int neg = *s == '-';
  if(neg) s++;
  int r = s[0] == '0' && (s[1] == 'x' || s[1] == 'X') ? digitos(s + 2, 16, &v) : (*s == '#' || *s == '$') ? digitos(s + 1, 16, &v) : digitos(s, 10, &v);
  if(r) return -1;
  if(neg) {
    if(v > (1ull << (largura * 8 - 1))) return -1;
    v = 0 - v;
  } else if(largura < 8 && v >> (largura * 8)) return -1;
  for(int i = 0; i < largura; i++) o[i] = (unsigned char)(v >> (i * 8));
  return largura;
}

static int valor_float(const char *s, int dupla, unsigned char *o) {
  char *fim = NULL;
  errno = 0;
  double d = strtod(s, &fim);
  if(!*s || errno == ERANGE || !fim || *fim || d - d != 0.0) return -1;   /* d - d != 0: infinito ou NaN */
  if(dupla) {
    uint64_t b;
    memcpy(&b, &d, 8);
    for(int i = 0; i < 8; i++) o[i] = (unsigned char)(b >> (i * 8));
    return 8;
  }
  float f = (float)d;
  if(f - f != 0.0f) return -1;
  uint32_t b;
  memcpy(&b, &f, 4);
  for(int i = 0; i < 4; i++) o[i] = (unsigned char)(b >> (i * 8));
  return 4;
}

/* texto com escapes \n \t \r \0 \\ \xHH -> bytes (UTF-8 como esta) */
static int valor_utf8(const char *s, unsigned char *o, int max) {
  int n = 0;
  for(; *s; s++) {
    unsigned char c = (unsigned char)*s;
    if(c == '\\' && s[1]) {
      s++;
      if(*s == 'n') c = '\n';
      else if(*s == 't') c = '\t';
      else if(*s == 'r') c = '\r';
      else if(*s == '0') c = 0;
      else if(*s == '\\') c = '\\';
      else if(*s == 'x' && digito_hex(s[1]) >= 0 && digito_hex(s[2]) >= 0) { c = (unsigned char)(digito_hex(s[1]) << 4 | digito_hex(s[2])); s += 2; }
      else return -1;
    }
    if(n == max) return -1;
    o[n++] = c;
  }
  return n ? n : -1;
}

/* proximo codigo UTF-8 (com os escapes do valor_utf8); -1 se invalido */
static long utf8_prox(const unsigned char **p, const unsigned char *fim) {
  const unsigned char *s = *p;
  unsigned c = *s++;
  long cp;
  int extra;
  if(c < 0x80) { cp = c; extra = 0; }
  else if((c & 0xE0) == 0xC0) { cp = c & 0x1F; extra = 1; }
  else if((c & 0xF0) == 0xE0) { cp = c & 0x0F; extra = 2; }
  else if((c & 0xF8) == 0xF0) { cp = c & 0x07; extra = 3; }
  else return -1;
  for(int i = 0; i < extra; i++) {
    if(s >= fim || (*s & 0xC0) != 0x80) return -1;
    cp = cp << 6 | (*s++ & 0x3F);
  }
  *p = s;
  return cp > 0x10FFFF || (cp >= 0xD800 && cp <= 0xDFFF) ? -1 : cp;
}

static int valor_utf16(const char *s, unsigned char *o, int max) {
  unsigned char tmp[MAX_TRECHO];
  int nb = valor_utf8(s, tmp, (int)sizeof tmp), n = 0;
  if(nb < 0) return -1;
  for(const unsigned char *p = tmp; p < tmp + nb;) {
    long cp = utf8_prox(&p, tmp + nb);
    if(cp < 0) return -1;
    unsigned u[2];
    int k = 1;
    if(cp > 0xFFFF) { cp -= 0x10000; u[0] = 0xD800 | (unsigned)(cp >> 10); u[1] = 0xDC00 | (unsigned)(cp & 0x3FF); k = 2; }
    else u[0] = (unsigned)cp;
    for(int i = 0; i < k; i++) {
      if(n + 2 > max) return -1;
      o[n++] = (unsigned char)u[i];
      o[n++] = (unsigned char)(u[i] >> 8);
    }
  }
  return n ? n : -1;
}

static int valor_codificar(const char *tipo, const char *s, unsigned char *o, int max) {
  if(!strcmp(tipo, "bytes")) return valor_hex(s, o, max);
  if(!strcmp(tipo, "byte")) return valor_inteiro(s, 1, o);
  if(!strcmp(tipo, "bytes16")) return valor_inteiro(s, 2, o);
  if(!strcmp(tipo, "bytes32")) return valor_inteiro(s, 4, o);
  if(!strcmp(tipo, "bytes64")) return valor_inteiro(s, 8, o);
  if(!strcmp(tipo, "float32")) return valor_float(s, 0, o);
  if(!strcmp(tipo, "float64")) return valor_float(s, 1, o);
  if(!strcmp(tipo, "utf8")) return valor_utf8(s, o, max);
  if(!strcmp(tipo, "utf16")) return valor_utf16(s, o, max);
  return -1;
}

/* padrao "0f 4f ?? c3" (espacos opcionais; "?" ou "??" = qualquer byte). Pelo menos um byte fixo. */
static int padrao_decodificar(const char *s, unsigned char *pad, unsigned char *masc, int max) {
  int n = 0, fixos = 0;
  while(*s) {
    if(*s == ' ' || *s == '\t' || *s == '\n' || *s == '\r') { s++; continue; }
    if(n == max) return -1;
    if(*s == '?') {
      s += s[1] == '?' ? 2 : 1;
      pad[n] = 0;
      masc[n++] = 0;
      continue;
    }
    int a = digito_hex(s[0]), b = s[0] ? digito_hex(s[1]) : -1;
    if(a < 0 || b < 0) return -1;
    pad[n] = (unsigned char)(a << 4 | b);
    masc[n++] = 0xFF;
    fixos++;
    s += 2;
  }
  return n && fixos ? n : -1;
}

/* AppVer: lista separada por virgulas; "mask" vale para qualquer versao */
static int versao_bate(const char *lista, const char *versao) {
  char v[64];
  while(*lista) {
    const char *virg = strchr(lista, ',');
    size_t k = virg ? (size_t)(virg - lista) : strlen(lista);
    if(k < sizeof v) {
      memcpy(v, lista, k);
      v[k] = 0;
      if(!copiar_aparado(v, v, sizeof v) && (!strcmp(v, versao) || !strcasecmp(v, "mask"))) return 1;
    }
    if(!virg) break;
    lista = virg + 1;
  }
  return 0;
}

/* Uma <Line> do Illusion num trecho. 0 = ok; -1 = linha invalida (o trecho fica "invalido"). */
static int linha_illusion(const xn_t *l, uint64_t base_img, trecho_t *t) {
  static const char *const CAMPOS[] = {"Type", "Address", "Value", "Offset", "Target", "Size"};
  char tipo[24], end[600], valor[MAX_TRECHO * 3], desl[40], alvo[600], tam[16];
  char *v[] = {tipo, end, valor, desl, alvo, tam};
  size_t tv[] = {sizeof tipo, sizeof end, sizeof valor, sizeof desl, sizeof alvo, sizeof tam};
  int tem[6];
  for(int i = 0; i < 6; i++)
    if((tem[i] = xn_valor(l, CAMPOS[i], v[i], tv[i])) < 0) return -1;
  for(const xa_t *a = l->attr; a; a = a->prox) {   /* campo desconhecido = linha que o glibren nao entende */
    int conhecido = 0;
    for(int i = 0; i < 6; i++) conhecido |= !strcasecmp(a->nome, CAMPOS[i]);
    if(!conhecido) return -1;
  }
  unsigned char *on = malloc(MAX_TRECHO);
  if(!on) return -1;
  int n;
  if(!strcmp(tipo, "mask") || !strcmp(tipo, "mask_jump32")) {
    int salto = tipo[4] == '_';
    if((!salto && (tem[4] || tem[5])) || !end[0] || !valor[0]) { free(on); return -1; }
    t->padrao = malloc(256);
    t->mascara = malloc(256);
    if(!t->padrao || !t->mascara || (t->np = padrao_decodificar(end, t->padrao, t->mascara, 256)) < 0 || desloc_com_sinal(desl, &t->desloc) ||
       (n = valor_hex(valor, on, MAX_TRECHO)) < 0) { free(on); return -1; }
    if(salto) {
      uint64_t sz = 5;
      if(!(t->alvo = malloc(256)) || (t->nalvo = valor_hex(alvo, t->alvo, 256)) <= 0 || (tam[0] && (digitos(tam, 10, &sz) || sz < 5 || sz > 255))) {
        free(on);
        return -1;
      }
      t->tam_salto = (int)sz;
    }
    hex_txt_simples(t->offset_txt, sizeof t->offset_txt, t->padrao, t->mascara, t->np > 8 ? 8 : t->np);
    t->tipo = salto ? "padrao_salto" : "padrao";
  } else {
    uint64_t a;
    if(tem[3] || tem[4] || tem[5] || !end[0] || !valor[0] || numero_endereco(end, &a) || a < base_img ||
       (n = valor_codificar(tipo, valor, on, MAX_TRECHO)) < 0) { free(on); return -1; }
    t->offset = a - base_img;
    snprintf(t->offset_txt, sizeof t->offset_txt, "%llX", (unsigned long long)t->offset);
    t->tipo = "sem_off";
  }
  t->n = n;
  t->on = on;
  return 0;
}

/* .xml (Illusion PS4-PS5-Game-Patch) -> cfile: so os <Metadata> desta versao (AppVer) e deste jogo (TitleID). */
static int cf_illusion(const char *dados, size_t n, const char *tid, const char *versao, cfile_t *cf) {
  const char *erro = "";
  xn_t *r = xml_ler(dados, n, &erro);
  const xn_t *ids = r ? xn_filho(r, "TitleID", NULL) : NULL;
  if(!r || strcasecmp(r->nome, "Patch") || !ids || xn_filho(r, "TitleID", ids)) {
    snprintf(cf->erro, sizeof cf->erro, "%s", !r ? erro : strcasecmp(r->nome, "Patch") ? "o arquivo nao e um <Patch> (Illusion)" : "TitleID ausente ou repetido");
    xn_liberar(r);
    return -1;
  }
  int do_jogo = 0;
  char x[64];
  for(const xn_t *id = xn_filho(ids, "ID", NULL); id && !do_jogo; id = xn_filho(ids, "ID", id))
    do_jogo = !copiar_aparado(id->texto, x, sizeof x) && !strcasecmp(x, tid);
  if(!do_jogo) {
    snprintf(cf->erro, sizeof cf->erro, "o arquivo e de outro jogo (TitleID)");
    xn_liberar(r);
    return -1;
  }
  snprintf(cf->jogo, sizeof cf->jogo, "Illusion PS-Game-Patch");
  for(const xn_t *m = xn_filho(r, "Metadata", NULL); m; m = xn_filho(r, "Metadata", m)) {
    char appver[256], base_txt[40], nome[512], elf[128], nota[2048], autor[80];
    if(xn_valor(m, "AppVer", appver, sizeof appver) <= 0 || !versao_bate(appver, versao)) continue;
    cheat_t *c = cheat_novo(cf);
    if(!c) break;
    uint64_t base_img = 0x400000;
    int ok = xn_valor(m, "ImageBase", base_txt, sizeof base_txt) >= 0 && (!base_txt[0] || !numero_endereco(base_txt, &base_img));
    ok &= xn_valor(m, "Name", nome, sizeof nome) > 0;
    ok &= xn_valor(m, "AppElf", elf, sizeof elf) >= 0;
    ok &= xn_valor(m, "Note", nota, sizeof nota) >= 0;
    if(xn_valor(m, "Author", autor, sizeof autor) > 0) credito(cf, autor);
    copiar_cortado(nome[0] ? nome : "?", c->nome, sizeof c->nome);
    copiar_cortado(nota, c->descricao, sizeof c->descricao);
    snprintf(c->tipo, sizeof c->tipo, "checkbox");
    snprintf(c->modulo, sizeof c->modulo, "%s", elf[0] ? base_nome(elf) : "eboot.bin");
    if(!cf->processo[0]) snprintf(cf->processo, sizeof cf->processo, "%s", c->modulo);
    const xn_t *pl = xn_filho(m, "PatchList", NULL);
    if(!ok || !pl || xn_filho(m, "PatchList", pl)) { c->invalido = 1; continue; }
    for(const xn_t *l = pl->filho; l; l = l->prox) {
      trecho_t *t = trecho_novo(c);
      if(!t) { c->invalido = 1; break; }
      if(strcasecmp(l->nome, "Line") || linha_illusion(l, base_img, t)) t->tipo = "invalido";
    }
  }
  if(!cf->processo[0]) snprintf(cf->processo, sizeof cf->processo, "eboot.bin");
  snprintf(cf->versao, sizeof cf->versao, "%s", cf->n ? versao : "");
  xn_liberar(r);
  return 0;
}

/* ---- dependencias e impressao digital (calculadas uma vez por arquivo) */

typedef struct {
  uint64_t ini;
  int n, cheat;
} cave_t;

static int cmp_cave(const void *a, const void *b) {
  const cave_t *x = a, *y = b;
  return x->ini < y->ini ? -1 : x->ini > y->ini;
}

/* Saltos rel32 (E8 call, E9 jmp, 0F 80..8F jcc) nos bytes "on" que caem na area extra de OUTRA cheat do arquivo. */
static void calcular_dependencias(cfile_t *cf) {
  int nc = 0;
  for(int i = 0; i < cf->n; i++)
    for(int k = 0; k < cf->c[i].nt; k++) nc += !strcmp(cf->c[i].t[k].tipo, "area_extra");
  if(!nc) return;
  cave_t *cv = malloc((size_t)nc * sizeof *cv);
  if(!cv) return;
  nc = 0;
  for(int i = 0; i < cf->n; i++)
    for(int k = 0; k < cf->c[i].nt; k++)
      if(!strcmp(cf->c[i].t[k].tipo, "area_extra")) cv[nc++] = (cave_t){cf->c[i].t[k].offset, cf->c[i].t[k].n, i};
  qsort(cv, (size_t)nc, sizeof *cv, cmp_cave);
  for(int i = 0; i < cf->n; i++) {
    cheat_t *c = &cf->c[i];
    for(int k = 0; k < c->nt && c->ndep >= 0; k++) {
      const trecho_t *t = &c->t[k];
      if(strcmp(t->tipo, "normal") && strcmp(t->tipo, "area_extra")) continue;
      for(int p = 0; p < t->n && c->ndep >= 0; p++) {
        int len;
        int32_t rel;
        if((t->on[p] == 0xE8 || t->on[p] == 0xE9) && p + 5 <= t->n) { len = 5; rel = (int32_t)le32(t->on + p + 1); }
        else if(t->on[p] == 0x0F && p + 6 <= t->n && (t->on[p + 1] & 0xF0) == 0x80) { len = 6; rel = (int32_t)le32(t->on + p + 2); }
        else continue;
        uint64_t alvo = t->offset + (uint64_t)p + (uint64_t)len + (uint64_t)(int64_t)rel;
        int lo = 0, hi = nc - 1, achou = -1;   /* ultima cave com ini <= alvo */
        while(lo <= hi) {
          int m = (lo + hi) / 2;
          if(cv[m].ini <= alvo) { achou = m; lo = m + 1; }
          else hi = m - 1;
        }
        for(int m = achou; m >= 0 && m > achou - 4; m--) {   /* caves vizinhas podem se sobrepor */
          if(alvo >= cv[m].ini + (uint64_t)cv[m].n || cv[m].cheat == i) continue;
          int ja = 0;
          for(int d = 0; d < c->ndep; d++) ja |= c->dep[d] == cv[m].cheat;
          if(ja) continue;
          if(c->ndep == MAX_DEPS) { c->ndep = -1; break; }
          c->dep[c->ndep++] = cv[m].cheat;
        }
      }
    }
  }
  free(cv);
}

static void calcular_impressao(cfile_t *cf) {
  uint64_t h = fnv(0xcbf29ce484222325ull, &cf->n, sizeof cf->n);
  for(int i = 0; i < cf->n; i++) {
    const cheat_t *c = &cf->c[i];
    h = fnv(h, &c->nt, sizeof c->nt);
    h = fnv(h, &c->inicial, sizeof c->inicial);
    for(int k = 0; k < c->nt; k++) {
      const trecho_t *t = &c->t[k];
      h = fnv(h, t->tipo, strlen(t->tipo) + 1);
      h = fnv(h, &t->offset, sizeof t->offset);
      h = fnv(h, &t->n, sizeof t->n);
      if(t->on) h = fnv(h, t->on, (size_t)t->n);
      if(t->off) h = fnv(h, t->off, (size_t)t->n);
      if(t->padrao) h = fnv(fnv(fnv(h, t->padrao, (size_t)t->np), t->mascara, (size_t)t->np), &t->desloc, sizeof t->desloc);
    }
  }
  cf->impressao = h;
}

/* ---- leitura com cache (so com g_trava_mem): o arquivo so e lido de novo se mudar (tamanho/data) */

static struct {
  char caminho[700], tid[16], versao[32];
  long long mtime, tam;
  unsigned uso;
  int ocupado;
  cfile_t cf;
} g_cf[MAX_ARQUIVOS];
static unsigned g_cf_uso;

static void cfile_ler(const char *caminho, int fmt, const char *tid, const char *versao, cfile_t *cf) {
  buf_t dados = {0};
  memset(cf, 0, sizeof *cf);
  cf->fmt = fmt;
  if(ler_arquivo(caminho, &dados, MAX_JSON)) {
    snprintf(cf->erro, sizeof cf->erro, "arquivo grande demais ou ilegivel");
    buf_free(&dados);
    return;
  }
  int r = -1;
  if(fmt == FMT_JSON) r = cf_json(dados.d, dados.n, cf);
  else if(fmt == FMT_SHN) r = cf_trainer(dados.d, dados.n, cf);
  else if(fmt == FMT_MC4) {
    buf_t xml = {0};
    const char *erro = "";
    if(mc4_decodificar(dados.d, dados.n, &xml, &erro)) snprintf(cf->erro, sizeof cf->erro, "%s", erro);
    else r = cf_trainer(xml.d, xml.n, cf);
    if(xml.d) memset(xml.d, 0, xml.n);
    buf_free(&xml);
  } else r = cf_illusion(dados.d, dados.n, tid, versao, cf);
  buf_free(&dados);
  if(r) return;
  limpar_txt(cf->jogo);
  for(int i = 0; i < cf->n; i++) {
    limpar_txt(cf->c[i].nome);
    limpar_txt(cf->c[i].descricao);
  }
  cf->versao_confere = !strcmp(cf->versao, versao);
  calcular_dependencias(cf);
  calcular_impressao(cf);
}

static const cfile_t *ler_cfile(const arquivo_t *a, const jogo_t *j) {
  struct stat st;
  long long mt = 0, tam = -1;
  if(!stat(a->caminho, &st)) { mt = (long long)st.st_mtime; tam = (long long)st.st_size; }
  int livre = 0;
  for(int i = 0; i < MAX_ARQUIVOS; i++) {
    if(g_cf[i].ocupado && !strcmp(g_cf[i].caminho, a->caminho) && g_cf[i].mtime == mt && g_cf[i].tam == tam &&
       !strcmp(g_cf[i].tid, j->tid) && !strcmp(g_cf[i].versao, j->versao)) {
      g_cf[i].uso = ++g_cf_uso;
      return &g_cf[i].cf;
    }
    if(!g_cf[i].ocupado || g_cf[i].uso < g_cf[livre].uso) livre = i;
    if(!g_cf[i].ocupado) break;
  }
  if(g_cf[livre].ocupado) cfile_liberar(&g_cf[livre].cf);
  snprintf(g_cf[livre].caminho, sizeof g_cf[livre].caminho, "%s", a->caminho);
  snprintf(g_cf[livre].tid, sizeof g_cf[livre].tid, "%s", j->tid);
  snprintf(g_cf[livre].versao, sizeof g_cf[livre].versao, "%s", j->versao);
  g_cf[livre].mtime = mt;
  g_cf[livre].tam = tam;
  g_cf[livre].ocupado = 1;
  g_cf[livre].uso = ++g_cf_uso;
  cfile_ler(a->caminho, a->fmt, j->tid, j->versao, &g_cf[livre].cf);
  return &g_cf[livre].cf;
}

/* .json (aplicadas.json): hex de um campo */
static unsigned char *hex_campo(const jv_t *m, const char *nome, int *n) { return hex_campo_txt(jv_txt(m, nome), n); }

/* ------------------------------------------------------------------ cheats ligadas pelo glibren */

/* Cada cheat ligada guarda os bytes originais (lidos antes de gravar, iguais ao "off") para restaurar. Tudo fica
   em memoria e em <catalogo>/aplicadas.json (gravado ANTES de mexer no jogo), com pid, app id, Title ID, versao e
   enderecos: se o glibren cair e voltar com o mesmo jogo aberto, ele retoma a lista. Se o pid ou o app id do jogo
   mudarem, as cheats viram "perdidas" (o jogo fechou e a memoria dele sumiu) e nada e gravado. */
typedef struct {
  uint64_t endereco;
  int n;
  unsigned char *original, *on, *off;
} trecho_ap_t;

typedef struct {
  char arquivo[256];
  int indice;
  char nome[160];
  int inicial;              /* codigo inicial (<StartUP>) do .shn/.mc4 */
  int xml;                  /* 0.9.26: .xml (Illusion): "off" = original lido ao ligar ("fonte":"xml") */
  int dep[MAX_DEPS], ndep;  /* cheats do mesmo arquivo de que esta depende (tem de desligar esta antes delas) */
  int n;
  trecho_ap_t *t;
} aplicada_t;

static pthread_mutex_t g_trava_mem = PTHREAD_MUTEX_INITIALIZER;   /* leitura, escrita (uma por vez) e g_ap */
static struct {
  int carregou;
  int pid, app_id;
  char tid[16], versao[32];
  int n;
  aplicada_t a[MAX_APLICADAS];
  char perdidas[600];
  time_t perdidas_quando;
} g_ap;

static void aplicada_liberar(aplicada_t *a) {
  for(int i = 0; a->t && i < a->n; i++) {
    free(a->t[i].original);
    free(a->t[i].on);
    free(a->t[i].off);
  }
  free(a->t);
  memset(a, 0, sizeof *a);
}

static void aplicada_tirar(int k) {
  aplicada_liberar(&g_ap.a[k]);
  memmove(&g_ap.a[k], &g_ap.a[k + 1], (size_t)(g_ap.n - k - 1) * sizeof g_ap.a[0]);
  g_ap.n--;
  memset(&g_ap.a[g_ap.n], 0, sizeof g_ap.a[0]);
}

static int aplicada_achar(const char *arquivo, int indice) {
  for(int k = 0; k < g_ap.n; k++)
    if(g_ap.a[k].indice == indice && !strcmp(g_ap.a[k].arquivo, arquivo)) return k;
  return -1;
}

static void caminho_aplicadas(char *s, size_t tam) {
  char p[512];
  pasta_catalogo(p, sizeof p);
  snprintf(s, tam, "%s/aplicadas.json", p);
}

void cheats_caminho_aplicadas(char *s, size_t tam) {
  caminho_aplicadas(s, tam);
}

static void hex_todo(buf_t *b, const unsigned char *d, int n) {
  static const char H[] = "0123456789ABCDEF";
  buf_str(b, "\"");
  for(int i = 0; i < n; i++) {
    char x[2] = {H[d[i] >> 4], H[d[i] & 15]};
    buf_add(b, x, 2);
  }
  buf_str(b, "\"");
}

/* Hex para o diario/mensagens (ate 32 bytes; mais que isso termina em ".."). */
static void hex_txt(char *s, size_t tam, const unsigned char *d, int n) {
  size_t p = 0;
  s[0] = 0;
  for(int i = 0; i < n && i < 32 && p + 3 < tam; i++) p += (size_t)snprintf(s + p, tam - p, "%02X", d[i]);
  if(n > 32 && p + 3 < tam) snprintf(s + p, tam - p, "..");
}

/* Grava g_ap em aplicadas.json (arquivo novo + rename). 0 = gravou. */
static int ap_gravar(void) {
  char c[600], tmp[640], pasta[512];
  pasta_catalogo(pasta, sizeof pasta);
  if(mkdir_p(pasta)) return -1;
  caminho_aplicadas(c, sizeof c);
  buf_t b = {0};
  buf_fmt(&b, "{\"formato\":1,\"gravado\":%lld,\"pid\":%d,\"app_id\":%d,\"tid\":", (long long)time(NULL), g_ap.n ? g_ap.pid : -1,
          g_ap.n ? g_ap.app_id : -1);
  buf_json(&b, g_ap.n ? g_ap.tid : "");
  buf_str(&b, ",\"versao\":");
  buf_json(&b, g_ap.n ? g_ap.versao : "");
  buf_str(&b, ",\"cheats\":[");
  for(int k = 0; k < g_ap.n; k++) {
    const aplicada_t *a = &g_ap.a[k];
    buf_str(&b, k ? ",\n{\"arquivo\":" : "\n{\"arquivo\":");
    buf_json(&b, a->arquivo);
    buf_fmt(&b, ",\"indice\":%d,\"nome\":", a->indice);
    buf_json(&b, a->nome);
    buf_fmt(&b, ",\"inicial\":%s,%s\"depende\":[", a->inicial ? "true" : "false", a->xml ? "\"fonte\":\"xml\"," : "");
    for(int d = 0; d < a->ndep; d++) buf_fmt(&b, "%s%d", d ? "," : "", a->dep[d]);
    buf_str(&b, "],\"trechos\":[");
    for(int i = 0; i < a->n; i++) {
      buf_fmt(&b, "%s{\"endereco\":\"0x%llx\",\"original\":", i ? "," : "", (unsigned long long)a->t[i].endereco);
      hex_todo(&b, a->t[i].original, a->t[i].n);
      buf_str(&b, ",\"on\":");
      hex_todo(&b, a->t[i].on, a->t[i].n);
      buf_str(&b, ",\"off\":");
      hex_todo(&b, a->t[i].off, a->t[i].n);
      buf_str(&b, "}");
    }
    buf_str(&b, "]}");
  }
  buf_str(&b, "]}\n");
  snprintf(tmp, sizeof tmp, "%s.tmp", c);
  unlink(tmp);
  int fd = open(tmp, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0644);
  int ok = fd >= 0 && write(fd, b.d, b.n) == (ssize_t)b.n;
  if(fd >= 0 && fsync(fd)) ok = 0;
  if(fd >= 0 && close(fd)) ok = 0;
  buf_free(&b);
  if(!ok || rename(tmp, c)) {
    unlink(tmp);
    diario("cheats: nao gravou %s (errno %d)", c, errno);
    return -1;
  }
  return 0;
}

/* Le aplicadas.json uma vez (o glibren pode ter caido com cheats ligadas). Quem decide se valem e ap_conferir. */
static void ap_carregar(void) {
  if(g_ap.carregou) return;
  g_ap.carregou = 1;
  char c[600];
  caminho_aplicadas(c, sizeof c);
  buf_t b = {0};
  if(ler_arquivo(c, &b, MAX_JSON)) { buf_free(&b); return; }
  jv_t *r = jv_ler(b.d, b.n, NULL);
  buf_free(&b);
  const jv_t *ch = jv_campo(r, "cheats");
  if(!r || !ch || ch->tipo != JV_LISTA || !ch->filho) { jv_liberar(r); return; }
  g_ap.pid = atoi(jv_txt(r, "pid"));
  g_ap.app_id = atoi(jv_txt(r, "app_id"));
  snprintf(g_ap.tid, sizeof g_ap.tid, "%s", jv_txt(r, "tid"));
  snprintf(g_ap.versao, sizeof g_ap.versao, "%s", jv_txt(r, "versao"));
  int ruins = 0;
  for(const jv_t *x = ch->filho; x && g_ap.n < MAX_APLICADAS; x = x->prox) {
    const jv_t *tr = jv_campo(x, "trechos");
    aplicada_t *a = &g_ap.a[g_ap.n];
    int ok = x->tipo == JV_OBJETO && tr && tr->tipo == JV_LISTA && g_ap.pid > 0;
    snprintf(a->arquivo, sizeof a->arquivo, "%s", jv_txt(x, "arquivo"));
    snprintf(a->nome, sizeof a->nome, "%s", jv_txt(x, "nome"));
    a->indice = atoi(jv_txt(x, "indice"));
    const jv_t *ini = jv_campo(x, "inicial"), *dep = jv_campo(x, "depende");
    a->inicial = ini && ini->tipo == JV_LOGICO && ini->logico;
    a->xml = !strcmp(jv_txt(x, "fonte"), "xml");
    for(const jv_t *d = dep && dep->tipo == JV_LISTA ? dep->filho : NULL; d && a->ndep < MAX_DEPS; d = d->prox)
      if(d->tipo == JV_NUMERO) a->dep[a->ndep++] = atoi(d->texto);
    a->t = ok ? calloc(MAX_TRECHOS_CHEAT, sizeof *a->t) : NULL;
    ok = ok && a->t;
    for(const jv_t *y = ok ? tr->filho : NULL; y && ok && a->n < MAX_TRECHOS_CHEAT; y = y->prox) {
      trecho_ap_t *t = &a->t[a->n];
      int n1, n2, n3;
      t->original = hex_campo(y, "original", &n1);
      t->on = hex_campo(y, "on", &n2);
      t->off = hex_campo(y, "off", &n3);
      t->n = n1;
      a->n++;
      ok = !hex_offset(jv_txt(y, "endereco"), &t->endereco) && n1 > 0 && n1 == n2 && n1 == n3;
    }
    if(ok && a->n) g_ap.n++;
    else { ruins++; aplicada_liberar(a); }
  }
  jv_liberar(r);
  diario("cheats: %s: %d cheat(s) ligada(s) de antes (%s pid %d app %d)%s", c, g_ap.n, g_ap.tid, g_ap.pid, g_ap.app_id,
         ruins ? "; registros invalidos ignorados" : "");
}

/* Confere se as cheats ligadas ainda sao do jogo aberto. 0 = valem (ou nao ha nenhuma); 1 = viraram perdidas
   (jogo fechou/mudou: nada e gravado); -1 = nao deu para conferir agora (nada muda, nada e gravado). */
static int ap_conferir(const jogo_t *j, int pid_atual) {
  if(!g_ap.n) return 0;
  int mudou;
  if(!strcmp(j->tipo, "desconhecido")) return -1;
  if(strcmp(j->tid, g_ap.tid)) mudou = 1;   /* outro jogo ou nenhum (menu) */
  else if(j->app_id >= 0 && g_ap.app_id >= 0 && j->app_id != g_ap.app_id) mudou = 1;
  else if(pid_atual > 0) mudou = pid_atual != g_ap.pid;
  else if(kill(g_ap.pid, 0) && errno == ESRCH) mudou = 1;
  else return -1;
  if(!mudou) return 0;
  size_t p = 0;
  g_ap.perdidas[0] = 0;
  for(int k = 0; k < g_ap.n; k++)
    p += (size_t)snprintf(g_ap.perdidas + p, p < sizeof g_ap.perdidas ? sizeof g_ap.perdidas - p : 0, "%s%s", k ? ", " : "",
                          g_ap.a[k].nome);
  g_ap.perdidas_quando = time(NULL);
  diario("cheats: o jogo mudou (%s pid %d app %d -> %s pid %d app %d): %d cheat(s) ligada(s) perdida(s), nada foi gravado: %s",
         g_ap.tid, g_ap.pid, g_ap.app_id, j->tid[0] ? j->tid : "-", pid_atual, j->app_id, g_ap.n, g_ap.perdidas);
  while(g_ap.n) aplicada_tirar(g_ap.n - 1);
  ap_gravar();
  return 1;
}

/* ------------------------------------------------------------------ o que pode ser ligado (suporte) */

static int tem_tipo(const trecho_t *t, int n, const char *tipo) {
  for(int i = 0; i < n; i++)
    if(!strcmp(t[i].tipo, tipo)) return 1;
  return 0;
}

/* Area extra (Fase 2): a area tem de existir, estar em pagina executavel do jogo (e, com faixas conhecidas, numa
   faixa executavel do modulo). "" = pode; senao o motivo. */
static const char *cave_ok(int pid, const char *modulo, uint64_t base, const trecho_t *t) {
  uint64_t end = base + t->offset;
  int p = prot_memoria(pid, end, (size_t)t->n);
  if(p < 0) return "area_extra_ilegivel";
  if(!(p & PROT_L)) return "area_extra_sem_leitura";   /* 0.9.26: "--x" (so execucao, PS5 real) nao conta como r-x */
  if(!(p & PROT_X)) return "area_extra_nao_exec";
  const faixa_t *f;
  const char *origem;
  int nf = faixas_do_modulo(pid, modulo, base, &f, &origem);
  if(nf && !dentro_das_faixas(f, nf, end, (uint64_t)t->n, PROT_X)) return "area_extra_fora";
  return "";
}

/* Destino da cheat no jogo (processo e base do modulo dela). */
typedef struct {
  int pid, tem_base;
  uint64_t base;
} alvo_t;

/* 0.9.26: um pedaco a gravar de uma cheat ja resolvida: endereco, bytes "on", "off" (NULL no .xml: o desligado e o
   original lido na hora de ligar) e a fase de gravacao (0 = codigo na area extra, 1 = salto de volta da area extra,
   2 = trecho comum e salto de ida). Ligar grava na ordem das fases; desligar anda de tras para frente. */
typedef struct {
  uint64_t end;
  int n, fase;
  const unsigned char *on, *off;
  unsigned char salto[256];
} seg_t;

static const char *motivo_busca(int r) {
  return r == BUSCA_AUSENTE ? "padrao_ausente" : r == BUSCA_AMBIGUO ? "padrao_ambiguo" : r == BUSCA_SEM_FAIXAS ? "padrao_sem_faixas"
       : r == BUSCA_LIMITE ? "padrao_limite" : "padrao_erro";
}

/* jmp rel32 (E9) de "de" para "para" em "tam" bytes (o resto NOP, como o onionHEN). -1 = longe demais. */
static int salto_rel32(uint64_t de, uint64_t para, int tam, unsigned char *o) {
  int64_t d = (int64_t)(para - (de + 5));
  if(tam < 5 || tam > 256 || d < INT32_MIN || d > INT32_MAX) return -1;
  memset(o, 0x90, (size_t)tam);
  uint32_t u = (uint32_t)(int32_t)d;
  o[0] = 0xE9;
  for(int i = 0; i < 4; i++) o[1 + i] = (unsigned char)(u >> (8 * i));
  return 0;
}

/* 0.9.26: resolve os trechos de uma cheat .xml (Illusion) nos enderecos do jogo. Endereco direto = base + offset;
   mask = padrao achado EXATAMENTE uma vez nas partes do modulo + Offset; mask_jump32 = como o onionHEN (Value na area
   extra achada pelo Target, salto de volta logo depois e jmp no lugar do padrao), mas so com a opcao de teste da
   area extra ligada e se a area passar nas MESMAS regras da area extra do .json (existe, r-x, dentro do modulo) e
   estiver zerada nos bytes que serao gravados. "" = resolvida (seg em ordem de fase, *nseg); senao o motivo. */
static const char *xml_resolver(const cheat_t *c, const alvo_t *al, seg_t *seg, int max, int *nseg) {
  static unsigned char todos[256];
  if(!todos[0]) memset(todos, 0xFF, sizeof todos);
  int ns = 0, bytes = 0;
  *nseg = 0;
  for(int k = 0; k < c->nt; k++) {
    const trecho_t *t = &c->t[k];
    if(ns + 3 > max) return "grande";
    if(!t->padrao) {
      seg[ns++] = (seg_t){.end = al->base + t->offset, .n = t->n, .fase = 2, .on = t->on};
      continue;
    }
    uint64_t m = 0;
    int r = buscar_padrao(al->pid, c->modulo, al->base, t->padrao, t->mascara, t->np, &m);
    if(r != BUSCA_ACHOU) return motivo_busca(r);
    if(t->desloc < 0 && m < (uint64_t)(-t->desloc)) return "padrao_erro";
    uint64_t end = m + (uint64_t)t->desloc;
    if(strcmp(t->tipo, "padrao_salto")) {
      seg[ns++] = (seg_t){.end = end, .n = t->n, .fase = 2, .on = t->on};
      continue;
    }
    if(!config_cheats_area_extra()) return "area_extra";
    uint64_t cave = 0;
    r = buscar_padrao(al->pid, c->modulo, al->base, t->alvo, todos, t->nalvo, &cave);
    if(r == BUSCA_AUSENTE) return "area_extra_ausente";
    if(r == BUSCA_AMBIGUO) return "area_extra_ambigua";
    if(r != BUSCA_ACHOU) return motivo_busca(r);
    trecho_t tc = {.offset = cave - al->base, .n = t->n + 5};
    const char *mot = cave_ok(al->pid, c->modulo, al->base, &tc);
    if(*mot) return mot;
    unsigned char *z = malloc((size_t)tc.n);
    int ok = z && !ler_memoria(al->pid, cave, z, (size_t)tc.n), zero = ok && tudo_zero(z, tc.n);
    free(z);
    if(!ok) return "area_extra_ilegivel";
    if(!zero) return "area_extra_nao_zerada";
    seg_t *ida = &seg[ns + 2], *volta = &seg[ns + 1];
    seg[ns] = (seg_t){.end = cave, .n = t->n, .fase = 0, .on = t->on};
    *volta = (seg_t){.end = cave + (uint64_t)t->n, .n = 5, .fase = 1};
    *ida = (seg_t){.end = end, .n = t->tam_salto, .fase = 2};
    if(salto_rel32(volta->end, end + (uint64_t)t->tam_salto, 5, volta->salto) || salto_rel32(end, cave, t->tam_salto, ida->salto))
      return "salto_longe";
    volta->on = volta->salto;
    ida->on = ida->salto;
    ns += 3;
  }
  /* ordem de gravacao por fase (estavel) */
  for(int i = 1; i < ns; i++)
    for(int k = i; k > 0 && seg[k - 1].fase > seg[k].fase; k--) {
      seg_t x = seg[k];
      seg[k] = seg[k - 1];
      seg[k - 1] = x;
      if(seg[k].on == seg[k - 1].salto) seg[k].on = seg[k].salto;   /* o vetor salto mudou de lugar com o seg */
      if(seg[k - 1].on == seg[k].salto) seg[k - 1].on = seg[k - 1].salto;
    }
  for(int a = 0; a < ns; a++) {
    bytes += seg[a].n;
    for(int b = a + 1; b < ns; b++)
      if(seg[a].end < seg[b].end + (uint64_t)seg[b].n && seg[b].end < seg[a].end + (uint64_t)seg[a].n) return "invalido";
  }
  if(bytes > MAX_BYTES_CHEAT) return "grande";
  *nseg = ns;
  return "";
}

/* Por que a cheat i do arquivo nao pode ser ligada ("" = pode). dep recebe o nome da cheat de que ela depende
   (motivos "depende" e "precisa_inicial"). Com padroes (.xml), a busca usa o alvo (pode ler a memoria). */
static const char *cheat_suporte(const cfile_t *cf, int i, const char *arquivo, const alvo_t *al, char *dep, size_t tdep) {
  const cheat_t *c = &cf->c[i];
  const trecho_t *t = c->t;
  int n = c->nt, bytes = 0;
  if(dep) dep[0] = 0;
  if(c->invalido || tem_tipo(t, n, "invalido")) return "invalido";
  if(!n) return "vazia";
  for(int a = 0; a < n; a++)   /* trechos da mesma cheat que se sobrepoem */
    for(int b = a + 1; b < n; b++)
      if(!t[a].padrao && !t[b].padrao && t[a].offset < t[b].offset + (uint64_t)t[b].n && t[b].offset < t[a].offset + (uint64_t)t[a].n)
        return "invalido";
  if(cf->fmt == FMT_XML) {   /* 0.9.26: .xml com escrita (os originais sao lidos e guardados ao ligar) */
    if(aplicada_achar(arquivo, i) >= 0) return "";   /* ligada pelo glibren: desligar usa os enderecos guardados */
    if(strcmp(c->modulo, "eboot.bin")) return "outro_processo";
    if(!al || !al->tem_base || al->pid <= 0) return "sem_processo";
    seg_t *s = calloc((size_t)n * 3, sizeof *s);
    if(!s) return "grande";
    int ns;
    const char *m = xml_resolver(c, al, s, n * 3, &ns);
    free(s);
    return m;
  }
  if(strcmp(c->modulo, "eboot.bin")) return "outro_processo";
  if(tem_tipo(t, n, "secao")) return "secao";
  if(tem_tipo(t, n, "absoluto")) return "absoluto";
  if(tem_tipo(t, n, "sem_off")) return "sem_off";
  for(int k = 0; k < n; k++) bytes += t[k].n;
  if(bytes > MAX_BYTES_CHEAT) return "grande";
  if(tem_tipo(t, n, "area_extra")) {
    if(!config_cheats_area_extra()) return "area_extra";
    if(!al || !al->tem_base) return "area_extra";
    for(int k = 0; k < n; k++) {
      if(strcmp(t[k].tipo, "area_extra")) continue;
      const char *m = cave_ok(al->pid, c->modulo, al->base, &t[k]);
      if(*m) return m;
    }
  }
  if(cf->tem_inicial && !c->inicial)
    for(int k = 0; k < cf->n; k++)
      if(cf->c[k].inicial && aplicada_achar(arquivo, k) < 0) {
        if(dep) snprintf(dep, tdep, "%s", cf->c[k].nome);
        return "precisa_inicial";
      }
  if(c->ndep < 0) return "depende_muitas";
  for(int d = 0; d < c->ndep; d++)
    if(aplicada_achar(arquivo, c->dep[d]) < 0) {
      if(dep) snprintf(dep, tdep, "%s", cf->c[c->dep[d]].nome);
      return "depende";
    }
  return "";
}

/* Outra cheat ligada que depende da cheat k de g_ap (salta para a area extra dela, ou e comum num arquivo com
   codigo inicial e k e um codigo inicial). -1 se nenhuma. */
static int dependente_ligada(int k) {
  const aplicada_t *a = &g_ap.a[k];
  for(int m = 0; m < g_ap.n; m++) {
    const aplicada_t *b = &g_ap.a[m];
    if(m == k || strcmp(a->arquivo, b->arquivo)) continue;
    if(a->inicial && !b->inicial) return m;
    for(int d = 0; d < b->ndep; d++)
      if(b->dep[d] == a->indice) return m;
  }
  return -1;
}

/* ------------------------------------------------------------------ JSON de saida */

/* Bytes em hex (ate 24; mais que isso termina em ".."). */
static void hex_curto(buf_t *b, const unsigned char *d, int n) {
  char s[2 * 24 + 4];
  int k = n > 24 ? 24 : n, p = 0;
  for(int i = 0; i < k; i++) p += snprintf(s + p, sizeof s - (size_t)p, "%02X", d[i]);
  if(n > k) snprintf(s + p, sizeof s - (size_t)p, "..");
  s[sizeof s - 1] = 0;
  buf_json(b, s);
}

/* Contagem dos trechos por tipo e, nos conferiveis (normal, absoluto, sem_off, outro_processo, padrao achado), pelo
   que foi lido. As areas extras NAO entram em "lidos" (na 0.9.17 entravam duas vezes: "5 de 9" com 7 trechos); o
   estado delas fica em cav_* (so para o estado da cheat). */
typedef struct {
  int trechos, normais, caves, secao, absolutos, sem_off, outro_processo, invalidos, padroes;
  int conferiveis, lidos, desligados, ligados, diferentes, erros;
  int cav_lig, cav_des, cav_dif, cav_err;
} contagem_t;

static void contagem_somar(contagem_t *t, const contagem_t *c) {
  int *a = (int *)t;
  const int *b = (const int *)c;
  for(size_t i = 0; i < sizeof *t / sizeof(int); i++) a[i] += b[i];
}

/* Primeiro processo do jogo que tem o modulo (pid e base). */
static void resolver_modulo(const processos_t *pr, const char *modulo, alvo_t *al) {
  al->pid = pr->n ? pr->pids[0] : -1;
  al->tem_base = 0;
  al->base = 0;
  for(int i = 0; i < pr->n; i++)
    if(!base_do_modulo(pr->pids[i], modulo, &al->base)) {
      al->pid = pr->pids[i];
      al->tem_base = 1;
      return;
    }
}

/* Um trecho: le e compara. Estados: desligado, ligado, diferente, cave (area extra), erro (leitura falhou), invalido,
   secao, sem_base (modulo nao achado), limite, sem_off (lido, sem "off" para comparar) e, nos padroes:
   padrao_ausente, padrao_ambiguo, padrao_sem_faixas, padrao_limite, padrao_erro. */
static void trecho_json(buf_t *b, const trecho_t *t, const char *modulo, const alvo_t *al, int *leituras, contagem_t *c) {
  static unsigned char atual[MAX_TRECHO];   /* so com g_trava_mem */
  const char *estado = NULL, *tipo = t->tipo;
  int cave = !strcmp(tipo, "area_extra"), absoluto = !strcmp(tipo, "absoluto"), padrao = t->padrao != NULL;
  if(!strcmp(tipo, "normal") && strcmp(modulo, "eboot.bin")) tipo = "outro_processo";
  c->trechos++;
  if(!strcmp(tipo, "normal")) c->normais++;
  else if(cave) c->caves++;
  else if(!strcmp(tipo, "secao")) c->secao++;
  else if(absoluto) c->absolutos++;
  else if(!strcmp(tipo, "sem_off")) c->sem_off++;
  else if(!strcmp(tipo, "outro_processo")) c->outro_processo++;
  else if(padrao) c->padroes++;
  else c->invalidos++;
  int conferivel = !cave && strcmp(tipo, "secao") && strcmp(tipo, "invalido");
  buf_str(b, "{\"offset\":");
  buf_json(b, t->offset_txt);
  buf_str(b, ",\"tipo\":");
  buf_json(b, tipo);
  if(padrao) {
    char h[3 * 32 + 4];
    hex_txt_simples(h, sizeof h, t->padrao, t->mascara, t->np);
    buf_str(b, ",\"padrao\":");
    buf_json(b, h);
    buf_fmt(b, ",\"desloc\":%lld", (long long)t->desloc);
  }
  if(!strcmp(tipo, "invalido") || !strcmp(tipo, "secao")) estado = tipo;
  else if(!al->tem_base && !absoluto) estado = "sem_base";
  else if(*leituras >= MAX_LEITURAS) estado = "limite";
  if(estado) {
    if(conferivel) { c->conferiveis++; c->erros++; }
    goto fim;
  }
  uint64_t end = absoluto ? t->offset : al->base + t->offset;
  if(padrao) {
    uint64_t m = 0;
    int r = buscar_padrao(al->pid, modulo, al->base, t->padrao, t->mascara, t->np, &m);
    if(r == BUSCA_ACHOU && t->desloc < 0 && m < (uint64_t)(-t->desloc)) r = BUSCA_ERRO;
    if(r != BUSCA_ACHOU) {
      static char nome[32];
      snprintf(nome, sizeof nome, "padrao_%s", BUSCA_NOME[r]);
      estado = nome;
      goto fim;
    }
    end = m + (uint64_t)t->desloc;
  }
  if(conferivel) c->conferiveis++;
  (*leituras)++;
  buf_fmt(b, ",\"endereco\":\"0x%llx\"", (unsigned long long)end);
  if(ler_memoria(al->pid, end, atual, (size_t)t->n)) {
    estado = cave ? "cave" : "erro";
    if(cave) c->cav_err++;
    else c->erros++;
    goto fim;
  }
  buf_str(b, ",\"lido\":");
  hex_curto(b, atual, t->n);
  int bate_off = t->off && !memcmp(atual, t->off, (size_t)t->n), bate_on = !memcmp(atual, t->on, (size_t)t->n);
  if(cave) {
    estado = bate_off ? "cave" : bate_on ? "ligado" : "diferente";
    if(bate_off) c->cav_des++;
    else if(bate_on) c->cav_lig++;
    else c->cav_dif++;
    if(config_cheats_area_extra()) {
      int p = prot_memoria(al->pid, end, (size_t)t->n);
      buf_fmt(b, ",\"prot\":\"%s%c%c%c\"", p < 0 ? "?" : "", p >= 0 && p & PROT_L ? 'r' : '-', p >= 0 && p & PROT_E ? 'w' : '-',
              p >= 0 && p & PROT_X ? 'x' : '-');
    }
  } else {
    c->lidos++;
    if(bate_off) { estado = "desligado"; c->desligados++; }
    else if(bate_on) { estado = "ligado"; c->ligados++; }
    else if(!t->off) estado = "sem_off";   /* sem o "off" no arquivo: nao da para dizer que nao bate */
    else { estado = "diferente"; c->diferentes++; }
  }
fim:
  buf_str(b, ",\"estado\":");
  buf_json(b, estado);
  buf_fmt(b, ",\"bytes\":%d}", t->n);
}

/* As cheats de um arquivo, com a leitura de cada trecho. */
static void arquivo_cheats(buf_t *b, const arquivo_t *a, const cfile_t *cf, const processos_t *pr, int *leituras, int *primeiro,
                           contagem_t *total, int *suportadas, int *nao_suportadas) {
  buf_fmt(b, "%s{\"arquivo\":", *primeiro ? "" : ",");
  *primeiro = 0;
  buf_json(b, a->nome);
  buf_str(b, ",\"origem\":");
  buf_json(b, a->origem);
  buf_str(b, ",\"formato\":");
  buf_json(b, FMT_NOME[a->fmt]);
  if(cf->erro[0]) {
    buf_str(b, ",\"erro\":");
    buf_json(b, cf->erro);
    buf_str(b, ",\"mods\":[]}");
    return;
  }
  /* destino de cada modulo usado no arquivo (o .xml pode ter um AppElf por patch) */
  struct { char nome[128]; alvo_t al; } mods[8];
  int nmods = 0;
  alvo_t al_arq;
  resolver_modulo(pr, base_nome(cf->processo), &al_arq);
  buf_str(b, ",\"jogo\":");
  buf_json(b, cf->jogo);
  buf_str(b, ",\"processo\":");
  buf_json(b, cf->processo);
  buf_fmt(b, ",\"versao_confere\":%s,\"pid\":%d", cf->versao_confere ? "true" : "false", al_arq.pid);
  if(al_arq.tem_base) buf_fmt(b, ",\"base\":\"0x%llx\"", (unsigned long long)al_arq.base);
  buf_fmt(b, ",\"codigo_inicial\":%s,\"creditos\":[", cf->tem_inicial ? "true" : "false");
  for(int k = 0; k < cf->ncred; k++) {
    if(k) buf_str(b, ",");
    buf_json(b, cf->creditos[k]);
  }
  buf_str(b, "],\"mods\":[");
  for(int i = 0; i < cf->n; i++) {
    const cheat_t *c = &cf->c[i];
    alvo_t al = al_arq;
    if(strcmp(c->modulo, base_nome(cf->processo))) {
      int m = 0;
      while(m < nmods && strcmp(mods[m].nome, c->modulo)) m++;
      if(m == nmods && nmods < 8) {
        snprintf(mods[m].nome, sizeof mods[m].nome, "%s", c->modulo);
        resolver_modulo(pr, c->modulo, &mods[m].al);
        nmods++;
      }
      if(m < nmods) al = mods[m].al;
      else al.tem_base = 0;
    }
    buf_fmt(b, "%s{\"indice\":%d,\"nome\":", i ? "," : "", i);
    buf_json(b, c->nome);
    buf_str(b, ",\"descricao\":");
    buf_json(b, c->descricao);
    buf_str(b, ",\"tipo\":");
    buf_json(b, c->tipo);
    buf_fmt(b, ",\"inicial\":%s", c->inicial ? "true" : "false");
    if(strcmp(c->modulo, base_nome(cf->processo))) {
      buf_str(b, ",\"modulo\":");
      buf_json(b, c->modulo);
    }
    buf_str(b, ",\"trechos\":[");
    contagem_t cc = {0};
    for(int k = 0; k < c->nt; k++) {
      if(k) buf_str(b, ",");
      trecho_json(b, &c->t[k], c->modulo, &al, leituras, &cc);
    }
    char dep[160];
    const char *suporte = cheat_suporte(cf, i, a->nome, &al, dep, sizeof dep);
    /* estado verdadeiro: os trechos conferiveis e (nas cheats com area extra) as areas extras */
    int lig = cc.ligados + cc.cav_lig, des = cc.desligados + cc.cav_des, dif = cc.diferentes + cc.cav_dif, err = cc.erros + cc.cav_err;
    const char *leitura = err ? "erro" : dif ? "diferente" : lig && des ? "misto" : lig ? "ligado" : des ? "desligado" : "sem_leitura";
    const char *estado = *suporte ? "nao_suportada" : !strcmp(leitura, "sem_leitura") ? "desligado" : leitura;
    if(*suporte) (*nao_suportadas)++;
    else (*suportadas)++;
    buf_str(b, "],\"estado\":");
    buf_json(b, estado);
    buf_str(b, ",\"leitura\":");
    buf_json(b, leitura);
    buf_str(b, ",\"suporte\":");
    buf_json(b, suporte);
    if(dep[0]) {
      buf_str(b, ",\"depende\":");
      buf_json(b, dep);
    }
    buf_fmt(b, ",\"aplicada\":%s}", aplicada_achar(a->nome, i) >= 0 ? "true" : "false");
    contagem_somar(total, &cc);
  }
  buf_str(b, "]}");
}

/* Processo eboot.bin do jogo aberto e a base dele (para gravar e para conferir as ligadas). -1 = nao achou. */
static int pid_do_eboot(const processos_t *pr, uint64_t *base) {
  for(int i = 0; i < pr->n; i++)
    if(!base_do_modulo(pr->pids[i], "eboot.bin", base)) return pr->pids[i];
  return -1;
}

static char g_ultimo_resumo[460];

void cheats_json(buf_t *b) {
  jogo_t j;
  jogo_aberto(&j);
  jogo_versao(&j);
#ifdef __PROSPERO__
  const char *simulado = "false";
#else
  const char *simulado = "true";
#endif
  buf_fmt(b, "{\"ok\":true,\"teste\":true,\"somente_leitura\":false,\"escrita\":true,\"fase\":2,\"area_extra_teste\":%s,\"simulado\":%s,\"jogo\":{\"tid\":",
          config_cheats_area_extra() ? "true" : "false", simulado);
  buf_json(b, j.tid);
  buf_str(b, ",\"tipo\":");
  buf_json(b, j.tipo);
  buf_str(b, ",\"nome\":");
  buf_json(b, j.nome);
  buf_str(b, ",\"versao\":");
  buf_json(b, j.versao);
  buf_str(b, ",\"versao_de\":");
  buf_json(b, j.versao_de);
  buf_str(b, ",\"mestre\":");
  buf_json(b, j.mestre);
  buf_fmt(b, ",\"app_id\":%d},", j.app_id);
  catalogo_json(b);

  arquivo_t *lista = calloc(MAX_ARQUIVOS, sizeof *lista);
  int n = lista && j.versao[0] && j.tid[0] ? achar_arquivos(&j, lista, MAX_ARQUIVOS) : 0;
  processos_t pr;
  memset(&pr, 0, sizeof pr);
  pthread_mutex_lock(&g_trava_mem);
  ap_carregar();
  if(n || g_ap.n) processos_do_jogo(&j, &pr);
  uint64_t base_eboot = 0;
  ap_conferir(&j, pid_do_eboot(&pr, &base_eboot));
  buf_str(b, ",\"processos\":[");
  for(int i = 0; i < pr.n; i++) {
    buf_fmt(b, "%s{\"pid\":%d,\"nome\":", i ? "," : "", pr.pids[i]);
    buf_json(b, pr.comm[i]);
    buf_str(b, "}");
  }
  buf_str(b, "],\"arquivos\":[");
  int leituras = 0, primeiro = 1, suportadas = 0, nao_suportadas = 0, mostrados = 0, por_fmt[FMT_QTD] = {0};
  contagem_t total = {0};
  uint64_t impressoes[MAX_ARQUIVOS];
  int dono[MAX_ARQUIVOS];
  buf_t ign = {0};
  buf_add(&ign, "", 0);
  for(int i = 0; i < n; i++) {
    const cfile_t *cf = ler_cfile(&lista[i], &j);
    int igual = -1;
    for(int k = 0; k < mostrados && igual < 0 && !cf->erro[0] && cf->n; k++)
      if(impressoes[k] == cf->impressao) igual = dono[k];
    if(igual >= 0 || (!cf->erro[0] && !cf->n && lista[i].fmt == FMT_XML)) {
      buf_str(&ign, ign.n ? ",{\"arquivo\":" : "{\"arquivo\":");
      buf_json(&ign, lista[i].nome);
      buf_str(&ign, ",\"formato\":");
      buf_json(&ign, FMT_NOME[lista[i].fmt]);
      if(igual >= 0) {
        buf_str(&ign, ",\"motivo\":\"igual\",\"igual_a\":");
        buf_json(&ign, lista[igual].nome);
      } else buf_str(&ign, ",\"motivo\":\"sem_patches\"");
      buf_str(&ign, "}");
      continue;
    }
    impressoes[mostrados] = cf->impressao;
    dono[mostrados++] = i;
    por_fmt[lista[i].fmt]++;
    arquivo_cheats(b, &lista[i], cf, &pr, &leituras, &primeiro, &total, &suportadas, &nao_suportadas);
  }
  buf_str(b, "],\"ignorados\":[");
  buf_add(b, ign.d, ign.n);
  buf_free(&ign);
  buf_fmt(b, "],\"formatos\":{\"json\":%d,\"shn\":%d,\"mc4\":%d,\"xml\":%d}", por_fmt[FMT_JSON], por_fmt[FMT_SHN], por_fmt[FMT_MC4],
          por_fmt[FMT_XML]);
  buf_fmt(b,
          ",\"resumo\":{\"trechos\":%d,\"normais\":%d,\"caves\":%d,\"secao\":%d,\"absolutos\":%d,\"sem_off\":%d,"
          "\"outro_processo\":%d,\"invalidos\":%d,\"padroes\":%d,\"conferiveis\":%d,\"lidos\":%d,\"desligados\":%d,\"ligados\":%d,"
          "\"diferentes\":%d,\"erros\":%d,\"suportadas\":%d,\"nao_suportadas\":%d,\"aplicadas\":%d}",
          total.trechos, total.normais, total.caves, total.secao, total.absolutos, total.sem_off, total.outro_processo,
          total.invalidos, total.padroes, total.conferiveis, total.lidos, total.desligados, total.ligados, total.diferentes, total.erros,
          suportadas, nao_suportadas, g_ap.n);
  buf_str(b, ",\"aplicadas\":[");
  for(int k = 0; k < g_ap.n; k++) {
    buf_str(b, k ? ",{\"arquivo\":" : "{\"arquivo\":");
    buf_json(b, g_ap.a[k].arquivo);
    buf_fmt(b, ",\"indice\":%d,\"nome\":", g_ap.a[k].indice);
    buf_json(b, g_ap.a[k].nome);
    buf_str(b, "}");
  }
  buf_str(b, "],\"perdidas\":{\"nomes\":");
  buf_json(b, g_ap.perdidas);
  buf_fmt(b, ",\"quando\":%lld}}", (long long)g_ap.perdidas_quando);
  /* diario: uma linha quando o resultado muda (nao a cada consulta da pagina) */
  char resumo[460];
  snprintf(resumo, sizeof resumo,
           "%s %s v%s (%s): %d arquivo(s) (json %d, shn %d, mc4 %d, xml %d), %d processo(s)%s%s; %d trecho(s): %d conferiveis "
           "(desligados %d, ligados %d, diferentes %d, erros %d), area extra %d, secao %d, outro processo %d, padroes %d, "
           "invalidos %d; ligadas pelo glibren %d",
           j.tipo, j.tid[0] ? j.tid : "-", j.versao[0] ? j.versao : "?", j.versao_de[0] ? j.versao_de : "-", mostrados, por_fmt[FMT_JSON],
           por_fmt[FMT_SHN], por_fmt[FMT_MC4], por_fmt[FMT_XML], pr.n, pr.n ? " primeiro " : "", pr.n ? pr.comm[0] : "", total.trechos,
           total.conferiveis, total.desligados, total.ligados, total.diferentes, total.erros, total.caves, total.secao, total.outro_processo,
           total.padroes, total.invalidos, g_ap.n);
  if(strcmp(resumo, g_ultimo_resumo)) {
    snprintf(g_ultimo_resumo, sizeof g_ultimo_resumo, "%s", resumo);
    diario("cheats: %s", resumo);
  }
  pthread_mutex_unlock(&g_trava_mem);
  free(lista);
}

/* ------------------------------------------------------------------ ligar e desligar (Fase 1) */

/* Resposta de erro: {"ok":false,"chave":..,"erro":..,"params":{..}}. params_json = conteudo do objeto (ou ""). */
static int recusar(buf_t *r, int status, const char *chave, const char *params_json, const char *fmt, ...)
  __attribute__((format(printf, 5, 6)));
static int recusar(buf_t *r, int status, const char *chave, const char *params_json, const char *fmt, ...) {
  char msg[400];
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(msg, sizeof msg, fmt, ap);
  va_end(ap);
  buf_str(r, "{\"ok\":false,\"chave\":");
  buf_json(r, chave);
  buf_str(r, ",\"erro\":");
  buf_json(r, msg);
  buf_fmt(r, ",\"params\":{%s}}", params_json ? params_json : "");
  return status;
}

/* params de um trecho: {"trecho":N,"endereco":"0x..","lido":"..","esperado":".."} (conteudo, sem chaves) */
static void params_trecho(char *s, size_t tam, int i, uint64_t end, const unsigned char *lido, const unsigned char *esperado, int n) {
  char hl[80] = "", he[80] = "";
  if(lido) hex_txt(hl, sizeof hl, lido, n);
  if(esperado) hex_txt(he, sizeof he, esperado, n);
  snprintf(s, tam, "\"trecho\":%d,\"endereco\":\"0x%llx\",\"lido\":\"%s\",\"esperado\":\"%s\"", i + 1, (unsigned long long)end, hl, he);
}

/* Grava "dados" no trecho e le de volta. 0 = conferido; -1 = escrita falhou; -2 = leitura de volta diferente/falhou. */
static int gravar_conferir(int pid, uint64_t end, const unsigned char *dados, int n, unsigned char *lido) {
  if(escrever_memoria(pid, end, dados, (size_t)n)) return -1;
  if(ler_memoria(pid, end, lido, (size_t)n) || memcmp(lido, dados, (size_t)n)) return -2;
  return 0;
}

/* Volta os trechos 0..ate de uma cheat para "alvo_de" (original ou on), de tras para frente; so grava onde os bytes
   atuais sao diferentes. 0 = todos conferidos. */
static int voltar_trechos(int pid, const aplicada_t *a, int ate, int para_original, unsigned char *lido) {
  int falhas = 0;
  for(int i = ate; i >= 0; i--) {
    const trecho_ap_t *t = &a->t[i];
    const unsigned char *alvo = para_original ? t->original : t->on;
    if(!ler_memoria(pid, t->endereco, lido, (size_t)t->n) && !memcmp(lido, alvo, (size_t)t->n)) continue;
    int r = gravar_conferir(pid, t->endereco, alvo, t->n, lido);
    char h[80];
    hex_txt(h, sizeof h, alvo, t->n);
    diario("cheats:   desfazer trecho %d 0x%llx -> %s: %s", i + 1, (unsigned long long)t->endereco, h,
           !r ? "ok" : r == -1 ? "ESCRITA FALHOU" : "LEITURA DE VOLTA DIFERENTE");
    if(r) falhas++;
  }
  return falhas ? -1 : 0;
}

/* Desliga a cheat k de g_ap (com g_trava_mem). Exige os bytes atuais = "on" e originais = "off"; grava os originais
   de tras para frente e le de volta; se um trecho falhar, volta os ja restaurados para "on" (cheat continua ligada).
   0 = desligou (e saiu de g_ap). */
static int desligar_k(int k, int pid, const char *quando, buf_t *r) {
  aplicada_t *a = &g_ap.a[k];
  char nome[160], tid[16], params[300];
  unsigned char *lido = malloc(MAX_TRECHO);
  snprintf(nome, sizeof nome, "%s", a->nome);
  snprintf(tid, sizeof tid, "%s", g_ap.tid);
  if(!lido) return recusar(r, 500, "cheats_memoria", "", "sem memoria");
  int dk = dependente_ligada(k);
  if(dk >= 0) {   /* outra ligada salta para a area extra desta (ou esta e o codigo inicial dela): desligar a outra antes */
    buf_t p = {0};
    buf_str(&p, "\"nome\":");
    buf_json(&p, g_ap.a[dk].nome);
    diario("cheats: desligar %s em %s recusado: %s (ligada) depende dela", nome, tid, g_ap.a[dk].nome);
    int st = recusar(r, 200, "cheats_dependente", p.d, "outra cheat ligada depende desta: desligue-a antes");
    buf_free(&p);
    free(lido);
    return st;
  }
  for(int i = 0; i < a->n; i++) {
    trecho_ap_t *t = &a->t[i];
    if(memcmp(t->original, t->off, (size_t)t->n)) {
      free(lido);
      params_trecho(params, sizeof params, i, t->endereco, t->original, t->off, t->n);
      diario("cheats: desligar %s em %s recusado: registro com original diferente do desligado no trecho %d", nome, tid, i + 1);
      return recusar(r, 200, "cheats_registro_invalido", params, "os bytes originais guardados nao batem com o desligado do arquivo");
    }
    if(ler_memoria(pid, t->endereco, lido, (size_t)t->n)) {
      free(lido);
      params_trecho(params, sizeof params, i, t->endereco, NULL, t->on, t->n);
      diario("cheats: desligar %s em %s recusado: nao leu o trecho %d (0x%llx)", nome, tid, i + 1, (unsigned long long)t->endereco);
      return recusar(r, 200, "cheats_leitura", params, "nao leu a memoria do jogo no trecho %d", i + 1);
    }
    if(memcmp(lido, t->on, (size_t)t->n)) {
      params_trecho(params, sizeof params, i, t->endereco, lido, t->on, t->n);
      free(lido);
      diario("cheats: desligar %s em %s recusado: os bytes do trecho %d (0x%llx) nao estao mais ligados", nome, tid, i + 1,
             (unsigned long long)t->endereco);
      return recusar(r, 200, "cheats_mudou", params, "os bytes do trecho %d nao batem mais com o ligado", i + 1);
    }
  }
  diario("cheats: desligando %s em %s (pid %d, %d trecho(s))%s", nome, tid, pid, a->n, quando);
  for(int i = a->n - 1; i >= 0; i--) {
    trecho_ap_t *t = &a->t[i];
    int res = gravar_conferir(pid, t->endereco, t->original, t->n, lido);
    char h1[80], h2[80];
    hex_txt(h1, sizeof h1, t->on, t->n);
    hex_txt(h2, sizeof h2, t->original, t->n);
    diario("cheats:   trecho %d 0x%llx: %s -> %s: %s", i + 1, (unsigned long long)t->endereco, h1, h2,
           !res ? "lido de volta ok" : res == -1 ? "ESCRITA FALHOU" : "LEITURA DE VOLTA DIFERENTE");
    if(res) {
      /* volta para "on" os ja restaurados (i+1..fim) e o atual, para a cheat ficar inteira ligada */
      int voltou = 0;
      int falhas = 0;
      for(int m = i; m < a->n; m++) {
        const trecho_ap_t *u = &a->t[m];
        if(!ler_memoria(pid, u->endereco, lido, (size_t)u->n) && !memcmp(lido, u->on, (size_t)u->n)) continue;
        if(gravar_conferir(pid, u->endereco, u->on, u->n, lido)) falhas++;
      }
      voltou = !falhas;
      diario("cheats: desligar %s em %s falhou no trecho %d (0x%llx); a cheat %s", nome, tid, i + 1, (unsigned long long)t->endereco,
             voltou ? "continua ligada (voltou inteira para o ligado)" : "ficou PARCIAL: salve e feche o jogo");
      params_trecho(params, sizeof params, i, t->endereco, NULL, t->original, t->n);
      snprintf(params + strlen(params), sizeof params - strlen(params), ",\"voltou\":%s", voltou ? "true" : "false");
      free(lido);
      return recusar(r, 200, res == -1 ? "cheats_escrita" : "cheats_conferencia", params,
                     "%s no trecho %d", res == -1 ? "a escrita falhou" : "a leitura de volta nao bateu", i + 1);
    }
  }
  free(lido);
  int n = a->n;
  aplicada_tirar(k);
  ap_gravar();
  diario("cheats: desligou %s em %s (pid %d, %d trecho(s); leitura de volta OK)%s", nome, tid, pid, n, quando);
  buf_str(r, "{\"ok\":true,\"estado\":\"desligado\",\"nome\":");
  buf_json(r, nome);
  buf_fmt(r, ",\"trechos\":%d}", n);
  return 200;
}

/* Liga a cheat (com g_trava_mem). Ver as regras no topo e em ESTUDO-cheats (Fases 1 e 2). Vale para .json, .shn, .mc4
   e (0.9.26) .xml: o .xml nao tem "off", entao os bytes originais lidos aqui viram o desligado do registro. Com area extra (so com a opcao de teste), as areas extras sao gravadas primeiro. */
static int ligar_cheat(const jogo_t *j, int pid, uint64_t base, const char *arquivo, int indice, buf_t *r) {
  arquivo_t *lista = calloc(MAX_ARQUIVOS, sizeof *lista);
  if(!lista) return recusar(r, 500, "cheats_memoria", "", "sem memoria");
  int n = achar_arquivos(j, lista, MAX_ARQUIVOS), achou = -1;
  for(int i = 0; i < n && achou < 0; i++)
    if(!strcmp(lista[i].nome, arquivo)) achou = i;
  if(achou < 0) {
    free(lista);
    return recusar(r, 200, "cheats_arquivo", "", "arquivo de cheat nao encontrado para este jogo e versao");
  }
  const cfile_t *cf = ler_cfile(&lista[achou], j);   /* fica no cache (g_trava_mem): nada a liberar */
  free(lista);
  if(indice >= cf->n) return recusar(r, 200, "cheats_indice", "", "a cheat nao existe no arquivo");
  const cheat_t *ch = &cf->c[indice];
  char nome[160], params[400], dep[160];
  copiar_cortado(ch->nome, nome, sizeof nome);
  alvo_t al = {pid, 1, base};
  const char *suporte = cheat_suporte(cf, indice, arquivo, &al, dep, sizeof dep);
  /* ordem de gravacao: areas extras primeiro (o codigo novo tem de estar la antes do salto que leva a ele); o
     desligar anda de tras para frente (tira os saltos e depois devolve os zeros). 0.9.26: o .xml resolve os enderecos
     agora (padrao achado uma vez, salto do mask_jump32) e o "off" dele e o original lido abaixo. */
  int nt = 0;
  seg_t *t = calloc((size_t)(ch->nt ? ch->nt * 3 : 1), sizeof *t);
  if(!t) return recusar(r, 500, "cheats_memoria", "", "sem memoria");
  if(!*suporte && cf->fmt == FMT_XML) suporte = xml_resolver(ch, &al, t, ch->nt * 3, &nt);
  else if(!*suporte)
    for(int passo = 0; passo < 2; passo++)
      for(int i = 0; i < ch->nt; i++)
        if(!strcmp(ch->t[i].tipo, "area_extra") == !passo)   /* os bytes continuam no cache */
          t[nt++] = (seg_t){.end = base + ch->t[i].offset, .n = ch->t[i].n, .fase = passo ? 2 : 0, .on = ch->t[i].on, .off = ch->t[i].off};
  int status = 0;
  unsigned char *lido = NULL;
  aplicada_t *a = NULL;
  if(*suporte) {
    buf_t p = {0};
    buf_fmt(&p, "\"motivo\":\"%s\",\"nome\":", suporte);
    buf_json(&p, dep);
    snprintf(params, sizeof params, "%s", p.d);
    buf_free(&p);
    diario("cheats: ligar %s em %s recusado: nao suportada ainda (%s%s%s)", nome, j->tid, suporte, dep[0] ? ": " : "", dep);
    status = recusar(r, 200, "cheats_nao_suportada", params, "cheat nao suportada ainda (%s)", suporte);
    goto fim;
  }
  if(aplicada_achar(arquivo, indice) >= 0) {
    status = recusar(r, 200, "cheats_ja_ligada", "", "a cheat ja esta ligada");
    goto fim;
  }
  if(g_ap.n >= MAX_APLICADAS) {
    status = recusar(r, 200, "cheats_limite", "", "cheats ligadas demais (maximo %d)", MAX_APLICADAS);
    goto fim;
  }
  /* nao pode mexer nos mesmos bytes de outra cheat ligada */
  for(int i = 0; i < nt; i++)
    for(int k = 0; k < g_ap.n; k++)
      for(int m = 0; m < g_ap.a[k].n; m++) {
        uint64_t e1 = t[i].end, e2 = g_ap.a[k].t[m].endereco;
        if(e1 < e2 + (uint64_t)g_ap.a[k].t[m].n && e2 < e1 + (uint64_t)t[i].n) {
          buf_t p = {0};
          buf_str(&p, "\"nome\":");
          buf_json(&p, g_ap.a[k].nome);
          diario("cheats: ligar %s em %s recusado: mexe nos mesmos bytes que %s (ligada)", nome, j->tid, g_ap.a[k].nome);
          status = recusar(r, 200, "cheats_sobreposta", p.d, "mexe nos mesmos bytes de outra cheat ligada");
          buf_free(&p);
          goto fim;
        }
      }
  /* bytes atuais de TODOS os trechos = "off" (senao: versao errada, outra ferramenta ou cheat ja ligada) */
  if(!(lido = malloc(MAX_TRECHO))) { status = recusar(r, 500, "cheats_memoria", "", "sem memoria"); goto fim; }
  a = &g_ap.a[g_ap.n];
  memset(a, 0, sizeof *a);
  if(!(a->t = calloc((size_t)nt, sizeof *a->t))) { status = recusar(r, 500, "cheats_memoria", "", "sem memoria"); goto fim; }
  a->xml = cf->fmt == FMT_XML;
  for(int i = 0; i < nt; i++) {
    uint64_t end = t[i].end;
    trecho_ap_t *u = &a->t[i];
    u->endereco = end;
    u->n = t[i].n;
    u->original = malloc((size_t)t[i].n);
    u->on = malloc((size_t)t[i].n);
    u->off = malloc((size_t)t[i].n);
    a->n = i + 1;
    if(!u->original || !u->on || !u->off) { status = recusar(r, 500, "cheats_memoria", "", "sem memoria"); goto fim; }
    if(ler_memoria(pid, end, u->original, (size_t)t[i].n)) {
      params_trecho(params, sizeof params, i, end, NULL, t[i].off, t[i].n);
      diario("cheats: ligar %s em %s recusado: nao leu o trecho %d (0x%llx)", nome, j->tid, i + 1, (unsigned long long)end);
      status = recusar(r, 200, "cheats_leitura", params, "nao leu a memoria do jogo no trecho %d", i + 1);
      goto fim;
    }
    memcpy(u->on, t[i].on, (size_t)t[i].n);
    memcpy(u->off, t[i].off ? t[i].off : u->original, (size_t)t[i].n);   /* .xml: desligar = voltar o original */
  }
  int todos_on = 1;
  for(int i = 0; i < nt; i++)
    if(memcmp(a->t[i].original, a->t[i].on, (size_t)a->t[i].n)) todos_on = 0;
  if(todos_on) {
    diario("cheats: ligar %s em %s recusado: os bytes ja estao ligados (outra ferramenta?)", nome, j->tid);
    status = recusar(r, 200, "cheats_ligada_fora", "", "os bytes ja estao ligados (outra ferramenta?)");
    goto fim;
  }
  for(int i = 0; i < nt; i++) {
    const trecho_ap_t *u = &a->t[i];
    if(!memcmp(u->original, u->off, (size_t)u->n)) continue;
    char hl[80], he[80];
    hex_txt(hl, sizeof hl, u->original, u->n);
    hex_txt(he, sizeof he, u->off, u->n);
    params_trecho(params, sizeof params, i, u->endereco, u->original, u->off, u->n);
    diario("cheats: ligar %s em %s recusado: trecho %d (0x%llx) tem %s, o desligado do arquivo e %s", nome, j->tid, i + 1,
           (unsigned long long)u->endereco, hl, he);
    status = recusar(r, 200, "cheats_nao_bate", params, "os bytes do trecho %d nao batem com o desligado do arquivo (outra versao?)", i + 1);
    goto fim;
  }
  /* registro ANTES de gravar no jogo: originais em memoria e em aplicadas.json */
  snprintf(a->arquivo, sizeof a->arquivo, "%s", arquivo);
  snprintf(a->nome, sizeof a->nome, "%s", nome);
  a->indice = indice;
  a->inicial = ch->inicial;
  for(int d = 0; d < ch->ndep && d < MAX_DEPS; d++) a->dep[a->ndep++] = ch->dep[d];
  if(!g_ap.n) {
    g_ap.pid = pid;
    g_ap.app_id = j->app_id;
    snprintf(g_ap.tid, sizeof g_ap.tid, "%s", j->tid);
    snprintf(g_ap.versao, sizeof g_ap.versao, "%s", j->versao);
  }
  g_ap.n++;
  if(ap_gravar()) {
    g_ap.n--;
    status = recusar(r, 200, "cheats_registro", "", "nao gravou o registro das cheats (aplicadas.json): nada foi mudado no jogo");
    goto fim;
  }
  diario("cheats: ligando %s em %s (pid %d, %d trecho(s))", nome, j->tid, pid, nt);
  for(int i = 0; i < nt; i++) {
    trecho_ap_t *u = &a->t[i];
    int res = gravar_conferir(pid, u->endereco, u->on, u->n, lido);
    char h1[80], h2[80];
    hex_txt(h1, sizeof h1, u->original, u->n);
    hex_txt(h2, sizeof h2, u->on, u->n);
    diario("cheats:   trecho %d 0x%llx: %s -> %s: %s", i + 1, (unsigned long long)u->endereco, h1, h2,
           !res ? "lido de volta ok" : res == -1 ? "ESCRITA FALHOU" : "LEITURA DE VOLTA DIFERENTE");
    if(res) {
      int desfez = !voltar_trechos(pid, a, i, 1, lido);
      diario("cheats: ligar %s em %s falhou no trecho %d (0x%llx); desfeito: %s", nome, j->tid, i + 1, (unsigned long long)u->endereco,
             desfez ? "OK (jogo como antes)" : "FALHOU (salve e feche o jogo)");
      params_trecho(params, sizeof params, i, u->endereco, NULL, u->on, u->n);
      snprintf(params + strlen(params), sizeof params - strlen(params), ",\"desfeito\":%s", desfez ? "true" : "false");
      aplicada_tirar(g_ap.n - 1);
      a = NULL;
      ap_gravar();
      status = recusar(r, 200, res == -1 ? "cheats_escrita" : "cheats_conferencia", params, "%s no trecho %d",
                       res == -1 ? "a escrita falhou" : "a leitura de volta nao bateu", i + 1);
      goto fim;
    }
  }
  a = NULL;
  diario("cheats: ligou %s em %s (pid %d, %d trecho(s); leitura de volta OK)", nome, j->tid, pid, nt);
  buf_str(r, "{\"ok\":true,\"estado\":\"ligado\",\"nome\":");
  buf_json(r, nome);
  buf_fmt(r, ",\"trechos\":%d}", nt);
  status = 200;
fim:
  if(a) aplicada_liberar(a);   /* registro que nao chegou a valer */
  free(lido);
  free(t);   /* so o vetor: os bytes "on" sao do cache ou do proprio vetor (saltos) */
  return status;
}

/* Campo do pedido: JSON {"tid":..} ou formulario tid=..&.. */
static void campo_pedido(const jv_t *json, const char *corpo, const char *nome, char *saida, size_t tam) {
  saida[0] = 0;
  if(json) snprintf(saida, tam, "%s", jv_txt(json, nome));
  else if(corpo) param(corpo, nome, 0, saida, tam);
}

int cheats_acao(int ligar, const char *corpo, size_t n, buf_t *r) {
  char tid[16], versao[32], arquivo[256], indice_txt[16];
  char *copia = malloc(n + 1);
  if(!copia) return recusar(r, 500, "cheats_memoria", "", "sem memoria");
  if(n) memcpy(copia, corpo, n);
  copia[n] = 0;
  const char *p = copia;
  while(*p == ' ' || *p == '\n' || *p == '\r' || *p == '\t') p++;
  jv_t *json = *p == '{' ? jv_ler(copia, n, NULL) : NULL;
  campo_pedido(json, *p == '{' ? NULL : copia, "tid", tid, sizeof tid);
  campo_pedido(json, *p == '{' ? NULL : copia, "versao", versao, sizeof versao);
  campo_pedido(json, *p == '{' ? NULL : copia, "arquivo", arquivo, sizeof arquivo);
  campo_pedido(json, *p == '{' ? NULL : copia, "indice", indice_txt, sizeof indice_txt);
  jv_liberar(json);
  free(copia);
  size_t na = strlen(arquivo);
  int indice = -1;
  if(indice_txt[0] && strspn(indice_txt, "0123456789") == strlen(indice_txt) && strlen(indice_txt) <= 4) indice = atoi(indice_txt);
  if(!titulo_valido(tid) || !versao_valida(versao) || na < 6 || formato_do_nome(arquivo) < 0 || !nome_valido(arquivo) ||
     arquivo[0] == '.' || indice < 0 || indice >= MAX_CHEATS_ARQ)
    return recusar(r, 400, "cheats_parametros", "", "pedido invalido (tid, versao, arquivo, indice)");

  pthread_mutex_lock(&g_trava_mem);   /* uma escrita por vez (e nenhuma leitura no meio) */
  ap_carregar();
  jogo_t j;
  jogo_aberto(&j);
  jogo_versao(&j);
  int status;
  processos_t pr;
  memset(&pr, 0, sizeof pr);
  uint64_t base = 0;
  int pid = -1;
  if(strcmp(j.tid, tid) || strcmp(j.versao, versao)) {
    status = recusar(r, 200, "cheats_jogo_mudou", "", "o jogo aberto nao e o do pedido (%s v%s)", j.tid[0] ? j.tid : "-", j.versao[0] ? j.versao : "?");
    goto fim;
  }
  processos_do_jogo(&j, &pr);
  pid = pid_do_eboot(&pr, &base);
  int conf = ap_conferir(&j, pid);
  if(conf < 0) {
    status = recusar(r, 200, "cheats_nao_conferiu", "", "nao deu para conferir o jogo agora: tente de novo");
    goto fim;
  }
  if(pid <= 0) {
    status = recusar(r, 200, "cheats_sem_processo", "", "processo eboot.bin do jogo nao encontrado");
    goto fim;
  }
  if(ligar) status = ligar_cheat(&j, pid, base, arquivo, indice, r);
  else {
    int k = aplicada_achar(arquivo, indice);
    if(k < 0) {
      diario("cheats: desligar %s#%d em %s recusado: nao foi ligada pelo glibren%s", arquivo, indice, j.tid, conf == 1 ? " (o jogo mudou)" : "");
      status = recusar(r, 200, conf == 1 ? "cheats_perdida" : "cheats_nao_ligada", "",
                       conf == 1 ? "o jogo fechou: a cheat se perdeu (nada foi gravado)" : "esta cheat nao foi ligada pelo glibren");
    } else status = desligar_k(k, pid, "", r);
  }
fim:
  pthread_mutex_unlock(&g_trava_mem);
  return status;
}

/* 0.9.25: POST /api/cheats/area-extra {"ligado":true|false} (ou ligado=1|0): liga/desliga a opcao de teste pela pagina.
   Desligar com uma cheat de area extra ligada pelo glibren e RECUSADO com os nomes (o usuario desliga cada uma antes,
   vendo o resultado). Escolha mais segura que desligar sozinho: uma chave de configuracao nunca escreve na memoria
   do jogo; desligar varias cheats de uma vez pode parar no meio (dependencias, bytes mudados) e deixar o jogo num
   estado que a pessoa nao viu. Cheats que se perderam (jogo fechou) nao contam: ap_conferir as tira antes.
   Tudo com g_trava_mem: nenhuma cheat liga entre a conferencia e a gravacao do config.ini. */
static int aplicada_usa_area_extra(const aplicada_t *a) {
  if(a->ndep) return 1;   /* salta para a area extra de outra cheat (calcular_dependencias) */
  for(int i = 0; i < a->n; i++)
    if(a->t[i].off && tudo_zero(a->t[i].off, a->t[i].n)) return 1;   /* mesmo criterio de trecho_classificar */
  return 0;
}

int cheats_area_extra_mudar(const char *corpo, size_t n, buf_t *r) {
  char *copia = malloc(n + 1);
  if(!copia) return recusar(r, 500, "cheats_memoria", "", "sem memoria");
  if(n) memcpy(copia, corpo, n);
  copia[n] = 0;
  const char *p = copia;
  while(*p == ' ' || *p == '\n' || *p == '\r' || *p == '\t') p++;
  int ligado = -1;
  if(*p == '{') {
    jv_t *json = jv_ler(copia, n, NULL);
    const jv_t *c = jv_campo(json, "ligado");
    if(c && c->tipo == JV_LOGICO) ligado = c->logico;
    jv_liberar(json);
  } else {
    char v[8] = "";
    param(copia, "ligado", 0, v, sizeof v);
    if(!strcmp(v, "1") || !strcmp(v, "true")) ligado = 1;
    else if(!strcmp(v, "0") || !strcmp(v, "false")) ligado = 0;
  }
  free(copia);
  if(ligado < 0) return recusar(r, 400, "cheats_parametros", "", "pedido invalido (ligado: true ou false)");

  pthread_mutex_lock(&g_trava_mem);
  int status;
  if(!ligado) {
    ap_carregar();
    if(g_ap.n) {
      jogo_t j;
      jogo_aberto(&j);
      processos_t pr;
      memset(&pr, 0, sizeof pr);
      processos_do_jogo(&j, &pr);
      uint64_t base = 0;
      ap_conferir(&j, pid_do_eboot(&pr, &base));   /* jogo fechou/mudou: as ligadas se perderam e saem do registro */
    }
    buf_t nomes = {0};
    int qtd = 0;
    for(int k = 0; k < g_ap.n; k++)
      if(aplicada_usa_area_extra(&g_ap.a[k])) {
        buf_str(&nomes, qtd++ ? ", " : "");
        buf_str(&nomes, g_ap.a[k].nome);
      }
    if(qtd) {
      buf_add(&nomes, "", 0);
      buf_t pj = {0};
      buf_str(&pj, "\"nomes\":");
      buf_json(&pj, nomes.d);
      buf_fmt(&pj, ",\"qtd\":%d", qtd);
      diario("cheats: desligar a area extra (teste) recusado: %d cheat(s) de area extra ligada(s): %s", qtd, nomes.d);
      status = recusar(r, 200, "cheats_area_extra_em_uso", pj.d, "desligue antes as cheats de area extra ligadas: %s", nomes.d);
      buf_free(&pj);
      buf_free(&nomes);
      goto fim;
    }
    buf_free(&nomes);
  }
  if(config_gravar_cheats_area_extra(ligado)) {
    diario("cheats: nao gravou cheats_area_extra no config.ini (errno %d)", errno);
    status = recusar(r, 500, "cheats_config", "", "nao gravou o config.ini");
    goto fim;
  }
  diario("cheats: area extra (teste) %s pela pagina Cheats", ligado ? "LIGADA" : "desligada");
  buf_fmt(r, "{\"ok\":true,\"ligado\":%s}", ligado ? "true" : "false");
  status = 200;
fim:
  pthread_mutex_unlock(&g_trava_mem);
  return status;
}

void cheats_restaurar_ao_sair(void) {
  pthread_mutex_lock(&g_trava_mem);
  ap_carregar();
  if(g_ap.n) {
    jogo_t j;
    jogo_aberto(&j);
    processos_t pr;
    memset(&pr, 0, sizeof pr);
    processos_do_jogo(&j, &pr);
    uint64_t base = 0;
    int pid = pid_do_eboot(&pr, &base);
    int conf = ap_conferir(&j, pid);
    if(conf < 0) diario("cheats: ao fechar: nao deu para conferir o jogo; %d cheat(s) ficam no registro (aplicadas.json)", g_ap.n);
    for(int k = g_ap.n - 1; conf == 0 && k >= 0; k--) {
      buf_t r = {0};
      if(desligar_k(k, pid, " ao fechar o glibren", &r) != 200) diario("cheats: ao fechar: %s continua ligada", g_ap.a[k].nome);
      buf_free(&r);
    }
  }
  pthread_mutex_unlock(&g_trava_mem);
}

#ifndef __PROSPERO__
/* Teste dos parsers (so PC): "glibren-pc --teste-cheat ARQUIVO TID VERSAO" imprime o arquivo lido em JSON (cheats,
   trechos com offset/tipo/bytes, dependencias). Nao le nem grava memoria nenhuma. */
int cheats_teste_arquivo(const char *caminho, const char *tid, const char *versao) {
  int fmt = formato_do_nome(caminho);
  if(fmt < 0) { fprintf(stderr, "formato desconhecido: %s\n", caminho); return 2; }
  cfile_t cf;
  cfile_ler(caminho, fmt, tid, versao, &cf);
  buf_t b = {0};
  buf_fmt(&b, "{\"formato\":\"%s\",\"erro\":", FMT_NOME[fmt]);
  buf_json(&b, cf.erro);
  buf_str(&b, ",\"jogo\":");
  buf_json(&b, cf.jogo);
  buf_str(&b, ",\"processo\":");
  buf_json(&b, cf.processo);
  buf_str(&b, ",\"versao\":");
  buf_json(&b, cf.versao);
  buf_fmt(&b, ",\"codigo_inicial\":%s,\"impressao\":\"%016llx\",\"creditos\":[", cf.tem_inicial ? "true" : "false",
          (unsigned long long)cf.impressao);
  for(int k = 0; k < cf.ncred; k++) {
    if(k) buf_str(&b, ",");
    buf_json(&b, cf.creditos[k]);
  }
  buf_str(&b, "],\"cheats\":[");
  for(int i = 0; i < cf.n; i++) {
    const cheat_t *c = &cf.c[i];
    buf_str(&b, i ? ",\n{\"nome\":" : "\n{\"nome\":");
    buf_json(&b, c->nome);
    buf_str(&b, ",\"descricao\":");
    buf_json(&b, c->descricao);
    buf_str(&b, ",\"modulo\":");
    buf_json(&b, c->modulo);
    buf_fmt(&b, ",\"inicial\":%s,\"invalido\":%s,\"dep\":[", c->inicial ? "true" : "false", c->invalido ? "true" : "false");
    for(int d = 0; d < c->ndep; d++) buf_fmt(&b, "%s%d", d ? "," : "", c->dep[d]);
    buf_fmt(&b, "],\"ndep\":%d,\"suporte\":", c->ndep);
    char dep[160];
    buf_json(&b, cheat_suporte(&cf, i, "", NULL, dep, sizeof dep));
    buf_str(&b, ",\"trechos\":[");
    for(int k = 0; k < c->nt; k++) {
      const trecho_t *t = &c->t[k];
      buf_fmt(&b, "%s{\"offset\":\"%llX\",\"tipo\":\"%s\",\"n\":%d,\"on\":", k ? "," : "", (unsigned long long)t->offset, t->tipo, t->n);
      if(t->on) hex_todo(&b, t->on, t->n);
      else buf_str(&b, "\"\"");
      buf_str(&b, ",\"off\":");
      if(t->off) hex_todo(&b, t->off, t->n);
      else buf_str(&b, "\"\"");
      if(t->padrao) {
        char h[3 * 32 + 4];
        hex_txt_simples(h, sizeof h, t->padrao, t->mascara, t->np);
        buf_str(&b, ",\"padrao\":");
        buf_json(&b, h);
        buf_fmt(&b, ",\"np\":%d,\"desloc\":%lld", t->np, (long long)t->desloc);
      }
      buf_str(&b, "}");
    }
    buf_str(&b, "]}");
  }
  buf_str(&b, "]}\n");
  fwrite(b.d, 1, b.n, stdout);
  buf_free(&b);
  int r = cf.erro[0] ? 1 : 0;
  cfile_liberar(&cf);
  return r;
}
#endif
