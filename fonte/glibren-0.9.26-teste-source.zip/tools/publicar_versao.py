"""Prepara uma versao do glibren para o repositorio publico de versoes (pristmc-code/ps5-glibren-releases).

Uso:  python tools/publicar_versao.py PASTA_DO_REPO_PUBLICO "notas da versao" [--titulo=TEXTO] [--rodape=ARQUIVO]
                                       [--sem-testes] [--simular]
Depois: git push na pasta do repositorio publico (os dois commits vao juntos).

Para em qualquer problema, antes de gravar qualquer coisa no repositorio publico:
1. o repositorio do payload tem de estar limpo (tudo commitado): o binario e o fonte publicados saem do mesmo HEAD;
2. compila do zero no WSL (compilar.sh clean + all), nunca reaproveita um build antigo;
3. roda todos os testes do PC (compilar.sh pc + testes/todos.sh), salvo --sem-testes;
4. confere o marcador exato "GLIBREN-VERSAO:<versao>\\n" no .elf e que a versao e maior que a ja publicada;
5. assina saida/glibren.elf com a chave privada Ed25519 (fica so neste PC, fora do repositorio) e confere a
   assinatura com a chave publica embutida no payload (src/chave_publica.h);
6. gera fonte/glibren-<versao>-source.zip do HEAD (git archive);
7. passa tudo pela checagem de privacidade (ps5/ferramentas/privacidade.py), que bloqueia;
8. (0.9.24) publica em DOIS commits no repositorio publico (que tem de estar limpo):
   a) glibren.elf, glibren.elf.sig e o zip do fonte; confere que esse commit tem exatamente o .elf e a .sig novos;
   b) o versao.json com "commit" = o hash do commit (a) e "commit_fonte" = o HEAD do repositorio do payload.
   O payload 0.9.24+ baixa o .elf de raw.githubusercontent.com/.../<commit>/glibren.elf, endereco imutavel: o cache
   do "main" no CDN do GitHub guarda cada arquivo separadamente por alguns minutos e chegou a entregar o versao.json
   novo com o .elf velho (PS5 real, 13/11/2026). Por isso o versao.json nunca pode apontar para um commit em que o
   .elf ainda e o velho. Titulo do commit (b): --titulo (padrao: as notas); --rodape = arquivo com as linhas finais
   das mensagens (Co-Authored-By etc.).
Com --simular faz tudo numa pasta temporaria e nao toca no repositorio publico.
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

from cryptography.hazmat.primitives import serialization

CHAVE = os.path.join(os.path.expanduser("~"), ".glibren", "assinatura_ed25519.pem")
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PRIVACIDADE = os.path.join(os.path.dirname(RAIZ), "ferramentas", "privacidade.py")


def parar(msg):
    print(f"PARAR: {msg}")
    sys.exit(1)


def git(*args):
    return subprocess.run(["git", "-C", RAIZ, *args], capture_output=True, text=True, check=True).stdout


def git_pub(destino, *args):
    return subprocess.run(["git", "-C", destino, *args], capture_output=True, text=True, check=True).stdout


def git_pub_bytes(destino, *args):
    return subprocess.run(["git", "-C", destino, *args], capture_output=True, check=True).stdout


def commitar(destino, mensagem, arquivos):
    git_pub(destino, "add", "--", *arquivos)
    subprocess.run(["git", "-C", destino, "commit", "-q", "-F", "-"], input=mensagem.encode("utf-8"), check=True)
    return git_pub(destino, "rev-parse", "HEAD").strip()


def caminho_wsl(p):
    p = os.path.abspath(p).replace("\\", "/")
    return f"/mnt/{p[0].lower()}{p[2:]}"


def wsl(script, *args, trava=False):
    # trava: os testes do PC usam portas fixas; /tmp/ps5-testes.lock evita rodar junto com outra suite
    pre = ["flock", "/tmp/ps5-testes.lock"] if trava else []
    r = subprocess.run(["wsl", "-d", "Ubuntu-24.04", "-u", "root", "--", *pre, "bash", caminho_wsl(script), *args])
    if r.returncode:
        parar(f"{os.path.basename(script)} {' '.join(args)} falhou (saida {r.returncode})")


def numero_versao(v):
    """Igual ao numero_versao() do payload (atualizacao.c): so os numeros, ate 3 partes."""
    partes = re.findall(r"\d+", v.split("-")[0])[:3]
    n = 0
    for i in range(3):
        n = n * 1000 + (int(partes[i]) if i < len(partes) else 0)
    return n


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    sem_testes, simular = "--sem-testes" in sys.argv, "--simular" in sys.argv
    opcoes = dict(a[2:].split("=", 1) for a in sys.argv[1:] if a.startswith("--") and "=" in a)
    if len(args) < 2:
        print(__doc__)
        return 1
    destino, notas = args[0], args[1]
    if not os.path.exists(PRIVACIDADE):
        parar(f"falta {PRIVACIDADE}")
    titulo = opcoes.get("titulo", notas)
    rodape = open(opcoes["rodape"], encoding="utf-8").read().strip() if "rodape" in opcoes else ""
    if not simular:
        if not os.path.isdir(os.path.join(destino, ".git")):
            parar(f"{destino} nao e o repositorio publico (sem .git)")
        if git_pub(destino, "status", "--porcelain").strip():
            parar("o repositorio publico tem mudancas sem commit")
        if git_pub(destino, "rev-parse", "--abbrev-ref", "HEAD").strip() != "main":
            parar("o repositorio publico nao esta no branch main")

    # 1) repositorio limpo
    sujo = git("status", "--porcelain")
    if sujo.strip():
        parar("o repositorio do payload tem mudancas sem commit:\n" + sujo)
    commit = git("rev-parse", "HEAD").strip()
    versao = re.search(r'#define VERSAO "([^"]+)"', open(os.path.join(RAIZ, "src", "api.h"), encoding="utf-8").read()).group(1)
    publicada = os.path.join(destino, "versao.json")
    if os.path.exists(publicada):
        anterior = json.load(open(publicada, encoding="utf-8")).get("versao", "")
        if numero_versao(versao) <= numero_versao(anterior):
            if not simular:
                parar(f"a versao {versao} nao e maior que a publicada ({anterior})")
            print(f"AVISO (simulacao): a versao {versao} nao e maior que a publicada ({anterior}); publicar seria recusado")
    print(f"versao {versao}, commit {commit[:12]}")

    # 2) e 3) compilar do zero e testar
    compilar = os.path.join(RAIZ, "compilar.sh")
    for velho in ("glibren.elf", "glibren-pc"):   # um build que nao gerar nada nao deixa o antigo no lugar
        if os.path.exists(os.path.join(RAIZ, "saida", velho)):
            os.remove(os.path.join(RAIZ, "saida", velho))
    wsl(compilar, "clean")
    wsl(compilar, "all")
    if not sem_testes:
        wsl(compilar, "pc")
        wsl(os.path.join(RAIZ, "testes", "todos.sh"), trava=True)
    if git("status", "--porcelain").strip():
        parar("a compilacao ou os testes mudaram arquivos do repositorio")

    # 4) marcador exato
    elf = open(os.path.join(RAIZ, "saida", "glibren.elf"), "rb").read()
    if f"GLIBREN-VERSAO:{versao}\n".encode() not in elf:
        parar(f"saida/glibren.elf nao tem o marcador da versao {versao}")

    # 5) assinatura
    chave = serialization.load_pem_private_key(open(CHAVE, "rb").read(), None)
    publica = chave.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    embutida = bytes(int(x, 16) for x in re.findall(r"0x([0-9a-f]{2})", open(os.path.join(RAIZ, "src", "chave_publica.h"), encoding="utf-8").read()))
    if publica != embutida:
        parar("a chave privada nao corresponde a chave publica embutida no payload")
    assinatura = chave.sign(elf)
    chave.public_key().verify(assinatura, elf)   # confere antes de publicar
    del chave

    # 6) arquivos numa pasta temporaria
    tmp = tempfile.mkdtemp(prefix="glibren-pub-")
    os.makedirs(os.path.join(tmp, "fonte"))
    open(os.path.join(tmp, "glibren.elf"), "wb").write(elf)
    open(os.path.join(tmp, "glibren.elf.sig"), "wb").write(assinatura)
    # "commit" (repositorio publico) so e conhecido depois do commit (a); na simulacao fica um marcador
    info = {"versao": versao, "notas": notas, "tamanho": len(elf), "sha256": hashlib.sha256(elf).hexdigest(),
            "commit": "0" * 40, "commit_fonte": commit}

    def gravar_json(pasta):
        with open(os.path.join(pasta, "versao.json"), "w", encoding="utf-8", newline="\n") as f:
            json.dump(info, f, ensure_ascii=False, indent=2)
            f.write("\n")

    gravar_json(tmp)
    zip_nome = f"glibren-{versao}-source.zip"
    if os.path.exists(os.path.join(destino, "fonte", zip_nome)):
        if not simular:
            parar(f"fonte/{zip_nome} ja existe no repositorio publico")
        print(f"AVISO (simulacao): fonte/{zip_nome} ja existe no repositorio publico; publicar seria recusado")
    git("archive", "--format=zip", "-o", os.path.join(tmp, "fonte", zip_nome), "HEAD")

    # 7) privacidade
    r = subprocess.run([sys.executable, PRIVACIDADE, os.path.join(tmp, "glibren.elf"), os.path.join(tmp, "versao.json"),
                        os.path.join(tmp, "fonte", zip_nome)])
    if r.returncode:
        shutil.rmtree(tmp)
        parar("a checagem de privacidade acusou algo (nada foi gravado)")

    if simular:
        print(f"SIMULACAO: arquivos em {tmp} (o repositorio publico nao foi tocado)")
        return 0
    def mensagem(t):
        return f"glibren {versao}: {t}" + (f"\n\n{rodape}\n" if rodape else "\n")

    # 8a) commit com o .elf, a .sig e o fonte
    os.makedirs(os.path.join(destino, "fonte"), exist_ok=True)
    arquivos = ["glibren.elf", "glibren.elf.sig", f"fonte/{zip_nome}"]
    for nome in arquivos:
        shutil.copyfile(os.path.join(tmp, nome), os.path.join(destino, nome))
    commit_pub = commitar(destino, mensagem("arquivos da versao (elf, assinatura e fonte)"), arquivos)
    if git_pub_bytes(destino, "show", f"{commit_pub}:glibren.elf") != elf or \
            git_pub_bytes(destino, "show", f"{commit_pub}:glibren.elf.sig") != assinatura:
        parar(f"o commit {commit_pub[:12]} do repositorio publico nao tem o .elf/.sig desta versao (nada foi enviado)")

    # 8b) versao.json apontando para esse commit
    info["commit"] = commit_pub
    gravar_json(tmp)
    r = subprocess.run([sys.executable, PRIVACIDADE, os.path.join(tmp, "versao.json")])
    if r.returncode:
        parar("a checagem de privacidade acusou algo no versao.json final (o commit dos arquivos ficou local, sem push)")
    shutil.copyfile(os.path.join(tmp, "versao.json"), os.path.join(destino, "versao.json"))
    commit_json = commitar(destino, mensagem(titulo), ["versao.json"])
    shutil.rmtree(tmp)
    print(f"versao {versao} pronta em {destino} ({len(elf)} bytes, sha256 {info['sha256'][:16]}..., fonte {commit[:12]})")
    print(f"commit dos arquivos {commit_pub}, commit do versao.json {commit_json[:12]}; falta: git -C {destino} push")
    return 0


if __name__ == "__main__":
    sys.exit(main())
