/* Game Library Renamer (payload PS5) - instalador/atualizador de apps homebrew (catalogo assinado) e botao YouTube. */
#pragma once

#include <stddef.h>
#include "util.h"

/* {"ok","catalogo","erro","apps":[...],"trabalho":{...}}; forcar = baixa o catalogo agora (senao, a cada 15 min). */
void apps_json(buf_t *json, int forcar);
/* Baixa, confere e instala o app "id" do catalogo numa thread (um trabalho por vez). 0 = iniciou. */
int apps_instalar(const char *id, char *msg, size_t tam);
/* Texto de diagnostico: hora do PS5 e o final do log do app (ytps5: yt.log, so com o app aberto). */
void apps_log(const char *id, buf_t *b);
/* Desinstala o app "id" do catalogo numa thread (o ShadowMountPlus tira o icone; a pasta e apagada). 0 = iniciou. */
int apps_desinstalar(const char *id, char *msg, size_t tam);
/* Grava a busca no app de YouTube instalado (ytps5, depois YouTube Max'd) e abre o app. 0 = ok (json recebe a
   resposta); senao chave/msg explicam (chave "sem_app_youtube" = nenhum instalado). */
int apps_youtube(const char *busca, buf_t *json, char *chave, size_t tam_chave, char *msg, size_t tam_msg);
