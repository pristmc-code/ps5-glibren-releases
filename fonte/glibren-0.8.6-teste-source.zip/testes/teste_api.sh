#!/bin/bash
# Testa a versao de PC do payload no WSL com pastas de PS5 de mentira (arquivos esparsos: nao ocupam disco).
#   wsl -d Ubuntu-24.04 -u root -- bash testes/teste_api.sh
ORIGEM="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="$ORIGEM/saida/glibren-pc"
DADOS=/root/glr-dados-api
PORTA=8799
U="http://127.0.0.1:$PORTA"
ok=0; falhou=0
confere() { if echo "$2" | grep -q -- "$3"; then echo "OK   $1"; ok=$((ok+1)); else echo "FALHOU $1 -> $2"; falhou=$((falhou+1)); fi; }

rm -rf /data/homebrew /mnt/ext1/homebrew "$DADOS"
mkdir -p /data/homebrew/subpasta /mnt/ext1/homebrew
G=$((1024*1024*1024))
truncate -s $((90*G)) "/data/homebrew/PPSA08329-app.pkg"
truncate -s $((38*G)) "/data/homebrew/CUSA07408 God of War.pkg"
truncate -s $((12*G)) "/data/homebrew/PPSA01453-blackbox.exfat.part"
truncate -s $((40*G)) "/data/homebrew/PPSA01411.ffpkg"
truncate -s 100 "/data/homebrew/PPSA01411.ffpkg.aria2"
truncate -s $((49*G)) "/mnt/ext1/homebrew/PPSA04609-elden.exfat"
truncate -s $((5*G)) "/mnt/ext1/homebrew/God_of_War-CUSA07408-US-PS4.pkg"

"$BIN" -p $PORTA -d "$DADOS" > /tmp/glr.log 2>&1 &
PID=$!
sleep 1

confere "pagina"            "$(curl -s $U/)" "Game Library Renamer"
confere "estado"            "$(curl -s $U/api/estado)" '"pastas":\["/data/homebrew/","/mnt/ext1/homebrew/"\]'
confere "fs raiz"           "$(curl -s "$U/api/fs?caminho=/")" '"nome":"data","tipo":"pasta"'
confere "fs homebrew"       "$(curl -s "$U/api/fs?caminho=/data/homebrew")" '"nome":"subpasta","tipo":"pasta"'
confere "fs caminho .."     "$(curl -s "$U/api/fs?caminho=/data/../etc")" 'pasta_invalida'
confere "escanear"          "$(curl -s $U/api/escanear)" '"nome":"PPSA08329-app.pkg","tipo":"arquivo","tamanho":96636764160'
confere "escanear sem pasta" "$(curl -s $U/api/escanear)" '"existe":true,"qtd":5'
confere "POST sem X-GLR"    "$(curl -s -o /dev/null -w '%{http_code}' -X POST -d 'pasta=/x' $U/api/pastas)" '403'
confere "pastas invalida"   "$(curl -s -H 'X-GLR: 1' -d 'pasta=relativa' $U/api/pastas)" 'pasta_invalida'
confere "pastas grava"      "$(curl -s -H 'X-GLR: 1' -d 'pasta=/data/homebrew/&pasta=/mnt/ext1/homebrew/&pasta=/data/homebrew/' $U/api/pastas)" '"pastas":\["/data/homebrew/","/mnt/ext1/homebrew/"\]'
confere "idioma"            "$(curl -s -H 'X-GLR: 1' -d 'idioma=en' $U/api/idioma; curl -s $U/api/estado)" '"idioma":"en"'
confere "ren .part"         "$(curl -s -H 'X-GLR: 1' --data-urlencode 'pasta=/data/homebrew/' --data-urlencode 'de=PPSA01453-blackbox.exfat.part' --data-urlencode 'para=X.part' $U/api/renomear)" 'em_download'
confere "ren aria2 ao lado" "$(curl -s -H 'X-GLR: 1' --data-urlencode 'pasta=/data/homebrew/' --data-urlencode 'de=PPSA01411.ffpkg' --data-urlencode 'para=X.ffpkg' $U/api/renomear)" 'em_download'
confere "ren tamanho mudou" "$(curl -s -H 'X-GLR: 1' --data-urlencode 'pasta=/data/homebrew/' --data-urlencode 'de=PPSA08329-app.pkg' --data-urlencode 'para=X.pkg' --data-urlencode 'tamanho=123' $U/api/renomear)" 'em_download'
confere "ren destino existe" "$(curl -s -H 'X-GLR: 1' --data-urlencode 'pasta=/mnt/ext1/homebrew/' --data-urlencode 'de=PPSA04609-elden.exfat' --data-urlencode 'para=God_of_War-CUSA07408-US-PS4.pkg' $U/api/renomear)" 'destino_existe'
confere "ren nome com /"    "$(curl -s -H 'X-GLR: 1' --data-urlencode 'pasta=/data/homebrew/' --data-urlencode 'de=PPSA08329-app.pkg' --data-urlencode 'para=../x.pkg' $U/api/renomear)" 'nome_invalido'
confere "ren origem sumiu"  "$(curl -s -H 'X-GLR: 1' --data-urlencode 'pasta=/data/homebrew/' --data-urlencode 'de=nao-existe.pkg' --data-urlencode 'para=y.pkg' $U/api/renomear)" 'origem_sumiu'
confere "ren ok"            "$(curl -s -H 'X-GLR: 1' --data-urlencode 'pasta=/data/homebrew/' --data-urlencode 'de=PPSA08329-app.pkg' --data-urlencode 'para=God_of_War_Ragnarok-PPSA08329-US-PS5.pkg' --data-urlencode "tamanho=$((90*G))" $U/api/renomear)" '"ok":true'
confere "ren conferido"     "$(ls /data/homebrew)" 'God_of_War_Ragnarok-PPSA08329-US-PS5.pkg'
confere "cache vazio"       "$(curl -s $U/api/cache)" '{}'
confere "cache grava"       "$(curl -s -H 'X-GLR: 1' -H 'Content-Type: application/json' -d '{"PPSA08329":{"status":"ok"}}' $U/api/cache; curl -s $U/api/cache)" 'PPSA08329'
confere "web fora da lista" "$(curl -s -o /dev/null -w '%{http_code}' "$U/api/web?url=https://example.com/")" '403'
confere "icone codigo ruim" "$(curl -s -o /dev/null -w '%{http_code}' "$U/icone/../../etc")" '404'
echo "--- internet (base de titulos, site e icone)"
for i in $(seq 1 30); do s=$(curl -s $U/api/estado); echo "$s" | grep -q '"situacao":"ok"' && break; sleep 2; done
confere "base baixada"      "$s" '"situacao":"ok"'
confere "base servida"      "$(curl -s $U/base_titulos.tsv | head -c 8)" 'titleId'
confere "base 304"          "$(E=$(curl -sI $U/base_titulos.tsv | grep -i etag | cut -d' ' -f2 | tr -d '\r'); curl -s -o /dev/null -w '%{http_code}' -H "If-None-Match: $E" $U/base_titulos.tsv)" '304'
confere "web prosperopatches" "$(curl -s "$U/api/web?url=https://prosperopatches.com/PPSA08329")" 'og:title'
ICONE=$(curl -s "$U/api/web?url=https://prosperopatches.com/PPSA08329" | grep -o 'class="game-icon[^"]*"[^>]*url(https://[^)]*)' | grep -o 'https://[^)]*' | head -1)
confere "icone baixa"       "$(curl -s -o /tmp/icone.bin -w '%{http_code} %{content_type}' "$U/icone/PPSA08329?url=$(python3 -c 'import sys,urllib.parse;print(urllib.parse.quote(sys.argv[1],safe=""))' "$ICONE")")" '200 image/'
confere "icone do disco"    "$(curl -s -o /dev/null -w '%{http_code}' "$U/icone/PPSA08329")" '200'
echo "--- energia (desligar / repouso; no PC so registra no diario)"
confere "energia sem X-GLR"  "$(curl -s -o /dev/null -w '%{http_code}' -X POST -d 'acao=desligar' $U/api/energia)" '403'
confere "energia por GET"    "$(curl -s -o /dev/null -w '%{http_code}' "$U/api/energia?acao=desligar")" '404'
confere "energia invalida"   "$(curl -s -H 'X-GLR: 1' -d 'acao=explodir' $U/api/energia)" 'acao invalida'
confere "energia repouso"    "$(curl -s -H 'X-GLR: 1' -d 'acao=repouso' $U/api/energia)" '"ok":true'
confere "energia 1 por vez"  "$(curl -s -H 'X-GLR: 1' -d 'acao=desligar' $U/api/energia)" 'em andamento'
sleep 4
confere "repouso no diario"  "$(curl -s $U/diario)" 'energia (PC): modo de repouso - no PS5 chamaria sceSystemStateMgrEnterStandby'
confere "energia desligar"   "$(curl -s -H 'X-GLR: 1' -d 'acao=desligar' $U/api/energia)" '"ok":true'
sleep 4
confere "desligar no diario" "$(curl -s $U/diario)" 'energia (PC): desligar - no PS5 chamaria sceSystemStateMgrTurnOff'
confere "segue rodando (PC)" "$(curl -s $U/api/estado)" '"pastas"'
confere "sair"              "$(curl -s -H 'X-GLR: 1' -X POST $U/api/sair)" '"ok":true'
sleep 1
confere "processo encerrou" "$(kill -0 $PID 2>&1 || echo encerrado)" 'encerrado'
echo "=== $ok ok, $falhou falharam"
echo "--- log do payload:"; cat /tmp/glr.log
